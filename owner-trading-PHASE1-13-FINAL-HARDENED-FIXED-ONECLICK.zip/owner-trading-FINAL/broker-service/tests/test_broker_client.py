import dataclasses
import unittest
from unittest.mock import AsyncMock, patch

from app import broker_client as bc
from app import credential_manager as cm
from app import sdk_adapter as a
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI


class ClientBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.holder = {}

        def factory(**kw):
            n = FakeNeoAPI(**kw)
            n.responses["limits"] = {"stat": "Ok", "stCode": 200, "Net": "1000"}
            n.responses["order_report"] = {"stat": "Ok", "stCode": 200, "data": []}
            n.responses["trade_report"] = {"stat": "ok", "stCode": 200, "data": []}
            n.responses["positions"] = {"stat": "Ok", "stCode": 200, "data": []}
            n.responses["holdings"] = {"data": []}
            self.holder["neo"] = n
            return n

        self.ps = [patch.object(a, "SDK_AVAILABLE", True), patch.object(a, "SDK_VERSION", "3.0.7"), patch.object(a, "NeoAPI", factory),
                   patch.object(cm.credential_manager, "current_totp_code", return_value="123456"),
                   patch("app.websocket_manager.websocket_manager.start", new=AsyncMock()),
                   patch("app.websocket_manager.websocket_manager.stop", new=AsyncMock())]
        for p in self.ps:
            p.start()
        cm.credential_manager.set(consumer_key="ck", mobile_number="9999999999", ucc="U1", mpin="1234", totp_secret="S")
        current_state.transition(BrokerState.DISCONNECTED)
        self.client = bc.BrokerClient()

    async def asyncTearDown(self):
        for p in self.ps:
            p.stop()
        cm.credential_manager.clear()
        current_state.transition(BrokerState.DISCONNECTED)


class ConnectTests(ClientBase):
    async def test_connect_success_reaches_connected_only_after_verification(self):
        r = await self.client.connect()
        self.assertEqual(r["state"], "CONNECTED")
        names = [n for n, _ in self.holder["neo"].calls]
        self.assertEqual(names[:3], ["totp_login", "totp_validate", "limits"])   # verified via a read-only call
        self.assertIsNotNone(self.client.sdk)

    async def test_consumer_key_and_env_passed_to_sdk(self):
        seen = {}
        orig = a.NeoAPI
        def spy(**kw):
            seen.update(kw)
            return orig(**kw)
        with patch.object(a, "NeoAPI", spy):
            await self.client.connect()
        self.assertEqual(seen["consumer_key"], "ck")
        self.assertIn(seen["environment"], ("prod", "uat"))

    async def test_bad_mpin_is_auth_failed_and_no_session_kept(self):
        orig = a.NeoAPI
        def bad(**kw):
            n = orig(**kw)
            n.login_ok = False
            return n
        with patch.object(a, "NeoAPI", bad):
            r = await self.client.connect()
        self.assertEqual(r["state"], "AUTH_FAILED")
        self.assertIsNone(self.client.sdk)

    async def test_limits_rejected_after_login_is_auth_failed(self):
        orig = a.NeoAPI
        def f(**kw):
            n = orig(**kw)
            n.responses["limits"] = {"stCode": 1005, "errMsg": "not authorised"}
            return n
        with patch.object(a, "NeoAPI", f):
            r = await self.client.connect()
        self.assertEqual(r["state"], "AUTH_FAILED")

    async def test_transport_failure_is_connection_error(self):
        def boom(**kw):
            raise ConnectionError("dns")
        with patch.object(a, "NeoAPI", boom):
            r = await self.client.connect()
        self.assertEqual(r["state"], "CONNECTION_ERROR")

    async def test_sdk_missing_or_wrong_version_never_attempts_login(self):
        with patch.object(a, "SDK_VERSION", "3.0.6"):
            r = await self.client.connect()
        self.assertEqual(r["state"], "CONNECTION_ERROR")
        self.assertNotIn("neo", self.holder)

    async def test_not_configured(self):
        cm.credential_manager.clear()
        r = await self.client.connect()
        self.assertEqual(r["state"], "NOT_CONFIGURED")

    async def test_test_connection_does_not_keep_session(self):
        r = await self.client.test_connection()
        self.assertTrue(r["success"])
        self.assertIsNone(self.client.sdk)
        self.assertTrue(self.holder["neo"].logged_out)
        self.assertNotEqual(current_state.state, BrokerState.CONNECTED)

    async def test_no_secret_leaks_into_state_or_errors(self):
        orig = a.NeoAPI
        def bad(**kw):
            n = orig(**kw)
            n.login_ok = False
            return n
        with patch.object(a, "NeoAPI", bad):
            r = await self.client.connect()
        blob = str(r) + str(self.client.sdk)
        for secret in ("1234", "123456", "S"):
            if len(secret) > 1:
                self.assertNotIn(secret, blob)

    async def test_disconnect_logs_out_and_clears(self):
        await self.client.connect()
        neo = self.holder["neo"]
        r = await self.client.disconnect()
        self.assertEqual(r["state"], "DISCONNECTED")
        self.assertTrue(neo.logged_out)
        self.assertIsNone(self.client.sdk)

    async def test_reconnect(self):
        await self.client.connect()
        first = self.holder["neo"]
        r = await self.client.reconnect()
        self.assertEqual(r["state"], "CONNECTED")
        self.assertIsNot(first, self.holder["neo"])


class GateTests(ClientBase):
    async def test_reads_require_connection(self):
        with self.assertRaises(bc.NotConfiguredError):
            self.client.read("positions")

    async def test_read_allowlist(self):
        await self.client.connect()
        with self.assertRaises(ValueError):
            self.client.read("place_order")
        with self.assertRaises(ValueError):
            self.client.read("logout")

    async def test_state_changing_calls_are_gated_in_live_mode(self):
        await self.client.connect()
        cfg = dataclasses.replace(bc.config, trading_mode="LIVE")
        with patch.object(bc, "config", cfg):
            with self.assertRaises(bc.LiveTradingBlockedError):
                self.client.cancel_order(order_id="1")
            with self.assertRaises(bc.LiveTradingBlockedError):
                self.client.modify_order(order_id="1", order_type="L", quantity=1, validity="DAY", price=1)
        self.assertNotIn("cancel_order", [n for n, _ in self.holder["neo"].calls])


if __name__ == "__main__":
    unittest.main()
