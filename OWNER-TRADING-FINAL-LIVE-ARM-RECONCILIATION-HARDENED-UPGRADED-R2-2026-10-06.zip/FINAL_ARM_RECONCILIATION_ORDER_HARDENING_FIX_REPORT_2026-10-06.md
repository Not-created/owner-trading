# Owner Trading — Final ARM / Reconciliation / LIVE Order Hardening

Date: 2026-10-06

## Scope

This release fixes the LIVE ARM chain and the next hidden LIVE-order blockers found during the line-by-line audit of the 2026-10-05 build. Existing scanner, strategy, broker, order, reconciliation, database, deployment and UI scope is preserved.

## Fixed

1. **Kotak SDK nested REST Error normalization**
   - Handles the official SDK REST pattern `{ "Error": ApiException(...) }`.
   - Promotes `ApiException.body` fields (`stCode`, `errMsg`, `stat`) into the canonical response path.
   - Raised and internally-caught SDK errors now follow the same classifier.
   - Exact documented `5203 / No Data` is treated as an empty read-only collection only in the four collection endpoints.
   - Exact endpoint-specific empty-account `424` responses are treated as empty only for orders/trades/positions/holdings.
   - Generic 424, auth failures, rate limits, 5xx and transport failures remain blocking.

2. **Reconciliation concurrency / ARM race**
   - Concurrent reconciliation callers wait for the existing in-flight reconciliation task.
   - No caller receives a misleading `skipped` result.
   - ARM therefore evaluates the completed reconciliation rather than stale persisted state.

3. **Correct reconciliation freshness**
   - Reconciliation freshness is now based on `reconciliation_runs.completed_at`.
   - Funds snapshot freshness remains a separate mandatory gate.
   - Future/invalid timestamps fail closed.
   - Final production audit also checks reconciliation and funds freshness.

4. **Global LIVE ARM commit race**
   - Explicit ARM transitions are serialized.
   - A final readiness evaluation occurs immediately before persisting `live_trading_armed`.
   - Existing order-time LIVE safety gates remain unchanged.

5. **Strategy LIVE ARM commit race**
   - Strategy feed acquisition + pre-commit readiness + strategy ARM state transition are serialized.
   - Post-arm readiness and rollback behavior is preserved.
   - Existing strategy-specific scanner/subscription isolation is preserved.

6. **Strategy ARM diagnostics**
   - Strategy UI now displays the exact failed readiness gates returned by the backend instead of only a generic ARM failure.

7. **Official Kotak margin response compatibility**
   - LIVE margin parsing now recognizes official `reqdMrgn` first and `ordMrgn` as fallback before generic aliases.
   - This prevents a valid official margin response from being incorrectly treated as “required margin unavailable”.

8. **LIVE instrument identity hardening**
   - Every LIVE order must resolve `(exchange_segment, instrument_token)` in the authoritative scrip master.
   - The supplied `trading_symbol` must exactly match the authoritative symbol.

9. **LIVE lot-size validation**
   - Quantity must be a positive multiple of the authoritative instrument `lot_size`.

10. **LIVE tick-size validation**
    - Supplied limit/trigger prices must align exactly with authoritative `tick_size`.
    - Market orders without a price are unaffected.

## Tests added/updated

- Nested SDK `Error` + 424 empty collection regression tests.
- Nested SDK `Error` + generic 424 blocking test.
- Nested SDK `Error` + 5203 No Data test.
- Official `reqdMrgn` / `ordMrgn` margin response test.
- Token/symbol mismatch test.
- Lot-size test.
- Tick-size test.
- Concurrent reconciliation wait test.
- Separate reconciliation-vs-funds freshness test.
- ARM tests updated for final pre-commit readiness checks.

## Validation performed

- Broker Python test suite: **352 passed, 3 skipped**.
- Python bytecode compilation: **PASS**.
- `deploy.sh` shell syntax: **PASS**.
- Backend Node test suite: **26 passed, 6 skipped**.
- Fresh SQLite migration + idempotency tests: **PASS**.
- Official SDK conformance/integrity tests: included in passing broker suite.
- Uploaded official Kotak SDK source compared against vendored `neo_api_client`: **no source differences**.

## Frontend build note

The supplied frontend ZIP did not contain `node_modules`; the environment could not complete dependency installation within the validation window, so a fresh Vite production build could not be independently executed here. Frontend source was modified only for the Strategy ARM diagnostic display and no package/dependency changes were introduced.

## LIVE safety invariant

No fix bypasses the LIVE order gate. ARM only becomes possible after the readiness chain is clean and fresh, and order submission continues to require the final broker/feed/reconciliation/risk/idempotency/funds checks.
