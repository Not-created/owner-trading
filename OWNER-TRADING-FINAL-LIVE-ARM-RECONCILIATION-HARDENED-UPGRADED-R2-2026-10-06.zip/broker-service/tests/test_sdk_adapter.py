import unittest

from app import sdk_adapter as a
from tests.fakes import FakeNeoAPI


def sdk():
    s = a.KotakSdk("ck", "prod", neo_factory=FakeNeoAPI)
    return s, s._neo


def logged_in():
    s, neo = sdk()
    assert s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234").ok
    return s, neo


class ClassifyTests(unittest.TestCase):
    def test_success_with_order_number(self):
        o = a.classify({"stat": "Ok", "nOrdNo": "2606000001", "stCode": 200}, expect_order_id=True, state_changing=True)
        self.assertTrue(o.ok)
        self.assertEqual(o.order_id, "2606000001")

    def test_no_session_is_auth(self):
        o = a.classify({"Error Message": "Complete the 2fa process before accessing this application"}, state_changing=True)
        self.assertEqual(o.kind, a.AUTH)

    def test_capital_Error_with_validation_exception_is_definitive_rejection(self):
        # the SDK raises ApiValueError for its own validation failures; match by class name
        class ApiValueError(Exception):
            pass
        o = a.classify({"Error": ApiValueError("Invalid quantity")}, state_changing=True)
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "VALIDATION")

    def test_transport_exception_on_state_change_is_unknown_not_rejected(self):
        class ApiException(Exception):
            status = 0
        o = a.classify({"Error": ApiException("timed out")}, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_transport_exception_on_read_is_not_unknown(self):
        class ApiException(Exception):
            status = 0
        self.assertEqual(a.classify({"Error": ApiException("x")}).kind, a.REJECTED)

    def test_modify_generic_string_error_on_state_change_is_unknown(self):
        o = a.classify({"Error": "Exception has been occurred while connecting to API"}, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_http_403_exception_is_auth(self):
        class ApiException(Exception):
            status = 403
        self.assertEqual(a.classify({"Error": ApiException("Forbidden")}, state_changing=True).kind, a.AUTH)

    def test_backend_rejection_body(self):
        o = a.classify({"stCode": 1021, "errMsg": "Order is completed", "stat": "Not_Ok", "status_code": 400}, state_changing=True)
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "1021")

    def test_backend_403_body_is_auth(self):
        self.assertEqual(a.classify({"stCode": 403, "errMsg": "Invalid session, please re-login"}).kind, a.AUTH)

    def test_error_list_shape(self):
        o = a.classify({"error": [{"code": "10300", "message": "Validation Errors!"}]})
        self.assertEqual((o.kind, o.code), (a.REJECTED, "10300"))

    def test_2xx_without_order_number_is_unknown(self):
        o = a.classify({"stat": "Ok", "stCode": 200}, expect_order_id=True, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_result_is_json_safe(self):
        import json
        class ApiException(Exception):
            status = 0
        json.dumps(a.classify({"Error": ApiException("x")}, state_changing=True).as_dict())
        json.dumps(a.jsonable({"Error": ApiException("boom")}))

    def test_official_auth_error_shape_is_rejected_with_real_message(self):
        # Official Kotak auth-API rejection shape (totp_login/totp_validate),
        # distinct from the order/portfolio-API shape used elsewhere in this
        # file ({"stCode","errMsg","stat"}). Before this fix, classify() only
        # recognised the order/portfolio shape, so this fell through to the
        # "success, no data" branch and its real message was lost.
        o = a.classify({"status": "error", "message": "Invalid credentials or TOTP.", "errorCode": "401"})
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.message, "Invalid credentials or TOTP.")
        self.assertEqual(o.code, "401")

    def test_official_auth_error_shape_403_is_auth(self):
        o = a.classify({"status": "error", "message": "Session invalid, please re-login.", "errorCode": "403"})
        self.assertEqual(o.kind, a.AUTH)

    def test_official_auth_error_shape_429_is_rate_limited(self):
        o = a.classify({"status": "error", "message": "Too many requests, please try again later.", "errorCode": "429"})
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "429")

    def test_nested_sdk_error_424_empty_collection_is_normalized_for_all_read_collections(self):
        """NeoAPI REST methods normally return {Error: ApiException(...)} rather than raising."""
        class ApiException(Exception):
            def __init__(self, status, body):
                super().__init__("HTTP error")
                self.status = status
                self.body = body

        s, neo = logged_in()
        bodies = {
            "order_report": {"stCode": 424, "errMsg": "No orders found for this client V883E", "stat": "Not_Ok"},
            "trade_report": {"stCode": 424, "errMsg": "No trades found for this client V883E", "stat": "Not_Ok"},
            "positions": {"stCode": 424, "errMsg": "No positions found for this client V883E", "stat": "Not_Ok"},
            "holdings": {"stCode": 424, "errMsg": "No holdings found for this client V883E", "stat": "Not_Ok"},
        }
        for method, body in bodies.items():
            neo.responses[method] = {"Error": ApiException(424, body)}
            out = getattr(s, method)()
            self.assertTrue(out.ok, method)
            self.assertEqual(out.data, [], method)
            self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_EMPTY_424", method)
            self.assertEqual(out.extra["broker_diagnostics"]["kotak_st_code"], 424, method)

    def test_nested_sdk_error_reason_only_424_empty_holdings_is_normalized(self):
        # Defensive coverage for SDK/OpenAPI paths where ApiException carries
        # only status + reason and no parsed HTTP body. The matcher remains
        # endpoint-specific, so generic 424 errors still block LIVE.
        class ApiException(Exception):
            def __init__(self, status, reason):
                super().__init__(reason)
                self.status = status
                self.reason = reason
                self.body = None
        s, neo = logged_in()
        neo.responses["holdings"] = {
            "Error": ApiException(424, "No holdings found for this client V883E")
        }
        out = s.holdings()
        self.assertTrue(out.ok)
        self.assertEqual(out.data, [])
        self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_EMPTY_424")

    def test_nested_sdk_error_generic_424_remains_blocking(self):
        class ApiException(Exception):
            status = 424
            body = {"stCode": 424, "errMsg": "Portfolio service unavailable", "stat": "Not_Ok"}
        s, neo = logged_in()
        neo.responses["holdings"] = {"Error": ApiException("HTTP 424")}
        out = s.holdings()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "424")
        self.assertIn("Portfolio service unavailable", out.message)

    def test_nested_sdk_error_5203_no_data_is_normalized(self):
        class ApiException(Exception):
            status = 5203
            body = {"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"}
        s, neo = logged_in()
        neo.responses["holdings"] = {"Error": ApiException("No Data")}
        out = s.holdings()
        self.assertTrue(out.ok)
        self.assertEqual(out.data, [])

    def test_http_424_exception_body_empty_collection_is_normalized_for_all_read_collections(self):
        """Covers the real SDK raise_on_error=True path used by the production screenshot."""
        class ApiException(Exception):
            def __init__(self, status, body):
                super().__init__("HTTP error")
                self.status = status
                self.body = body

        s, neo = logged_in()
        bodies = {
            "order_report": {"stCode": 424, "errMsg": "No orders found for this client V883E", "stat": "Not_Ok"},
            "trade_report": {"stCode": 424, "errMsg": "No trades found for this client V883E", "stat": "Not_Ok"},
            "positions": {"stCode": 424, "errMsg": "No positions found for this client V883E", "stat": "Not_Ok"},
            "holdings": {"stCode": 424, "errMsg": "No holdings found for this client V883E", "stat": "Not_Ok"},
        }
        for method, body in bodies.items():
            neo.responses[method] = lambda **_kw: (_ for _ in ()).throw(ApiException(424, body))
            out = getattr(s, method)()
            self.assertTrue(out.ok, method)
            self.assertEqual(out.data, [], method)
            self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_EMPTY_424", method)
            self.assertEqual(out.extra["broker_diagnostics"]["http_status"], 424, method)
            self.assertEqual(out.extra["broker_diagnostics"]["session_auth_indication"], "SESSION_PRESENT_BROKER_REPLIED", method)

    def test_http_424_exception_body_generic_failure_remains_blocking(self):
        class ApiException(Exception):
            status = 424
            body = {"stCode": 424, "errMsg": "Portfolio service unavailable", "stat": "Not_Ok"}

        s, neo = logged_in()
        neo.responses["holdings"] = lambda **_kw: (_ for _ in ()).throw(ApiException("HTTP error"))
        out = s.holdings()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "424")
        self.assertEqual(out.extra["broker_diagnostics"]["session_auth_indication"], "SESSION_PRESENT_BROKER_REPLIED")

    def test_empty_holdings_424_without_http_status_is_normalized_to_empty_list(self):
        s, neo = logged_in()
        neo.responses["holdings"] = {
            "stCode": "424",
            "errMsg": " No holdings found for this client V883E ",
            "stat": "Not_Ok",
        }
        out = s.holdings()
        self.assertTrue(out.ok)
        self.assertEqual(out.data, [])
        self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_EMPTY_424")

    def test_empty_holdings_424_is_normalized_to_empty_list(self):
        s, neo = logged_in()
        neo.responses["holdings"] = {
            "status_code": 424,
            "stCode": 424,
            "errMsg": "No holdings found for this client V883E",
            "stat": "Not_Ok",
        }
        out = s.holdings()
        self.assertTrue(out.ok)
        self.assertEqual(out.data, [])

    def test_official_5203_no_data_is_normalized_for_all_empty_read_collections(self):
        s, neo = logged_in()
        responses = {
            "order_report": {"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"},
            "trade_report": {"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"},
            "positions": {"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"},
            "holdings": {"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"},
        }
        for method, response in responses.items():
            neo.responses[method] = response
            out = getattr(s, method)()
            self.assertTrue(out.ok, method)
            self.assertEqual(out.data, [], method)
            self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_NO_DATA")
            self.assertEqual(out.extra["broker_diagnostics"]["kotak_st_code"], 5203)
            self.assertEqual(out.extra["broker_diagnostics"]["kotak_err_msg"], "No Data")

    def test_classify_does_not_globally_treat_5203_as_success(self):
        out = a.classify({"stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"})
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "5203")

    def test_5203_with_wrong_shape_remains_rejected(self):
        s, neo = logged_in()
        neo.responses["positions"] = {"stCode": 5203, "errMsg": "Temporary service failure", "desc": "data not found", "stat": "Not_Ok"}
        out = s.positions()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "5203")

    def test_successful_collection_without_data_container_is_blocked(self):
        s, neo = logged_in()
        for method in ("order_report", "trade_report", "positions", "holdings"):
            neo.responses[method] = {"stat": "Ok", "stCode": 200}
            out = getattr(s, method)()
            self.assertFalse(out.ok, method)
            self.assertEqual(out.code, "MALFORMED_RESPONSE", method)
            self.assertEqual(out.extra["broker_diagnostics"]["response_classification"], "KOTAK_MALFORMED_READ_RESPONSE")

    def test_limits_without_documented_fields_are_blocked(self):
        s, neo = logged_in()
        neo.responses["limits"] = {"stat": "Ok", "stCode": 200, "data": []}
        out = s.limits()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "MALFORMED_RESPONSE")

    def test_5203_with_http_failure_does_not_get_normalized(self):
        s, neo = logged_in()
        neo.responses["positions"] = {"status_code": 500, "stCode": 5203, "errMsg": "No Data", "desc": "data not found", "stat": "Not_Ok"}
        out = s.positions()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "5203")

    def test_unrelated_holdings_424_remains_rejected(self):
        s, neo = logged_in()
        neo.responses["holdings"] = {
            "status_code": 424,
            "stCode": 424,
            "errMsg": "Portfolio service unavailable",
            "stat": "Not_Ok",
        }
        out = s.holdings()
        self.assertFalse(out.ok)
        self.assertEqual(out.code, "424")

    def test_empty_positions_424_is_normalized_to_empty_list(self):
        s, neo = logged_in()
        neo.responses["positions"] = {
            "status_code": 424,
            "stCode": 424,
            "errMsg": "No positions found for this client V883E",
            "stat": "Not_Ok",
        }
        out = s.positions()
        self.assertTrue(out.ok)
        self.assertEqual(out.data, [])

    def test_empty_order_and_trade_424_are_normalized_to_empty_lists(self):
        s, neo = logged_in()
        neo.responses["order_report"] = {"status_code": 424, "stCode": 424, "errMsg": "No orders found for this client V883E", "stat": "Not_Ok"}
        neo.responses["trade_report"] = {"status_code": 424, "stCode": 424, "errMsg": "No trades found for this client V883E", "stat": "Not_Ok"}
        self.assertTrue(s.order_report().ok)
        self.assertEqual(s.order_report().data, [])
        self.assertTrue(s.trade_report().ok)
        self.assertEqual(s.trade_report().data, [])

    def test_broker_diagnostics_capture_http_stcode_message_endpoint_and_body(self):
        s, neo = logged_in()
        neo.responses["holdings"] = {"status_code": 424, "stCode": 424, "errMsg": "Portfolio service unavailable", "stat": "Not_Ok"}
        out = s.holdings()
        self.assertFalse(out.ok)
        d = out.extra["broker_diagnostics"]
        self.assertEqual(d["http_status"], 424)
        self.assertEqual(d["kotak_st_code"], 424)
        self.assertEqual(d["kotak_err_msg"], "Portfolio service unavailable")
        self.assertEqual(d["endpoint"], "https://e21.kotaksecurities.com/portfolio/v1/holdings")
        self.assertEqual(d["session_auth_indication"], "SESSION_PRESENT_BROKER_REPLIED")
        self.assertEqual(d["response_body"]["status_code"], 424)
        self.assertEqual(out.as_dict()["diagnostics"]["endpoint"], d["endpoint"])

    def test_rows_of_handles_documented_shapes(self):
        self.assertEqual(a.rows_of(a.classify({"data": [{"a": 1}]})), [{"a": 1}])
        self.assertEqual(a.rows_of(a.classify({"data": {"stat": "Ok", "data": [{"b": 2}]}})), [{"b": 2}])
        self.assertEqual(a.rows_of(a.classify({"stat": "Ok", "stCode": 200})), [])


class OrderRequestTests(unittest.TestCase):
    def base(self, **kw):
        d = dict(exchange_segment="nse_cm", trading_symbol="YESBANK-EQ", transaction_type="B", order_type="L",
                 product="CNC", quantity=10, validity="DAY", price=20.5, tag="OTABC")
        d.update(kw)
        return a.OrderRequest(**d)

    def test_exact_kwargs_are_all_strings(self):
        kw = self.base().to_sdk_kwargs()
        self.assertEqual(kw["price"], "20.50")
        self.assertEqual(kw["quantity"], "10")
        self.assertEqual(kw["tag"], "OTABC")
        self.assertTrue(all(isinstance(v, str) for v in kw.values()))

    def test_market_order_sends_zero_price(self):
        self.assertEqual(self.base(order_type="MKT", price=None).to_sdk_kwargs()["price"], "0")

    def test_kwargs_accepted_by_real_signature(self):
        s, neo = logged_in()
        neo.responses["place_order"] = {"stat": "Ok", "nOrdNo": "1", "stCode": 200}
        self.assertTrue(s.place_order(self.base()).ok)   # FakeNeoAPI raises TypeError on any guessed kwarg

    def test_validation(self):
        bad = [dict(exchange_segment="NSE"), dict(exchange_segment="NSECM"), dict(product="DELIVERY"), dict(order_type="LIMIT"),
               dict(transaction_type="BUY"), dict(quantity=0), dict(quantity="10"), dict(price=None),
               dict(order_type="SL", trigger_price=None), dict(validity="GTC"), dict(exchange_segment="mcx_fo", validity="IOC"),
               dict(trading_symbol=" "), dict(tag="  "), dict(amo="MAYBE")]
        for kw in bad:
            with self.assertRaises(a.OrderRequestError, msg=str(kw)):
                self.base(**kw).to_sdk_kwargs()

    def test_fmt_price(self):
        self.assertEqual(a.fmt_price(0.1 + 0.2), "0.30")
        self.assertEqual(a.fmt_price(100), "100.00")
        self.assertEqual(a.fmt_price("9.4"), "9.40")
        self.assertEqual(a.fmt_price(1e-05).count("e"), 0)
        with self.assertRaises(a.OrderRequestError):
            a.fmt_price(-1)

    def test_not_sent_when_invalid(self):
        s, neo = logged_in()
        with self.assertRaises(a.OrderRequestError):
            s.place_order(self.base(quantity=0))
        self.assertFalse([c for c in neo.calls if c[0] == "place_order"])


class LoginTests(unittest.TestCase):
    def test_success_requires_trade_session(self):
        s, neo = sdk()
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertTrue(o.ok)
        self.assertTrue(s.has_trade_session())
        self.assertEqual(o.data["data_center"], "e21")

    def test_bad_mpin_is_rejected(self):
        s, neo = sdk()
        neo.login_ok = False
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="0000")
        self.assertFalse(o.ok)
        self.assertFalse(s.has_trade_session())

    def test_validate_reporting_view_ktype_is_rejected(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "View", "status": "success"}}
        self.assertFalse(s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1").ok)

    def test_success_body_without_session_is_rejected(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "Trade", "status": "success"}}  # config never populated
        self.assertFalse(s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1").ok)

    def test_session_summary_has_no_tokens(self):
        s, _ = logged_in()
        self.assertNotIn("TOK", str(s.session_summary()))
        self.assertNotIn("SID", str(s.session_summary()))

    def test_totp_login_rejection_preserves_broker_message_and_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_login"] = {"status": "error", "message": "Invalid credentials or TOTP.", "errorCode": "401"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="000000", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "TOTP_LOGIN_FAILED")
        self.assertIn("Invalid credentials or TOTP.", o.message)
        self.assertNotIn("no data in response", o.message)
        self.assertFalse(s.has_trade_session())

    def test_mpin_validation_rejection_has_its_own_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"status": "error", "message": "Invalid MPIN.", "errorCode": "401"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="0000")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "MPIN_VALIDATION_FAILED")
        self.assertIn("Invalid MPIN.", o.message)
        self.assertFalse(s.has_trade_session())
        # totp_login itself must have been called and accepted -- this is
        # specifically the "totp_login OK, totp_validate rejected" case.
        self.assertTrue(any(n == "totp_login" for n, _ in neo.calls))

    def test_transport_error_during_totp_login_is_its_own_stage_code(self):
        class ApiException(Exception):
            status = 0
        s, neo = sdk()
        neo.responses["totp_login"] = {"Error": ApiException("Connection timed out")}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.kind, a.UNKNOWN)  # ambiguous -- may or may not have reached the broker
        self.assertEqual(o.code, "TRANSPORT_ERROR")

    def test_rate_limited_during_totp_login_is_its_own_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_login"] = {"status": "error", "message": "Too many requests.", "errorCode": "429"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "RATE_LIMITED")

    def test_session_verification_failure_has_its_own_stage_code(self):
        # totp_validate succeeds and reports a Trade session, but the SDK
        # config never actually populated tokens -- has_trade_session() is
        # False, which is the "session established but unusable" case.
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "Trade", "status": "success"}}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "SESSION_VERIFICATION_FAILED")


class MethodCoverageTests(unittest.TestCase):
    def test_every_adapter_call_matches_official_signature(self):
        s, neo = logged_in()
        s.modify_order(order_id="1", order_type="L", quantity=5, validity="DAY", price=10, trigger_price=None)
        s.cancel_order(order_id="1")
        s.order_report(); s.order_report("1"); s.order_history("1"); s.trade_report()
        s.positions(); s.holdings(); s.limits(); s.whatsmyip()
        s.margin_required(exchange_segment="nse_cm", price=10, order_type="L", product="CNC", quantity=1,
                          instrument_token="11536", transaction_type="B")
        s.quotes([("nse_cm", "11536")], "ltp")
        s.scrip_master("nse_cm")
        s.search_scrip(exchange_segment="nse_cm", symbol="yes")
        called = {c[0] for c in neo.calls}
        self.assertTrue({"modify_order", "cancel_order", "order_report", "order_history", "trade_report", "positions",
                         "holdings", "limits", "whatsmyip", "margin_required", "quotes", "scrip_master", "search_scrip"} <= called)

    def test_modify_sends_new_quantity_price_as_strings(self):
        s, neo = logged_in()
        s.modify_order(order_id="9", order_type="L", quantity=5, validity="DAY", price=10.5)
        kw = dict(neo.calls)["modify_order"]
        self.assertEqual((kw["quantity"], kw["price"], kw["order_id"]), ("5", "10.50", "9"))

    def test_quotes_payload_shape(self):
        s, neo = logged_in()
        s.quotes([("nse_cm", "11536")])
        self.assertEqual(dict(neo.calls)["quotes"]["instrument_tokens"], [{"instrument_token": "11536", "exchange_segment": "nse_cm"}])

    def test_empty_ids_rejected_before_sdk(self):
        s, neo = logged_in()
        for fn in (lambda: s.cancel_order(order_id=""), lambda: s.modify_order(order_id="", order_type="L", quantity=1, validity="DAY", price=1)):
            with self.assertRaises(a.OrderRequestError):
                fn()


class DerivativesAndMiscTests(unittest.TestCase):
    def test_expiries_validates_segment_and_sends_exact_kwargs(self):
        s, neo = logged_in()
        neo.responses["expiries"] = {"exchange": "nse_fo", "underlying": "NIFTY", "expiries": ["2026-06-25"]}
        o = s.expiries(exchange="nse_fo", underlying="NIFTY", instrument_type="option")
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["expiries"], {"exchange": "nse_fo", "underlying": "NIFTY", "instrument_type": "option"})
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_cm", underlying="NIFTY")
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_fo", underlying="")
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_fo", underlying="NIFTY", instrument_type="swap")

    def test_option_chain_validates_and_sends_exact_kwargs(self):
        s, neo = logged_in()
        neo.responses["option_chain"] = {"data": {"common_data": {}, "call": [], "put": []}}
        o = s.option_chain(exchange="nse_fo", underlying="NIFTY", expiry="2026-06-25", instrument_type="option", count=20)
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["option_chain"],
                         {"exchange": "nse_fo", "underlying": "NIFTY", "expiry": "2026-06-25", "instrument_type": "option", "count": 20})
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="mcx_fo", underlying="", count=1)
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="nse_fo", underlying="NIFTY", count=0)
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="nse_fo", underlying="NIFTY", count="20")

    def test_historical_data_validates_neosymbol_interval_and_unsupported_segment(self):
        s, neo = logged_in()
        neo.responses["historical_data"] = {"status": "success", "interval": "D", "data": {"candles": [["t", 1, 2, 0.5, 1.5, 100, 0]]}}
        o = s.historical_data(neosymbol="nse_cm|1333", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["historical_data"],
                         {"neosymbol": "nse_cm|1333", "interval": "D", "from_date": "2026-08-01", "to_date": "2026-09-01"})
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm1333", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="mcx_fo|1", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm|1333", interval="2min", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm|1333", interval="D", from_date="", to_date="2026-09-01")

    def test_scrip_master_with_and_without_segment(self):
        s, neo = logged_in()
        neo.responses["scrip_master"] = "https://lapi.kotaksecurities.com/wso2-scripmaster/v1/prod/2026-07-14/transformed-v1/nse_cm-v1.csv"
        o = s.scrip_master(exchange_segment="nse_cm")
        self.assertTrue(o.ok)
        self.assertTrue(o.data.startswith("https://"))
        neo.responses["scrip_master"] = {"baseFolder": "https://x", "filesPaths": ["https://x/a.csv"]}
        o2 = s.scrip_master()
        self.assertTrue(o2.ok)
        self.assertIn("filesPaths", o2.data)

    def test_whatsmyip(self):
        s, neo = logged_in()
        neo.responses["whatsmyip"] = {"ip": "1.2.3.4"}
        o = s.whatsmyip()
        self.assertTrue(o.ok)
        self.assertEqual(o.data["ip"], "1.2.3.4")


if __name__ == "__main__":
    unittest.main()
