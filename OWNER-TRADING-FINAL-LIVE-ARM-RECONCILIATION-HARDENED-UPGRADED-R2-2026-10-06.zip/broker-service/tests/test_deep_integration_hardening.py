import asyncio
import dataclasses
import unittest
from unittest.mock import AsyncMock, patch

from app import broker_client as bc
from app import db as dbmod
from app import server
from app import websocket_manager as wsm
from app import order_service as osvc
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db


class ArmAndReconciliationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.old_cfg = server.config
        current_state.transition(BrokerState.RECONCILING)

    async def asyncTearDown(self):
        current_state.transition(BrokerState.DISCONNECTED)
        server.config = self.old_cfg

    async def test_global_arm_waits_when_reconciliation_is_already_running(self):
        ready_false = {"ready": False, "armed": False, "gates": [{"id": "recent_reconciliation", "ok": False, "blocking": True}]}
        ready_true = {"ready": True, "armed": False, "gates": []}
        with patch.object(server, 'config', dataclasses.replace(server.config, trading_mode='LIVE')), \
             patch('app.live_readiness.evaluate', side_effect=[ready_false, ready_true, ready_true]) as ev, \
             patch('app.reconciliation.run_full_reconciliation', new=AsyncMock(return_value={"ok": True})) as recon:
            status, body = await server.h_arm({}, {"confirm": "ARM LIVE TRADING"})
        self.assertEqual(status, 200, body)
        self.assertTrue(body["armed"])
        recon.assert_awaited_once()
        self.assertEqual(ev.call_count, 3)
        self.assertTrue(self.db.is_live_armed())


class ExitLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def _seed_position(self):
        strategy=self.db.create_strategy('exit-test')
        definition={
            'timeframe':'5m','side':'BUY',
            'entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':1}]},
            'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':1}]},
            'universe':{'instrument_tokens':['11915']},
            'risk':{'stop_loss':19.0,'target':21.0},
            'position_sizing':{'quantity':10},
            'execution':{'product':'MIS'},
        }
        version=self.db.save_strategy_version(strategy['id'],definition,'VALIDATED',[])
        signal=self.db.record_signal(strategy_version_id=version['id'],scanner_id=None,exchange_segment='nse_cm',instrument_token='11915',trading_symbol='YESBANK-EQ',timeframe='5m',side='BUY',signal_price=20.0,conditions={'indicators':{}},risk={},status='ORDERED',candle_at='2026-10-06 09:15:00')
        self.db.create_order(
            internal_order_id='entry-1', mode='LIVE', status='COMPLETE', client_tag='ENTRYTAG',
            trading_symbol='YESBANK-EQ', exchange_segment='nse_cm', transaction_type='B',
            order_type='MKT', product='MIS', validity='DAY', quantity=10, price=None,
            trigger_price=None, instrument_token='11915', signal_id=signal, algo_position_id=None,
            order_role='ENTRY', parent_order_id=None, broker_order_id='EB1',
        )
        pid=self.db.ensure_algo_position(
            exchange_segment='nse_cm', instrument_token='11915', trading_symbol='YESBANK-EQ',
            strategy_version_id=version['id'], entry_order_id='entry-1', quantity=10, average_entry=20.0,
            stop_loss=19.0, target=21.0,
        )
        return pid

    def test_failed_exit_request_becomes_retryable(self):
        pid = self._seed_position()
        eid = self.db.record_exit_request(pid, 'STOP_LOSS', 10, 19.0)
        self.assertFalse(self.db.has_pending_exit(pid))
        self.db.mark_exit_failed(eid, 'rejected')
        self.assertFalse(self.db.has_pending_exit(pid))
        with self.db._connection() as conn:
            row = conn.execute('SELECT status FROM algo_exits WHERE id=?',(eid,)).fetchone()
        self.assertEqual(row[0], 'FAILED')

    def test_orphan_requested_exit_is_released_after_restart(self):
        pid = self._seed_position()
        self.db.record_exit_request(pid, 'STOP_LOSS', 10, 19.0)
        self.assertEqual(self.db.mark_orphan_exit_requests_retryable(), 1)
        self.assertFalse(self.db.has_pending_exit(pid))

    def test_rejected_broker_order_releases_exit(self):
        pid = self._seed_position()
        eid = self.db.record_exit_request(pid, 'STOP_LOSS', 10, 19.0)
        self.db.create_order(
            internal_order_id='exit-1', mode='LIVE', status='SUBMITTED', client_tag='TAG',
            trading_symbol='YESBANK-EQ', exchange_segment='nse_cm', transaction_type='S',
            order_type='MKT', product='MIS', validity='DAY', quantity=10, price=None,
            trigger_price=None, instrument_token='11915', signal_id=None, algo_position_id=pid,
            order_role='EXIT', parent_order_id='entry-1',
        )
        self.db.mark_exit_order(pid, 'exit-1', eid)
        self.db.apply_broker_order_state(
            internal_order_id='exit-1', status='REJECTED', broker_status='rejected',
            filled_quantity=0, average_price=None, broker_order_id='B1', status_reason='RMS reject'
        )
        self.assertFalse(self.db.has_pending_exit(pid))


class MarketFeedLivenessTests(unittest.TestCase):
    def setUp(self):
        self.m = wsm.WebSocketManager()
        self.m._market = type('Feed', (), {'is_connected': True})()
        self.m._subs[('nse_cm','11915')] = None

    def test_only_market_status_does_not_count_as_fresh_tick(self):
        self.m._last_market_msg = asyncio.get_event_loop().time() if False else None
        status = type('M', (), {'type':'market_status','exchange_segment':'nse_cm','status_code':1,'status':'Market open'})()
        self.m._on_market_message(status)
        self.assertTrue(self.m.is_stale())
        tick = type('T', (), {'type':'scrip','exchange_segment':'nse_cm','instrument_token':'11915','last_traded_price':20.5,'trading_symbol':'YESBANK-EQ','close_price':20.0,'volume_traded_today':100})()
        with patch.object(wsm._db, 'record_market_tick'):
            self.m._on_market_message(tick)
        self.assertFalse(self.m.is_stale())


class PendingPositionRiskTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def test_partially_filled_pending_entry_reserves_strategy_position(self):
        strategy=self.db.create_strategy('pending-test')
        version=self.db.save_strategy_version(strategy['id'], {'timeframe':'5m','side':'BUY','entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':1}]},'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':1}]},'universe':{'instrument_tokens':['11915']},'risk':{'stop_loss':19,'target':21},'position_sizing':{'quantity':25},'execution':{'product':'MIS'}}, 'VALIDATED', [])
        signal=self.db.record_signal(strategy_version_id=version['id'],scanner_id=None,exchange_segment='nse_cm',instrument_token='11915',trading_symbol='YESBANK-EQ',timeframe='5m',side='BUY',signal_price=20,conditions={},risk={},status='DETECTED',candle_at='2026-10-06 09:15:00')
        self.db.create_order(
            internal_order_id='entry-1', mode='LIVE', status='PARTIALLY_FILLED', client_tag='TAG',
            trading_symbol='YESBANK-EQ', exchange_segment='nse_cm', transaction_type='B',
            order_type='MKT', product='MIS', validity='DAY', quantity=25, price=None,
            trigger_price=None, instrument_token='11915', signal_id=signal, algo_position_id=None,
            order_role='ENTRY', parent_order_id=None,
        )
        self.db.apply_broker_order_state(internal_order_id='entry-1', status='PARTIALLY_FILLED', broker_status='open', filled_quantity=5, average_price=20.0)
        with patch('app.order_service.fresh_ltp', return_value=20.0):
            total, by_strategy, by_instrument, counts, complete = osvc._pending_entry_risk()
            self.assertEqual(counts.get(version['id']), 1)
            self.assertTrue(complete)


if __name__ == '__main__':
    unittest.main()
