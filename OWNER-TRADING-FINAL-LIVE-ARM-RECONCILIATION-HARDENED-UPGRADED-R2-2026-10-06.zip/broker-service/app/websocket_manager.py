"""Market (SFeed) and order-feed supervision on the official async SDK clients.

Uses ONLY the SDK's modern clients (`NeoAPI.create_websocket()` -> SFeedWebSocket,
`NeoAPI.create_order_feed()` -> OrderFeedWebSocket) with their documented
callbacks (on_message / on_connect / on_disconnect / on_error) and
`subscribe_scrips(list[WsToken])`. The legacy v2 callback-attribute /
`subscribe(instrument_tokens=...)` handling has been removed.

Division of labour (from the SDK source):
  * The SDK client reconnects on its own (reconnect_delay x max_reconnect_attempts)
    and re-sends its own subscriptions.
  * THIS supervisor covers what the SDK does not: (a) a client that gave up
    (is_connected stays False past the SDK's own retry window) -> build a new
    client from the current session, back off, resubscribe from our registry;
    (b) after ANY (re)connect of the order feed -> REST reconciliation, because
    order events sent while disconnected are not replayed;
    (c) repeated failures -> probe the session with a read-only limits() call so
    an expired session moves the service to SESSION_EXPIRED instead of looping.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any

from . import db as _db
from . import order_sync, sdk_adapter
from .broker_client import NotConfiguredError, broker_client
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket")

# SDK retries internally for about reconnect_delay * max_reconnect_attempts (5s * 5).
SDK_RECONNECT_WINDOW_SECONDS = 30
LOST_GRACE_SECONDS = SDK_RECONNECT_WINDOW_SECONDS + 10
BACKOFF_START, BACKOFF_MAX = 2.0, 60.0
PROBE_AFTER_FAILURES = 3
TICK_WRITE_INTERVAL_SECONDS = 1.0
STALE_AFTER_SECONDS = 90   # informational only: silence is normal outside market hours
_TICK_TYPES = ("scrip", "scrip_lite", "index")


class WebSocketManager:
    def __init__(self) -> None:
        # Actual SFeed subscriptions are the union of logical owners. A token
        # can simultaneously belong to the scanner universe, multiple strategy
        # candidates, and a manually selected market-data subscription. We only
        # send the broker unsubscribe frame when the final owner releases it.
        self._subs: dict[tuple[str, str], None] = {}
        self._owners: dict[tuple[str, str], set[str]] = {}
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()
        self._market: Any = None
        self._order: Any = None
        self._last_market_msg: float | None = None
        self._last_market_tick: float | None = None
        self._last_order_msg: float | None = None
        self._last_tick_write: dict[tuple[str, str], float] = {}
        self._reconnects = {"market": 0, "order": 0}
        self._reconcile_task: asyncio.Task | None = None
        self._market_status: dict[str, dict] = {}
        self._max_subscriptions = 3000

    # ------------------------------------------------------------ lifecycle
    @property
    def running(self) -> bool:
        return any(not t.done() for t in self._tasks)

    async def start(self) -> None:
        if self.running:
            return
        self._stop = asyncio.Event()
        self._tasks = [
            asyncio.create_task(self._supervise("market", self._run_market)),
            asyncio.create_task(self._supervise("order", self._run_order)),
        ]

    async def ensure_started_and_wait(self, timeout: float = 15.0) -> dict:
        """Start both LIVE feeds and wait briefly for their initial connection.

        The supervisor is intentionally asynchronous for long-term recovery, but
        the initial connect path must not report a healthy broker while the order
        feed is still booting. Waiting here removes that startup race without
        weakening the normal reconnect supervisor. A timeout is reported as a
        diagnostic result; the supervisor continues retrying in the background.
        """
        await self.start()
        # A test/dry harness may deliberately stub start() and provide no
        # supervisor tasks. In that case there is nothing real to wait for;
        # production start() always creates both supervisor tasks.
        if not self._tasks:
            status = self.status()
            return {
                "ready": bool(status["market"]["connected"] and status["orderFeed"]["connected"]),
                "market": bool(status["market"]["connected"]),
                "order": bool(status["orderFeed"]["connected"]),
            }
        deadline = asyncio.get_running_loop().time() + max(0.0, float(timeout))
        while asyncio.get_running_loop().time() < deadline:
            m = self._market
            o = self._order
            if m is not None and o is not None and m.is_connected and o.is_connected:
                return {"ready": True, "market": True, "order": True}
            await asyncio.sleep(0.25)
        status = self.status()
        return {
            "ready": bool(status["market"]["connected"] and status["orderFeed"]["connected"]),
            "market": bool(status["market"]["connected"]),
            "order": bool(status["orderFeed"]["connected"]),
        }

    async def stop(self) -> None:
        self._stop.set()
        try:
            from .candle_engine import candle_engine
            candle_engine.flush()
        except Exception as exc:
            logger.warning("Failed to flush forming candles during websocket stop: %s", exc)
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        self._tasks = []
        for feed in (self._market, self._order):
            await self._safe_close(feed)
        self._market = self._order = None

    @staticmethod
    async def _safe_close(feed) -> None:
        if feed is None:
            return
        try:
            await feed.close()
        except Exception:  # noqa: BLE001
            pass

    # -------------------------------------------------------- subscriptions
    async def subscribe(self, exchange_segment: str, instrument_token: str, owner: str = "manual") -> None:
        await self.subscribe_many([(exchange_segment, str(instrument_token))], owner=owner)

    async def unsubscribe(self, exchange_segment: str, instrument_token: str, owner: str = "manual") -> None:
        await self.unsubscribe_many([(exchange_segment, str(instrument_token))], owner=owner)

    async def subscribe_many(self, keys: list[tuple[str, str]], owner: str = "manual") -> dict:
        """Add a logical subscription owner and ensure its SFeed membership.

        `owner` is deliberately separate from the broker's actual subscription:
        shared instruments therefore cannot be accidentally unsubscribed when
        one strategy disarms or one candidate expires.
        """
        owner = str(owner or "manual")
        normalized=[]
        for exchange_segment, instrument_token in keys:
            if exchange_segment not in sdk_adapter.EXCHANGE_SEGMENTS:
                raise ValueError(f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}.")
            normalized.append((exchange_segment,str(instrument_token)))
        normalized=list(dict.fromkeys(normalized))
        new_keys=[k for k in normalized if k not in self._subs]
        if len(self._subs)+len(new_keys)>self._max_subscriptions:
            raise ValueError(f"SFeed subscription limit reached ({self._max_subscriptions}).")
        feed=self._market
        added=[]
        try:
            if feed is not None and feed.is_connected and new_keys:
                for i in range(0,len(new_keys),500):
                    batch=new_keys[i:i+500]
                    await feed.subscribe_scrips([sdk_adapter.make_ws_token(*k) for k in batch])
                    for key in batch:
                        self._subs[key]=None
                        self._owners.setdefault(key,set()).add(owner)
                        added.append(key)
            else:
                for key in new_keys:
                    self._subs[key]=None
                    self._owners.setdefault(key,set()).add(owner)
                    added.append(key)
            # Existing broker subscriptions still need the new logical owner.
            for key in normalized:
                self._owners.setdefault(key,set()).add(owner)
        except Exception:
            logger.exception("SFeed batched subscription failed after %d token(s).", len(added))
            raise
        return {"requested":len(normalized),"added":len(added),"total":len(self._subs),"owner":owner}

    async def unsubscribe_many(self, keys: list[tuple[str, str]], owner: str = "manual") -> dict:
        owner = str(owner or "manual")
        normalized=list(dict.fromkeys((s,str(t)) for s,t in keys))
        feed=self._market
        removed=0; released=0
        for key in normalized:
            owners=self._owners.get(key,set())
            if owner in owners:
                owners.discard(owner); released += 1
            if owners:
                continue
            if key not in self._subs:
                self._owners.pop(key,None)
                continue
            if feed is not None and feed.is_connected:
                await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*key)])
            self._subs.pop(key,None); self._owners.pop(key,None); removed += 1
        return {"requested":len(normalized),"released":released,"removed":removed,"total":len(self._subs),"owner":owner}

    async def release_owner(self, owner: str) -> int:
        """Release every logical subscription owned by one runtime component."""
        owner=str(owner)
        keys=[key for key,owners in self._owners.items() if owner in owners]
        if not keys:return 0
        result=await self.unsubscribe_many(keys, owner=owner)
        return int(result.get("removed") or 0)

    async def ensure_owner_subscriptions(self, keys: list[tuple[str,str]], owner: str) -> dict:
        return await self.subscribe_many(keys, owner=owner)

    async def restore_armed_strategy_subscriptions(self) -> dict:
        """Rebuild persisted strategy/candidate owners after a process restart.

        Scanner-linked strategies restore only their still-active candidates;
        scanner-less strategies restore their explicit universe. This preserves
        the candidate architecture instead of subscribing an entire strategy
        universe merely because it is LIVE armed.
        """
        from . import db as _db
        # Remove stale strategy owners while preserving manual/scanner-universe
        # owners.
        for owner in list({o for owners in self._owners.values() for o in owners if o.startswith("strategy:")}):
            await self.release_owner(owner)
        restored=0
        for item in _db.list_live_armed_strategy_versions():
            vid=int(item["id"]); definition=item.get("definition") or {}
            scanner_ids=definition.get("scanner_ids") or []
            try:
                if scanner_ids:
                    for c in _db.list_strategy_candidates(strategy_version_id=vid, active_only=True):
                        owner=f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}"
                        try:
                            await self.subscribe(c["exchange_segment"],c["instrument_token"],owner=owner)
                            _db.mark_strategy_candidate_subscribed(c["id"],True)
                            restored += 1
                        except Exception as exc:
                            _db.mark_strategy_candidate_subscribed(c["id"],False,error=f"{type(exc).__name__}: {exc}")
                            logger.warning("Failed to restore candidate subscription strategy=%s token=%s: %s", vid, c.get("instrument_token"), exc)
                else:
                    universe=definition.get("universe") or {}
                    keys=[("nse_cm",str(t).strip()) for t in (universe.get("instrument_tokens") or []) if str(t).strip()] if isinstance(universe,dict) else []
                    if keys:
                        try:
                            await self.subscribe_many(keys,owner=f"strategy:{vid}:universe")
                            restored += len(keys)
                        except Exception as exc:
                            logger.warning("Failed to restore scanner-less strategy=%s subscriptions: %s", vid, exc)
            except Exception as exc:
                logger.warning("Strategy subscription recovery failed for version=%s: %s", vid, exc)
        logger.info("Restored %d persisted LIVE strategy subscription owner(s).", restored)
        return {"restored": restored}

    async def remove_if_unneeded(self, keys: list[tuple[str, str]] | None = None) -> int:
        """Remove stale strategy owners; never let one strategy block another.

        The actual broker subscription is retained whenever any owner still
        needs the token (scanner universe, another strategy, or manual UI).
        """
        from . import db as _db
        desired_candidates={(s,t,vid) for s,t,vid in _db.list_active_candidate_subscription_keys()}
        desired_strategy_owners=set()
        for s,t,vid in desired_candidates:
            desired_strategy_owners.add(f"strategy:{vid}:candidate:{s}:{t}")
        for item in _db.list_live_armed_strategy_versions():
            vid=int(item["id"]); definition=item.get("definition") or {}
            if definition.get("scanner_ids"):continue
            desired_strategy_owners.add(f"strategy:{vid}:universe")
        owners={o for owners in self._owners.values() for o in owners if o.startswith("strategy:")}
        removed=0
        for owner in owners-desired_strategy_owners:
            removed += await self.release_owner(owner)
        if keys is not None:
            # Caller-provided keys are retained if any non-strategy owner still
            # holds them; otherwise the strategy-owner cleanup above is enough.
            pass
        return removed

    def subscription_owners(self, key: tuple[str,str] | None = None):
        if key is not None:
            return sorted(self._owners.get(key,set()))
        return {f"{s}:{t}": sorted(owners) for (s,t),owners in self._owners.items()}

    def subscriptions(self) -> list[dict]:
        # Resolve display metadata in one bounded DB lookup so a large (up to 3000)
        # subscription set does not cause one SQLite query per row.
        metadata = _db.get_instruments_for_keys(list(self._subs))
        out = []
        for s, t in self._subs:
            item = {"exchange_segment": s, "instrument_token": t}
            instrument = metadata.get((s, t))
            if instrument:
                item["trading_symbol"] = instrument.get("trading_symbol")
                item["name"] = instrument.get("name")
            out.append(item)
        return out

    # ------------------------------------------------------------- status
    def is_stale(self) -> bool:
        """True when a market subscription exists, the feed claims to be
        connected, and nothing arrived for STALE_AFTER_SECONDS. Informational
        (no ticks is normal when the market is closed); never forces a reconnect."""
        if not self._subs or self._market is None or not self._market.is_connected:
            return False
        # Feed health is based on actual price/index ticks, not market-status
        # control frames. A connected socket that only emits an OPEN/CLOSE
        # notification must not make a dead price stream look fresh.
        if self._last_market_tick is None:
            return True
        return (time.time() - self._last_market_tick) > STALE_AFTER_SECONDS

    def status(self) -> dict:
        m, o = self._market, self._order
        return {
            "running": self.running,
            "market": {"connected": bool(m and m.is_connected), "subscriptions": len(self._subs),
                       "lastMessageAt": self._last_market_msg, "lastTickAt": self._last_market_tick, "reconnects": self._reconnects["market"], "stale": self.is_stale(),
                       "maxSubscriptions": self._max_subscriptions, "marketStatus": self._market_status,
                       "ownedSubscriptions": sum(len(v) for v in self._owners.values())},
            "orderFeed": {"connected": bool(o and o.is_connected), "lastMessageAt": self._last_order_msg,
                          "reconnects": self._reconnects["order"]},
        }

    # ----------------------------------------------------------- supervisor
    async def _supervise(self, name: str, runner) -> None:
        backoff, failures = BACKOFF_START, 0
        while not self._stop.is_set():
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                await self._sleep(2.0)   # no valid session: nothing to (re)connect to
                continue
            started = time.time()
            try:
                await runner()
                failures = 0
            except asyncio.CancelledError:
                raise
            except NotConfiguredError:
                await self._sleep(2.0)
                continue
            except Exception as exc:  # noqa: BLE001
                failures += 1
                logger.warning("%s feed failed (%s: %s); failure %d.", name, type(exc).__name__, exc, failures)
            self._reconnects[name] += 1
            if time.time() - started > 60:      # a long healthy run resets backoff
                backoff, failures = BACKOFF_START, 0
            if failures >= PROBE_AFTER_FAILURES:
                await self._probe_session()
                failures = 0
            await self._sleep(backoff * (1 + random.uniform(0, 0.25)))
            backoff = min(backoff * 2, BACKOFF_MAX)

    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _probe_session(self) -> None:
        """Read-only limits(); an AUTH outcome flips state to SESSION_EXPIRED inside broker_client."""
        try:
            await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("limits"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session probe failed: %s", exc)

    async def _hold_until_lost(self, feed) -> None:
        """Returns once `feed` has been disconnected longer than the SDK's own retry window."""
        down_since: float | None = None
        while not self._stop.is_set():
            await asyncio.sleep(1.0)
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                return
            if feed.is_connected:
                down_since = None
            else:
                down_since = down_since or time.time()
                if time.time() - down_since > LOST_GRACE_SECONDS:
                    return

    # ------------------------------------------------------------- market
    async def _run_market(self) -> None:
        feed = broker_client.create_market_feed()
        self._market = feed
        feed.on_message = self._on_market_message
        feed.on_error = lambda e: logger.warning("SFeed error: %s", e)
        feed.on_disconnect = lambda: setattr(self, "_last_market_tick", None)
        feed.on_connect = lambda: self._on_market_connect(feed)
        try:
            await feed.connect()
            try:
                await feed.subscribe_exchange()
            except Exception as exc:
                logger.warning("Market-status subscription unavailable: %s", exc)
            await self._resubscribe(feed)
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    async def _resubscribe(self, feed) -> None:
        tokens = [sdk_adapter.make_ws_token(s, t) for s, t in self._subs]
        for i in range(0, len(tokens), 500):
            await feed.subscribe_scrips(tokens[i:i + 500])

    def _on_market_connect(self, feed) -> None:
        # A new/renewed socket has no proof of fresh price data yet. Reset the
        # tick clock so readiness cannot inherit a pre-reconnect tick and call
        # a silent feed healthy. The first real SFeed tick establishes freshness.
        self._last_market_tick = None
        # SDK-internal reconnects re-send its own subscriptions; if the counts
        # disagree (e.g. a new client), our registry is authoritative.
        if feed.subscription_count < len(self._subs):
            asyncio.get_running_loop().create_task(self._resubscribe(feed))

    def _on_market_message(self, message) -> None:
        self._last_market_msg = time.time()
        mtype = getattr(message, "type", None)
        if mtype == "market_status":
            seg = getattr(message, "exchange_segment", None)
            if seg:
                self._market_status[str(seg)] = {"status_code": getattr(message, "status_code", None), "status": getattr(message, "status", None), "updatedAt": time.time()}
            return
        if mtype not in _TICK_TYPES:
            return
        self._last_market_tick = time.time()
        seg, tok = getattr(message, "exchange_segment", None), getattr(message, "instrument_token", None)
        ltp = getattr(message, "last_traded_price", None)
        if not tok or ltp is None:
            return
        now = time.time()
        key = (seg or "", str(tok))
        # Protective exits are deliberately NOT throttled with the 1-second
        # persistence writer. They consume every valid market tick.
        try:
            from .exit_engine import on_tick as exit_tick
            asyncio.get_running_loop().create_task(
                exit_tick(exchange_segment=seg, instrument_token=str(tok), price=float(ltp))
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Protective exit tick dispatch failed: %s", exc)
        # Candle construction must consume EVERY valid tick. SQLite persistence
        # remains throttled independently so database load does not distort OHLC.
        try:
            from .candle_engine import candle_engine
            import datetime as dt
            from zoneinfo import ZoneInfo
            raw_ts = getattr(message, "last_trade_time", None) or getattr(message, "last_update_time", None)
            tick_ts = None
            if raw_ts:
                epoch = float(raw_ts) / (1000.0 if float(raw_ts) > 1_000_000_000_000 else 1.0)
                tick_ts = dt.datetime.fromtimestamp(epoch, tz=dt.timezone.utc)
            candle_engine.on_tick(exchange_segment=seg, instrument_token=str(tok),
                                  trading_symbol=getattr(message, "trading_symbol", None), price=float(ltp),
                                  volume=getattr(message, "volume_traded_today", None), timestamp=tick_ts)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Candle/algo processing failed: %s", exc)

        if now - self._last_tick_write.get(key, 0) < TICK_WRITE_INTERVAL_SECONDS:
            return
        self._last_tick_write[key] = now
        try:
            _db.record_market_tick(
                instrument_token=str(tok), exchange_segment=seg, last_traded_price=float(ltp),
                trading_symbol=getattr(message, "trading_symbol", None),
                close_price=getattr(message, "close_price", None),
                volume=getattr(message, "volume_traded_today", None),
            )
        except Exception as exc:  # noqa: BLE001 -- a DB hiccup must not kill the receive loop
            logger.warning("Failed to persist tick: %s", exc)

    # -------------------------------------------------------- order feed
    async def _run_order(self) -> None:
        feed = broker_client.create_order_feed()
        self._order = feed
        feed.on_message = self._on_order_message
        feed.on_error = lambda e: logger.warning("Order feed error: %s", e)
        feed.on_connect = lambda: self._schedule_reconcile("order feed connected")
        try:
            await feed.connect()
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    def _on_order_message(self, message) -> None:
        self._last_order_msg = time.time()
        mtype = getattr(message, "type", None)
        try:
            if mtype == "order":
                if getattr(message, "data", None) is None:
                    logger.warning("Ignoring order-feed message with no data payload")
                    return
                row = message.data.model_dump(by_alias=True)
                res = order_sync.apply_order_row(row, source="order_feed")
                if res["matched"] and res["changed"]:
                    self._schedule_reconcile("order update")   # picks up fills/positions via REST (authoritative)
            elif mtype == "position":
                self._schedule_reconcile("position update")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to process order-feed message: %s", exc)

    def _schedule_reconcile(self, reason: str) -> None:
        """Debounced: at most one pending reconciliation task."""
        if self._reconcile_task and not self._reconcile_task.done():
            return
        from . import reconciliation

        async def _go():
            await asyncio.sleep(1.5)
            try:
                await reconciliation.run_full_reconciliation()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconciliation (%s) failed: %s", reason, exc)

        try:
            self._reconcile_task = asyncio.get_running_loop().create_task(_go())
        except RuntimeError:
            pass


websocket_manager = WebSocketManager()
