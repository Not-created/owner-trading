# Final ARM / Holdings Reconciliation Fix — 2026-10-06 R2

## Root cause addressed

The LIVE ARM gate must never treat a generic Kotak HTTP 424 as an empty portfolio. The only safe empty-account cases are the documented 5203 `No Data` response and the narrow endpoint-specific 424 messages such as:

`No holdings found for this client <client>`

The adapter now additionally handles an SDK/OpenAPI exception path where `ApiException` contains only `status=424` and `reason=...` but no parsed `body`. The reason is converted into a canonical response **only when the HTTP status is genuinely 4xx/5xx**. Transport status 0/None remains an exception so state-changing calls stay UNKNOWN and reconciliation remains blocking.

## Safety rules

- 5203 + exact `No Data` + documented shape -> empty collection.
- 424 + exact endpoint-specific `No <section> found for this client ...` -> empty collection.
- Generic 424 -> BLOCK / discrepancy.
- 401/403/session-invalid -> AUTH / BLOCK.
- 429/5xx -> BLOCK.
- timeout / transport status 0 -> UNKNOWN for state-changing operations and blocking for reconciliation reads.
- malformed response -> BLOCK.

No ARM bypass, forced PASS, discrepancy suppression, or generic 424 acceptance was added.

## ARM / reconciliation chain

`Kotak SDK response -> sdk_adapter normalization -> semantic empty/error classification -> reconciliation section result -> reconciliation run COMPLETE/DISCREPANCY -> live readiness -> explicit ARM -> final readiness -> persisted arm state`

Concurrent reconciliation calls share and await one in-flight run. ARM does not interpret `skipped` as success.

## Deployment verification aid

Broker `/status` now exposes:

`releaseId = OWNER-TRADING-ARM-HOLDINGS-424-HARDENED-2026-10-06-R2`

This is an immutable release fingerprint so the VPS can prove which application build is actually running. It does not expose credentials or tokens.

## Validation

- Broker Python suite: 360 passed, 3 skipped
- SDK adapter + reconciliation + readiness focused suite: 80+ passed
- Python compile: PASS
- deploy.sh syntax: PASS
- SDK conformance tests included in full suite
- Vendor SDK source was not modified by this fix

A fresh frontend Vite production build was not executed in this environment because the runtime dependency installation/network path is unavailable here; deploy.sh performs the real dependency install and build on the VPS.
