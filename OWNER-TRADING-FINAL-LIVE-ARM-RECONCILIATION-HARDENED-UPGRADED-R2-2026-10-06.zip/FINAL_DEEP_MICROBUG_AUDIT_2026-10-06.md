# Owner Trading — Deep Micro-Bug + Live Connectivity Hardening
## 2026-10-06

This release was audited from the actual source tree, not from the previous audit report. Existing scope/features were preserved. The official Kotak Neo SDK source under `broker-service/vendor/kotakneoapi/neo_api_client` was compared with the supplied official SDK archive: **0 source-file differences**. Only local Python cache artifacts were excluded from the release ZIP.

## Production fixes in this upgrade

1. ARM now waits for an already-running reconciliation instead of treating it as a completed/failed stale state.
2. Global ARM and strategy ARM are serialized with the ARM critical section; global/strategy disarm is serialized too.
3. Final LIVE execution gate now checks reconciliation freshness independently from funds freshness.
4. Market-feed freshness is based on real SFeed price/index ticks, not market-status control frames.
5. Market tick freshness is reset on every new/reconnected SFeed socket, preventing stale pre-reconnect ticks from making a dead stream look healthy.
6. Scanner-linked strategy evaluation requires a live subscribed candidate; an ACTIVE-but-unsubscribed candidate can no longer produce an execution signal.
7. Manual scanner runs now honor an explicit scanner universe instead of silently scanning the whole metadata universe.
8. Scanner activation validates the persisted scanner definition before allowing it to become ACTIVE.
9. Partially filled pending ENTRY orders reserve a strategy position slot; they cannot bypass `max_strategy_positions`.
10. Pending ENTRY orders also reserve global open-position slots for `max_open_positions`.
11. Order modification now passes the same authoritative instrument/token, lot-size, tick-size, and official SDK field validation as a new order.
12. LIVE ATR-stop strategies cannot generate a new entry signal unless a usable ATR is available at signal time.
13. LIVE entry fills derive protective levels from the actual broker fill price; percentage/ATR levels are re-derived after weighted-average partial fills.
14. Exit requests now distinguish accepted/pending broker outcomes from deterministic rejection.
15. A rejected/cancelled exit is released as retryable instead of permanently blocking the position.
16. A process restart releases orphaned `REQUESTED` exits that never acquired a durable internal order.
17. Exit idempotency keys now include the durable `exit_id`, allowing a deterministic rejected exit to be retried with a fresh attempt while preserving the no-blind-retry rule for UNKNOWN outcomes.
18. Broker order-state reconciliation now propagates EXIT order rejection/cancellation/partial-fill state into `algo_exits`.
19. Final audit now reports real market-tick health, required strategy/candidate feed ownership, and scanner-runtime feed ownership.
20. Existing nested Kotak SDK REST `{"Error": ApiException(...)}` normalization, exact 424/5203 empty-read handling, and official `reqdMrgn`/`ordMrgn` margin parsing remain intact.
21. Existing token/symbol, lot-size and tick-size LIVE order safety checks remain enforced.
22. Existing restart-safe candidate/universe subscription recovery, reference-counted SFeed ownership, 3000-token capacity, order-feed reconciliation, and durable UNKNOWN-order handling remain intact.
23. Regression coverage was expanded for ARM/reconciliation concurrency, feed liveness, exit retry lifecycle, orphan exits, rejected exits, and partial-fill position pressure.

## Live execution/data-flow connectivity audit

The source-level chain is connected as follows:

`Kotak REST/Auth`
→ `sdk_adapter`
→ `BrokerClient`
→ `reconciliation / order_service`
→ `SQLite durable state`

`Kotak SFeed`
→ `WebSocketManager`
→ `market_data_state`
→ `CandleEngine`
→ `ScannerEngine / StrategyEngine`
→ `Signal`
→ `Risk Gate`
→ `Final LIVE Gate`
→ `OrderService`
→ `Kotak place_order`

`Kotak Order Feed`
→ `order_sync`
→ `SQLite order state`
→ `trade/fill reconciliation`
→ `algo_position`
→ `ExitEngine`
→ `risk-safe EXIT order`
→ `Order Feed / REST reconciliation`

Restart recovery is connected through persisted strategy/candidate state and the WebSocket owner registry.

## UI/API connectivity audit

- Frontend pages discovered: **20**.
- Frontend API request bases discovered: **61**.
- Backend route declarations: **69**.
- Backend SQLite migrations: **13**.
- Broker-service Python application modules: **28**.
- Strategy, scanner, backtest, execution-monitor, risk, market-data, orders, positions, holdings, funds, logs and system pages are present and wired through the central API client.
- Website-session HTTP 401 handling remains separated from broker/Kotak 401 responses; downstream broker errors do not force website logout.

## Validation

- Broker Python suite: **358 passed, 3 skipped**.
- Backend Node suite: **26 passed, 6 skipped**. The six skips are dependency-gated session E2E tests because the audit environment intentionally did not have the frontend/backend npm dependency tree installed.
- Python compileall: **PASS**.
- Shell syntax (`deploy.sh`, deployment scripts): **PASS**.
- Fresh SQLite migration + idempotency: **PASS**.
- Official SDK conformance tests: **6 passed**.
- Vendored official SDK manifest: **52 methods/signatures checked; integrity PASS**.
- Official SDK source comparison against supplied official archive: **0 source differences**.

## Environment limitation

A fresh Vite production build was not falsely claimed. The audit container has no installed frontend dependency tree and external npm registry access is unavailable, so `npm run build` could not be executed here. The deployment script still performs `npm ci`/`npm install` and then the real Vite production build on the target VPS. No application dependency versions were changed in this hardening pass.

## Safety conclusion

No LIVE safety gate was bypassed. The upgrade strengthens the existing fail-closed path. UNKNOWN broker outcomes still require reconciliation and are never blindly retried. EXITs remain allowed to reduce existing exposure subject to broker/session/reconciliation safety, while new exposure remains subject to owner ARM, feed, reconciliation, freshness, risk, duplicate/idempotency and funds/margin gates.
