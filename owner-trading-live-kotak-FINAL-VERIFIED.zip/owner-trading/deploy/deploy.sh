#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"
KOTAK_DIR="$PROJECT_ROOT/kotak_service"
BACKEND_SERVICE="owner-trading-backend"
KOTAK_SERVICE="kotak-service"
PORT="4000"
KOTAK_PORT="5055"

log(){ echo "[deploy] $*"; }
die(){ echo "[deploy] ERROR: $*" >&2; exit 1; }
random_hex(){ node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"; }
run_root(){ if [ "$(id -u)" -eq 0 ]; then "$@"; else sudo "$@"; fi; }

check_prereqs(){
  command -v node >/dev/null || die "Node.js is required."
  command -v npm >/dev/null || die "npm is required."
  command -v python3 >/dev/null || die "Python 3 is required."
  python3 -c 'import sys; assert sys.version_info >= (3,10)' || die "Python 3.10+ is required."
}

install_os_deps(){
  command -v systemctl >/dev/null || die "systemd is required on the deployment VPS."
  local need=()
  command -v nginx >/dev/null || need+=(nginx)
  command -v curl >/dev/null || need+=(curl)
  python3 -c 'import venv' >/dev/null 2>&1 || need+=(python3-venv)
  if [ ${#need[@]} -eq 0 ]; then return; fi
  command -v apt-get >/dev/null || die "Required OS packages missing and apt-get is not present: ${need[*]}"
  log "Installing required OS packages: ${need[*]}"
  run_root apt-get update -y
  run_root apt-get install -y "${need[@]}"
}

setup_env(){
  local host_ip domain frontend_origin kotak_secret
  host_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  host_ip="${host_ip:-127.0.0.1}"
  domain="${DOMAIN:-_}"
  frontend_origin="${FRONTEND_ORIGIN:-http://${host_ip}}"

  if [ ! -f "$BACKEND_DIR/.env" ]; then cp "$BACKEND_DIR/.env.example" "$BACKEND_DIR/.env"; fi
  kotak_secret="$(grep '^KOTAK_SERVICE_SECRET=' "$BACKEND_DIR/.env" | cut -d= -f2- || true)"
  [ -n "$kotak_secret" ] || kotak_secret="$(random_hex)"
  local session_secret encryption_key
  session_secret="$(grep '^SESSION_SECRET=' "$BACKEND_DIR/.env" | cut -d= -f2- || true)"
  encryption_key="$(grep '^CREDENTIAL_ENCRYPTION_KEY=' "$BACKEND_DIR/.env" | cut -d= -f2- || true)"
  [[ -n "$session_secret" && "$session_secret" != changeme* ]] || session_secret="$(random_hex)"
  [[ "$encryption_key" =~ ^[0-9a-fA-F]{64}$ ]] || encryption_key="$(node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')"
  sed -i \
    -e "s#^NODE_ENV=.*#NODE_ENV=production#" \
    -e "s#^PORT=.*#PORT=$PORT#" \
    -e "s#^FRONTEND_ORIGIN=.*#FRONTEND_ORIGIN=$frontend_origin#" \
    -e "s#^KOTAK_INTEGRATION_ENABLED=.*#KOTAK_INTEGRATION_ENABLED=true#" \
    -e "s#^KOTAK_SERVICE_URL=.*#KOTAK_SERVICE_URL=http://127.0.0.1:$KOTAK_PORT#" \
    -e "s#^KOTAK_SERVICE_SECRET=.*#KOTAK_SERVICE_SECRET=$kotak_secret#" \
    -e "s#^SESSION_SECRET=.*#SESSION_SECRET=$session_secret#" \
    -e "s#^CREDENTIAL_ENCRYPTION_KEY=.*#CREDENTIAL_ENCRYPTION_KEY=$encryption_key#" \
    "$BACKEND_DIR/.env"

  if [ ! -f "$KOTAK_DIR/.env" ]; then cp "$KOTAK_DIR/.env.example" "$KOTAK_DIR/.env"; fi
  sed -i -e "s#^KOTAK_SERVICE_SECRET=.*#KOTAK_SERVICE_SECRET=$kotak_secret#" -e "s#^KOTAK_SERVICE_PORT=.*#KOTAK_SERVICE_PORT=$KOTAK_PORT#" "$KOTAK_DIR/.env"

  # Same-origin production API; no hard-coded localhost in the browser bundle.
  cat > "$FRONTEND_DIR/.env" <<EOF
VITE_API_BASE_URL=/api
EOF
  # IP fallback is HTTP; explicitly disable Secure cookie only for this fallback.
  # When HTTPS is configured, deploy.sh sets COOKIE_SECURE=true.
  if [[ "$frontend_origin" == https://* ]]; then
    if grep -q '^COOKIE_SECURE=' "$BACKEND_DIR/.env"; then sed -i 's#^COOKIE_SECURE=.*#COOKIE_SECURE=true#' "$BACKEND_DIR/.env"; else echo 'COOKIE_SECURE=true' >> "$BACKEND_DIR/.env"; fi
  else
    if grep -q '^COOKIE_SECURE=' "$BACKEND_DIR/.env"; then sed -i 's#^COOKIE_SECURE=.*#COOKIE_SECURE=false#' "$BACKEND_DIR/.env"; else echo 'COOKIE_SECURE=false' >> "$BACKEND_DIR/.env"; fi
  fi
  chmod 600 "$BACKEND_DIR/.env" "$KOTAK_DIR/.env"
  log "Environment ready (real broker credentials are entered only through the application)."
}

install_dependencies(){
  log "Installing Node dependencies..."; (cd "$BACKEND_DIR" && npm install --omit=dev)
  log "Installing frontend dependencies..."; (cd "$FRONTEND_DIR" && npm install)
}
setup_python(){
  [ -d "$KOTAK_DIR/venv" ] || python3 -m venv "$KOTAK_DIR/venv"
  "$KOTAK_DIR/venv/bin/pip" install --upgrade pip
  "$KOTAK_DIR/venv/bin/pip" install -r "$KOTAK_DIR/requirements.txt"
}
build_frontend(){ (cd "$FRONTEND_DIR" && npm run build); [ -f "$FRONTEND_DIR/dist/index.html" ] || die "Frontend build failed."; }
setup_systemd(){
  local user="${SUDO_USER:-$(id -un)}"
  [ "$user" != "root" ] || user="ubuntu"
  local tmp1 tmp2
  tmp1="$(mktemp)"; tmp2="$(mktemp)"
  sed -e "s#__PROJECT_ROOT__#$PROJECT_ROOT#g" -e "s#__SERVICE_USER__#$user#g" "$SCRIPT_DIR/kotak-service.service.template" > "$tmp1"
  sed -e "s#__PROJECT_ROOT__#$PROJECT_ROOT#g" -e "s#__SERVICE_USER__#$user#g" "$SCRIPT_DIR/owner-trading.service.template" > "$tmp2"
  run_root install -m 0644 "$tmp1" "/etc/systemd/system/$KOTAK_SERVICE.service"
  run_root install -m 0644 "$tmp2" "/etc/systemd/system/$BACKEND_SERVICE.service"
  rm -f "$tmp1" "$tmp2"
  run_root systemctl daemon-reload
  run_root systemctl enable "$KOTAK_SERVICE" "$BACKEND_SERVICE"
}
setup_nginx(){
  local domain="${DOMAIN:-_}"
  local conf="/etc/nginx/sites-available/$BACKEND_SERVICE"
  run_root install -d /etc/nginx/sites-available /etc/nginx/sites-enabled
  sed -e "s#__DOMAIN__#$domain#g" -e "s#__PROJECT_ROOT__#$PROJECT_ROOT#g" -e "s#__BACKEND_PORT__#$PORT#g" "$SCRIPT_DIR/nginx.conf.template" | run_root tee "$conf" >/dev/null
  run_root ln -sf "$conf" "/etc/nginx/sites-enabled/$BACKEND_SERVICE"
  # Preserve unrelated sites. If the stock Ubuntu Nginx default is still the
  # default server, disable only that stock site so Owner Trading can own :80.
  if [ -e /etc/nginx/sites-enabled/default ] && grep -q 'listen 80 default_server' /etc/nginx/sites-enabled/default 2>/dev/null; then
    if grep -q 'Welcome to nginx' /etc/nginx/sites-enabled/default 2>/dev/null || grep -q 'root /var/www/html' /etc/nginx/sites-enabled/default 2>/dev/null; then
      run_root rm -f /etc/nginx/sites-enabled/default
      log "Disabled stock Nginx default site; unrelated custom sites were left untouched."
    else
      die "Another custom Nginx default_server is active on port 80; refusing to replace it automatically."
    fi
  fi
  run_root nginx -t
  run_root systemctl enable nginx
  run_root systemctl restart nginx
}
run_migrations(){
  log "Database migrations are applied by the backend startup against the configured SQLite database.";
}
start_services(){
  run_root systemctl restart "$KOTAK_SERVICE" "$BACKEND_SERVICE"
}
health(){
  local host_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"; host_ip="${host_ip:-127.0.0.1}"
  local i
  for i in $(seq 1 30); do
    if curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null \
       && curl -fsS "http://127.0.0.1:$KOTAK_PORT/health" >/dev/null \
       && curl -fsS -H "Host: $host_ip" "http://127.0.0.1/" >/dev/null; then
      log "All local health checks passed."
      return
    fi
    sleep 1
  done
  die "Deployment health checks failed after 30 seconds."
}

main(){
  check_prereqs
  install_os_deps
  setup_env
  install_dependencies
  setup_python
  build_frontend
  run_migrations
  setup_systemd
  setup_nginx
  start_services
  health
  log "============================================================"
  log "ONE-COMMAND DEPLOYMENT COMPLETE"
  log "Frontend/API: http://$(hostname -I | awk '{print $1}')/"
  log "Kotak credentials: enter through Settings -> Test Connection / Save & Connect"
  log "No second deployment command is required."
  log "============================================================"
}
main "$@"
