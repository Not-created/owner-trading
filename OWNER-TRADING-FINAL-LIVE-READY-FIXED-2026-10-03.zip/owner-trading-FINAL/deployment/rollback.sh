#!/usr/bin/env bash
# Owner Trading -- manual release rollback. Keeps persistent DB/credentials untouched.
set -euo pipefail
BASE="${RUNTIME_ROOT:-/opt/owner-trading}"
CURRENT="$BASE/current"
RELEASES="$BASE/releases"
[ "$(id -u)" -eq 0 ] || exec sudo -E bash "$0" "$@"
TARGET="${1:-}"
if [ -z "$TARGET" ]; then
  TARGET="$(find "$RELEASES" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' 2>/dev/null | sort -nr | sed -n '2p' | cut -d' ' -f2-)"
fi
[ -n "$TARGET" ] && [ -d "$TARGET" ] || { echo "No rollback release found." >&2; exit 1; }
CURRENT_REAL="$(readlink -f "$CURRENT" 2>/dev/null || true)"
[ "$TARGET" != "$CURRENT_REAL" ] || { echo "Target is already current: $TARGET"; exit 0; }
echo "Rolling back $CURRENT_REAL -> $TARGET"
systemctl stop owner-trading-broker owner-trading-backend || true
ln -sfn "$TARGET" "$CURRENT"
systemctl daemon-reload
systemctl start owner-trading-broker
systemctl start owner-trading-backend
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:8800/health >/dev/null 2>&1 && curl -fsS http://127.0.0.1:4000/api/health >/dev/null 2>&1; then
    echo "Rollback health checks passed. current=$(readlink -f "$CURRENT")"
    exit 0
  fi
  sleep 1
done
journalctl -u owner-trading-broker -u owner-trading-backend -n 80 --no-pager
exit 1
