#!/usr/bin/env bash
# Post-deploy smoke test of the whole chain. Reports PASS/FAIL per check; exits non-zero on any FAIL.
# Never places orders and never logs in to Kotak.
set -uo pipefail
SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME_ROOT="${RUNTIME_ROOT:-/opt/owner-trading}"
CURRENT_LINK="$RUNTIME_ROOT/current"
ROOT_DIR="$(readlink -f "$CURRENT_LINK" 2>/dev/null || true)"
[ -d "$ROOT_DIR/backend" ] || ROOT_DIR="$SOURCE_ROOT"
BACKEND_ENV="${BACKEND_ENV:-/etc/owner-trading/backend.env}"
BROKER_ENV="${BROKER_ENV:-/etc/owner-trading/broker.env}"
PORT="$(grep -E '^PORT=' "$BACKEND_ENV" 2>/dev/null | cut -d= -f2 || true)"; PORT="${PORT:-4000}"
BPORT="$(grep -E '^BROKER_SERVICE_PORT=' "$BROKER_ENV" 2>/dev/null | cut -d= -f2 || true)"; BPORT="${BPORT:-8800}"
TOKEN="$(grep -E '^BROKER_SERVICE_TOKEN=' "$BROKER_ENV" 2>/dev/null | cut -d= -f2 || true)"
MODE="LIVE"
DOMAIN="${DOMAIN:-}"
FAILS=0
check() { if eval "$2" >/dev/null 2>&1; then printf '  PASS  %s\n' "$1"; else printf '  FAIL  %s\n' "$1"; FAILS=$((FAILS+1)); fi; }

echo "Services"
check "owner-trading-broker active"  "systemctl is-active --quiet owner-trading-broker"
check "owner-trading-backend active" "systemctl is-active --quiet owner-trading-backend"
echo "Working-directory / ProtectHome (the P0 502 failure mode: CHDIR under ProtectHome=true)"
for u in owner-trading-backend owner-trading-broker; do
  check "$u: no CHDIR error in recent journal" "! journalctl -u $u -n 30 --no-pager 2>/dev/null | grep -qi 'CHDIR\\|Changing to the requested working directory failed'"
  WD="$(systemctl show "$u" -p WorkingDirectory 2>/dev/null | cut -d= -f2)"
  check "$u: WorkingDirectory ($WD) is set" "[ -n \"$WD\" ]"
  RO="$(systemctl show "$u" -p ReadOnlyPaths 2>/dev/null | cut -d= -f2-)"
  check "$u: ReadOnlyPaths covers its own WorkingDirectory (re-exposes it under ProtectHome=true)" "echo \"$RO\" | grep -qF \"$WD\""
  PH="$(systemctl show "$u" -p ProtectHome 2>/dev/null | cut -d= -f2)"
  check "$u: ProtectHome is still true (hardening preserved, not disabled to work around this)" "[ \"$PH\" = yes ] || [ \"$PH\" = true ]"
done
echo "Broker service (loopback)"
check "/health answers"                          "curl -fsS --max-time 5 http://127.0.0.1:$BPORT/health"
check "/status rejects a missing token"          "[ \"\$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:$BPORT/status)\" = 401 ] || [ -z \"$TOKEN\" ]"
check "/status accepts the internal token"       "curl -fsS --max-time 5 -H 'X-Internal-Token: $TOKEN' http://127.0.0.1:$BPORT/status"
check "broker port is bound to loopback only"    "! ss -ltn | grep -E ':$BPORT ' | grep -vE '127\\.0\\.0\\.1|\\[::1\\]'"
echo "Backend"
check "/api/health answers"                      "curl -fsS --max-time 5 http://127.0.0.1:$PORT/api/health"
check "protected API requires a session"         "[ \"\$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:$PORT/api/orders)\" = 401 ]"
check "frontend build is served"                 "curl -fsS --max-time 5 http://127.0.0.1:$PORT/ | grep -qi '<div id=\"root\"'"
check "backend port is bound to loopback only"    "! ss -ltn | grep -E ':$PORT ' | grep -vE '127\.0\.0\.1|\[::1\]'"
echo "Release / persistent state"
check "current release symlink exists" "[ -L "$CURRENT_LINK" ] && [ -d "$CURRENT_LINK/backend" ]"
check "persistent SQLite DB exists" "[ -s /var/lib/owner-trading/data/owner-trading.db ]"
check "persistent secure state directory exists" "[ -d /var/lib/owner-trading/secure ]"
echo "Configuration"
T1="$(grep -E '^BROKER_SERVICE_TOKEN=' "$BACKEND_ENV" 2>/dev/null | cut -d= -f2)"
check "BROKER_SERVICE_TOKEN identical in both env files" "[ -n \"$T1\" ] && [ \"$T1\" = \"$TOKEN\" ]"
check "env files are mode 600" "[ \"\$(stat -c %a $BACKEND_ENV)\" = 600 ] && [ \"\$(stat -c %a $BROKER_ENV)\" = 600 ]"
CP="$(grep -E '^SESSION_COOKIE_SECURE=' "$BACKEND_ENV" 2>/dev/null | cut -d= -f2 | tr 'A-Z' 'a-z')"; CP="${CP:-auto}"
check "SESSION_COOKIE_SECURE is auto/true/false ($CP)" "echo $CP | grep -qE '^(auto|true|false|1|0|yes|no|on|off)$'"
if [ "$MODE" = "LIVE" ]; then check "LIVE requires SESSION_COOKIE_SECURE=true" "echo $CP | grep -qE '^(true|1|yes|on)$'"; fi
if command -v nginx >/dev/null 2>&1 && systemctl is-active --quiet nginx 2>/dev/null; then
  echo "HTTP through nginx (port 80)"
  check "nginx config valid"                    "nginx -t"
  check "HTTP redirects to HTTPS (no 502)"         "[ \"$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1/api/health)\" = 301 ]"
  check "nginx forwards X-Forwarded-Proto"      "grep -rq 'X-Forwarded-Proto \$scheme' /etc/nginx/snippets/owner-trading-proxy.conf"
fi
if [ -n "$DOMAIN" ]; then
  echo "Public HTTPS ($DOMAIN) -- only meaningful when DNS points here and a certificate was issued"
  if echo "$DOMAIN" | grep -qE "^[0-9]+(\.[0-9]+){3}$"; then
    check "HTTPS IP bootstrap certificate + app reachable" "curl -kfsS --max-time 10 https://$DOMAIN/api/health"
  else
    check "HTTPS certificate valid and app reachable" "curl -fsS --max-time 10 https://$DOMAIN/api/health"
    check "certbot renewal timer"                     "systemctl list-timers 2>/dev/null | grep -qi certbot || [ -f /etc/cron.d/certbot ]"
  fi
  check "HTTP redirects to HTTPS" "[ \"$(curl -k -s -o /dev/null -w '%{http_code}' --max-time 10 http://$DOMAIN/api/health)\" = 301 ]"
fi
echo
[ "$FAILS" -eq 0 ] && echo "All checks passed." || { echo "$FAILS check(s) FAILED."; exit 1; }
