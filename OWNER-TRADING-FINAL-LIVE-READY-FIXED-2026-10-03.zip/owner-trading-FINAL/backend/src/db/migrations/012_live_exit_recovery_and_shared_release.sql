-- LIVE execution hardening: durable exit linkage/state and release-safe runtime fields.
-- Additive only; existing orders/positions/credentials remain intact.
ALTER TABLE orders ADD COLUMN exit_id INTEGER REFERENCES algo_exits(id);
CREATE INDEX IF NOT EXISTS idx_orders_exit_id ON orders(exit_id);
ALTER TABLE algo_exits ADD COLUMN attempt_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE algo_exits ADD COLUMN error_message TEXT;
ALTER TABLE algo_exits ADD COLUMN updated_at TEXT NOT NULL DEFAULT (datetime('now'));
CREATE INDEX IF NOT EXISTS idx_algo_exits_recovery ON algo_exits(status, internal_order_id, created_at);
