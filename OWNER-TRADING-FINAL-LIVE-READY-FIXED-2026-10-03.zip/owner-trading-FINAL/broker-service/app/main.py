"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express. When encrypted credentials are already present, the
service uses the same verified connect path on startup and after a detected
session expiry; no credentials means no broker login attempt.
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")

# BUGFIX (final audit): session.check_and_handle_expiry() and
# reconciliation.run_full_reconciliation() were both fully implemented but
# never invoked from anywhere -- dead code. Session expiry would never be
# detected until the next broker call happened to fail, and reconciliation
# never ran on any schedule (only once, right after a successful connect,
# per the fix in broker_client.py). This loop is what actually makes both
# real: it polls every SESSION_CHECK_INTERVAL_SECONDS while the service is
# up, regardless of connection state (check_and_handle_expiry() itself is a
# no-op unless state is CONNECTED), and re-reconciles on the slower
# RECONCILIATION_INTERVAL_SECONDS cadence whenever still CONNECTED.
SESSION_CHECK_INTERVAL_SECONDS = 60
RECONCILIATION_INTERVAL_SECONDS = 15 * 60
AUTO_RECONNECT_RETRY_SECONDS = 5 * 60


def _determine_initial_state() -> None:
    """Sets the starting state without inventing credentials. If saved credentials are recovered, main() may subsequently run the verified auto-connect lifecycle. LIVE refuses to start without the internal API token."""
    import os
    from . import sdk_adapter
    from .credential_manager import credential_manager

    if config.trading_mode == "LIVE" and not os.environ.get("BROKER_SERVICE_TOKEN"):
        raise SystemExit("LIVE execution requires BROKER_SERVICE_TOKEN to be set. Refusing to start.")

    if config.trading_mode == "LIVE" or sdk_adapter.SDK_AVAILABLE:
        from .broker_client import sdk_ready
        ok, reason = sdk_ready()
        if not ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, reason)
            logger.error(reason)
            return
        from .sdk_conformance import check_sdk_conformance
        conformance = check_sdk_conformance()
        if not conformance.ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, conformance.summary())
            logger.error(conformance.summary())
            return
        logger.info(conformance.summary())
    else:
        current_state.transition(BrokerState.CONNECTION_ERROR, f"Official SDK not importable: {sdk_adapter.SDK_IMPORT_ERROR}")
        logger.warning("Official SDK not importable -- broker service running in degraded mode.")
        return

    if config.is_fully_configured():
        credential_manager.set(consumer_key=config.consumer_key, mobile_number=config.mobile_number, ucc=config.ucc,
                               mpin=config.mpin, totp_secret=config.totp_secret)
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials loaded from protected environment. State: DISCONNECTED (startup lifecycle may authenticate automatically).")
    else:
        try:
            if credential_manager.load_persisted():
                current_state.transition(BrokerState.DISCONNECTED)
                logger.info("Encrypted Kotak credentials recovered. State: DISCONNECTED (startup lifecycle may authenticate automatically).")
            else:
                current_state.transition(BrokerState.NOT_CONFIGURED)
                logger.info("Kotak credentials are not configured. State: NOT_CONFIGURED.")
        except Exception as exc:
            current_state.transition(BrokerState.AUTH_FAILED, "Persisted credential store could not be loaded.")
            logger.error("Encrypted credential store load failed: %s", exc)


async def _auto_connect_on_startup() -> dict | None:
    """Authenticate once at service startup when encrypted credentials exist.
    This is deliberately a separate lifecycle function so it is easy to test
    without starting the HTTP server. No credentials means a strict no-op."""
    from .credential_manager import credential_manager

    if (not credential_manager.has_base_credentials() or current_state.state != BrokerState.DISCONNECTED
            or not credential_manager.startup_auto_connect_allowed()):
        return None
    try:
        result = await broker_client_module.broker_client.connect()
        if result.get("state") == BrokerState.CONNECTED.value:
            logger.info("Kotak broker authenticated automatically from saved credentials on service startup.")
        else:
            logger.warning("Kotak startup auto-connect did not connect: state=%s error=%s",
                           result.get("state"), result.get("last_error"))
        return result
    except Exception as exc:  # noqa: BLE001
        logger.warning("Kotak startup auto-connect failed: %s", exc)
        return {"state": BrokerState.CONNECTION_ERROR.value, "last_error": type(exc).__name__}


async def _background_maintenance_loop(stop_event: asyncio.Event) -> None:
    """Session-expiry detection, controlled broker recovery and scheduled
    reconciliation. A failed recovery never kills the maintenance loop."""
    from . import reconciliation as _reconciliation
    from . import session as _session
    from . import websocket_manager as _wsm
    from .credential_manager import credential_manager

    elapsed = 0
    retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
    recovery_pending = False
    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=SESSION_CHECK_INTERVAL_SECONDS)
            break
        except asyncio.TimeoutError:
            pass

        try:
            ttl_expired = _session.check_and_handle_expiry()
            broker_reported_expiry = current_state.state == BrokerState.SESSION_EXPIRED
            if ttl_expired or broker_reported_expiry:
                if not recovery_pending:
                    logger.warning("Broker session expired; scheduling verified automatic reconnect.")
                    await _wsm.websocket_manager.stop()
                    recovery_pending = True
                    # Try once immediately. If Kotak rejects it, subsequent
                    # retries are spaced out to avoid an authentication storm.
                    retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
                    try:
                        result = await broker_client_module.broker_client.connect()
                        if result.get("state") == BrokerState.CONNECTED.value:
                            recovery_pending = False
                            logger.info("Broker session recovered automatically after expiry.")
                        else:
                            logger.warning("Automatic broker recovery did not connect: state=%s error=%s",
                                           result.get("state"), result.get("last_error"))
                    except Exception as recovery_exc:  # noqa: BLE001
                        logger.warning("Immediate broker recovery attempt failed: %s", recovery_exc)
        except Exception as exc:  # noqa: BLE001
            recovery_pending = True
            logger.warning("Session-expiry/recovery check failed: %s", exc)

        # An explicit owner Disconnect (or a fresh credential save) transitions
        # the service to DISCONNECTED. That must cancel any pending automatic
        # recovery so the service does not reconnect against the owner's intent.
        if current_state.state == BrokerState.DISCONNECTED:
            recovery_pending = False
            retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS

        if recovery_pending and credential_manager.has_base_credentials():
            retry_elapsed -= SESSION_CHECK_INTERVAL_SECONDS
            if retry_elapsed <= 0:
                retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
                try:
                    result = await broker_client_module.broker_client.connect()
                    if result.get("state") == BrokerState.CONNECTED.value:
                        recovery_pending = False
                        logger.info("Broker automatic recovery retry succeeded.")
                    else:
                        logger.warning("Broker automatic recovery retry failed: state=%s error=%s",
                                       result.get("state"), result.get("last_error"))
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Broker automatic recovery retry failed: %s", exc)

        elapsed += SESSION_CHECK_INTERVAL_SECONDS
        if elapsed >= RECONCILIATION_INTERVAL_SECONDS:
            elapsed = 0
            if current_state.state == BrokerState.CONNECTED:
                try:
                    await _reconciliation.run_full_reconciliation()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Scheduled reconciliation failed: %s", exc)


async def _main() -> None:
    # Recover durable exit requests before any new tick can trigger a duplicate
    # protective order. No automatic broker resubmission is performed here.
    try:
        from . import db as _db
        logger.info("Exit recovery: %s", _db.recover_exit_state())
    except Exception as exc:
        logger.warning("Exit-state recovery failed: %s", exc)
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())

    # Persistent-service recovery: only reconnect after an explicit prior owner
    # CONNECT. Credentials alone are never treated as owner intent.
    await _auto_connect_on_startup()

    maintenance_task = asyncio.create_task(_background_maintenance_loop(stop_event))

    await stop_event.wait()
    server_task.cancel()
    maintenance_task.cancel()
    for task in (server_task, maintenance_task):
        try:
            await task
        except asyncio.CancelledError:
            pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
