"""Market (SFeed) and order-feed supervision on the official async SDK clients.

Uses ONLY the SDK's modern clients (`NeoAPI.create_websocket()` -> SFeedWebSocket,
`NeoAPI.create_order_feed()` -> OrderFeedWebSocket) with their documented
callbacks (on_message / on_connect / on_disconnect / on_error) and
`subscribe_scrips(list[WsToken])`. The legacy v2 callback-attribute /
`subscribe(instrument_tokens=...)` handling has been removed.

Division of labour (from the SDK source):
  * The SDK client reconnects on its own (reconnect_delay x max_reconnect_attempts)
    and re-sends its own subscriptions.
  * THIS supervisor covers what the SDK does not: (a) a client that gave up
    (is_connected stays False past the SDK's own retry window) -> build a new
    client from the current session, back off, resubscribe from our registry;
    (b) after ANY (re)connect of the order feed -> REST reconciliation, because
    order events sent while disconnected are not replayed;
    (c) repeated failures -> probe the session with a read-only limits() call so
    an expired session moves the service to SESSION_EXPIRED instead of looping.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any

from . import db as _db
from . import order_sync, sdk_adapter
from .broker_client import NotConfiguredError, broker_client
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket")

# SDK retries internally for about reconnect_delay * max_reconnect_attempts (5s * 5).
SDK_RECONNECT_WINDOW_SECONDS = 30
LOST_GRACE_SECONDS = SDK_RECONNECT_WINDOW_SECONDS + 10
BACKOFF_START, BACKOFF_MAX = 2.0, 60.0
PROBE_AFTER_FAILURES = 3
TICK_WRITE_INTERVAL_SECONDS = 1.0
STALE_AFTER_SECONDS = 90   # informational only: silence is normal outside market hours
_TICK_TYPES = ("scrip", "scrip_lite", "index")


class WebSocketManager:
    def __init__(self) -> None:
        self._subs: dict[tuple[str, str], None] = {}      # registry: (exchange_segment, token)
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()
        self._market: Any = None
        self._order: Any = None
        self._last_market_msg: float | None = None
        self._last_order_msg: float | None = None
        self._last_tick_write: dict[tuple[str, str], float] = {}
        self._reconnects = {"market": 0, "order": 0}
        self._reconcile_task: asyncio.Task | None = None
        self._market_status: dict[str, dict] = {}
        self._max_subscriptions = 3000

    # ------------------------------------------------------------ lifecycle
    @property
    def running(self) -> bool:
        return any(not t.done() for t in self._tasks)

    async def start(self) -> None:
        if self.running:
            return
        self._stop = asyncio.Event()
        self._tasks = [
            asyncio.create_task(self._supervise("market", self._run_market)),
            asyncio.create_task(self._supervise("order", self._run_order)),
        ]

    async def stop(self) -> None:
        self._stop.set()
        try:
            from .candle_engine import candle_engine
            candle_engine.flush()
        except Exception as exc:
            logger.warning("Failed to flush forming candles during websocket stop: %s", exc)
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        self._tasks = []
        for feed in (self._market, self._order):
            await self._safe_close(feed)
        self._market = self._order = None

    @staticmethod
    async def _safe_close(feed) -> None:
        if feed is None:
            return
        try:
            await feed.close()
        except Exception:  # noqa: BLE001
            pass

    # -------------------------------------------------------- subscriptions
    async def subscribe(self, exchange_segment: str, instrument_token: str) -> None:
        if exchange_segment not in sdk_adapter.EXCHANGE_SEGMENTS:
            raise ValueError(f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}.")
        key = (exchange_segment, str(instrument_token))
        if key not in self._subs and len(self._subs) >= self._max_subscriptions:
            raise ValueError(f"SFeed subscription limit reached ({self._max_subscriptions}).")
        self._subs[key] = None
        feed = self._market
        if feed is not None and feed.is_connected:
            await feed.subscribe_scrips([sdk_adapter.make_ws_token(*key)])

    async def unsubscribe(self, exchange_segment: str, instrument_token: str) -> None:
        key = (exchange_segment, str(instrument_token))
        self._subs.pop(key, None)
        feed = self._market
        if feed is not None and feed.is_connected:
            await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*key)])

    async def subscribe_many(self, keys: list[tuple[str, str]]) -> dict:
        normalized=[]
        for exchange_segment, instrument_token in keys:
            if exchange_segment not in sdk_adapter.EXCHANGE_SEGMENTS:
                raise ValueError(f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}.")
            normalized.append((exchange_segment,str(instrument_token)))
        normalized=list(dict.fromkeys(normalized))
        new_keys=[k for k in normalized if k not in self._subs]
        if len(self._subs)+len(new_keys)>self._max_subscriptions:
            raise ValueError(f"SFeed subscription limit reached ({self._max_subscriptions}).")
        feed=self._market
        added=[]
        try:
            if feed is not None and feed.is_connected and new_keys:
                for i in range(0,len(new_keys),500):
                    batch=new_keys[i:i+500]
                    await feed.subscribe_scrips([sdk_adapter.make_ws_token(*k) for k in batch])
                    # Reflect only broker-confirmed batches in the desired registry.
                    for key in batch:
                        self._subs[key]=None
                        added.append(key)
            else:
                for key in new_keys:
                    self._subs[key]=None
                    added.append(key)
        except Exception:
            # A later batch can fail after earlier frames were accepted. Keep the
            # accepted registry entries so readiness accurately reports what was
            # requested, and let the caller decide whether to roll them back.
            logger.exception("SFeed batched subscription failed after %d token(s).", len(added))
            raise
        return {"requested":len(normalized),"added":len(added),"total":len(self._subs)}

    async def unsubscribe_many(self, keys: list[tuple[str, str]]) -> dict:
        normalized=list(dict.fromkeys((s,str(t)) for s,t in keys))
        feed=self._market
        existing=[k for k in normalized if k in self._subs]
        removed=0
        if feed is not None and feed.is_connected and existing:
            for i in range(0,len(existing),500):
                batch=existing[i:i+500]
                await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*k) for k in batch])
                for key in batch:
                    self._subs.pop(key,None)
                    removed += 1
        else:
            for key in existing:
                self._subs.pop(key,None)
                removed += 1
        return {"requested":len(normalized),"removed":removed,"total":len(self._subs)}

    async def restore_armed_strategy_subscriptions(self) -> dict:
        """Rebuild the in-memory feed registry from persisted LIVE strategies."""
        from . import db as _db
        requested = set()
        for item in _db.list_live_armed_strategy_versions():
            definition = item.get("definition") or {}
            universe = definition.get("universe") or {}
            for token in (universe.get("instrument_tokens") or []) if isinstance(universe, dict) else []:
                tok = str(token).strip()
                if tok and _db.get_instrument("nse_cm", tok):
                    requested.add(("nse_cm", tok))
        if len(requested) > self._max_subscriptions:
            raise RuntimeError(f"Persisted LIVE universe exceeds SFeed limit ({len(requested)} > {self._max_subscriptions}).")
        self._subs = {key: None for key in sorted(requested)}
        logger.info("Restored %d persisted LIVE market subscriptions.", len(self._subs))
        return {"restored": len(self._subs)}

    async def remove_if_unneeded(self, keys: list[tuple[str, str]]) -> int:
        """Remove subscriptions no longer required by any armed strategy."""
        from . import db as _db
        needed = set()
        for item in _db.list_live_armed_strategy_versions():
            universe = (item.get("definition") or {}).get("universe") or {}
            if isinstance(universe, dict):
                needed.update(("nse_cm", str(t).strip()) for t in (universe.get("instrument_tokens") or []) if str(t).strip())
        removed = 0
        for key in keys:
            if key in self._subs and key not in needed:
                await self.unsubscribe(*key)
                removed += 1
        return removed

    def subscriptions(self) -> list[dict]:
        # Resolve display metadata in one bounded DB lookup so a large (up to 3000)
        # subscription set does not cause one SQLite query per row.
        metadata = _db.get_instruments_for_keys(list(self._subs))
        out = []
        for s, t in self._subs:
            item = {"exchange_segment": s, "instrument_token": t}
            instrument = metadata.get((s, t))
            if instrument:
                item["trading_symbol"] = instrument.get("trading_symbol")
                item["name"] = instrument.get("name")
            out.append(item)
        return out

    # ------------------------------------------------------------- status
    def is_stale(self) -> bool:
        """True when a market subscription exists, the feed claims to be
        connected, and nothing arrived for STALE_AFTER_SECONDS. Informational
        (no ticks is normal when the market is closed); never forces a reconnect."""
        if not self._subs or self._market is None or not self._market.is_connected:
            return False
        if self._last_market_msg is None:
            return False
        return (time.time() - self._last_market_msg) > STALE_AFTER_SECONDS

    def status(self) -> dict:
        m, o = self._market, self._order
        return {
            "running": self.running,
            "market": {"connected": bool(m and m.is_connected), "subscriptions": len(self._subs),
                       "lastMessageAt": self._last_market_msg, "reconnects": self._reconnects["market"], "stale": self.is_stale(),
                       "maxSubscriptions": self._max_subscriptions, "marketStatus": self._market_status},
            "orderFeed": {"connected": bool(o and o.is_connected), "lastMessageAt": self._last_order_msg,
                          "reconnects": self._reconnects["order"]},
        }

    # ----------------------------------------------------------- supervisor
    async def _supervise(self, name: str, runner) -> None:
        backoff, failures = BACKOFF_START, 0
        while not self._stop.is_set():
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                await self._sleep(2.0)   # no valid session: nothing to (re)connect to
                continue
            started = time.time()
            try:
                await runner()
                failures = 0
            except asyncio.CancelledError:
                raise
            except NotConfiguredError:
                await self._sleep(2.0)
                continue
            except Exception as exc:  # noqa: BLE001
                failures += 1
                logger.warning("%s feed failed (%s: %s); failure %d.", name, type(exc).__name__, exc, failures)
            self._reconnects[name] += 1
            if time.time() - started > 60:      # a long healthy run resets backoff
                backoff, failures = BACKOFF_START, 0
            if failures >= PROBE_AFTER_FAILURES:
                await self._probe_session()
                failures = 0
            await self._sleep(backoff * (1 + random.uniform(0, 0.25)))
            backoff = min(backoff * 2, BACKOFF_MAX)

    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _probe_session(self) -> None:
        """Read-only limits(); an AUTH outcome flips state to SESSION_EXPIRED inside broker_client."""
        try:
            await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("limits"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session probe failed: %s", exc)

    async def _hold_until_lost(self, feed) -> None:
        """Returns once `feed` has been disconnected longer than the SDK's own retry window."""
        down_since: float | None = None
        while not self._stop.is_set():
            await asyncio.sleep(1.0)
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                return
            if feed.is_connected:
                down_since = None
            else:
                down_since = down_since or time.time()
                if time.time() - down_since > LOST_GRACE_SECONDS:
                    return

    # ------------------------------------------------------------- market
    async def _run_market(self) -> None:
        feed = broker_client.create_market_feed()
        self._market = feed
        feed.on_message = self._on_market_message
        feed.on_error = lambda e: logger.warning("SFeed error: %s", e)
        feed.on_connect = lambda: self._on_market_connect(feed)
        try:
            await feed.connect()
            try:
                await feed.subscribe_exchange()
            except Exception as exc:
                logger.warning("Market-status subscription unavailable: %s", exc)
            await self._resubscribe(feed)
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    async def _resubscribe(self, feed) -> None:
        tokens = [sdk_adapter.make_ws_token(s, t) for s, t in self._subs]
        for i in range(0, len(tokens), 500):
            await feed.subscribe_scrips(tokens[i:i + 500])

    def _on_market_connect(self, feed) -> None:
        # SDK-internal reconnects re-send its own subscriptions; if the counts
        # disagree (e.g. a new client), our registry is authoritative.
        if feed.subscription_count < len(self._subs):
            asyncio.get_running_loop().create_task(self._resubscribe(feed))

    def _on_market_message(self, message) -> None:
        self._last_market_msg = time.time()
        mtype = getattr(message, "type", None)
        if mtype == "market_status":
            seg = getattr(message, "exchange_segment", None)
            if seg:
                self._market_status[str(seg)] = {"status_code": getattr(message, "status_code", None), "status": getattr(message, "status", None), "updatedAt": time.time()}
            return
        if mtype not in _TICK_TYPES:
            return
        seg, tok = getattr(message, "exchange_segment", None), getattr(message, "instrument_token", None)
        ltp = getattr(message, "last_traded_price", None)
        if not tok or ltp is None:
            return
        now = time.time()
        # Some lightweight unit tests instantiate the manager without __init__;
        # keep the tick path defensive while retaining the same production state.
        if not hasattr(self, "_pending_tick_rows"):
            self._pending_tick_rows = {}
            self._last_tick_flush = 0.0
            self._tick_flush_interval = 1.0
        if not hasattr(self, "_last_tick_write"):
            self._last_tick_write = {}
        key = (seg or "", str(tok))
        # Protective exits are deliberately NOT throttled with the 1-second
        # persistence writer. They consume every valid market tick.
        try:
            from .exit_engine import on_tick as exit_tick
            asyncio.get_running_loop().create_task(
                exit_tick(exchange_segment=seg, instrument_token=str(tok), price=float(ltp))
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Protective exit tick dispatch failed: %s", exc)
        # Candle construction must consume EVERY valid tick. SQLite persistence
        # remains throttled independently so database load does not distort OHLC.
        try:
            from .candle_engine import candle_engine
            import datetime as dt
            from zoneinfo import ZoneInfo
            raw_ts = getattr(message, "last_trade_time", None) or getattr(message, "last_update_time", None)
            tick_ts = None
            if raw_ts:
                epoch = float(raw_ts) / (1000.0 if float(raw_ts) > 1_000_000_000_000 else 1.0)
                tick_ts = dt.datetime.fromtimestamp(epoch, tz=dt.timezone.utc)
            candle_engine.on_tick(exchange_segment=seg, instrument_token=str(tok),
                                  trading_symbol=getattr(message, "trading_symbol", None), price=float(ltp),
                                  volume=getattr(message, "volume_traded_today", None), timestamp=tick_ts)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Candle/algo processing failed: %s", exc)

        # Queue only the latest tick for each instrument and flush the whole
        # batch in one SQLite transaction. This keeps the DB useful for LTP/risk
        # lookups without allowing a 3000-token feed to become 3000 writes/sec.
        if now - self._last_tick_write.get(key, 0) >= TICK_WRITE_INTERVAL_SECONDS:
            self._last_tick_write[key] = now
            self._pending_tick_rows[key] = {
                "instrument_token": str(tok), "exchange_segment": seg,
                "last_traded_price": float(ltp),
                "trading_symbol": getattr(message, "trading_symbol", None),
                "close_price": getattr(message, "close_price", None),
                "volume": getattr(message, "volume_traded_today", None),
            }
        if now - self._last_tick_flush >= self._tick_flush_interval and self._pending_tick_rows:
            self.flush_tick_buffer()

    def flush_tick_buffer(self) -> int:
        """Flush queued latest ticks in one SQLite transaction."""
        rows=list(getattr(self, "_pending_tick_rows", {}).values())
        if not rows:
            return 0
        self._pending_tick_rows.clear()
        self._last_tick_flush=time.time()
        try:
            return _db.record_market_ticks(rows)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to flush %d queued ticks: %s", len(rows), exc)
            return 0

    # -------------------------------------------------------- order feed
    async def _run_order(self) -> None:
        feed = broker_client.create_order_feed()
        self._order = feed
        feed.on_message = self._on_order_message
        feed.on_error = lambda e: logger.warning("Order feed error: %s", e)
        feed.on_connect = lambda: self._schedule_reconcile("order feed connected")
        try:
            await feed.connect()
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    def _on_order_message(self, message) -> None:
        self._last_order_msg = time.time()
        mtype = getattr(message, "type", None)
        try:
            if mtype == "order":
                if getattr(message, "data", None) is None:
                    logger.warning("Ignoring order-feed message with no data payload")
                    return
                row = message.data.model_dump(by_alias=True)
                res = order_sync.apply_order_row(row, source="order_feed")
                if res["matched"] and res["changed"]:
                    self._schedule_reconcile("order update")   # picks up fills/positions via REST (authoritative)
            elif mtype == "position":
                self._schedule_reconcile("position update")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to process order-feed message: %s", exc)

    def _schedule_reconcile(self, reason: str) -> None:
        """Debounced: at most one pending reconciliation task."""
        if self._reconcile_task and not self._reconcile_task.done():
            return
        from . import reconciliation

        async def _go():
            await asyncio.sleep(1.5)
            try:
                await reconciliation.run_full_reconciliation()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconciliation (%s) failed: %s", reason, exc)

        try:
            self._reconcile_task = asyncio.get_running_loop().create_task(_go())
        except RuntimeError:
            pass


websocket_manager = WebSocketManager()
