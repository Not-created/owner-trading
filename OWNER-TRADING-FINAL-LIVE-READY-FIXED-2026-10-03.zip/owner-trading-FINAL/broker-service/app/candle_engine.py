from __future__ import annotations

import datetime as dt
import logging
from zoneinfo import ZoneInfo

from . import db

logger = logging.getLogger("owner_trading.candle")

IST = ZoneInfo("Asia/Kolkata")
TIMEFRAMES = {"1m": 1, "3m": 3, "5m": 5, "10m": 10, "15m": 15, "30m": 30, "1h": 60, "1d": 1440}


class CandleEngine:
    """Builds completed bars from SFeed ticks.

    SFeed volume is cumulative day volume, so persisted candle volume is the
    delta from the previous tick/day baseline, never the cumulative value.
    Strategy evaluation is emitted only when a bar is completed.
    """
    def __init__(self):
        self._state = {}
        self._last_cum_volume: dict[tuple[str, str], int] = {}
        self._last_persist: dict[tuple[str, str, str], float] = {}
        self._persist_interval_seconds = 5.0
        self._timeframe_cache: set[str] | None = None
        self._timeframe_cache_at = 0.0
        self._timeframe_cache_ttl = 5.0

    @staticmethod
    def _bucket(now: dt.datetime, minutes: int) -> dt.datetime:
        if minutes >= 1440:
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        # NSE cash intraday bars are anchored at the 09:15 IST session open.
        # Midnight-flooring misaligned 30m/1h bars to 09:00/10:00.
        session_start = 9 * 60 + 15
        total = now.hour * 60 + now.minute
        if total < session_start:
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        bucket_minute = session_start + ((total - session_start) // minutes) * minutes
        return now.replace(hour=bucket_minute // 60, minute=bucket_minute % 60, second=0, microsecond=0)

    def flush(self):
        """Persist all forming bars in one SQLite transaction."""
        rows=[]
        for key, st in list(self._state.items()):
            exchange_segment, instrument_token, timeframe = key
            rows.append({"exchange_segment":exchange_segment,"instrument_token":instrument_token,
                         "trading_symbol":st.get("trading_symbol") or str(instrument_token),"timeframe":timeframe,
                         "candle_at":st["at"].strftime("%Y-%m-%d %H:%M:%S"),"open":st["open"],
                         "high":st["high"],"low":st["low"],"close":st["close"],"volume":st["volume"]})
        db.upsert_candles(rows)

    def _required_timeframes(self) -> set[str]:
        """Return only timeframes actually needed by armed LIVE strategies/scanners.

        Building every timeframe for every subscribed instrument is unnecessarily
        expensive on the 1-OCPU production target. The result is cached briefly
        so a large tick stream does not repeatedly query the strategy tables.
        """
        now = dt.datetime.now(dt.timezone.utc).timestamp()
        if self._timeframe_cache is not None and now - self._timeframe_cache_at < self._timeframe_cache_ttl:
            return set(self._timeframe_cache)
        required: set[str] = set()
        try:
            for item in db.list_live_armed_strategy_versions():
                definition = item.get("definition") or {}
                tf = str(definition.get("timeframe") or "5m")
                if tf in TIMEFRAMES:
                    required.add(tf)
            for scanner in db.list_scanners():
                if scanner.get("is_active"):
                    definition = scanner.get("definition") or {}
                    tf = str(definition.get("timeframe") or "5m")
                    if tf in TIMEFRAMES:
                        required.add(tf)
        except Exception as exc:  # noqa: BLE001 -- feed processing must continue
            logger.warning("Could not determine required candle timeframes: %s", exc)
        self._timeframe_cache = required or {"5m"}
        self._timeframe_cache_at = now
        return set(self._timeframe_cache)

    def on_tick(self, *, exchange_segment, instrument_token, trading_symbol, price, volume=None, timestamp=None):
        now = timestamp.astimezone(IST) if timestamp else dt.datetime.now(IST)
        price = float(price)
        key_base = (exchange_segment or "", str(instrument_token))
        cumulative = int(volume or 0)
        completed = []
        completed_rows = []
        required_timeframes = self._required_timeframes()
        # Restore the cumulative-volume baseline before calculating this tick's
        # delta. Without this ordering, the first tick after a restart loses its
        # volume contribution because the persisted baseline is loaded too late.
        previous_cumulative = self._last_cum_volume.get(key_base)
        if previous_cumulative is None:
            try:
                for restore_tf in sorted(required_timeframes):
                    runtime = db.get_candle_runtime_state(exchange_segment, instrument_token, restore_tf)
                    if runtime and runtime.get("cumulative_volume") is not None:
                        previous_cumulative = int(runtime["cumulative_volume"])
                        break
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not restore cumulative volume baseline: %s", exc)
        if previous_cumulative is None or cumulative < previous_cumulative:
            delta_volume = 0 if previous_cumulative is None else cumulative
        else:
            delta_volume = cumulative - previous_cumulative
        self._last_cum_volume[key_base] = cumulative

        for tf, minutes in ((tf, TIMEFRAMES[tf]) for tf in required_timeframes):
            bucket = self._bucket(now, minutes)
            key = (*key_base, tf)
            st = self._state.get(key)
            if st is None:
                persisted = db.get_candle_runtime_state(exchange_segment, instrument_token, tf)
                if persisted and str(persisted.get("candle_at")) == bucket.strftime("%Y-%m-%d %H:%M:%S"):
                    st = {"at": bucket, "open": float(persisted["open"]), "high": float(persisted["high"]),
                          "low": float(persisted["low"]), "close": float(persisted["close"]),
                          "volume": int(persisted.get("volume") or 0), "trading_symbol": persisted.get("trading_symbol") or trading_symbol}
                    self._state[key] = st
                    if persisted.get("cumulative_volume") is not None:
                        self._last_cum_volume[key_base] = int(persisted["cumulative_volume"])
                if st is None:
                    persisted = db.get_candle(exchange_segment, instrument_token, tf, bucket.strftime("%Y-%m-%d %H:%M:%S"))
                    if persisted:
                        st = {"at": bucket, "open": float(persisted["open"]), "high": float(persisted["high"]),
                              "low": float(persisted["low"]), "close": float(persisted["close"]),
                              "volume": int(persisted.get("volume") or 0), "trading_symbol": persisted.get("trading_symbol") or trading_symbol}
                        self._state[key] = st
            if not st or st["at"] != bucket:
                if st:
                    completed_rows.append({"exchange_segment":exchange_segment,"instrument_token":instrument_token,
                                           "trading_symbol":trading_symbol,"timeframe":tf,
                                           "candle_at":st["at"].strftime("%Y-%m-%d %H:%M:%S"),"open":st["open"],
                                           "high":st["high"],"low":st["low"],"close":st["close"],"volume":st["volume"]})
                    db.delete_candle_runtime_state(exchange_segment, instrument_token, tf)
                    completed.append(tf)
                st = {"at": bucket, "open": price, "high": price, "low": price,
                      "close": price, "volume": int(delta_volume), "trading_symbol": trading_symbol}
                self._state[key] = st
                db.upsert_candle_runtime_state(exchange_segment=exchange_segment, instrument_token=instrument_token, timeframe=tf,
                                               candle_at=st["at"].strftime("%Y-%m-%d %H:%M:%S"), open_=st["open"], high=st["high"],
                                               low=st["low"], close=st["close"], volume=st["volume"],
                                               trading_symbol=trading_symbol, cumulative_volume=cumulative)
            else:
                st["high"] = max(st["high"], price)
                st["low"] = min(st["low"], price)
                st["close"] = price
                st["volume"] += int(delta_volume)
                st["trading_symbol"] = trading_symbol or st.get("trading_symbol")

            now_ts = dt.datetime.now(dt.timezone.utc).timestamp()
            if now_ts - self._last_persist.get(key, 0.0) >= self._persist_interval_seconds:
                db.upsert_candle_runtime_state(exchange_segment=exchange_segment, instrument_token=instrument_token, timeframe=tf,
                                               candle_at=st["at"].strftime("%Y-%m-%d %H:%M:%S"), open_=st["open"], high=st["high"],
                                               low=st["low"], close=st["close"], volume=st["volume"],
                                               trading_symbol=st.get("trading_symbol"), cumulative_volume=cumulative)
                self._last_persist[key] = now_ts

        if completed_rows:
            db.upsert_candles(completed_rows)

        # Automated strategy evaluation is emitted only for completed bars.
        # Protective exits are separate and receive the raw tick path from the
        # WebSocket supervisor, so a stop/target never waits for a 5m close.
        if completed:
            try:
                import asyncio
                from .algo_engine import algo_engine
                loop = asyncio.get_running_loop()
                for tf in completed:
                    loop.create_task(algo_engine.on_tick(
                        exchange_segment=exchange_segment,
                        instrument_token=str(instrument_token),
                        trading_symbol=trading_symbol,
                        timeframe=tf,
                    ))
            except RuntimeError:
                pass


candle_engine = CandleEngine()
