
import asyncio
from types import SimpleNamespace

from app import strategy_engine
from app.exit_engine import derive_levels


def test_atr_stop_is_derived_for_live_position():
    definition = {"risk": {"stop_atr_multiple": 2}}
    assert derive_levels(definition, 100.0, "BUY", atr_value=3.0) == (94.0, None)
    assert derive_levels(definition, 100.0, "SELL", atr_value=3.0) == (106.0, None)


def test_atr_stop_does_not_invent_level_without_atr():
    definition = {"risk": {"stop_atr_multiple": 2}}
    assert derive_levels(definition, 100.0, "BUY", atr_value=None) == (None, None)


def test_scanner_ids_are_optional_but_validated_when_present():
    base = {
        "timeframe": "5m",
        "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "universe": {"instrument_tokens": ["1"]},
        "risk": {"stop_loss_pct": 1},
        "position_sizing": {"quantity": 1},
    }
    assert not any("scanner_ids" in e for e in strategy_engine.validate_strategy(base))
    invalid = dict(base, scanner_ids=["bad"])
    assert any("scanner_ids" in e for e in strategy_engine.validate_strategy(invalid))


def test_timeframe_support_includes_10m():
    assert "10m" in strategy_engine.TIMEFRAMES


def test_risk_per_trade_percentage_uses_actual_stop_distance():
    from app.strategy_engine import size_position
    definition={
        "side":"BUY",
        "position_sizing":{"risk_per_trade":1000},
        "risk":{"stop_loss_pct":1},
    }
    assert size_position(definition,100,lot_size=1)==1000


def test_bound_scanner_ignores_unrelated_active_scanner():
    from app.algo_engine import evaluate_bound_scanners
    candles=[{"open":100,"high":101,"low":99,"close":100,"volume":1000,"candle_at":"2026-10-03 10:00:00"}] * 20
    base={"timeframe":"5m","side":"BUY","entry":{"op":"AND","conditions":[{"left":"close","operator":">","right":"99"}]},"exit":{"op":"OR","conditions":[{"left":"close","operator":"<","right":"200"}]}}
    strategy=dict(base,scanner_ids=[2])
    scanners=[
      {"id":1,"is_active":True,"definition":dict(base,entry={"op":"AND","conditions":[{"left":"close","operator":">","right":"1000"}]})},
      {"id":2,"is_active":True,"definition":base},
    ]
    assert evaluate_bound_scanners(strategy,candles,scanners)==[2]


def test_bound_scanner_requires_selected_scanner_to_pass():
    from app.algo_engine import evaluate_bound_scanners
    candles=[{"open":100,"high":101,"low":99,"close":100,"volume":1000,"candle_at":"2026-10-03 10:00:00"}] * 20
    base={"timeframe":"5m","side":"BUY","entry":{"op":"AND","conditions":[{"left":"close","operator":">","right":"99"}]},"exit":{"op":"OR","conditions":[{"left":"close","operator":"<","right":"200"}]}}
    strategy=dict(base,scanner_ids=[2])
    scanners=[{"id":2,"is_active":True,"definition":dict(base,entry={"op":"AND","conditions":[{"left":"close","operator":">","right":"1000"}]})}]
    assert evaluate_bound_scanners(strategy,candles,scanners)==[]
