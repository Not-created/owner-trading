# Owner Trading — Final Fix 16 Release

## Scope
This release addresses the requested production/LIVE-trading hardening set without changing the Dark/Light theme or the vendored official Kotak Neo SDK source.

1. Reconciliation blocker hardening — historical terminal orders no longer create false `order_missing_at_broker` discrepancies; only genuinely unresolved/live local orders can block clean reconciliation. Empty 424 positions/holdings remain treated as empty snapshots.
2. Scanner binding — a strategy only evaluates scanners explicitly listed in `scanner_ids`; unrelated active scanners cannot block the strategy. Multiple bound scanners are AND filters.
3. Risk-per-trade sizing — `risk_per_trade` now uses the actual entry-to-stop price distance. Percentage stops are converted to a real stop price before quantity calculation.
4. Exit state machine + crash recovery — durable `REQUESTED → SUBMITTING → SUBMITTED/PARTIALLY_FILLED/COMPLETE/FAILED/UNKNOWN` handling, explicit exit/order linkage, and startup recovery without blind resubmission.
5. Manual order token validation — LIVE orders require an instrument token present in the synced scrip master and require the token's authoritative trading symbol to match the submitted symbol before any broker call.
6. Strategy Builder sizing UI — fixed quantity / capital % / risk ₹ per trade are now mutually exclusive UI modes.
7. Strict numeric schema — finite numeric parsing and exact integer validation were strengthened across strategy and order fields.
8. Candle/tick SQLite batching — completed candles and latest market ticks are persisted in batched SQLite transactions; the raw tick/candle execution path remains live and unthrottled for protective exits/candle construction.
9. Regression tests — updated/added tests cover sizing, scanner binding, exit recovery, manual token requirements, tick batching, and deployment architecture.
10. Release directories — deployment stages releases under `/opt/owner-trading/releases/<UTC timestamp>`.
11. Atomic current release — `/opt/owner-trading/current` is switched atomically only after staging/build/test work.
12. Persistent shared data — SQLite, password hash, encrypted broker state/cache remain outside release directories under `/var/lib/owner-trading`.
13. Rollback — deployment retains the previous release and automatically attempts rollback if service startup/health verification fails; `deployment/rollback.sh` provides manual rollback.
14. package-lock — bootstrap lockfiles are included; first VPS deployment resolves the full dependency graph and persists it, then uses `npm ci` from the resolved lockfile on later deployments.
15. Clean ZIP — generated Python caches/test caches are excluded from the final archive.
16. Deployment verification — release symlink, shared database/state, systemd hardening, local health, broker token protection, backend health, and Nginx 502/HTTPS checks are included.

## Verification performed before packaging
- Python compile check: PASS
- Broker-service pytest: **305 passed, 3 skipped**
- Targeted order/scanner/exit/websocket/deployment regression suites: PASS
- Vendored Kotak SDK files were not modified by this fix set.
- Dark/Light theme files were not modified by this fix set.

## Important deployment behavior
The new deployment is staged while the current release continues serving. A short controlled stop is still required for the additive SQLite migration and atomic cutover; this is not a destructive source-tree replacement. The previous release is retained for rollback.

The release does not connect to Kotak or arm LIVE execution during deployment.
