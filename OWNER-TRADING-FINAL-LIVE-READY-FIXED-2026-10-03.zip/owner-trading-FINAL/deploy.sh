#!/usr/bin/env bash
# Owner Trading -- one-command deployment (Ubuntu VPS, run as root for systemd/nginx/HTTPS).
#
#   sudo ./deploy.sh                                   # LIVE-only infrastructure deployment
#   sudo DOMAIN=trade.example.com CERTBOT_EMAIL=you@example.com ./deploy.sh   # + nginx + Let's Encrypt HTTPS
#
# What it guarantees before it reports success:
#   * the vendored official Kotak Neo SDK (v3.0.7) is byte-identical to its manifest,
#   * it installs, imports, is exactly 3.0.7, and every method signature the adapter uses matches,
#   * migrations applied, frontend built, both services healthy, internal token enforced.
# It never touches Kotak credentials and never arms LIVE execution.
set -euo pipefail

# One-click entrypoint: if launched as the normal Ubuntu user, re-exec with sudo so
# systemd/nginx/HTTPS can be configured instead of silently falling back to a
# non-persistent HTTP process. No credentials are handled here.
if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || { echo "ERROR: deploy.sh must run as root or with passwordless sudo." >&2; exit 1; }
  exec sudo -E bash "$0" "$@"
fi

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNTIME_ROOT="${RUNTIME_ROOT:-/opt/owner-trading}"
RELEASES_DIR="$RUNTIME_ROOT/releases"
CURRENT_LINK="$RUNTIME_ROOT/current"
SHARED_ROOT="${SHARED_ROOT:-/var/lib/owner-trading}"
SHARED_DATA="$SHARED_ROOT/data"
SHARED_SECURE="$SHARED_ROOT/secure"
ROOT_DIR="$SOURCE_ROOT"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
BROKER_DIR="$ROOT_DIR/broker-service"
DEPLOYMENT_DIR="$ROOT_DIR/deployment"
ENV_FILE="/etc/owner-trading/backend.env"
PASSWORD_HASH_FILE="$SHARED_SECURE/password.hash.json"
DB_PATH="$SHARED_DATA/owner-trading.db"
PREVIOUS_RELEASE=""
NEW_RELEASE=""
SERVICES_QUIESCED=0
CUTOVER_DONE=0
DEPLOY_SUCCESS=0
BROKER_ENV_SYSTEM_PATH="/etc/owner-trading/broker.env"
PORT="${PORT:-4000}"
BROKER_PORT="${BROKER_SERVICE_PORT:-8800}"
DOMAIN="${DOMAIN:-}"
CERTBOT_EMAIL="${CERTBOT_EMAIL:-}"
REQUIRED_SDK_VERSION="3.0.7"
IS_ROOT=""; [ "$(id -u)" -eq 0 ] && IS_ROOT=1
USE_SYSTEMD=""
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] && [ -n "$IS_ROOT" ]; then USE_SYSTEMD=1; fi

info()  { printf '\n\033[1;36m==>\033[0m %s\n' "$1"; }
ok()    { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
warn()  { printf '  \033[1;33m! %s\033[0m\n' "$1"; }
fail()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

set_kv() { # file key value  (idempotent .env editing)
  if grep -q "^$2=" "$1" 2>/dev/null; then sed -i "s#^$2=.*#$2=$3#" "$1"; else echo "$2=$3" >> "$1"; fi
}
get_kv() { grep -E "^$2=" "$1" 2>/dev/null | tail -n1 | cut -d= -f2- || true; }

echo "=============================================="
echo "   OWNER TRADING -- Deployment"
echo "=============================================="

# ------------------------------------------------------------------ environment
# Phase 1 safety: never run a schema-changing deploy against a live database
# without a point-in-time backup. The backup is retained outside the source
# tree so rsync --delete can never remove it.
BACKUP_DIR="${BACKUP_DIR:-/var/backups/owner-trading}"
mkdir -p "$BACKUP_DIR" 2>/dev/null || true

info "Checking environment"
[ -f /etc/os-release ] && grep -qi ubuntu /etc/os-release && ok "Ubuntu: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')" \
  || warn "Not Ubuntu -- this script is written for Ubuntu production hosts."
if ! command -v node >/dev/null 2>&1 || ! node -e "require('node:sqlite')" >/dev/null 2>&1; then
  if [ -n "$IS_ROOT" ] && command -v apt-get >/dev/null 2>&1; then
    info "Installing/upgrading system Node.js 22 (node:sqlite required)"
    command -v curl >/dev/null 2>&1 || apt-get install -y -qq curl >/dev/null 2>&1 || fail "curl is required to install supported Node.js 22."
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/tmp/ot-node-setup.log 2>&1 || { tail -n 30 /tmp/ot-node-setup.log; fail "NodeSource setup failed."; }
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nodejs >/dev/null 2>&1 || fail "Node.js 22 installation failed."
  fi
fi
command -v node >/dev/null 2>&1 || fail "Node.js 22.5+ is required."
NODE_BIN="$(command -v node)"
NODE_VERSION="$(node -p 'process.versions.node')"
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
NODE_MINOR="$(node -p 'Number(process.versions.node.split(".")[1])')"
if [ "$NODE_MAJOR" -lt 22 ] || { [ "$NODE_MAJOR" -eq 22 ] && [ "$NODE_MINOR" -lt 5 ]; }; then fail "Node.js $NODE_VERSION is too old; Node 22.5+ is required."; fi
ok "Node.js $NODE_VERSION ($NODE_BIN)"
command -v npm >/dev/null 2>&1 || fail "npm is required."
node -e "require('node:sqlite')" >/dev/null 2>&1 || fail "node:sqlite unavailable: Node 22.5+ is required (found $(node --version))."
ok "node:sqlite available"
if [ -n "$IS_ROOT" ]; then
  case "$NODE_BIN" in /home/*|/root/*) fail "Node at $NODE_BIN is inside a home directory, which the hardened systemd unit cannot read. Install system-wide Node 22 (NodeSource) and re-run.";; esac
fi

PYTHON_BIN=""
for c in python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1; then
    v="$("$c" -c 'import sys; print(sys.version_info[0]*100+sys.version_info[1])')"
    if [ "$v" -ge 310 ]; then PYTHON_BIN="$c"; break; fi
  fi
done

# One-click deployment must not require a manual Python installation. On a
# supported Ubuntu host, install the distro Python + venv package when no
# Python >=3.10 interpreter is already available, then detect it again.
if [ -z "$PYTHON_BIN" ] && command -v apt-get >/dev/null 2>&1 && [ -n "$IS_ROOT" ]; then
  info "Python >= 3.10 not found; installing Ubuntu Python and venv support"
  DEBIAN_FRONTEND=noninteractive apt-get update -y -qq || fail "apt-get update failed while preparing Python."
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 python3-venv || fail "Automatic Python installation failed."
  for c in python3.12 python3.11 python3.10 python3; do
    if command -v "$c" >/dev/null 2>&1; then
      v="$("$c" -c 'import sys; print(sys.version_info[0]*100+sys.version_info[1])')"
      if [ "$v" -ge 310 ]; then PYTHON_BIN="$c"; break; fi
    fi
  done
fi
[ -n "$PYTHON_BIN" ] || fail "Python >= 3.10 is required and could not be installed automatically."
ok "Python: $("$PYTHON_BIN" --version) ($PYTHON_BIN)"

# ------------------------------------------------------------------ staged release + persistent shared state
# Keep production services outside /home; /opt/current is the only executable release root.
# Stage the complete release while the currently running release remains online.
# Only the short cutover/migration window stops services. The previous release is
# never deleted until the new release passes all local health checks.
if [ -n "$IS_ROOT" ] && [ "$SOURCE_ROOT" != "$RUNTIME_ROOT" ]; then
  info "Preparing staged production release (zero-destructive deployment)"
  mkdir -p "$RELEASES_DIR" "$SHARED_DATA" "$SHARED_SECURE" "$SHARED_ROOT/scrip_cache"
  if ! command -v rsync >/dev/null 2>&1; then
    DEBIAN_FRONTEND=noninteractive apt-get update -y -qq >/dev/null 2>&1 || true
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rsync >/dev/null 2>&1 || fail "rsync is required for staged release deployment."
  fi
  TS="$(date -u +%Y%m%dT%H%M%SZ)"
  NEW_RELEASE="$RELEASES_DIR/$TS"
  while [ -e "$NEW_RELEASE" ]; do sleep 1; TS="$(date -u +%Y%m%dT%H%M%SZ)"; NEW_RELEASE="$RELEASES_DIR/$TS"; done
  mkdir -p "$NEW_RELEASE"
  rsync -a --delete \
    --exclude '.git/' --exclude '.venv/' --exclude 'venv/' --exclude 'node_modules/' --exclude 'frontend/dist/' \
    --exclude 'backend/.env' --exclude 'backend/data/' --exclude 'backend/src/data/secure/' \
    --exclude 'broker-service/data/' \
    "$SOURCE_ROOT/" "$NEW_RELEASE/"
  if [ -L "$CURRENT_LINK" ]; then
    PREVIOUS_RELEASE="$(readlink -f "$CURRENT_LINK")"
  elif [ -d "$RUNTIME_ROOT/backend" ]; then
    PREVIOUS_RELEASE="$RUNTIME_ROOT"
  fi
  # First migration to shared state: preserve the existing production DB/password
  # exactly once. Never overwrite a populated shared state.
  if [ ! -f "$DB_PATH" ] && [ -n "$PREVIOUS_RELEASE" ] && [ -f "$PREVIOUS_RELEASE/backend/data/owner-trading.db" ]; then
    cp -a "$PREVIOUS_RELEASE/backend/data/owner-trading.db" "$DB_PATH"
    ok "Migrated existing SQLite DB into persistent shared state"
  fi
  if [ ! -f "$PASSWORD_HASH_FILE" ] && [ -n "$PREVIOUS_RELEASE" ] && [ -f "$PREVIOUS_RELEASE/backend/src/data/secure/password.hash.json" ]; then
    cp -a "$PREVIOUS_RELEASE/backend/src/data/secure/password.hash.json" "$PASSWORD_HASH_FILE"
    ok "Migrated existing website password hash into persistent shared state"
  fi
  ROOT_DIR="$NEW_RELEASE"
  BACKEND_DIR="$ROOT_DIR/backend"
  FRONTEND_DIR="$ROOT_DIR/frontend"
  BROKER_DIR="$ROOT_DIR/broker-service"
  DEPLOYMENT_DIR="$ROOT_DIR/deployment"
  ok "Release staged at $NEW_RELEASE"
  if [ -n "$PREVIOUS_RELEASE" ]; then ok "Previous release retained at $PREVIOUS_RELEASE"; fi
fi
info "OS packages"
if command -v apt-get >/dev/null 2>&1 && [ -n "$IS_ROOT" ]; then
  PKGS="${PYTHON_BIN}-venv build-essential curl nginx"
  [ -n "$DOMAIN" ] && PKGS="$PKGS certbot"
  DEBIAN_FRONTEND=noninteractive apt-get update -y -qq || fail "apt-get update failed; required deployment packages cannot be verified."
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq $PKGS >/dev/null 2>&1 && ok "Installed/verified: $PKGS" \
    || fail "Could not install required OS packages ($PKGS)."
else
  warn "Not root or no apt-get -- skipping OS package installation."
fi

# ------------------------------------------------------------------ vendored SDK checks (stdlib only, before any install)
info "Vendored official Kotak Neo SDK ${REQUIRED_SDK_VERSION}: integrity and signature check"
PRE="$(cd "$BROKER_DIR" && "$PYTHON_BIN" - <<'PY' 2>&1
import sys
from app import sdk_conformance as c
vi = c.check_vendor_integrity()
st = c.check_static()
print(f"vendor files verified: {vi.checked}; adapter signatures checked: {st.checked}")
errs = vi.errors + st.errors
for e in errs: print("ERROR:", e)
sys.exit(1 if errs else 0)
PY
)" && ok "$PRE" || fail "Vendored SDK check failed:
$PRE
The files under broker-service/vendor/kotakneoapi must be exactly the official 3.0.7 source."

# ------------------------------------------------------------------ venv + pip
info "Python virtual environment"
if [ -x "$BROKER_DIR/venv/bin/python" ] && "$BROKER_DIR/venv/bin/python" -c 'import sys' >/dev/null 2>&1; then
  ok "broker-service/venv is usable"
else
  [ -d "$BROKER_DIR/venv" ] && { warn "venv is broken -- recreating."; rm -rf "$BROKER_DIR/venv"; }
  "$PYTHON_BIN" -m venv "$BROKER_DIR/venv" || fail "Could not create venv (install ${PYTHON_BIN}-venv)."
  ok "Created broker-service/venv"
fi
VENV_PY="$BROKER_DIR/venv/bin/python"; VENV_PIP="$BROKER_DIR/venv/bin/pip"

info "Network access to PyPI (needed for the SDK's own dependencies: httpx, pydantic, websockets, ...)"
if command -v curl >/dev/null 2>&1 && ! curl -fsS --max-time 10 -o /dev/null "https://pypi.org/simple/"; then
  fail "Cannot reach https://pypi.org (DNS/egress/proxy). Fix network access (export HTTPS_PROXY if needed) and re-run."
fi
ok "PyPI reachable"

info "Removing conflicting or outdated Kotak SDK installs"
for legacy in neo-api-client kotak-neo-api; do
  if "$VENV_PIP" show "$legacy" >/dev/null 2>&1; then "$VENV_PIP" uninstall -y "$legacy" --quiet && warn "removed legacy package $legacy"; fi
done
CUR=""
if "$VENV_PIP" show kotakneoapi >/dev/null 2>&1; then
  CUR="$("$VENV_PIP" show kotakneoapi | awk -F': ' '/^Version:/ {print $2}')"
fi
if [ -n "$CUR" ] && [ "$CUR" != "$REQUIRED_SDK_VERSION" ]; then
  "$VENV_PIP" uninstall -y kotakneoapi --quiet && warn "removed kotakneoapi $CUR (need $REQUIRED_SDK_VERSION)"
fi
ok "SDK install state clean"

info "Installing the vendored SDK and broker-service dependencies"
"$VENV_PIP" install --upgrade pip --quiet || warn "pip self-upgrade failed; continuing."
PIP_LOG="$(mktemp)"; PIP_OK=""
for attempt in 1 2 3; do
  if (cd "$BROKER_DIR" && "$VENV_PIP" install -r requirements.txt) > "$PIP_LOG" 2>&1; then PIP_OK=1; break; fi
  [ "$attempt" -lt 3 ] && { warn "pip attempt $attempt/3 failed; retrying in $((attempt*3))s"; sleep $((attempt*3)); }
done
if [ -z "$PIP_OK" ]; then tail -n 25 "$PIP_LOG" | sed 's/^/  /'; fail "pip install failed (output above). Deployment cannot continue without the SDK."; fi
rm -f "$PIP_LOG"; ok "pip install succeeded"

info "Verifying Python dependency closure"
PIP_CHECK_OUT="$("$VENV_PIP" check 2>&1)" || { echo "$PIP_CHECK_OUT" | sed 's/^/  /'; fail "Python dependency check failed. Deployment cannot continue with a partial broker environment."; }
ok "pip dependency check passed"
RUNTIME_IMPORTS="$("$VENV_PY" - <<'PY'
mods = [
    "neo_api_client",
    "cryptography.fernet",
    "pyotp",
    "httpx",
    "pydantic",
    "websockets",
]
for name in mods:
    __import__(name)
print("runtime imports: " + ", ".join(mods))
PY
)" || fail "Required Python/Kotak runtime imports failed. No manual package installation is required; fix the dependency declaration and re-run deploy.sh."
ok "$RUNTIME_IMPORTS"

info "Verifying the INSTALLED SDK"
INSTALLED="$("$VENV_PIP" show kotakneoapi 2>/dev/null | awk -F': ' '/^Version:/ {print $2}')"
[ "$INSTALLED" = "$REQUIRED_SDK_VERSION" ] || fail "Installed kotakneoapi is '${INSTALLED:-none}', expected $REQUIRED_SDK_VERSION."
ok "kotakneoapi $INSTALLED"
IMPORT_OUT="$(cd "$BROKER_DIR" && "$VENV_PY" -c 'import neo_api_client; from neo_api_client import NeoAPI; print(neo_api_client.__version__)' 2>&1)" \
  || fail "SDK import failed: $IMPORT_OUT"
[ "$IMPORT_OUT" = "$REQUIRED_SDK_VERSION" ] || fail "neo_api_client.__version__ is '$IMPORT_OUT', expected $REQUIRED_SDK_VERSION."
ok "import neo_api_client -> $IMPORT_OUT"
CONF="$(cd "$BROKER_DIR" && "$VENV_PY" -c '
import sys
from app.sdk_conformance import check_runtime
r = check_runtime(); print(r.summary()); sys.exit(0 if r.ok else 1)' 2>&1)" \
  && ok "$CONF" || fail "Runtime signature check failed: $CONF"
info "Installing validation-only Python test dependency"
(cd "$BROKER_DIR" && "$VENV_PIP" install --disable-pip-version-check --no-cache-dir -r test-requirements.txt) \
  || fail "Broker-service validation dependency installation failed."

info "Running the COMPLETE broker-service pytest suite inside the production venv"
(cd "$BROKER_DIR" && DB_PATH="$(mktemp -d)/test.db" NEO_LOG_FILE_ENABLED=false "$VENV_PY" -m pytest -q) \
  || fail "Broker-service pytest suite failed on this host."

# ------------------------------------------------------------------ node
info "Backend and frontend dependencies"
# The release carries bootstrap lockfiles. On the first deployment, resolve the
# full dependency graph on the VPS and persist it; subsequent releases use npm ci
# against the committed lockfile without silently changing dependency versions.
for APP_DIR in "$BACKEND_DIR" "$FRONTEND_DIR"; do
  if [ ! -f "$APP_DIR/package-lock.json" ]; then
    (cd "$APP_DIR" && npm install --package-lock-only --ignore-scripts --no-audit --no-fund) || fail "Could not create package-lock.json in $APP_DIR."
  elif ! grep -q '"node_modules/' "$APP_DIR/package-lock.json"; then
    (cd "$APP_DIR" && npm install --package-lock-only --ignore-scripts --no-audit --no-fund) || fail "Could not resolve the bootstrap package-lock.json in $APP_DIR."
  fi
  (cd "$APP_DIR" && npm ci --no-audit --no-fund) || fail "npm ci failed in $APP_DIR."
done
ok "npm dependencies installed from lockfiles"
info "Backend tests"
(cd "$BACKEND_DIR" && npm test --silent >/tmp/ot-node-tests.$$ 2>&1) && ok "backend tests passed" || { tail -n 30 /tmp/ot-node-tests.$$; rm -f /tmp/ot-node-tests.$$; fail "Backend tests failed."; }
rm -f /tmp/ot-node-tests.$$

recover_previous_on_abort() {
  [ "$DEPLOY_SUCCESS" = "1" ] && return 0
  [ "$SERVICES_QUIESCED" = "1" ] || return 0
  warn "Deployment aborted; restoring service availability."
  if [ "$CUTOVER_DONE" = "1" ] && [ -n "$PREVIOUS_RELEASE" ] && [ -d "$PREVIOUS_RELEASE" ]; then
    ln -sfn "$PREVIOUS_RELEASE" "$CURRENT_LINK" 2>/dev/null || true
  fi
  systemctl daemon-reload 2>/dev/null || true
  systemctl start owner-trading-broker owner-trading-backend 2>/dev/null || true
}
trap recover_previous_on_abort EXIT

info "Database + controlled release cutover"
if [ -n "$USE_SYSTEMD" ]; then
  # Staging/tests/builds have already happened while the previous release was
  # serving traffic. Stop only for the additive SQLite migration and atomic
  # symlink switch.
  systemctl stop owner-trading-broker owner-trading-backend 2>/dev/null || true
  SERVICES_QUIESCED=1
  ok "Services quiesced for the short migration/cutover window"
fi
mkdir -p "$SHARED_DATA" "$SHARED_SECURE" "$BROKER_DIR/data"
# Take a consistent SQLite backup before any migration. Existing production
# credentials/database are preserved; only the backup copy is created here.
if [ -f "$DB_PATH" ]; then
  info "SQLite pre-deploy backup + integrity check"
  TS="$(date -u +%Y%m%dT%H%M%SZ)"
  BACKUP_PATH="$BACKUP_DIR/owner-trading-$TS.db"
  DB_PATH="$DB_PATH" BACKUP_PATH="$BACKUP_PATH" node - <<'NODE' || fail "SQLite backup/integrity check failed."
const { DatabaseSync } = require("node:sqlite");
const fs = require("fs");
const dbPath = process.env.DB_PATH;
const backupPath = process.env.BACKUP_PATH;
const db = new DatabaseSync(dbPath);
const check = db.prepare("PRAGMA integrity_check").get();
const value = String(check[Object.keys(check)[0]] || "");
if (value !== "ok") throw new Error(`integrity_check=${value}`);
fs.mkdirSync(require("path").dirname(backupPath), {recursive:true});
const escaped = backupPath.replace(/'/g, "''");
db.exec(`VACUUM INTO '${escaped}'`);
const stat = fs.statSync(backupPath);
if (!stat.size) throw new Error("backup file is empty");
console.log(`backup=${backupPath} bytes=${stat.size}`);
NODE
  chmod 600 "$BACKUP_PATH"
  # Keep the newest 10 database backups.
  ls -1t "$BACKUP_DIR"/owner-trading-*.db 2>/dev/null | tail -n +11 | xargs -r rm -f
  ok "SQLite backup created: $BACKUP_PATH"
fi

DB_PATH="$DB_PATH" PASSWORD_HASH_FILE="$PASSWORD_HASH_FILE" FRONTEND_DIST_PATH="$CURRENT_LINK/frontend/dist" node "$BACKEND_DIR/src/db/migrate.js" || fail "Database migration failed."
ok "Migrations applied"

# ------------------------------------------------------------------ configuration
info "Configuration (secrets are generated once and preserved)"
gen() { node -e "console.log(require('crypto').randomBytes(${1:-32}).toString('hex'))"; }
mkdir -p "$(dirname "$ENV_FILE")"
if [ ! -f "$ENV_FILE" ]; then
  { echo "NODE_ENV=production"; echo "PORT=${PORT}"; echo "DB_PATH=${DB_PATH}"; echo "PASSWORD_HASH_FILE=${PASSWORD_HASH_FILE}"; echo "FRONTEND_DIST_PATH=${CURRENT_LINK}/frontend/dist"; echo "BROKER_SERVICE_URL=http://127.0.0.1:${BROKER_PORT}"; echo "# LIVE-only execution"; } > "$ENV_FILE"
fi
set_kv "$ENV_FILE" DB_PATH "$DB_PATH"
set_kv "$ENV_FILE" PASSWORD_HASH_FILE "$PASSWORD_HASH_FILE"
set_kv "$ENV_FILE" FRONTEND_DIST_PATH "$CURRENT_LINK/frontend/dist"
[ -n "$(get_kv "$ENV_FILE" SESSION_SECRET)" ] || set_kv "$ENV_FILE" SESSION_SECRET "$(gen 48)"
[ -n "$(get_kv "$ENV_FILE" BROKER_SERVICE_TOKEN)" ] || set_kv "$ENV_FILE" BROKER_SERVICE_TOKEN "$(gen 32)"
CURRENT_KOTAK_KEY="$(get_kv "$ENV_FILE" KOTAK_CREDENTIAL_ENCRYPTION_KEY)"
if [ -z "$CURRENT_KOTAK_KEY" ]; then
  # Fernet requires a 32-byte URL-safe Base64 key with canonical padding.
  set_kv "$ENV_FILE" KOTAK_CREDENTIAL_ENCRYPTION_KEY "$(node -e 'const c=require("crypto"); const s=c.randomBytes(32).toString("base64url"); console.log(s+"=".repeat((4-s.length%4)%4))')"
elif ! "$VENV_PY" - "$CURRENT_KOTAK_KEY" <<'PY' >/dev/null 2>&1
import sys
from cryptography.fernet import Fernet
Fernet(sys.argv[1].encode())
PY
then
  # Never rotate an invalid key when an encrypted credential store already exists.
  # A silent rotation would make existing credentials permanently undecryptable.
  if [ -f "/var/lib/owner-trading/kotak-credentials.enc" ]; then
    fail "Existing KOTAK_CREDENTIAL_ENCRYPTION_KEY is invalid and an encrypted Kotak credential store exists; refusing automatic key rotation."
  fi
  set_kv "$ENV_FILE" KOTAK_CREDENTIAL_ENCRYPTION_KEY "$(node -e 'const c=require("crypto"); const s=c.randomBytes(32).toString("base64url"); console.log(s+"=".repeat((4-s.length%4)%4))')"
fi
[ -n "$(get_kv "$ENV_FILE" KOTAK_CREDENTIAL_STORE)" ] || set_kv "$ENV_FILE" KOTAK_CREDENTIAL_STORE "/var/lib/owner-trading/kotak-credentials.enc"
# auto = Secure cookie on HTTPS requests, plain cookie on HTTP (see backend/src/config/sessionCookie.js)
[ -n "$(get_kv "$ENV_FILE" SESSION_COOKIE_SECURE)" ] || set_kv "$ENV_FILE" SESSION_COOKIE_SECURE true
chmod 600 "$ENV_FILE"; ok "backend/.env ready"
COOKIE_POLICY="$(get_kv "$ENV_FILE" SESSION_COOKIE_SECURE | tr 'A-Z' 'a-z')"; COOKIE_POLICY="${COOKIE_POLICY:-auto}"
# Remove any legacy execution-mode variable; the application is permanently LIVE-only.
sed -i '/^TRADING_MODE=/d' "$ENV_FILE" 2>/dev/null || true
if [ -f "$BROKER_ENV_SYSTEM_PATH" ]; then sed -i '/^TRADING_MODE=/d' "$BROKER_ENV_SYSTEM_PATH"; fi
TOKEN="$(get_kv "$ENV_FILE" BROKER_SERVICE_TOKEN)"; MODE="LIVE"

if [ -n "$IS_ROOT" ]; then
  mkdir -p "$(dirname "$BROKER_ENV_SYSTEM_PATH")"
  chown owner-trading:owner-trading "$(dirname "$BROKER_ENV_SYSTEM_PATH")" 2>/dev/null || true
  chmod 700 "$(dirname "$BROKER_ENV_SYSTEM_PATH")"
  if [ ! -f "$BROKER_ENV_SYSTEM_PATH" ]; then
    if [ -f "$BROKER_DIR/.env.example" ]; then
      sed "s#/opt/owner-trading#${ROOT_DIR}#g" "$BROKER_DIR/.env.example" > "$BROKER_ENV_SYSTEM_PATH"
    else
      { echo "BROKER_SERVICE_PORT=${BROKER_PORT}"; echo "BROKER_SERVICE_TOKEN=${TOKEN}"; echo "DB_PATH=${DB_PATH}"; echo "TRADING_MODE=LIVE"; echo "KOTAK_CREDENTIAL_ENCRYPTION_KEY=$(get_kv "$ENV_FILE" KOTAK_CREDENTIAL_ENCRYPTION_KEY)"; echo "KOTAK_CREDENTIAL_STORE=/var/lib/owner-trading/kotak-credentials.enc"; } > "$BROKER_ENV_SYSTEM_PATH"
    fi
    ok "Created $BROKER_ENV_SYSTEM_PATH"
  fi
  set_kv "$BROKER_ENV_SYSTEM_PATH" BROKER_SERVICE_PORT "$BROKER_PORT"
  set_kv "$BROKER_ENV_SYSTEM_PATH" BROKER_SERVICE_TOKEN "$TOKEN"   # always identical to backend/.env
  set_kv "$BROKER_ENV_SYSTEM_PATH" DB_PATH "$DB_PATH"
  set_kv "$BROKER_ENV_SYSTEM_PATH" KOTAK_CREDENTIAL_ENCRYPTION_KEY "$(get_kv "$ENV_FILE" KOTAK_CREDENTIAL_ENCRYPTION_KEY)"
  set_kv "$BROKER_ENV_SYSTEM_PATH" KOTAK_CREDENTIAL_STORE "/var/lib/owner-trading/kotak-credentials.enc"
  set_kv "$BROKER_ENV_SYSTEM_PATH" NEO_SCRIP_CACHE_DIR "/var/lib/owner-trading/scrip_cache"
  chmod 600 "$BROKER_ENV_SYSTEM_PATH"; ok "broker.env synchronised (token + DB path)"
fi

info "Building frontend"
(cd "$FRONTEND_DIR" && npm run build) || fail "Frontend build failed."
[ -f "$FRONTEND_DIR/dist/index.html" ] || fail "Frontend build produced no dist/index.html."
ok "frontend/dist built"

# ------------------------------------------------------------------ password
info "Website access password"
NEW_PW=""
if [ -f "$PASSWORD_HASH_FILE" ]; then
  # Non-interactive production deploys must never block on a password prompt.
  # Existing credentials are preserved unless OWNER_TRADING_PASSWORD is explicitly supplied.
  if [ -n "${OWNER_TRADING_PASSWORD:-}" ]; then
    [ ${#OWNER_TRADING_PASSWORD} -eq 8 ] || fail "OWNER_TRADING_PASSWORD must be exactly 8 characters."
    printf '%s' "$OWNER_TRADING_PASSWORD" | PASSWORD_HASH_FILE="$PASSWORD_HASH_FILE" node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to store the supplied password hash."
    NEW_PW="$OWNER_TRADING_PASSWORD"
    unset OWNER_TRADING_PASSWORD
    ok "Website password updated from OWNER_TRADING_PASSWORD"
  else
    ok "Existing website password preserved (no interactive prompt)"
  fi
else
  if [ -n "${OWNER_TRADING_PASSWORD:-}" ]; then
    [ ${#OWNER_TRADING_PASSWORD} -eq 8 ] || fail "OWNER_TRADING_PASSWORD must be exactly 8 characters."
    NEW_PW="$OWNER_TRADING_PASSWORD"
    printf '%s' "$NEW_PW" | PASSWORD_HASH_FILE="$PASSWORD_HASH_FILE" node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to store the supplied password hash."
    unset OWNER_TRADING_PASSWORD
    ok "Initial website password stored from OWNER_TRADING_PASSWORD"
  else
    NEW_PW="$(node -e 'const c=require("crypto"); const a="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"; let s=""; for(let i=0;i<8;i++) s+=a[c.randomInt(a.length)]; process.stdout.write(s)')"
    printf '%s' "$NEW_PW" | PASSWORD_HASH_FILE="$PASSWORD_HASH_FILE" node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to generate/store the initial website password."
    echo "  IMPORTANT: generated initial website password: $NEW_PW"
    ok "Initial website password generated and stored"
  fi
fi

# ------------------------------------------------------------------ services
info "Process management"
if [ -n "$USE_SYSTEMD" ]; then
  id owner-trading >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin owner-trading
  mkdir -p /etc/owner-trading "$SHARED_ROOT" "$SHARED_DATA" "$SHARED_SECURE" "$SHARED_ROOT/scrip_cache"
  chown owner-trading:owner-trading /etc/owner-trading "$SHARED_ROOT" "$SHARED_DATA" "$SHARED_SECURE" "$SHARED_ROOT/scrip_cache"
  chmod 700 /etc/owner-trading "$SHARED_ROOT" "$SHARED_SECURE"
  # Older releases stored the encrypted credential blob under /etc. Migrate it
  # once into the dedicated writable state directory so ProtectSystem=strict
  # can keep the configuration directory read-only to the broker process.
  if [ -f /etc/owner-trading/kotak-credentials.enc ] && [ ! -f /var/lib/owner-trading/kotak-credentials.enc ]; then
    mv /etc/owner-trading/kotak-credentials.enc /var/lib/owner-trading/kotak-credentials.enc
    chown owner-trading:owner-trading /var/lib/owner-trading/kotak-credentials.enc
    chmod 600 /var/lib/owner-trading/kotak-credentials.enc
    ok "Migrated encrypted Kotak credential store to /var/lib/owner-trading"
  fi
  chown -R owner-trading:owner-trading "$SHARED_DATA" "$SHARED_SECURE" "$BROKER_DIR/data"
  for f in "$ENV_FILE" "$PASSWORD_HASH_FILE" "$BROKER_ENV_SYSTEM_PATH"; do [ -f "$f" ] && { chown owner-trading:owner-trading "$f"; chmod 600 "$f"; }; done

  # Generate units with the actual production runtime root. The checked-in
  # templates default to /opt/owner-trading, but RUNTIME_ROOT is supported by
  # deploy.sh and must not leave stale hard-coded paths in systemd.
  sed -e "s#__CURRENT_ROOT__#${CURRENT_LINK}#g" -e "s#/opt/owner-trading#${CURRENT_LINK}#g" -e "s#/usr/bin/env node#${NODE_BIN}#g" \
    "$DEPLOYMENT_DIR/systemd/owner-trading-backend.service" > /etc/systemd/system/owner-trading-backend.service
  sed -e "s#__CURRENT_ROOT__#${CURRENT_LINK}#g" -e "s#/opt/owner-trading#${CURRENT_LINK}#g" \
    "$DEPLOYMENT_DIR/systemd/owner-trading-broker.service" > /etc/systemd/system/owner-trading-broker.service
  if command -v systemd-analyze >/dev/null 2>&1; then
    for u in owner-trading-backend owner-trading-broker; do
      OUT="$(systemd-analyze verify "/etc/systemd/system/$u.service" 2>&1 || true)"; [ -n "$OUT" ] && warn "systemd-analyze ($u): $OUT"
    done
  fi
  # Atomic release switch. The old release remains intact for immediate rollback.
  if [ -n "$NEW_RELEASE" ]; then
    ln -sfn "$NEW_RELEASE" "$CURRENT_LINK"
    CUTOVER_DONE=1
    ok "Atomic release switch: $CURRENT_LINK -> $NEW_RELEASE"
  fi
  systemctl daemon-reload
  ok "systemctl daemon-reload"
  systemctl enable owner-trading-broker.service owner-trading-backend.service >/dev/null
  rollback_release() {
    if [ -n "$PREVIOUS_RELEASE" ] && [ -d "$PREVIOUS_RELEASE" ]; then
      warn "Rolling back current release to $PREVIOUS_RELEASE"
      ln -sfn "$PREVIOUS_RELEASE" "$CURRENT_LINK"
      systemctl daemon-reload || true
      systemctl restart owner-trading-broker.service || true
      systemctl restart owner-trading-backend.service || true
      ok "Rollback restart attempted"
    fi
  }
  systemctl restart owner-trading-broker.service || { journalctl -u owner-trading-broker -n 50 --no-pager; rollback_release; fail "broker failed to start; release was rolled back."; }
  systemctl restart owner-trading-backend.service || { journalctl -u owner-trading-backend -n 50 --no-pager; rollback_release; fail "backend failed to start; release was rolled back."; }
  ok "systemd units installed, enabled at boot, (re)started"

  info "Verifying effective systemd configuration (not just the unit source files)"
  for u in owner-trading-backend owner-trading-broker; do
    systemctl is-active --quiet "$u" || { journalctl -u "$u" -n 50 --no-pager; fail "$u is not active after restart."; }
    EFFECTIVE="$(systemctl show "$u" -p User,Group,WorkingDirectory,ProtectHome,ProtectSystem,ReadOnlyPaths,ReadWritePaths,Result,ExecMainStatus 2>&1)"
    echo "$EFFECTIVE" | sed 's/^/    /'
    RESULT="$(echo "$EFFECTIVE" | awk -F= '/^Result=/{print $2}')"
    [ "$RESULT" = "success" ] || warn "$u Result=$RESULT (non-fatal if the unit is still Type=simple and running; check journal if status is wrong below)."
    ok "$u effective config captured above"
  done
  # Regression guard for the exact failure this fix addresses: if it recurs (e.g. a
  # future edit reverts the ReadOnlyPaths= lines), fail loudly here instead of
  # surfacing only as a 502 from Nginx later.
  for u in owner-trading-backend owner-trading-broker; do
    if journalctl -u "$u" -n 20 --no-pager 2>/dev/null | grep -qi 'CHDIR\|Changing to the requested working directory failed'; then
      journalctl -u "$u" -n 50 --no-pager
      fail "$u: CHDIR/working-directory error detected in the journal (see above). This is the ProtectHome/WorkingDirectory issue -- check that ReadOnlyPaths= in the unit covers the service's own directory."
    fi
  done
  ok "No CHDIR/working-directory errors in either service's recent journal"

  info "Verifying backend and broker respond locally (before Nginx is touched)"
  wait_for() { for _ in $(seq 1 25); do curl -fsS "$1" >/dev/null 2>&1 && return 0; sleep 1; done; return 1; }
  wait_for "http://127.0.0.1:${BROKER_PORT}/health" || { journalctl -u owner-trading-broker -n 50 --no-pager; rollback_release; fail "Broker service failed its health check; release was rolled back."; }
  ok "Broker service healthy on 127.0.0.1:${BROKER_PORT} (127.0.0.1:${BROKER_PORT}/health)"
  ss -ltn 2>/dev/null | grep -q "127.0.0.1:${BROKER_PORT} " && ok "127.0.0.1:${BROKER_PORT} is listening on loopback only" || warn "Could not confirm 127.0.0.1:${BROKER_PORT} is loopback-only via ss (non-fatal; the health check above already succeeded)."
  [ "$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${BROKER_PORT}/status")" = 401 ] && ok "Broker API rejects requests without the internal token" || warn "Broker API did not return 401 without a token (not acceptable for LIVE-only deployment)."
  BSTAT="$(curl -fsS -H "X-Internal-Token: $TOKEN" "http://127.0.0.1:${BROKER_PORT}/status" || true)"
  echo "$BSTAT" | grep -qE '"state":"(NOT_CONFIGURED|DISCONNECTED)"' \
    && ok "Broker starts cleanly with no Kotak credentials entered (state: $(echo "$BSTAT" | grep -o '"state":"[^"]*"'))" \
    || warn "Broker state was not NOT_CONFIGURED/DISCONNECTED at startup: $(echo "$BSTAT" | head -c 200) (fine if credentials were pre-supplied via broker.env)."
  ok "Broker status: $(echo "$BSTAT" | head -c 300)"
  wait_for "http://127.0.0.1:${PORT}/api/health" || { journalctl -u owner-trading-backend -n 50 --no-pager; rollback_release; fail "Backend failed its health check; release was rolled back."; }
  ok "Backend healthy on 127.0.0.1:${PORT} (127.0.0.1:${PORT}/api/health)"
  ss -ltn 2>/dev/null | grep -q "127.0.0.1:${PORT} " && ok "127.0.0.1:${PORT} is listening on loopback only" || warn "Could not confirm 127.0.0.1:${PORT} is loopback-only via ss (non-fatal; the health check above already succeeded)."
else
  warn "systemd unavailable (not root / container) -- starting both services directly in the background."
  for svc in broker backend; do
    PF="$ROOT_DIR/.owner-trading-$svc.pid"
    [ -f "$PF" ] && kill -0 "$(cat "$PF")" 2>/dev/null && { kill "$(cat "$PF")" 2>/dev/null || true; sleep 1; }
  done
  (cd "$BROKER_DIR" && set -a && { [ -f "$BROKER_ENV_SYSTEM_PATH" ] && . "$BROKER_ENV_SYSTEM_PATH"; true; } && set +a \
     && BROKER_SERVICE_PORT="$BROKER_PORT" BROKER_SERVICE_TOKEN="$TOKEN" DB_PATH="$DB_PATH" NEO_LOG_FILE_ENABLED=false \
     nohup ./venv/bin/python -m app.main > "$ROOT_DIR/owner-trading-broker.log" 2>&1 & echo $! > "$ROOT_DIR/.owner-trading-broker.pid")
  (cd "$BACKEND_DIR" && nohup npm start > "$ROOT_DIR/owner-trading-backend.log" 2>&1 & echo $! > "$ROOT_DIR/.owner-trading-backend.pid")
  ok "Started (logs: owner-trading-*.log)"
fi

# ------------------------------------------------------------------ nginx + HTTPS
# LIVE is HTTPS-only. A real domain uses Let's Encrypt. An IP-only one-click
# deployment uses a self-signed certificate so authenticated browser control is
# still HTTPS and SESSION_COOKIE_SECURE=true remains valid.
if [ -z "$DOMAIN" ]; then
  DOMAIN="${PUBLIC_IP:-}"
  if [ -z "$DOMAIN" ]; then
    DOMAIN="$(hostname -I 2>/dev/null | tr ' ' '\n' | awk '/^[0-9]+(\.[0-9]+){3}$/ && $0 !~ /^127\./ {print; exit}')"
  fi
  [ -n "$DOMAIN" ] || fail "Could not detect a server IPv4 address. Re-run with DOMAIN=<domain-or-public-ip>."
  ok "No DOMAIN supplied; using server IPv4 $DOMAIN for HTTPS bootstrap."
fi

info "Nginx reverse proxy: HTTP -> HTTPS redirect, verified TLS required for LIVE"
NGINX_ACTIVE=""; HTTPS_ACTIVE=""
[ -n "$IS_ROOT" ] || fail "deploy.sh must run as root (it should have re-execed through sudo automatically)."
command -v nginx >/dev/null 2>&1 || fail "nginx is required for LIVE deployment."

NGX_SRC="$DEPLOYMENT_DIR/nginx"
mkdir -p /etc/nginx/snippets /etc/nginx/conf.d /var/www/certbot
cp "$NGX_SRC/owner-trading-zones.conf" /etc/nginx/conf.d/owner-trading-zones.conf
sed "s#127.0.0.1:4000#127.0.0.1:${PORT}#g" "$NGX_SRC/owner-trading-proxy.conf" > /etc/nginx/snippets/owner-trading-proxy.conf
cp "$NGX_SRC/owner-trading-locations.conf" /etc/nginx/snippets/owner-trading-locations.conf
SITE=/etc/nginx/sites-available/owner-trading

build_http_site() {
  sed "s#__SERVER_NAME__#${DOMAIN}#g" "$NGX_SRC/owner-trading.http.conf" > "$SITE"
  ln -sf "$SITE" /etc/nginx/sites-enabled/owner-trading
  rm -f /etc/nginx/sites-enabled/default
}

build_http_site
nginx -t >/tmp/ot-nginx-t.$$ 2>&1 || { cat /tmp/ot-nginx-t.$$; rm -f /tmp/ot-nginx-t.$$; fail "nginx HTTP configuration test failed."; }
systemctl enable --now nginx >/dev/null 2>&1 || true
systemctl reload nginx 2>/dev/null || systemctl restart nginx
NGINX_ACTIVE=1
ok "HTTP reverse proxy prepared on port 80 (redirects to HTTPS)"

CERT=""; KEY=""
if [[ "$DOMAIN" =~ ^[0-9]+(\.[0-9]+){3}$ ]] && [ -z "$CERTBOT_EMAIL" ]; then
  TLS_DIR="/etc/owner-trading/tls"
  CERT="$TLS_DIR/fullchain.pem"; KEY="$TLS_DIR/privkey.pem"
  mkdir -p "$TLS_DIR"; chmod 700 "$TLS_DIR"
  if [ ! -s "$CERT" ] || [ ! -s "$KEY" ]; then
    command -v openssl >/dev/null 2>&1 || fail "openssl is required for the HTTPS IP bootstrap certificate."
    openssl req -x509 -nodes -newkey rsa:2048 -sha256 -days 825 \
      -keyout "$KEY" -out "$CERT" -subj "/CN=$DOMAIN" \
      -addext "subjectAltName=IP:$DOMAIN" >/tmp/ot-selfsigned.$$ 2>&1 \
      || { cat /tmp/ot-selfsigned.$$; rm -f /tmp/ot-selfsigned.$$; fail "Could not create the HTTPS bootstrap certificate."; }
    chmod 600 "$KEY"; chmod 644 "$CERT"
    ok "Created self-signed HTTPS certificate for $DOMAIN (IP bootstrap)."
  fi
else
  [ -n "$CERTBOT_EMAIL" ] || fail "CERTBOT_EMAIL is required when DOMAIN is a DNS name. For IP-only deployment, omit DOMAIN and the script will create a self-signed HTTPS bootstrap certificate."
  CERT="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
  KEY="/etc/letsencrypt/live/$DOMAIN/privkey.pem"
  [ -f "$CERT" ] || certbot certonly --webroot -w /var/www/certbot -d "$DOMAIN" -m "$CERTBOT_EMAIL" --agree-tos --non-interactive \
    || fail "certbot could not issue a certificate for $DOMAIN. Ensure DNS points to this server and port 80 is reachable."
  ok "Let's Encrypt certificate ready for $DOMAIN"
fi

sed -e "s#__DOMAIN__#${DOMAIN}#g" -e "s#__CERT__#${CERT}#g" -e "s#__KEY__#${KEY}#g" \
  "$NGX_SRC/owner-trading.https.conf" > /tmp/owner-trading.https.generated.$$
printf '\n' >> "$SITE"
cat /tmp/owner-trading.https.generated.$$ >> "$SITE"
if nginx -t >/tmp/ot-nginx-t.$$ 2>&1; then
  systemctl reload nginx 2>/dev/null || systemctl restart nginx
  HTTPS_ACTIVE=1
  ok "HTTPS enabled for https://$DOMAIN (HTTP redirects to HTTPS)"
  if [[ "$CERT" == /etc/letsencrypt/* ]]; then
    mkdir -p /etc/letsencrypt/renewal-hooks/deploy
    printf '#!/bin/sh\nsystemctl reload nginx\n' > /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh
    chmod +x /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh
  fi
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi active; then
    ufw allow 'Nginx Full' >/dev/null 2>&1 || true
    ok "ufw: Nginx Full allowed"
  fi
else
  cat /tmp/ot-nginx-t.$$; rm -f /tmp/ot-nginx-t.$$; fail "HTTPS server block failed nginx -t; LIVE deployment refuses to continue without verified HTTPS."
fi
rm -f /tmp/ot-nginx-t.$$ /tmp/ot-selfsigned.$$ /tmp/owner-trading.https.generated.$$

# ------------------------------------------------------------------ non-systemd fallback health check
if [ -z "$USE_SYSTEMD" ]; then
  info "Health checks"
  wait_for() { for _ in $(seq 1 25); do curl -fsS "$1" >/dev/null 2>&1 && return 0; sleep 1; done; return 1; }
  wait_for "http://127.0.0.1:${BROKER_PORT}/health" || { tail -n 30 "$ROOT_DIR/owner-trading-broker.log" 2>/dev/null; fail "Broker service failed its health check."; }
  ok "Broker service healthy"
  BSTAT="$(curl -fsS -H "X-Internal-Token: $TOKEN" "http://127.0.0.1:${BROKER_PORT}/status" || true)"
  ok "Broker status: $(echo "$BSTAT" | head -c 300)"
  wait_for "http://127.0.0.1:${PORT}/api/health" || { tail -n 30 "$ROOT_DIR/owner-trading-backend.log" 2>/dev/null; fail "Backend failed its health check."; }
  ok "Backend healthy"
fi

# ------------------------------------------------------------------ nginx upstream / public reachability
if [ -n "$NGINX_ACTIVE" ]; then
  info "Verifying Nginx upstream connectivity (the actual 502 check)"
  CODE="$(curl -s -o /tmp/ot-nginx-body.$$ -w '%{http_code}' --max-time 10 "http://127.0.0.1/api/health" || echo 000)"
  if [ "$CODE" = "502" ] || [ "$CODE" = "503" ] || [ "$CODE" = "504" ]; then
    tail -c 500 /tmp/ot-nginx-body.$$; rm -f /tmp/ot-nginx-body.$$
    journalctl -u owner-trading-backend -n 30 --no-pager
    fail "Nginx returned HTTP $CODE proxying to the backend -- upstream is not reachable from Nginx. See the backend journal above."
  fi
  [ "$CODE" = "301" ] || { tail -c 300 /tmp/ot-nginx-body.$$; fail "Nginx HTTP -> HTTPS redirect failed (got HTTP $CODE)."; }
  rm -f /tmp/ot-nginx-body.$$
  ok "Nginx HTTP -> HTTPS redirect verified (no 502/503/504)"
  ROOT_CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1/")"
  [ "$ROOT_CODE" = "502" ] && fail "Nginx returned 502 for the site root through the local reverse proxy."
  ok "Site root via Nginx: HTTP $ROOT_CODE (not 502)"
  if [ -n "$HTTPS_ACTIVE" ]; then
    HCODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 --resolve "${DOMAIN}:443:127.0.0.1" "https://${DOMAIN}/api/health")"
    [ "$HCODE" = "502" ] && fail "Nginx returned 502 for https://${DOMAIN}/api/health."
    [ "$HCODE" = "200" ] && ok "HTTPS via Nginx (https://${DOMAIN}/api/health): HTTP 200, no 502" || warn "HTTPS via Nginx: HTTP $HCODE (expected 200)."
  fi
  echo "  NOTE: the checks above confirm Nginx <-> backend connectivity FROM THIS SERVER. Confirming the site is"
  echo "  reachable from the public internet (not just that this server can reach itself) requires an external"
  echo "  request -- e.g. curl from another machine, or deployment/verify-deployment.sh DOMAIN=${DOMAIN:-<domain>} run"
  echo "  after DNS points here. This script does not claim that external check on your behalf."
else
  info "Nginx is not active -- skipping the Nginx-upstream / 502 check (the app is reachable directly on 127.0.0.1:${PORT})."
fi

# ---- Login + session verification -------------------------------------------------------------
# Runs REAL requests and checks REAL behaviour (cookie attributes, authenticated API access, logout).
# Nothing is faked: the plain-HTTP flow sends no proxy headers at all; the HTTPS flows are either a
# real TLS request through nginx, or -- clearly labelled -- the exact X-Forwarded-Proto header nginx
# adds on port 443, sent to Express directly.
session_flow() { # label base_url expect(plain|secure|none) [extra curl args...]
  local label="$1" base="$2" expect="$3"; shift 3
  local hdr body code cookie_line pair
  hdr="$(mktemp)"; body="$(mktemp)"
  code="$(printf '%s' "$LOGIN_JSON" | curl -sS -o "$body" -D "$hdr" -w '%{http_code}' --max-time 15 "$@" \
          -H 'Content-Type: application/json' --data-binary @- "$base/api/auth/login" 2>&1)" || { rm -f "$hdr" "$body"; fail "[$label] login request failed to connect: $code"; }
  [ "$code" = "200" ] && grep -q '"success":true' "$body" || { rm -f "$hdr" "$body"; fail "[$label] POST /api/auth/login returned HTTP $code (password authentication itself is separate from cookies -- see backend log)."; }
  cookie_line="$(grep -i '^set-cookie: owner_trading_sid=' "$hdr" | head -n1 | tr -d '\r')"
  rm -f "$hdr" "$body"
  if [ "$expect" = "none" ]; then
    [ -z "$cookie_line" ] && { ok "[$label] password accepted; no session cookie over this transport -- expected: SESSION_COOKIE_SECURE=true is HTTPS-only"; return 0; }
    fail "[$label] a session cookie was issued although SESSION_COOKIE_SECURE=true forbids it over plain HTTP."
  fi
  [ -n "$cookie_line" ] || fail "[$label] login succeeded but NO session cookie was issued -- the browser could not stay logged in."
  echo "$cookie_line" | grep -qi 'httponly'          || fail "[$label] session cookie lacks HttpOnly: $cookie_line"
  echo "$cookie_line" | grep -qi 'samesite=lax'      || fail "[$label] session cookie lacks SameSite=Lax: $cookie_line"
  if [ "$expect" = "secure" ]; then echo "$cookie_line" | grep -qi '; *secure' || fail "[$label] cookie over HTTPS is NOT Secure: $cookie_line"
  else echo "$cookie_line" | grep -qi '; *secure' && fail "[$label] cookie over plain HTTP is marked Secure (browser would drop it): $cookie_line"; fi
  pair="$(echo "${cookie_line#*:}" | sed 's/^ *//' | cut -d';' -f1)"
  # Replay the cookie exactly as a browser would on this transport.
  curl -fsS --max-time 10 "$@" -H "Cookie: $pair" "$base/api/auth/session" | grep -q '"authenticated":true' \
    || fail "[$label] cookie was issued but /api/auth/session does not report an authenticated session."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" -H "Cookie: $pair" "$base/api/risk")" = "200" ] \
    || fail "[$label] authenticated request to a protected API endpoint (/api/risk) was not accepted."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" "$base/api/risk")" = "401" ] \
    || fail "[$label] protected endpoint answered without a session cookie."
  curl -fsS --max-time 10 -X POST "$@" -H "Cookie: $pair" "$base/api/auth/logout" >/dev/null || fail "[$label] logout request failed."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" -H "Cookie: $pair" "$base/api/risk")" = "401" ] \
    || fail "[$label] session still valid after logout."
  ok "[$label] login -> $([ "$expect" = secure ] && echo 'Secure' || echo 'non-Secure') HttpOnly SameSite=Lax cookie -> authenticated API access -> logout destroys session"
}

if [ -n "$NEW_PW" ]; then
  info "Verifying login + session over HTTP and HTTPS"
  LOGIN_JSON="$(node -e 'process.stdout.write(JSON.stringify({password: process.argv[1]}))' "$NEW_PW")"
  unset NEW_PW
  EXP_HTTP=plain; EXP_HTTPS=secure
  case "$COOKIE_POLICY" in true|1|yes|on) EXP_HTTP=none ;; false|0|no|off) EXP_HTTPS=plain ;; esac
  session_flow "HTTP  -> Express :${PORT}" "http://127.0.0.1:${PORT}" "$EXP_HTTP"
  session_flow "HTTPS -> Express :${PORT} (nginx's X-Forwarded-Proto: https header, simulated)" "http://127.0.0.1:${PORT}" "$EXP_HTTPS" -H 'X-Forwarded-Proto: https'
  if [ -n "$NGINX_ACTIVE" ]; then
    REDIRECT_CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1/api/auth/session")"
    [ "$REDIRECT_CODE" = "301" ] || fail "HTTP nginx endpoint did not redirect to HTTPS (got HTTP $REDIRECT_CODE)."
    ok "HTTP nginx authentication endpoint redirects to HTTPS"
  fi
  if [ -n "$HTTPS_ACTIVE" ]; then
    TLS_ARGS=(--resolve "${DOMAIN}:443:127.0.0.1")
    if [[ "$DOMAIN" =~ ^[0-9]+(\.[0-9]+){3}$ ]] && [ -z "$CERTBOT_EMAIL" ]; then TLS_ARGS=(-k "${TLS_ARGS[@]}"); fi
    session_flow "HTTPS -> nginx :443 (real TLS for $DOMAIN)" "https://${DOMAIN}" "$EXP_HTTPS" "${TLS_ARGS[@]}"
  fi
  unset LOGIN_JSON
else
  info "Login verification skipped: the existing password was kept and this script never holds its plaintext."
  echo "  Unauthenticated session endpoint check only:"
  curl -fsS --max-time 10 "http://127.0.0.1:${PORT}/api/auth/session" | grep -q '"authenticated":false' && ok "GET /api/auth/session answers {authenticated:false} without a cookie" || fail "/api/auth/session did not answer as expected."
  echo "  To verify login for real: re-run ./deploy.sh and choose to set a new password, or log in from a browser."
fi

echo
echo "=============================================="
echo "   Deployment complete"
echo "   Execution:       LIVE-only (strategy execution remains disarmed until owner arms it)"
echo "   Official SDK:    kotakneoapi $INSTALLED (vendored, integrity + signatures verified)"
if [ -n "$NGINX_ACTIVE" ]; then HTTP_DESC="http://<server-ip>/  (via nginx on port 80)"; else HTTP_DESC="http://<server-ip>:${PORT}/  (nginx not installed)"; fi
if [ -n "$HTTPS_ACTIVE" ]; then HTTPS_DESC="https://${DOMAIN} (nginx :443; HTTP stays available)"; else HTTPS_DESC="not enabled (needs DOMAIN + a certificate)"; fi
echo "   HTTP:            ${HTTP_DESC} (redirects to HTTPS)"
echo "   HTTPS:           ${HTTPS_DESC}"
echo "   Cookie policy:   SESSION_COOKIE_SECURE=${COOKIE_POLICY} (LIVE authenticated control is HTTPS-only)"
if [ -n "$USE_SYSTEMD" ]; then echo "   Services:        owner-trading-backend, owner-trading-broker (systemd, User=Group=owner-trading, effective config verified above)"; fi
if [ -n "$NGINX_ACTIVE" ]; then echo "   Nginx upstream:  verified (no 502/503/504 from 127.0.0.1)"; fi
echo "   Next:            Settings -> enter Kotak credentials -> Test -> Connect -> configure Risk -> reconcile -> arm strategy."
echo "   Smoke test:      DOMAIN=${DOMAIN} sudo deployment/verify-deployment.sh"
DEPLOY_SUCCESS=1
SERVICES_QUIESCED=0

if [ -n "$IS_ROOT" ] && [ -n "$NEW_RELEASE" ] && [ -d "$RELEASES_DIR" ]; then
  # Keep the current release plus the three newest rollback candidates.
  ls -1dt "$RELEASES_DIR"/* 2>/dev/null | while read -r rel; do
    [ "$rel" = "$NEW_RELEASE" ] && continue
    [ -n "$PREVIOUS_RELEASE" ] && [ "$rel" = "$PREVIOUS_RELEASE" ] && continue
    count="$(find "$RELEASES_DIR" -mindepth 1 -maxdepth 1 -type d -printf '%p\n' | wc -l)"
    [ "$count" -le 4 ] && break
    rm -rf -- "$rel"
  done
  ok "Rollback releases retained under $RELEASES_DIR"
fi

echo "=============================================="
