import { useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";

const FIELDS = ["close", "sma20", "ema20", "ema50", "rsi14", "atr14", "macd", "macd_signal", "adx14", "vwap", "bb_upper", "bb_lower", "volume_sma20"];
const OPERATORS = [">", ">=", "<", "<=", "cross_above", "cross_below"];
const TIMEFRAMES = ["1m", "3m", "5m", "10m", "15m", "30m", "1h", "1d"];

function conditionSummary(details) {
  const items = (details && details.items) || [];
  return items.map((i) => (i.reason ? String(i.reason) : "")).filter(Boolean).join("; ") || "—";
}

export default function Scanner() {
  const scanners = usePolling(() => api.getScanners(), 5000);
  const candidates = usePolling(() => api.getAlgoCandidates("", 3000), 5000);
  const [name, setName] = useState("Momentum Scanner");
  const [left, setLeft] = useState("ema20");
  const [op, setOp] = useState(">");
  const [right, setRight] = useState("ema50");
  const [timeframe, setTimeframe] = useState("5m");
  const [warmup, setWarmup] = useState(true);
  const [subscribeMatches, setSubscribeMatches] = useState(false);
  const [msg, setMsg] = useState("");
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(null);

  const definition = {
    timeframe,
    side: "BUY",
    entry: { op: "AND", conditions: [{ left, operator: op, right }] },
    exit: { op: "OR", conditions: [{ left: "rsi14", operator: "<", right: 45 }] },
    position_sizing: { quantity: 1 },
    execution: { product: "MIS" },
  };

  async function save() {
    const r = await api.createScanner({ name, definition });
    setMsg(r.ok ? "Scanner saved and validated." : (r.body && r.body.validation_errors && r.body.validation_errors.join("; ")) || (r.body && r.body.error) || "Save failed");
    scanners.reload();
  }

  async function run() {
    setRunning(true);
    setMsg("Scanning… loading missing candle history first (up to ~10 s).");
    const r = await api.runScanner({ definition, timeframe, limit: 3000, warmup, subscribe_matches: subscribeMatches });
    setRunning(false);
    if (r.ok) {
      setResult(r.body);
      setMsg(`Scanned ${r.body.scanned}; matched ${r.body.matched}.`);
      candidates.reload();
    } else {
      setResult(null);
      setMsg((r.body && (r.body.validation_errors ? r.body.validation_errors.join("; ") : r.body.error)) || "Scan failed");
    }
  }

  const d = result && result.diagnostics;
  const w = result && result.warmup;
  const matches = (result && result.matches) || [];
  const list = (candidates.body && candidates.body.candidates) || [];

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Scanner</h2>
        <p className="page__subtitle">Validated candidate discovery before strategy execution. A scanner match never places an order.</p>
      </div>

      <div className="card">
        <div className="order-form">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Scanner name" />
          <select value={timeframe} onChange={(e) => setTimeframe(e.target.value)}>
            {TIMEFRAMES.map((x) => <option key={x} value={x}>{x}</option>)}
          </select>
          <select value={left} onChange={(e) => setLeft(e.target.value)}>
            {FIELDS.map((x) => <option key={x}>{x}</option>)}
          </select>
          <select value={op} onChange={(e) => setOp(e.target.value)}>
            {OPERATORS.map((x) => <option key={x}>{x}</option>)}
          </select>
          <input value={right} onChange={(e) => setRight(e.target.value)} placeholder="indicator / number" />
        </div>
        <label className="form-hint"><input type="checkbox" checked={warmup} onChange={(e) => setWarmup(e.target.checked)} /> Load missing candle history from Kotak first</label>
        <br />
        <label className="form-hint"><input type="checkbox" checked={subscribeMatches} onChange={(e) => setSubscribeMatches(e.target.checked)} /> Subscribe matched stocks to the live feed (replaces the previous scan's matches)</label>
        <br />
        <button type="button" onClick={save}>Save Scanner</button>{" "}
        <button type="button" onClick={run} disabled={running}>{running ? "Scanning…" : "Run Now"}</button>
        {msg && <p className="form-hint">{msg}</p>}
      </div>

      {result && (
        <div className="card">
          <h3>Scan result</h3>
          {result.explanation && <p><strong>{result.explanation}</strong></p>}
          {d && (
            <p className="form-hint">
              Universe {d.universe} · evaluated {d.evaluated} · no candles {d.no_candles} · fewer than {d.required_bars} bars {d.insufficient_history} · stale {d.stale} · matched {d.matched}
              {d.latest_candle_at ? ` · latest completed bar ${d.latest_candle_at} IST` : ""} · market {result.market_open ? "open" : "closed"}
            </p>
          )}
          {w && (
            <p className="form-hint">
              History: needed {w.needed ?? 0} · loaded {w.fetched ?? 0} · failed {w.failed ?? 0} · remaining {w.remaining ?? 0}
              {w.remaining > 0 ? " — press Run Now again to keep loading." : ""}
              {w.stopped ? ` · stopped: ${w.stopped}` : ""}{w.error ? ` · ${w.error}` : ""}
            </p>
          )}
          {result.subscribed_matches && (
            <p className="form-hint">
              Live feed: {result.subscribed_matches.error ? `subscription failed — ${result.subscribed_matches.error}` : `${result.subscribed_matches.subscribed} matched stocks subscribed`}
            </p>
          )}
          {matches.length > 0 ? (
            <div className="data-table-wrap">
              <table className="data-table">
                <thead><tr><th>Symbol</th><th>Price</th><th>Bar (IST)</th><th>Conditions</th></tr></thead>
                <tbody>
                  {matches.map((m) => (
                    <tr key={`${m.exchange_segment}:${m.instrument_token}`}>
                      <td>{m.trading_symbol || m.instrument_token}</td>
                      <td>{m.price}</td>
                      <td>{m.candle_at || "—"}</td>
                      <td>{conditionSummary(m.details)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p className="form-hint">No matching stocks.</p>}
        </div>
      )}

      <div className="card">
        <h3>LIVE Candidate Registry</h3>
        <p className="form-hint">Only strategy-linked scanner matches appear here (the scanner runs automatically every 30 s while a scanner-linked strategy is LIVE-armed and the market is open). Candidate subscription is separate from final strategy entry/risk/order validation.</p>
        {list.length ? (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead><tr><th>Strategy</th><th>Scanner</th><th>Symbol</th><th>Status</th><th>Matched</th><th>Expires</th></tr></thead>
              <tbody>
                {list.map((c) => (
                  <tr key={c.id}>
                    <td>v{c.strategy_version_id}</td><td>#{c.scanner_id}</td>
                    <td>{c.trading_symbol || c.instrument_token}</td>
                    <td>{c.status}{c.subscribed_at ? " · SUBSCRIBED" : ""}{c.subscription_error ? ` · ${c.subscription_error}` : ""}</td>
                    <td>{c.matched_price ?? "—"}</td><td>{c.expires_at || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="form-hint">No active candidates.</p>}
      </div>

      {((scanners.body && scanners.body.scanners) || []).map((s) => (
        <div className="card" key={s.id}>
          <strong>{s.name}</strong> · {s.is_active ? "ACTIVE" : "inactive"}
          <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(s.definition, null, 2)}</pre>
          <button type="button" onClick={async () => { await api.activateScanner(s.id); scanners.reload(); }}>Activate</button>{" "}
          <button type="button" onClick={async () => { await api.deactivateScanner(s.id); scanners.reload(); }}>Deactivate</button>
        </div>
      ))}
    </div>
  );
}
