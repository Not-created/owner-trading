import { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import Icon from "../common/Icon";
import { NAV_SECTIONS } from "./navConfig";

// The five destinations used all day; everything else lives in the "More" sheet.
const PRIMARY = [
  { key: "dashboard", label: "Home" },
  { key: "scanner", label: "Scan" },
  { key: "orders", label: "Orders" },
  { key: "positions", label: "Positions" },
];

const byKey = Object.fromEntries(NAV_SECTIONS.map((s) => [s.key, s]));

export default function BottomNav({ onLogout }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMoreOpen(false);
  }, [location.pathname]);

  const primaryPaths = PRIMARY.map((p) => byKey[p.key]?.path).filter(Boolean);
  const onPrimary = primaryPaths.some((path) =>
    path === "/dashboard" ? location.pathname === "/dashboard" : location.pathname.startsWith(path)
  );
  const secondary = NAV_SECTIONS.filter((s) => !PRIMARY.some((p) => p.key === s.key));

  return (
    <>
      {moreOpen && (
        <div className="more-sheet__backdrop" onClick={() => setMoreOpen(false)} aria-hidden="true" />
      )}
      {moreOpen && (
        <div className="more-sheet" role="dialog" aria-label="All sections">
          <div className="more-sheet__grid">
            {secondary.map((item) => (
              <NavLink
                key={item.key}
                to={item.path}
                className={({ isActive }) => `more-sheet__item ${isActive ? "more-sheet__item--active" : ""}`}
              >
                <Icon name={item.icon} size={22} />
                <span>{item.label}</span>
              </NavLink>
            ))}
            <button type="button" className="more-sheet__item more-sheet__item--danger" onClick={onLogout}>
              <Icon name="logout" size={22} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      )}

      <nav className="bottom-nav" aria-label="Main navigation">
        {PRIMARY.map((p) => {
          const item = byKey[p.key];
          if (!item) return null;
          return (
            <NavLink
              key={p.key}
              to={item.path}
              end={item.path === "/dashboard"}
              className={({ isActive }) => `bottom-nav__item ${isActive ? "bottom-nav__item--active" : ""}`}
            >
              <Icon name={item.icon} size={22} />
              <span>{p.label}</span>
            </NavLink>
          );
        })}
        <button
          type="button"
          className={`bottom-nav__item ${moreOpen || !onPrimary ? "bottom-nav__item--active" : ""}`}
          onClick={() => setMoreOpen((v) => !v)}
          aria-expanded={moreOpen}
        >
          <Icon name="more" size={22} />
          <span>More</span>
        </button>
      </nav>
    </>
  );
}
