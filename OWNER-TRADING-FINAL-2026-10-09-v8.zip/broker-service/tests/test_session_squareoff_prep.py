import asyncio
import datetime as dt
import os
import tempfile
import unittest
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

from app import market_session as ms
from tests.dbutil import fresh_db
from tests.test_exit_request_lifecycle import _setup

IST = ZoneInfo("Asia/Kolkata")


def at(h, m, day=dt.date(2026, 10, 8)):          # 2026-10-08 is a Thursday
    return dt.datetime(day.year, day.month, day.day, h, m, tzinfo=IST)


class SessionRules(unittest.TestCase):
    def test_default_times(self):
        self.assertTrue(ms.mis_entries_allowed(at(10, 0))[0])
        self.assertTrue(ms.mis_entries_allowed(at(14, 59))[0])
        ok, why = ms.mis_entries_allowed(at(15, 0)); self.assertFalse(ok); self.assertIn("15:00", why)
        self.assertFalse(ms.mis_squareoff_due(at(15, 14)))
        self.assertTrue(ms.mis_squareoff_due(at(15, 15)))
        self.assertTrue(ms.mis_squareoff_due(at(15, 29)))
        self.assertFalse(ms.mis_squareoff_due(at(15, 30)))          # market closed
        self.assertFalse(ms.mis_squareoff_due(at(10, 0)))

    def test_weekend_and_holiday_are_closed(self):
        self.assertEqual(ms.session_state(at(11, 0, dt.date(2026, 10, 10)))["reason"], "WEEKEND")
        with patch.dict(os.environ, {"MARKET_HOLIDAYS": "2026-10-08, 2026-10-20"}):
            st = ms.session_state(at(11, 0))
            self.assertEqual((st["open"], st["holiday"], st["reason"]), (False, True, "HOLIDAY"))
            self.assertFalse(ms.mis_squareoff_due(at(15, 20)))
            self.assertFalse(ms.mis_entries_allowed(at(10, 0))[0])

    def test_holiday_file_with_comments_and_bad_lines(self):
        with tempfile.TemporaryDirectory() as d:
            f = os.path.join(d, "h.txt")
            open(f, "w").write("# Diwali\n2026-10-08\nnot-a-date\n\n2026-11-09 # Balipratipada\n")
            with patch.dict(os.environ, {"MARKET_HOLIDAYS_FILE": f, "MARKET_HOLIDAYS": ""}):
                self.assertEqual(ms.holidays(), frozenset({dt.date(2026, 10, 8), dt.date(2026, 11, 9)}))
                self.assertTrue(ms.session_state(at(11, 0))["holiday"])

    def test_custom_times_and_invalid_fall_back(self):
        with patch.dict(os.environ, {"MIS_ENTRY_CUTOFF_IST": "14:30", "MIS_SQUAREOFF_IST": "15:10"}):
            self.assertFalse(ms.mis_entries_allowed(at(14, 31))[0])
            self.assertTrue(ms.mis_squareoff_due(at(15, 10)))
        with patch.dict(os.environ, {"MIS_ENTRY_CUTOFF_IST": "16:00", "MIS_SQUAREOFF_IST": "xx"}):
            self.assertEqual(ms._times(), (dt.time(15, 0), dt.time(15, 15)))


class MisOrderGate(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments([{"trading_symbol": "ABC-EQ", "instrument_token": "500", "lot_size": 1, "tick_size": 0.05}])
        from app import order_service
        self.osv = order_service
        self.p = dict(trading_symbol="ABC-EQ", exchange_segment="nse_cm", transaction_type="B", order_type="L", product="MIS",
                      validity="DAY", quantity=1, price=100.05, instrument_token="500", order_role="MANUAL")

    def test_new_mis_order_blocked_after_cutoff_but_cnc_and_exit_are_not(self):
        with patch("app.market_session.mis_entries_allowed", return_value=(False, "MIS entries are closed after 15:00 IST")):
            with self.assertRaisesRegex(self.osv.OrderValidationError, "MIS"):
                self.osv._validate(dict(self.p))
            self.assertTrue(self.osv._validate(dict(self.p, product="CNC")))


class SquareOff(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        import app.exit_engine as ee
        self.ee = ee
        ee._inflight.clear(); ee._last_attempt.clear()
        self._cd = ee.EXIT_RETRY_COOLDOWN_SECONDS; ee.EXIT_RETRY_COOLDOWN_SECONDS = 0.0
        self.pos = _setup(self.db)
        self.calls = []
        self._orig = ee.order_service.place_order

        async def fake(payload):
            self.calls.append(payload)
            self.db.create_order(internal_order_id=payload["idempotency_key"], trading_symbol="ABC", exchange_segment="nse_cm",
                                 transaction_type="S", order_type="MKT", product="MIS", validity="DAY", quantity=payload["quantity"],
                                 price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
                                 client_tag="TG" + payload["idempotency_key"][-8:].replace("-", "X"), instrument_token="123",
                                 order_role="EXIT", algo_position_id=payload["algo_position_id"], parent_order_id="entry-1")
            return self.db.get_order(payload["idempotency_key"])
        ee.order_service.place_order = fake

    def tearDown(self):
        self.ee.order_service.place_order = self._orig
        self.ee.EXIT_RETRY_COOLDOWN_SECONDS = self._cd

    def test_not_due_before_squareoff_time(self):
        r = asyncio.run(self.ee.square_off_due(at(15, 0)))
        self.assertEqual((r["due"], self.calls), (False, []))

    def test_mis_position_is_flattened_once_at_squareoff_time(self):
        r = asyncio.run(self.ee.square_off_due(at(15, 16)))
        self.assertTrue(r["due"])
        self.assertEqual(len(self.calls), 1)
        c = self.calls[0]
        self.assertEqual((c["order_role"], c["order_type"], c["transaction_type"], c["quantity"]), ("EXIT", "MKT", "S", 10))
        asyncio.run(self.ee.square_off_due(at(15, 17)))             # exit is pending: never duplicated
        self.assertEqual(len(self.calls), 1)
        with self.db._connection() as c2:
            self.assertEqual(c2.execute("SELECT reason FROM algo_exits").fetchone()[0], "MIS_SQUAREOFF")

    def test_full_quantity_even_with_partial_exit_pct(self):
        asyncio.run(self.ee.square_off_due(at(15, 16)))
        self.assertEqual(self.calls[0]["quantity"], 10)              # strategy has partial_exit_pct=50

    def test_cnc_positions_are_never_squared_off(self):
        with self.db._connection() as c:
            import json
            row = c.execute("SELECT id, definition_json FROM strategy_versions WHERE id=?", (self.pos["strategy_version_id"],)).fetchone()
            d = json.loads(row[1]); d.setdefault("execution", {})["product"] = "CNC"
            c.execute("UPDATE strategy_versions SET definition_json=? WHERE id=?", (json.dumps(d), row[0]))
        asyncio.run(self.ee.square_off_due(at(15, 16)))
        self.assertEqual(self.calls, [])


class DailyPrep(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        from app import daily_prep
        self.dp = daily_prep
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = patch.object(daily_prep.config, "data_dir", self.tmp.name) if False else None
        self.p1 = patch("app.daily_prep._marker_path", lambda day: os.path.join(self.tmp.name, f"m-{day}.json"))
        self.p1.start()
        daily_prep._last_attempt = float("-inf")
        from types import SimpleNamespace
        from app.state import BrokerState
        self.BS = BrokerState
        self.cs = SimpleNamespace(state=BrokerState.CONNECTED)
        self.p2 = patch("app.daily_prep.current_state", self.cs)
        self.p2.start()

    async def asyncTearDown(self):
        self.p1.stop(); self.p2.stop(); self.tmp.cleanup()

    async def test_runs_once_per_day_and_resumes_when_incomplete(self):
        sync = AsyncMock(return_value={"ok": True, "count": 3000})
        with patch("app.daily_prep.universe.sync_nse_cash_metadata", sync):
            r = await self.dp.maybe_run(at(8, 45))
            self.assertTrue(r["complete"]); sync.assert_awaited_once()
            self.assertIsNone(await self.dp.maybe_run(at(8, 50)))       # done today: not repeated
            self.assertEqual(sync.await_count, 1)

    async def test_failed_scrip_sync_is_retried_after_cooldown(self):
        sync = AsyncMock(return_value={"ok": False, "error": "network"})
        with patch("app.daily_prep.universe.sync_nse_cash_metadata", sync):
            r = await self.dp.maybe_run(at(8, 45))
            self.assertFalse(r["complete"])
            self.assertIsNone(await self.dp.maybe_run(at(8, 46)))       # within retry window
            self.dp._last_attempt = float("-inf")
            await self.dp.maybe_run(at(8, 52))
            self.assertEqual(sync.await_count, 2)

    async def test_skips_weekend_holiday_early_morning_and_disconnected(self):
        sync = AsyncMock(return_value={"ok": True})
        with patch("app.daily_prep.universe.sync_nse_cash_metadata", sync):
            self.assertIsNone(await self.dp.maybe_run(at(8, 45, dt.date(2026, 10, 10))))   # Saturday
            self.assertIsNone(await self.dp.maybe_run(at(7, 0)))                           # too early
            with patch.dict(os.environ, {"MARKET_HOLIDAYS": "2026-10-08"}):
                self.assertIsNone(await self.dp.maybe_run(at(8, 45)))
            self.cs.state = self.BS.DISCONNECTED
            self.assertIsNone(await self.dp.maybe_run(at(8, 45)))
        sync.assert_not_awaited()

    async def test_history_warmup_is_run_for_armed_scanner_universe(self):
        d = {"side": "BUY", "timeframe": "5m", "scanner_ids": [1],
             "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
             "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
             "execution": {"product": "MIS"}, "risk": {"stop_loss_pct": 1, "target_pct": 2}, "position_sizing": {"quantity": 1}}
        warm = AsyncMock(return_value={"fetched": 5, "remaining": 0, "needed": 5})
        with patch("app.daily_prep.universe.sync_nse_cash_metadata", AsyncMock(return_value={"ok": True})), \
             patch("app.daily_prep._warmup_jobs", return_value=[("scanner#1", [{"exchange_segment": "nse_cm", "instrument_token": "1"}], "5m", d)]), \
             patch("app.daily_prep.scanner_engine.warmup_history", warm):
            r = await self.dp.run_daily_prep(now=at(8, 45))
        self.assertTrue(r["complete"]); warm.assert_awaited_once()
        self.assertEqual(r["history"][0]["fetched"], 5)


if __name__ == "__main__":
    unittest.main()
