import datetime as dt
import unittest
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")


def at(h, m, s=0):
    return dt.datetime(2026, 9, 24, h, m, s, tzinfo=IST)


class CandleIntegrity(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app.candle_engine import CandleEngine
        self.e = CandleEngine()
        self.e._timeframe_cache = {"5m"}; self.e._timeframe_cache_at = 1e18
        self.t = lambda p, ts, v=None: self.e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=p, volume=v, timestamp=ts)

    def test_out_of_order_tick_does_not_close_or_rewind_bar(self):
        self.t(100, at(10, 2)); self.t(101, at(10, 3))
        self.t(50, at(9, 58))                      # late tick from an earlier bar
        st = self.e._state[("nse_cm", "1", "5m")]
        self.assertEqual((st["at"].minute, st["close"], st["low"]), (0, 101, 100))

    def test_invalid_prices_ignored(self):
        self.t(100, at(10, 2))
        for bad in (0, -1, float("nan"), float("inf"), "abc", None):
            self.t(bad, at(10, 3))
        st = self.e._state[("nse_cm", "1", "5m")]
        self.assertEqual((st["close"], st["high"], st["low"]), (100, 100, 100))

    def test_same_day_cumulative_volume_glitch_adds_nothing(self):
        self.t(100, at(10, 1), 1000); self.t(100, at(10, 2), 1500)
        self.t(100, at(10, 3), 200)                # lower cumulative on same date: glitch
        self.t(100, at(10, 4), 1600)
        self.assertEqual(self.e._state[("nse_cm", "1", "5m")]["volume"], 0 + 500 + 0 + 100)

    def test_bar_completes_on_forward_bucket_change(self):
        self.t(100, at(10, 1)); self.t(105, at(10, 6))
        c = self.db.get_candle("nse_cm", "1", "5m", "2026-09-24 10:00:00")
        self.assertEqual(c["close"], 100)


if __name__ == "__main__":
    unittest.main()


class ScannerFreshnessTimezone(unittest.TestCase):
    def test_naive_ist_candle_from_the_candle_engine_is_fresh(self):
        from app import scanner_engine as se
        now_ist = dt.datetime.now(IST)
        recent = (now_ist - dt.timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
        old = (now_ist - dt.timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:%S")
        future = (now_ist + dt.timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        self.assertTrue(se._candle_is_fresh(recent, "5m"))
        self.assertFalse(se._candle_is_fresh(old, "5m"))
        self.assertFalse(se._candle_is_fresh(future, "5m"))


class ScannerScanRealPath(unittest.TestCase):
    def test_scan_matches_with_fresh_ist_candles_and_ttl_is_computed(self):
        db = fresh_db()
        from app import scanner_engine as se
        now = dt.datetime.now(IST).replace(second=0, microsecond=0)
        now = now - dt.timedelta(minutes=now.minute % 5 + 5)           # last completed 5m bar
        rows = []
        for i in range(30):
            ts = (now - dt.timedelta(minutes=5 * (29 - i))).strftime("%Y-%m-%d %H:%M:%S")
            px = 100 + i
            rows.append({"exchange_segment": "nse_cm", "instrument_token": "77", "trading_symbol": "ZZZ", "timeframe": "5m",
                         "candle_at": ts, "open": px, "high": px + 1, "low": px - 1, "close": px, "volume": 1000})
        db.upsert_candles(rows)
        definition = {"side": "BUY", "timeframe": "5m",
                      "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
                      "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
                      "execution": {"product": "MIS"}, "risk": {"stop_loss_pct": 1, "target_pct": 2},
                      "position_sizing": {"quantity": 1}}
        out = se._scan([{"exchange_segment": "nse_cm", "instrument_token": "77", "trading_symbol": "ZZZ"}], definition, "5m")
        self.assertEqual(len(out), 1)
        self.assertRegex(se._expiry_for("5m", {}), r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$")
