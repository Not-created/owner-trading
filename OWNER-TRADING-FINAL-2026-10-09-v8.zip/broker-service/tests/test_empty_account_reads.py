"""Empty-account 'No <section> found for this client <id>' must not fail reconciliation/ARM."""
import unittest

from app import sdk_adapter as sa

MSG = "No holdings found for this client V883E"


class EmptyAccount(unittest.TestCase):
    def test_exact_message_is_empty_for_any_non_5xx_code(self):
        for body in ({"errMsg": MSG, "stCode": 424, "stat": "Not_Ok"}, {"errMsg": MSG, "status_code": 400, "stCode": 400},
                     {"errMsg": MSG, "stat": "Not_Ok"}, {"error": {"errMsg": MSG}, "status_code": 424},
                     {"Error": MSG, "StatusCode": 424}, {"errMsg": MSG + ".", "status_code": 424}):
            o = sa._empty_read_response(body, "holdings", {})
            self.assertIsNotNone(o, body)
            self.assertEqual((o.kind, o.data), (sa.OK, []))

    def test_everything_else_stays_a_failure(self):
        for body in ({"errMsg": MSG, "status_code": 500}, {"errMsg": MSG, "status_code": 503},
                     {"errMsg": "Dependency failed", "status_code": 424}, {"errMsg": "Invalid Session", "status_code": 401},
                     {"errMsg": "No orders found for this client X", "status_code": 424},      # other section
                     {"errMsg": MSG + " and some other failure text", "status_code": 424},
                     {"errMsg": "Not authenticated", "status_code": 424}):
            self.assertIsNone(sa._empty_read_response(body, "holdings", {}), body)

    def test_raised_exception_with_body_is_also_empty(self):
        class ApiException(Exception):
            status = 424
            body = '{"errMsg": "%s", "stat": "Not_Ok"}' % MSG
        o = sa._classify_read_exception(ApiException("424"), method="holdings", endpoint="x", section="holdings")
        self.assertEqual((o.kind, o.data), (sa.OK, []))


if __name__ == "__main__":
    unittest.main()
