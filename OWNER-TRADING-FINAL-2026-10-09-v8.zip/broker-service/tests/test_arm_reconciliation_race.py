import asyncio
import dataclasses
import unittest
from unittest.mock import patch, AsyncMock

from app import reconciliation, server
from tests.test_server import ServerBase, call

ARM = {'confirm': 'ARM LIVE TRADING'}
READY = {"ready": True, "armed": False, "gates": []}


class ArmRaceTests(ServerBase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        # module-level Lock binds to the first loop that contends it; use one per test loop
        self._lock_patch = patch.object(reconciliation, '_lock', asyncio.Lock())
        self._lock_patch.start()

    async def asyncTearDown(self):
        self._lock_patch.stop()
        await super().asyncTearDown()

    def _live(self):
        return patch.object(server, 'config', dataclasses.replace(server.config, trading_mode='LIVE'))

    async def test_arm_waits_for_running_reconciliation_before_evaluating(self):
        self.connect_fake()
        order = []

        def ev(*a, **k):
            order.append("evaluate"); return READY
        await reconciliation._lock.acquire()          # a pass is "running"
        with self._live(), patch("app.live_readiness.evaluate", side_effect=ev):
            task = asyncio.ensure_future(call('POST', '/risk/arm-live', ARM))
            await asyncio.sleep(0.05)
            self.assertEqual(order, [])               # not evaluated while the pass is running
            order.append("pass_finished"); reconciliation._lock.release()
            s, b = await asyncio.wait_for(task, 5)
        self.assertEqual((s, order), (200, ["pass_finished", "evaluate"]))
        self.assertTrue(self.db.is_live_armed())

    async def test_arm_gives_up_cleanly_if_reconciliation_never_finishes(self):
        self.connect_fake()
        async with reconciliation._lock:
            with self._live(), patch.object(server, 'ARM_RECONCILIATION_WAIT_SECONDS', 0.05):
                s, b = await call('POST', '/risk/arm-live', ARM)
        self.assertEqual(s, 409); self.assertTrue(b["reconciliation_running"])
        self.assertFalse(self.db.is_live_armed())

    async def test_disarm_during_arm_wins(self):
        self.connect_fake()
        await reconciliation._lock.acquire()
        with self._live(), patch("app.live_readiness.evaluate", return_value=READY):
            task = asyncio.ensure_future(call('POST', '/risk/arm-live', ARM))
            await asyncio.sleep(0.05)
            await call('POST', '/risk/disarm-live', {})
            reconciliation._lock.release()
            s, b = await asyncio.wait_for(task, 5)
        self.assertEqual(s, 409)
        self.assertFalse(self.db.is_live_armed())

    async def test_emergency_stop_during_arm_aborts(self):
        self.connect_fake()
        with self._live(), patch("app.live_readiness.evaluate", return_value=READY), \
             patch.object(self.db, "is_emergency_stop_active", return_value=True):
            s, b = await call('POST', '/risk/arm-live', ARM)
        self.assertEqual(s, 409); self.assertFalse(self.db.is_live_armed())

    async def test_readiness_endpoint_waits_for_idle(self):
        async with reconciliation._lock:
            with patch.object(server, 'READINESS_RECONCILIATION_WAIT_SECONDS', 0.05):
                s, b = await call('GET', '/live-readiness')
        self.assertEqual(s, 200)


if __name__ == "__main__":
    unittest.main()
