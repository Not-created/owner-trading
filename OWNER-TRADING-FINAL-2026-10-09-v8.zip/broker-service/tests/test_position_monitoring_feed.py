"""DISARM / candidate expiry must never starve an OPEN position of ticks."""
import unittest
from unittest.mock import patch

from app import sdk_adapter as a
from app import websocket_manager as wsm
from tests.dbutil import fresh_db
from tests.test_exit_request_lifecycle import _setup
from tests.test_websocket_manager import FakeFeed


class PositionFeedTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.m = wsm.WebSocketManager()
        self.feed = FakeFeed(); self.feed.is_connected = True
        self.m._market = self.feed
        self.tok = patch.object(a, "make_ws_token", lambda seg, tok: (seg, tok)); self.tok.start()
        self.pos = _setup(self.db)           # OPEN position on nse_cm|123

    async def asyncTearDown(self):
        self.tok.stop()

    async def test_releasing_last_strategy_owner_hands_subscription_to_open_position(self):
        await self.m.subscribe_many([("nse_cm", "123")], owner="strategy:1:universe")
        await self.m.release_owner("strategy:1:universe")
        self.assertIn(("nse_cm", "123"), self.m._subs)                    # still subscribed
        self.assertEqual(self.m.subscription_owners(("nse_cm", "123")), [f"position:{self.pos['id']}"])
        self.assertEqual(self.feed.subscription_count, 1)                 # no broker unsubscribe frame sent

    async def test_instrument_without_open_position_is_still_unsubscribed(self):
        await self.m.subscribe_many([("nse_cm", "999")], owner="strategy:1:universe")
        await self.m.release_owner("strategy:1:universe")
        self.assertNotIn(("nse_cm", "999"), self.m._subs)

    async def test_sync_subscribes_open_positions_and_releases_closed_ones(self):
        r = await self.m.sync_position_owners()
        self.assertEqual((r["positions"], r["subscribed"], r["errors"]), (1, 1, []))
        self.assertIn(("nse_cm", "123"), self.m._subs)
        self.db.apply_trade_to_algo_position  # position still open
        self.db.update_algo_position_from_broker(self.pos["id"], 0, None)   # broker says flat -> CLOSED
        r = await self.m.sync_position_owners()
        self.assertEqual(r["released"], 1)
        self.assertNotIn(("nse_cm", "123"), self.m._subs)

    async def test_restore_after_restart_resubscribes_open_positions_without_armed_strategy(self):
        r = await self.m.restore_armed_strategy_subscriptions()
        self.assertEqual(r["positions"]["subscribed"], 1)
        self.assertIn(("nse_cm", "123"), self.m._subs)


if __name__ == "__main__":
    unittest.main()
