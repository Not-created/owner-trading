"""Regression tests: OFFICIAL margin_required response shape and 5xx handling on
state-changing calls (docs/functions/portfolio/margin_required.md, SDK 3.0.7)."""
import unittest

from app import sdk_adapter as sa

OFFICIAL = {"data": {"avlCash": "38.190000", "totMrgnUsd": "34.280000", "mrgnUsd": "18.780000",
                     "ordMrgn": "15.500000", "rmsVldtd": "OK", "reqdMrgn": "0.000000",
                     "avlMrgn": "0.000000", "insufFund": "0.000000", "stat": "Ok", "stCode": 200}}


def _with(**over):
    d = dict(OFFICIAL["data"]); d.update(over)
    return {"data": d}


class MarginParserTests(unittest.TestCase):
    def test_official_sample_parses_order_margin(self):
        p = sa.parse_margin_required(OFFICIAL)
        self.assertEqual(p["required_margin"], 15.5)
        self.assertEqual(p["available_cash"], 38.19)
        self.assertTrue(p["rms_validated"])

    def test_required_is_max_of_ordMrgn_and_reqdMrgn(self):
        self.assertEqual(sa.parse_margin_required(_with(reqdMrgn="20.5"))["required_margin"], 20.5)

    def test_insufficient_funds_blocks(self):
        with self.assertRaises(sa.MarginUnavailableError):
            sa.parse_margin_required(_with(insufFund="5.00"))

    def test_rms_not_ok_blocks(self):
        with self.assertRaises(sa.MarginUnavailableError):
            sa.parse_margin_required(_with(rmsVldtd="REJECTED"))

    def test_nested_error_blocks_even_though_outer_is_ok(self):
        for bad in ({"data": {"stat": "Not_Ok", "stCode": 1021, "errMsg": "RMS"}},
                    {"data": {"ordMrgn": "1", "stat": "Ok", "stCode": 500}},
                    {"data": {"errMsg": "boom"}}):
            with self.assertRaises(sa.MarginUnavailableError):
                sa.parse_margin_required(bad)

    def test_missing_unparseable_or_negative_order_margin_blocks(self):
        for bad in ({"data": {"stat": "Ok", "stCode": 200}}, _with(ordMrgn="abc"), _with(ordMrgn=""),
                    _with(ordMrgn="-1"), _with(ordMrgn="nan"), {"data": []}, None, "x", []):
            with self.assertRaises(sa.MarginUnavailableError):
                sa.parse_margin_required(bad)

    def test_legacy_guessed_keys_are_not_accepted(self):
        for bad in ({"margin": "1000"}, {"data": {"margin": "1000"}}, {"data": [{"margin": "1000"}]}):
            with self.assertRaises(sa.MarginUnavailableError):
                sa.parse_margin_required(bad)

    def test_order_service_helper_returns_none_when_undeterminable(self):
        from app import order_service as osv
        self.assertEqual(osv._extract_margin_required(OFFICIAL), 15.5)
        self.assertIsNone(osv._extract_margin_required({"margin": "1"}))
        self.assertIsNone(osv._extract_margin_required(_with(insufFund="1")))


class FiveXXStateChangingTests(unittest.TestCase):
    def test_http_5xx_on_order_call_is_unknown_not_rejected(self):
        for code in (500, 502, 503, 504):
            o = sa.classify({"stCode": code, "errMsg": "Not able to communicate with OMS", "stat": "Not_Ok",
                             "status_code": code}, expect_order_id=True, state_changing=True)
            self.assertEqual(o.kind, sa.UNKNOWN, code)

    def test_http_5xx_apiexception_on_order_call_is_unknown(self):
        class ApiException(Exception):
            status = 502
        o = sa.classify({"error": ApiException("bad gateway")}, expect_order_id=True, state_changing=True)
        self.assertEqual(o.kind, sa.UNKNOWN)

    def test_4xx_and_reads_stay_definitive(self):
        o = sa.classify({"stCode": 1021, "errMsg": "RMS: Margin exceeds", "stat": "Not_Ok", "status_code": 400},
                        expect_order_id=True, state_changing=True)
        self.assertEqual(o.kind, sa.REJECTED)
        o = sa.classify({"stCode": 503, "errMsg": "down", "stat": "Not_Ok", "status_code": 503}, state_changing=False)
        self.assertEqual(o.kind, sa.REJECTED)
        self.assertEqual(o.code, "503")


if __name__ == "__main__":
    unittest.main()
