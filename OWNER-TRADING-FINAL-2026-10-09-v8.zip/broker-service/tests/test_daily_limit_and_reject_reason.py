import unittest

from app import order_service as osv
from app import scanner_engine as se
from app import sdk_adapter as sa
from tests.dbutil import fresh_db


def mk(db, oid, status, broker_id=None, role="MANUAL"):
    db.create_order(internal_order_id=oid, trading_symbol="ABC-EQ", exchange_segment="nse_cm", transaction_type="B",
                    order_type="L", product="CNC", validity="DAY", quantity=1, price=1.0, trigger_price=None, mode="LIVE",
                    status="SUBMITTING", client_tag="TAG" + oid.replace("-", "X"), instrument_token="500", order_role=role)
    db.update_order(internal_order_id=oid, status=status, **({"broker_order_id": broker_id} if broker_id else {}))


class DailyLimit(unittest.TestCase):
    def test_rejected_attempts_do_not_use_the_daily_allowance(self):
        db = fresh_db()
        mk(db, "r1", "REJECTED"); mk(db, "r2", "REJECTED"); mk(db, "r3", "REJECTED")
        self.assertEqual(db.count_orders_today(mode="LIVE"), 0)
        mk(db, "ok1", "SUBMITTED", "B1"); mk(db, "ok2", "COMPLETE", "B2")
        self.assertEqual(db.count_orders_today(mode="LIVE"), 2)
        mk(db, "pend", "PENDING_RECONCILE")                          # unknown outcome may exist at the broker: counts
        self.assertEqual(db.count_orders_today(mode="LIVE"), 3)

    def test_runaway_rejections_are_still_capped(self):
        from unittest.mock import patch
        db = fresh_db()
        for i in range(10):
            mk(db, f"rej{i}", "REJECTED")
        self.assertEqual(db.count_rejected_orders_today(), 10)
        rs = dict(db.get_risk_settings()); rs["max_orders_per_day"] = 2
        order = {"quantity": 1, "order_role": "MANUAL", "exchange_segment": "nse_cm", "instrument_token": "500",
                 "trading_symbol": "ABC-EQ", "price": 1.0, "order_type": "L", "transaction_type": "B", "product": "MIS"}
        with patch.object(osv._db, "get_risk_settings", return_value=rs):
            with self.assertRaisesRegex(osv.RiskLimitExceededError, "rejected today"):
                osv._check_risk_limits(order, "LIVE")

    def test_below_the_cap_rejections_do_not_block(self):
        from unittest.mock import patch
        db = fresh_db()
        for i in range(3):
            mk(db, f"rej{i}", "REJECTED")
        rs = dict(db.get_risk_settings()); rs["max_orders_per_day"] = 2
        for k in ("max_order_value", "max_total_exposure", "max_strategy_exposure", "max_strategy_capital", "max_instrument_exposure"):
            rs[k] = None
        order = {"quantity": 1, "order_role": "MANUAL", "exchange_segment": "nse_cm", "instrument_token": "500",
                 "trading_symbol": "ABC-EQ", "price": 1.0, "order_type": "L", "transaction_type": "B", "product": "MIS"}
        with patch.object(osv._db, "get_risk_settings", return_value=rs):
            try:
                osv._check_risk_limits(order, "LIVE")
            except osv.RiskLimitExceededError as exc:
                self.assertNotIn("Daily order limit", str(exc)); self.assertNotIn("rejected today", str(exc))


class RejectReason(unittest.TestCase):
    def test_unauthorized_reason_has_code_and_actionable_hint(self):
        o = sa.Outcome(sa.REJECTED, message="unauthorized", code="401",
                       extra={"broker_diagnostics": {"http_status": 401, "kotak_st_code": None}})
        text = osv._broker_reject_reason(o)
        self.assertIn("HTTP 401", text); self.assertIn("whitelisted", text); self.assertLessEqual(len(text), 480)

    def test_ordinary_rejection_keeps_the_kotak_text_without_hint(self):
        o = sa.Outcome(sa.REJECTED, message="RMS: Margin Exceeds", code="1021",
                       extra={"broker_diagnostics": {"http_status": 400, "kotak_st_code": 1021}})
        text = osv._broker_reject_reason(o)
        self.assertTrue(text.startswith("RMS: Margin Exceeds [HTTP 400, stCode 1021]"))
        self.assertNotIn("whitelisted", text)


class HistoryWindow(unittest.TestCase):
    def test_single_small_chunk(self):
        from app import backtest_service as bs
        for tf, need in (("1d", 52), ("15m", 52), ("5m", 202), ("1h", 52), ("1m", 40)):
            d = se.history_calendar_days(tf, need)
            self.assertGreaterEqual(d, 3)
            self.assertLessEqual(d, bs.HISTORICAL_MAX_DAYS[tf] - 1)
        self.assertEqual(se.history_calendar_days("15m", 52), 11)    # ~3 trading days of 25 bars + weekend slack


if __name__ == "__main__":
    unittest.main()
