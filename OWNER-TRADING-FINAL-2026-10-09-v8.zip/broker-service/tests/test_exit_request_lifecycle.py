"""Protective exits must never be blocked forever by one failed attempt."""
import asyncio
import unittest

from tests.dbutil import fresh_db


def _setup(db):
    st = db.create_strategy("exitlife")
    definition = {
        "side": "BUY", "timeframe": "5m",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
        "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 90}]},
        "execution": {"product": "MIS"},
        "risk": {"stop_loss_pct": 1, "target_pct": 2, "partial_exit_pct": 50},
        "position_sizing": {"quantity": 10},
    }
    v = db.save_strategy_version(st["id"], definition)
    sid = db.record_signal(strategy_version_id=v["id"], exchange_segment="nse_cm", instrument_token="123",
                           trading_symbol="ABC", timeframe="5m", side="BUY", signal_price=100, conditions={},
                           risk={}, status="ORDERED", candle_at="2026-09-24 10:00:00")
    db.create_order(internal_order_id="entry-1", trading_symbol="ABC", exchange_segment="nse_cm",
                    transaction_type="B", order_type="MKT", product="MIS", validity="DAY", quantity=10,
                    price=None, trigger_price=None, mode="LIVE", status="SUBMITTED", client_tag="TAGentry1",
                    instrument_token="123", order_role="ENTRY", signal_id=sid)
    db.apply_trade_to_algo_position("entry-1", 10, 100, "B")
    return db.list_algo_positions()[0]


class ExitLifecycle(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        import app.exit_engine as ee
        self.ee = ee
        ee._inflight.clear(); ee._last_attempt.clear()
        self._cd = ee.EXIT_RETRY_COOLDOWN_SECONDS
        ee.EXIT_RETRY_COOLDOWN_SECONDS = 0.0
        self.pos = _setup(self.db)
        self.calls = []
        self._orig = ee.order_service.place_order

    def tearDown(self):
        self.ee.order_service.place_order = self._orig
        self.ee.EXIT_RETRY_COOLDOWN_SECONDS = self._cd

    def _tick(self, price=98.0):
        asyncio.run(self.ee.on_tick(exchange_segment="nse_cm", instrument_token="123", price=price))

    def _install(self, fn):
        async def fake(payload):
            self.calls.append(payload)
            return fn(payload)
        self.ee.order_service.place_order = fake

    def _make_order(self, payload, status):
        self.db.create_order(internal_order_id=payload["idempotency_key"], trading_symbol="ABC", exchange_segment="nse_cm",
                             transaction_type="S", order_type="MKT", product="MIS", validity="DAY",
                             quantity=payload["quantity"], price=None, trigger_price=None, mode="LIVE", status="SUBMITTING",
                             client_tag="TG" + payload["idempotency_key"][-8:].replace("-", "X"), instrument_token="123",
                             order_role="EXIT", algo_position_id=payload["algo_position_id"], parent_order_id="entry-1")
        self.db.update_order(internal_order_id=payload["idempotency_key"], status=status, status_reason="blocked")
        return self.db.get_order(payload["idempotency_key"])

    def test_rejected_exit_is_released_and_retried_with_a_new_request_key(self):
        self._install(lambda p: self._make_order(p, "REJECTED"))
        self._tick(); self.assertFalse(self.db.has_pending_exit(self.pos["id"]))
        self._tick()
        self.assertEqual(len(self.calls), 2)
        self.assertNotEqual(self.calls[0]["idempotency_key"], self.calls[1]["idempotency_key"])

    def test_exception_before_broker_releases_the_request(self):
        def boom(p): raise ValueError("blocked by gate")
        self._install(boom)
        self._tick(); self.assertFalse(self.db.has_pending_exit(self.pos["id"]))
        self._tick(); self.assertEqual(len(self.calls), 2)

    def test_accepted_exit_blocks_duplicates_until_broker_cancels_it(self):
        self._install(lambda p: self._make_order(p, "SUBMITTED"))
        self._tick(); self._tick()
        self.assertEqual(len(self.calls), 1)                       # no duplicate while pending
        self.assertTrue(self.db.has_pending_exit(self.pos["id"]))
        # broker later cancels it (order feed / reconciliation path)
        self.db.apply_broker_order_state(internal_order_id=self.calls[0]["idempotency_key"], status="CANCELLED", broker_status="cancelled")
        self.assertFalse(self.db.has_pending_exit(self.pos["id"]))
        self._tick(); self.assertEqual(len(self.calls), 2)

    def test_broker_rejection_after_acceptance_releases_exit(self):
        self._install(lambda p: self._make_order(p, "SUBMITTED"))
        self._tick()
        self.db.apply_broker_order_state(internal_order_id=self.calls[0]["idempotency_key"], status="REJECTED", broker_status="rejected")
        self.assertFalse(self.db.has_pending_exit(self.pos["id"]))

    def test_unknown_outcome_stays_pending_and_is_not_resent(self):
        self._install(lambda p: self._make_order(p, "PENDING_RECONCILE"))
        self._tick(); self._tick(); self._tick()
        self.assertEqual(len(self.calls), 1)
        self.assertTrue(self.db.has_pending_exit(self.pos["id"]))

    def test_stale_requested_exit_from_a_crash_is_released(self):
        eid = self.db.record_exit_request(self.pos["id"], "STOP_LOSS", 10, 99.0)
        self.assertTrue(self.db.has_pending_exit(self.pos["id"]))
        self.assertEqual(self.db.expire_stale_exit_requests(self.pos["id"], max_age_seconds=120), 0)  # fresh: untouched
        self.assertEqual(self.db.expire_stale_exit_requests(self.pos["id"], max_age_seconds=-5), 1)
        self.assertFalse(self.db.has_pending_exit(self.pos["id"]))

    def test_stale_requested_exit_adopts_an_existing_live_order(self):
        eid = self.db.record_exit_request(self.pos["id"], "STOP_LOSS", 10, 99.0)
        self._make_order({"idempotency_key": f"exit-{self.pos['id']}-x{eid}", "quantity": 10, "algo_position_id": self.pos["id"]}, "SUBMITTED")
        self.db.expire_stale_exit_requests(self.pos["id"], max_age_seconds=-5)
        self.assertTrue(self.db.has_pending_exit(self.pos["id"]))   # adopted, not duplicated

    def test_stop_loss_exits_full_quantity_even_with_partial_exit_pct(self):
        self._install(lambda p: self._make_order(p, "SUBMITTED"))
        self._tick(98.0)                                           # stop (1%) hit
        self.assertEqual(self.calls[0]["quantity"], 10)

    def test_target_honours_partial_exit_pct(self):
        self._install(lambda p: self._make_order(p, "SUBMITTED"))
        self._tick(103.0)
        self.assertEqual(self.calls[0]["quantity"], 5)

    def test_cooldown_prevents_per_tick_hammering(self):
        self.ee.EXIT_RETRY_COOLDOWN_SECONDS = 60.0
        self.ee._last_attempt.clear()
        self._install(lambda p: self._make_order(p, "REJECTED"))
        self._tick(); self._tick(); self._tick()
        self.assertEqual(len(self.calls), 1)


if __name__ == "__main__":
    unittest.main()
