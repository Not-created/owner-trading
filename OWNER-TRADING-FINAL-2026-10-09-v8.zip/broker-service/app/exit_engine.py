"""LIVE protective-exit supervisor.

Stop/target/trailing decisions use every received SFeed tick. Strategy/time
exits may additionally use completed candles. No simulator is involved.
"""
from __future__ import annotations
import asyncio,datetime as dt,logging,time
from . import db,strategy_engine,order_service
logger=logging.getLogger('owner_trading.exit')
_inflight:set[int]=set()
_last_attempt:dict[int,float]={}
EXIT_RETRY_COOLDOWN_SECONDS=5.0
# Protective exits must flatten the whole remaining position; only a TARGET or a
# strategy exit may honour a configured partial_exit_pct.
_PARTIAL_ALLOWED_REASONS=('TARGET','STRATEGY_EXIT')  # MIS_SQUAREOFF always flattens
_lock=asyncio.Lock()

def derive_levels(definition,entry,side='BUY',atr_value=None):
    """Derive immutable protective levels at position creation/recovery.

    ATR stops are calculated from the entry-time ATR supplied by the candle
    engine/reconciliation path. A missing/invalid ATR never invents a stop.
    """
    risk=definition.get('risk',{}) or {};side=str(side).upper();stop=risk.get('stop_loss');target=risk.get('target')
    if stop is None and risk.get('stop_atr_multiple') is not None and atr_value is not None:
        try:
            mult=float(risk['stop_atr_multiple']); av=float(atr_value)
            if mult > 0 and av > 0:
                stop=entry-mult*av if side=='BUY' else entry+mult*av
        except (TypeError,ValueError):
            pass
    if stop is None and risk.get('stop_loss_pct') is not None:
        stop=entry*(1-float(risk['stop_loss_pct'])/100 if side=='BUY' else 1+float(risk['stop_loss_pct'])/100)
    if target is None and risk.get('target_pct') is not None:
        target=entry*(1+float(risk['target_pct'])/100 if side=='BUY' else 1-float(risk['target_pct'])/100)
    return stop,target

TIMEFRAME_MINUTES={"1m":1,"3m":3,"5m":5,"10m":10,"15m":15,"30m":30,"1h":60,"1d":1440}

def _time_exit_due(position,risk,now,timeframe="5m"):
    bars=risk.get('time_exit_bars')
    if not bars or not position.get('opened_at'):return False
    try:
        opened=dt.datetime.fromisoformat(str(position['opened_at']).replace(' ','T')).replace(tzinfo=dt.timezone.utc)
        minutes=int(bars)*TIMEFRAME_MINUTES.get(str(timeframe),5)
        return (now-opened).total_seconds() >= minutes*60
    except (TypeError,ValueError):return False

async def evaluate_position(position, *, price:float, timestamp=None):
    pid=int(position['id'])
    if position.get('status')!='OPEN' or not position.get('remaining_quantity'):return
    if db.has_pending_exit(pid):
        # A request orphaned by a crash/restart must never block protection forever.
        db.expire_stale_exit_requests(pid)
        if db.has_pending_exit(pid):return
    version=db.get_strategy_version(position.get('strategy_version_id') or 0)
    if not version:return
    definition=version['definition'];side=str(definition.get('side','BUY')).upper();risk=definition.get('risk',{}) or {};timeframe=str(definition.get('timeframe') or '5m')
    stop=position.get('stop_loss');target=position.get('target')
    trailing=position.get('trailing_stop');trail_pct=risk.get('trailing_stop_pct')
    now=timestamp or dt.datetime.now(dt.timezone.utc)
    db.update_algo_position_risk(pid,last_price=float(price))

    # Monotonic trailing stop: it can tighten, never loosen.
    if trail_pct is not None:
        pct=float(trail_pct)/100
        candidate=float(price)*(1-pct if side=='BUY' else 1+pct)
        if trailing is None:
            trailing=candidate
        elif side=='BUY':
            trailing=max(float(trailing),candidate)
        else:
            trailing=min(float(trailing),candidate)
        db.update_algo_position_risk(pid,trailing_stop=trailing)

    reason=None;trigger=None
    if side=='BUY':
        if stop is not None and float(price)<=float(stop):reason='STOP_LOSS';trigger=float(stop)
        elif target is not None and float(price)>=float(target):reason='TARGET';trigger=float(target)
        elif trailing is not None and float(price)<=float(trailing):reason='TRAILING_STOP';trigger=float(trailing)
    else:
        if stop is not None and float(price)>=float(stop):reason='STOP_LOSS';trigger=float(stop)
        elif target is not None and float(price)<=float(target):reason='TARGET';trigger=float(target)
        elif trailing is not None and float(price)>=float(trailing):reason='TRAILING_STOP';trigger=float(trailing)

    if reason is None and _time_exit_due(position,risk,now,timeframe):
        reason='TIME_EXIT';trigger=float(price)

    # Strategy-defined exits are evaluated only on completed candle history.
    if reason is None:
        candles=db.recent_candles(position['exchange_segment'],position['instrument_token'],timeframe,250)
        if len(candles)>=20:
            ok,_=strategy_engine.evaluate_exit(definition,candles)
            if ok:reason='STRATEGY_EXIT';trigger=float(price)
    if reason is None:return

    await _request_exit(position,definition,side,risk,reason,trigger)

async def _request_exit(position,definition,side,risk,reason,trigger):
    pid=int(position['id'])
    async with _lock:
        if pid in _inflight or db.has_pending_exit(pid):return
        # After a failed attempt (blocked/rejected) retry, but not on every tick.
        if time.monotonic()-_last_attempt.get(pid,-1e9) < EXIT_RETRY_COOLDOWN_SECONDS:return
        _inflight.add(pid);_last_attempt[pid]=time.monotonic()
    try:
        qty=int(position['remaining_quantity'])
        partial_pct=float(risk.get('partial_exit_pct') or 100) if reason in _PARTIAL_ALLOWED_REASONS else 100.0
        request_qty=max(1,min(qty,int(round(qty*partial_pct/100))))
        exit_id=db.record_exit_request(pid,reason,request_qty,trigger)
        try:
            order=await order_service.place_order({
                'trading_symbol':position['trading_symbol'],
                'exchange_segment':position['exchange_segment'],
                'transaction_type':'S' if side=='BUY' else 'B',
                'order_type':'MKT',
                'product':definition.get('execution',{}).get('product','MIS'),
                'validity':'DAY','quantity':request_qty,
                'instrument_token':position['instrument_token'],
                'algo_position_id':pid,'order_role':'EXIT',
                'parent_order_id':position.get('entry_order_id'),
                # One key per exit REQUEST: a crash-replay of this request cannot double-send,
                # while a later retry after a rejected/cancelled attempt is a new request.
                'idempotency_key':f"exit-{pid}-x{exit_id}",
            })
            if order:
                status=db.mark_exit_order(pid,order.get('internal_order_id'),exit_id)
                if status=='FAILED':
                    logger.warning('Exit order for %s ended %s (%s); exit request released for retry.',position['trading_symbol'],order.get('status'),order.get('status_reason'))
            else:
                db.fail_exit_request(exit_id)
        except Exception as exc:
            # Nothing reached the broker (validation/risk/gate error): release the request so the
            # next tick can retry. An UNKNOWN broker outcome does NOT raise -- it returns an order
            # in PENDING_RECONCILE, which stays pending until reconciliation resolves it.
            db.fail_exit_request(exit_id)
            logger.warning('Exit order blocked for %s: %s',position['trading_symbol'],exc)
    finally:
        async with _lock:_inflight.discard(pid)

async def on_tick(*,exchange_segment,instrument_token,price,timestamp=None):
    positions=db.list_algo_positions()
    for position in positions:
        if position['exchange_segment']==exchange_segment and str(position['instrument_token'])==str(instrument_token):
            await evaluate_position(position,price=float(price),timestamp=timestamp)

def _position_product(definition):
    return str((definition.get('execution') or {}).get('product','MIS')).upper()

async def square_off_due(now=None):
    """Close every open MIS algo position from the configured square-off time until the close.

    Runs on a timer (not on ticks) so an illiquid stock with no ticks is still closed. It uses the
    normal exit path: the same order service, idempotent per request, retry cooldown, and a
    pending/UNKNOWN exit is never duplicated. CNC/NRML positions are never touched.
    """
    from .market_session import mis_squareoff_due
    if not mis_squareoff_due(now):
        return {"due":False,"requested":0}
    requested=0
    for position in db.list_algo_positions():
        pid=int(position['id'])
        if position.get('status')!='OPEN' or not position.get('remaining_quantity'):continue
        version=db.get_strategy_version(position.get('strategy_version_id') or 0)
        if not version:continue
        definition=version['definition']
        if _position_product(definition)!='MIS':continue
        if db.has_pending_exit(pid):
            db.expire_stale_exit_requests(pid)
            if db.has_pending_exit(pid):continue
        side=str(definition.get('side','BUY')).upper();risk=definition.get('risk',{}) or {}
        price=position.get('last_price') or position.get('average_entry')
        try:
            await _request_exit(position,definition,side,risk,'MIS_SQUAREOFF',float(price) if price else None)
            requested+=1
        except Exception as exc:  # noqa: BLE001 -- one failing position must not stop the others
            logger.warning('MIS square-off request failed for %s: %s',position.get('trading_symbol'),exc)
    return {"due":True,"requested":requested}
