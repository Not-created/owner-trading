"""Indian cash-market session, exchange holidays and MIS time rules (all Asia/Kolkata).

* Continuous session 09:15-15:30 on weekdays that are not exchange holidays.
* Exchange holidays are NOT hard-coded (NSE publishes a new list every year and a wrong built-in
  list would be worse than none). The owner lists them in ``MARKET_HOLIDAYS`` (comma separated
  YYYY-MM-DD) and/or in ``<BROKER_DATA_DIR>/market-holidays.txt`` (one date per line, ``#`` comments).
* MIS (intraday) rules, configurable via environment:
    ``MIS_ENTRY_CUTOFF_IST`` (default 15:00) -- no NEW MIS entries at/after this time.
    ``MIS_SQUAREOFF_IST``    (default 15:15) -- open MIS algo positions are closed from this time,
                                                before Kotak's own forced square-off (with charges).
"""
from __future__ import annotations
import datetime as dt
import os
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
OPEN = dt.time(9, 15)
CLOSE = dt.time(15, 30)


def _hhmm(value, default: dt.time) -> dt.time:
    try:
        h, m = str(value).strip().split(":")
        t = dt.time(int(h), int(m))
        return t
    except (AttributeError, TypeError, ValueError):
        return default


def _times() -> tuple[dt.time, dt.time]:
    cutoff = _hhmm(os.environ.get("MIS_ENTRY_CUTOFF_IST"), dt.time(15, 0))
    square = _hhmm(os.environ.get("MIS_SQUAREOFF_IST"), dt.time(15, 15))
    # Keep the ordering sane: OPEN < cutoff <= square-off < CLOSE; otherwise fall back to defaults.
    if not (OPEN < cutoff <= square < CLOSE):
        return dt.time(15, 0), dt.time(15, 15)
    return cutoff, square


_holiday_cache: dict = {"key": None, "dates": frozenset()}


def _holiday_file() -> str:
    explicit = os.environ.get("MARKET_HOLIDAYS_FILE")
    if explicit:
        return explicit
    try:
        from .config import config
        return os.path.join(config.data_dir, "market-holidays.txt")
    except Exception:  # noqa: BLE001
        return ""


def _parse_dates(text: str) -> set[dt.date]:
    out: set[dt.date] = set()
    for raw in str(text).replace(",", "\n").replace(";", "\n").splitlines():
        token = raw.split("#", 1)[0].strip()
        if not token:
            continue
        try:
            out.add(dt.date.fromisoformat(token))
        except ValueError:
            continue
    return out


def holidays() -> frozenset:
    path = _holiday_file()
    try:
        mtime = os.path.getmtime(path) if path and os.path.exists(path) else None
    except OSError:
        mtime = None
    key = (os.environ.get("MARKET_HOLIDAYS", ""), path, mtime)
    if _holiday_cache["key"] != key:
        dates = _parse_dates(os.environ.get("MARKET_HOLIDAYS", ""))
        if mtime is not None:
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    dates |= _parse_dates(fh.read())
            except OSError:
                pass
        _holiday_cache.update(key=key, dates=frozenset(dates))
    return _holiday_cache["dates"]


def session_state(now: dt.datetime | None = None) -> dict:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    weekday = local.weekday() < 5
    holiday = local.date() in holidays()
    in_hours = OPEN <= local.time().replace(tzinfo=None) < CLOSE
    is_open = bool(weekday and not holiday and in_hours)
    cutoff, square = _times()
    reason = "OPEN" if is_open else ("WEEKEND" if not weekday else ("HOLIDAY" if holiday else "OUTSIDE_SESSION"))
    return {
        "open": is_open,
        "timezone": "Asia/Kolkata",
        "local_time": local.isoformat(),
        "weekday": weekday,
        "holiday": holiday,
        "continuous_session": "09:15-15:30",
        "mis_entry_cutoff": cutoff.strftime("%H:%M"),
        "mis_squareoff": square.strftime("%H:%M"),
        "reason": reason,
    }


def mis_entries_allowed(now: dt.datetime | None = None) -> tuple[bool, str]:
    """May a NEW MIS entry be placed right now? (Never affects exits.)"""
    st = session_state(now)
    if not st["open"]:
        return False, f"market session is not open ({st['reason']})"
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    cutoff, _ = _times()
    if local.time().replace(tzinfo=None) >= cutoff:
        return False, f"MIS entries are closed after {cutoff.strftime('%H:%M')} IST"
    return True, "ok"


def mis_squareoff_due(now: dt.datetime | None = None) -> bool:
    """True from the configured square-off time until the close on a trading day."""
    st = session_state(now)
    if not st["open"]:
        return False
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    _, square = _times()
    return local.time().replace(tzinfo=None) >= square
