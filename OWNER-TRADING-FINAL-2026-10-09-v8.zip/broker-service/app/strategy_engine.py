"""Canonical strategy DSL, indicators, sizing and historical backtest engine.

The same validated definition is used by scanner/live/backtest.  This module
contains no broker calls and never creates live orders.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Any

# timeframe -> bar length in minutes (membership checks and minute lookups share one source)
TIMEFRAMES={"1m":1,"3m":3,"5m":5,"10m":10,"15m":15,"30m":30,"1h":60,"1d":1440}
OPS={">",">=","<","<=","==","!=","cross_above","cross_below"}
SIDES={"BUY","SELL"}
PRODUCTS={"CNC","NRML","MIS","MTF"}
INDICATOR_NAMES={"close","open","high","low","volume","sma","ema","rsi","atr","macd","macd_signal","macd_hist","adx","vwap","bb_mid","bb_upper","bb_lower","volume_sma"}


def _num(v):
    try:
        value = float(v)
    except (TypeError,ValueError):
        return None
    return value if math.isfinite(value) else None

def sma(values,n):
    n=int(n); return sum(values[-n:])/n if len(values)>=n and n>0 else None

def ema(values,n):
    n=int(n)
    if len(values)<n or n<=0:return None
    k=2/(n+1); e=sum(values[:n])/n
    for v in values[n:]: e=v*k+e*(1-k)
    return e

def rsi(values,n=14):
    n=int(n)
    if n<=0 or len(values)<n+1:return None
    deltas=[float(b)-float(a) for a,b in zip(values[:-1],values[1:])]
    gains=[max(d,0.0) for d in deltas]; losses=[max(-d,0.0) for d in deltas]
    ag=sum(gains[:n])/n; al=sum(losses[:n])/n
    for i in range(n,len(deltas)):
        ag=((ag*(n-1))+gains[i])/n; al=((al*(n-1))+losses[i])/n
    if al==0: return 100.0 if ag>0 else 50.0
    rs=ag/al
    return 100-(100/(1+rs))

def atr(candles,n=14):
    n=int(n)
    if n<=0 or len(candles)<n+1:return None
    trs=[]
    for prev,c in zip(candles[:-1],candles[1:]):
        trs.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
    value=sum(trs[:n])/n
    for tr in trs[n:]: value=((value*(n-1))+tr)/n
    return value


def macd(values,fast=12,slow=26,signal=9):
    if len(values)<slow+signal:return (None,None,None)
    series=[]
    for i in range(slow,len(values)+1):
        f=ema(values[:i],fast); s=ema(values[:i],slow)
        if f is not None and s is not None:series.append(f-s)
    line=series[-1] if series else None
    sig=ema(series,signal) if len(series)>=signal else None
    return line,sig,(line-sig if line is not None and sig is not None else None)

def adx(candles,n=14):
    n=int(n)
    if n<=0 or len(candles)<(2*n+1):return None
    tr=[]; plus=[]; minus=[]
    for prev,c in zip(candles[:-1],candles[1:]):
        up=float(c['high'])-float(prev['high']); down=float(prev['low'])-float(c['low'])
        tr.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
        plus.append(up if up>down and up>0 else 0.0); minus.append(down if down>up and down>0 else 0.0)
    atr_v=sum(tr[:n])/n; p_dm=sum(plus[:n])/n; m_dm=sum(minus[:n])/n; dx=[]
    def dx_value():
        if atr_v==0:return 0.0
        pdi=100*p_dm/atr_v; mdi=100*m_dm/atr_v; den=pdi+mdi
        return 100*abs(pdi-mdi)/den if den else 0.0
    dx.append(dx_value())
    for i in range(n,len(tr)):
        atr_v=((atr_v*(n-1))+tr[i])/n; p_dm=((p_dm*(n-1))+plus[i])/n; m_dm=((m_dm*(n-1))+minus[i])/n
        dx.append(dx_value())
    if len(dx)<n:return None
    adx_v=sum(dx[:n])/n
    for x in dx[n:]: adx_v=((adx_v*(n-1))+x)/n
    return adx_v

def vwap(candles):
    if not candles:return None
    last_day=str(candles[-1].get('candle_at',''))[:10]
    session=[c for c in candles if str(c.get('candle_at',''))[:10]==last_day]
    pv=0.0; vol=0.0
    for c in session:
        v=float(c.get('volume') or 0); typical=(float(c['high'])+float(c['low'])+float(c['close']))/3
        pv+=typical*v; vol+=v
    return pv/vol if vol else None

def indicators(candles):
    closes=[float(x['close']) for x in candles]; opens=[float(x['open']) for x in candles]
    highs=[float(x['high']) for x in candles]; lows=[float(x['low']) for x in candles]; vols=[float(x.get('volume') or 0) for x in candles]
    out={'close':closes[-1] if closes else None,'open':opens[-1] if opens else None,'high':highs[-1] if highs else None,'low':lows[-1] if lows else None,'volume':vols[-1] if vols else None}
    for n in (5,9,20,50,100,200):out[f'sma{n}']=sma(closes,n);out[f'ema{n}']=ema(closes,n)
    out['rsi14']=rsi(closes,14);out['atr14']=atr(candles,14)
    ml,ms,mh=macd(closes);out.update({'macd':ml,'macd_signal':ms,'macd_hist':mh})
    out['adx14']=adx(candles,14);out['vwap']=vwap(candles)
    if len(closes)>=20:
        m=sma(closes,20);sd=(sum((x-m)**2 for x in closes[-20:])/20)**0.5;out['bb_mid']=m;out['bb_upper']=m+2*sd;out['bb_lower']=m-2*sd
    out['volume_sma20']=sma(vols,20)
    # Common price-action fields for no-code conditions.
    if candles:
        c=candles[-1]; out['body']=abs(float(c['close'])-float(c['open']));out['range']=float(c['high'])-float(c['low']);out['bullish_candle']=1 if float(c['close'])>float(c['open']) else 0;out['bearish_candle']=1 if float(c['close'])<float(c['open']) else 0
    return out


def _value(name,vals,ind):
    if isinstance(name,(int,float)):return float(name)
    if name is None:return None
    key=str(name).lower().strip()
    n=_num(key)
    if n is not None:return n
    return vals.get(key,ind.get(key))


def eval_condition(cond,candles,ind=None):
    if not candles:return False,'no candle data'
    ind=ind or indicators(candles)
    c=candles[-1]; vals={'price':float(c['close']),'close':float(c['close']),'open':float(c['open']),'high':float(c['high']),'low':float(c['low']),'volume':float(c.get('volume') or 0),'previous_close':float(candles[-2]['close']) if len(candles)>1 else None}
    op=str(cond.get('operator') or cond.get('op') or '>').lower(); left=_value(cond.get('left'),vals,ind);right=_value(cond.get('right'),vals,ind)
    if left is None or right is None:return False,f'missing operand: {cond.get("left")} {op} {cond.get("right")}'
    if op in ('cross_above','cross_below') and len(candles)>=2:
        prev=indicators(candles[:-1]); pc=candles[-2]; pv={'price':float(pc['close']),'close':float(pc['close']),'open':float(pc['open']),'high':float(pc['high']),'low':float(pc['low']),'volume':float(pc.get('volume') or 0)}
        pl=_value(cond.get('left'),pv,prev);pr=_value(cond.get('right'),pv,prev)
        ok=(pl<=pr and left>right) if op=='cross_above' else (pl>=pr and left<right)
    elif op=='>':ok=left>right
    elif op=='>=':ok=left>=right
    elif op=='<':ok=left<right
    elif op=='<=':ok=left<=right
    elif op=='==':ok=left==right
    elif op=='!=':ok=left!=right
    else:return False,f'unsupported operator {op}'
    return bool(ok),f'{cond.get("left")} {op} {cond.get("right")} => {ok}'


def eval_group(group,candles):
    """Evaluate a canonical boolean group.

    A group may contain flat ``conditions`` plus nested ``groups``. Items are
    combined with the group's AND/OR operator. The flat form remains fully
    compatible with Phase 1-6 strategies.
    """
    group=group or {}; ind=indicators(candles); op=str(group.get('op','AND')).upper()
    if op not in ('AND','OR'):
        return False,{'reason':f'unsupported group operator {op}','indicators':ind}
    results=[]
    for c in group.get('conditions',[]) or []:
        ok,reason=eval_condition(c,candles,ind); results.append((ok,{'condition':c,'passed':ok,'reason':reason}))
    for child in group.get('groups',[]) or []:
        ok,detail=eval_group(child,candles); results.append((ok,{'group_result':detail,'passed':ok}))
    passed=(all(x[0] for x in results) if op=='AND' else any(x[0] for x in results)) if results else False
    return passed,{'group':op,'items':[x[1] for x in results],'indicators':ind}


def evaluate_entry(definition,candles):return eval_group(definition.get('entry',{}),candles)
def evaluate_exit(definition,candles):return eval_group(definition.get('exit',{}),candles)


OPERANDS={"open","high","low","close","volume"}|{f"sma{x}" for x in (5,9,20,50,100,200)}|{f"ema{x}" for x in (5,9,20,50,100,200)}|{"rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_mid","bb_upper","bb_lower","volume_sma20","body","range","bullish_candle","bearish_candle"}

def validate_strategy(definition:dict)->list[str]:
    errors=[]
    if not isinstance(definition,dict):return ['definition must be an object']
    if str(definition.get('timeframe','5m')) not in TIMEFRAMES:errors.append('timeframe is invalid')
    side=str(definition.get('side','BUY')).upper()
    if side not in SIDES:errors.append('side must be BUY or SELL')
    ex=definition.get('execution',{}) or {}; product=str(ex.get('product','MIS')).upper()
    if product not in PRODUCTS:errors.append(f'unsupported product: {product}')
    def check_group(group,path):
        if not isinstance(group,dict):errors.append(f'{path} group is required');return
        op=str(group.get('op','AND')).upper()
        if op not in ('AND','OR'):errors.append(f'{path}.op must be AND or OR')
        conditions=group.get('conditions',[])
        if conditions is not None and not isinstance(conditions,list):errors.append(f'{path}.conditions must be a list');conditions=[]
        for i,c in enumerate(conditions or []):
            if not isinstance(c,dict):errors.append(f'{path}.conditions[{i}] must be an object');continue
            if c.get('operator') not in OPS:errors.append(f'{path}.conditions[{i}].operator is invalid')
            if c.get('left') is None or c.get('right') is None:errors.append(f'{path}.conditions[{i}] needs left and right')
            for field in ('left','right'):
                val=c.get(field)
                if isinstance(val,str) and val.lower() in ('open','high','low','close','volume'):
                    pass
                elif isinstance(val,str) and val.lower() not in OPERANDS:
                    numeric = _num(val)
                    if numeric is None:
                        errors.append(f'{path}.conditions[{i}].{field} is an unknown or non-finite operand: {val}')
        groups=group.get('groups',[])
        if groups is not None and not isinstance(groups,list):errors.append(f'{path}.groups must be a list');groups=[]
        for i,g in enumerate(groups or []):check_group(g,f'{path}.groups[{i}]')
        if not (conditions or groups):errors.append(f'{path} must contain at least one condition/group')
    check_group(definition.get('entry'), 'entry')
    check_group(definition.get('exit'), 'exit')
    risk=definition.get('risk',{}) or {}
    if not isinstance(risk,dict):errors.append('risk must be an object');risk={}
    for k in ('stop_loss','target','stop_loss_pct','target_pct','trailing_stop_pct','stop_atr_multiple','partial_exit_pct'):
        if k in risk and risk[k] is not None and _num(risk[k]) is None:errors.append(f'risk.{k} must be numeric')
    for k in ('stop_loss_pct','target_pct','trailing_stop_pct','stop_atr_multiple'):
        if risk.get(k) is not None and _num(risk[k]) is not None and float(risk[k]) <= 0:
            errors.append(f'risk.{k} must be greater than 0')
    if risk.get('stop_loss') is not None and _num(risk['stop_loss']) is not None and float(risk['stop_loss']) <= 0:
        errors.append('risk.stop_loss must be greater than 0')
    if risk.get('target') is not None and _num(risk['target']) is not None and float(risk['target']) <= 0:
        errors.append('risk.target must be greater than 0')
    stop_modes=sum(1 for k in ('stop_loss','stop_loss_pct','stop_atr_multiple') if risk.get(k) is not None)
    if stop_modes > 1:
        errors.append('use only one stop-loss mode: price, percentage or ATR multiple')
    target_modes=sum(1 for k in ('target','target_pct') if risk.get(k) is not None)
    if target_modes > 1:
        errors.append('use only one target mode: price or percentage')
    stop_value = _num(risk.get('stop_loss'))
    target_value = _num(risk.get('target'))
    if stop_value is not None and target_value is not None:
        if side == 'BUY' and stop_value >= target_value:
            errors.append('BUY strategy requires stop_loss below target')
        if side == 'SELL' and stop_value <= target_value:
            errors.append('SELL strategy requires stop_loss above target')
    for pct_key, price_key in (('stop_loss_pct','stop_loss'),('target_pct','target')):
        if risk.get(pct_key) is not None and risk.get(price_key) is not None:
            errors.append(f'use either risk.{pct_key} or risk.{price_key}, not both')
    if risk.get('partial_exit_pct') is not None and not (0<float(risk['partial_exit_pct'])<=100):errors.append('risk.partial_exit_pct must be between 0 and 100')
    if risk.get('time_exit_bars') is not None:
        try:
            raw_bars = risk['time_exit_bars']
            bars = int(raw_bars)
            if isinstance(raw_bars, bool) or str(raw_bars).strip() != str(bars) or bars < 1:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('risk.time_exit_bars must be a positive integer')
    if definition.get('time_exit_bars') is not None:
        errors.append('time_exit_bars must be under risk.time_exit_bars')
    scanner_ids=definition.get('scanner_ids')
    if scanner_ids is not None:
        if not isinstance(scanner_ids,list) or any((not str(x).isdigit() or int(x) <= 0) for x in scanner_ids):
            errors.append('scanner_ids must be a list of positive scanner IDs')
    if definition.get('max_positions') is not None:
        try:
            raw_max = definition['max_positions']
            max_pos = int(raw_max)
            if isinstance(raw_max, bool) or str(raw_max).strip() != str(max_pos) or max_pos < 1:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('max_positions must be a positive integer')
    sizing=definition.get('position_sizing',{}) or {}
    if not isinstance(sizing,dict):errors.append('position_sizing must be an object');sizing={}
    if sizing.get('quantity') is not None:
        q=_num(sizing['quantity'])
        if q is None or q<1 or not float(q).is_integer(): errors.append('position_sizing.quantity must be a positive integer')
    if sizing.get('capital_pct') is not None:
        cap_pct = _num(sizing['capital_pct'])
        if cap_pct is None or not math.isfinite(float(cap_pct)) or not (0<float(cap_pct)<=100):
            errors.append('capital_pct must be between 0 and 100')
    if sizing.get('risk_per_trade') is not None and (not _num(sizing['risk_per_trade']) or float(sizing['risk_per_trade'])<=0):errors.append('risk_per_trade must be > 0')
    sizing_modes = sum(1 for k in ('quantity','capital_pct','risk_per_trade') if sizing.get(k) is not None)
    if sizing_modes > 1:
        errors.append('position_sizing must use only one of quantity, capital_pct or risk_per_trade')
    if sizing.get('risk_per_trade') is not None and not any(risk.get(k) is not None for k in ('stop_loss','stop_loss_pct','stop_atr_multiple')):
        errors.append('risk_per_trade sizing requires a stop-loss mode')
    execution=definition.get('execution',{}) or {}
    if not isinstance(execution,dict):
        errors.append('execution must be an object')
        execution={}
    if execution.get('cooldown_bars') is not None:
        try:
            raw_cooldown = execution['cooldown_bars']
            cooldown = int(raw_cooldown)
            if isinstance(raw_cooldown, bool) or str(raw_cooldown).strip() != str(cooldown) or cooldown < 0:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('execution.cooldown_bars must be a non-negative integer')
    universe=definition.get('universe',{}) or {}
    scanner_ids=definition.get('scanner_ids') or []
    scanner_linked=bool(scanner_ids)
    if universe and not isinstance(universe,dict):errors.append('universe must be an object')
    if isinstance(universe,dict) and universe.get('instrument_tokens') is not None:
        toks=universe.get('instrument_tokens')
        # Scanner-linked strategies may intentionally send an empty explicit
        # universe: the scanner owns discovery and candidate subscriptions.
        # Scanner-less strategies still require a non-empty explicit universe.
        if not isinstance(toks,list) or (not toks and not scanner_linked):
            errors.append('universe.instrument_tokens must be a non-empty list when no scanner is configured')
        elif len(toks)>3000:
            errors.append('universe.instrument_tokens cannot exceed the SFeed limit of 3000')
        else:
            cleaned=[]
            for i,tok in enumerate(toks):
                text=str(tok).strip() if tok is not None else ''
                if not text or not text.isdigit() or int(text) <= 0:
                    errors.append(f'universe.instrument_tokens[{i}] must be a positive integer token')
                cleaned.append(text)
            if len(cleaned) != len(set(cleaned)):
                errors.append('universe.instrument_tokens must not contain duplicate tokens')
    return errors


def size_position(definition,price,available_funds=None,atr_value=None,lot_size=1,max_quantity=None):
    sizing=definition.get('position_sizing',{}) or {}; qty=sizing.get('quantity')
    if qty is not None:
        result=max(1,int(qty))
    else:
        pct=sizing.get('capital_pct')
        if pct and available_funds and price>0:
            result=max(1,int((float(available_funds)*float(pct)/100)/price))
        else:
            risk=sizing.get('risk_per_trade'); stop=(definition.get('risk',{}) or {}).get('stop_loss')
            if stop is None and atr_value and (definition.get('risk',{}) or {}).get('stop_atr_multiple') is not None:
                mult=float(definition['risk']['stop_atr_multiple'])
                stop=price-mult*float(atr_value) if str(definition.get('side','BUY')).upper()=='BUY' else price+mult*float(atr_value)
            result=max(1,int(float(risk)/(abs(price-float(stop))))) if risk and stop and price>0 and price!=float(stop) else 1
    lot=max(1,int(lot_size or 1))
    result=(result//lot)*lot
    if result <= 0:
        return 0
    if max_quantity is not None:
        cap=(int(max_quantity)//lot)*lot
        if cap < lot:return 0
        result=min(result,cap)
    if result < lot:
        return 0
    return result


@dataclass
class BacktestTrade:
    symbol:str;entry_time:str;exit_time:str;side:str;quantity:int;entry_price:float;exit_price:float;gross_pnl:float;costs:float;net_pnl:float;exit_reason:str


def _bar_in_cash_session(candle):
    try:
        from datetime import datetime, time
        from zoneinfo import ZoneInfo
        raw=str(candle.get('candle_at','')).replace('Z','+00:00')
        x=datetime.fromisoformat(raw)
        if x.tzinfo is None:x=x.replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        else:x=x.astimezone(ZoneInfo('Asia/Kolkata'))
        return x.weekday()<5 and time(9,15)<=x.time().replace(tzinfo=None)<time(15,30)
    except (TypeError,ValueError,OverflowError):
        # Unknown timestamps are never treated as valid NSE cash-session bars.
        return False

def _cagr(initial_capital, final_equity, start_time, end_time):
    if initial_capital <= 0 or final_equity <= 0 or not start_time or not end_time:
        return None
    try:
        a = __import__("datetime").datetime.fromisoformat(str(start_time).replace("Z","+00:00"))
        b = __import__("datetime").datetime.fromisoformat(str(end_time).replace("Z","+00:00"))
        years = (b-a).total_seconds() / (365.25*86400)
        if years <= 0:
            return None
        return ((final_equity/initial_capital)**(1/years)-1)*100
    except (TypeError, ValueError):
        return None


def _risk_ratios_from_equity_curve(equity_curve, initial_capital, candles=None, requested_from=None, requested_to=None):
    """Annualized daily realized portfolio-return Sharpe/Sortino.

    The daily series is built across the full requested trading-date window,
    carrying equity forward on no-trade days so the denominator is a genuine
    daily portfolio series rather than a trade-count series.
    """
    if initial_capital <= 0: return None, None
    realized={}
    for point in equity_curve or []:
        day=str(point.get("candle_at", ""))[:10]
        if day: realized[day]=float(point["equity"])
    if not realized: return None, None
    if candles:
        days=sorted({str(c.get("candle_at", ""))[:10] for c in candles if str(c.get("candle_at", ""))[:10]})
        frm=str(requested_from or days[0])[:10]; to=str(requested_to or days[-1])[:10]
        days=[d for d in days if frm <= d <= to]
        daily={}; equity=float(initial_capital)
        for day in days:
            if day in realized: equity=realized[day]
            daily[day]=equity
    else:
        daily=realized
    ordered=sorted(daily.items())
    prev=float(initial_capital); returns=[]
    for _,equity in ordered:
        if prev>0: returns.append((equity-prev)/prev)
        prev=equity
    if len(returns)<2:return None,None
    mean=sum(returns)/len(returns)
    var=sum((x-mean)**2 for x in returns)/(len(returns)-1)
    std=var**0.5
    sharpe=(mean/std)*(252**0.5) if std else None
    dstd=(sum(min(0.0,x)**2 for x in returns)/len(returns))**0.5
    sortino=(mean/dstd)*(252**0.5) if dstd else None
    return sharpe,sortino


def _trade_leg_cost(price, qty, *, side, leg, flat_per_side=0.0, model=None):
    model=model or {}
    value=float(price)*int(qty)
    brokerage=float(model.get(f"{leg}_brokerage",flat_per_side) or 0)
    exchange=value*float(model.get("exchange_txn_pct",0) or 0)/100
    sebi=value*float(model.get("sebi_pct",0) or 0)/100
    transaction=str(side).upper()
    is_sell = (transaction == "BUY" and leg == "exit") or (transaction == "SELL" and leg == "entry")
    is_buy = not is_sell
    stt=value*float(model.get("stt_sell_pct",0) or 0)/100 if is_sell else 0.0
    stamp=value*float(model.get("stamp_duty_buy_pct",0) or 0)/100 if is_buy else 0.0
    gst=(brokerage+exchange+sebi)*float(model.get("gst_pct",0) or 0)/100
    return brokerage+exchange+sebi+stt+stamp+gst


def _trade_costs(entry_price, exit_price, qty, side="BUY", flat_per_side=0.0, model=None):
    """Full round-trip cost using separate entry and exit legs."""
    return (_trade_leg_cost(entry_price, qty, side=side, leg="entry", flat_per_side=flat_per_side, model=model)
            + _trade_leg_cost(exit_price, qty, side=side, leg="exit", flat_per_side=flat_per_side, model=model))


def run_backtest(
    candles, definition, symbol, quantity=1, slippage=0.0, fees=0.0,
    initial_capital=100000.0, requested_from=None, requested_to=None, cost_model=None
):
    """Conservative historical simulation.

    Indicator warm-up candles may precede requested_from, but no trade can
    open before requested_from. Signals use only completed candles and entries
    execute at the NEXT candle open, eliminating same-candle look-ahead.
    Stops/targets use candle high/low with stop checked first when both are
    touched. Optional partial exits, trailing stops and time exits are supported.
    """
    side=str(definition.get('side','BUY')).upper()
    trades=[]; open_trade=None
    req_from=str(requested_from or "")[:10]
    req_to=str(requested_to or "")[:10]
    realized_equity=float(initial_capital)
    equity_curve=[]

    for i in range(1,len(candles)):
        c=candles[i]; close=float(c['close']); cdate=str(c.get('candle_at',''))[:10]
        if req_to and cdate > req_to:
            break
        if open_trade is None:
            # Warm-up history is available to indicators but is not executable.
            if req_from and cdate < req_from:
                continue
            hist=candles[:i]
            if not _bar_in_cash_session(c): continue
            ok,_=evaluate_entry(definition,hist)
            if ok:
                ind=indicators(hist)
                q=size_position(
                    definition,float(c['open']),definition.get('_available_funds'),
                    ind.get('atr14')
                ) or quantity
                entry=float(c['open'])*(1+slippage if side=='BUY' else 1-slippage)
                entry_cost=_trade_leg_cost(entry,q,side=side,leg='entry',flat_per_side=fees,model=cost_model)
                open_trade={'time':c['candle_at'],'price':entry,'qty':q,'remaining':q,
                            'side':side,'bars':0,'partial_taken':False,'entry_cost_per_unit':entry_cost/q if q else 0.0}
            continue

        open_trade['bars']+=1
        risk=definition.get('risk',{}) or {}; entry=open_trade['price']
        stop=risk.get('stop_loss'); target=risk.get('target')
        if stop is None and risk.get('stop_loss_pct') is not None:
            stop=entry*(1-float(risk['stop_loss_pct'])/100 if side=='BUY' else 1+float(risk['stop_loss_pct'])/100)
        if stop is None and risk.get('stop_atr_multiple') is not None:
            hist=candles[:i]
            av=indicators(hist).get('atr14')
            if av is not None:
                mult=float(risk['stop_atr_multiple'])
                stop=entry-mult*av if side=='BUY' else entry+mult*av
        if target is None and risk.get('target_pct') is not None:
            target=entry*(1+float(risk['target_pct'])/100 if side=='BUY' else 1-float(risk['target_pct'])/100)
        if risk.get('trailing_stop_pct') is not None:
            pct=float(risk['trailing_stop_pct'])/100
            candidate=close*(1-pct) if side=='BUY' else close*(1+pct)
            open_trade['trailing_stop']=(
                max(open_trade.get('trailing_stop',candidate),candidate)
                if side=='BUY' else
                min(open_trade.get('trailing_stop',candidate),candidate)
            )

        reason=None; exit_price=close
        if side=='BUY':
            if stop is not None and float(c['low'])<=float(stop): reason='STOP_LOSS'; exit_price=float(stop)
            elif target is not None and float(c['high'])>=float(target): reason='TARGET'; exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['low'])<=open_trade['trailing_stop']:
                reason='TRAILING_STOP'; exit_price=open_trade['trailing_stop']
        else:
            if stop is not None and float(c['high'])>=float(stop): reason='STOP_LOSS'; exit_price=float(stop)
            elif target is not None and float(c['low'])<=float(target): reason='TARGET'; exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['high'])>=open_trade['trailing_stop']:
                reason='TRAILING_STOP'; exit_price=open_trade['trailing_stop']

        if reason is None and risk.get('time_exit_bars') and open_trade['bars']>=int(risk['time_exit_bars']):
            reason='TIME_EXIT'
        if reason is None:
            exit_ok,_=evaluate_exit(definition,candles[:i+1])
            if exit_ok: reason='STRATEGY_EXIT'
        if reason is None: continue

        exit_price*=1-slippage if side=='BUY' else 1+slippage
        partial=float(risk.get('partial_exit_pct') or 100)
        exit_qty=(
            open_trade['remaining'] if partial>=100 or open_trade['partial_taken']
            else max(1,min(open_trade['remaining'],int(round(open_trade['qty']*partial/100))))
        )
        gross=(exit_price-entry)*exit_qty*(1 if side=='BUY' else -1)
        entry_cost=open_trade.get('entry_cost_per_unit',0.0)*exit_qty
        exit_cost=_trade_leg_cost(exit_price,exit_qty,side=side,leg='exit',flat_per_side=fees,model=cost_model)
        costs=entry_cost+exit_cost
        net=gross-costs
        trades.append(BacktestTrade(
            symbol,open_trade['time'],c['candle_at'],side,exit_qty,
            entry,exit_price,gross,costs,net,reason
        ))
        open_trade['remaining']-=exit_qty
        if open_trade['remaining']<=0:
            open_trade=None
        else:
            open_trade['partial_taken']=True

    # Close any remaining position at the final requested candle so the report
    # cannot hide an open simulated position.
    if open_trade is not None:
        usable=[c for c in candles if not req_to or str(c.get('candle_at',''))[:10] <= req_to]
        if usable:
            last=usable[-1]
            exit_price=float(last['close'])*(1-slippage if side=='BUY' else 1+slippage)
            qty=int(open_trade['remaining'])
            gross=(exit_price-open_trade['price'])*qty*(1 if side=='BUY' else -1)
            entry_cost=open_trade.get('entry_cost_per_unit',0.0)*qty
            exit_cost=_trade_leg_cost(exit_price,qty,side=side,leg='exit',flat_per_side=fees,model=cost_model)
            costs=entry_cost+exit_cost
            net=gross-costs
            trades.append(BacktestTrade(
                symbol,open_trade['time'],last['candle_at'],side,qty,
                open_trade['price'],exit_price,gross,costs,net,'DATA_END'
            ))

    pnl=sum(t.net_pnl for t in trades)
    wins=[t.net_pnl for t in trades if t.net_pnl>0]
    losses=[t.net_pnl for t in trades if t.net_pnl<0]
    equity=float(initial_capital); peak=equity; dd=0.0
    equity_curve=[]; consecutive=0; max_consecutive=0

    # Rebuild a mark-to-market portfolio series across every requested candle.
    # This is the basis for drawdown and daily Sharpe/Sortino; trade-count
    # returns are intentionally not used.
    trade_idx=0
    active=None
    realized=float(initial_capital)
    for c in candles:
        day=str(c.get('candle_at',''))[:10]
        if req_from and day < req_from: continue
        if req_to and day > req_to: break
        # Apply any trade exits that occurred on this candle before the close mark.
        while trade_idx < len(trades) and str(trades[trade_idx].exit_time) == str(c.get('candle_at')):
            realized += float(trades[trade_idx].net_pnl)
            trade_idx += 1
        # Find an open interval by looking at the next trade entry/exit window.
        mark=realized
        if trade_idx < len(trades):
            t=trades[trade_idx]
            if str(t.entry_time) <= str(c.get('candle_at')) < str(t.exit_time):
                px=float(c['close'])
                gross=(px-float(t.entry_price))*int(t.quantity)*(1 if t.side=='BUY' else -1)
                entry_cost = _trade_leg_cost(t.entry_price, t.quantity, side=t.side, leg='entry', flat_per_side=fees, model=cost_model)
                mark += gross - entry_cost
        equity=mark
        peak=max(peak,equity); draw=max(0.0,peak-equity); dd=max(dd,draw)
        equity_curve.append({
            'candle_at':c.get('candle_at'),'equity':equity,'drawdown':draw,
            'drawdown_pct':(draw/peak*100 if peak else 0),
        })

    # Consecutive losses remain trade-based, which is the appropriate unit for
    # this metric and independent of candle frequency.
    for t in trades:
        consecutive=consecutive+1 if t.net_pnl<0 else 0
        max_consecutive=max(max_consecutive,consecutive)

    avg=(sum(t.net_pnl for t in trades)/len(trades)) if trades else 0
    gross_profit=sum(wins); gross_loss=abs(sum(losses))
    sharpe,sortino=_risk_ratios_from_equity_curve(equity_curve,float(initial_capital),candles,requested_from,requested_to)
    final_equity=equity
    first_time=trades[0].entry_time if trades else (candles[0]['candle_at'] if candles else None)
    last_time=trades[-1].exit_time if trades else (candles[-1]['candle_at'] if candles else None)
    return {
        'trades':[t.__dict__ for t in trades],
        'total_trades':len(trades),
        'initial_capital':float(initial_capital),
        'final_equity':final_equity,
        'net_pnl':pnl,
        'win_rate':(len(wins)/len(trades)*100 if trades else 0),
        'profit_factor':(sum(wins)/abs(sum(losses)) if losses else None),
        'max_drawdown':dd,
        'max_drawdown_pct':(dd/peak*100 if peak else 0),
        'cagr':_cagr(float(initial_capital),final_equity,first_time,last_time),
        'sharpe':sharpe,
        'sortino':sortino,
        'average_win':(sum(wins)/len(wins) if wins else 0),
        'average_loss':(sum(losses)/len(losses) if losses else 0),
        'gross_profit':gross_profit,
        'gross_loss':gross_loss,
        'expectancy':avg,
        'max_consecutive_losses':max_consecutive,
        'total_costs':sum(t.costs for t in trades),
        'equity_curve':equity_curve,
        'side':side,
        'execution_model':'next_bar_open',
        'session_filter':'NSE_CASH_WEEKDAY_09:15-15:30_IST',
        'slippage':float(slippage),
        'fees_per_exit':float(fees),
        'cost_model':cost_model or {},
        'risk_metric_basis':'daily_realized_portfolio_returns_annualized_252',
        'requested_from':requested_from,
        'requested_to':requested_to,
    }
