"""Pre-market preparation that used to need a human: runs once per trading day, unattended.

1. Refresh the NSE cash scrip master (new listings, lot sizes, tick sizes) via the SDK.
2. Back-fill completed-bar history for every LIVE-armed strategy's scanner universe / own universe,
   so the first scan at 09:15 already has the bars the indicators need.

It never places an order and never subscribes anything. It needs the broker to be CONNECTED
(the maintenance loop reconnects automatically after the daily session expiry) and simply retries
later when it is not. Progress is persisted in a per-day marker file so a restart does not repeat
a finished preparation, and a half-finished one resumes.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
import time

from . import db, scanner_engine, universe
from .config import config
from .market_session import IST, holidays
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.daily_prep")

PREP_START = dt.time(8, 30)
PREP_END = dt.time(15, 30)
RETRY_AFTER_SECONDS = 300
MAX_PREP_SECONDS = 600
_last_attempt = float("-inf")


def is_trading_day(day: dt.date) -> bool:
    return day.weekday() < 5 and day not in holidays()


def _marker_path(day: dt.date) -> str:
    return os.path.join(config.data_dir, f"daily-prep-{day.isoformat()}.json")


def read_marker(day: dt.date) -> dict | None:
    try:
        with open(_marker_path(day), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _write_marker(day: dt.date, payload: dict) -> None:
    try:
        os.makedirs(config.data_dir, exist_ok=True)
        tmp = _marker_path(day) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
        os.replace(tmp, _marker_path(day))
    except OSError as exc:
        logger.warning("Could not write the daily-prep marker: %s", exc)


def _warmup_jobs() -> list[tuple[str, list[dict], str, dict]]:
    """(label, instruments, timeframe, definition) for every LIVE-armed strategy."""
    jobs: list[tuple[str, list[dict], str, dict]] = []
    scanners = {s["id"]: s for s in db.list_scanners() if s.get("is_active")}
    full = db.list_instruments(scanner_engine.MAX_UNIVERSE)
    for item in db.list_live_armed_strategy_versions():
        definition = item.get("definition") or {}
        sids = [int(x) for x in definition.get("scanner_ids") or [] if str(x).isdigit()]
        if sids:
            for sid in sids:
                sc = scanners.get(sid)
                if not sc:
                    continue
                sdef = sc.get("definition") or {}
                tf = str(sdef.get("timeframe") or definition.get("timeframe") or "5m")
                jobs.append((f"scanner#{sid}", scanner_engine._scanner_universe(sc, full), tf, sdef))
        else:
            tokens = [str(t) for t in ((definition.get("universe") or {}).get("instrument_tokens") or [])]
            insts = [i for i in (db.get_instrument("nse_cm", t) for t in tokens) if i]
            if insts:
                jobs.append((f"strategy#{item['id']}", insts, str(definition.get("timeframe") or "5m"), definition))
    return jobs


async def run_daily_prep(*, now: dt.datetime | None = None) -> dict:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    result: dict = {"date": local.date().isoformat(), "scrip_master": None, "history": [], "complete": False}
    try:
        sync = await universe.sync_nse_cash_metadata()
        result["scrip_master"] = {"ok": bool(sync.get("ok")), "count": sync.get("count") or sync.get("instruments"),
                                  "error": None if sync.get("ok") else str(sync.get("error") or sync)[:200]}
    except Exception as exc:  # noqa: BLE001
        result["scrip_master"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:200]}
    deadline = time.monotonic() + MAX_PREP_SECONDS
    history_ok = True
    for label, insts, tf, definition in _warmup_jobs():
        entry = {"job": label, "instruments": len(insts), "timeframe": tf, "fetched": 0, "remaining": None, "stopped": None}
        for _ in range(40):
            if time.monotonic() >= deadline or current_state.state != BrokerState.CONNECTED:
                entry["stopped"] = entry["stopped"] or "time budget or broker state"
                break
            r = await scanner_engine.warmup_history(insts, tf, definition, time_budget=25.0, max_instruments=300)
            entry["fetched"] += r.get("fetched", 0)
            entry["remaining"] = r.get("remaining")
            if r.get("stopped"):
                entry["stopped"] = r["stopped"]
                break
            if not r.get("remaining") or r.get("fetched", 0) == 0:
                break
            await asyncio.sleep(0.5)
        if entry["remaining"]:
            history_ok = False
        result["history"].append(entry)
    result["complete"] = bool(result["scrip_master"] and result["scrip_master"]["ok"] and history_ok)
    result["finished_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    logger.info("Daily preparation: %s", result)
    return result


async def maybe_run(now: dt.datetime | None = None) -> dict | None:
    """Called every minute. Runs the preparation at most once per trading day (retrying every 5 min)."""
    global _last_attempt
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    day = local.date()
    if not is_trading_day(day) or not (PREP_START <= local.time().replace(tzinfo=None) < PREP_END):
        return None
    marker = read_marker(day)
    if marker and marker.get("complete"):
        return None
    if current_state.state != BrokerState.CONNECTED:
        return None
    if time.monotonic() - _last_attempt < RETRY_AFTER_SECONDS:
        return None
    _last_attempt = time.monotonic()
    result = await run_daily_prep(now=now)
    _write_marker(day, result)
    return result
