// Runs without Express: stubs the two modules the middleware reads.
const test = require("node:test");
const assert = require("node:assert");
const path = require("node:path");

const cfgPath = require.resolve("../src/config");
const statePath = require.resolve("../src/services/brokerState");
let emergency = false, brokerState = "CONNECTED", mode = "LIVE";
require.cache[cfgPath] = { id: cfgPath, filename: cfgPath, loaded: true, exports: { get tradingMode() { return mode; } } };
require.cache[statePath] = { id: statePath, filename: statePath, loaded: true, exports: {
  BROKER_STATES: { CONNECTED: "CONNECTED" },
  isEmergencyStopActive: () => emergency,
  getBrokerConnectionState: () => ({ state: brokerState }),
} };
const { requireLiveTradingAllowed, requireCancelAllowed } = require("../src/middleware/requireLiveTradingAllowed");

function run(mw) {
  let out = { next: false };
  const res = { status(c) { out.status = c; return this; }, json(b) { out.body = b; return this; } };
  mw({}, res, () => { out.next = true; });
  return out;
}

test("emergency stop blocks new/modify orders but not cancel", () => {
  emergency = true; brokerState = "CONNECTED"; mode = "LIVE";
  assert.equal(run(requireLiveTradingAllowed).status, 423);
  assert.equal(run(requireCancelAllowed).next, true);
});
test("cancel still requires LIVE mode and a connected broker", () => {
  emergency = false; brokerState = "SESSION_EXPIRED";
  assert.equal(run(requireCancelAllowed).status, 409);
  brokerState = "CONNECTED"; mode = "PAPER";
  assert.equal(run(requireCancelAllowed).status, 403);
});
