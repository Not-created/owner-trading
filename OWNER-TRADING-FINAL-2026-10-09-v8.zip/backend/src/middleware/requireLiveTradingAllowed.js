const config = require("../config");
const { getBrokerConnectionState, isEmergencyStopActive, BROKER_STATES } = require("../services/brokerState");

// Defense-in-depth gate for every executable LIVE order request.
function requireLiveTradingAllowed(req, res, next, { allowDuringEmergencyStop = false } = {}) {
  if (config.tradingMode !== "LIVE") return res.status(403).json({ error: "LIVE trading is unavailable." });
  if (!allowDuringEmergencyStop && isEmergencyStopActive()) return res.status(423).json({ error: "Emergency stop is active. No LIVE orders are permitted." });
  const { state } = getBrokerConnectionState();
  if (state !== BROKER_STATES.CONNECTED) return res.status(409).json({ error: `Broker is not connected (state: ${state}). LIVE orders are blocked.` });
  return next();
}

// Cancelling an open order only reduces exposure, so it stays available during an emergency
// stop (the broker service applies the same rule). Mode and broker-connection gates still apply.
const requireCancelAllowed = (req, res, next) => requireLiveTradingAllowed(req, res, next, { allowDuringEmergencyStop: true });

module.exports = { requireLiveTradingAllowed, requireCancelAllowed };
