import unittest

from app import pnl

# Row shaped like docs/functions/portfolio/positions.md (all numerics are strings)
CASH = {"trdSym": "YESBANK-EQ", "exSeg": "nse_cm", "prod": "MIS", "tok": "11915", "cfBuyQty": "0", "flBuyQty": "100",
        "cfSellQty": "0", "flSellQty": "40", "cfBuyAmt": "0", "buyAmt": "2000.00", "cfSellAmt": "0", "sellAmt": "840.00",
        "lotSz": "1", "multiplier": "1", "genNum": "1", "genDen": "1", "prcNum": "1", "prcDen": "1"}


class PositionTests(unittest.TestCase):
    def test_normalize_net_and_average(self):
        p = pnl.normalize_position(CASH)
        self.assertEqual((p["buy_quantity"], p["sell_quantity"], p["quantity"]), (100, 40, 60))
        self.assertAlmostEqual(p["average_price"], 20.0)
        self.assertEqual(p["instrument_token"], "11915")

    def test_realised_plus_unrealised_equals_documented_formula(self):
        p = pnl.normalize_position(CASH)
        for ltp in (18.0, 20.0, 23.5):
            r = pnl.position_pnl(p, ltp)
            self.assertAlmostEqual(r["total"], pnl.documented_pnl(p, ltp), places=6)
        # realised: 40 sold @21 vs 20 cost = +40
        self.assertAlmostEqual(pnl.position_pnl(p, 20.0)["realized"], 40.0)

    def test_short_position(self):
        row = dict(CASH, flBuyQty="10", buyAmt="200.00", flSellQty="50", sellAmt="1100.00")
        p = pnl.normalize_position(row)
        self.assertEqual(p["quantity"], -40)
        r = pnl.position_pnl(p, 21.0)
        self.assertAlmostEqual(r["total"], pnl.documented_pnl(p, 21.0), places=6)

    def test_unknown_ltp_never_fabricated(self):
        r = pnl.position_pnl(pnl.normalize_position(CASH), None)
        self.assertIsNone(r["unrealized"])
        self.assertIsNone(r["total"])

    def test_flat_position_needs_no_ltp(self):
        p = pnl.normalize_position(dict(CASH, flSellQty="100", sellAmt="2200.00"))
        r = pnl.position_pnl(p, None)
        self.assertEqual(r["unrealized"], 0.0)
        self.assertAlmostEqual(r["total"], 200.0)

    def test_price_factor_applied(self):
        row = dict(CASH, multiplier="10", genNum="1", genDen="2", prcNum="1", prcDen="1")
        self.assertAlmostEqual(pnl.price_factor(row), 5.0)

    def test_carry_forward_included(self):
        p = pnl.normalize_position(dict(CASH, cfBuyQty="50", cfBuyAmt="900.00"))
        self.assertEqual(p["buy_quantity"], 150)
        self.assertAlmostEqual(p["buy_amount"], 2900.0)

    def test_aggregate_flags_incomplete(self):
        p = pnl.normalize_position(CASH)
        agg = pnl.aggregate([p], {})
        self.assertFalse(agg["complete"])
        agg = pnl.aggregate([p], {("nse_cm", "11915"): 21.0})
        self.assertTrue(agg["complete"])
        self.assertAlmostEqual(agg["total"], pnl.documented_pnl(p, 21.0), places=6)

    def test_garbage_numbers_do_not_crash(self):
        p = pnl.normalize_position({"trdSym": "X", "flBuyQty": "abc", "buyAmt": None})
        self.assertEqual(p["quantity"], 0)


class FundsHoldingsTests(unittest.TestCase):
    def test_limits_flat_dict(self):
        r = pnl.parse_limits({"stat": "Ok", "stCode": 200, "Net": "50000.50", "MarginUsed": "1200",
                              "CashRlsMtomPrsnt": "100", "FoRlsMtomPrsnt": "-20", "CashUnRlsMtomPrsnt": "5"})
        self.assertEqual(r["available_margin"], 50000.5)
        self.assertEqual(r["used_margin"], 1200.0)
        self.assertEqual(r["realized_mtom"], 80.0)
        self.assertEqual(r["unrealized_mtom"], 5.0)

    def test_limits_missing_fields_are_none_not_zero(self):
        self.assertIsNone(pnl.parse_limits({})["available_margin"])
        self.assertIsNone(pnl.parse_limits([])["available_margin"])

    def test_holding(self):
        h = pnl.normalize_holding({"displaySymbol": "TCS", "quantity": 3, "averagePrice": 3500.5, "closingPrice": 3600,
                                   "instrumentToken": 11536, "exchangeSegment": "nse_cm", "mktValue": "10800"})
        self.assertEqual((h["trading_symbol"], h["quantity"], h["instrument_token"]), ("TCS", 3, "11536"))


class PaperPositionsTests(unittest.TestCase):
    def test_fills_to_positions_and_pnl(self):
        fills = [{"trading_symbol": "A", "exchange_segment": "nse_cm", "product": "MIS", "transaction_type": "B", "fill_quantity": 10, "fill_price": 100},
                 {"trading_symbol": "A", "exchange_segment": "nse_cm", "product": "MIS", "transaction_type": "S", "fill_quantity": 4, "fill_price": 110}]
        pos = pnl.simulate_fills_to_positions(fills)
        self.assertEqual(pos[0]["quantity"], 6)
        r = pnl.position_pnl(pos[0], 105.0)
        self.assertAlmostEqual(r["realized"], 40.0)
        self.assertAlmostEqual(r["unrealized"], 30.0)


if __name__ == "__main__":
    unittest.main()
