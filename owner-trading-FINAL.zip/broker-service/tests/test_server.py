import asyncio
import dataclasses
import json
import os
import unittest
from unittest.mock import patch

from app import broker_client as bc
from app import order_service as osvc
from app import sdk_adapter as a
from app import server
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI

TOKEN = "t" * 32


async def call(method, path, body=None, headers=None, query=None):
    reader = asyncio.StreamReader()
    raw = json.dumps(body).encode() if body is not None else b""
    reader.feed_data(raw)
    reader.feed_eof()
    h = {"content-length": str(len(raw))}
    h.update(headers if headers is not None else {"x-internal-token": TOKEN})
    out = await server.dispatch(method, path, query or {}, h, reader)
    head, _, payload = out.partition(b"\r\n\r\n")
    return int(head.split(b" ")[1]), json.loads(payload)


class ServerBase(unittest.IsolatedAsyncioTestCase):
    MODE = "PAPER"

    async def asyncSetUp(self):
        self.db = fresh_db()
        os.environ["BROKER_SERVICE_TOKEN"] = TOKEN
        cfg = dataclasses.replace(server.config, trading_mode=self.MODE)
        self.ps = [patch.object(server, "config", cfg), patch.object(osvc, "config", cfg), patch.object(bc, "config", cfg)]
        for p in self.ps:
            p.start()
        current_state.transition(BrokerState.DISCONNECTED)

    async def asyncTearDown(self):
        for p in self.ps:
            p.stop()
        os.environ.pop("BROKER_SERVICE_TOKEN", None)
        bc.broker_client._sdk = None
        current_state.transition(BrokerState.DISCONNECTED)

    def connect_fake(self):
        sdk = a.KotakSdk("ck", "prod", neo_factory=FakeNeoAPI)
        sdk.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1")
        bc.broker_client._sdk = sdk
        current_state.transition(BrokerState.CONNECTED)
        return sdk._neo


class AuthTests(ServerBase):
    async def test_health_is_open(self):
        self.assertEqual(await call("GET", "/health", headers={}), (200, {"status": "ok"}))

    async def test_every_other_route_requires_token(self):
        for m, p in list(server.ROUTES):
            s, _ = await call(m, p, {} if m == "POST" else None, headers={})
            self.assertEqual(s, 401, f"{m} {p}")
        s, _ = await call("GET", "/status", headers={"x-internal-token": "wrong"})
        self.assertEqual(s, 401)

    async def test_live_mode_without_configured_token_denies_everything(self):
        os.environ.pop("BROKER_SERVICE_TOKEN")
        with patch.object(server, "config", dataclasses.replace(server.config, trading_mode="LIVE")):
            s, _ = await call("GET", "/status", headers={})
        self.assertEqual(s, 401)

    async def test_unknown_and_wrong_method(self):
        self.assertEqual((await call("GET", "/nope"))[0], 404)
        self.assertEqual((await call("DELETE", "/orders"))[0], 405)


class PaperRouteTests(ServerBase):
    async def test_status_reports_sdk_and_mode(self):
        s, b = await call("GET", "/status")
        self.assertEqual(s, 200)
        self.assertEqual(b["tradingMode"], "PAPER")
        self.assertEqual(b["sdk"]["required"], "3.0.7")
        self.assertIn("websocket", b)

    async def test_place_list_cancel_over_dispatch(self):
        body = dict(trading_symbol="YESBANK-EQ", exchange_segment="nse_cm", transaction_type="B", order_type="L", product="CNC", quantity=5, price=10)
        s, o = await call("POST", "/orders", body)
        self.assertEqual((s, o["status"]), (200, "PAPER_ACCEPTED"))
        s, lst = await call("GET", "/orders")
        self.assertEqual(len(lst["orders"]), 1)
        s, c = await call("POST", "/orders/cancel", {"internal_order_id": o["internal_order_id"]})
        self.assertEqual((s, c["status"]), (200, "CANCELLED"))

    async def test_invalid_order_is_400_and_missing_id_is_400(self):
        self.assertEqual((await call("POST", "/orders", {"trading_symbol": "X"}))[0], 400)
        self.assertEqual((await call("POST", "/orders/cancel", {}))[0], 400)
        self.assertEqual((await call("POST", "/orders/modify", {}))[0], 400)

    async def test_broker_params_is_dropped(self):
        body = dict(trading_symbol="Y", exchange_segment="nse_cm", transaction_type="B", order_type="MKT", product="CNC", quantity=1,
                    broker_params={"exchange_segment": "evil"})
        s, o = await call("POST", "/orders", body)
        self.assertEqual((s, o["exchange_segment"]), (200, "nse_cm"))

    async def test_broker_backed_routes_409_when_not_connected(self):
        for m, p, b in (("POST", "/quotes", {"instruments": [{"exchange_segment": "nse_cm", "instrument_token": "1"}]}),
                        ("POST", "/scrip-search", {"exchange_segment": "nse_cm"}), ("POST", "/reconcile", {}),
                        ("POST", "/subscribe", {"exchange_segment": "nse_cm", "instrument_token": "1"})):
            self.assertEqual((await call(m, p, b))[0], 409, p)
        self.assertEqual((await call("GET", "/funds", query={"refresh": ["1"]}))[0], 409)

    async def test_snapshots_readable_without_broker(self):
        s, b = await call("GET", "/positions")
        self.assertEqual((s, b), (200, {"positions": []}))

    async def test_oversized_body_rejected(self):
        s, _ = await call("POST", "/orders", {"x": "y" * 9000})
        self.assertEqual(s, 400)

    async def test_ticks_and_trades(self):
        self.db.record_market_tick(instrument_token="1", exchange_segment="nse_cm", last_traded_price=5.0)
        self.assertEqual(len((await call("GET", "/market-ticks"))[1]["ticks"]), 1)
        self.assertEqual((await call("GET", "/trades"))[1], {"trades": []})


class BrokerBackedRouteTests(ServerBase):
    async def test_quotes_uses_exact_sdk_shape_and_validates(self):
        neo = self.connect_fake()
        neo.responses["quotes"] = [{"exchange_token": "11915", "ltp": "20.25"}]
        s, b = await call("POST", "/quotes", {"instruments": [{"exchange_segment": "nse_cm", "instrument_token": 11915}], "quote_type": "ltp"})
        self.assertEqual(s, 200)
        self.assertEqual(dict(neo.calls)["quotes"]["instrument_tokens"], [{"instrument_token": "11915", "exchange_segment": "nse_cm"}])
        self.assertEqual((await call("POST", "/quotes", {"instruments": []}))[0], 400)
        self.assertEqual((await call("POST", "/quotes", {"instruments": [{"exchange_segment": "NSE", "instrument_token": "1"}]}))[0], 400)

    async def test_scrip_search_validates_segment_and_passes_exact_args(self):
        neo = self.connect_fake()
        neo.responses["search_scrip"] = [{"pSymbol": 11915, "pTrdSymbol": "YESBANK-EQ"}]
        s, _ = await call("POST", "/scrip-search", {"exchange_segment": "nse_cm", "symbol": "yesbank"})
        self.assertEqual(s, 200)
        self.assertEqual(dict(neo.calls)["search_scrip"]["symbol"], "yesbank")
        self.assertEqual((await call("POST", "/scrip-search", {"exchange_segment": "bad"}))[0], 400)

    async def test_order_history_uses_broker_order_id(self):
        neo = self.connect_fake()
        neo.responses["order_history"] = {"stat": "Ok", "stCode": 200, "data": [{"ordSt": "open"}]}
        self.db.create_order(internal_order_id="o1", trading_symbol="X", exchange_segment="nse_cm", transaction_type="B", order_type="L",
                             product="CNC", validity="DAY", quantity=1, price=1.0, trigger_price=None, mode="LIVE",
                             status="SUBMITTED", broker_order_id="N5", client_tag="T1")
        s, b = await call("GET", "/order-history", query={"internal_order_id": ["o1"]})
        self.assertEqual(s, 200)
        self.assertEqual(dict(neo.calls)["order_history"]["order_id"], "N5")
        self.assertEqual((await call("GET", "/order-history", query={"internal_order_id": ["nope"]}))[0], 400)

    async def test_funds_refresh_runs_reconciliation(self):
        neo = self.connect_fake()
        neo.responses.update({"limits": {"stat": "Ok", "stCode": 200, "Net": "777"}, "order_report": {"stat": "Ok", "stCode": 200, "data": []},
                              "trade_report": {"stat": "ok", "stCode": 200, "data": []}, "positions": {"stat": "Ok", "stCode": 200, "data": []},
                              "holdings": {"data": []}})
        s, b = await call("GET", "/funds", query={"refresh": ["1"]})
        self.assertEqual((s, b["funds"]["available_margin"]), (200, 777.0))


class DerivativesRouteTests(ServerBase):
    async def test_scrip_master_route(self):
        neo = self.connect_fake()
        neo.responses["scrip_master"] = "https://example.com/nse_cm-v1.csv"
        s, b = await call("GET", "/scrip-master", query={"exchange_segment": ["nse_cm"]})
        self.assertEqual((s, b["data"]), (200, "https://example.com/nse_cm-v1.csv"))
        self.assertEqual(dict(neo.calls)["scrip_master"], {"exchange_segment": "nse_cm"})

    async def test_scrip_master_without_segment_returns_file_index(self):
        neo = self.connect_fake()
        neo.responses["scrip_master"] = {"baseFolder": "https://x", "filesPaths": ["https://x/a.csv"]}
        s, b = await call("GET", "/scrip-master")
        self.assertEqual(s, 200)
        self.assertIn("filesPaths", b["data"])

    async def test_expiries_route_validates_and_passes_exact_args(self):
        neo = self.connect_fake()
        neo.responses["expiries"] = {"exchange": "nse_fo", "underlying": "NIFTY", "expiries": ["2026-06-25"]}
        s, b = await call("POST", "/expiries", {"exchange": "nse_fo", "underlying": "NIFTY"})
        self.assertEqual((s, b["data"]["expiries"]), (200, ["2026-06-25"]))
        self.assertEqual(dict(neo.calls)["expiries"], {"exchange": "nse_fo", "underlying": "NIFTY", "instrument_type": None})
        self.assertEqual((await call("POST", "/expiries", {"exchange": "nse_cm", "underlying": "NIFTY"}))[0], 400)
        self.assertEqual((await call("POST", "/expiries", {"exchange": "nse_fo"}))[0], 400)

    async def test_option_chain_route(self):
        neo = self.connect_fake()
        neo.responses["option_chain"] = {"data": {"common_data": {}, "call": [], "put": []}}
        s, b = await call("POST", "/option-chain", {"exchange": "nse_fo", "underlying": "NIFTY", "expiry": "2026-06-25", "count": 10})
        self.assertEqual(s, 200)
        self.assertEqual(dict(neo.calls)["option_chain"]["count"], 10)
        self.assertEqual((await call("POST", "/option-chain", {"exchange": "bad", "underlying": "NIFTY"}))[0], 400)

    async def test_historical_data_route(self):
        neo = self.connect_fake()
        neo.responses["historical_data"] = {"status": "success", "data": {"candles": [["t", 1, 2, 0.5, 1.5, 100, 0]]}}
        s, b = await call("POST", "/historical-data", {"neosymbol": "nse_cm|1333", "interval": "D", "from_date": "2026-08-01", "to_date": "2026-09-01"})
        self.assertEqual((s, len(b["data"]["data"]["candles"])), (200, 1))
        self.assertEqual((await call("POST", "/historical-data", {"neosymbol": "nse_cm|1333"}))[0], 400)

    async def test_margin_route_requires_fields_and_passes_them(self):
        neo = self.connect_fake()
        neo.responses["margin_required"] = {"stat": "Ok", "stCode": 200, "marginUsed": "1000"}
        payload = {"exchange_segment": "nse_cm", "price": 20, "order_type": "L", "product": "CNC", "quantity": 5,
                   "instrument_token": "11915", "transaction_type": "B"}
        s, b = await call("POST", "/margin", payload)
        self.assertEqual(s, 200)
        self.assertEqual(dict(neo.calls)["margin_required"]["instrument_token"], "11915")
        self.assertEqual((await call("POST", "/margin", {"exchange_segment": "nse_cm"}))[0], 400)
        self.assertEqual((await call("POST", "/margin", dict(payload, exchange_segment="bad")))[0], 400)

    async def test_whatsmyip_route(self):
        neo = self.connect_fake()
        neo.responses["whatsmyip"] = {"ip": "203.0.113.5"}
        s, b = await call("GET", "/whatsmyip")
        self.assertEqual((s, b["data"]["ip"]), (200, "203.0.113.5"))

    async def test_derivatives_routes_409_when_not_connected(self):
        for m, p, b in (("GET", "/scrip-master", None), ("POST", "/expiries", {"exchange": "nse_fo", "underlying": "N"}),
                        ("POST", "/option-chain", {"exchange": "nse_fo", "underlying": "N"}),
                        ("POST", "/historical-data", {"neosymbol": "nse_cm|1", "interval": "D", "from_date": "a", "to_date": "b"}),
                        ("POST", "/margin", {"exchange_segment": "nse_cm", "price": 1, "order_type": "L", "product": "CNC",
                                             "quantity": 1, "instrument_token": "1", "transaction_type": "B"}),
                        ("GET", "/whatsmyip", None)):
            self.assertEqual((await call(m, p, b))[0], 409, p)


class RiskAndPnlRouteTests(ServerBase):
    async def test_risk_settings_validation_and_audit(self):
        s, b = await call("POST", "/risk-settings", {"max_order_quantity": 10, "max_order_value": 5000.5, "max_daily_loss": 1000})
        self.assertEqual((s, b["risk"]["max_order_quantity"], b["risk"]["max_daily_loss"]), (200, 10, 1000.0))
        for bad in ({"max_order_quantity": -1}, {"max_order_quantity": 1.5}, {"max_order_value": "abc"}, {"max_daily_loss": True}):
            self.assertEqual((await call("POST", "/risk-settings", bad))[0], 400, bad)
        s, b = await call("POST", "/risk-settings", {"max_order_quantity": None})
        self.assertIsNone(b["risk"]["max_order_quantity"])
        self.assertTrue(any(l["action"] == "risk.settings_updated" for l in self.db.list_audit_logs()))

    async def test_pnl_separates_paper_and_live(self):
        self.db.record_market_tick(instrument_token="11915", exchange_segment="nse_cm", last_traded_price=25.0, trading_symbol="YESBANK-EQ")
        self.db.record_trade(broker_trade_id="P1", order_id=None, broker_order_id=None, fill_quantity=10, fill_price=20.0, fill_time=None,
                             raw_payload={}, mode="PAPER", trading_symbol="YESBANK-EQ", exchange_segment="nse_cm", transaction_type="B", product="MIS")
        s, b = await call("GET", "/pnl")
        self.assertEqual(s, 200)
        self.assertAlmostEqual(b["paper"]["unrealized"], 50.0)
        self.assertTrue(b["paper"]["complete"])
        self.assertEqual(b["live"]["positions"], [])

    async def test_arm_requires_live_mode_confirmation_and_readiness(self):
        self.assertEqual((await call("POST", "/risk/arm-live", {"confirm": "ARM LIVE TRADING"}))[0], 409)   # PAPER deployment
        with patch.object(server, "config", dataclasses.replace(server.config, trading_mode="LIVE")):
            self.assertEqual((await call("POST", "/risk/arm-live", {}))[0], 400)
            s, b = await call("POST", "/risk/arm-live", {"confirm": "ARM LIVE TRADING"})
            self.assertEqual(s, 409)                        # gates failing (not connected, no limits ...)
            self.assertFalse(b["readiness"]["ready"])
        self.assertFalse(self.db.is_live_armed())

    async def test_disarm_always_allowed(self):
        self.db.set_live_armed(True)
        self.assertEqual((await call("POST", "/risk/disarm-live", {}))[1], {"armed": False})
        self.assertFalse(self.db.is_live_armed())


class SocketSmokeTests(ServerBase):
    async def test_real_socket_roundtrip(self):
        srv = await asyncio.start_server(server._handle_client, "127.0.0.1", 0)
        port = srv.sockets[0].getsockname()[1]
        try:
            r, w = await asyncio.open_connection("127.0.0.1", port)
            w.write(f"GET /status HTTP/1.1\r\nHost: x\r\nX-Internal-Token: {TOKEN}\r\n\r\n".encode())
            await w.drain()
            raw = await asyncio.wait_for(r.read(), 5)
            w.close()
            self.assertIn(b"200 OK", raw.split(b"\r\n")[0])
            self.assertIn(b"tradingMode", raw)
        finally:
            srv.close()
            await srv.wait_closed()


if __name__ == "__main__":
    unittest.main()
