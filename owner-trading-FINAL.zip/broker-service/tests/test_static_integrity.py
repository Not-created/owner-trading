"""Every intra-package import (including lazy ones inside functions) must resolve to a real name.
Guards against the class of bug where a rarely-executed code path imports something that no longer exists."""
import ast
import importlib
import os
import unittest

APP = os.path.join(os.path.dirname(__file__), "..", "app")


class ImportResolutionTests(unittest.TestCase):
    def test_all_relative_imports_resolve(self):
        problems = []
        for f in sorted(os.listdir(APP)):
            if not f.endswith(".py"):
                continue
            with open(os.path.join(APP, f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            for n in ast.walk(tree):
                if isinstance(n, ast.ImportFrom) and n.level == 1:
                    if n.module is None:                      # from . import a, b
                        for a in n.names:
                            try:
                                importlib.import_module(f"app.{a.name}")
                            except Exception as exc:           # noqa: BLE001
                                problems.append(f"{f}: from . import {a.name}: {exc}")
                    else:                                       # from .mod import name
                        try:
                            mod = importlib.import_module(f"app.{n.module}")
                        except Exception as exc:               # noqa: BLE001
                            problems.append(f"{f}: from .{n.module}: {exc}")
                            continue
                        for a in n.names:
                            if not hasattr(mod, a.name):
                                problems.append(f"{f}: .{n.module} has no name {a.name}")
        self.assertEqual(problems, [])

    def test_every_module_imports_cleanly(self):
        for f in sorted(os.listdir(APP)):
            if f.endswith(".py") and f != "main.py":
                importlib.import_module(f"app.{f[:-3]}")

    def test_attribute_access_on_db_module_is_defined(self):
        """`_db.x` / `db.x` used anywhere in app/ must exist in db.py."""
        from app import db
        missing = []
        for f in sorted(os.listdir(APP)):
            if not f.endswith(".py") or f == "db.py":
                continue
            with open(os.path.join(APP, f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            for n in ast.walk(tree):
                if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in ("_db", "db"):
                    if not hasattr(db, n.attr):
                        missing.append(f"{f}: db.{n.attr}")
        self.assertEqual(missing, [])

    def test_attribute_access_on_named_modules(self):
        """Same check for other module aliases used in the code (sdk_adapter, pnl, order_sync, ...)."""
        aliases = {"sdk_adapter": "sdk_adapter", "pnl": "pnl", "order_sync": "order_sync", "_reconciliation": "reconciliation",
                   "_session": "session", "paper_engine": "paper_engine", "live_readiness": "live_readiness",
                   "sdk_conformance": "sdk_conformance", "order_service": "order_service", "_wsm": "websocket_manager"}
        missing = []
        for f in sorted(os.listdir(APP)):
            if not f.endswith(".py"):
                continue
            with open(os.path.join(APP, f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            for n in ast.walk(tree):
                if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in aliases:
                    mod = importlib.import_module(f"app.{aliases[n.value.id]}")
                    if not hasattr(mod, n.attr):
                        missing.append(f"{f}: {n.value.id}.{n.attr}")
        self.assertEqual(missing, [])


if __name__ == "__main__":
    unittest.main()
