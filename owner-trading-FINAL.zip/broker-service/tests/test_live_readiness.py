import dataclasses
import os
import unittest
from unittest.mock import patch

from app import broker_client as bc
from app import live_readiness as lr
from app import sdk_adapter as a
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI
from tests.test_order_lifecycle import mk


def gate(res, gid):
    return next(g for g in res["gates"] if g["id"] == gid)


class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        os.environ.pop("BROKER_SERVICE_TOKEN", None)
        current_state.transition(BrokerState.DISCONNECTED)

    def tearDown(self):
        os.environ.pop("BROKER_SERVICE_TOKEN", None)

    def test_fresh_paper_deployment_is_not_ready_and_says_why(self):
        r = lr.evaluate()
        self.assertFalse(r["ready"])
        self.assertFalse(r["live_orders_can_be_sent"])
        failing = {g["id"] for g in r["gates"] if not g["ok"]}
        for must in ("trading_mode_live", "broker_connected", "risk_limits_configured", "order_feed_connected", "internal_token_set"):
            self.assertIn(must, failing)

    def test_all_gates_can_pass_and_arming_is_separate(self):
        cfg = dataclasses.replace(lr.config, trading_mode="LIVE")
        os.environ["BROKER_SERVICE_TOKEN"] = "x" * 32
        self.db.set_risk_settings({"max_order_quantity": 10, "max_order_value": 5000, "max_orders_per_day": 5, "max_daily_loss": 1000})
        self.db.record_funds_snapshot(available_margin=1000, used_margin=0, raw={})
        ws = {"market": {"connected": True}, "orderFeed": {"connected": True}}
        with patch.object(lr, "config", cfg), patch.object(a, "SDK_AVAILABLE", True), patch.object(a, "SDK_VERSION", "3.0.7"), \
             patch("app.sdk_conformance.check_runtime", return_value=lr.sdk_conformance.ConformanceResult(ok=True, checked=20)), \
             patch("app.credential_manager.credential_manager.has_base_credentials", return_value=True), \
             patch("app.websocket_manager.websocket_manager.status", return_value=ws):
            current_state.transition(BrokerState.CONNECTED)
            r = lr.evaluate()
            self.assertTrue(r["ready"], [g for g in r["gates"] if not g["ok"]])
            self.assertFalse(r["live_orders_can_be_sent"])            # not armed yet
            self.db.set_live_armed(True)
            self.assertTrue(lr.evaluate()["live_orders_can_be_sent"])

    def test_unknown_outcome_order_blocks_readiness(self):
        mk(self.db, status="PENDING_RECONCILE", broker_id=None)
        self.db.update_order(internal_order_id="o1", outcome_unknown=True)
        self.assertFalse(gate(lr.evaluate(), "no_unknown_outcome_orders")["ok"])

    def test_emergency_stop_blocks(self):
        with patch.object(self.db, "is_emergency_stop_active", return_value=True):
            self.assertFalse(gate(lr.evaluate(), "emergency_stop_clear")["ok"])

    def test_missing_limits_named(self):
        self.db.set_risk_settings({"max_order_quantity": 10})
        g = gate(lr.evaluate(), "risk_limits_configured")
        self.assertFalse(g["ok"])
        self.assertIn("max_daily_loss", g["detail"])

    def test_vendor_tamper_is_reported_non_blocking_warning(self):
        with patch("app.sdk_conformance.check_vendor_integrity", return_value=lr.sdk_conformance.ConformanceResult(ok=False, errors=["x modified"])):
            g = gate(lr.evaluate(), "vendored_sdk_unmodified")
        self.assertFalse(g["ok"])
        self.assertFalse(g["blocking"])

    def test_evaluation_is_audited(self):
        lr.evaluate()
        with self.db._connection() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM live_readiness_checks").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
