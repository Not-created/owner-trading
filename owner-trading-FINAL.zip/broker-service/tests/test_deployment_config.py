"""Static checks of the HTTP + HTTPS deployment files (nginx is not installed in CI, so these assert
the properties that matter directly on the templates and on deploy.sh)."""
import os
import re
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as fh:
        return fh.read()


def code(text):
    return "\n".join(l for l in text.splitlines() if not l.strip().startswith("#"))


class NginxTemplateTests(unittest.TestCase):
    def test_http_block_is_always_present_and_never_forces_https(self):
        http = code(read("deployment", "nginx", "owner-trading.http.conf"))
        self.assertIn("listen 80 default_server", http)
        self.assertNotIn("return 301", http)
        self.assertNotIn("return 302", http)
        self.assertNotIn("rewrite", http)
        self.assertIn("/.well-known/acme-challenge/", http)
        self.assertIn("include snippets/owner-trading-locations.conf", http)

    def test_https_block_has_tls_and_shares_the_same_locations(self):
        https = code(read("deployment", "nginx", "owner-trading.https.conf"))
        self.assertIn("listen 443 ssl", https)
        self.assertIn("/etc/letsencrypt/live/__DOMAIN__/fullchain.pem", https)
        self.assertIn("TLSv1.2 TLSv1.3", https)
        self.assertNotIn("TLSv1.0", https)
        self.assertIn("include snippets/owner-trading-locations.conf", https)   # identical behaviour on both ports

    def test_every_proxying_location_forwards_scheme_host_and_client_ip(self):
        loc = code(read("deployment", "nginx", "owner-trading-locations.conf"))
        proxy = code(read("deployment", "nginx", "owner-trading-proxy.conf"))
        # nginx does not inherit proxy_set_header into a location that sets its own: each proxying
        # location must include the proxy snippet (which carries all the headers).
        blocks = re.findall(r"location [^{]+\{(.*?)\n\}", loc, flags=re.S)
        proxying = [b for b in blocks if "proxy_pass" in b or "owner-trading-proxy.conf" in b]
        self.assertGreaterEqual(len(proxying), 3)
        for b in proxying:
            self.assertIn("include snippets/owner-trading-proxy.conf", b)
            self.assertNotIn("proxy_set_header", b, "a location-level proxy_set_header would drop the inherited headers")
        for h in ("Host              $host", "X-Real-IP         $remote_addr", "X-Forwarded-For   $proxy_add_x_forwarded_for", "X-Forwarded-Proto $scheme"):
            self.assertIn(h, proxy)

    def test_no_hsts_because_http_must_stay_usable(self):
        for f in ("owner-trading-locations.conf", "owner-trading.http.conf", "owner-trading.https.conf", "owner-trading-proxy.conf"):
            self.assertNotIn("Strict-Transport-Security", code(read("deployment", "nginx", f)))

    def test_login_endpoint_is_rate_limited_and_secrets_paths_denied(self):
        loc = code(read("deployment", "nginx", "owner-trading-locations.conf"))
        self.assertRegex(loc, r"location = /api/auth/login \{[^}]*limit_req zone=ot_login")
        self.assertIn("deny all", loc)
        self.assertIn("limit_req_zone", read("deployment", "nginx", "owner-trading-zones.conf"))

    def test_old_forced_redirect_templates_are_gone(self):
        self.assertFalse(os.path.exists(os.path.join(ROOT, "deployment", "nginx", "owner-trading.bootstrap.conf")))
        self.assertFalse(os.path.exists(os.path.join(ROOT, "deployment", "nginx", "owner-trading.conf")))


class DeployScriptTests(unittest.TestCase):
    def setUp(self):
        self.s = read("deploy.sh")

    def test_installs_all_nginx_pieces_and_never_fails_without_domain_or_certificate(self):
        for f in ("owner-trading-zones.conf", "owner-trading-proxy.conf", "owner-trading-locations.conf", "owner-trading.http.conf", "owner-trading.https.conf"):
            self.assertIn(f, self.s)
        block = self.s[self.s.index("Nginx reverse proxy"):self.s.index("Health checks")]
        # The certificate/domain-absent paths only warn.
        self.assertIn('warn "No DOMAIN set', block)
        self.assertIn('warn "certbot could not issue', block)
        self.assertNotRegex(block, r"fail \"[^\"]*(certbot|certificate)")

    def test_http_verification_flow_sends_no_forwarded_proto_header(self):
        """The plain-HTTP verification must be real HTTP -- the https header is only ever used on the flow labelled as the HTTPS simulation."""
        lines = [l for l in self.s.splitlines() if l.strip().startswith('session_flow "')]
        http_direct = [l for l in lines if l.startswith('  session_flow "HTTP  -> Express')][0]
        self.assertNotIn("X-Forwarded-Proto", http_direct)
        http_nginx = [l for l in lines if "HTTP  -> nginx" in l][0]
        self.assertNotIn("X-Forwarded-Proto", http_nginx)
        https_sim = [l for l in lines if "HTTPS -> Express" in l][0]
        self.assertIn("X-Forwarded-Proto: https", https_sim)
        self.assertIn("simulated", https_sim)
        real_tls = [l for l in lines if "real TLS" in l][0]
        self.assertIn("https://${DOMAIN}", real_tls)
        self.assertNotIn(" -k", real_tls)          # certificate must actually verify

    def test_verification_checks_cookie_attributes_session_protected_api_and_logout(self):
        f = self.s[self.s.index("session_flow() {"):self.s.index('if [ -n "$NEW_PW" ]; then\n  info "Verifying login')]
        for needle in ("httponly", "samesite=lax", "; *secure", "/api/auth/session", "/api/risk", "/api/auth/logout", "after logout"):
            self.assertIn(needle, f)

    def test_password_never_passed_on_a_command_line(self):
        self.assertIn("--data-binary @-", self.s)
        self.assertNotIn("-d \"$LOGIN_JSON\"", self.s)

    def test_project_password_policy_not_changed(self):
        self.assertNotIn("at least 12", self.s)

    def test_cookie_policy_default_written_and_used(self):
        self.assertIn("SESSION_COOKIE_SECURE auto", self.s)
        self.assertIn("COOKIE_POLICY", self.s)


class ExpressWiringTests(unittest.TestCase):
    def test_app_uses_config_driven_cookie_not_hardcoded_production_flag(self):
        app = read("backend", "src", "app.js")
        self.assertNotIn('secure: config.env === "production"', app)
        self.assertIn("buildSessionCookieOptions(config)", app)
        self.assertIn('app.set("trust proxy", 1)', app)
        self.assertNotIn("secure: false", app)
        sc = read("backend", "src", "config", "sessionCookie.js")
        self.assertIn("httpOnly: true", sc)
        self.assertIn('sameSite: "lax"', sc)
        self.assertNotIn("secure: false", sc)

    def test_session_secret_and_lifetime_preserved(self):
        app = read("backend", "src", "app.js")
        self.assertIn("secret: config.sessionSecret", app)
        cfg = read("backend", "src", "config", "index.js")
        self.assertIn('SESSION_MAX_AGE_MS || "43200000"', cfg)

    def test_frontend_uses_same_origin_relative_api_and_sends_cookies(self):
        client = read("frontend", "src", "api", "client.js")
        self.assertIn('credentials: "include"', client)
        self.assertNotRegex(client, r"https?://")
        for dp, _, fs in os.walk(os.path.join(ROOT, "frontend", "src")):
            for f in fs:
                if f.endswith((".js", ".jsx")):
                    src = read(os.path.relpath(os.path.join(dp, f), ROOT))
                    self.assertNotRegex(re.sub(r"xmlns=\"http://www\.w3\.org/2000/svg\"", "", src), r"fetch\(\s*[\"'`]https?://", f)


if __name__ == "__main__":
    unittest.main()
