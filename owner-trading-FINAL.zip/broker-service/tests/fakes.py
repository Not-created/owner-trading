"""Signature-checked fake of the official NeoAPI.

The fake's methods take **kwargs and validate them against the REAL
signatures parsed (via ast) from the vendored official source: an unknown
keyword, or a missing required one, raises TypeError exactly as calling the
real SDK would. So a fake-backed test cannot pass with a guessed parameter.
Responses are whatever the test scripts (shaped like the official docs).
"""
import ast
import os

_SRC = os.path.join(os.path.dirname(__file__), "..", "vendor", "kotakneoapi", "neo_api_client", "neo_api.py")


def _real_signatures():
    tree = ast.parse(open(_SRC, encoding="utf-8").read())
    out = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "NeoAPI":
            for f in node.body:
                if isinstance(f, ast.FunctionDef):
                    a = f.args
                    pos = [x.arg for x in a.args][1:]
                    req = pos[: len(pos) - len(a.defaults)] if a.defaults else pos
                    out[f.name] = (set(pos), set(req), a.kwarg is not None)
    return out


SIGS = _real_signatures()


class FakeConfiguration:
    def __init__(self):
        self.edit_token = None
        self.edit_sid = None
        self.data_center = None
        self.base_url = None
        self.ucc = None


class FakeNeoAPI:
    """Instantiate like the SDK: FakeNeoAPI(consumer_key=..., environment=...)."""

    def __init__(self, *, consumer_key, environment="prod", **kw):
        unknown = set(kw) - SIGS["__init__"][0]
        if unknown:
            raise TypeError(f"unexpected kwargs {unknown}")
        self.configuration = FakeConfiguration()
        self.calls = []
        self.responses = {}      # method -> response or callable(**kwargs) -> response
        self.login_ok = True
        self.logged_out = False

    def _call(self, name, kwargs):
        pos, req, has_kwargs = SIGS[name]
        unknown = set(kwargs) - pos
        if unknown and not has_kwargs:
            raise TypeError(f"{name}() got unexpected keyword arguments {sorted(unknown)}")
        missing = req - set(kwargs)
        if missing:
            raise TypeError(f"{name}() missing required arguments {sorted(missing)}")
        self.calls.append((name, dict(kwargs)))
        r = self.responses.get(name, {"stat": "Ok", "stCode": 200, "data": []})
        return r(**kwargs) if callable(r) else r

    def totp_login(self, **kw):
        r = self._call("totp_login", kw)
        return r if name_in(self.responses, "totp_login") else {"data": {"status": "success", "kType": "View", "ucc": kw["ucc"]}}

    def totp_validate(self, **kw):
        r = self._call("totp_validate", kw)
        if name_in(self.responses, "totp_validate"):
            return r
        if self.login_ok:
            self.configuration.edit_token, self.configuration.edit_sid = "TOK", "SID"
            self.configuration.data_center, self.configuration.base_url = "e21", "https://e21.kotaksecurities.com"
            return {"data": {"kType": "Trade", "status": "success", "ucc": "UCC1"}}
        return {"error": [{"code": "10519", "message": "Invalid MPIN"}]}

    def logout(self):
        self.logged_out = True
        self.configuration.edit_token = self.configuration.edit_sid = None
        return {"message": "logged out"}

    def __getattr__(self, name):
        if name in SIGS:
            return lambda **kw: self._call(name, kw)
        raise AttributeError(name)


def name_in(d, k):
    return k in d
