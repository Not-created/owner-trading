"""Market (SFeed) and order-feed supervision on the official async SDK clients.

Uses ONLY the SDK's modern clients (`NeoAPI.create_websocket()` -> SFeedWebSocket,
`NeoAPI.create_order_feed()` -> OrderFeedWebSocket) with their documented
callbacks (on_message / on_connect / on_disconnect / on_error) and
`subscribe_scrips(list[WsToken])`. The legacy v2 callback-attribute /
`subscribe(instrument_tokens=...)` handling has been removed.

Division of labour (from the SDK source):
  * The SDK client reconnects on its own (reconnect_delay x max_reconnect_attempts)
    and re-sends its own subscriptions.
  * THIS supervisor covers what the SDK does not: (a) a client that gave up
    (is_connected stays False past the SDK's own retry window) -> build a new
    client from the current session, back off, resubscribe from our registry;
    (b) after ANY (re)connect of the order feed -> REST reconciliation, because
    order events sent while disconnected are not replayed;
    (c) repeated failures -> probe the session with a read-only limits() call so
    an expired session moves the service to SESSION_EXPIRED instead of looping.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any

from . import db as _db
from . import order_sync, sdk_adapter
from .broker_client import NotConfiguredError, broker_client
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket")

# SDK retries internally for about reconnect_delay * max_reconnect_attempts (5s * 5).
SDK_RECONNECT_WINDOW_SECONDS = 30
LOST_GRACE_SECONDS = SDK_RECONNECT_WINDOW_SECONDS + 10
BACKOFF_START, BACKOFF_MAX = 2.0, 60.0
PROBE_AFTER_FAILURES = 3
TICK_WRITE_INTERVAL_SECONDS = 1.0
STALE_AFTER_SECONDS = 90   # informational only: silence is normal outside market hours
_TICK_TYPES = ("scrip", "scrip_lite", "index")


class WebSocketManager:
    def __init__(self) -> None:
        self._subs: dict[tuple[str, str], None] = {}      # registry: (exchange_segment, token)
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()
        self._market: Any = None
        self._order: Any = None
        self._last_market_msg: float | None = None
        self._last_order_msg: float | None = None
        self._last_tick_write: dict[tuple[str, str], float] = {}
        self._reconnects = {"market": 0, "order": 0}
        self._reconcile_task: asyncio.Task | None = None

    # ------------------------------------------------------------ lifecycle
    @property
    def running(self) -> bool:
        return any(not t.done() for t in self._tasks)

    async def start(self) -> None:
        if self.running:
            return
        self._stop = asyncio.Event()
        self._tasks = [
            asyncio.create_task(self._supervise("market", self._run_market)),
            asyncio.create_task(self._supervise("order", self._run_order)),
        ]

    async def stop(self) -> None:
        self._stop.set()
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        self._tasks = []
        for feed in (self._market, self._order):
            await self._safe_close(feed)
        self._market = self._order = None

    @staticmethod
    async def _safe_close(feed) -> None:
        if feed is None:
            return
        try:
            await feed.close()
        except Exception:  # noqa: BLE001
            pass

    # -------------------------------------------------------- subscriptions
    async def subscribe(self, exchange_segment: str, instrument_token: str) -> None:
        if exchange_segment not in sdk_adapter.EXCHANGE_SEGMENTS:
            raise ValueError(f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}.")
        key = (exchange_segment, str(instrument_token))
        self._subs[key] = None
        feed = self._market
        if feed is not None and feed.is_connected:
            await feed.subscribe_scrips([sdk_adapter.make_ws_token(*key)])

    async def unsubscribe(self, exchange_segment: str, instrument_token: str) -> None:
        key = (exchange_segment, str(instrument_token))
        self._subs.pop(key, None)
        feed = self._market
        if feed is not None and feed.is_connected:
            await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*key)])

    def subscriptions(self) -> list[dict]:
        return [{"exchange_segment": s, "instrument_token": t} for s, t in self._subs]

    # ------------------------------------------------------------- status
    def is_stale(self) -> bool:
        """True when a market subscription exists, the feed claims to be
        connected, and nothing arrived for STALE_AFTER_SECONDS. Informational
        (no ticks is normal when the market is closed); never forces a reconnect."""
        if not self._subs or self._market is None or not self._market.is_connected:
            return False
        if self._last_market_msg is None:
            return False
        return (time.time() - self._last_market_msg) > STALE_AFTER_SECONDS

    def status(self) -> dict:
        m, o = self._market, self._order
        return {
            "running": self.running,
            "market": {"connected": bool(m and m.is_connected), "subscriptions": len(self._subs),
                       "lastMessageAt": self._last_market_msg, "reconnects": self._reconnects["market"], "stale": self.is_stale()},
            "orderFeed": {"connected": bool(o and o.is_connected), "lastMessageAt": self._last_order_msg,
                          "reconnects": self._reconnects["order"]},
        }

    # ----------------------------------------------------------- supervisor
    async def _supervise(self, name: str, runner) -> None:
        backoff, failures = BACKOFF_START, 0
        while not self._stop.is_set():
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                await self._sleep(2.0)   # no valid session: nothing to (re)connect to
                continue
            started = time.time()
            try:
                await runner()
                failures = 0
            except asyncio.CancelledError:
                raise
            except NotConfiguredError:
                await self._sleep(2.0)
                continue
            except Exception as exc:  # noqa: BLE001
                failures += 1
                logger.warning("%s feed failed (%s: %s); failure %d.", name, type(exc).__name__, exc, failures)
            self._reconnects[name] += 1
            if time.time() - started > 60:      # a long healthy run resets backoff
                backoff, failures = BACKOFF_START, 0
            if failures >= PROBE_AFTER_FAILURES:
                await self._probe_session()
                failures = 0
            await self._sleep(backoff * (1 + random.uniform(0, 0.25)))
            backoff = min(backoff * 2, BACKOFF_MAX)

    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _probe_session(self) -> None:
        """Read-only limits(); an AUTH outcome flips state to SESSION_EXPIRED inside broker_client."""
        try:
            await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("limits"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session probe failed: %s", exc)

    async def _hold_until_lost(self, feed) -> None:
        """Returns once `feed` has been disconnected longer than the SDK's own retry window."""
        down_since: float | None = None
        while not self._stop.is_set():
            await asyncio.sleep(1.0)
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                return
            if feed.is_connected:
                down_since = None
            else:
                down_since = down_since or time.time()
                if time.time() - down_since > LOST_GRACE_SECONDS:
                    return

    # ------------------------------------------------------------- market
    async def _run_market(self) -> None:
        feed = broker_client.create_market_feed()
        self._market = feed
        feed.on_message = self._on_market_message
        feed.on_error = lambda e: logger.warning("SFeed error: %s", e)
        feed.on_connect = lambda: self._on_market_connect(feed)
        try:
            await feed.connect()
            await self._resubscribe(feed)
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    async def _resubscribe(self, feed) -> None:
        tokens = [sdk_adapter.make_ws_token(s, t) for s, t in self._subs]
        for i in range(0, len(tokens), 500):
            await feed.subscribe_scrips(tokens[i:i + 500])

    def _on_market_connect(self, feed) -> None:
        # SDK-internal reconnects re-send its own subscriptions; if the counts
        # disagree (e.g. a new client), our registry is authoritative.
        if feed.subscription_count < len(self._subs):
            asyncio.get_running_loop().create_task(self._resubscribe(feed))

    def _on_market_message(self, message) -> None:
        self._last_market_msg = time.time()
        mtype = getattr(message, "type", None)
        if mtype not in _TICK_TYPES:
            return
        seg, tok = getattr(message, "exchange_segment", None), getattr(message, "instrument_token", None)
        ltp = getattr(message, "last_traded_price", None)
        if not tok or ltp is None:
            return
        now = time.time()
        key = (seg or "", str(tok))
        if now - self._last_tick_write.get(key, 0) < TICK_WRITE_INTERVAL_SECONDS:
            return
        self._last_tick_write[key] = now
        try:
            _db.record_market_tick(
                instrument_token=str(tok), exchange_segment=seg, last_traded_price=float(ltp),
                trading_symbol=getattr(message, "trading_symbol", None),
                close_price=getattr(message, "close_price", None),
                volume=getattr(message, "volume_traded_today", None),
            )
        except Exception as exc:  # noqa: BLE001 -- a DB hiccup must not kill the receive loop
            logger.warning("Failed to persist tick: %s", exc)

    # -------------------------------------------------------- order feed
    async def _run_order(self) -> None:
        feed = broker_client.create_order_feed()
        self._order = feed
        feed.on_message = self._on_order_message
        feed.on_error = lambda e: logger.warning("Order feed error: %s", e)
        feed.on_connect = lambda: self._schedule_reconcile("order feed connected")
        try:
            await feed.connect()
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    def _on_order_message(self, message) -> None:
        self._last_order_msg = time.time()
        mtype = getattr(message, "type", None)
        try:
            if mtype == "order":
                row = message.data.model_dump(by_alias=True)
                res = order_sync.apply_order_row(row, source="order_feed")
                if res["matched"] and res["changed"]:
                    self._schedule_reconcile("order update")   # picks up fills/positions via REST (authoritative)
            elif mtype == "position":
                self._schedule_reconcile("position update")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to process order-feed message: %s", exc)

    def _schedule_reconcile(self, reason: str) -> None:
        """Debounced: at most one pending reconciliation task."""
        if self._reconcile_task and not self._reconcile_task.done():
            return
        from . import reconciliation

        async def _go():
            await asyncio.sleep(1.5)
            try:
                await reconciliation.run_full_reconciliation()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconciliation (%s) failed: %s", reason, exc)

        try:
            self._reconcile_task = asyncio.get_running_loop().create_task(_go())
        except RuntimeError:
            pass


websocket_manager = WebSocketManager()
