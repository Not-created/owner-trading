"""In-memory holder for Kotak credentials submitted via the Settings UI.

Design decision for this phase: credentials submitted through the "Save"
action are held ONLY in this process's memory, for the broker-service
process's lifetime -- never written to disk, never logged, never echoed
back to any API response. This is a deliberate, documented tradeoff: a
broker-service restart requires re-saving credentials (or the operator can
still populate /etc/owner-trading/broker.env for the env-var path that
config.py already reads at startup, which IS the persistent option). This
module is the ONLY thing allowed to hold the raw values.

TOTP: the official SDK's own dependency list (kotakneoapi's package
metadata, confirmed during the earlier SDK audit) includes `pyotp` --
strong, source-grounded evidence that the intended integration pattern is
storing the TOTP *secret* (the seed used to set up an authenticator app)
once, and generating a fresh 6-digit code at each login attempt via
`pyotp.TOTP(secret).now()`, rather than requiring a human to type a live
code on every single connect/reconnect. This module stores the secret; the
current numeric code is generated on demand in broker_client.py and is
never itself persisted or logged.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


class CredentialFormatError(ValueError):
    """Raised by CredentialManager.set() when a value is shaped in a way
    the real Kotak API will reject -- caught by the /credentials HTTP
    handler in server.py and reported back as a 400, never silently
    accepted and only failing later inside a real totp_login() call.
    """


# Every official Kotak Neo SDK example (v2.0.2's Kotak-Neo-api-v2 README
# and the kotakneoapi package page, both fetched during this audit) shows
# totp_login() called with the mobile number in full E.164 form, country
# code included: mobile_number="+919876543210". The current Settings UI/
# Express-side validation (kotakCredentialValidation.js) still accepts a
# bare 10-digit number for backward compatibility, so this is the one place
# that normalizes it to what the SDK actually expects before any network
# call is made -- never guessing, always this exact, documented shape.
_BARE_10_DIGIT = re.compile(r"^\d{10}$")
_E164_LIKE = re.compile(r"^\+\d{1,3}\d{6,14}$")
_MPIN = re.compile(r"^\d{4,6}$")


def normalize_mobile_number(value: str, *, default_country_code: str = "+91") -> str:
    """Returns the SDK-ready E.164 form. Raises CredentialFormatError for
    anything that isn't clearly one of the two accepted input shapes --
    never silently passes through something malformed."""
    value = (value or "").strip()
    if _E164_LIKE.match(value):
        return value
    if _BARE_10_DIGIT.match(value):
        return f"{default_country_code}{value}"
    raise CredentialFormatError(
        "Mobile number must be a bare 10-digit number or include a country code, e.g. +919876543210."
    )


try:
    import pyotp

    PYOTP_AVAILABLE = True
except ImportError:
    # Same offline-degrade pattern as the NeoAPI import in broker_client.py
    # -- pyotp ships as a transitive dependency of kotakneoapi, so it is
    # only actually importable once that package is installed.
    pyotp = None
    PYOTP_AVAILABLE = False


@dataclass
class KotakCredentials:
    consumer_key: str
    mobile_number: str
    ucc: str
    mpin: str
    totp_secret: str


class CredentialManager:
    def __init__(self) -> None:
        self._creds: KotakCredentials | None = None

    def set(self, *, consumer_key: str, mobile_number: str, ucc: str, mpin: str, totp_secret: str) -> None:
        """Validates and normalizes any value that IS supplied before
        storing, so a malformed mobile number or MPIN is rejected here (400
        back to the caller) instead of being stored as-is and only
        discovered later as an opaque totp_login()/totp_validate() failure.

        Deliberately does NOT require every field to be non-empty -- that
        is a separate concern (has_base_credentials()/NOT_CONFIGURED)
        already handled by callers, and the HTTP layer (server.py's
        /credentials handler) already rejects a request missing a field
        before this is ever called.
        """
        if mpin and not _MPIN.match(mpin):
            raise CredentialFormatError("MPIN must be 4-6 digits.")
        normalized_mobile = normalize_mobile_number(mobile_number) if mobile_number else mobile_number
        self._creds = KotakCredentials(
            consumer_key=consumer_key,
            mobile_number=normalized_mobile,
            ucc=ucc,
            mpin=mpin,
            totp_secret=totp_secret,
        )

    def get(self) -> KotakCredentials | None:
        return self._creds

    def current_totp_code(self) -> str | None:
        """Generates the live 6-digit TOTP code from the stored secret.
        Returns None if no secret is stored or pyotp isn't installed --
        callers must treat that as "cannot authenticate right now", never
        substitute a fake code.
        """
        if self._creds is None or not self._creds.totp_secret:
            return None
        if not PYOTP_AVAILABLE:
            return None
        return pyotp.TOTP(self._creds.totp_secret).now()

    def has_base_credentials(self) -> bool:
        c = self._creds
        return bool(c and c.consumer_key and c.mobile_number and c.ucc and c.mpin and c.totp_secret)

    def clear(self) -> None:
        self._creds = None

    def masked_summary(self) -> dict:
        """Safe-to-return summary for status endpoints -- never the actual
        values, only whether they're present and a masked hint."""
        from .secure_store import redact

        c = self._creds
        if c is None:
            return {"configured": False}
        return {
            "configured": True,
            "consumerKey": redact(c.consumer_key),
            "mobileNumber": redact(c.mobile_number),
            "ucc": redact(c.ucc),
            "totpConfigured": bool(c.totp_secret),
        }


# Module-level singleton -- one broker service process, one credential set.
credential_manager = CredentialManager()
