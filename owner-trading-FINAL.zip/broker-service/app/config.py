"""Configuration for the broker service, read entirely from environment
variables. Nothing here contains a real secret -- in this phase, all of
these are expected to be UNSET, and the service must behave correctly
(report NOT_CONFIGURED) when they are.
"""
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    # Local-only HTTP interface the Express backend talks to. Never bind
    # this to a public interface -- it carries no auth of its own because
    # it is only ever reachable from localhost (Express runs on the same
    # host, per the systemd units in deployment/systemd/).
    host: str = os.environ.get("BROKER_SERVICE_HOST", "127.0.0.1")
    port: int = int(os.environ.get("BROKER_SERVICE_PORT", "8800"))

    # Kotak Neo credentials. All optional at this phase -- if any required
    # value is missing, the service reports NOT_CONFIGURED rather than
    # attempting to connect. None of these are ever logged.
    consumer_key: str | None = os.environ.get("KOTAK_CONSUMER_KEY") or None
    consumer_secret: str | None = os.environ.get("KOTAK_CONSUMER_SECRET") or None
    mobile_number: str | None = os.environ.get("KOTAK_MOBILE_NUMBER") or None
    ucc: str | None = os.environ.get("KOTAK_UCC") or None
    totp_secret: str | None = os.environ.get("KOTAK_TOTP_SECRET") or None
    mpin: str | None = os.environ.get("KOTAK_MPIN") or None
    environment: str = os.environ.get("KOTAK_ENVIRONMENT", "prod")

    # PAPER never calls Kotak; LIVE is additionally gated by the Express
    # backend's requireLiveTradingAllowed middleware. This service enforces
    # its own copy of the same rule independently (defense in depth).
    trading_mode: str = os.environ.get("TRADING_MODE", "PAPER")

    # Where the scrip master cache and any session-reconstruction artifacts
    # are written. Kept outside the SQLite DB (which the Express side owns)
    # to avoid two processes writing the same file.
    data_dir: str = os.environ.get("BROKER_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "data"))

    # Pre-trade risk limits (Phase: risk management). Unset/0 means "no
    # limit configured" -- deliberately NOT defaulted to a specific number
    # here, since a safe default for one account is meaningless for
    # another; an operator who wants these enforced must set them
    # explicitly. See order_service.py's _check_risk_limits() for how each
    # is applied, and the final report for what this does and does not
    # cover (there is no per-strategy exposure engine yet -- these are
    # global limits only).
    max_order_quantity: int = int(os.environ.get("MAX_ORDER_QUANTITY", "0") or "0")
    max_orders_per_day: int = int(os.environ.get("MAX_ORDERS_PER_DAY", "0") or "0")

    def is_fully_configured(self) -> bool:
        """True only when every credential this phase's auth flow needs is
        present. Does NOT mean authenticated -- see state.py."""
        return all([self.consumer_key, self.mobile_number, self.ucc, self.totp_secret, self.mpin])


config = Config()
