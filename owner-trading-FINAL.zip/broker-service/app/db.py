"""Shared-database writer for the broker service.

The Node backend OWNS the SQLite schema (see
backend/src/db/migrations/001_init.sql) and runs all migrations -- this
module only ever INSERTs into tables that already exist, using the same
file (DB_PATH env var, matching backend/src/config/index.js's default of
backend/data/owner-trading.db). SQLite's WAL mode (enabled by the Node side
in db/client.js) safely supports this: one writer at a time, with SQLite
handling the locking -- both processes retry-on-busy rather than corrupt
data.

Every insert here is written to be idempotent against the UNIQUE
constraints already in the schema (order_events.(event_source,
broker_event_id), trades.broker_trade_id) using INSERT OR IGNORE, so a
duplicated WebSocket message or a retried REST reconciliation can never
double-record the same event -- this is the "duplicate-event protection /
idempotency" requirement implemented concretely, not just described.

Order/position/holding/funds persistence and audit logging (Phase 1C) are
called from order_service.py, reconciliation.py, and server.py's new
routes -- see those modules for how each function here is actually used.
"""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "data", "owner-trading.db"
)
DB_PATH = os.environ.get("DB_PATH", DEFAULT_DB_PATH)


@contextmanager
def _connection():
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def record_order_event(
    *,
    event_source: str,
    broker_event_id: str | None,
    raw_payload: dict,
    order_id: int | None = None,
    broker_order_id: str | None = None,
) -> bool:
    """Idempotent insert into order_events. Returns True if a new row was
    written, False if this exact (event_source, broker_event_id) was
    already recorded (duplicate, correctly ignored).
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO order_events
               (order_id, broker_order_id, event_source, broker_event_id, raw_payload)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, event_source, broker_event_id, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def record_trade(
    *, broker_trade_id: str, order_id: int | None, broker_order_id: str | None,
    fill_quantity: int, fill_price: float, fill_time: str | None, raw_payload: dict,
    mode: str = "LIVE", trading_symbol: str | None = None, exchange_segment: str | None = None,
    transaction_type: str | None = None, product: str | None = None, multiplier: float | None = None,
) -> bool:
    """Idempotent insert keyed on broker_trade_id (each partial fill has its
    own id; re-delivery is a no-op)."""
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO trades
               (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, raw_payload,
                mode, trading_symbol, exchange_segment, transaction_type, product, multiplier)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, json.dumps(raw_payload),
             mode, trading_symbol, exchange_segment, transaction_type, product, multiplier),
        )
        return cur.rowcount == 1


def list_trades(*, mode: str | None = None, limit: int = 1000) -> list[dict]:
    limit = max(1, min(limit, 5000))
    sql = ("SELECT id, order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, "
           "mode, trading_symbol, exchange_segment, transaction_type, product, multiplier FROM trades")
    params: list = []
    if mode:
        sql += " WHERE mode = ?"
        params.append(mode)
    sql += " ORDER BY id ASC LIMIT ?"
    keys = ["id", "order_id", "broker_order_id", "broker_trade_id", "fill_quantity", "fill_price", "fill_time",
            "mode", "trading_symbol", "exchange_segment", "transaction_type", "product", "multiplier"]
    with _connection() as conn:
        return [dict(zip(keys, r)) for r in conn.execute(sql, (*params, limit)).fetchall()]


# ---- risk settings / live arming (singleton row id=1, migration 003) ----
_RISK_KEYS = ("max_order_quantity", "max_order_value", "max_orders_per_day", "max_daily_loss", "max_open_positions")


def get_risk_settings() -> dict:
    with _connection() as conn:
        row = conn.execute(
            "SELECT max_order_quantity, max_order_value, max_orders_per_day, max_daily_loss, max_open_positions, "
            "live_trading_armed, armed_at FROM risk_settings WHERE id = 1"
        ).fetchone()
    if not row:
        return {k: None for k in _RISK_KEYS} | {"live_trading_armed": False, "armed_at": None}
    d = dict(zip(_RISK_KEYS, row[:5]))
    d["live_trading_armed"] = bool(row[5])
    d["armed_at"] = row[6]
    return d


def set_risk_settings(values: dict) -> dict:
    """Only the five limit keys are writable here; None/absent clears a limit."""
    with _connection() as conn:
        for k in _RISK_KEYS:
            if k in values:
                conn.execute(f"UPDATE risk_settings SET {k} = ?, updated_at = datetime('now') WHERE id = 1", (values[k],))
    return get_risk_settings()


def is_live_armed() -> bool:
    with _connection() as conn:
        row = conn.execute("SELECT live_trading_armed FROM risk_settings WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


def set_live_armed(armed: bool) -> None:
    with _connection() as conn:
        conn.execute(
            "UPDATE risk_settings SET live_trading_armed = ?, armed_at = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END, "
            "updated_at = datetime('now') WHERE id = 1", (1 if armed else 0, 1 if armed else 0),
        )


def record_live_readiness(ready: bool, details: dict) -> None:
    with _connection() as conn:
        conn.execute("INSERT INTO live_readiness_checks (ready, details) VALUES (?, ?)", (1 if ready else 0, json.dumps(details)))


def is_emergency_stop_active() -> bool:
    """Reads the shared emergency_stop_state singleton row (owned/migrated
    by the Node backend). Read-only from this side -- only the Express API
    is meant to toggle it (next phase: an explicit owner-triggered action).
    """
    with _connection() as conn:
        row = conn.execute("SELECT is_active FROM emergency_stop_state WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


# BUGFIX (final audit): broker_sessions (001_init.sql) was defined in the
# schema but never referenced by any code anywhere -- pure dead schema.
# Rather than delete a table that's a genuinely useful audit trail (when
# was each session established/revoked, from which data center), this
# wires it up: session.py calls these two functions on every
# established/ended transition, so broker_sessions becomes a real,
# queryable history instead of an always-empty table.
def record_session_started(*, data_center: str | None, expires_at_iso: str | None) -> None:
    with _connection() as conn:
        account = conn.execute("SELECT id FROM broker_accounts ORDER BY id ASC LIMIT 1").fetchone()
        if account is None:
            # No account row exists yet (Settings UI hasn't saved account
            # metadata) -- session history has nowhere to attach; skip
            # rather than violate the NOT NULL broker_account_id FK.
            return
        conn.execute(
            """INSERT INTO broker_sessions (broker_account_id, session_ref, data_center, established_at, expires_at)
               VALUES (?, ?, ?, datetime('now'), ?)""",
            (account[0], None, data_center, expires_at_iso),
        )


def record_session_ended() -> None:
    """Marks the most recent still-open (revoked_at IS NULL) session row as
    revoked now. Idempotent: a second call with nothing open is a no-op."""
    with _connection() as conn:
        conn.execute(
            """UPDATE broker_sessions SET revoked_at = datetime('now')
               WHERE id = (SELECT id FROM broker_sessions WHERE revoked_at IS NULL ORDER BY id DESC LIMIT 1)"""
        )


def record_reconciliation(
    *, reconciliation_type: str, reference_id: str | None, discrepancy_found: bool, details: dict | None
) -> None:
    """Always inserts (not idempotent by design -- every reconciliation
    pass is its own audit record, even if the result matches the last one).
    """
    with _connection() as conn:
        conn.execute(
            """INSERT INTO reconciliation_records
               (reconciliation_type, reference_id, discrepancy_found, details)
               VALUES (?, ?, ?, ?)""",
            (reconciliation_type, reference_id, 1 if discrepancy_found else 0, json.dumps(details) if details else None),
        )


# ==================================================================== #
# Phase 1C: order/position/holding/funds persistence + audit logging.
# Everything below writes into tables the Node backend already migrated
# (001_init.sql) -- see that file for column definitions. Nothing here
# invents a schema; it only starts actually using what was already there.
# ==================================================================== #


def write_audit_log(*, actor: str, action: str, details: dict | None = None) -> None:
    """Appends to audit_logs. Never raises into the caller's control flow
    for anything except a genuinely broken DB -- an audit-log write failing
    must not itself block a real order/connection action, but every
    call site should still know a total DB outage is a serious problem,
    so this deliberately does NOT swallow exceptions; callers that must
    not fail on audit-log trouble wrap this themselves (see order_service.py).
    """
    with _connection() as conn:
        conn.execute(
            "INSERT INTO audit_logs (actor, action, details) VALUES (?, ?, ?)",
            (actor, action, json.dumps(details) if details is not None else None),
        )


def list_audit_logs(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            "SELECT id, actor, action, details, created_at FROM audit_logs ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {
                "id": r[0],
                "actor": r[1],
                "action": r[2],
                "details": json.loads(r[3]) if r[3] else None,
                "created_at": r[4],
            }
            for r in rows
        ]


_ORDER_COLS = [
    "id", "internal_order_id", "broker_order_id", "trading_symbol", "exchange_segment",
    "transaction_type", "order_type", "product", "validity", "quantity", "price",
    "trigger_price", "mode", "status", "status_reason", "submitted_at", "updated_at", "created_at",
    "client_tag", "exchange_order_id", "filled_quantity", "average_price", "broker_status",
    "outcome_unknown", "last_broker_update_at", "instrument_token", "pnl_realized",
]
_ORDER_SELECT = "SELECT " + ", ".join(_ORDER_COLS) + " FROM orders"

# Order status vocabulary. Terminal states never regress (a late/duplicate
# feed message cannot re-open a completed/cancelled/rejected order).
TERMINAL_STATUSES = ("COMPLETE", "CANCELLED", "REJECTED")


def create_order(
    *,
    internal_order_id: str,
    trading_symbol: str,
    exchange_segment: str | None,
    transaction_type: str,
    order_type: str,
    product: str,
    validity: str,
    quantity: int,
    price: float | None,
    trigger_price: float | None,
    mode: str,
    status: str,
    status_reason: str | None = None,
    broker_order_id: str | None = None,
    client_tag: str | None = None,
    instrument_token: str | None = None,
) -> int:
    """Inserts a new local order row BEFORE any broker call, so every request
    has a durable record (and a client_tag to reconcile by) even if the
    broker call times out ambiguously."""
    with _connection() as conn:
        cur = conn.execute(
            """INSERT INTO orders
               (internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason, submitted_at, client_tag, instrument_token)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), ?, ?)""",
            (
                internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason, client_tag, instrument_token,
            ),
        )
        return cur.lastrowid


def update_order(
    *, internal_order_id: str, status: str | None = None, status_reason: str | None = None,
    broker_order_id: str | None = None, outcome_unknown: bool | None = None,
) -> None:
    """Partial update by internal_order_id -- only columns explicitly passed
    are changed. Never moves an order OUT of a terminal state."""
    with _connection() as conn:
        sets = ["updated_at = datetime('now')"]
        params: list = []
        if status is not None:
            sets.append("status = ?")
            params.append(status)
        if status_reason is not None:
            sets.append("status_reason = ?")
            params.append(status_reason)
        if broker_order_id is not None:
            sets.append("broker_order_id = ?")
            params.append(broker_order_id)
        if outcome_unknown is not None:
            sets.append("outcome_unknown = ?")
            params.append(1 if outcome_unknown else 0)
        params.append(internal_order_id)
        guard = ""
        if status is not None:
            guard = " AND status NOT IN ('COMPLETE','CANCELLED','REJECTED')"
        conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?{guard}", params)


def update_order_fields(
    *, internal_order_id: str, quantity: int | None = None, price: float | None = None,
    trigger_price: float | None = None,
) -> None:
    """Fields a modify actually changes (what the order IS, not its state)."""
    sets = []
    params: list = []
    if quantity is not None:
        sets.append("quantity = ?")
        params.append(quantity)
    if price is not None:
        sets.append("price = ?")
        params.append(price)
    if trigger_price is not None:
        sets.append("trigger_price = ?")
        params.append(trigger_price)
    if not sets:
        return
    sets.append("updated_at = datetime('now')")
    params.append(internal_order_id)
    with _connection() as conn:
        conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?", params)


def apply_broker_order_state(
    *, internal_order_id: str, status: str, broker_status: str | None,
    filled_quantity: int | None = None, average_price: float | None = None,
    exchange_order_id: str | None = None, broker_order_id: str | None = None,
    status_reason: str | None = None,
) -> bool:
    """Applies broker-reported order state (order feed OR REST order_report)
    to a local order. Rules (each covered by tests):
      * a terminal local status is never overwritten;
      * filled_quantity only ever increases (feed messages can arrive
        out of order or be re-delivered);
      * average_price is only replaced when the fill count grows.
    Returns True if any column changed."""
    with _connection() as conn:
        row = conn.execute(
            "SELECT status, filled_quantity FROM orders WHERE internal_order_id = ?", (internal_order_id,)
        ).fetchone()
        if row is None:
            return False
        cur_status, cur_filled = row[0], row[1] or 0
        sets = ["last_broker_update_at = datetime('now')", "updated_at = datetime('now')", "outcome_unknown = 0"]
        params: list = []
        if broker_status is not None:
            sets.append("broker_status = ?")
            params.append(broker_status)
        if cur_status not in TERMINAL_STATUSES:
            sets.append("status = ?")
            params.append(status)
            if status_reason is not None:
                sets.append("status_reason = ?")
                params.append(status_reason)
        new_filled = cur_filled
        if filled_quantity is not None and filled_quantity > cur_filled:
            new_filled = filled_quantity
            sets.append("filled_quantity = ?")
            params.append(filled_quantity)
            if average_price is not None:
                sets.append("average_price = ?")
                params.append(average_price)
        elif filled_quantity is not None and filled_quantity == cur_filled and average_price and cur_filled:
            sets.append("average_price = COALESCE(average_price, ?)")
            params.append(average_price)
        if exchange_order_id:
            sets.append("exchange_order_id = ?")
            params.append(exchange_order_id)
        if broker_order_id:
            sets.append("broker_order_id = COALESCE(broker_order_id, ?)")
            params.append(broker_order_id)
        params.append(internal_order_id)
        cur = conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?", params)
        return cur.rowcount == 1


def get_order(internal_order_id: str) -> dict | None:
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE internal_order_id = ?", (internal_order_id,)).fetchone()
        return _order_row_to_dict(row) if row else None


def get_order_by_broker_order_id(broker_order_id: str) -> dict | None:
    """Maps an incoming feed/report row (identified by the broker's nOrdNo)
    back to our local order."""
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE broker_order_id = ? ORDER BY id DESC LIMIT 1", (broker_order_id,)).fetchone()
        return _order_row_to_dict(row) if row else None


def get_order_by_client_tag(client_tag: str) -> dict | None:
    """Recovers an order whose placement outcome was UNKNOWN: the broker echoes
    our `tag` back as GuiOrdId in order_report()/trade_report()."""
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE client_tag = ?", (client_tag,)).fetchone()
        return _order_row_to_dict(row) if row else None


def list_orders(*, limit: int = 200, mode: str | None = None, open_only: bool = False) -> list[dict]:
    limit = max(1, min(limit, 1000))
    where, params = [], []
    if mode:
        where.append("mode = ?")
        params.append(mode)
    if open_only:
        where.append("status NOT IN ('COMPLETE','CANCELLED','REJECTED')")
    sql = _ORDER_SELECT + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id DESC LIMIT ?"
    with _connection() as conn:
        return [_order_row_to_dict(r) for r in conn.execute(sql, (*params, limit)).fetchall()]


def list_unresolved_live_orders() -> list[dict]:
    """LIVE orders whose broker outcome/state still needs to be established:
    placement outcome UNKNOWN, or submitted but not yet terminal."""
    with _connection() as conn:
        rows = conn.execute(
            _ORDER_SELECT + " WHERE mode = 'LIVE' AND (outcome_unknown = 1 OR "
            "(status NOT IN ('COMPLETE','CANCELLED','REJECTED') AND status NOT IN ('SUBMITTING'))) ORDER BY id ASC"
        ).fetchall()
        return [_order_row_to_dict(r) for r in rows]


def count_orders_today(*, mode: str | None = None) -> int:
    """Used by order_service.py's max_orders_per_day check. Counts by
    `created_at` (SQLite UTC) on the current UTC calendar day; rejected
    local-validation failures are never inserted, so they don't count."""
    with _connection() as conn:
        if mode:
            row = conn.execute(
                "SELECT COUNT(*) FROM orders WHERE date(created_at) = date('now') AND mode = ?", (mode,)
            ).fetchone()
        else:
            row = conn.execute("SELECT COUNT(*) FROM orders WHERE date(created_at) = date('now')").fetchone()
        return row[0] if row else 0


def sum_filled_quantity(order_id: int) -> int:
    """Sum of recorded fills for one local order (by integer `id`)."""
    with _connection() as conn:
        row = conn.execute("SELECT COALESCE(SUM(fill_quantity), 0) FROM trades WHERE order_id = ?", (order_id,)).fetchone()
        return row[0] if row else 0


def _order_row_to_dict(row) -> dict:
    return dict(zip(_ORDER_COLS, row))


def record_market_tick(
    *, instrument_token: str, exchange_segment: str | None, last_traded_price: float | None,
    trading_symbol: str | None = None, close_price: float | None = None, volume: int | None = None,
) -> None:
    """Upserts the latest tick per instrument. exchange_segment is normalised
    to "" (SQLite treats NULLs as distinct for UNIQUE, which would break the upsert)."""
    exchange_segment = exchange_segment or ""
    with _connection() as conn:
        conn.execute(
            """INSERT INTO market_data_state
                 (instrument_token, exchange_segment, last_traded_price, last_tick_at, trading_symbol, close_price, volume)
               VALUES (?, ?, ?, datetime('now'), ?, ?, ?)
               ON CONFLICT (instrument_token, exchange_segment)
               DO UPDATE SET last_traded_price = excluded.last_traded_price, last_tick_at = excluded.last_tick_at,
                             trading_symbol = COALESCE(excluded.trading_symbol, trading_symbol),
                             close_price = COALESCE(excluded.close_price, close_price),
                             volume = COALESCE(excluded.volume, volume)""",
            (instrument_token, exchange_segment, last_traded_price, trading_symbol, close_price, volume),
        )


def latest_market_ticks(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            "SELECT instrument_token, exchange_segment, last_traded_price, last_tick_at, trading_symbol, close_price, volume FROM market_data_state ORDER BY last_tick_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"instrument_token": r[0], "exchange_segment": r[1], "last_traded_price": r[2], "last_tick_at": r[3], "trading_symbol": r[4], "close_price": r[5], "volume": r[6]}
            for r in rows
        ]


def record_positions_snapshot(rows: list[dict]) -> None:
    """Replaces positions_snapshot with the latest broker fetch (one
    transaction). Row keys: trading_symbol, exchange_segment, product,
    instrument_token, buy_quantity, sell_quantity, quantity (NET),
    buy_amount, sell_amount, average_price, price_factor, lot_size, raw."""
    with _connection() as conn:
        conn.execute("DELETE FROM positions_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO positions_snapshot
                   (trading_symbol, exchange_segment, product, quantity, average_price, raw_payload,
                    instrument_token, buy_quantity, sell_quantity, buy_amount, sell_amount, price_factor, lot_size)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"), r.get("product"),
                    r.get("quantity"), r.get("average_price"), json.dumps(r.get("raw", r)),
                    r.get("instrument_token"), r.get("buy_quantity"), r.get("sell_quantity"),
                    r.get("buy_amount"), r.get("sell_amount"), r.get("price_factor"), r.get("lot_size"),
                ),
            )


def record_holdings_snapshot(rows: list[dict]) -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM holdings_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO holdings_snapshot
                   (trading_symbol, exchange_segment, quantity, average_price, raw_payload,
                    instrument_token, closing_price, market_value)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"), r.get("quantity"), r.get("average_price"),
                    json.dumps(r.get("raw", r)), r.get("instrument_token"), r.get("closing_price"), r.get("market_value"),
                ),
            )


def record_funds_snapshot(
    *, available_margin: float | None, used_margin: float | None, raw: dict,
    realized_mtom: float | None = None, unrealized_mtom: float | None = None,
) -> None:
    with _connection() as conn:
        conn.execute(
            """INSERT INTO funds_snapshot (available_margin, used_margin, raw_payload, realized_mtom, unrealized_mtom)
               VALUES (?, ?, ?, ?, ?)""",
            (available_margin, used_margin, json.dumps(raw), realized_mtom, unrealized_mtom),
        )


def latest_positions_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, product, quantity, average_price, raw_payload, snapshot_at, instrument_token, buy_quantity, sell_quantity, buy_amount, sell_amount, price_factor, lot_size FROM positions_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1], "product": r[2],
                "quantity": r[3], "average_price": r[4], "raw": json.loads(r[5]) if r[5] else None,
                "snapshot_at": r[6], "instrument_token": r[7], "buy_quantity": r[8], "sell_quantity": r[9],
                "buy_amount": r[10], "sell_amount": r[11], "price_factor": r[12], "lot_size": r[13],
            }
            for r in rows
        ]


def latest_holdings_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, quantity, average_price, raw_payload, snapshot_at, instrument_token, closing_price, market_value FROM holdings_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1],
                "quantity": r[2], "average_price": r[3], "raw": json.loads(r[4]) if r[4] else None,
                "snapshot_at": r[5], "instrument_token": r[6], "closing_price": r[7], "market_value": r[8],
            }
            for r in rows
        ]


def latest_funds_snapshot() -> dict | None:
    with _connection() as conn:
        row = conn.execute(
            "SELECT available_margin, used_margin, raw_payload, snapshot_at, realized_mtom, unrealized_mtom FROM funds_snapshot ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        return {
            "available_margin": row[0], "used_margin": row[1],
            "raw": json.loads(row[2]) if row[2] else None, "snapshot_at": row[3],
            "realized_mtom": row[4], "unrealized_mtom": row[5],
        }
