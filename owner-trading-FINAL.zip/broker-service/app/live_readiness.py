"""LIVE-readiness gates, evaluated from real runtime state -- never assumed.

Each gate is {id, ok, blocking, detail}. `ready` is True only when every
blocking gate passes. Arming LIVE (orders actually reach Kotak) additionally
requires `ready` AND an explicit owner action (risk_settings.live_trading_armed).
Gates that can only be established by a human (first tiny live order
observed, IP whitelist etc.) are listed in LIVE_READINESS.md, not faked here.
"""
from __future__ import annotations

import datetime as _dt
import json
import os

from . import db as _db
from . import sdk_conformance
from .broker_client import sdk_ready
from .config import config
from .state import BrokerState, current_state


def _gate(id_: str, ok: bool, detail: str, blocking: bool = True) -> dict:
    return {"id": id_, "ok": bool(ok), "blocking": blocking, "detail": detail}


def _age_seconds(ts: str | None) -> float | None:
    if not ts:
        return None
    try:
        return (_dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None) - _dt.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")).total_seconds()
    except ValueError:
        return None


def evaluate() -> dict:
    from .credential_manager import credential_manager
    from .websocket_manager import websocket_manager

    gates: list[dict] = []
    gates.append(_gate("trading_mode_live", config.trading_mode == "LIVE", f"TRADING_MODE={config.trading_mode}"))
    ok, why = sdk_ready()
    gates.append(_gate("sdk_installed_v3_0_7", ok, why or 'official SDK importable at required version'))
    conf = sdk_conformance.check_runtime() if ok else None
    gates.append(_gate("sdk_signatures_match", bool(conf and conf.ok), conf.summary() if conf else "SDK not importable"))
    vend = sdk_conformance.check_vendor_integrity()
    gates.append(_gate("vendored_sdk_unmodified", vend.ok, "; ".join(vend.errors) or f"{vend.checked} files match manifest",
                       blocking=False))
    gates.append(_gate("credentials_configured", credential_manager.has_base_credentials(), "Kotak credentials saved"))
    gates.append(_gate("broker_connected", current_state.state == BrokerState.CONNECTED, f"state={current_state.state.value}"))
    ws = websocket_manager.status()
    gates.append(_gate("order_feed_connected", ws["orderFeed"]["connected"], "order feed socket"))
    gates.append(_gate("market_feed_connected", ws["market"]["connected"], "SFeed socket"))
    gates.append(_gate("emergency_stop_clear", not _db.is_emergency_stop_active(), "emergency stop"))
    rs = _db.get_risk_settings()
    missing = [k for k in ("max_order_quantity", "max_order_value", "max_orders_per_day", "max_daily_loss") if not rs.get(k)]
    gates.append(_gate("risk_limits_configured", not missing, "unset: " + ", ".join(missing) if missing else "all core limits set"))
    unresolved = [o["internal_order_id"] for o in _db.list_unresolved_live_orders() if o["outcome_unknown"]]
    gates.append(_gate("no_unknown_outcome_orders", not unresolved, f"{len(unresolved)} order(s) with unknown outcome" if unresolved else "none"))
    funds = _db.latest_funds_snapshot()
    age = _age_seconds(funds["snapshot_at"]) if funds else None
    gates.append(_gate("recent_reconciliation", age is not None and age < 20 * 60,
                       "no snapshot yet" if age is None else f"last snapshot {int(age)}s ago"))
    tok = bool(os.environ.get("BROKER_SERVICE_TOKEN"))
    gates.append(_gate("internal_token_set", tok, "BROKER_SERVICE_TOKEN protects the broker-service API"))
    ready = all(g["ok"] for g in gates if g["blocking"])
    result = {"ready": ready, "armed": rs["live_trading_armed"], "gates": gates,
              "live_orders_can_be_sent": ready and rs["live_trading_armed"]}
    try:
        _db.record_live_readiness(ready, {"gates": gates})
    except Exception:  # noqa: BLE001
        pass
    return result
