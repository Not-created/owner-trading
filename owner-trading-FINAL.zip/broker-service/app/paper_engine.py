"""PAPER-mode simulator. Imports nothing from broker_client / sdk_adapter:
PAPER can never reach Kotak. It reads only the local market_data_state
(last ticks) and writes orders/trades rows with mode='PAPER'.

Fill rules (deliberately simple and stated, not "realistic"):
  * MKT / SL-M  -> fill fully at the last tick price if that tick is fresh
                   (<= MAX_TICK_AGE_SECONDS); otherwise stay PAPER_ACCEPTED.
  * L           -> marketable (BUY: ltp <= limit, SELL: ltp >= limit) fills at the
                   LIMIT price; otherwise rests.
  * SL          -> once triggered (BUY: ltp >= trigger, SELL: ltp <= trigger)
                   behaves as L.
No slippage, no partial fills, no fees are simulated.
"""
from __future__ import annotations

import uuid

from . import db as _db
from .market_prices import fresh_ltp


def _fill_price(o: dict, ltp: float) -> float | None:
    t, side = o["order_type"], o["transaction_type"]
    if t in ("MKT", "SL-M"):
        if t == "SL-M":
            trig = o["trigger_price"]
            if trig is None or (side == "B" and ltp < trig) or (side == "S" and ltp > trig):
                return None
        return ltp
    if t == "SL":
        trig = o["trigger_price"]
        if trig is None or (side == "B" and ltp < trig) or (side == "S" and ltp > trig):
            return None
    limit = o["price"]
    if limit is None:
        return None
    if (side == "B" and ltp <= limit) or (side == "S" and ltp >= limit):
        return float(limit)
    return None


def try_fill(internal_order_id: str) -> bool:
    """Attempt to fill one PAPER order. Returns True if it completed."""
    o = _db.get_order(internal_order_id)
    if not o or o["mode"] != "PAPER" or o["status"] in _db.TERMINAL_STATUSES:
        return False
    ltp = fresh_ltp(o.get("instrument_token"), o["trading_symbol"], o["exchange_segment"])
    if ltp is None:
        return False
    px = _fill_price(o, ltp)
    if px is None:
        return False
    _db.record_trade(
        broker_trade_id=f"PAPER-{uuid.uuid4().hex}", order_id=o["id"], broker_order_id=None,
        fill_quantity=o["quantity"], fill_price=px, fill_time=None, raw_payload={"simulated": True, "ltp": ltp},
        mode="PAPER", trading_symbol=o["trading_symbol"], exchange_segment=o["exchange_segment"],
        transaction_type=o["transaction_type"], product=o["product"], multiplier=1.0,
    )
    _db.apply_broker_order_state(
        internal_order_id=internal_order_id, status="COMPLETE", broker_status="paper complete",
        filled_quantity=o["quantity"], average_price=px,
    )
    return True


def match_open_orders() -> int:
    """Called periodically: fills resting PAPER orders whose condition is now met."""
    n = 0
    for o in _db.list_orders(limit=500, mode="PAPER", open_only=True):
        if try_fill(o["internal_order_id"]):
            n += 1
    return n
