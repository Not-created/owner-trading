"""Order placement / modification / cancellation.

PAPER: local only (paper_engine.py). Never imports or calls the broker.
LIVE : exclusively the official SDK via broker_client -> sdk_adapter, with
       exact, validated parameters. There is NO simulator on this path and NO
       caller-supplied `broker_params`.

LIVE safety properties (each has a test):
  * a durable local row + unique client_tag exist BEFORE the broker call;
  * the client_tag is sent as the SDK `tag` and comes back as GuiOrdId, so an
    order whose placement outcome is UNKNOWN (timeout) is recovered by
    reconciliation -- it is never blindly retried and never marked rejected;
  * risk limits fail CLOSED when they cannot be evaluated;
  * idempotency_key replays return the existing order, never a second one.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from decimal import Decimal

from . import db as _db
from . import paper_engine
from .market_prices import fresh_ltp
from . import sdk_adapter
from .broker_client import LiveTradingBlockedError, NotConfiguredError, assert_live_trading_allowed, broker_client
from .config import config
from .sdk_adapter import AUTH, OK, REJECTED, UNKNOWN, OrderRequest, OrderRequestError

logger = logging.getLogger("owner_trading.order_service")


class OrderValidationError(ValueError):
    """Malformed request -> HTTP 400."""


class RiskLimitExceededError(ValueError):
    """Well-formed but blocked by risk policy -> HTTP 400."""


def _write_audit(*, action: str, **details) -> None:
    try:
        _db.write_audit_log(actor="owner", action=action, details=details)
    except Exception as exc:  # noqa: BLE001 -- audit failure must not block the order flow
        logger.warning("Failed to write audit log for %s: %s", action, exc)


def new_client_tag() -> str:
    """Alphanumeric, 18 chars. Broker-side tag length/charset limits are NOT
    documented in the SDK; this is deliberately short and conservative.
    (Verify with a 1-lot order on first LIVE use -- see LIVE_READINESS.md.)"""
    return "OT" + uuid.uuid4().hex[:16].upper()


# ------------------------------------------------------------------ validation
def _num(payload: dict, key: str) -> float | None:
    v = payload.get(key)
    if v is None or v == "":
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise OrderValidationError(f"{key} must be a number.")
    if f < 0:
        raise OrderValidationError(f"{key} cannot be negative.")
    return f


def _validate(payload: dict) -> dict:
    try:
        quantity = int(payload.get("quantity"))
    except (TypeError, ValueError):
        raise OrderValidationError("quantity must be a positive integer.")
    order = {
        "trading_symbol": (payload.get("trading_symbol") or "").strip(),
        "exchange_segment": (payload.get("exchange_segment") or "").strip().lower(),
        "transaction_type": (payload.get("transaction_type") or "").strip().upper(),
        "order_type": (payload.get("order_type") or "").strip().upper(),
        "product": (payload.get("product") or "").strip().upper(),
        "validity": (payload.get("validity") or "DAY").strip().upper(),
        "quantity": quantity,
        "price": _num(payload, "price"),
        "trigger_price": _num(payload, "trigger_price"),
        "instrument_token": (str(payload["instrument_token"]).strip() if payload.get("instrument_token") not in (None, "") else None),
    }
    if order["order_type"] in ("MKT", "SL-M"):
        order["price"] = None if not order["price"] else order["price"]
    try:
        _to_request(order).validate()      # the SDK's own validation rules, applied to BOTH modes
    except OrderRequestError as exc:
        raise OrderValidationError(str(exc))
    return order


def _to_request(order: dict, tag: str | None = None) -> OrderRequest:
    return OrderRequest(
        exchange_segment=order["exchange_segment"], trading_symbol=order["trading_symbol"],
        transaction_type=order["transaction_type"], order_type=order["order_type"], product=order["product"],
        quantity=order["quantity"], validity=order["validity"], price=order["price"],
        trigger_price=order["trigger_price"], tag=tag,
    )


# ------------------------------------------------------------------ risk
def _reference_price(order: dict) -> float | None:
    if order.get("price"):
        return float(order["price"])
    if order.get("trigger_price"):
        return float(order["trigger_price"])
    px = fresh_ltp(order.get("instrument_token"), order["trading_symbol"], order["exchange_segment"])
    return px


def _daily_pnl_total() -> float | None:
    """LIVE: realised+unrealised from the latest funds snapshot (broker-reported)."""
    f = _db.latest_funds_snapshot()
    if not f or f.get("realized_mtom") is None or f.get("unrealized_mtom") is None:
        return None
    return float(f["realized_mtom"]) + float(f["unrealized_mtom"])


def _check_risk_limits(order: dict, mode: str) -> None:
    rs = _db.get_risk_settings()
    max_qty = min([v for v in (config.max_order_quantity or None, rs["max_order_quantity"]) if v] or [0]) or None
    max_orders = min([v for v in (config.max_orders_per_day or None, rs["max_orders_per_day"]) if v] or [0]) or None
    if max_qty and order["quantity"] > max_qty:
        raise RiskLimitExceededError(f"Order quantity {order['quantity']} exceeds the maximum order quantity ({max_qty}).")
    if max_orders:
        placed = _db.count_orders_today(mode=mode)
        if placed >= max_orders:
            raise RiskLimitExceededError(f"Daily order limit reached ({placed}/{max_orders}).")
    ref = _reference_price(order)
    if rs["max_order_value"]:
        if ref is None:
            raise RiskLimitExceededError("max_order_value is set but the order value cannot be determined (no price / fresh tick) -- blocked.")
        if ref * order["quantity"] > rs["max_order_value"]:
            raise RiskLimitExceededError(f"Order value {ref * order['quantity']:.2f} exceeds max_order_value ({rs['max_order_value']}).")
    if mode != "LIVE":
        return
    if rs["max_daily_loss"]:
        total = _daily_pnl_total()
        if total is None:
            raise RiskLimitExceededError("max_daily_loss is set but P&L is unknown (no funds snapshot) -- blocked.")
        if total <= -abs(rs["max_daily_loss"]):
            raise RiskLimitExceededError(f"Daily loss limit reached (P&L {total:.2f}).")
    if rs["max_open_positions"]:
        open_syms = {(p["exchange_segment"], p["trading_symbol"]) for p in _db.latest_positions_snapshot() if p.get("quantity")}
        if (order["exchange_segment"], order["trading_symbol"]) not in open_syms and len(open_syms) >= rs["max_open_positions"]:
            raise RiskLimitExceededError(f"Open position limit reached ({len(open_syms)}/{rs['max_open_positions']}).")
    if order["transaction_type"] == "B" and ref is not None:
        funds = _db.latest_funds_snapshot()
        if funds and funds.get("available_margin") is not None and ref * order["quantity"] > funds["available_margin"] \
                and order["product"] == "CNC":
            raise RiskLimitExceededError(
                f"Order value {ref * order['quantity']:.2f} exceeds available funds {funds['available_margin']:.2f} "
                f"(snapshot {funds.get('snapshot_at', '?')}). Margin for MIS/NRML is not pre-estimated here.")


# ------------------------------------------------------------------ helpers
async def _in_executor(fn):
    return await asyncio.get_running_loop().run_in_executor(None, fn)


def _schedule_reconcile() -> None:
    try:
        from . import reconciliation
        asyncio.get_running_loop().create_task(reconciliation.run_full_reconciliation())
    except Exception:  # noqa: BLE001
        pass


def _finish(internal_order_id: str, outcome, action: str) -> dict:
    """Map a state-changing broker Outcome onto local state (place/modify/cancel)."""
    if outcome.kind == OK:
        return {"ok": True}
    if outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, outcome_unknown=True,
                         status_reason=f"{action}: outcome unknown ({outcome.message[:150]}); reconciling with broker.")
        _write_audit(action=f"order.{action}_unknown", internal_order_id=internal_order_id, reason=outcome.message)
        _schedule_reconcile()
        return {"ok": False, "unknown": True}
    return {"ok": False, "unknown": False}


# ------------------------------------------------------------------ place
async def place_order(payload: dict) -> dict:
    key = payload.get("idempotency_key")
    if key:
        key = str(key).strip()[:200]
        existing = _db.get_order(key)
        if existing is not None:
            logger.info("place_order idempotent replay for %s.", key)
            return existing
    order = _validate(payload)
    mode = config.trading_mode
    try:
        _check_risk_limits(order, mode)
    except RiskLimitExceededError as exc:
        _write_audit(action="order.risk_blocked", mode=mode, order=order, reason=str(exc))
        raise OrderValidationError(str(exc))

    internal_order_id = key or str(uuid.uuid4())
    tag = new_client_tag()
    _db.create_order(
        internal_order_id=internal_order_id, mode=mode,
        status="SUBMITTING" if mode == "LIVE" else "PAPER_ACCEPTED", client_tag=tag, **order,
    )
    _write_audit(action="order.create", internal_order_id=internal_order_id, mode=mode, order=order, client_tag=tag)

    if mode != "LIVE":
        paper_engine.try_fill(internal_order_id)
        return _db.get_order(internal_order_id)

    def reject(reason: str, action: str = "order.rejected") -> dict:
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason[:300])
        _write_audit(action=action, internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    try:
        req = _to_request(order, tag=tag)
        outcome = await _in_executor(lambda: broker_client.place_order(req))
    except (LiveTradingBlockedError, NotConfiguredError) as exc:
        return reject(str(exc), "order.blocked")
    except OrderRequestError as exc:
        return reject(str(exc))
    except Exception as exc:  # noqa: BLE001 -- unexpected failure AFTER we may have sent: never assume rejection
        logger.exception("place_order raised unexpectedly")
        outcome = sdk_adapter.Outcome(UNKNOWN, message=f"{type(exc).__name__}", code="INTERNAL")

    if outcome.kind == OK:
        _db.update_order(internal_order_id=internal_order_id, status="SUBMITTED", broker_order_id=outcome.order_id)
        _db.record_order_event(event_source="place_order_response", broker_event_id=outcome.order_id,
                               raw_payload=outcome.raw if isinstance(outcome.raw, dict) else {"raw": str(outcome.raw)},
                               order_id=_db.get_order(internal_order_id)["id"], broker_order_id=outcome.order_id)
        _write_audit(action="order.submitted", internal_order_id=internal_order_id, mode=mode, broker_order_id=outcome.order_id)
    elif outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, status="PENDING_RECONCILE")
        _finish(internal_order_id, outcome, "place")
    else:  # REJECTED or AUTH: nothing was accepted by the broker
        return reject(outcome.message or "Rejected by broker.")
    return _db.get_order(internal_order_id)


# ------------------------------------------------------------------ modify
async def modify_order(internal_order_id: str, payload: dict) -> dict:
    o = _db.get_order(internal_order_id)
    if o is None:
        raise OrderValidationError("Unknown order.")
    if o["status"] in _db.TERMINAL_STATUSES:
        raise OrderValidationError(f"Order is {o['status']} and cannot be modified.")
    new_qty = int(payload["quantity"]) if payload.get("quantity") not in (None, "") else o["quantity"]
    price = _num(payload, "price") if "price" in payload else o["price"]
    trigger = _num(payload, "trigger_price") if "trigger_price" in payload else o["trigger_price"]
    order_type = (payload.get("order_type") or o["order_type"]).upper()
    validity = (payload.get("validity") or o["validity"]).upper()

    if o["mode"] == "PAPER":
        if o["status"] != "PAPER_ACCEPTED":
            raise OrderValidationError("Only resting PAPER orders can be modified.")
        _db.update_order_fields(internal_order_id=internal_order_id, quantity=new_qty, price=price, trigger_price=trigger)
        _write_audit(action="order.modify", internal_order_id=internal_order_id, mode="PAPER")
        paper_engine.try_fill(internal_order_id)
        return _db.get_order(internal_order_id)

    if config.trading_mode != "LIVE":
        raise OrderValidationError("This deployment is not in LIVE mode.")
    if not o["broker_order_id"]:
        raise OrderValidationError("Order has no broker order id yet (placement not confirmed); reconcile first.")
    if o["filled_quantity"] and new_qty != o["quantity"]:
        # Kotak's modify-quantity semantics for partially filled orders are not documented in the SDK.
        raise OrderValidationError("Quantity of a partially filled order cannot be changed here; cancel the remainder instead.")
    try:
        outcome = await _in_executor(lambda: broker_client.modify_order(
            order_id=o["broker_order_id"], order_type=order_type, quantity=new_qty, validity=validity,
            price=price, trigger_price=trigger))
    except (LiveTradingBlockedError, NotConfiguredError, OrderRequestError) as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        outcome = sdk_adapter.Outcome(UNKNOWN, message=type(exc).__name__)
    if outcome.kind == OK:
        # The broker may return a NEW order number for the modified order.
        _db.update_order(internal_order_id=internal_order_id, status="MODIFY_REQUESTED", broker_order_id=outcome.order_id)
        _db.update_order_fields(internal_order_id=internal_order_id, quantity=new_qty, price=price, trigger_price=trigger)
        _write_audit(action="order.modify", internal_order_id=internal_order_id, broker_order_id=outcome.order_id)
        _schedule_reconcile()
    elif outcome.kind == UNKNOWN:
        _finish(internal_order_id, outcome, "modify")
    else:
        _write_audit(action="order.modify_rejected", internal_order_id=internal_order_id, reason=outcome.message)
        raise OrderValidationError(outcome.message or "Modify rejected by broker.")
    return _db.get_order(internal_order_id)


# ------------------------------------------------------------------ cancel
async def cancel_order(internal_order_id: str) -> dict:
    o = _db.get_order(internal_order_id)
    if o is None:
        raise OrderValidationError("Unknown order.")
    if o["status"] in _db.TERMINAL_STATUSES:
        raise OrderValidationError(f"Order is already {o['status']}.")
    if o["mode"] == "PAPER":
        _db.update_order(internal_order_id=internal_order_id, status="CANCELLED", status_reason="Cancelled (PAPER).")
        _write_audit(action="order.cancel", internal_order_id=internal_order_id, mode="PAPER")
        return _db.get_order(internal_order_id)
    if config.trading_mode != "LIVE":
        raise OrderValidationError("This deployment is not in LIVE mode.")
    if not o["broker_order_id"]:
        raise OrderValidationError("Order has no broker order id yet (placement not confirmed); reconcile first.")
    try:
        outcome = await _in_executor(lambda: broker_client.cancel_order(order_id=o["broker_order_id"]))
    except (LiveTradingBlockedError, NotConfiguredError, OrderRequestError) as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        outcome = sdk_adapter.Outcome(UNKNOWN, message=type(exc).__name__)
    if outcome.kind == OK:
        _db.update_order(internal_order_id=internal_order_id, status="CANCEL_REQUESTED")
        _write_audit(action="order.cancel", internal_order_id=internal_order_id, broker_order_id=o["broker_order_id"])
        _schedule_reconcile()
    elif outcome.kind == UNKNOWN:
        _finish(internal_order_id, outcome, "cancel")
    else:
        _write_audit(action="order.cancel_rejected", internal_order_id=internal_order_id, reason=outcome.message)
        raise OrderValidationError(outcome.message or "Cancel rejected by broker.")
    return _db.get_order(internal_order_id)
