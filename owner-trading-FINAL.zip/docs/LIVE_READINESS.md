# LIVE-readiness audit

Status legend — **VERIFIED**: exercised by a test that was actually run (how is stated). **UNVERIFIED**: not run anywhere yet;
requires the real environment. Nothing here is marked verified on the strength of reading code.

## Verified (test suites: broker-service 225 tests via `unittest`; backend `node:test` 23 pass)
| Area | Evidence |
|---|---|
| Vendored SDK is the official 3.0.7, unmodified | 47 package files hash-identical to the uploaded ZIP; `check_vendor_integrity` + tamper tests |
| Every SDK call the adapter makes matches the official signature | `ast` check of `neo_api.py` (20 methods); mutation tests prove drift is detected; test doubles reject any kwarg not in the real signature |
| Order parameters (`exchange_segment`, `product`, `order_type`, `transaction_type`, `validity`, string prices/quantities, `tag`) | adapter tests against the SDK's own enums/validation rules |
| Response handling (`Error`, `error`, `Error Message`, `stCode`/`errMsg`, 403, transport errors) | classification tests; **timeouts → UNKNOWN, never "rejected", never retried** |
| Unknown-outcome recovery by client tag (`GuiOrdId`) | order-service + reconciliation tests |
| Order lifecycle: partial fills, out-of-order/duplicate events, terminal-state protection, cancel-after-partial | DB + `order_sync` tests |
| Reconciliation (orders, fills, positions, holdings, funds); failed section keeps prior snapshot; session loss aborts pass | reconciliation tests |
| P&L (realised + unrealised = SDK-documented formula; never fabricates an LTP) | `test_pnl.py` |
| Risk limits fail closed; daily-loss, order-value, quantity, per-day, open positions, CNC funds | order-service tests |
| PAPER never reaches Kotak; LIVE never simulates | runtime tests + static import-isolation tests |
| LIVE gates: mode, emergency stop, connected, **explicit arming**, internal token | order-service, server, readiness tests |
| WebSocket supervision on the SDK's async clients (reconnect/backoff/resubscribe, reconcile after order-feed reconnect, session probe) | `test_websocket_manager.py` with fake feeds |
| Frontend ↔ Express ↔ broker-service ↔ SDK contract (routes, field names, enums, states) | static contract tests |
| Session cookie policy (auto/true/false) and startup validation | 15 `node:test` cases |
| `deploy.sh` login/session verification logic (passes correct behaviour; fails on Secure-over-HTTP, missing cookie, no HttpOnly, session surviving logout, wrong password) | 11 tests against a mock auth server |
| nginx templates: no forced redirect, headers forwarded in every location, no HSTS, HTTPS block optional | static tests |
| Migrations apply cleanly and idempotently; LIVE starts disarmed | `node:test` |
| Frontend syntax + import resolution (32 files) | TypeScript parser + resolver (**not** a Vite build) |
| Expiries/option chain/historical data/margin/scrip-master/whatsmyip: exact SDK kwargs, validation, response classification | adapter unit tests against the vendored signatures |
| Same five capabilities wired UI → Express → broker-service → SDK (route names, methods, 409-when-disconnected) | server route tests + static contract tests |

## UNVERIFIED — must be checked in the real environment
1. **Real Kotak login** (`totp_login` → `totp_validate` → `limits`) with your credentials/TOTP secret.
2. **Expiries/option chain/historical data/scrip master/whatsmyip against real Kotak data.** Response shapes (option chain's `common_data`/`call`/`put`/`fut`, historical candle row order, scrip master's `filesPaths`) are taken from the SDK docs, not exercised against a live account.
3. **Margin estimate accuracy.** `margin_required()` is called with real order parameters but its returned figure is never cross-checked against Kotak's own margin calculator.
4. **A real order.** Tag length/charset limits are undocumented in the SDK (we send 18 alphanumerics); modify semantics (does the broker return a *new* `nOrdNo`? quantity meaning after a partial fill) and the exact `ordSt` strings for partial fills are inferred from SDK docs/models. Do the first LIVE order as 1 share, limit far from market, then cancel; check the Orders page shows it.
5. **Real feeds**: SFeed/order-feed message shapes and SDK reconnect behaviour against Kotak's servers.
6. **Session expiry**: the invalid-session text/status markers and TTL (`session.py` assumes 8 h) are heuristics; `403`/`Invalid session` responses are the authoritative trigger.
7. **F&O P&L**: units-vs-lots convention is an assumption (documented in `pnl.py`); confirm on one real F&O position.
8. Pre-trade margin is shown as an *estimate* on the Orders page (via `margin_required()`) but is **not** enforced as a risk gate (only CNC-vs-funds is checked locally).
9. **Express behaviour end to end**: `backend/test/session-e2e.test.js` runs the real app but was **skipped in the build environment** (no npm packages, no network). It runs in `deploy.sh` (`npm test`) on the server.
10. **Frontend production build** (`vite build`), **nginx -t**, **systemd units**, **certbot/HTTPS**: not executable in the build environment. `deploy.sh` performs them and fails loudly.
11. Installing the real SDK with its dependencies (`pandas<3`, `httpx[http2]`, `pydantic`, `websockets` …): done by `deploy.sh`; the post-install runtime signature check and test-suite run there.
12. Kotak-side: static-IP whitelisting / API entitlement for your account (check with the Settings page's "Check Kotak-visible IP" once connected).

## Known limitations (by design, not blockers)
* Session store is in-memory: sessions end when Express restarts. Broker-service TOTP session must be reconnected after a restart.
* An order stuck in `PENDING_RECONCILE` (timeout, never found at the broker) is flagged, blocks LIVE readiness, and needs the owner to check Kotak manually; it is never auto-failed or auto-resent.
* PAPER fills are simple (full fill at last tick / limit price; no slippage, fees or partials).

## Go-live checklist
`deploy.sh` (PAPER) → Settings: credentials, Test, Connect → verify funds/positions/holdings/orders load →
Market Data: subscribe one instrument and see ticks → `set-mode.sh LIVE` → Risk: set all four core limits → all readiness
checks green → Arm → 1-share limit order far from market → cancel → observe status in Orders → only then normal use.
