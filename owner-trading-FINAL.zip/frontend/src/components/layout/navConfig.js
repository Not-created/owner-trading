// Single source of truth for the dashboard's navigation structure, shared
// by the Sidebar (renders the links) and App.jsx (registers the routes).
// Adding a new section later means adding one entry here.
export const NAV_SECTIONS = [
  { key: "dashboard", label: "Dashboard", path: "/dashboard", icon: "grid" },
  { key: "orders", label: "Orders", path: "/dashboard/orders", icon: "file-text" },
  { key: "positions", label: "Positions", path: "/dashboard/positions", icon: "layers" },
  { key: "holdings", label: "Holdings", path: "/dashboard/holdings", icon: "briefcase" },
  { key: "history", label: "History", path: "/dashboard/history", icon: "clock" },
  { key: "reports", label: "Reports", path: "/dashboard/reports", icon: "file" },
  { key: "market-data", label: "Market Data", path: "/dashboard/market-data", icon: "globe" },
  { key: "funds", label: "Funds", path: "/dashboard/funds", icon: "dollar-sign" },
  { key: "risk", label: "Risk", path: "/dashboard/risk", icon: "alert-triangle" },
  { key: "logs", label: "Logs", path: "/dashboard/logs", icon: "list" },
  { key: "settings", label: "Settings", path: "/dashboard/settings", icon: "settings" },
  { key: "help", label: "Help", path: "/dashboard/help", icon: "help-circle" },
];
