import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import MetricCard from "../components/common/MetricCard";
import usePolling from "../hooks/usePolling";
import { fmt } from "../lib/format";

// A report is only what the system can actually compute: fills and P&L. No invented analytics.
export default function Reports() {
  const trades = usePolling(() => api.getTrades(), 0);
  const pnl = usePolling(() => api.getPnl(), 0);
  const rows = (trades.body && trades.body.trades) || [];
  const bySymbol = {};
  for (const t of rows) {
    const k = `${t.mode}|${t.trading_symbol}`;
    const r = (bySymbol[k] ||= { mode: t.mode, symbol: t.trading_symbol, buyQty: 0, sellQty: 0, buyValue: 0, sellValue: 0 });
    const v = t.fill_quantity * t.fill_price;
    if (t.transaction_type === "B") { r.buyQty += t.fill_quantity; r.buyValue += v; } else { r.sellQty += t.fill_quantity; r.sellValue += v; }
  }
  const summary = Object.values(bySymbol);
  function downloadCsv() {
    const head = "mode,symbol,buy_qty,sell_qty,buy_value,sell_value\n";
    const body = summary.map((r) => [r.mode, r.symbol, r.buyQty, r.sellQty, r.buyValue.toFixed(2), r.sellValue.toFixed(2)].join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([head + body], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url; a.download = "trade-summary.csv"; a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Reports</h2>
        <p className="page__subtitle">Fill summary per symbol and current P&amp;L, computed from recorded fills.</p>
      </div>
      {pnl.body && (
        <div className="metrics-grid">
          <MetricCard label="LIVE total P&L" icon="activity" value={fmt(pnl.body.live.total)} />
          <MetricCard label="PAPER total P&L" icon="activity" value={fmt(pnl.body.paper.total)} />
        </div>
      )}
      <div className="card">
        <div className="card__head">
          <h3 className="card__title">Fills by symbol</h3>
          <button type="button" onClick={downloadCsv} disabled={summary.length === 0}>Download CSV</button>
        </div>
        {trades.loading && <EmptyState title="Loading…" />}
        {!trades.loading && summary.length === 0 && <EmptyState title="No fills to report" icon="file" />}
        {summary.length > 0 && (
          <table className="data-table">
            <thead><tr><th>Mode</th><th>Symbol</th><th>Bought</th><th>Sold</th><th>Buy value</th><th>Sell value</th></tr></thead>
            <tbody>
              {summary.map((r) => (
                <tr key={r.mode + r.symbol}><td>{r.mode}</td><td>{r.symbol}</td><td>{r.buyQty}</td><td>{r.sellQty}</td><td>{fmt(r.buyValue)}</td><td>{fmt(r.sellValue)}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
