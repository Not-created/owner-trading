export default function Help() {
  const p = { style: { color: "#9caebf", fontSize: "0.88rem", lineHeight: 1.7, margin: "0 0 0.6rem" } };
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Help</h2>
        <p className="page__subtitle">How Owner Trading behaves, in plain terms.</p>
      </div>
      <div className="card">
        <h3 className="card__title">PAPER vs LIVE</h3>
        <p {...p}>PAPER orders are simulated on this server and never reach Kotak. LIVE orders are sent to your real Kotak Neo account through the official SDK. The deployment mode is fixed by the server configuration and shown on every page.</p>
        <p {...p}>LIVE additionally requires: a connected broker session, every check on the Risk page passing, and you explicitly arming LIVE trading. The emergency stop blocks all LIVE orders immediately.</p>
      </div>
      <div className="card">
        <h3 className="card__title">Orders that show “unconfirmed”</h3>
        <p {...p}>If the broker does not answer an order request in time, the outcome is unknown. The order is marked unconfirmed and is never resent automatically; it is matched against Kotak's order book using its tag. Check the status before placing anything similar.</p>
      </div>
      <div className="card">
        <h3 className="card__title">Sessions</h3>
        <p {...p}>Kotak sessions expire. When that happens the broker state changes to SESSION_EXPIRED and LIVE orders are blocked until you reconnect from Settings.</p>
      </div>
    </div>
  );
}
