import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import MetricCard from "../components/common/MetricCard";
import usePolling from "../hooks/usePolling";
import { fmt, pnlClass } from "../lib/format";

export default function Positions() {
  const { loading, error, body } = usePolling(() => api.getPnl(), 5000);
  const live = body && body.live;
  const paper = body && body.paper;

  const table = (title, ledger) => (
    <div className="card">
      <div className="card__head"><h3 className="card__title">{title}</h3></div>
      {ledger.positions.length === 0 ? (
        <EmptyState title="No positions" icon="layers" />
      ) : (
        <div className="table-scroll">
          <table className="data-table">
            <thead><tr><th>Symbol</th><th>Exchange</th><th>Product</th><th>Net qty</th><th>LTP</th><th>Realised</th><th>Unrealised</th><th>Total</th></tr></thead>
            <tbody>
              {ledger.positions.map((p, i) => (
                <tr key={i}>
                  <td>{p.trading_symbol}</td><td>{p.exchange_segment}</td><td>{p.product}</td><td>{p.net_quantity}</td>
                  <td>{p.ltp == null ? "no price" : fmt(p.ltp)}</td>
                  <td className={pnlClass(p.realized)}>{fmt(p.realized)}</td>
                  <td className={pnlClass(p.unrealized)}>{fmt(p.unrealized)}</td>
                  <td className={pnlClass(p.total)}>{fmt(p.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {!ledger.complete && <p className="form-hint">Some open positions have no live price (subscribe them on Market Data); totals exclude their unrealised P&L.</p>}
    </div>
  );

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Positions &amp; P&amp;L</h2>
        <p className="page__subtitle">LIVE comes from Kotak positions() with live SFeed prices; PAPER is built from simulated fills. The two ledgers are never mixed.</p>
      </div>
      {loading && <div className="card"><EmptyState title="Loading…" /></div>}
      {!loading && error && <div className="card"><EmptyState title="P&L unavailable" hint={error} icon="layers" /></div>}
      {live && (
        <>
          <div className="metrics-grid">
            <MetricCard label="LIVE realised" icon="activity" value={fmt(live.realized)} />
            <MetricCard label="LIVE unrealised" icon="activity" value={live.complete ? fmt(live.unrealized) : `${fmt(live.unrealized)}*`} />
            <MetricCard label="Broker-reported MTM (realised / unrealised)" icon="dollar-sign"
                        value={live.broker_reported && live.broker_reported.realized_mtom != null ? `${fmt(live.broker_reported.realized_mtom)} / ${fmt(live.broker_reported.unrealized_mtom)}` : undefined} />
          </div>
          {table("LIVE positions", live)}
        </>
      )}
      {paper && (
        <>
          <div className="metrics-grid">
            <MetricCard label="PAPER realised" icon="activity" value={fmt(paper.realized)} />
            <MetricCard label="PAPER unrealised" icon="activity" value={fmt(paper.unrealized)} />
          </div>
          {table("PAPER positions", paper)}
        </>
      )}
    </div>
  );
}
