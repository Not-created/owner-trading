import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api } from "../api/client";

const AuthContext = createContext(null);

/**
 * Owns the single piece of truth for "is this browser currently
 * authenticated". On mount it asks the backend (GET /api/auth/session,
 * which reads the httpOnly session cookie) rather than trusting anything
 * stored client-side -- there is no password or token kept in
 * localStorage/sessionStorage at any point.
 */
export function AuthProvider({ children }) {
  const [authenticated, setAuthenticated] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);

  const refreshSession = useCallback(async () => {
    const { ok, body } = await api.getSession();
    setAuthenticated(!!(ok && body && body.authenticated));
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      await refreshSession();
      if (!cancelled) setCheckingSession(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [refreshSession]);

  const login = useCallback(async (password) => {
    const { ok, status, body } = await api.login(password);
    if (ok) {
      setAuthenticated(true);
      return { success: true };
    }
    const message =
      status === 429
        ? "Too many attempts. Please wait and try again."
        : (body && body.error) || "Incorrect password.";
    return { success: false, message };
  }, []);

  const logout = useCallback(async () => {
    await api.logout();
    setAuthenticated(false);
  }, []);

  return (
    <AuthContext.Provider value={{ authenticated, checkingSession, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
