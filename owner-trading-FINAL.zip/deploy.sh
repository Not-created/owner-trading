#!/usr/bin/env bash
# Owner Trading -- one-command deployment (Ubuntu VPS, run as root for systemd/nginx/HTTPS).
#
#   sudo ./deploy.sh                                   # PAPER mode, local only
#   sudo DOMAIN=trade.example.com CERTBOT_EMAIL=you@example.com ./deploy.sh   # + nginx + Let's Encrypt HTTPS
#
# What it guarantees before it reports success:
#   * the vendored official Kotak Neo SDK (v3.0.7) is byte-identical to its manifest,
#   * it installs, imports, is exactly 3.0.7, and every method signature the adapter uses matches,
#   * migrations applied, frontend built, both services healthy, internal token enforced.
# It never touches Kotak credentials and never enables LIVE (use deployment/set-mode.sh).
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
BROKER_DIR="$ROOT_DIR/broker-service"
DEPLOYMENT_DIR="$ROOT_DIR/deployment"
ENV_FILE="$BACKEND_DIR/.env"
PASSWORD_HASH_FILE="$BACKEND_DIR/src/data/secure/password.hash.json"
DB_PATH="$BACKEND_DIR/data/owner-trading.db"
BROKER_ENV_SYSTEM_PATH="/etc/owner-trading/broker.env"
PORT="${PORT:-4000}"
BROKER_PORT="${BROKER_SERVICE_PORT:-8800}"
DOMAIN="${DOMAIN:-}"
CERTBOT_EMAIL="${CERTBOT_EMAIL:-}"
REQUIRED_SDK_VERSION="3.0.7"
IS_ROOT=""; [ "$(id -u)" -eq 0 ] && IS_ROOT=1

info()  { printf '\n\033[1;36m==>\033[0m %s\n' "$1"; }
ok()    { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
warn()  { printf '  \033[1;33m! %s\033[0m\n' "$1"; }
fail()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

set_kv() { # file key value  (idempotent .env editing)
  if grep -q "^$2=" "$1" 2>/dev/null; then sed -i "s#^$2=.*#$2=$3#" "$1"; else echo "$2=$3" >> "$1"; fi
}
get_kv() { grep -E "^$2=" "$1" 2>/dev/null | tail -n1 | cut -d= -f2- || true; }

echo "=============================================="
echo "   OWNER TRADING -- Deployment"
echo "=============================================="

# ------------------------------------------------------------------ environment
info "Checking environment"
[ -f /etc/os-release ] && grep -qi ubuntu /etc/os-release && ok "Ubuntu: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')" \
  || warn "Not Ubuntu -- this script is written for Ubuntu production hosts."
command -v node >/dev/null 2>&1 || fail "Node.js 22.5+ is required."
NODE_BIN="$(command -v node)"
ok "Node.js $(node --version) ($NODE_BIN)"
command -v npm >/dev/null 2>&1 || fail "npm is required."
node -e "require('node:sqlite')" >/dev/null 2>&1 || fail "node:sqlite unavailable: Node 22.5+ is required (found $(node --version))."
ok "node:sqlite available"
if [ -n "$IS_ROOT" ]; then
  case "$NODE_BIN" in /home/*|/root/*) fail "Node at $NODE_BIN is inside a home directory, which the hardened systemd unit cannot read. Install system-wide Node 22 (NodeSource) and re-run.";; esac
fi

PYTHON_BIN=""
for c in python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1; then
    v="$("$c" -c 'import sys; print(sys.version_info[0]*100+sys.version_info[1])')"
    if [ "$v" -ge 310 ]; then PYTHON_BIN="$c"; break; fi
  fi
done
[ -n "$PYTHON_BIN" ] || fail "Python >= 3.10 is required (sudo apt install python3.12 python3.12-venv)."
ok "Python: $("$PYTHON_BIN" --version) ($PYTHON_BIN)"

info "OS packages"
if command -v apt-get >/dev/null 2>&1 && [ -n "$IS_ROOT" ]; then
  PKGS="${PYTHON_BIN}-venv build-essential curl nginx"
  [ -n "$DOMAIN" ] && PKGS="$PKGS certbot"
  DEBIAN_FRONTEND=noninteractive apt-get update -y -qq || warn "apt-get update failed; continuing."
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq $PKGS >/dev/null 2>&1 && ok "Installed/verified: $PKGS" \
    || warn "Could not install some OS packages ($PKGS); ensure they exist."
else
  warn "Not root or no apt-get -- skipping OS package installation."
fi

# ------------------------------------------------------------------ vendored SDK checks (stdlib only, before any install)
info "Vendored official Kotak Neo SDK ${REQUIRED_SDK_VERSION}: integrity and signature check"
PRE="$(cd "$BROKER_DIR" && "$PYTHON_BIN" - <<'PY' 2>&1
import sys
from app import sdk_conformance as c
vi = c.check_vendor_integrity()
st = c.check_static()
print(f"vendor files verified: {vi.checked}; adapter signatures checked: {st.checked}")
errs = vi.errors + st.errors
for e in errs: print("ERROR:", e)
sys.exit(1 if errs else 0)
PY
)" && ok "$PRE" || fail "Vendored SDK check failed:
$PRE
The files under broker-service/vendor/kotakneoapi must be exactly the official 3.0.7 source."

# ------------------------------------------------------------------ venv + pip
info "Python virtual environment"
if [ -x "$BROKER_DIR/venv/bin/python" ] && "$BROKER_DIR/venv/bin/python" -c 'import sys' >/dev/null 2>&1; then
  ok "broker-service/venv is usable"
else
  [ -d "$BROKER_DIR/venv" ] && { warn "venv is broken -- recreating."; rm -rf "$BROKER_DIR/venv"; }
  "$PYTHON_BIN" -m venv "$BROKER_DIR/venv" || fail "Could not create venv (install ${PYTHON_BIN}-venv)."
  ok "Created broker-service/venv"
fi
VENV_PY="$BROKER_DIR/venv/bin/python"; VENV_PIP="$BROKER_DIR/venv/bin/pip"

info "Network access to PyPI (needed for the SDK's own dependencies: httpx, pydantic, websockets, ...)"
if command -v curl >/dev/null 2>&1 && ! curl -fsS --max-time 10 -o /dev/null "https://pypi.org/simple/"; then
  fail "Cannot reach https://pypi.org (DNS/egress/proxy). Fix network access (export HTTPS_PROXY if needed) and re-run."
fi
ok "PyPI reachable"

info "Removing conflicting or outdated Kotak SDK installs"
for legacy in neo-api-client kotak-neo-api; do
  if "$VENV_PIP" show "$legacy" >/dev/null 2>&1; then "$VENV_PIP" uninstall -y "$legacy" --quiet && warn "removed legacy package $legacy"; fi
done
CUR="$("$VENV_PIP" show kotakneoapi 2>/dev/null | awk -F': ' '/^Version:/ {print $2}')"
if [ -n "$CUR" ] && [ "$CUR" != "$REQUIRED_SDK_VERSION" ]; then
  "$VENV_PIP" uninstall -y kotakneoapi --quiet && warn "removed kotakneoapi $CUR (need $REQUIRED_SDK_VERSION)"
fi
ok "SDK install state clean"

info "Installing the vendored SDK and broker-service dependencies"
"$VENV_PIP" install --upgrade pip --quiet || warn "pip self-upgrade failed; continuing."
PIP_LOG="$(mktemp)"; PIP_OK=""
for attempt in 1 2 3; do
  if (cd "$BROKER_DIR" && "$VENV_PIP" install -r requirements.txt) > "$PIP_LOG" 2>&1; then PIP_OK=1; break; fi
  [ "$attempt" -lt 3 ] && { warn "pip attempt $attempt/3 failed; retrying in $((attempt*3))s"; sleep $((attempt*3)); }
done
if [ -z "$PIP_OK" ]; then tail -n 25 "$PIP_LOG" | sed 's/^/  /'; fail "pip install failed (output above). Deployment cannot continue without the SDK."; fi
rm -f "$PIP_LOG"; ok "pip install succeeded"

info "Verifying the INSTALLED SDK"
INSTALLED="$("$VENV_PIP" show kotakneoapi 2>/dev/null | awk -F': ' '/^Version:/ {print $2}')"
[ "$INSTALLED" = "$REQUIRED_SDK_VERSION" ] || fail "Installed kotakneoapi is '${INSTALLED:-none}', expected $REQUIRED_SDK_VERSION."
ok "kotakneoapi $INSTALLED"
IMPORT_OUT="$(cd "$BROKER_DIR" && "$VENV_PY" -c 'import neo_api_client; from neo_api_client import NeoAPI; print(neo_api_client.__version__)' 2>&1)" \
  || fail "SDK import failed: $IMPORT_OUT"
[ "$IMPORT_OUT" = "$REQUIRED_SDK_VERSION" ] || fail "neo_api_client.__version__ is '$IMPORT_OUT', expected $REQUIRED_SDK_VERSION."
ok "import neo_api_client -> $IMPORT_OUT"
CONF="$(cd "$BROKER_DIR" && "$VENV_PY" -c '
import sys
from app.sdk_conformance import check_runtime
r = check_runtime(); print(r.summary()); sys.exit(0 if r.ok else 1)' 2>&1)" \
  && ok "$CONF" || fail "Runtime signature check failed: $CONF"
info "Running the broker-service test-suite inside the production venv"
(cd "$BROKER_DIR" && DB_PATH="$(mktemp -d)/test.db" NEO_LOG_FILE_ENABLED=false TRADING_MODE=PAPER "$VENV_PY" -m unittest discover -s tests -t . >/tmp/ot-tests.$$ 2>&1) \
  && ok "$(tail -n 3 /tmp/ot-tests.$$ | tr '\n' ' ')" || { tail -n 30 /tmp/ot-tests.$$; rm -f /tmp/ot-tests.$$; fail "Broker-service tests failed on this host."; }
rm -f /tmp/ot-tests.$$

# ------------------------------------------------------------------ node
info "Backend and frontend dependencies"
(cd "$BACKEND_DIR" && npm install --no-audit --no-fund) || fail "Backend npm install failed."
(cd "$FRONTEND_DIR" && npm install --no-audit --no-fund) || fail "Frontend npm install failed."
ok "npm dependencies installed"
info "Backend tests"
(cd "$BACKEND_DIR" && npm test --silent >/tmp/ot-node-tests.$$ 2>&1) && ok "backend tests passed" || { tail -n 30 /tmp/ot-node-tests.$$; rm -f /tmp/ot-node-tests.$$; fail "Backend tests failed."; }
rm -f /tmp/ot-node-tests.$$

info "Database"
if [ -f "$DB_PATH" ]; then
  mkdir -p "$ROOT_DIR/backups"; B="$ROOT_DIR/backups/owner-trading.db.$(date +%Y%m%d%H%M%S).bak"; cp "$DB_PATH" "$B"; ok "Backed up existing database -> ${B#$ROOT_DIR/}"
fi
mkdir -p "$BACKEND_DIR/src/data/secure" "$BACKEND_DIR/data" "$BROKER_DIR/data"
node "$BACKEND_DIR/src/db/migrate.js" || fail "Database migration failed."
ok "Migrations applied"

# ------------------------------------------------------------------ configuration
info "Configuration (secrets are generated once and preserved)"
gen() { node -e "console.log(require('crypto').randomBytes(${1:-32}).toString('hex'))"; }
if [ ! -f "$ENV_FILE" ]; then
  { echo "NODE_ENV=production"; echo "PORT=${PORT}"; echo "DB_PATH=${DB_PATH}"; echo "BROKER_SERVICE_URL=http://127.0.0.1:${BROKER_PORT}"; echo "TRADING_MODE=PAPER"; } > "$ENV_FILE"
fi
[ -n "$(get_kv "$ENV_FILE" SESSION_SECRET)" ] || set_kv "$ENV_FILE" SESSION_SECRET "$(gen 48)"
[ -n "$(get_kv "$ENV_FILE" BROKER_SERVICE_TOKEN)" ] || set_kv "$ENV_FILE" BROKER_SERVICE_TOKEN "$(gen 32)"
# auto = Secure cookie on HTTPS requests, plain cookie on HTTP (see backend/src/config/sessionCookie.js)
[ -n "$(get_kv "$ENV_FILE" SESSION_COOKIE_SECURE)" ] || set_kv "$ENV_FILE" SESSION_COOKIE_SECURE auto
chmod 600 "$ENV_FILE"; ok "backend/.env ready"
COOKIE_POLICY="$(get_kv "$ENV_FILE" SESSION_COOKIE_SECURE | tr 'A-Z' 'a-z')"; COOKIE_POLICY="${COOKIE_POLICY:-auto}"
TOKEN="$(get_kv "$ENV_FILE" BROKER_SERVICE_TOKEN)"; MODE="$(get_kv "$ENV_FILE" TRADING_MODE)"; MODE="${MODE:-PAPER}"

if [ -n "$IS_ROOT" ]; then
  mkdir -p "$(dirname "$BROKER_ENV_SYSTEM_PATH")"
  if [ ! -f "$BROKER_ENV_SYSTEM_PATH" ]; then
    sed "s#/opt/owner-trading#${ROOT_DIR}#g" "$BROKER_DIR/.env.example" > "$BROKER_ENV_SYSTEM_PATH"
    ok "Created $BROKER_ENV_SYSTEM_PATH from template"
  fi
  set_kv "$BROKER_ENV_SYSTEM_PATH" BROKER_SERVICE_PORT "$BROKER_PORT"
  set_kv "$BROKER_ENV_SYSTEM_PATH" BROKER_SERVICE_TOKEN "$TOKEN"   # always identical to backend/.env
  set_kv "$BROKER_ENV_SYSTEM_PATH" TRADING_MODE "$MODE"            # always identical to backend/.env
  set_kv "$BROKER_ENV_SYSTEM_PATH" DB_PATH "$DB_PATH"
  chmod 600 "$BROKER_ENV_SYSTEM_PATH"; ok "broker.env synchronised (token + mode + DB path)"
fi

info "Building frontend"
(cd "$FRONTEND_DIR" && npm run build) || fail "Frontend build failed."
[ -f "$FRONTEND_DIR/dist/index.html" ] || fail "Frontend build produced no dist/index.html."
ok "frontend/dist built"

# ------------------------------------------------------------------ password
info "Website access password"
NEW_PW=""
if [ -f "$PASSWORD_HASH_FILE" ]; then
  read -r -p "  A password is already set. Set a new one? [y/N]: " R; R="${R:-N}"
else R="y"; fi
if [[ "$R" =~ ^[Yy]$ ]]; then
  while true; do
    read -r -s -p "  Website access password: " P1; echo
    read -r -s -p "  Confirm: " P2; echo
    [[ "$P1" == "$P2" ]] || { echo "  Passwords do not match."; continue; }
    [[ -n "$P1" ]] || { echo "  Cannot be empty."; continue; }
    [[ $(printf '%s' "$P1" | wc -c) -le 72 ]] || { echo "  Too long (bcrypt max 72 bytes)."; continue; }
    break
  done
  printf '%s' "$P1" | node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to store the password hash."
  NEW_PW="$P1"; unset P1 P2; ok "Password stored (bcrypt hash)"
else ok "Keeping existing password"; fi

# ------------------------------------------------------------------ services
info "Process management"
USE_SYSTEMD=""
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] && [ -n "$IS_ROOT" ]; then USE_SYSTEMD=1; fi
if [ -n "$USE_SYSTEMD" ]; then
  id owner-trading >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin owner-trading
  chown -R owner-trading:owner-trading "$BACKEND_DIR/data" "$BACKEND_DIR/src/data/secure" "$BROKER_DIR/data"
  for f in "$ENV_FILE" "$PASSWORD_HASH_FILE" "$BROKER_ENV_SYSTEM_PATH"; do [ -f "$f" ] && { chown owner-trading:owner-trading "$f"; chmod 600 "$f"; }; done

  # The service units run as the dedicated owner-trading user with ProtectHome=true
  # (kept -- see the units' ReadOnlyPaths= comment). If ROOT_DIR sits under /home
  # (e.g. /home/ubuntu/owner-trading/owner-trading), only ROOT_DIR/backend and
  # ROOT_DIR/broker-service themselves are re-exposed by ReadOnlyPaths= inside the
  # service's mount namespace; systemd creates the ancestor directories leading to
  # that mount point itself (root:root, traversable), so real permissions on
  # /home/<user> do not matter for the CHDIR to succeed. What DOES matter is that
  # ROOT_DIR/backend and ROOT_DIR/broker-service themselves -- the real, on-disk
  # directories that get bind-mounted -- are traversable by "other" (owner-trading
  # has no group relationship to whichever user deployed the project). Fix that
  # here, non-recursively (only the two directories' own mode, never their
  # contents), rather than relying on a manual workaround after the fact.
  for d in "$BACKEND_DIR" "$BROKER_DIR"; do
    if [ -d "$d" ]; then
      OTHER_DIGIT="$(stat -c '%a' "$d" | tail -c 2)"
      if [ $(( OTHER_DIGIT % 2 )) -eq 0 ]; then
        chmod o+rx "$d" && ok "Granted traverse (o+rx) on $d for the owner-trading service user (was mode $(stat -c '%a' "$d"))"
      fi
    fi
  done

  sed -e "s#/opt/owner-trading#${ROOT_DIR}#g" -e "s#/usr/bin/env node#${NODE_BIN}#g" "$DEPLOYMENT_DIR/systemd/owner-trading-backend.service" > /etc/systemd/system/owner-trading-backend.service
  sed -e "s#/opt/owner-trading#${ROOT_DIR}#g" "$DEPLOYMENT_DIR/systemd/owner-trading-broker.service" > /etc/systemd/system/owner-trading-broker.service
  if command -v systemd-analyze >/dev/null 2>&1; then
    for u in owner-trading-backend owner-trading-broker; do
      OUT="$(systemd-analyze verify "/etc/systemd/system/$u.service" 2>&1 || true)"; [ -n "$OUT" ] && warn "systemd-analyze ($u): $OUT"
    done
  fi
  systemctl daemon-reload
  ok "systemctl daemon-reload"
  systemctl enable owner-trading-broker.service owner-trading-backend.service >/dev/null
  systemctl restart owner-trading-broker.service  || { journalctl -u owner-trading-broker  -n 50 --no-pager; fail "broker failed to start (journal above)."; }
  systemctl restart owner-trading-backend.service || { journalctl -u owner-trading-backend -n 50 --no-pager; fail "backend failed to start (journal above)."; }
  ok "systemd units installed, enabled at boot, (re)started"

  info "Verifying effective systemd configuration (not just the unit source files)"
  for u in owner-trading-backend owner-trading-broker; do
    systemctl is-active --quiet "$u" || { journalctl -u "$u" -n 50 --no-pager; fail "$u is not active after restart."; }
    EFFECTIVE="$(systemctl show "$u" -p User,Group,WorkingDirectory,ProtectHome,ProtectSystem,ReadOnlyPaths,ReadWritePaths,Result,ExecMainStatus 2>&1)"
    echo "$EFFECTIVE" | sed 's/^/    /'
    RESULT="$(echo "$EFFECTIVE" | awk -F= '/^Result=/{print $2}')"
    [ "$RESULT" = "success" ] || warn "$u Result=$RESULT (non-fatal if the unit is still Type=simple and running; check journal if status is wrong below)."
    ok "$u effective config captured above"
  done
  # Regression guard for the exact failure this fix addresses: if it recurs (e.g. a
  # future edit reverts the ReadOnlyPaths= lines), fail loudly here instead of
  # surfacing only as a 502 from Nginx later.
  for u in owner-trading-backend owner-trading-broker; do
    if journalctl -u "$u" -n 20 --no-pager 2>/dev/null | grep -qi 'CHDIR\|Changing to the requested working directory failed'; then
      journalctl -u "$u" -n 50 --no-pager
      fail "$u: CHDIR/working-directory error detected in the journal (see above). This is the ProtectHome/WorkingDirectory issue -- check that ReadOnlyPaths= in the unit covers the service's own directory."
    fi
  done
  ok "No CHDIR/working-directory errors in either service's recent journal"

  info "Verifying backend and broker respond locally (before Nginx is touched)"
  wait_for() { for _ in $(seq 1 25); do curl -fsS "$1" >/dev/null 2>&1 && return 0; sleep 1; done; return 1; }
  wait_for "http://127.0.0.1:${BROKER_PORT}/health" || { journalctl -u owner-trading-broker -n 50 --no-pager; fail "Broker service failed its health check on 127.0.0.1:${BROKER_PORT}."; }
  ok "Broker service healthy on 127.0.0.1:${BROKER_PORT} (127.0.0.1:${BROKER_PORT}/health)"
  ss -ltn 2>/dev/null | grep -q "127.0.0.1:${BROKER_PORT} " && ok "127.0.0.1:${BROKER_PORT} is listening on loopback only" || warn "Could not confirm 127.0.0.1:${BROKER_PORT} is loopback-only via ss (non-fatal; the health check above already succeeded)."
  [ "$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${BROKER_PORT}/status")" = 401 ] && ok "Broker API rejects requests without the internal token" || warn "Broker API did not return 401 without a token (only acceptable in PAPER dev)."
  BSTAT="$(curl -fsS -H "X-Internal-Token: $TOKEN" "http://127.0.0.1:${BROKER_PORT}/status" || true)"
  echo "$BSTAT" | grep -qE '"state":"(NOT_CONFIGURED|DISCONNECTED)"' \
    && ok "Broker starts cleanly with no Kotak credentials entered (state: $(echo "$BSTAT" | grep -o '"state":"[^"]*"'))" \
    || warn "Broker state was not NOT_CONFIGURED/DISCONNECTED at startup: $(echo "$BSTAT" | head -c 200) (fine if credentials were pre-supplied via broker.env)."
  ok "Broker status: $(echo "$BSTAT" | head -c 300)"
  wait_for "http://127.0.0.1:${PORT}/api/health" || { journalctl -u owner-trading-backend -n 50 --no-pager; fail "Backend failed its health check on 127.0.0.1:${PORT}."; }
  ok "Backend healthy on 127.0.0.1:${PORT} (127.0.0.1:${PORT}/api/health)"
  ss -ltn 2>/dev/null | grep -q "127.0.0.1:${PORT} " && ok "127.0.0.1:${PORT} is listening on loopback only" || warn "Could not confirm 127.0.0.1:${PORT} is loopback-only via ss (non-fatal; the health check above already succeeded)."
else
  warn "systemd unavailable (not root / container) -- starting both services directly in the background."
  for svc in broker backend; do
    PF="$ROOT_DIR/.owner-trading-$svc.pid"
    [ -f "$PF" ] && kill -0 "$(cat "$PF")" 2>/dev/null && { kill "$(cat "$PF")" 2>/dev/null || true; sleep 1; }
  done
  (cd "$BROKER_DIR" && set -a && { [ -f "$BROKER_ENV_SYSTEM_PATH" ] && . "$BROKER_ENV_SYSTEM_PATH"; true; } && set +a \
     && BROKER_SERVICE_PORT="$BROKER_PORT" BROKER_SERVICE_TOKEN="$TOKEN" TRADING_MODE="$MODE" DB_PATH="$DB_PATH" NEO_LOG_FILE_ENABLED=false \
     nohup ./venv/bin/python -m app.main > "$ROOT_DIR/owner-trading-broker.log" 2>&1 & echo $! > "$ROOT_DIR/.owner-trading-broker.pid")
  (cd "$BACKEND_DIR" && nohup npm start > "$ROOT_DIR/owner-trading-backend.log" 2>&1 & echo $! > "$ROOT_DIR/.owner-trading-backend.pid")
  ok "Started (logs: owner-trading-*.log)"
fi

# ------------------------------------------------------------------ nginx + HTTPS
info "Nginx reverse proxy: HTTP always, HTTPS when a domain + certificate are available"
NGINX_ACTIVE=""; HTTPS_ACTIVE=""
if [ -z "$IS_ROOT" ] || ! command -v nginx >/dev/null 2>&1; then
  warn "nginx not available (or not root) -- skipped. The app is reachable over HTTP at http://<this-server>:${PORT}/ directly."
else
  NGX_SRC="$DEPLOYMENT_DIR/nginx"
  mkdir -p /etc/nginx/snippets /etc/nginx/conf.d /var/www/certbot
  cp "$NGX_SRC/owner-trading-zones.conf" /etc/nginx/conf.d/owner-trading-zones.conf
  sed "s#127.0.0.1:4000#127.0.0.1:${PORT}#g" "$NGX_SRC/owner-trading-proxy.conf" > /etc/nginx/snippets/owner-trading-proxy.conf
  cp "$NGX_SRC/owner-trading-locations.conf" /etc/nginx/snippets/owner-trading-locations.conf
  SITE=/etc/nginx/sites-available/owner-trading
  build_site() { # $1 = "with-https" | "http-only"
    sed "s#__SERVER_NAME__#${DOMAIN:-_}#g" "$NGX_SRC/owner-trading.http.conf" > "$SITE"
    if [ "$1" = "with-https" ]; then printf '\n' >> "$SITE"; sed "s#__DOMAIN__#${DOMAIN}#g" "$NGX_SRC/owner-trading.https.conf" >> "$SITE"; fi
    ln -sf "$SITE" /etc/nginx/sites-enabled/owner-trading
    rm -f /etc/nginx/sites-enabled/default      # the stock site also claims default_server on :80
  }
  apply_site() { nginx -t >/tmp/ot-nginx-t.$$ 2>&1 && systemctl reload nginx 2>/dev/null || systemctl restart nginx; }
  build_site http-only
  nginx -t >/tmp/ot-nginx-t.$$ 2>&1 || { cat /tmp/ot-nginx-t.$$; rm -f /tmp/ot-nginx-t.$$; fail "nginx configuration test failed (HTTP site written to $SITE)."; }
  systemctl enable --now nginx >/dev/null 2>&1 || true
  systemctl reload nginx 2>/dev/null || systemctl restart nginx
  NGINX_ACTIVE=1; ok "HTTP reverse proxy active on port 80 (no forced redirect)"
  if [ -z "$DOMAIN" ]; then
    warn "No DOMAIN set -> HTTPS not configured. HTTP works at http://<server-ip>/. To add HTTPS later: sudo DOMAIN=your.domain CERTBOT_EMAIL=you@example.com ./deploy.sh"
  else
    CERT="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
    if [ ! -f "$CERT" ]; then
      if [ -z "$CERTBOT_EMAIL" ]; then warn "CERTBOT_EMAIL not set -- cannot request a certificate. HTTP keeps working; HTTPS not enabled."
      elif ! command -v certbot >/dev/null 2>&1; then warn "certbot is not installed -- HTTPS not enabled. HTTP keeps working."
      elif certbot certonly --webroot -w /var/www/certbot -d "$DOMAIN" -m "$CERTBOT_EMAIL" --agree-tos --non-interactive; then ok "Certificate issued for $DOMAIN"
      else warn "certbot could not issue a certificate for $DOMAIN (DNS must point at this server and port 80 must be reachable). HTTP keeps working; re-run to retry HTTPS."; fi
    fi
    if [ -f "$CERT" ]; then
      build_site with-https
      if nginx -t >/tmp/ot-nginx-t.$$ 2>&1; then
        mkdir -p /etc/letsencrypt/renewal-hooks/deploy
        printf '#!/bin/sh\nsystemctl reload nginx\n' > /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh; chmod +x /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh
        systemctl reload nginx && HTTPS_ACTIVE=1 && ok "HTTPS enabled for https://$DOMAIN (HTTP still available; certbot timer renews and reloads nginx)"
        if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi active; then ufw allow 'Nginx Full' >/dev/null 2>&1 && ok "ufw: Nginx Full allowed"; fi
      else
        cat /tmp/ot-nginx-t.$$; build_site http-only; systemctl reload nginx 2>/dev/null || true
        warn "HTTPS server block failed nginx -t and was NOT enabled; HTTP site restored."
      fi
    fi
  fi
  rm -f /tmp/ot-nginx-t.$$
fi

# ------------------------------------------------------------------ non-systemd fallback health check
if [ -z "$USE_SYSTEMD" ]; then
  info "Health checks"
  wait_for() { for _ in $(seq 1 25); do curl -fsS "$1" >/dev/null 2>&1 && return 0; sleep 1; done; return 1; }
  wait_for "http://127.0.0.1:${BROKER_PORT}/health" || { tail -n 30 "$ROOT_DIR/owner-trading-broker.log" 2>/dev/null; fail "Broker service failed its health check."; }
  ok "Broker service healthy"
  BSTAT="$(curl -fsS -H "X-Internal-Token: $TOKEN" "http://127.0.0.1:${BROKER_PORT}/status" || true)"
  ok "Broker status: $(echo "$BSTAT" | head -c 300)"
  wait_for "http://127.0.0.1:${PORT}/api/health" || { tail -n 30 "$ROOT_DIR/owner-trading-backend.log" 2>/dev/null; fail "Backend failed its health check."; }
  ok "Backend healthy"
fi

# ------------------------------------------------------------------ nginx upstream / public reachability
if [ -n "$NGINX_ACTIVE" ]; then
  info "Verifying Nginx upstream connectivity (the actual 502 check)"
  CODE="$(curl -s -o /tmp/ot-nginx-body.$$ -w '%{http_code}' --max-time 10 "http://127.0.0.1/api/health" || echo 000)"
  if [ "$CODE" = "502" ] || [ "$CODE" = "503" ] || [ "$CODE" = "504" ]; then
    tail -c 500 /tmp/ot-nginx-body.$$; rm -f /tmp/ot-nginx-body.$$
    journalctl -u owner-trading-backend -n 30 --no-pager
    fail "Nginx returned HTTP $CODE proxying to the backend -- upstream is not reachable from Nginx. See the backend journal above."
  fi
  [ "$CODE" = "200" ] || { tail -c 300 /tmp/ot-nginx-body.$$; fail "Nginx did not return 200 for /api/health via the local reverse proxy (got HTTP $CODE)."; }
  rm -f /tmp/ot-nginx-body.$$
  ok "Nginx -> backend upstream OK (http://127.0.0.1/api/health -> HTTP 200, no 502/503/504)"
  ROOT_CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1/")"
  [ "$ROOT_CODE" = "502" ] && fail "Nginx returned 502 for the site root through the local reverse proxy."
  ok "Site root via Nginx: HTTP $ROOT_CODE (not 502)"
  if [ -n "$HTTPS_ACTIVE" ]; then
    HCODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 --resolve "${DOMAIN}:443:127.0.0.1" "https://${DOMAIN}/api/health")"
    [ "$HCODE" = "502" ] && fail "Nginx returned 502 for https://${DOMAIN}/api/health."
    [ "$HCODE" = "200" ] && ok "HTTPS via Nginx (https://${DOMAIN}/api/health): HTTP 200, no 502" || warn "HTTPS via Nginx: HTTP $HCODE (expected 200)."
  fi
  echo "  NOTE: the checks above confirm Nginx <-> backend connectivity FROM THIS SERVER. Confirming the site is"
  echo "  reachable from the public internet (not just that this server can reach itself) requires an external"
  echo "  request -- e.g. curl from another machine, or deployment/verify-deployment.sh DOMAIN=${DOMAIN:-<domain>} run"
  echo "  after DNS points here. This script does not claim that external check on your behalf."
else
  info "Nginx is not active -- skipping the Nginx-upstream / 502 check (the app is reachable directly on 127.0.0.1:${PORT})."
fi

# ---- Login + session verification -------------------------------------------------------------
# Runs REAL requests and checks REAL behaviour (cookie attributes, authenticated API access, logout).
# Nothing is faked: the plain-HTTP flow sends no proxy headers at all; the HTTPS flows are either a
# real TLS request through nginx, or -- clearly labelled -- the exact X-Forwarded-Proto header nginx
# adds on port 443, sent to Express directly.
session_flow() { # label base_url expect(plain|secure|none) [extra curl args...]
  local label="$1" base="$2" expect="$3"; shift 3
  local hdr body code cookie_line pair
  hdr="$(mktemp)"; body="$(mktemp)"
  code="$(printf '%s' "$LOGIN_JSON" | curl -sS -o "$body" -D "$hdr" -w '%{http_code}' --max-time 15 "$@" \
          -H 'Content-Type: application/json' --data-binary @- "$base/api/auth/login" 2>&1)" || { rm -f "$hdr" "$body"; fail "[$label] login request failed to connect: $code"; }
  [ "$code" = "200" ] && grep -q '"success":true' "$body" || { rm -f "$hdr" "$body"; fail "[$label] POST /api/auth/login returned HTTP $code (password authentication itself is separate from cookies -- see backend log)."; }
  cookie_line="$(grep -i '^set-cookie: owner_trading_sid=' "$hdr" | head -n1 | tr -d '\r')"
  rm -f "$hdr" "$body"
  if [ "$expect" = "none" ]; then
    [ -z "$cookie_line" ] && { ok "[$label] password accepted; no session cookie over this transport -- expected: SESSION_COOKIE_SECURE=true is HTTPS-only"; return 0; }
    fail "[$label] a session cookie was issued although SESSION_COOKIE_SECURE=true forbids it over plain HTTP."
  fi
  [ -n "$cookie_line" ] || fail "[$label] login succeeded but NO session cookie was issued -- the browser could not stay logged in."
  echo "$cookie_line" | grep -qi 'httponly'          || fail "[$label] session cookie lacks HttpOnly: $cookie_line"
  echo "$cookie_line" | grep -qi 'samesite=lax'      || fail "[$label] session cookie lacks SameSite=Lax: $cookie_line"
  if [ "$expect" = "secure" ]; then echo "$cookie_line" | grep -qi '; *secure' || fail "[$label] cookie over HTTPS is NOT Secure: $cookie_line"
  else echo "$cookie_line" | grep -qi '; *secure' && fail "[$label] cookie over plain HTTP is marked Secure (browser would drop it): $cookie_line"; fi
  pair="$(echo "${cookie_line#*:}" | sed 's/^ *//' | cut -d';' -f1)"
  # Replay the cookie exactly as a browser would on this transport.
  curl -fsS --max-time 10 "$@" -H "Cookie: $pair" "$base/api/auth/session" | grep -q '"authenticated":true' \
    || fail "[$label] cookie was issued but /api/auth/session does not report an authenticated session."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" -H "Cookie: $pair" "$base/api/risk")" = "200" ] \
    || fail "[$label] authenticated request to a protected API endpoint (/api/risk) was not accepted."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" "$base/api/risk")" = "401" ] \
    || fail "[$label] protected endpoint answered without a session cookie."
  curl -fsS --max-time 10 -X POST "$@" -H "Cookie: $pair" "$base/api/auth/logout" >/dev/null || fail "[$label] logout request failed."
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" -H "Cookie: $pair" "$base/api/risk")" = "401" ] \
    || fail "[$label] session still valid after logout."
  ok "[$label] login -> $([ "$expect" = secure ] && echo 'Secure' || echo 'non-Secure') HttpOnly SameSite=Lax cookie -> authenticated API access -> logout destroys session"
}

if [ -n "$NEW_PW" ]; then
  info "Verifying login + session over HTTP and HTTPS"
  LOGIN_JSON="$(node -e 'process.stdout.write(JSON.stringify({password: process.argv[1]}))' "$NEW_PW")"
  unset NEW_PW
  EXP_HTTP=plain; EXP_HTTPS=secure
  case "$COOKIE_POLICY" in true|1|yes|on) EXP_HTTP=none ;; false|0|no|off) EXP_HTTPS=plain ;; esac
  session_flow "HTTP  -> Express :${PORT}" "http://127.0.0.1:${PORT}" "$EXP_HTTP"
  session_flow "HTTPS -> Express :${PORT} (nginx's X-Forwarded-Proto: https header, simulated)" "http://127.0.0.1:${PORT}" "$EXP_HTTPS" -H 'X-Forwarded-Proto: https'
  if [ -n "$NGINX_ACTIVE" ]; then
    session_flow "HTTP  -> nginx :80 (real reverse proxy)" "http://127.0.0.1" "$EXP_HTTP"
  fi
  if [ -n "$HTTPS_ACTIVE" ]; then
    session_flow "HTTPS -> nginx :443 (real TLS, certificate verified for $DOMAIN)" "https://${DOMAIN}" "$EXP_HTTPS" --resolve "${DOMAIN}:443:127.0.0.1"
  fi
  unset LOGIN_JSON
else
  info "Login verification skipped: the existing password was kept and this script never holds its plaintext."
  echo "  Unauthenticated session endpoint check only:"
  curl -fsS --max-time 10 "http://127.0.0.1:${PORT}/api/auth/session" | grep -q '"authenticated":false' && ok "GET /api/auth/session answers {authenticated:false} without a cookie" || fail "/api/auth/session did not answer as expected."
  echo "  To verify login for real: re-run ./deploy.sh and choose to set a new password, or log in from a browser."
fi

echo
echo "=============================================="
echo "   Deployment complete"
echo "   Mode:            $MODE   (change with: sudo deployment/set-mode.sh PAPER|LIVE)"
echo "   Official SDK:    kotakneoapi $INSTALLED (vendored, integrity + signatures verified)"
if [ -n "$NGINX_ACTIVE" ]; then HTTP_DESC="http://<server-ip>/  (via nginx on port 80)"; else HTTP_DESC="http://<server-ip>:${PORT}/  (nginx not installed)"; fi
if [ -n "$HTTPS_ACTIVE" ]; then HTTPS_DESC="https://${DOMAIN} (nginx :443; HTTP stays available)"; else HTTPS_DESC="not enabled (needs DOMAIN + a certificate)"; fi
echo "   HTTP:            ${HTTP_DESC}"
echo "   HTTPS:           ${HTTPS_DESC}"
echo "   Cookie policy:   SESSION_COOKIE_SECURE=${COOKIE_POLICY} (auto: Secure on HTTPS, plain on HTTP)"
if [ -n "$USE_SYSTEMD" ]; then echo "   Services:        owner-trading-backend, owner-trading-broker (systemd, User=Group=owner-trading, effective config verified above)"; fi
if [ -n "$NGINX_ACTIVE" ]; then echo "   Nginx upstream:  verified (no 502/503/504 from 127.0.0.1)"; fi
echo "   Next:            Settings -> enter Kotak credentials -> Test -> Connect."
echo "                    LIVE additionally needs: set-mode.sh LIVE, all checks green on the Risk page, then Arm."
echo "   Smoke test:      DOMAIN=${DOMAIN} sudo deployment/verify-deployment.sh"
echo "=============================================="
