#!/usr/bin/env bash
# Switch BOTH services between PAPER and LIVE together, so they can never disagree.
#   sudo deployment/set-mode.sh PAPER
#   sudo deployment/set-mode.sh LIVE
# LIVE only changes the mode. Orders still cannot reach Kotak until every readiness check passes
# and you arm LIVE trading on the Risk page.
set -euo pipefail
MODE="${1:-}"
[[ "$MODE" == "PAPER" || "$MODE" == "LIVE" ]] || { echo "usage: $0 PAPER|LIVE" >&2; exit 2; }
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_ENV="$ROOT_DIR/backend/.env"
BROKER_ENV="${BROKER_ENV:-/etc/owner-trading/broker.env}"
[ -f "$BACKEND_ENV" ] || { echo "missing $BACKEND_ENV" >&2; exit 1; }
[ -f "$BROKER_ENV" ] || { echo "missing $BROKER_ENV" >&2; exit 1; }

get() { grep -E "^$2=" "$1" | tail -n1 | cut -d= -f2-; }
if [[ "$MODE" == "LIVE" ]]; then
  T1="$(get "$BACKEND_ENV" BROKER_SERVICE_TOKEN)"; T2="$(get "$BROKER_ENV" BROKER_SERVICE_TOKEN)"
  [[ ${#T1} -ge 32 && "$T1" == "$T2" ]] || { echo "LIVE needs the same BROKER_SERVICE_TOKEN (>=32 chars) in both env files." >&2; exit 1; }
  [[ "$(get "$BACKEND_ENV" NODE_ENV)" == "production" ]] || { echo "LIVE needs NODE_ENV=production in $BACKEND_ENV." >&2; exit 1; }
  read -r -p "Switch to LIVE? Real orders become possible once armed. Type LIVE to confirm: " C
  [[ "$C" == "LIVE" ]] || { echo "aborted"; exit 1; }
fi
set_kv() { if grep -q "^$2=" "$1"; then sed -i "s#^$2=.*#$2=$3#" "$1"; else echo "$2=$3" >> "$1"; fi; }
if [[ "$MODE" == "LIVE" ]]; then
  # LIVE control is HTTPS-only: the session cookie must be Secure-only (login over plain HTTP is then refused by design).
  set_kv "$BACKEND_ENV" SESSION_COOKIE_SECURE true
  echo "SESSION_COOKIE_SECURE=true set: LIVE mode is usable over HTTPS only."
fi
set_kv "$BACKEND_ENV" TRADING_MODE "$MODE"
set_kv "$BROKER_ENV" TRADING_MODE "$MODE"
# always start disarmed after a mode change
DB="$(get "$BACKEND_ENV" DB_PATH)"
if [ -n "$DB" ] && [ -f "$DB" ] && command -v node >/dev/null; then
  node -e "const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync(process.argv[1]);d.prepare('UPDATE risk_settings SET live_trading_armed=0, armed_at=NULL WHERE id=1').run();" "$DB" || true
fi
systemctl restart owner-trading-broker.service owner-trading-backend.service
echo "Mode is now $MODE (LIVE trading is disarmed). Verify: deployment/verify-deployment.sh"
