require("dotenv").config();

const createApp = require("./src/app");
const config = require("./src/config");
const passwordStore = require("./src/services/passwordStore");
const { run: runMigrations } = require("./src/db/migrate");
const { markReady, markDegraded } = require("./src/services/readiness");

// Migrations are idempotent (see src/db/migrate.js) -- running them on
// every boot is safe and means a fresh deploy never needs a separate manual
// migration step.
//
// BUGFIX (final audit): markDegraded() here used to be silently overwritten
// by an unconditional markReady() inside app.listen()'s callback below --
// meaning a migration failure was recorded for a few milliseconds and then
// immediately erased, so /api/system/readiness would report READY even
// though migrations had failed. `startupOk` makes the READY call
// conditional on nothing having failed first, so a migration failure (or
// any other startup failure added later) stays DEGRADED for the life of
// the process instead of being overwritten.
const { validateConfig, configWarnings } = require("./src/config/validate");
const configProblems = validateConfig(config);
if (configProblems.length) {
  for (const p of configProblems) console.error("[owner-trading] CONFIG ERROR:", p);
  process.exit(1);
}

for (const w of configWarnings(config)) console.warn("[owner-trading] NOTE:", w);

let startupOk = true;
try {
  runMigrations();
} catch (err) {
  console.error("[owner-trading] migration run failed at startup:", err.message);
  markDegraded();
  startupOk = false;
}

const app = createApp();

app.listen(config.port, () => {
  console.log(`[owner-trading] backend listening on port ${config.port} (env: ${config.env})`);
  if (startupOk) {
    markReady();
  } else {
    console.error(
      "[owner-trading] startup completed with errors -- readiness stays DEGRADED. " +
        "Fix the migration failure above and restart."
    );
  }

  if (!passwordStore.hasPasswordConfigured()) {
    console.warn(
      "[owner-trading] WARNING: no access password is configured yet. " +
        "Run ./deploy.sh from the project root, or " +
        "`node deployment/set-password.js`, before exposing this server."
    );
  }
});

process.on("SIGTERM", () => {
  console.log("[owner-trading] received SIGTERM, shutting down gracefully");
  process.exit(0);
});
process.on("SIGINT", () => {
  console.log("[owner-trading] received SIGINT, shutting down gracefully");
  process.exit(0);
});
