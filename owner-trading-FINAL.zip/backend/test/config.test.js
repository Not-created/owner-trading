const test = require("node:test");
const assert = require("node:assert");
const { validateConfig } = require("../src/config/validate");

const good = { env: "production", sessionSecret: "x".repeat(40), tradingMode: "PAPER", brokerServiceToken: "", brokerServiceUrl: "http://127.0.0.1:8800", sessionCookieSecure: "auto" };

test("valid PAPER production config passes", () => assert.deepStrictEqual(validateConfig(good), []));
test("default / short session secret rejected in production", () => {
  assert.ok(validateConfig({ ...good, sessionSecret: "dev-only-insecure-secret-change-me" }).length);
  assert.ok(validateConfig({ ...good, sessionSecret: "short" }).length);
});
test("development may use any secret", () => assert.deepStrictEqual(validateConfig({ ...good, env: "development", sessionSecret: "dev" }), []));
test("unknown trading mode rejected", () => assert.ok(validateConfig({ ...good, tradingMode: "live" }).length));
test("LIVE requires production and a strong internal token", () => {
  assert.ok(validateConfig({ ...good, tradingMode: "LIVE" }).some((p) => /BROKER_SERVICE_TOKEN/.test(p)));
  assert.ok(validateConfig({ ...good, env: "development", tradingMode: "LIVE", brokerServiceToken: "t".repeat(32) }).some((p) => /NODE_ENV/.test(p)));
  assert.deepStrictEqual(validateConfig({ ...good, tradingMode: "LIVE", brokerServiceToken: "t".repeat(32), sessionCookieSecure: "true" }), []);
});
test("broker service URL must be loopback", () => {
  assert.ok(validateConfig({ ...good, brokerServiceUrl: "http://10.0.0.5:8800" }).length);
  assert.ok(validateConfig({ ...good, brokerServiceUrl: "http://example.com" }).length);
  assert.deepStrictEqual(validateConfig({ ...good, brokerServiceUrl: "http://localhost:8800" }), []);
});
