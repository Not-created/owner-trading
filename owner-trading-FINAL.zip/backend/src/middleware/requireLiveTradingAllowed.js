const config = require("../config");
const { getBrokerConnectionState, isEmergencyStopActive, BROKER_STATES } = require("../services/brokerState");

/**
 * Safety gate for any future LIVE-order-placing route. No such route exists
 * yet in this foundation phase -- this middleware exists now so that when
 * one is added (next phase), it is structurally impossible to wire it up
 * without going through this check.
 *
 * Blocks the request unless ALL of the following hold:
 *   - TRADING_MODE is explicitly "LIVE" (default is "PAPER" -- PAPER must
 *     never reach this gate at all, let alone pass it)
 *   - emergency stop is not active
 *   - the broker connection state is genuinely CONNECTED (not just
 *     "credentials exist")
 *
 * PAPER-mode requests should never call this middleware in the first place
 * -- routing PAPER orders here would be a bug in the caller, not something
 * this gate is meant to silently allow through.
 */
function requireLiveTradingAllowed(req, res, next) {
  if (config.tradingMode !== "LIVE") {
    return res.status(403).json({ error: "LIVE trading is not enabled on this deployment." });
  }
  if (isEmergencyStopActive()) {
    return res.status(423).json({ error: "Emergency stop is active. No LIVE orders are permitted." });
  }
  const { state } = getBrokerConnectionState();
  if (state !== BROKER_STATES.CONNECTED) {
    return res.status(409).json({ error: `Broker is not connected (state: ${state}). LIVE orders are blocked.` });
  }
  return next();
}

module.exports = { requireLiveTradingAllowed };
