const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { getBrokerConnectionState, getEmergencyStopState } = require("../services/brokerState");
const config = require("../config");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

const refresh = (req) => req.query.refresh === "1";

router.get("/orders", wrap(async (req, res) => relay(res, await brokerClient.getOrders(req.query.limit, req.query.mode))));
router.get("/positions", wrap(async (req, res) => relay(res, await brokerClient.getPositions(refresh(req)))));
router.get("/holdings", wrap(async (req, res) => relay(res, await brokerClient.getHoldings(refresh(req)))));
router.get("/pnl", wrap(async (req, res) => relay(res, await brokerClient.getPnl())));
router.get("/history", wrap(async (req, res) => relay(res, await brokerClient.getTrades(req.query.mode))));

// One round-trip summary for the dashboard: only data the broker service
// actually has. Any failing sub-call is reported as null + an entry in `errors`.
router.get("/summary", wrap(async (req, res) => {
  const [funds, pnl, orders] = await Promise.all([brokerClient.getFunds(false), brokerClient.getPnl(), brokerClient.getOrders(200, undefined)]);
  const errors = [];
  const take = (name, r, pick) => {
    if (r.ok && r.body) return pick(r.body);
    errors.push(`${name}: ${r.networkError || (r.body && r.body.error) || `HTTP ${r.status}`}`);
    return null;
  };
  const openStatuses = new Set(["SUBMITTING", "SUBMITTED", "OPEN", "PARTIALLY_FILLED", "PENDING_RECONCILE", "MODIFY_REQUESTED", "CANCEL_REQUESTED", "PAPER_ACCEPTED"]);
  res.json({
    tradingMode: config.tradingMode,
    broker: getBrokerConnectionState(),
    emergencyStop: getEmergencyStopState(),
    funds: take("funds", funds, (b) => b.funds),
    pnl: take("pnl", pnl, (b) => b),
    orders: take("orders", orders, (b) => ({
      total: b.orders.length,
      open: b.orders.filter((o) => openStatuses.has(o.status)).length,
      needingAttention: b.orders.filter((o) => o.outcome_unknown).length,
    })),
    errors,
  });
}));

module.exports = router;
