-- 001_init.sql
-- Foundation schema for Owner Trading. Covers structure needed for the
-- broker/order/portfolio foundation described in this phase. No real broker
-- data is written by anything yet -- these tables exist so the next phase
-- (Kotak account connection) has a ready, correct place to write into.

CREATE TABLE IF NOT EXISTS broker_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  broker_name TEXT NOT NULL DEFAULT 'kotak_neo',
  ucc TEXT,                          -- Kotak UCC, set only once connected (next phase)
  environment TEXT NOT NULL DEFAULT 'prod',
  credential_ref TEXT,               -- opaque reference to where secrets live (NOT the secret itself)
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS broker_connection_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),  -- singleton row
  broker_account_id INTEGER REFERENCES broker_accounts(id),
  state TEXT NOT NULL DEFAULT 'NOT_CONFIGURED',
  -- one of: DISCONNECTED, VERIFYING, CONNECTED, AUTH_FAILED,
  --         SESSION_EXPIRED, CONNECTION_ERROR, NOT_CONFIGURED
  last_error TEXT,
  last_transition_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Session/token metadata only -- never the raw token/secret value itself in
-- this table (see broker-service/app/secure_store.py for where actual
-- session artifacts are intended to live server-side, outside SQLite).
CREATE TABLE IF NOT EXISTS broker_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  broker_account_id INTEGER NOT NULL REFERENCES broker_accounts(id),
  session_ref TEXT,                  -- opaque reference, not the token itself
  data_center TEXT,
  established_at TEXT,
  expires_at TEXT,
  revoked_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS instruments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exchange_segment TEXT NOT NULL,
  trading_symbol TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  name TEXT,
  instrument_type TEXT,
  expiry TEXT,
  strike REAL,
  option_type TEXT,
  lot_size INTEGER,
  tick_size REAL,
  scrip_master_updated_at TEXT,
  UNIQUE (exchange_segment, instrument_token)
);
CREATE INDEX IF NOT EXISTS idx_instruments_symbol ON instruments (trading_symbol);

CREATE TABLE IF NOT EXISTS strategies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  mode TEXT NOT NULL DEFAULT 'PAPER',  -- PAPER | LIVE
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  internal_order_id TEXT NOT NULL UNIQUE,   -- our own idempotency key
  broker_order_id TEXT,                     -- Kotak's order id, once placed
  strategy_id INTEGER REFERENCES strategies(id),
  instrument_token TEXT,
  exchange_segment TEXT,
  trading_symbol TEXT,
  transaction_type TEXT,   -- B | S
  order_type TEXT,         -- L | MKT | SL | SL-M
  product TEXT,            -- CNC | NRML | MIS | MTF
  validity TEXT,           -- DAY | IOC
  quantity INTEGER,
  price REAL,
  trigger_price REAL,
  mode TEXT NOT NULL DEFAULT 'PAPER',  -- PAPER | LIVE
  status TEXT NOT NULL DEFAULT 'PENDING',
  status_reason TEXT,
  submitted_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_broker_order_id ON orders (broker_order_id);
CREATE INDEX IF NOT EXISTS idx_orders_strategy ON orders (strategy_id);

-- Every raw broker order-status/order-feed event, kept verbatim for
-- reconciliation and duplicate-event protection (idempotency key = broker
-- event id where the broker supplies one).
CREATE TABLE IF NOT EXISTS order_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER REFERENCES orders(id),
  broker_order_id TEXT,
  event_source TEXT NOT NULL,  -- 'order_feed_ws' | 'order_report_rest' | 'reconciliation'
  broker_event_id TEXT,        -- for de-duplication, when the broker provides one
  raw_payload TEXT NOT NULL,   -- verbatim JSON as received, never altered
  received_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (event_source, broker_event_id)
);

CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER REFERENCES orders(id),
  broker_order_id TEXT,
  broker_trade_id TEXT UNIQUE,  -- idempotency key for fills
  fill_quantity INTEGER,
  fill_price REAL,
  fill_time TEXT,
  raw_payload TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS positions_snapshot (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trading_symbol TEXT,
  exchange_segment TEXT,
  product TEXT,
  quantity INTEGER,
  average_price REAL,
  raw_payload TEXT,
  snapshot_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS holdings_snapshot (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trading_symbol TEXT,
  exchange_segment TEXT,
  quantity INTEGER,
  average_price REAL,
  raw_payload TEXT,
  snapshot_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS funds_snapshot (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  available_margin REAL,
  used_margin REAL,
  raw_payload TEXT,
  snapshot_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS market_data_state (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instrument_token TEXT NOT NULL,
  exchange_segment TEXT,
  last_traded_price REAL,
  last_tick_at TEXT,
  UNIQUE (instrument_token, exchange_segment)
);

CREATE TABLE IF NOT EXISTS reconciliation_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reconciliation_type TEXT NOT NULL,  -- 'order_status' | 'position' | 'holding' | 'funds'
  reference_id TEXT,
  discrepancy_found INTEGER NOT NULL DEFAULT 0,
  details TEXT,
  performed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL,          -- 'system' | 'owner' | 'broker_service'
  action TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS emergency_stop_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),  -- singleton row
  is_active INTEGER NOT NULL DEFAULT 0,
  reason TEXT,
  activated_at TEXT,
  cleared_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Seed the singleton rows so the app can always read them without a
-- special "does it exist" branch.
INSERT OR IGNORE INTO broker_connection_state (id, state) VALUES (1, 'NOT_CONFIGURED');
INSERT OR IGNORE INTO emergency_stop_state (id, is_active) VALUES (1, 0);
