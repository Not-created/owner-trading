-- 003: real order lifecycle (partial fills, client tag reconciliation),
-- position/holding/funds fields matching the official Kotak Neo SDK v3.0.7
-- response shapes, risk limits and live-readiness records.
-- Additive only: no existing column is dropped or renamed.

-- Orders ---------------------------------------------------------------
ALTER TABLE orders ADD COLUMN client_tag TEXT;            -- sent as SDK `tag`, echoed back as GuiOrdId
ALTER TABLE orders ADD COLUMN exchange_order_id TEXT;     -- exOrdId
ALTER TABLE orders ADD COLUMN filled_quantity INTEGER NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN average_price REAL;         -- volume-weighted fill price
ALTER TABLE orders ADD COLUMN broker_status TEXT;         -- last raw ordSt seen (verbatim)
ALTER TABLE orders ADD COLUMN outcome_unknown INTEGER NOT NULL DEFAULT 0; -- 1 = placement outcome must be reconciled
ALTER TABLE orders ADD COLUMN last_broker_update_at TEXT;
ALTER TABLE orders ADD COLUMN pnl_realized REAL;          -- PAPER only: realised P&L booked by the local simulator
CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_client_tag ON orders (client_tag) WHERE client_tag IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);

-- Trades: link fills to broker fields ---------------------------------
ALTER TABLE trades ADD COLUMN mode TEXT NOT NULL DEFAULT 'LIVE';   -- PAPER | LIVE
ALTER TABLE trades ADD COLUMN trading_symbol TEXT;
ALTER TABLE trades ADD COLUMN exchange_segment TEXT;
ALTER TABLE trades ADD COLUMN transaction_type TEXT;
ALTER TABLE trades ADD COLUMN product TEXT;
ALTER TABLE trades ADD COLUMN multiplier REAL;
CREATE INDEX IF NOT EXISTS idx_trades_order ON trades (order_id);

-- Positions (positions() rows: trdSym, exSeg, prod, tok, cf*/fl* qty & amt, multiplier, genNum/genDen/prcNum/prcDen) --
ALTER TABLE positions_snapshot ADD COLUMN instrument_token TEXT;
ALTER TABLE positions_snapshot ADD COLUMN buy_quantity INTEGER;
ALTER TABLE positions_snapshot ADD COLUMN sell_quantity INTEGER;
ALTER TABLE positions_snapshot ADD COLUMN buy_amount REAL;
ALTER TABLE positions_snapshot ADD COLUMN sell_amount REAL;
ALTER TABLE positions_snapshot ADD COLUMN price_factor REAL;   -- multiplier*(genNum/genDen)*(prcNum/prcDen)
ALTER TABLE positions_snapshot ADD COLUMN lot_size INTEGER;

-- Holdings (holdings() rows: symbol, quantity, averagePrice, closingPrice, instrumentToken, exchangeSegment) --
ALTER TABLE holdings_snapshot ADD COLUMN instrument_token TEXT;
ALTER TABLE holdings_snapshot ADD COLUMN closing_price REAL;
ALTER TABLE holdings_snapshot ADD COLUMN market_value REAL;

-- Funds (limits() flat dict: Net, MarginUsed, CashUnRlsMtomPrsnt, ... RlsMtomPrsnt) --
ALTER TABLE funds_snapshot ADD COLUMN realized_mtom REAL;
ALTER TABLE funds_snapshot ADD COLUMN unrealized_mtom REAL;

-- Market data: keep full feed context ---------------------------------
ALTER TABLE market_data_state ADD COLUMN trading_symbol TEXT;
ALTER TABLE market_data_state ADD COLUMN close_price REAL;
ALTER TABLE market_data_state ADD COLUMN volume INTEGER;

-- Risk limits: singleton, all unset (NULL) until the owner configures them --
CREATE TABLE IF NOT EXISTS risk_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  max_order_quantity INTEGER,
  max_order_value REAL,
  max_orders_per_day INTEGER,
  max_daily_loss REAL,            -- positive number; trading halts when realised+unrealised P&L <= -value
  max_open_positions INTEGER,
  live_trading_armed INTEGER NOT NULL DEFAULT 0,  -- explicit owner arming step, separate from TRADING_MODE
  armed_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO risk_settings (id) VALUES (1);

-- Result of the last live-readiness evaluation (audit trail) -----------
CREATE TABLE IF NOT EXISTS live_readiness_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ready INTEGER NOT NULL,
  details TEXT NOT NULL,          -- JSON: per-gate pass/fail with reasons
  checked_at TEXT NOT NULL DEFAULT (datetime('now'))
);
