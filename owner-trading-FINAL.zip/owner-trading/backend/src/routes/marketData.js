const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

// Exact shapes (validated again by the broker service against the official SDK):
//   POST /quotes       { instruments: [{ exchange_segment, instrument_token }], quote_type? }
//   POST /scrip-search { exchange_segment, symbol, expiry?, option_type?, strike_price? }
//   POST /subscribe | /unsubscribe { exchange_segment, instrument_token }   (live SFeed)
router.post("/quotes", wrap(async (req, res) => {
  const { instruments, quote_type } = req.body || {};
  relay(res, await brokerClient.getQuotes({ instruments, quote_type }));
}));

router.post("/scrip-search", wrap(async (req, res) => {
  const { exchange_segment, symbol, expiry, option_type, strike_price } = req.body || {};
  relay(res, await brokerClient.searchScrip({ exchange_segment, symbol, expiry, option_type, strike_price }));
}));

router.get("/ticks", wrap(async (req, res) => relay(res, await brokerClient.getMarketTicks())));
router.get("/subscriptions", wrap(async (req, res) => relay(res, await brokerClient.getSubscriptions())));
router.post("/subscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token } = req.body || {};
  relay(res, await brokerClient.subscribe({ exchange_segment, instrument_token }));
}));
router.post("/unsubscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token } = req.body || {};
  relay(res, await brokerClient.unsubscribe({ exchange_segment, instrument_token }));
}));

module.exports = router;
