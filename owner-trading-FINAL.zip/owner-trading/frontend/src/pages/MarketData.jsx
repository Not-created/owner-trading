import { useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import usePolling from "../hooks/usePolling";
import { EXCHANGE_SEGMENTS, fmt } from "../lib/format";

export default function MarketData() {
  const ticks = usePolling(() => api.getMarketTicks(), 3000);
  const subs = usePolling(() => api.getSubscriptions(), 8000);
  const [seg, setSeg] = useState("nse_cm");
  const [symbol, setSymbol] = useState("");
  const [results, setResults] = useState(null);
  const [searchError, setSearchError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [quote, setQuote] = useState(null);
  const [message, setMessage] = useState(null);

  async function search(e) {
    e.preventDefault();
    setBusy(true); setSearchError(null); setResults(null);
    const { ok, body, status } = await api.searchScrip({ exchange_segment: seg, symbol });
    setBusy(false);
    if (!ok) return setSearchError((body && body.error) || `Search failed (HTTP ${status}).`);
    const data = body.data;
    setResults(Array.isArray(data) ? data.slice(0, 50) : []);
  }

  async function getQuote(row) {
    setQuote(null); setMessage(null);
    const { ok, body, status } = await api.getQuotes([{ exchange_segment: seg, instrument_token: String(row.pSymbol) }], "ltp");
    if (ok) setQuote({ symbol: row.pTrdSymbol, data: body.data });
    else setMessage((body && body.error) || `Quote failed (HTTP ${status}).`);
  }

  async function subscribe(row) {
    setMessage(null);
    const { ok, body } = await api.subscribeInstrument(seg, String(row.pSymbol));
    setMessage(ok ? `Subscribed ${row.pTrdSymbol} to the live feed.` : (body && body.error) || "Subscribe failed.");
    subs.reload();
  }

  async function unsubscribe(s) {
    const { ok, body } = await api.unsubscribeInstrument(s.exchange_segment, s.instrument_token);
    if (!ok) setMessage((body && body.error) || "Unsubscribe failed.");
    subs.reload();
  }

  const tickRows = (ticks.body && ticks.body.ticks) || [];
  const subRows = (subs.body && subs.body.subscriptions) || [];

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Market Data</h2>
        <p className="page__subtitle">Instrument search (Kotak scrip master), REST quotes, and live SFeed subscriptions.</p>
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Find an instrument</h3></div>
        <form onSubmit={search} className="order-form">
          <select value={seg} onChange={(e) => setSeg(e.target.value)}>
            {EXCHANGE_SEGMENTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <input placeholder="Symbol (e.g. yesbank)" value={symbol} onChange={(e) => setSymbol(e.target.value)} required />
          <button type="submit" disabled={busy}>{busy ? "Searching…" : "Search"}</button>
        </form>
        {message && <div className="form-hint">{message}</div>}
        {searchError && <EmptyState title="Search unavailable" hint={searchError} icon="globe" />}
        {results && results.length === 0 && <EmptyState title="No matches" icon="globe" />}
        {results && results.length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Trading symbol</th><th>Name</th><th>Token</th><th>Lot</th><th></th></tr></thead>
              <tbody>
                {results.map((r) => (
                  <tr key={r.pSymbol}>
                    <td>{r.pTrdSymbol}</td><td>{r.pSymbolName}</td><td>{r.pSymbol}</td><td>{r.lLotSize ?? "--"}</td>
                    <td><button type="button" onClick={() => getQuote(r)}>Quote</button>{" "}<button type="button" onClick={() => subscribe(r)}>Subscribe</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {quote && <pre className="raw-json">{quote.symbol}: {JSON.stringify(quote.data, null, 2)}</pre>}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Live ticks</h3></div>
        {tickRows.length === 0 ? (
          <EmptyState title="No live ticks" hint="Connect the broker and subscribe an instrument. Ticks only flow while the market is open." icon="globe" />
        ) : (
          <table className="data-table">
            <thead><tr><th>Symbol</th><th>Token</th><th>Exchange</th><th>LTP</th><th>Close</th><th>Volume</th><th>Updated (UTC)</th></tr></thead>
            <tbody>
              {tickRows.map((t) => (
                <tr key={t.exchange_segment + t.instrument_token}>
                  <td>{t.trading_symbol || "--"}</td><td>{t.instrument_token}</td><td>{t.exchange_segment || "--"}</td>
                  <td>{fmt(t.last_traded_price)}</td><td>{fmt(t.close_price)}</td><td>{t.volume ?? "--"}</td><td>{t.last_tick_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Subscriptions</h3></div>
        {subRows.length === 0 ? <EmptyState title="Nothing subscribed" icon="globe" /> : (
          <table className="data-table">
            <thead><tr><th>Exchange</th><th>Token</th><th></th></tr></thead>
            <tbody>{subRows.map((s) => (
              <tr key={s.exchange_segment + s.instrument_token}><td>{s.exchange_segment}</td><td>{s.instrument_token}</td>
                <td><button type="button" onClick={() => unsubscribe(s)}>Unsubscribe</button></td></tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </div>
  );
}
