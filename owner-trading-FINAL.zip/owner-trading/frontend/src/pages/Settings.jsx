import { useEffect, useState } from "react";
import { api } from "../api/client";
import "./Settings.css";

const STATUS_LABELS = {
  CONNECTED: "Connected",
  VERIFYING: "Verifying…",
  RECONNECTING: "Reconnecting…",
  RECONCILING: "Reconciling…",
  AUTH_FAILED: "Authentication Failed",
  SESSION_EXPIRED: "Session Expired",
  CONNECTION_ERROR: "Connection Error",
  DISCONNECTED: "Disconnected",
  NOT_CONFIGURED: "Not Configured",
};

const STATUS_SEVERITY = {
  CONNECTED: "ok",
  VERIFYING: "warn",
  RECONNECTING: "warn",
  RECONCILING: "warn",
  AUTH_FAILED: "error",
  SESSION_EXPIRED: "error",
  CONNECTION_ERROR: "error",
  DISCONNECTED: "neutral",
  NOT_CONFIGURED: "neutral",
};

const EMPTY_FORM = {
  accountLabel: "",
  consumerKey: "",
  mobileNumber: "",
  ucc: "",
  mpin: "",
  totpSecret: "",
};

export default function Settings() {
  const [account, setAccount] = useState(null);
  const [status, setStatus] = useState(null);
  const [credsConfigured, setCredsConfigured] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [busy, setBusy] = useState(null); // "save" | "test" | "connect" | "disconnect" | "reconnect" | null
  const [message, setMessage] = useState(null); // { kind: "success"|"error", text }

  async function refresh() {
    const [accountsRes, statusRes, credsStatusRes] = await Promise.all([
      api.getBrokerAccounts(),
      api.getBrokerStatus(),
      api.getKotakCredentialsStatus(),
    ]);
    if (accountsRes.ok && accountsRes.body?.accounts?.length) {
      const acc = accountsRes.body.accounts[0];
      setAccount(acc);
      setForm((f) => ({ ...f, accountLabel: acc.account_label || "" }));
    }
    if (statusRes.ok && statusRes.body) {
      setStatus(statusRes.body.state);
    }
    if (credsStatusRes.ok && credsStatusRes.body) {
      setCredsConfigured(!!credsStatusRes.body.configured);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  function updateField(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setBusy("save");
    setMessage(null);

    // Account label is metadata (stored in SQLite); credentials go through
    // a separate call and are never stored by Express itself.
    const accountRes = await api.saveBrokerAccount(form.accountLabel);
    const credsRes = await api.saveKotakCredentials({
      consumerKey: form.consumerKey,
      mobileNumber: form.mobileNumber,
      ucc: form.ucc,
      mpin: form.mpin,
      totpSecret: form.totpSecret,
    });

    setBusy(null);
    if (accountRes.ok && credsRes.ok) {
      setMessage({ kind: "success", text: "Saved. Credentials are held in memory by the broker service." });
      // Never re-populate secret fields from a response -- clear them so
      // nothing sensitive lingers in the DOM/state longer than necessary.
      setForm((f) => ({ ...f, consumerKey: "", mobileNumber: "", ucc: "", mpin: "", totpSecret: "" }));
      refresh();
    } else {
      setMessage({ kind: "error", text: credsRes.body?.error || accountRes.body?.error || "Save failed." });
    }
  }

  async function handleAction(action, apiCall) {
    setBusy(action);
    setMessage(null);
    const res = await apiCall();
    setBusy(null);

    if (!res.ok) {
      setMessage({ kind: "error", text: res.body?.error || "Request failed." });
      return;
    }

    if (action === "test") {
      setMessage(
        res.body.success
          ? { kind: "success", text: "Test succeeded — credentials are valid and a session was established, then closed." }
          : { kind: "error", text: res.body.error || "Test failed." }
      );
    } else {
      setStatus(res.body.state);
      setMessage(
        res.body.state === "CONNECTED"
          ? { kind: "success", text: "Connected." }
          : { kind: "error", text: res.body.lastError || `Broker state: ${res.body.state}` }
      );
    }
  }

  const severity = status ? STATUS_SEVERITY[status] || "neutral" : "neutral";
  const label = status ? STATUS_LABELS[status] || status : "—";

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Settings</h2>
        <p className="page__subtitle">Manage application settings.</p>
      </div>

      <div className="card">
        <div className="card__head">
          <h3 className="card__title">Broker — Kotak Neo</h3>
          <span className={`status-pill status-pill--${severity}`}>
            <span className="status-pill__dot" />
            {label}
          </span>
        </div>

        <div className="settings-grid">
          <div className="settings-field">
            <label htmlFor="environment">Environment</label>
            <input id="environment" value="prod" disabled />
          </div>
          <div className="settings-field">
            <label htmlFor="accountLabel">Account Label</label>
            <input
              id="accountLabel"
              placeholder="e.g. My Kotak Account"
              value={form.accountLabel}
              onChange={(e) => updateField("accountLabel", e.target.value)}
            />
          </div>
        </div>

        <h4 className="settings-subhead">Credentials</h4>
        <p className="settings-note">
          Credentials are held in memory by the broker service only — never written to disk, logged, or
          returned by any API response. Fields below are cleared after every save.
          {credsConfigured && <strong> Credentials are currently saved for this session.</strong>}
        </p>

        <form onSubmit={handleSave}>
          <div className="settings-grid">
            <div className="settings-field">
              <label htmlFor="consumerKey">Consumer Key</label>
              <input
                id="consumerKey"
                type="password"
                autoComplete="off"
                value={form.consumerKey}
                onChange={(e) => updateField("consumerKey", e.target.value)}
              />
            </div>
            <div className="settings-field">
              <label htmlFor="mobileNumber">Mobile Number</label>
              <input
                id="mobileNumber"
                type="tel"
                autoComplete="off"
                placeholder="10 digits"
                value={form.mobileNumber}
                onChange={(e) => updateField("mobileNumber", e.target.value)}
              />
            </div>
            <div className="settings-field">
              <label htmlFor="ucc">UCC / Client Code</label>
              <input
                id="ucc"
                autoComplete="off"
                value={form.ucc}
                onChange={(e) => updateField("ucc", e.target.value)}
              />
            </div>
            <div className="settings-field">
              <label htmlFor="mpin">MPIN</label>
              <input
                id="mpin"
                type="password"
                autoComplete="off"
                placeholder="4-6 digits"
                value={form.mpin}
                onChange={(e) => updateField("mpin", e.target.value)}
              />
            </div>
            <div className="settings-field settings-field--wide">
              <label htmlFor="totpSecret">TOTP Secret</label>
              <input
                id="totpSecret"
                type="password"
                autoComplete="off"
                placeholder="Setup key from your authenticator app"
                value={form.totpSecret}
                onChange={(e) => updateField("totpSecret", e.target.value)}
              />
              <span className="settings-hint">
                The setup key, not a 6-digit code — used to generate a fresh code at each connection attempt.
              </span>
            </div>
          </div>

          {message && (
            <div className={`settings-message settings-message--${message.kind}`} role="alert">
              {message.text}
            </div>
          )}

          <div className="settings-actions">
            <button type="submit" className="btn btn--primary" disabled={busy !== null}>
              {busy === "save" ? "Saving…" : "Save"}
            </button>
            <button
              type="button"
              className="btn btn--secondary"
              disabled={busy !== null}
              onClick={() => handleAction("test", api.testKotakConnection)}
            >
              {busy === "test" ? "Testing…" : "Test Connection"}
            </button>
            <button
              type="button"
              className="btn btn--secondary"
              disabled={busy !== null}
              onClick={() => handleAction("connect", api.connectKotak)}
            >
              {busy === "connect" ? "Connecting…" : "Connect"}
            </button>
            <button
              type="button"
              className="btn btn--danger-outline"
              disabled={busy !== null}
              onClick={() => handleAction("disconnect", api.disconnectKotak)}
            >
              {busy === "disconnect" ? "Disconnecting…" : "Disconnect"}
            </button>
            <button
              type="button"
              className="btn btn--secondary"
              disabled={busy !== null}
              onClick={() => handleAction("reconnect", api.reconnectKotak)}
            >
              {busy === "reconnect" ? "Reconnecting…" : "Reconnect"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
