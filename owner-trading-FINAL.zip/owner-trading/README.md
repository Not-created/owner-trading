# Owner Trading

Private trading console for one owner: React frontend, Express backend, and a Python **broker service that
talks to Kotak Neo only through the official `kotakneoapi` SDK v3.0.7** (vendored, integrity-checked).
Two modes: **PAPER** (simulated locally, never calls Kotak) and **LIVE** (real orders, behind several gates).

```
Browser ──HTTP/HTTPS──▶ nginx ──▶ Express (:4000) ──X-Internal-Token──▶ broker-service (:8800, loopback)
                                     │                                      │
                                     └────── shared SQLite DB ──────────────┴──▶ official Kotak Neo SDK ──▶ Kotak
```

| Part | Where | Notes |
|---|---|---|
| Frontend | `frontend/` | React + Vite; same-origin relative `/api/...` calls with cookies |
| Backend | `backend/` | Express, `node:sqlite` (Node ≥ 22.5), session login, proxies to the broker service |
| Broker service | `broker-service/` | asyncio HTTP server; `app/sdk_adapter.py` is the **only** module that imports the SDK |
| Official SDK | `broker-service/vendor/kotakneoapi/` | v3.0.7, byte-identical to the official source; `VENDOR_MANIFEST.sha256` |
| Deployment | `deploy.sh`, `deployment/` | systemd units, nginx (HTTP + optional HTTPS), mode switch, smoke test |

## Deploy (Ubuntu VPS, as root)

```bash
sudo ./deploy.sh                                                            # PAPER, HTTP via nginx on port 80
sudo DOMAIN=trade.example.com CERTBOT_EMAIL=you@example.com ./deploy.sh     # + HTTPS (Let's Encrypt)
sudo deployment/verify-deployment.sh                                        # smoke test
```

`deploy.sh` verifies the vendored SDK, installs it, checks the installed version and method signatures, runs the
broker-service and backend tests, migrates the DB, builds the frontend, starts systemd services, configures nginx,
and finally performs a **real login/session check** (cookie attributes, authenticated API call, logout).
It never touches Kotak credentials and never enables LIVE.

### HTTP and HTTPS
Both work; neither is forced. See [docs/HTTP_HTTPS.md](docs/HTTP_HTTPS.md).
`SESSION_COOKIE_SECURE=auto` (default) gives a **Secure** session cookie on HTTPS requests and a plain one on HTTP.

## PAPER → LIVE

1. Settings page → enter Kotak credentials → **Test** → **Connect** (real `totp_login` → `totp_validate` → read-only `limits()` check).
2. `sudo deployment/set-mode.sh LIVE` (sets `TRADING_MODE=LIVE` and `SESSION_COOKIE_SECURE=true` in both env files, starts disarmed).
3. Risk page: set order/loss limits; every readiness check must pass; then **Arm LIVE trading** (typed confirmation).
4. Emergency stop blocks all LIVE order paths at any time. See [docs/LIVE_READINESS.md](docs/LIVE_READINESS.md) for what is and is **not** verified.

## Development

```bash
cd broker-service && python3 -m unittest discover -s tests -t .     # stdlib only, no pytest
cd backend && npm install && npm test                                # node:test (incl. real-Express session e2e)
cd frontend && npm install && npm run build
```

## Security notes
* Access password: bcrypt hash only (`backend/src/data/secure/`, gitignored); Kotak credentials live in broker-service memory only.
* Express → broker-service calls carry `X-Internal-Token` (mandatory for LIVE); the broker service listens on loopback only.
* Session cookie: HttpOnly, SameSite=Lax, Secure per `SESSION_COOKIE_SECURE`. Session store is in-memory (sessions end on restart).
* nginx: rate-limited login, security headers, secret paths denied. No HSTS by design (HTTP stays usable).
