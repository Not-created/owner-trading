"""Static cross-layer contract: frontend api client -> Express routes ->
brokerClient.js -> Python broker-service ROUTES. Catches a renamed/missing
endpoint anywhere in the chain without needing Express, Vite or a network."""
import os
import re
import unittest

from app import server

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as fh:
        return fh.read()


def express_routes():
    """[(METHOD, '/api/...')] from app.js mounts + router.<verb>('/x') declarations."""
    app = read("backend", "src", "app.js")
    var_to_file = dict(re.findall(r'const (\w+) = require\("\./routes/(\w+)"\)', app))
    mounts = re.findall(r'app\.use\("(/api[^"]*)", (\w+)\)', app)
    out = []
    for prefix, var in mounts:
        f = var_to_file.get(var)
        if not f:
            continue
        src = read("backend", "src", "routes", f + ".js")
        for verb, path in re.findall(r'router\.(get|post)\(\s*"([^"]*)"', src):
            out.append((verb.upper(), (prefix.rstrip("/") + ("" if path == "/" else path)) or "/"))
    return out


def norm(path):
    return re.sub(r"\?.*$", "", re.sub(r"\$\{[^}]*\}.*$", "", path)).rstrip("/") or "/"


class ContractTests(unittest.TestCase):
    def test_every_frontend_call_has_an_express_route(self):
        client = read("frontend", "src", "api", "client.js")
        calls = []
        for m in re.finditer(r'request\(\s*[`"](/api/[^`"?$]*)(?=[`"?])[^`"]*[`"]\s*,\s*\{\s*method:\s*"(GET|POST)"', client):
            calls.append((m.group(2), norm(m.group(1))))
        self.assertGreater(len(calls), 25)
        routes = set(express_routes())
        for method, path in calls:
            self.assertIn((method, path), routes, f"frontend calls {method} {path} but Express has no such route")

    def test_every_express_broker_call_exists_in_python_service(self):
        bc = read("backend", "src", "services", "brokerClient.js")
        found = []
        for m in re.finditer(r'_(post|get)ToBroker\(\s*[`"](/[^`"?$]*)', bc):
            found.append((m.group(1).upper(), m.group(2)))
        for m in re.finditer(r'_(post|get)ToBroker\(`(/[a-z\-/]+)\$\{', bc):
            found.append((m.group(1).upper(), m.group(2)))
        for m in re.finditer(r'_getFromBroker\(`(/[a-z\-/]+)', bc):
            found.append(("GET", m.group(1)))
        self.assertGreater(len(found), 20)
        py = set(server.ROUTES) | {("GET", "/health")}
        for method, path in set(found):
            self.assertIn((method, path), py, f"brokerClient.js calls {method} {path}; broker-service has no such route")

    def test_no_legacy_fields_anywhere_in_ui_or_express(self):
        for rel in (("frontend", "src"), ("backend", "src")):
            for dp, _, fs in os.walk(os.path.join(ROOT, *rel)):
                for f in fs:
                    if f.endswith((".js", ".jsx")):
                        with open(os.path.join(dp, f), encoding="utf-8") as fh:
                            txt = fh.read()
                        self.assertFalse("broker_params" in txt, f"{f}: legacy broker_params")
                        self.assertFalse("brokerParams" in txt, f"{f}: legacy brokerParams")

    def test_frontend_state_names_cover_every_python_state(self):
        from app.state import BrokerState
        for rel in ("components/common/BrokerStatusBadge.jsx", "pages/Settings.jsx"):
            src = read("frontend", "src", *rel.split("/"))
            for s in BrokerState:
                self.assertIn(s.value, src, f"{rel} lacks state {s.value}")
        js = read("backend", "src", "services", "brokerState.js")
        for s in BrokerState:
            self.assertIn(s.value, js, f"brokerState.js lacks {s.value}")

    def test_order_field_names_match_between_ui_express_and_python(self):
        fields = ["trading_symbol", "exchange_segment", "transaction_type", "order_type", "product", "validity",
                  "quantity", "price", "trigger_price", "instrument_token", "idempotency_key"]
        orders_js = read("backend", "src", "routes", "orders.js")
        ui = read("frontend", "src", "pages", "Orders.jsx")
        from app import order_service
        py = open(order_service.__file__, encoding="utf-8").read()
        for f in fields:
            self.assertIn(f'"{f}"', orders_js, f"Express drops {f}")
            self.assertIn(f, ui, f"UI never sends {f}")
            self.assertIn(f, py, f"Python never reads {f}")

    def test_ui_enum_values_match_sdk_enums(self):
        from app import sdk_adapter as a
        ui = read("frontend", "src", "pages", "Orders.jsx") + read("frontend", "src", "lib", "format.js")
        for v in a.EXCHANGE_SEGMENTS + a.PRODUCTS + a.ORDER_TYPES:
            self.assertIn(v, ui, f"UI lacks SDK value {v}")


if __name__ == "__main__":
    unittest.main()


class IsolationTests(unittest.TestCase):
    """Static proof that PAPER can never reach Kotak and only order_service/main use the simulator."""

    APP = os.path.join(os.path.dirname(__file__), "..", "app")

    def imports_of(self, fname):
        import ast
        with open(os.path.join(self.APP, fname), encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        mods = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom):
                if n.level:
                    mods.add(n.module or "")
                    mods.update(a.name for a in n.names)
                elif n.module:
                    mods.add(n.module)
            elif isinstance(n, ast.Import):
                mods.update(a.name for a in n.names)
        return mods

    def test_paper_engine_cannot_import_any_broker_module(self):
        m = self.imports_of("paper_engine.py") | self.imports_of("market_prices.py")
        for banned in ("broker_client", "sdk_adapter", "neo_api_client", "websocket_manager", "reconciliation", "order_sync"):
            self.assertNotIn(banned, m)

    def test_only_sdk_adapter_and_conformance_touch_the_sdk_package(self):
        for f in os.listdir(self.APP):
            if f.endswith(".py") and f not in ("sdk_adapter.py",):
                with open(os.path.join(self.APP, f), encoding="utf-8") as fh:
                    src = fh.read()
                self.assertFalse("import neo_api_client" in src or "from neo_api_client" in src, f"{f} imports the SDK directly")

    def test_simulator_only_used_by_order_service_and_main(self):
        for f in os.listdir(self.APP):
            if f.endswith(".py") and f not in ("paper_engine.py", "order_service.py", "main.py"):
                self.assertNotIn("paper_engine", self.imports_of(f), f"{f} imports the simulator")

    def test_no_legacy_websocket_api_in_service_code(self):
        for f in os.listdir(self.APP):
            if f.endswith(".py"):
                with open(os.path.join(self.APP, f), encoding="utf-8") as fh:
                    src = fh.read()
                for legacy in ("un_subscribe(", "subscribe_to_orderfeed", "NeoWebSocket", "on_close =", "on_open ="):
                    self.assertFalse(legacy in src, f"{f} uses legacy WebSocket API: {legacy}")
