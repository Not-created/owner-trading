"""Session owner for the official Kotak Neo SDK (v3.0.7).

This module owns exactly one authenticated `KotakSdk` (see sdk_adapter.py,
the only module that imports `neo_api_client`) for the process lifetime and
drives the state machine. It contains NO legacy v2 calls, NO guessed
parameter names and NO simulator: PAPER trading never reaches this module
(see order_service.py), and every method here talks to the real SDK.

Authentication runs only when /connect or /test is explicitly invoked --
never on startup. CONNECTED is reported only after: totp_login OK ->
totp_validate OK -> a Trade session (edit_token + edit_sid) exists -> a
read-only limits() call is accepted by the broker.
"""
from __future__ import annotations

import asyncio
import logging

from . import sdk_adapter
from .config import config
from .sdk_adapter import AUTH, UNKNOWN, KotakSdk, Outcome
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.broker_client")


class NotConfiguredError(RuntimeError):
    """No usable broker session. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """A state-changing broker call was attempted while LIVE is not allowed.
    Enforced here independently of the Express middleware (defence in depth)."""


def sdk_ready() -> tuple[bool, str]:
    """(ok, reason). The official SDK must import AND be the pinned version."""
    if not sdk_adapter.SDK_AVAILABLE:
        return False, f"Official kotakneoapi SDK is not importable: {sdk_adapter.SDK_IMPORT_ERROR}"
    v = sdk_adapter.SDK_VERSION
    if v is not None and v != sdk_adapter.REQUIRED_SDK_VERSION:
        return False, f"Installed SDK is {v}; this service is built and verified against {sdk_adapter.REQUIRED_SDK_VERSION}."
    return True, ""


def assert_live_trading_allowed() -> None:
    """Independent Python-side LIVE gate for place/modify/cancel."""
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("TRADING_MODE is not LIVE on this deployment.")
    if _db.is_emergency_stop_active():
        raise LiveTradingBlockedError("Emergency stop is active.")
    if current_state.state != BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")
    if not _db.is_live_armed():
        raise LiveTradingBlockedError("LIVE trading has not been armed by the owner (Risk page).")


class BrokerClient:
    def __init__(self) -> None:
        self._sdk: KotakSdk | None = None
        # connect/test/disconnect/reconnect are serialised: two overlapping
        # requests must never race on the SDK session or state machine.
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ #
    # Session
    # ------------------------------------------------------------------ #
    def is_connected(self) -> bool:
        return self._sdk is not None and current_state.state in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        )

    @property
    def sdk(self) -> KotakSdk | None:
        return self._sdk

    async def _login(self) -> tuple[Outcome, KotakSdk | None]:
        from .credential_manager import credential_manager

        ok, reason = sdk_ready()
        if not ok:
            return Outcome(UNKNOWN, message=reason, code="SDK"), None
        creds = credential_manager.get()
        if not credential_manager.has_base_credentials() or creds is None:
            return Outcome("REJECTED", message="Credentials have not been saved yet.", code="NOT_CONFIGURED"), None
        totp = credential_manager.current_totp_code()
        if not totp:
            return Outcome("REJECTED", message="Could not generate a TOTP code (no secret saved or pyotp unavailable).", code="TOTP"), None
        loop = asyncio.get_running_loop()
        try:
            sdk = KotakSdk(creds.consumer_key, config.environment)
            outcome = await loop.run_in_executor(
                None, lambda: sdk.login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp, mpin=creds.mpin)
            )
        except Exception as exc:  # noqa: BLE001 -- transport/SDK failure is a connection error, not a rejection
            return Outcome(UNKNOWN, message=f"login failed: {type(exc).__name__}", code="TRANSPORT"), None
        if not outcome.ok:
            return outcome, None
        # Read-only verification: the broker must accept the new session.
        try:
            verify = await loop.run_in_executor(None, sdk.limits)
        except Exception as exc:  # noqa: BLE001
            return Outcome(UNKNOWN, message=f"read-only verification (limits) failed: {type(exc).__name__}", code="TRANSPORT"), None
        if not verify.ok:
            return Outcome("REJECTED", message=f"Session established but limits() was not accepted: {verify.message}"), None
        return outcome, sdk

    async def connect(self) -> dict:
        async with self._lock:
            return await self._connect_locked()

    async def _connect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session
        from .credential_manager import credential_manager

        if not credential_manager.has_base_credentials():
            current_state.transition(BrokerState.NOT_CONFIGURED, "Credentials have not been saved yet.")
            return current_state.as_dict()
        current_state.transition(BrokerState.VERIFYING)
        outcome, sdk = await self._login()
        if sdk is None:
            self._sdk = None
            target = BrokerState.CONNECTION_ERROR if outcome.kind == UNKNOWN else BrokerState.AUTH_FAILED
            current_state.transition(target, (outcome.message or "Authentication failed.")[:300])
            return current_state.as_dict()

        self._sdk = sdk
        dc = sdk.data_center()
        _session.mark_session_established(dc)
        _db.record_reconciliation(
            reconciliation_type="connect", reference_id=credential_manager.get().ucc,
            discrepancy_found=False, details={"data_center": dc, "verification_call": "limits"},
        )
        # Best-effort layers on top of an already-verified REST session.
        try:
            from . import reconciliation as _reconciliation
            await _reconciliation.run_full_reconciliation()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Post-connect reconciliation failed (state remains CONNECTED): %s", exc)
        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.start()
        except Exception as exc:  # noqa: BLE001
            logger.warning("WebSocket start failed after connect (REST-only): %s", exc)
        return current_state.as_dict()

    async def test_connection(self) -> dict:
        async with self._lock:
            outcome, sdk = await self._login()
            if sdk is not None:
                try:
                    await asyncio.get_running_loop().run_in_executor(None, sdk.logout)
                except Exception:  # noqa: BLE001 -- test result already known
                    pass
                return {"success": True}
            return {"success": False, "error": (outcome.message or "Test failed.")[:300]}

    async def disconnect(self) -> dict:
        async with self._lock:
            return await self._disconnect_locked()

    async def _disconnect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session

        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.stop()
        except Exception:  # noqa: BLE001
            pass
        if self._sdk is not None:
            try:
                await asyncio.get_running_loop().run_in_executor(None, self._sdk.logout)
            except Exception:  # noqa: BLE001
                pass
        self._sdk = None
        _session.current_session.established_at = None
        try:
            _db.record_session_ended()
        except Exception:  # noqa: BLE001
            pass
        current_state.transition(BrokerState.DISCONNECTED)
        return current_state.as_dict()

    async def reconnect(self) -> dict:
        async with self._lock:
            await self._disconnect_locked()
            return await self._connect_locked()

    # ------------------------------------------------------------------ #
    # Calls (synchronous; run in an executor by callers)
    # ------------------------------------------------------------------ #
    def _require_connected(self) -> KotakSdk:
        if self._sdk is None or current_state.state not in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        ):
            raise NotConfiguredError(f"Broker is not connected (state: {current_state.state.value}).")
        return self._sdk

    def _after(self, outcome: Outcome) -> Outcome:
        """A broker answer that says the session is invalid downgrades our
        state immediately instead of waiting for a TTL guess."""
        if outcome.kind == AUTH and current_state.state in (BrokerState.CONNECTED, BrokerState.RECONCILING):
            from . import session as _session
            logger.warning("Broker reported an invalid/absent session; marking SESSION_EXPIRED.")
            _session.mark_session_expired()
        return outcome

    def read(self, method: str, *args, **kwargs) -> Outcome:
        """Read-only SDK call by adapter method name."""
        allowed = {
            "order_report", "order_history", "trade_report", "positions", "holdings", "limits",
            "margin_required", "quotes", "scrip_master", "search_scrip", "whatsmyip",
        }
        if method not in allowed:
            raise ValueError(f"{method} is not a permitted read call.")
        return self._after(getattr(self._require_connected(), method)(*args, **kwargs))

    def place_order(self, req: sdk_adapter.OrderRequest) -> Outcome:
        assert_live_trading_allowed()
        return self._after(self._require_connected().place_order(req))

    def modify_order(self, **kwargs) -> Outcome:
        assert_live_trading_allowed()
        return self._after(self._require_connected().modify_order(**kwargs))

    def cancel_order(self, **kwargs) -> Outcome:
        assert_live_trading_allowed()
        return self._after(self._require_connected().cancel_order(**kwargs))

    def create_market_feed(self, **kwargs):
        return self._require_connected().create_market_feed(**kwargs)

    def create_order_feed(self, **kwargs):
        return self._require_connected().create_order_feed(**kwargs)


broker_client = BrokerClient()
