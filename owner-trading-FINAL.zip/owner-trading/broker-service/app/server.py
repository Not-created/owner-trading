"""Broker-service HTTP interface (localhost only, called by Express).

Minimal asyncio HTTP server (no framework). Every state-changing or
data-returning route requires the shared secret header
`X-Internal-Token` == BROKER_SERVICE_TOKEN (mandatory when TRADING_MODE=LIVE;
enforced at startup by main.py). /health is open for systemd/nginx probes.

Routes
  GET  /health                       liveness
  GET  /status                       state machine + websocket + SDK info
  GET  /credentials/status | POST /credentials
  POST /test | /connect | /disconnect | /reconnect
  GET  /funds | /positions | /holdings        latest snapshots (?refresh=1 forces a broker fetch)
  GET  /orders?limit=&mode=  POST /orders  POST /orders/modify  POST /orders/cancel
  GET  /trades?mode=         GET /order-history?internal_order_id=
  POST /quotes {instruments:[{exchange_segment,instrument_token}], quote_type?}
  POST /scrip-search {exchange_segment, symbol, expiry?, option_type?, strike_price?}
  GET  /market-ticks  GET /subscriptions  POST /subscribe  POST /unsubscribe
  GET  /pnl                          realised/unrealised, PAPER and LIVE kept separate
  GET|POST /risk-settings            limits + POST /risk/arm-live | /risk/disarm-live
  GET  /live-readiness               gate evaluation
  POST /reconcile                    force a reconciliation pass
  GET  /audit-logs
Credential / request bodies are never logged.
"""
from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
from urllib.parse import parse_qs, urlsplit

from .config import config
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.server")

MAX_BODY_BYTES = 8192
_STATUS_TEXT = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
                405: "Method Not Allowed", 409: "Conflict", 423: "Locked", 500: "Internal Server Error", 502: "Bad Gateway"}


def _json_response(status_code: int, payload: dict) -> bytes:
    body = json.dumps(payload, default=str).encode("utf-8")
    head = (f"HTTP/1.1 {status_code} {_STATUS_TEXT.get(status_code, 'Error')}\r\n"
            f"Content-Type: application/json\r\nContent-Length: {len(body)}\r\nConnection: close\r\n\r\n")
    return head.encode("utf-8") + body


async def _read_headers(reader: asyncio.StreamReader) -> dict:
    headers: dict = {}
    while True:
        line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not line or line in (b"\r\n", b"\n"):
            break
        if b":" in line:
            name, _, value = line.partition(b":")
            headers[name.decode("latin-1").strip().lower()] = value.decode("latin-1").strip()
    return headers


async def _read_json_body(reader: asyncio.StreamReader, headers: dict) -> dict:
    length = int(headers.get("content-length", "0") or "0")
    if length <= 0:
        return {}
    if length > MAX_BODY_BYTES:
        raise ValueError("Request body too large.")
    raw = await asyncio.wait_for(reader.readexactly(length), timeout=10)
    parsed = json.loads(raw.decode("utf-8")) if raw else {}
    if not isinstance(parsed, dict):
        raise ValueError("Request body must be a JSON object.")
    return parsed


def _token_ok(headers: dict) -> bool:
    expected = os.environ.get("BROKER_SERVICE_TOKEN", "")
    if not expected:
        return config.trading_mode != "LIVE"   # PAPER dev without a token is allowed; LIVE never is
    return hmac.compare_digest(headers.get("x-internal-token", ""), expected)


def _connected_or_409():
    if current_state.state != BrokerState.CONNECTED:
        return 409, {"error": f"Broker is not connected (state: {current_state.state.value})."}
    return None


def _int(q: dict, key: str, default: int) -> int:
    try:
        return int(q.get(key, [str(default)])[0])
    except ValueError:
        return default


# ---------------------------------------------------------------- handlers
async def h_status(q, b):
    from . import sdk_adapter
    from .websocket_manager import websocket_manager
    from .broker_client import broker_client
    d = current_state.as_dict()
    d.update({
        "tradingMode": config.trading_mode,
        "sdk": {"available": sdk_adapter.SDK_AVAILABLE, "version": sdk_adapter.SDK_VERSION, "required": sdk_adapter.REQUIRED_SDK_VERSION},
        "session": broker_client.sdk.session_summary() if broker_client.sdk else None,
        "websocket": websocket_manager.status(),
    })
    return 200, d


async def h_cred_status(q, b):
    from .credential_manager import credential_manager
    return 200, credential_manager.masked_summary()


async def h_cred_set(q, b):
    from .credential_manager import CredentialFormatError, credential_manager
    for f in ("consumerKey", "mobileNumber", "ucc", "mpin", "totpSecret"):
        if not b.get(f):
            return 400, {"error": f"Missing required field: {f}"}
    try:
        credential_manager.set(consumer_key=b["consumerKey"], mobile_number=b["mobileNumber"], ucc=b["ucc"],
                               mpin=b["mpin"], totp_secret=b["totpSecret"])
    except CredentialFormatError as exc:
        return 400, {"error": str(exc)}
    if current_state.state == BrokerState.NOT_CONFIGURED:
        current_state.transition(BrokerState.DISCONNECTED)
    return 200, {"success": True}


def _session_route(name):
    async def h(q, b):
        from .broker_client import broker_client
        return 200, await getattr(broker_client, name)()
    return h


def _snapshot_route(which):
    async def h(q, b):
        from . import db as _db
        from . import reconciliation
        if q.get("refresh", ["0"])[0] == "1":
            blocked = _connected_or_409()
            if blocked:
                return blocked
            await reconciliation.run_full_reconciliation()
        fn = {"funds": _db.latest_funds_snapshot, "positions": _db.latest_positions_snapshot, "holdings": _db.latest_holdings_snapshot}[which]
        return 200, {which: fn()}
    return h


async def h_orders_list(q, b):
    from . import db as _db
    return 200, {"orders": _db.list_orders(limit=_int(q, "limit", 200), mode=(q.get("mode", [None])[0]))}


async def _order_call(fn, *args):
    from . import order_service
    from .broker_client import LiveTradingBlockedError, NotConfiguredError
    try:
        return 200, await fn(*args)
    except order_service.OrderValidationError as exc:
        return 400, {"error": str(exc)}
    except (LiveTradingBlockedError, NotConfiguredError) as exc:
        return 409, {"error": str(exc)}


async def h_order_place(q, b):
    from . import order_service
    b.pop("broker_params", None)   # legacy field: ignored, never forwarded anywhere
    return await _order_call(order_service.place_order, b)


async def h_order_modify(q, b):
    from . import order_service
    if not b.get("internal_order_id"):
        return 400, {"error": "internal_order_id is required."}
    return await _order_call(order_service.modify_order, b["internal_order_id"], b)


async def h_order_cancel(q, b):
    from . import order_service
    if not b.get("internal_order_id"):
        return 400, {"error": "internal_order_id is required."}
    return await _order_call(order_service.cancel_order, b["internal_order_id"])


async def h_trades(q, b):
    from . import db as _db
    return 200, {"trades": _db.list_trades(mode=q.get("mode", [None])[0], limit=_int(q, "limit", 1000))}


async def h_order_history(q, b):
    from . import db as _db
    from .broker_client import NotConfiguredError, broker_client
    from .sdk_adapter import rows_of
    blocked = _connected_or_409()
    if blocked:
        return blocked
    o = _db.get_order(q.get("internal_order_id", [""])[0])
    if o is None or not o["broker_order_id"]:
        return 400, {"error": "Unknown order, or it has no broker order id."}
    try:
        out = await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("order_history", o["broker_order_id"]))
    except NotConfiguredError as exc:
        return 409, {"error": str(exc)}
    if not out.ok:
        return 502, {"error": out.message}
    return 200, {"history": rows_of(out)}


async def h_quotes(q, b):
    from .broker_client import NotConfiguredError, broker_client
    from . import sdk_adapter
    blocked = _connected_or_409()
    if blocked:
        return blocked
    ins = b.get("instruments")
    if not isinstance(ins, list) or not ins or len(ins) > 50:
        return 400, {"error": "instruments must be a list of 1-50 {exchange_segment, instrument_token}."}
    try:
        pairs = []
        for i in ins:
            seg, tok = i.get("exchange_segment"), i.get("instrument_token")
            if seg not in sdk_adapter.EXCHANGE_SEGMENTS or not tok:
                return 400, {"error": "each instrument needs a valid exchange_segment and instrument_token."}
            pairs.append((seg, str(tok)))
        out = await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("quotes", pairs, b.get("quote_type")))
    except NotConfiguredError as exc:
        return 409, {"error": str(exc)}
    return (200, {"data": out.data}) if out.ok else (502, {"error": out.message})


async def h_scrip_search(q, b):
    from .broker_client import NotConfiguredError, broker_client
    from . import sdk_adapter
    blocked = _connected_or_409()
    if blocked:
        return blocked
    seg = b.get("exchange_segment")
    if seg not in sdk_adapter.EXCHANGE_SEGMENTS:
        return 400, {"error": f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}."}
    kw = {k: (str(b[k]) if b.get(k) not in (None, "") else None) for k in ("expiry", "option_type", "strike_price")}
    try:
        out = await asyncio.get_running_loop().run_in_executor(
            None, lambda: broker_client.read("search_scrip", exchange_segment=seg, symbol=str(b.get("symbol") or ""), **kw))
    except NotConfiguredError as exc:
        return 409, {"error": str(exc)}
    return (200, {"data": out.data}) if out.ok else (502, {"error": out.message})


async def h_ticks(q, b):
    from . import db as _db
    return 200, {"ticks": _db.latest_market_ticks(limit=_int(q, "limit", 200))}


async def h_subscriptions(q, b):
    from .websocket_manager import websocket_manager
    return 200, {"subscriptions": websocket_manager.subscriptions()}


def _sub_route(action):
    async def h(q, b):
        from .websocket_manager import websocket_manager
        blocked = _connected_or_409()
        if blocked:
            return blocked
        if not b.get("instrument_token"):
            return 400, {"error": "instrument_token is required."}
        try:
            await getattr(websocket_manager, action)(str(b.get("exchange_segment") or ""), str(b["instrument_token"]))
        except ValueError as exc:
            return 400, {"error": str(exc)}
        return 200, {"subscriptions": websocket_manager.subscriptions()}
    return h


async def h_pnl(q, b):
    from . import db as _db
    from . import pnl
    ticks = _db.latest_market_ticks(limit=1000)
    by_token = {(t["exchange_segment"], t["instrument_token"]): t["last_traded_price"] for t in ticks if t["last_traded_price"] is not None}
    by_symbol = {(t["exchange_segment"], t["trading_symbol"]): t["last_traded_price"] for t in ticks
                 if t.get("trading_symbol") and t["last_traded_price"] is not None}
    live = pnl.aggregate(_db.latest_positions_snapshot(), by_token)
    funds = _db.latest_funds_snapshot() or {}
    paper_pos = pnl.simulate_fills_to_positions(_db.list_trades(mode="PAPER", limit=5000))
    for p in paper_pos:
        p["instrument_token"] = p["trading_symbol"]
    paper = pnl.aggregate(paper_pos, {k: v for k, v in by_symbol.items()})
    return 200, {
        "live": {**live, "broker_reported": {"realized_mtom": funds.get("realized_mtom"), "unrealized_mtom": funds.get("unrealized_mtom"),
                                             "as_of": funds.get("snapshot_at")}},
        "paper": paper,
        "note": "PAPER and LIVE are separate ledgers. 'complete': false means at least one open position has no live price.",
    }


async def h_risk_get(q, b):
    from . import db as _db
    return 200, {"risk": _db.get_risk_settings()}


async def h_risk_set(q, b):
    from . import db as _db
    vals = {}
    for k in ("max_order_quantity", "max_orders_per_day", "max_open_positions"):
        if k in b:
            v = b[k]
            if v in (None, "", 0):
                vals[k] = None
            elif isinstance(v, int) and not isinstance(v, bool) and v > 0:
                vals[k] = v
            else:
                return 400, {"error": f"{k} must be a positive integer or null."}
    for k in ("max_order_value", "max_daily_loss"):
        if k in b:
            v = b[k]
            if v in (None, "", 0):
                vals[k] = None
            elif isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
                vals[k] = float(v)
            else:
                return 400, {"error": f"{k} must be a positive number or null."}
    _db.write_audit_log(actor="owner", action="risk.settings_updated", details=vals)
    return 200, {"risk": _db.set_risk_settings(vals)}


async def h_arm(q, b):
    from . import db as _db
    from . import live_readiness
    if config.trading_mode != "LIVE":
        return 409, {"error": "TRADING_MODE is not LIVE on this deployment."}
    if b.get("confirm") != "ARM LIVE TRADING":
        return 400, {"error": "Send {\"confirm\": \"ARM LIVE TRADING\"} to arm."}
    r = live_readiness.evaluate()
    if not r["ready"]:
        return 409, {"error": "LIVE readiness gates are failing; cannot arm.", "readiness": r}
    _db.set_live_armed(True)
    _db.write_audit_log(actor="owner", action="live.armed", details=None)
    return 200, {"armed": True}


async def h_disarm(q, b):
    from . import db as _db
    _db.set_live_armed(False)
    _db.write_audit_log(actor="owner", action="live.disarmed", details=None)
    return 200, {"armed": False}


async def h_readiness(q, b):
    from . import live_readiness
    return 200, live_readiness.evaluate()


async def h_reconcile(q, b):
    from . import reconciliation
    blocked = _connected_or_409()
    if blocked:
        return blocked
    return 200, await reconciliation.run_full_reconciliation()


async def h_audit(q, b):
    from . import db as _db
    return 200, {"logs": _db.list_audit_logs(limit=_int(q, "limit", 200))}


ROUTES = {
    ("GET", "/status"): h_status,
    ("GET", "/credentials/status"): h_cred_status, ("POST", "/credentials"): h_cred_set,
    ("POST", "/test"): _session_route("test_connection"), ("POST", "/connect"): _session_route("connect"),
    ("POST", "/disconnect"): _session_route("disconnect"), ("POST", "/reconnect"): _session_route("reconnect"),
    ("GET", "/funds"): _snapshot_route("funds"), ("GET", "/positions"): _snapshot_route("positions"),
    ("GET", "/holdings"): _snapshot_route("holdings"),
    ("GET", "/orders"): h_orders_list, ("POST", "/orders"): h_order_place,
    ("POST", "/orders/modify"): h_order_modify, ("POST", "/orders/cancel"): h_order_cancel,
    ("GET", "/trades"): h_trades, ("GET", "/order-history"): h_order_history,
    ("POST", "/quotes"): h_quotes, ("POST", "/scrip-search"): h_scrip_search,
    ("GET", "/market-ticks"): h_ticks, ("GET", "/subscriptions"): h_subscriptions,
    ("POST", "/subscribe"): _sub_route("subscribe"), ("POST", "/unsubscribe"): _sub_route("unsubscribe"),
    ("GET", "/pnl"): h_pnl,
    ("GET", "/risk-settings"): h_risk_get, ("POST", "/risk-settings"): h_risk_set,
    ("POST", "/risk/arm-live"): h_arm, ("POST", "/risk/disarm-live"): h_disarm,
    ("GET", "/live-readiness"): h_readiness, ("POST", "/reconcile"): h_reconcile,
    ("GET", "/audit-logs"): h_audit,
}


async def dispatch(method: str, path: str, query: dict, headers: dict, reader=None) -> bytes:
    if method == "GET" and path == "/health":
        return _json_response(200, {"status": "ok"})
    handler = ROUTES.get((method, path))
    if handler is None:
        known = any(p == path for (_, p) in ROUTES)
        return _json_response(405 if known else 404, {"error": "Method not allowed" if known else "Not found"})
    if not _token_ok(headers):
        return _json_response(401, {"error": "Missing or invalid internal token."})
    body: dict = {}
    if method == "POST":
        try:
            body = await _read_json_body(reader, headers) if reader is not None else {}
        except (ValueError, json.JSONDecodeError) as exc:
            return _json_response(400, {"error": str(exc)})
    status, payload = await handler(query, body)
    return _json_response(status, payload)


async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not request_line:
            return
        parts = request_line.decode("latin-1").strip().split(" ")
        method, raw_path = (parts[0], parts[1]) if len(parts) >= 2 else ("", "")
        split = urlsplit(raw_path)
        headers = await _read_headers(reader)
        writer.write(await dispatch(method, split.path, parse_qs(split.query), headers, reader))
        await writer.drain()
    except (asyncio.TimeoutError, ConnectionError) as exc:
        logger.debug("Client connection dropped: %s", exc)
    except Exception as exc:  # noqa: BLE001 -- never crash the server loop on a bad request
        logger.warning("Unhandled error serving request: %s: %s", type(exc).__name__, exc)
        try:
            writer.write(_json_response(500, {"error": "Internal server error."}))
            await writer.drain()
        except Exception:  # noqa: BLE001
            pass
    finally:
        writer.close()


async def run_server() -> None:
    server = await asyncio.start_server(_handle_client, config.host, config.port)
    addr = server.sockets[0].getsockname() if server.sockets else (config.host, config.port)
    logger.info("Broker service HTTP interface listening on %s:%s", *addr[:2])
    async with server:
        await server.serve_forever()
