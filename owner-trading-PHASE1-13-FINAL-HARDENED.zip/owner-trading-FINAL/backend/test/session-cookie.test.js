const test = require("node:test");
const assert = require("node:assert");
const { parseSessionCookieSecure, buildSessionCookieOptions } = require("../src/config/sessionCookie");
const { validateConfig, configWarnings } = require("../src/config/validate");

test("default and blank resolve to auto", () => {
  for (const raw of [undefined, null, "", "  ", "auto", "AUTO"]) assert.deepStrictEqual(parseSessionCookieSecure(raw), { value: "auto", valid: true });
});
test("explicit true/false spellings", () => {
  for (const raw of ["true", "TRUE", "1", "yes", "on"]) assert.strictEqual(parseSessionCookieSecure(raw).value, true);
  for (const raw of ["false", "FALSE", "0", "no", "off"]) assert.strictEqual(parseSessionCookieSecure(raw).value, false);
});
test("garbage is flagged invalid (and never silently treated as insecure)", () => {
  const r = parseSessionCookieSecure("maybe");
  assert.strictEqual(r.valid, false);
  assert.strictEqual(r.value, "auto");
});
test("cookie options: httpOnly and SameSite=lax are fixed, lifetime preserved", () => {
  for (const s of ["auto", "true", "false"]) {
    const o = buildSessionCookieOptions({ sessionCookieSecure: s, sessionMaxAgeMs: 43200000 });
    assert.strictEqual(o.httpOnly, true);
    assert.strictEqual(o.sameSite, "lax");
    assert.strictEqual(o.maxAge, 43200000);
  }
  assert.strictEqual(buildSessionCookieOptions({ sessionCookieSecure: "true", sessionMaxAgeMs: 1 }).secure, "auto");
  assert.strictEqual(buildSessionCookieOptions({ sessionCookieSecure: "true", sessionMaxAgeMs: 1 }).secure, true);
  assert.strictEqual(buildSessionCookieOptions({ sessionCookieSecure: "false", sessionMaxAgeMs: 1 }).secure, false);
});
test("production no longer hard-wires secure:true -- auto is the default even in production", () => {
  const cfg = require("../src/config");
  assert.ok(["auto", "true", "false"].includes(String(cfg.sessionCookieSecure).toLowerCase()));
  assert.strictEqual(buildSessionCookieOptions({ env: "production", sessionMaxAgeMs: 1 }).secure, "auto");
});

const base = { env: "production", sessionSecret: "x".repeat(40), tradingMode: "LIVE", brokerServiceToken: "", brokerServiceUrl: "http://127.0.0.1:8800", sessionCookieSecure: "true" };
test("LIVE production accepts auto, true and false", () => {
  for (const s of ["auto", "true", "false"]) assert.deepStrictEqual(validateConfig({ ...base, sessionCookieSecure: s }), []);
});
test("invalid SESSION_COOKIE_SECURE is a startup error", () => {
  assert.ok(validateConfig({ ...base, sessionCookieSecure: "sometimes" }).some((p) => /SESSION_COOKIE_SECURE/.test(p)));
});
test("LIVE requires SESSION_COOKIE_SECURE=true", () => {
  const live = { ...base, tradingMode: "LIVE", brokerServiceToken: "t".repeat(32) };
  assert.ok(validateConfig({ ...live, sessionCookieSecure: "true" }).some((p) => /SESSION_COOKIE_SECURE=true/.test(p)));
  assert.ok(validateConfig({ ...live, sessionCookieSecure: "false" }).some((p) => /SESSION_COOKIE_SECURE=true/.test(p)));
  assert.deepStrictEqual(validateConfig({ ...live, sessionCookieSecure: "true" }), []);
});
test("startup advisories for auto/false in production only", () => {
  assert.strictEqual(configWarnings({ ...base, sessionCookieSecure: "true" }).length, 1);
  assert.strictEqual(configWarnings({ ...base, sessionCookieSecure: "false" }).length, 1);
  assert.strictEqual(configWarnings({ ...base, sessionCookieSecure: "true" }).length, 0);
  assert.strictEqual(configWarnings({ ...base, env: "development", sessionCookieSecure: "false" }).length, 0);
});
