"""Continuous strategy-specific universe scanning and candidate management.

A scanner match is never an order signal by itself. It creates a durable
(strategy_version, instrument) candidate, acquires a logical LIVE-feed owner,
and lets the strategy engine perform the complete entry/risk/readiness chain.
"""
from __future__ import annotations

import datetime as dt
import logging
from zoneinfo import ZoneInfo
from . import db, strategy_engine
from .websocket_manager import websocket_manager

logger = logging.getLogger("owner_trading.scanner")
IST = ZoneInfo("Asia/Kolkata")
MAX_UNIVERSE = 3000
DEFAULT_CANDIDATE_TTL_BARS = 3


def _expiry_for(timeframe: str, definition: dict) -> str:
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 5))
    bars = int(definition.get("candidate_ttl_bars") or DEFAULT_CANDIDATE_TTL_BARS)
    bars = max(1, min(bars, 20))
    when = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=minutes * bars)
    return when.strftime("%Y-%m-%d %H:%M:%S")


def _scanner_universe(scanner: dict, fallback: list[dict]) -> list[dict]:
    definition=scanner.get("definition") or {}
    universe=definition.get("universe") if isinstance(definition,dict) else None
    tokens=[]
    if isinstance(universe,dict):
        tokens=[str(x).strip() for x in (universe.get("instrument_tokens") or []) if str(x).strip()]
    if not tokens:
        return fallback
    out=[]
    for tok in dict.fromkeys(tokens[:MAX_UNIVERSE]):
        inst=db.get_instrument("nse_cm",tok)
        if inst: out.append(inst)
    return out


def _candle_is_fresh(candle_at: str, timeframe: str) -> bool:
    try:
        raw=str(candle_at).replace("Z","+")
        stamp=dt.datetime.fromisoformat(raw)
        # Stored candle_at values are naive NSE (IST) wall-clock times, exactly as the candle
        # engine and historical loader write them -- NOT UTC. Reading them as UTC put every
        # candle 5.5h in the future and made the scanner treat all of them as stale.
        if stamp.tzinfo is None: stamp=stamp.replace(tzinfo=IST).astimezone(dt.timezone.utc)
        else: stamp=stamp.astimezone(dt.timezone.utc)
        minutes=int(strategy_engine.TIMEFRAMES.get(timeframe,5))
        age=(dt.datetime.now(dt.timezone.utc)-stamp).total_seconds()
        # Scanner works on completed candles. Intraday bars must be recent; a
        # daily bar may legitimately be the previous completed trading day.
        max_age=72*3600 if minutes>=1440 else max(3*minutes*60, 180)
        return 0 <= age <= max_age
    except (TypeError,ValueError,OverflowError):
        return False


def _scan(universe: list[dict], definition: dict, timeframe: str) -> list[dict]:
    candle_map = db.recent_candles_for_instruments(universe, timeframe, 250)
    matched = []
    for instrument in universe:
        candles = candle_map.get((instrument["exchange_segment"], str(instrument["instrument_token"])), [])
        if len(candles) < 20 or not _candle_is_fresh(candles[-1].get("candle_at"), timeframe):
            continue
        passed, detail = strategy_engine.evaluate_entry(definition, candles)
        if passed:
            matched.append({"instrument": instrument, "price": candles[-1]["close"], "details": detail})
    return matched


async def ensure_scanner_market_universe(limit: int = MAX_UNIVERSE) -> dict:
    """Keep the scanner's broad market feed alive without making it a strategy feed."""
    universe = db.list_instruments(max(1, min(int(limit or MAX_UNIVERSE), MAX_UNIVERSE)))
    keys=[("nse_cm",str(x["instrument_token"])) for x in universe if str(x.get("instrument_token") or "").strip()]
    if not keys:
        return {"universe": 0, "subscribed": 0, "error": "No NSE instruments are available. Sync Market Data first."}
    try:
        result=await websocket_manager.ensure_owner_subscriptions(keys, owner="scanner-universe")
        return {"universe":len(keys),"subscribed":int(result.get("added") or 0),"total":result.get("total")}
    except Exception as exc:
        return {"universe":len(keys),"subscribed":0,"error":f"Scanner market-feed subscription failed: {type(exc).__name__}: {exc}"}


async def run(payload: dict) -> dict:
    """Manual scanner run. It remains analysis-only unless a strategy version is supplied."""
    definition = payload.get("definition") or {}
    if not isinstance(definition, dict):
        return {"error": "definition must be an object", "results": [], "scanned": 0, "matched": 0}
    errors = strategy_engine.validate_strategy(definition)
    if errors:
        return {"error": "Invalid scanner definition", "validation_errors": errors, "results": [], "scanned": 0, "matched": 0}
    timeframe = str(payload.get("timeframe") or definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"error": "Unsupported scanner timeframe.", "results": [], "scanned": 0, "matched": 0}
    try:
        limit = max(1, min(int(payload.get("limit") or MAX_UNIVERSE), MAX_UNIVERSE))
    except (TypeError, ValueError):
        return {"error": "limit must be an integer.", "results": [], "scanned": 0, "matched": 0}
    universe = db.list_instruments(limit)
    matched = _scan(universe, definition, timeframe)
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    return {"results": matched, "scanned": len(universe), "matched": len(matched), "timeframe": timeframe}


async def run_for_strategy(strategy_version_id: int, scanner_id: int, scanner: dict, universe: list[dict]) -> dict:
    """Run one scanner only for the strategy that explicitly references it."""
    definition=scanner.get("definition") or {}
    errors=strategy_engine.validate_strategy(definition)
    if errors:
        logger.warning("Skipping invalid scanner %s: %s", scanner_id, errors)
        return {"matched":0,"scanned":len(universe),"errors":errors}
    timeframe=str(definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"matched":0,"scanned":len(universe),"errors":["unsupported scanner timeframe"]}
    matches=_scan(_scanner_universe(scanner, universe),definition,timeframe)
    ttl=_expiry_for(timeframe,definition)
    for item in matches:
        inst=item["instrument"]; tok=str(inst["instrument_token"]); seg=str(inst["exchange_segment"])
        candidate=db.upsert_strategy_candidate(
            strategy_version_id=strategy_version_id,scanner_id=int(scanner_id),exchange_segment=seg,
            instrument_token=tok,trading_symbol=inst.get("trading_symbol"),timeframe=timeframe,
            matched_price=float(item["price"]),conditions=item["details"],expires_at=ttl,
        )
        owner=f"strategy:{strategy_version_id}:candidate:{seg}:{tok}"
        try:
            await websocket_manager.subscribe(seg,tok,owner=owner)
            db.mark_strategy_candidate_subscribed(candidate["id"],True)
        except Exception as exc:
            db.mark_strategy_candidate_subscribed(candidate["id"],False,error=f"{type(exc).__name__}: {exc}")
            logger.warning("Candidate subscription failed for strategy=%s token=%s: %s",strategy_version_id,tok,exc)
    return {"matched":len(matches),"scanned":len(universe),"timeframe":timeframe}


async def cleanup_expired_candidates() -> int:
    """Expire candidate rows and release only the corresponding strategy owners."""
    before=db.list_strategy_candidates(active_only=True,limit=10000)
    db.expire_strategy_candidates()
    removed=0
    for c in before:
        if not db.has_active_candidate(strategy_version_id=c["strategy_version_id"], exchange_segment=c["exchange_segment"], instrument_token=c["instrument_token"]):
            owner=f"strategy:{c['strategy_version_id']}:candidate:{c['exchange_segment']}:{c['instrument_token']}"
            removed += await websocket_manager.release_owner(owner)
    return removed


async def run_continuous_cycle() -> dict:
    """Run only scanners referenced by currently LIVE-armed strategies."""
    active=[]
    scanner_by_id={s["id"]:s for s in db.list_scanners() if s.get("is_active")}
    for item in db.list_live_armed_strategy_versions():
        for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
            try: sid=int(raw_id)
            except (TypeError,ValueError): continue
            scanner=scanner_by_id.get(sid)
            if scanner: active.append((int(item["id"]),sid,scanner))
    if not active:
        # No active scanner is currently allowed to drive any armed strategy.
        # Immediately stop existing candidate owners instead of waiting for TTL.
        for item in db.list_live_armed_strategy_versions():
            vid=int(item["id"])
            if (item.get("definition") or {}).get("scanner_ids"):
                for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
                db.deactivate_strategy_candidates(vid)
        await websocket_manager.release_owner("scanner-universe")
        return {"strategies":0,"scanners":0,"matched":0,"universe":0}
    # Deactivate candidates belonging to scanners that are no longer active or
    # no longer referenced by their owning strategy.
    active_by_strategy={}
    for vid,sid,_scanner in active:
        active_by_strategy.setdefault(vid,set()).add(sid)
    for item in db.list_live_armed_strategy_versions():
        vid=int(item["id"]); configured=[int(x) for x in (item.get("definition") or {}).get("scanner_ids") or [] if str(x).isdigit()]
        if configured:
            allowed=active_by_strategy.get(vid,set())
            for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                if int(c["scanner_id"]) not in allowed:
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
            db.deactivate_strategy_candidates_for_scanners(vid,list(allowed))
    market=await ensure_scanner_market_universe(MAX_UNIVERSE)
    universe=db.list_instruments(MAX_UNIVERSE)
    matched=0
    for vid,sid,scanner in active:
        result=await run_for_strategy(vid,sid,scanner,universe)
        matched += int(result.get("matched") or 0)
    removed=await cleanup_expired_candidates()
    await websocket_manager.remove_if_unneeded()
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    return {"strategies":len({v for v,_,_ in active}),"scanners":len(active),"matched":matched,"universe":len(universe),"expired_unsubscribed":removed,"market":market}
