import datetime as dt
import os
import unittest
from unittest.mock import AsyncMock, patch

from app import notifications
from app.market_holidays import is_nse_equity_holiday
from app.market_session import session_state, mis_entry_allowed, mis_square_off_due
from tests.dbutil import fresh_db


class UnattendedSafetyTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        for key in ("TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"):
            os.environ.pop(key, None)

    def test_2026_nse_holiday_blocks_normal_session(self):
        now = dt.datetime(2026, 10, 20, 10, 0, tzinfo=dt.timezone.utc)  # 15:30 IST
        s = session_state(now)
        self.assertTrue(is_nse_equity_holiday(dt.date(2026, 10, 20)))
        self.assertFalse(s["open"])
        self.assertEqual(s["reason"], "NSE_HOLIDAY")
        self.assertFalse(mis_entry_allowed(now))

    def test_mis_entry_cutoff_and_squareoff_are_defense_in_depth(self):
        before = dt.datetime(2026, 10, 8, 9, 29, tzinfo=dt.timezone.utc)  # 14:59 IST
        cutoff = dt.datetime(2026, 10, 8, 9, 30, tzinfo=dt.timezone.utc)  # 15:00 IST
        after = dt.datetime(2026, 10, 8, 9, 45, tzinfo=dt.timezone.utc)   # 15:15 IST
        self.assertTrue(mis_entry_allowed(before))
        self.assertFalse(mis_entry_allowed(cutoff))
        self.assertTrue(mis_square_off_due(after))

    def test_readiness_requires_fresh_scrip_master(self):
        from app import live_readiness as lr
        from app.state import BrokerState, current_state
        current_state.transition(BrokerState.DISCONNECTED)
        os.environ["BROKER_SERVICE_TOKEN"] = "x" * 32
        result = lr.evaluate()
        gate = next(g for g in result["gates"] if g["id"] == "scrip_master_fresh")
        self.assertFalse(gate["ok"])
        os.environ.pop("BROKER_SERVICE_TOKEN", None)

    def test_order_service_rejects_new_mis_after_cutoff_but_exit_path_is_not_cutoff_blocked(self):
        from app import order_service
        payload = {
            "trading_symbol": "TEST-EQ", "exchange_segment": "nse_cm",
            "transaction_type": "B", "order_type": "MKT", "product": "MIS",
            "validity": "DAY", "quantity": 1, "instrument_token": "999999",
            "order_role": "ENTRY", "idempotency_key": "cutoff-test",
        }
        with patch("app.market_session.mis_entry_allowed", return_value=False):
            with self.assertRaises(order_service.OrderValidationError):
                order_service._validate(payload)
            # The cutoff is checked in _place_order_locked after payload
            # normalization; use a mocked normalized order to isolate that gate.
            with patch.object(order_service, "_validate", return_value={**payload, "order_role": "ENTRY"}), \
                 patch.object(order_service, "_check_risk_limits"), \
                 patch("app.market_session.mis_entry_allowed", return_value=False):
                with self.assertRaises(order_service.OrderValidationError):
                    import asyncio
                    asyncio.run(order_service._place_order_locked(payload))

    def test_telegram_is_disabled_without_real_credentials(self):
        self.assertFalse(notifications.configured())
        self.assertFalse(notifications.send("test", "no network call"))


if __name__ == "__main__":
    unittest.main()

class MisSquareOffTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        from app import db
        self.db = db
        strategy = db.create_strategy("mis-squareoff-test")
        definition = {
            "side": "BUY",
            "timeframe": "5m",
            "execution": {"product": "MIS"},
            "entry": {"conditions": [{"left": "close", "op": ">", "right": "0"}]},
            "risk": {"stop_loss_pct": 1},
            "position_sizing": {"quantity": 1},
            "universe": {"instrument_tokens": ["999999"]},
        }
        version = db.save_strategy_version(strategy["id"], definition, "LIVE_RUNNING", [])
        db.bulk_upsert_instruments([{
            "trading_symbol": "TEST-EQ", "instrument_token": "999999", "name": "Test",
            "instrument_type": "EQ", "lot_size": 1, "tick_size": 0.01,
        }])
        self.position_id = db.ensure_algo_position(
            exchange_segment="nse_cm", instrument_token="999999", trading_symbol="TEST-EQ",
            strategy_version_id=version["id"], entry_order_id="entry-1", quantity=1,
            average_entry=100.0, stop_loss=99.0, target=102.0,
        )

    async def test_failed_squareoff_remains_retryable(self):
        from app import exit_engine
        from app.market_session import mis_square_off_due
        with patch("app.market_session.mis_square_off_due", return_value=True), \
             patch.object(exit_engine.order_service, "place_order", new=AsyncMock(return_value={"status": "REJECTED"})):
            result = await exit_engine.force_square_off_mis_positions()
        self.assertEqual(result["failed"], 1)
        self.assertEqual(result["remaining"], 1)
        self.assertTrue(self.db.has_pending_exit(self.position_id) is False)
