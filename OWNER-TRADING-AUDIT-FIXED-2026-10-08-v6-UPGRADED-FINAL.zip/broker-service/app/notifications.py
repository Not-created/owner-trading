"""Optional real Telegram Bot API notifications for unattended LIVE trading.

Notifications never create, modify, cancel, simulate, or authorize orders.
If credentials are absent, alerts are simply disabled. Network failures are
contained so an alert outage cannot break the trading engine.
"""
from __future__ import annotations
import hashlib, json, logging, time, urllib.parse, urllib.request
from .config import config

logger = logging.getLogger("owner_trading.notifications")
_last_sent: dict[str, float] = {}


def configured() -> bool:
    return bool(config.telegram_bot_token and config.telegram_chat_id)


def send(event: str, message: str, *, cooldown: int | None = None, force: bool = False) -> bool:
    if not configured():
        return False
    text = str(message).strip()
    if not text:
        return False
    wait = config.telegram_alert_cooldown_seconds if cooldown is None else max(0, int(cooldown))
    key = f"{event}:{hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]}"
    now = time.monotonic()
    if not force and wait and now - _last_sent.get(key, -1e18) < wait:
        return False
    payload = urllib.parse.urlencode({"chat_id": config.telegram_chat_id, "text": text}).encode()
    url = f"https://api.telegram.org/bot{config.telegram_bot_token}/sendMessage"
    try:
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=10) as response:
            body = json.loads(response.read().decode("utf-8"))
        if not body.get("ok"):
            raise RuntimeError(str(body)[:300])
        _last_sent[key] = now
        return True
    except Exception as exc:
        logger.warning("Telegram alert failed for %s: %s", event, type(exc).__name__)
        return False


def system(message: str, *, force: bool = False) -> bool:
    return send("system", f"OWNER TRADING\n{message}", force=force)


def trade(message: str) -> bool:
    return send("trade", f"OWNER TRADING\n{message}", cooldown=5)


def critical(event: str, message: str) -> bool:
    return send(event, f"🚨 OWNER TRADING\n{message}", cooldown=300)
