"""NSE cash-market holidays for the current production calendar.

The 2026 equity dates are taken from NSE India's published 2026 equities
calendar. Unknown future years fail closed in the session helper rather than
silently assuming a weekday is tradable.
"""
from __future__ import annotations
from datetime import date

NSE_EQUITY_HOLIDAYS = {
    2026: frozenset({
        date(2026, 1, 15), date(2026, 1, 26), date(2026, 3, 3), date(2026, 3, 26),
        date(2026, 3, 31), date(2026, 4, 3), date(2026, 4, 14), date(2026, 5, 1),
        date(2026, 5, 28), date(2026, 6, 26), date(2026, 9, 14), date(2026, 10, 2),
        date(2026, 10, 20), date(2026, 11, 10), date(2026, 11, 24), date(2026, 12, 25),
    }),
}


def is_nse_equity_holiday(day: date) -> bool:
    return day in NSE_EQUITY_HOLIDAYS.get(day.year, frozenset())


def calendar_supported(day: date) -> bool:
    return day.year in NSE_EQUITY_HOLIDAYS
