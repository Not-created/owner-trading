"""NSE cash-market session and unattended MIS timing gates."""
from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo
from .config import config
from .market_holidays import calendar_supported, is_nse_equity_holiday

IST = ZoneInfo("Asia/Kolkata")
OPEN = dt.time(9, 15)
CLOSE = dt.time(15, 30)


def _clock(value: str, fallback: dt.time) -> dt.time:
    try:
        h, m = [int(x) for x in str(value).split(":", 1)]
        if 0 <= h <= 23 and 0 <= m <= 59:
            return dt.time(h, m)
    except (TypeError, ValueError):
        pass
    return fallback


def mis_entry_cutoff() -> dt.time:
    return _clock(config.mis_entry_cutoff, dt.time(15, 0))


def mis_square_off_time() -> dt.time:
    return _clock(config.mis_square_off_time, dt.time(15, 15))


def premarket_window() -> tuple[dt.time, dt.time]:
    return _clock(config.premarket_start, dt.time(8, 15)), _clock(config.premarket_end, dt.time(9, 10))


def session_state(now: dt.datetime | None = None) -> dict:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    weekday = local.weekday() < 5
    supported = calendar_supported(local.date())
    holiday = is_nse_equity_holiday(local.date())
    in_hours = OPEN <= local.time().replace(tzinfo=None) < CLOSE
    open_ = bool(weekday and supported and not holiday and in_hours)
    if not weekday:
        reason = "WEEKEND"
    elif not supported:
        reason = "HOLIDAY_CALENDAR_UNSUPPORTED"
    elif holiday:
        reason = "NSE_HOLIDAY"
    elif in_hours:
        reason = "OPEN"
    else:
        reason = "OUTSIDE_SESSION"
    return {
        "open": open_, "timezone": "Asia/Kolkata", "local_time": local.isoformat(),
        "weekday": weekday, "holiday": holiday, "calendar_supported": supported,
        "continuous_session": "09:15-15:30",
        "mis_entry_cutoff": mis_entry_cutoff().strftime("%H:%M"),
        "mis_square_off_time": mis_square_off_time().strftime("%H:%M"),
        "reason": reason,
    }


def mis_entry_allowed(now: dt.datetime | None = None) -> bool:
    s = session_state(now)
    if not s["open"]:
        return False
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    return local.time().replace(tzinfo=None) < mis_entry_cutoff()


def mis_square_off_due(now: dt.datetime | None = None) -> bool:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    return bool(local.weekday() < 5 and calendar_supported(local.date()) and not is_nse_equity_holiday(local.date()) and local.time().replace(tzinfo=None) >= mis_square_off_time())


def in_premarket_window(now: dt.datetime | None = None) -> bool:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    start, end = premarket_window()
    return bool(local.weekday() < 5 and calendar_supported(local.date()) and not is_nse_equity_holiday(local.date()) and start <= local.time().replace(tzinfo=None) < end)


def before_regular_open(now: dt.datetime | None = None) -> bool:
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    return bool(local.weekday() < 5 and calendar_supported(local.date()) and not is_nse_equity_holiday(local.date()) and local.time().replace(tzinfo=None) < OPEN)
