"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express. When encrypted credentials are already present, the
service uses the same verified connect path on startup and after a detected
session expiry; no credentials means no broker login attempt.
"""
from __future__ import annotations

import asyncio
import logging
import signal
import time

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")

# BUGFIX (final audit): session.check_and_handle_expiry() and
# reconciliation.run_full_reconciliation() were both fully implemented but
# never invoked from anywhere -- dead code. Session expiry would never be
# detected until the next broker call happened to fail, and reconciliation
# never ran on any schedule (only once, right after a successful connect,
# per the fix in broker_client.py). This loop is what actually makes both
# real: it polls every SESSION_CHECK_INTERVAL_SECONDS while the service is
# up, regardless of connection state (check_and_handle_expiry() itself is a
# no-op unless state is CONNECTED), and re-reconciles on the slower
# RECONCILIATION_INTERVAL_SECONDS cadence whenever still CONNECTED.
SESSION_CHECK_INTERVAL_SECONDS = 60
RECONCILIATION_INTERVAL_SECONDS = 15 * 60
SCANNER_CYCLE_INTERVAL_SECONDS = 30
AUTO_RECONNECT_RETRY_SECONDS = 5 * 60
UNATTENDED_RUNTIME_INTERVAL_SECONDS = 15


def _determine_initial_state() -> None:
    """Sets the starting state without inventing credentials. If saved credentials are recovered, main() may subsequently run the verified auto-connect lifecycle. LIVE refuses to start without the internal API token."""
    import os
    from . import sdk_adapter
    from .credential_manager import credential_manager

    if config.trading_mode == "LIVE" and not os.environ.get("BROKER_SERVICE_TOKEN"):
        raise SystemExit("LIVE execution requires BROKER_SERVICE_TOKEN to be set. Refusing to start.")

    if config.trading_mode == "LIVE" or sdk_adapter.SDK_AVAILABLE:
        from .broker_client import sdk_ready
        ok, reason = sdk_ready()
        if not ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, reason)
            logger.error(reason)
            return
        from .sdk_conformance import check_sdk_conformance
        conformance = check_sdk_conformance()
        if not conformance.ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, conformance.summary())
            logger.error(conformance.summary())
            return
        logger.info(conformance.summary())
    else:
        current_state.transition(BrokerState.CONNECTION_ERROR, f"Official SDK not importable: {sdk_adapter.SDK_IMPORT_ERROR}")
        logger.warning("Official SDK not importable -- broker service running in degraded mode.")
        return

    if config.is_fully_configured():
        credential_manager.set(consumer_key=config.consumer_key, mobile_number=config.mobile_number, ucc=config.ucc,
                               mpin=config.mpin, totp_secret=config.totp_secret)
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials loaded from protected environment. State: DISCONNECTED (startup lifecycle may authenticate automatically).")
    else:
        try:
            if credential_manager.load_persisted():
                current_state.transition(BrokerState.DISCONNECTED)
                logger.info("Encrypted Kotak credentials recovered. State: DISCONNECTED (startup lifecycle may authenticate automatically).")
            else:
                current_state.transition(BrokerState.NOT_CONFIGURED)
                logger.info("Kotak credentials are not configured. State: NOT_CONFIGURED.")
        except Exception as exc:
            current_state.transition(BrokerState.AUTH_FAILED, "Persisted credential store could not be loaded.")
            logger.error("Encrypted credential store load failed: %s", exc)


async def _auto_connect_on_startup() -> dict | None:
    """Authenticate once at service startup when encrypted credentials exist.
    This is deliberately a separate lifecycle function so it is easy to test
    without starting the HTTP server. No credentials means a strict no-op."""
    from .credential_manager import credential_manager

    if (not credential_manager.has_base_credentials() or current_state.state != BrokerState.DISCONNECTED
            or not credential_manager.startup_auto_connect_allowed()):
        return None
    try:
        result = await broker_client_module.broker_client.connect()
        if result.get("state") == BrokerState.CONNECTED.value:
            logger.info("Kotak broker authenticated automatically from saved credentials on service startup.")
        else:
            logger.warning("Kotak startup auto-connect did not connect: state=%s error=%s",
                           result.get("state"), result.get("last_error"))
        return result
    except Exception as exc:  # noqa: BLE001
        logger.warning("Kotak startup auto-connect failed: %s", exc)
        return {"state": BrokerState.CONNECTION_ERROR.value, "last_error": type(exc).__name__}


async def _background_scanner_loop(stop_event: asyncio.Event) -> None:
    """Continuously drive only scanner definitions referenced by LIVE strategies."""
    from . import scanner_engine
    from .market_session import session_state
    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=SCANNER_CYCLE_INTERVAL_SECONDS)
            break
        except asyncio.TimeoutError:
            pass
        try:
            if session_state()["open"]:
                result = await scanner_engine.run_continuous_cycle()
                logger.info("Scanner cycle: strategies=%s scanners=%s matched=%s universe=%s",
                            result.get("strategies", 0), result.get("scanners", 0),
                            result.get("matched", 0), result.get("universe", 0))
            else:
                await scanner_engine.cleanup_expired_candidates()
                await scanner_engine.websocket_manager.remove_if_unneeded()
        except Exception as exc:  # noqa: BLE001 -- scanner failure must not kill broker supervision
            logger.warning("Continuous scanner cycle failed: %s", exc)



async def _background_unattended_runtime_loop(stop_event: asyncio.Event) -> None:
    """Drive real daily preparation, MIS square-off, feed health and alerts.

    This loop never fabricates broker responses and never submits simulated
    orders. Every executable exit uses the existing production order_service.
    """
    from . import db, exit_engine, reconciliation, scanner_engine, universe
    from .market_session import before_regular_open, mis_square_off_due, session_state
    from .notifications import critical, system

    last_sync_date = None
    last_sync_attempt = 0.0
    last_prep_date = None
    last_prep_attempt = 0.0
    last_squareoff_date = None
    last_squareoff_attempt = 0.0
    last_summary_date = None
    previous_feed_state = None
    previous_order_feed_state = None

    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=UNATTENDED_RUNTIME_INTERVAL_SECONDS)
            break
        except asyncio.TimeoutError:
            pass

        try:
            session = session_state()
            today = session["local_time"][:10]
            connected = current_state.state == BrokerState.CONNECTED

            # Feed health transitions are useful operational alerts. They do not
            # change the existing fail-closed execution gates.
            try:
                from .websocket_manager import websocket_manager
                ws = websocket_manager.status()
                feed_state = (bool(ws["market"].get("connected")), bool(ws["market"].get("stale")))
                order_feed_state = bool(ws["orderFeed"].get("connected"))
                if previous_feed_state is not None and feed_state != previous_feed_state:
                    if not feed_state[0] or feed_state[1]:
                        critical("market_feed_unhealthy", "Market feed disconnected or stale; new LIVE entries remain blocked until healthy.")
                    elif previous_feed_state[0] is False or previous_feed_state[1] is True:
                        system("Market feed recovered and is receiving data.")
                if previous_order_feed_state is not None and order_feed_state != previous_order_feed_state:
                    if not order_feed_state:
                        critical("order_feed_unhealthy", "Order feed disconnected; broker reconciliation remains the source of truth.")
                    else:
                        system("Order feed recovered.")
                previous_feed_state = feed_state
                previous_order_feed_state = order_feed_state
            except Exception:
                pass

            # Daily metadata refresh. A successful full scrip-master import is
            # enough to satisfy the freshness gate for the trading date.
            if connected and session["calendar_supported"] and not session["holiday"]:
                metadata = db.scrip_master_status()
                age = metadata.get("age_seconds")
                needs_sync = (metadata.get("updated_at", "")[:10] != today) or age is None or age < 0 or age > float(config.scrip_master_max_age_hours) * 3600
                if needs_sync and last_sync_date != today and time.monotonic() - last_sync_attempt >= 300:
                    last_sync_attempt = time.monotonic()
                    result = await universe.sync_nse_cash_metadata()
                    if result.get("ok"):
                        last_sync_date = today
                        system(f"Daily NSE scrip master sync complete\nInstruments: {result.get('synced', 0)}")
                    else:
                        critical("scrip_sync_failed", "Daily NSE scrip master sync FAILED\n" + str(result.get("error") or "unknown error")[:450])

            # Prepare history before the first regular candle. If the service
            # starts late, do one bounded catch-up before/at the start of the
            # session instead of waiting for the first scanner cycle to discover
            # missing history.
            if connected and session["calendar_supported"] and not session["holiday"] and last_prep_date != today:
                prep_due = before_regular_open() or (session["open"] and session["local_time"][11:16] <= "09:25")
                if prep_due and time.monotonic() - last_prep_attempt >= 60:
                    last_prep_attempt = time.monotonic()
                    prep = await scanner_engine.prepare_live_strategy_history(time_budget=18.0, max_instruments=300)
                    if prep.get("remaining", 0) == 0 and not prep.get("failures"):
                        last_prep_date = today
                        system(f"Pre-market/catch-up history preparation READY\nPrepared: {prep.get('prepared', 0)}")
                    else:
                        critical("premarket_failed", "History preparation incomplete; affected LIVE entries will remain gated.\n" + "\n".join(prep.get("failures", [])[:3]) + ("\nRemaining: " + str(prep.get("remaining")) if prep.get("remaining") else ""))

            # Real MIS square-off. Do not mark the day complete until there are
            # no open MIS algo positions left. This means a rejected/unknown
            # square-off can be retried after reconciliation or reconnect.
            if mis_square_off_due() and last_squareoff_date != today and time.monotonic() - last_squareoff_attempt >= 60:
                if not connected:
                    critical("mis_squareoff_deferred", "MIS square-off time reached while Kotak is disconnected. Square-off will retry after verified reconnection.")
                else:
                    last_squareoff_attempt = time.monotonic()
                    result = await exit_engine.force_square_off_mis_positions()
                    if result.get("failed"):
                        critical("mis_squareoff_failed", f"MIS square-off has failures\nAttempted: {result.get('attempted')}\nSubmitted: {result.get('submitted')}\nFailed: {result.get('failed')}\nRemaining: {result.get('remaining')}")
                    # The helper counts open/pending MIS positions. Only a fully
                    # flat result is terminal for today's square-off supervisor.
                    if result.get("remaining", 0) == 0:
                        last_squareoff_date = today
                        system(f"MIS square-off supervisor complete\nAttempted: {result.get('attempted')}\nSubmitted: {result.get('submitted')}\nFailed: {result.get('failed')}")
                        try:
                            recon = await reconciliation.run_full_reconciliation()
                            if recon.get("discrepancies"):
                                critical("reconciliation_discrepancy", f"Post-square-off reconciliation found {len(recon.get('discrepancies') or [])} discrepancy(s).")
                        except Exception as exc:
                            critical("reconciliation_failed", f"Post-square-off reconciliation FAILED: {type(exc).__name__}")

            # Daily summary only after square-off has completed for the date.
            if last_squareoff_date == today and last_summary_date != today:
                orders = db.count_orders_today(mode="LIVE")
                rejected = db.count_rejected_orders_today()
                funds = db.latest_funds_snapshot() or {}
                parts = [f"Daily LIVE summary\nOrders: {orders}\nRejected: {rejected}"]
                if funds.get("realized_mtom") is not None:
                    parts.append(f"Broker realized MTM: ₹{float(funds['realized_mtom']):.2f}")
                if funds.get("unrealized_mtom") is not None:
                    parts.append(f"Broker unrealized MTM: ₹{float(funds['unrealized_mtom']):.2f}")
                system("\n".join(parts), force=True)
                last_summary_date = today
        except Exception as exc:
            logger.warning("Unattended runtime loop failed: %s", exc)
            try:
                critical("runtime_loop_failure", f"Unattended runtime supervisor error: {type(exc).__name__}")
            except Exception:
                pass


async def _background_maintenance_loop(stop_event: asyncio.Event) -> None:
    """Session-expiry detection, controlled broker recovery and scheduled
    reconciliation. A failed recovery never kills the maintenance loop."""
    from . import reconciliation as _reconciliation
    from . import session as _session
    from . import websocket_manager as _wsm
    from .credential_manager import credential_manager
    from .notifications import critical, system

    elapsed = 0
    retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
    recovery_pending = False
    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=SESSION_CHECK_INTERVAL_SECONDS)
            break
        except asyncio.TimeoutError:
            pass

        try:
            ttl_expired = _session.check_and_handle_expiry()
            broker_reported_expiry = current_state.state == BrokerState.SESSION_EXPIRED
            if ttl_expired or broker_reported_expiry:
                if not recovery_pending:
                    logger.warning("Broker session expired; scheduling verified automatic reconnect.")
                    critical("session_expired", "Kotak session expired. Automatic reconnect is being attempted; new entries remain gated until healthy.")
                    await _wsm.websocket_manager.stop()
                    recovery_pending = True
                    # Try once immediately. If Kotak rejects it, subsequent
                    # retries are spaced out to avoid an authentication storm.
                    retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
                    try:
                        result = await broker_client_module.broker_client.connect()
                        if result.get("state") == BrokerState.CONNECTED.value:
                            recovery_pending = False
                            logger.info("Broker session recovered automatically after expiry.")
                            system("Kotak broker session recovered automatically.")
                        else:
                            logger.warning("Automatic broker recovery did not connect: state=%s error=%s",
                                           result.get("state"), result.get("last_error"))
                            critical("session_recovery_failed", f"Automatic Kotak reconnect failed\nState: {result.get('state')}\nError: {str(result.get('last_error') or 'unknown')[:250]}")
                    except Exception as recovery_exc:  # noqa: BLE001
                        logger.warning("Immediate broker recovery attempt failed: %s", recovery_exc)
                        critical("session_recovery_failed", f"Immediate Kotak reconnect failed: {type(recovery_exc).__name__}")
        except Exception as exc:  # noqa: BLE001
            recovery_pending = True
            logger.warning("Session-expiry/recovery check failed: %s", exc)

        # An explicit owner Disconnect (or a fresh credential save) transitions
        # the service to DISCONNECTED. That must cancel any pending automatic
        # recovery so the service does not reconnect against the owner's intent.
        if current_state.state == BrokerState.DISCONNECTED:
            recovery_pending = False
            retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS

        if recovery_pending and credential_manager.has_base_credentials():
            retry_elapsed -= SESSION_CHECK_INTERVAL_SECONDS
            if retry_elapsed <= 0:
                retry_elapsed = AUTO_RECONNECT_RETRY_SECONDS
                try:
                    result = await broker_client_module.broker_client.connect()
                    if result.get("state") == BrokerState.CONNECTED.value:
                        recovery_pending = False
                        logger.info("Broker automatic recovery retry succeeded.")
                    else:
                        logger.warning("Broker automatic recovery retry failed: state=%s error=%s",
                                       result.get("state"), result.get("last_error"))
                        critical("session_recovery_failed", f"Automatic Kotak reconnect retry failed\nState: {result.get('state')}\nError: {str(result.get('last_error') or 'unknown')[:250]}")
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Broker automatic recovery retry failed: %s", exc)
                    critical("session_recovery_failed", f"Automatic Kotak reconnect retry failed: {type(exc).__name__}")

        elapsed += SESSION_CHECK_INTERVAL_SECONDS
        if elapsed >= RECONCILIATION_INTERVAL_SECONDS:
            elapsed = 0
            if current_state.state == BrokerState.CONNECTED:
                try:
                    result = await _reconciliation.run_full_reconciliation()
                    if result.get("discrepancies"):
                        critical("reconciliation_discrepancy", f"Scheduled broker reconciliation found {len(result.get('discrepancies') or [])} discrepancy(s).")
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Scheduled reconciliation failed: %s", exc)
                    critical("reconciliation_failed", f"Scheduled broker reconciliation FAILED: {type(exc).__name__}")


async def _main() -> None:
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    try:
        from . import db as _db_startup
        repaired = _db_startup.normalize_stored_candles()
        if repaired["normalized"] or repaired["duplicates_or_invalid_removed"]:
            logger.info("Candle cache repaired at startup: %s", repaired)
    except Exception as exc:  # noqa: BLE001 -- a cache repair failure must never stop supervision
        logger.warning("Candle cache normalisation skipped: %s", exc)
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())

    # Persistent-service recovery: only reconnect after an explicit prior owner
    # CONNECT. Credentials alone are never treated as owner intent.
    await _auto_connect_on_startup()

    maintenance_task = asyncio.create_task(_background_maintenance_loop(stop_event))
    scanner_task = asyncio.create_task(_background_scanner_loop(stop_event))
    unattended_task = asyncio.create_task(_background_unattended_runtime_loop(stop_event))

    await stop_event.wait()
    server_task.cancel()
    maintenance_task.cancel()
    scanner_task.cancel()
    unattended_task.cancel()
    for task in (server_task, maintenance_task, scanner_task, unattended_task):
        try:
            await task
        except asyncio.CancelledError:
            pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
