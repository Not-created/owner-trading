# Owner Trading — Upgrade 1+2+3 Final Bugfix / Re-audit

Date: 2026-10-08
Base: OWNER-TRADING-AUDIT-FIXED-2026-10-08-v6.zip

## Scope

Only unattended trading feature upgrades and their tests were changed. The deployment implementation was intentionally left untouched.

Deployment files were not edited:
- `deploy.sh`
- `deployment/` tree

The original `deploy.sh` SHA-256 remains:
`77f1eac3820e12ae32f2f299b87c98429fb053b9577b4d3ededbf131c8fd0f12`

No paper-trading, simulator, fake broker, dummy order path, or fake fill path was added to production code. Real exits continue through the existing `order_service` -> Kotak SDK path.

## Fixes / upgrades

### Upgrade 1 — unattended LIVE safety
- Final executable MIS entry cutoff (default 15:00 IST) added as defense-in-depth.
- Real MIS square-off supervisor (default 15:15 IST) uses the existing production order path and `order_role=EXIT`.
- Square-off is not considered complete until open/pending MIS algo positions are flat; rejected/failed exits remain retryable.
- Square-off retries are throttled to avoid duplicate/repeated real-money submissions.
- Existing protective SL/target/trailing/time-exit logic is preserved.
- Existing LIVE gates, idempotency, UNKNOWN reconciliation and emergency-stop behavior are preserved.

### Upgrade 2 — automatic preparation
- NSE 2026 equity holiday calendar integrated into the normal cash-session gate.
- Unknown calendar years fail closed rather than silently assuming a weekday is tradable.
- Daily NSE cash scrip-master refresh is automatic when connected and stale/missing.
- Freshness is enforced in LIVE readiness; stale metadata blocks new LIVE execution.
- Explicit strategy ARM can perform a metadata-only refresh when its explicit universe is stale/missing, without creating subscriptions.
- Pre-market/catch-up history warm-up runs automatically for armed strategies and is throttled on incomplete preparation.

### Upgrade 3 — real Telegram operations alerts
- Optional real Telegram Bot API notifications added; no credentials are bundled.
- Alerts cover broker/session recovery, feed health, scrip sync failure, preparation failure, order rejection/UNKNOWN outcome, broker-side order rejection, fills, MIS square-off failures, reconciliation failures/discrepancies, and daily LIVE summary.
- Alert cooldown/deduplication prevents repeated spam.
- Notification failures never alter or block the trading path.

## Route / architecture integrity

The existing Express -> persistent Python broker-service route contract was checked after the changes:
- brokerClient paths missing from broker-service: 0
- route contract: PASS

No new public broker architecture was introduced.

## Official Kotak SDK

The vendored SDK remains the official Kotak Neo Python SDK 3.0.7. The vendor manifest verifies cleanly. The package source under `neo_api_client/` was compared with the uploaded official SDK source: 47 common package files, 0 byte differences.

Kotak's official documentation states v3.x uses the `neo_api_client` import name, async/await SFeed, and strict canonical order parameters; production code continues to use the existing audited adapter rather than introducing a second SDK path.

## Validation

### Broker Python suite
- 429 passed
- 3 skipped
- 0 failed

The 3 skips are the existing systemd-related tests that cannot run in the packaging/container environment.

### Backend Node suite
- 34 tests
- 28 passed
- 0 failed
- 6 skipped

The 6 skips are the existing Express/session E2E tests because those npm runtime packages are not installed in this isolated packaging environment.

### Syntax / static checks
- Python syntax: 116 files, 0 errors
- Backend JS/MJS syntax: 36 files, 0 errors
- Shell syntax: PASS
- Kotak vendor manifest: PASS
- Official SDK package source comparison: PASS
- Broker route contract: PASS

### Not claimed
A fresh frontend Vite production build was not claimed because this environment does not contain `frontend/node_modules` and external npm installation was not completed. The frontend source was not changed in this feature set.

A real authenticated Kotak order/fill was not fabricated or claimed; that requires the user's live Kotak credentials/session and real market conditions.

## Production behavior

When the service is connected and the configured unattended controls are enabled, the flow remains real-money only:

market preparation -> scanner -> strategy -> risk/readiness gates -> real Kotak entry -> real fill -> existing protective exit engine -> real MIS square-off when due -> reconciliation -> Telegram operational reporting.

No guarantee of profit is implied by these execution/safety upgrades.
