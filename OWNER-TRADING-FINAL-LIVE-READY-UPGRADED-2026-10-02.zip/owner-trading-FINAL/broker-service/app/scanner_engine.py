from __future__ import annotations
from datetime import datetime, timezone
from . import db, strategy_engine


async def run(payload: dict) -> dict:
    definition = payload.get("definition") or {}
    if not isinstance(definition, dict):
        return {"error": "definition must be an object", "results": [], "scanned": 0, "matched": 0}
    errors = strategy_engine.validate_strategy(definition)
    if errors:
        return {"error": "Invalid scanner definition", "validation_errors": errors, "results": [], "scanned": 0, "matched": 0}
    timeframe = str(payload.get("timeframe") or definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"error": "Unsupported scanner timeframe.", "results": [], "scanned": 0, "matched": 0}
    try:
        limit = max(1, min(int(payload.get("limit") or 3000), 3000))
    except (TypeError, ValueError):
        return {"error": "limit must be an integer.", "results": [], "scanned": 0, "matched": 0}

    universe = db.list_instruments(limit)
    candle_map = db.recent_candles_for_instruments(universe, timeframe, 250)
    matched = []
    for instrument in universe:
        candles = candle_map.get((instrument["exchange_segment"], str(instrument["instrument_token"])), [])
        if len(candles) < 20:
            continue
        passed, detail = strategy_engine.evaluate_entry(definition, candles)
        if passed:
            matched.append({
                "instrument": instrument,
                "price": candles[-1]["close"],
                "details": detail,
            })

    db.set_algo_runtime(
        last_scan_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        universe_count=len(universe),
        status="RUNNING",
    )
    return {"results": matched, "scanned": len(universe), "matched": len(matched), "timeframe": timeframe}
