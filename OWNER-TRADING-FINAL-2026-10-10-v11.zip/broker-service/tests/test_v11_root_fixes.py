import asyncio
import datetime as dt
import json
import math
import os
import time
import unittest
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

from app import strategy_engine as se
from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")
FIX = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "test", "fixtures", "ma-definitions.json")


def fixture():
    with open(FIX, encoding="utf-8") as fh:
        return json.load(fh)


def bars(n, start=dt.datetime(2026, 9, 1, 9, 15), per_day=25, minutes=15, fmt="%Y-%m-%d %H:%M:%S"):
    out, p = [], 100.0
    for i in range(n):
        p += math.sin(i / 9) * 0.8 + 0.05 * math.sin(i / 3)
        day = start + dt.timedelta(days=i // per_day)
        ts = day + dt.timedelta(minutes=minutes * (i % per_day))
        out.append({"candle_at": ts.strftime(fmt), "open": p, "high": p + 0.4, "low": p - 0.4, "close": p, "volume": 1000 + i})
    return out


class CrossoverNeverCrashes(unittest.TestCase):
    def test_missing_previous_bar_indicator_is_not_a_crossover(self):
        d = {"entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"}]}}
        for n in range(2, 80):                                    # includes the exact bar where ema50 first exists
            passed, _ = se.evaluate_entry(d, bars(n))
            self.assertIn(passed, (True, False))
        passed, why = se.eval_condition({"left": "close", "operator": "cross_above", "right": "open"}, bars(1), se.indicators(bars(1)))
        self.assertFalse(passed)

    def test_every_builder_definition_backtests_without_error(self):
        if not os.path.exists(FIX):
            self.skipTest("fixture not present")
        data = bars(300)
        for name, d in fixture().items():
            r = se.run_backtest(data, dict(d, _available_funds=100000), "X", 1, 0.0005, 0.0, initial_capital=100000,
                                requested_from=data[0]["candle_at"][:10], requested_to=data[-1]["candle_at"][:10], cost_model={})
            self.assertIn("equity_curve", r, name)

    def test_backtest_time_grows_linearly_not_quadratically(self):
        data = bars(900)
        d = fixture()["buy_default"] if os.path.exists(FIX) else None
        if d is None:
            self.skipTest("fixture not present")
        t = time.time()
        se.run_backtest(data, dict(d, _available_funds=100000), "X", 1, 0, 0, initial_capital=100000,
                        requested_from=data[0]["candle_at"][:10], requested_to=data[-1]["candle_at"][:10], cost_model={})
        self.assertLess(time.time() - t, 15.0)                     # was ~10 s at 700 bars and minutes at 1500


class BacktestServiceEndToEnd(unittest.IsolatedAsyncioTestCase):
    async def test_run_merges_cache_and_broker_formats_and_does_not_block_the_loop(self):
        from app import backtest_service as bs
        db = fresh_db()
        raw = bars(400, start=dt.datetime(2026, 9, 1, 9, 15), fmt="%Y-%m-%dT%H:%M:%S+0530")      # Kotak style
        db.upsert_candles([dict(r, exchange_segment="nse_cm", instrument_token="11915", trading_symbol="YESBANK-EQ", timeframe="15m") for r in raw[:200]])
        fake = AsyncMock(return_value=(raw, {"chunk_count": 1, "chunks": []}))
        ticks = {"n": 0}

        async def heartbeat():
            while True:
                await asyncio.sleep(0.01); ticks["n"] += 1
        hb = asyncio.ensure_future(heartbeat())
        d = fixture()["buy_default"]
        with patch.object(bs, "_fetch_chunks", fake):
            status, body = await bs.run({"definition": d, "instrument_token": "11915", "trading_symbol": "YESBANK-EQ", "timeframe": "15m",
                                          "quantity": "1", "from_date": "2026-09-10", "to_date": "2026-09-20", "initial_capital": "100000",
                                          "slippage": "0.0005", "fees": "0", "cost_model": {}})
        hb.cancel()
        self.assertEqual(status, 200, body)
        res = body["result"]
        self.assertGreater(len(res["equity_curve"]), 20)
        times = [p["candle_at"] for p in res["equity_curve"]]
        self.assertEqual(times, sorted(set(times)))                # no duplicated / mis-ordered bars
        self.assertGreater(ticks["n"], 3)                          # the event loop kept running during the simulation


class WarmupNeverRefetchesTheSameInstrument(unittest.IsolatedAsyncioTestCase):
    async def test_unsatisfiable_instruments_are_fetched_once_per_job(self):
        from app import scanner_engine as se_
        db = fresh_db()
        db.bulk_upsert_instruments([{"trading_symbol": f"S{i}-EQ", "instrument_token": str(i), "lot_size": 1, "tick_size": 0.05} for i in range(1, 6)])
        d = {"side": "BUY", "timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
             "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]}, "execution": {"product": "MIS"},
             "risk": {"stop_loss_pct": 1}, "position_sizing": {"quantity": 1}}
        calls = []

        async def short_history(seg, tok, tf, a, b, sym):          # broker returns data but never enough bars (new listing)
            calls.append(tok)
            return [1], {}
        se_._WARMUP_JOBS.clear()
        with patch("app.backtest_service._fetch_chunks", short_history):
            job = se_.start_warmup_job(db.list_instruments(10), "5m", d)
            await asyncio.wait_for(job["task"], 10)
        self.assertEqual(sorted(calls), ["1", "2", "3", "4", "5"])   # each exactly once, then the job ends
        self.assertEqual(job["status"], "DONE")


class SchemaAndHousekeeping(unittest.IsolatedAsyncioTestCase):
    async def test_ticks_are_recorded_even_before_migration_014(self):
        from app import db as dbm
        db = fresh_db()
        with db._connection() as c:
            c.execute("ALTER TABLE market_data_state DROP COLUMN upper_circuit")
            c.execute("ALTER TABLE market_data_state DROP COLUMN lower_circuit")
        dbm._CIRCUIT_COLS.update(ok=None, path=None)
        db.record_market_tick(instrument_token="9", exchange_segment="nse_cm", last_traded_price=12.5, upper_circuit=14.0, lower_circuit=11.0)
        with db._connection() as c:
            self.assertEqual(c.execute("SELECT last_traded_price FROM market_data_state WHERE instrument_token='9'").fetchone()[0], 12.5)
        self.assertEqual(db.get_circuit_limits("nse_cm", "9"), (None, None))
        dbm._CIRCUIT_COLS.update(ok=None, path=None)

    async def test_order_time_subscription_is_released_later(self):
        from app import order_service as osv
        released = []
        with patch("app.market_prices.fresh_ltp", side_effect=[None, 10.0, 10.0]), \
             patch("app.websocket_manager.websocket_manager.subscribe", AsyncMock()), \
             patch("app.websocket_manager.websocket_manager.release_owner", AsyncMock(side_effect=lambda o: released.append(o))), \
             patch.object(osv, "ORDER_FEED_HOLD_SECONDS", 0.05):
            await osv._ensure_live_price_feed(dict(trading_symbol="ABC-EQ", exchange_segment="nse_cm", instrument_token="500", order_role="MANUAL"))
            await asyncio.sleep(0.2)
        self.assertEqual(released, ["order:nse_cm:500"])


if __name__ == "__main__":
    unittest.main()


class BacktestFailureIsReadable(unittest.IsolatedAsyncioTestCase):
    async def test_engine_exception_returns_a_reason_not_a_bare_500(self):
        from app import backtest_service as bs
        db = fresh_db()
        raw = bars(200, fmt="%Y-%m-%dT%H:%M:%S+0530")
        d = fixture()["buy_default"]
        with patch.object(bs, "_fetch_chunks", AsyncMock(return_value=(raw, {"chunk_count": 1, "chunks": []}))), \
             patch.object(bs.strategy_engine, "run_backtest", side_effect=ValueError("boom in engine")):
            status, body = await bs.run({"definition": d, "instrument_token": "11915", "trading_symbol": "YESBANK-EQ", "timeframe": "15m",
                                          "quantity": "1", "from_date": "2026-09-02", "to_date": "2026-09-08", "initial_capital": "100000",
                                          "slippage": "0.0005", "fees": "0", "cost_model": {}})
        self.assertEqual(status, 500)
        self.assertIn("boom in engine", body["error"])
        listed = db.list_backtests(5)
        self.assertEqual(listed[0]["status"], "FAILED")
        self.assertIn("boom in engine", listed[0]["error_message"])        # the run history can show the real reason
