"""Continuous strategy-specific universe scanning and candidate management.

A scanner match is never an order signal by itself. It creates a durable
(strategy_version, instrument) candidate, acquires a logical LIVE-feed owner,
and lets the strategy engine perform the complete entry/risk/readiness chain.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import logging
import re
import time
from zoneinfo import ZoneInfo
from . import db, strategy_engine
from .websocket_manager import websocket_manager

logger = logging.getLogger("owner_trading.scanner")
IST = ZoneInfo("Asia/Kolkata")
MAX_UNIVERSE = 3000
DEFAULT_CANDIDATE_TTL_BARS = 3


def _expiry_for(timeframe: str, definition: dict) -> str:
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 5))
    bars = int(definition.get("candidate_ttl_bars") or DEFAULT_CANDIDATE_TTL_BARS)
    bars = max(1, min(bars, 20))
    when = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=minutes * bars)
    return when.strftime("%Y-%m-%d %H:%M:%S")


def _scanner_universe(scanner: dict, fallback: list[dict]) -> list[dict]:
    definition=scanner.get("definition") or {}
    universe=definition.get("universe") if isinstance(definition,dict) else None
    tokens=[]
    if isinstance(universe,dict):
        tokens=[str(x).strip() for x in (universe.get("instrument_tokens") or []) if str(x).strip()]
    if not tokens:
        return fallback
    out=[]
    for tok in dict.fromkeys(tokens[:MAX_UNIVERSE]):
        inst=db.get_instrument("nse_cm",tok)
        if inst: out.append(inst)
    return out


def _candle_is_fresh(candle_at: str, timeframe: str) -> bool:
    try:
        raw=str(candle_at).replace("Z","+")
        stamp=dt.datetime.fromisoformat(raw)
        # Stored candle_at values are naive NSE (IST) wall-clock times, exactly as the candle
        # engine and historical loader write them -- NOT UTC. Reading them as UTC put every
        # candle 5.5h in the future and made the scanner treat all of them as stale.
        if stamp.tzinfo is None: stamp=stamp.replace(tzinfo=IST).astimezone(dt.timezone.utc)
        else: stamp=stamp.astimezone(dt.timezone.utc)
        minutes=int(strategy_engine.TIMEFRAMES.get(timeframe,5))
        age=(dt.datetime.now(dt.timezone.utc)-stamp).total_seconds()
        # Scanner works on completed candles. Intraday bars must be recent; a
        # daily bar may legitimately be the previous completed trading day.
        max_age=72*3600 if minutes>=1440 else max(3*minutes*60, 180)
        return 0 <= age <= max_age
    except (TypeError,ValueError,OverflowError):
        return False


MIN_BARS = 20
MAX_WARMUP_PER_CYCLE = 40
BARS_PER_TRADING_DAY = {"1m": 375, "3m": 125, "5m": 75, "10m": 38, "15m": 25, "30m": 13, "1h": 7, "1d": 1}


def history_calendar_days(timeframe: str, need_bars: int) -> int:
    """Smallest calendar window that covers `need_bars` completed bars (weekends/holidays included),
    kept inside ONE Kotak chunk so a single small request is made per instrument."""
    from . import backtest_service
    per_day = BARS_PER_TRADING_DAY.get(timeframe, 25)
    trading_days = -(-int(need_bars) // per_day) + 1
    days = -(-trading_days * 7 // 5) + 5
    return max(3, min(days, backtest_service.HISTORICAL_MAX_DAYS.get(timeframe, 30) - 1))


def _definition_operands(definition: dict) -> set[str]:
    out: set[str] = set()

    def walk(group):
        if not isinstance(group, dict):
            return
        for c in group.get("conditions") or []:
            if isinstance(c, dict):
                for k in ("left", "right"):
                    if isinstance(c.get(k), str):
                        out.add(c[k].strip().lower())
        for child in group.get("groups") or []:
            walk(child)
    for part in ("entry", "exit"):
        walk(definition.get(part))
    return out


def required_bars(definition: dict) -> int:
    """Smallest completed-bar history in which every indicator the definition uses is defined
    (e.g. ema50 needs >=50 bars; macd ~35; adx14 ~28; rsi14/atr14 ~15; bb/sma20 20)."""
    need = MIN_BARS
    for name in _definition_operands(definition):
        m = re.fullmatch(r"(?:sma|ema)(\d+)", name)
        if m:
            need = max(need, int(m.group(1)) + 2)
        elif name in ("macd", "macd_signal", "macd_hist"):
            need = max(need, 40)
        elif name == "adx14":
            need = max(need, 40)
        elif name in ("rsi14", "atr14"):
            need = max(need, 20)
    return min(need, 250)


def _bar_is_complete(candle_at: str, timeframe: str, now_ist: dt.datetime) -> bool:
    """A bar is complete once its whole window has elapsed (history may include the forming bar)."""
    try:
        start = dt.datetime.strptime(db.canonical_candle_at(candle_at), "%Y-%m-%d %H:%M:%S").replace(tzinfo=IST)
    except ValueError:
        return False
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 5))
    return start + dt.timedelta(minutes=minutes) <= now_ist


def _scan_with_stats(universe: list[dict], definition: dict, timeframe: str) -> tuple[list[dict], dict]:
    """Evaluate the entry conditions on COMPLETED bars and say exactly why instruments were skipped."""
    need = required_bars(definition)
    candle_map = db.recent_candles_for_instruments(universe, timeframe, 250)
    now_ist = dt.datetime.now(IST)
    stats = {"universe": len(universe), "no_candles": 0, "insufficient_history": 0, "stale": 0,
             "evaluated": 0, "matched": 0, "required_bars": need, "latest_candle_at": None}
    matched = []
    for instrument in universe:
        candles = candle_map.get((instrument["exchange_segment"], str(instrument["instrument_token"])), [])
        while candles and not _bar_is_complete(candles[-1].get("candle_at"), timeframe, now_ist):
            candles = candles[:-1]
        if not candles:
            stats["no_candles"] += 1
            continue
        last_at = db.canonical_candle_at(candles[-1]["candle_at"])
        if stats["latest_candle_at"] is None or last_at > stats["latest_candle_at"]:
            stats["latest_candle_at"] = last_at
        if len(candles) < need:
            stats["insufficient_history"] += 1
            continue
        if not _candle_is_fresh(last_at, timeframe):
            stats["stale"] += 1
            continue
        stats["evaluated"] += 1
        passed, detail = strategy_engine.evaluate_entry(definition, candles)
        if passed:
            matched.append({"instrument": instrument, "price": candles[-1]["close"], "details": detail,
                            "candle_at": last_at})
    stats["matched"] = len(matched)
    return matched, stats


def _scan(universe: list[dict], definition: dict, timeframe: str) -> list[dict]:
    return _scan_with_stats(universe, definition, timeframe)[0]


def explain_scan(stats: dict, *, market_open: bool) -> str:
    """One human sentence for the UI: why a scan produced what it produced."""
    if stats["universe"] == 0:
        return "No NSE instruments in the database. Sync Market Data (NSE cash scrip master) first."
    if stats["evaluated"] == 0:
        if stats["no_candles"] >= stats["universe"]:
            return ("No candle history exists for any instrument. Candles come from live ticks or Kotak historical data; "
                    "the scanner is loading history in batches -- run it again until 'remaining' reaches 0.")
        if stats["insufficient_history"] and not stats["stale"]:
            return (f"{stats['insufficient_history']} instruments have candles but fewer than the {stats['required_bars']} bars "
                    "this scanner's indicators need. Run again to keep loading history.")
        if stats["stale"]:
            return ("Candle history is stale (latest completed bar: %s). %s" % (
                stats["latest_candle_at"], "Wait for the next completed bar." if market_open else
                "The market is closed, so intraday scans only evaluate while it is open."))
    if stats["matched"] == 0:
        return f"Evaluated {stats['evaluated']} instruments on completed bars; none satisfy the entry conditions right now."
    return f"{stats['matched']} of {stats['evaluated']} evaluated instruments match."


def _warmup_targets(universe: list[dict], timeframe: str, definition: dict, need: int) -> list[dict]:
    """Instruments that cannot be evaluated yet (too few completed bars or a stale last bar)."""
    candle_map = db.recent_candles_for_instruments(universe, timeframe, 250)
    now_ist = dt.datetime.now(IST)
    targets = []
    for inst in universe:
        candles = candle_map.get((inst["exchange_segment"], str(inst["instrument_token"])), [])
        complete = [c for c in candles if _bar_is_complete(c.get("candle_at"), timeframe, now_ist)]
        ok = len(complete) >= need and complete and _candle_is_fresh(db.canonical_candle_at(complete[-1]["candle_at"]), timeframe)
        if not ok:
            targets.append(inst)
    return targets


async def warmup_history(universe: list[dict], timeframe: str, definition: dict, *,
                         time_budget: float = 6.0, max_instruments: int = 150, concurrency: int = 2,
                         attempted: set | None = None) -> dict:
    """Backfill completed-bar history from Kotak historical_data (docs/functions/market_data/historical_data.md).

    Only instruments that cannot yet be evaluated are fetched, time-boxed, with bounded concurrency, and
    stopped on the first broker auth/rate-limit/session/timeout failure instead of hammering the API.
    ``attempted`` (shared by the caller across batches) makes sure an instrument that was already fetched
    once -- e.g. a new listing that simply has too little history -- is never fetched again, so such stocks
    cannot starve the rest of the universe or cause a refetch loop. Read-only: no order path.
    """
    from . import backtest_service
    need = required_bars(definition)
    attempted = attempted if attempted is not None else set()
    # DB scan + indicator-window maths for up to 3000 instruments: keep it off the event loop.
    all_targets = await asyncio.to_thread(_warmup_targets, universe, timeframe, definition, need)
    key = lambda i: (i["exchange_segment"], str(i["instrument_token"]))
    targets = [t for t in all_targets if key(t) not in attempted]
    result = {"needed": len(targets), "fetched": 0, "failed": 0, "tried": 0, "remaining": len(targets), "stopped": None, "required_bars": need}
    if not targets or timeframe not in backtest_service.HISTORICAL_MAX_DAYS:
        return result
    batch = targets[:max(1, max_instruments)]
    days = history_calendar_days(timeframe, need)
    end = dt.datetime.now(IST).date()
    start = end - dt.timedelta(days=days)
    deadline = time.monotonic() + max(1.0, time_budget)
    sem = asyncio.Semaphore(max(1, concurrency))
    errors: list[str] = []
    stop = asyncio.Event()

    async def one(inst: dict):
        if stop.is_set() or time.monotonic() >= deadline:
            return
        async with sem:
            if stop.is_set() or time.monotonic() >= deadline:
                return
            try:
                rows, meta = await backtest_service._fetch_chunks(inst["exchange_segment"], str(inst["instrument_token"]), timeframe,
                                                                 start, end, inst.get("trading_symbol") or str(inst["instrument_token"]))
            except Exception as exc:  # noqa: BLE001 -- not connected / transport: stop, report
                errors.append(f"{type(exc).__name__}: {exc}"); stop.set(); result["stopped"] = errors[-1][:200]
                return
            attempted.add(key(inst)); result["tried"] += 1
            if rows is None:
                msg = str(meta.get("error") or "historical_data failed")
                result["failed"] += 1
                errors.append(msg)
                low = msg.lower()
                if any(k in low for k in ("429", "too many", "session", "auth", "login", "not connected", "403", "401", "timeout", "timed out")):
                    stop.set(); result["stopped"] = msg[:200]
                return
            result["fetched"] += 1

    await asyncio.gather(*(one(inst) for inst in batch))
    result["remaining"] = max(0, len(targets) - result["tried"])
    if errors and not result["stopped"] and result["fetched"] == 0:
        result["stopped"] = errors[0][:200]
    return result


async def ensure_scanner_market_universe(limit: int = MAX_UNIVERSE) -> dict:
    """Keep the scanner's broad market feed alive without making it a strategy feed."""
    universe = db.list_instruments(max(1, min(int(limit or MAX_UNIVERSE), MAX_UNIVERSE)))
    keys=[("nse_cm",str(x["instrument_token"])) for x in universe if str(x.get("instrument_token") or "").strip()]
    if not keys:
        return {"universe": 0, "subscribed": 0, "error": "No NSE instruments are available. Sync Market Data first."}
    try:
        result=await websocket_manager.ensure_owner_subscriptions(keys, owner="scanner-universe")
        return {"universe":len(keys),"subscribed":int(result.get("added") or 0),"total":result.get("total")}
    except Exception as exc:
        return {"universe":len(keys),"subscribed":0,"error":f"Scanner market-feed subscription failed: {type(exc).__name__}: {exc}"}


_WARMUP_JOBS: dict[str, dict] = {}
WARMUP_RESTART_AFTER_SECONDS = 30
WARMUP_MAX_SECONDS = 1200
_PUBLIC_JOB_FIELDS = ("status", "needed", "fetched", "failed", "remaining", "stopped", "required_bars", "started_at", "finished_at")


def _job_key(timeframe: str, definition: dict) -> str:
    return f"{timeframe}:{required_bars(definition)}"


def _public_job(job: dict | None) -> dict | None:
    return {k: job.get(k) for k in _PUBLIC_JOB_FIELDS} if job else None


async def _run_warmup_job(job: dict, universe: list[dict], timeframe: str, definition: dict) -> None:
    deadline = time.monotonic() + WARMUP_MAX_SECONDS
    attempted: set = set()
    try:
        for _ in range(200):
            if time.monotonic() >= deadline:
                job["stopped"] = job.get("stopped") or "time budget reached; press Run Now again to continue"
                break
            r = await warmup_history(universe, timeframe, definition, time_budget=25.0, max_instruments=300, attempted=attempted)
            if job["needed"] is None:
                job["needed"] = r.get("needed", 0)
            job["fetched"] += r.get("fetched", 0)
            job["failed"] += r.get("failed", 0)
            job["remaining"] = r.get("remaining", 0)
            job["required_bars"] = r.get("required_bars", job.get("required_bars"))
            if r.get("stopped"):
                job["stopped"] = r["stopped"]
                break
            if not r.get("remaining") or r.get("tried", 0) == 0:
                break
            await asyncio.sleep(0.5)
        job["status"] = "STOPPED" if job.get("stopped") else "DONE"
    except Exception as exc:  # noqa: BLE001 -- surfaced to the UI, never silent
        job["status"] = "ERROR"
        job["stopped"] = f"{type(exc).__name__}: {exc}"[:200]
        logger.warning("Scanner history job failed: %s", exc)
    finally:
        job["finished_at"] = dt.datetime.now(dt.timezone.utc).isoformat()


def start_warmup_job(universe: list[dict], timeframe: str, definition: dict) -> dict:
    """Single-flight background history load. Returns the (public) job state immediately; the HTTP
    request that asked for it never waits for Kotak. A failed job is not restarted for 30 s so a
    timeout/429 can never turn into a retry storm."""
    key = _job_key(timeframe, definition)
    job = _WARMUP_JOBS.get(key)
    if job:
        if job["status"] == "RUNNING":
            return job
        finished = job.get("finished_monotonic", 0.0)
        if job["status"] in ("STOPPED", "ERROR") and time.monotonic() - finished < WARMUP_RESTART_AFTER_SECONDS:
            return job
    job = {"status": "RUNNING", "needed": None, "fetched": 0, "failed": 0, "remaining": None, "stopped": None,
           "required_bars": required_bars(definition), "started_at": dt.datetime.now(dt.timezone.utc).isoformat(), "finished_at": None}
    _WARMUP_JOBS[key] = job
    task = asyncio.ensure_future(_run_warmup_job(job, universe, timeframe, definition))
    job["task"] = task
    task.add_done_callback(lambda _t, j=job: j.__setitem__("finished_monotonic", time.monotonic()))
    return job


async def run(payload: dict) -> dict:
    """Manual scanner run. Analysis-only: it never places an order.

    Loads missing history first (time-boxed), evaluates completed bars, returns matches with
    symbols plus a diagnostic breakdown, and -- when ``subscribe_matches`` is true -- subscribes
    the matched instruments to the live feed under one replaceable owner so they stay visible
    on Market Data."""
    from .market_session import session_state
    definition = payload.get("definition") or {}
    if not isinstance(definition, dict):
        return {"error": "definition must be an object", "results": [], "scanned": 0, "matched": 0}
    errors = strategy_engine.validate_strategy(definition)
    if errors:
        return {"error": "Invalid scanner definition", "validation_errors": errors, "results": [], "scanned": 0, "matched": 0}
    timeframe = str(payload.get("timeframe") or definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"error": "Unsupported scanner timeframe.", "results": [], "scanned": 0, "matched": 0}
    try:
        limit = max(1, min(int(payload.get("limit") or MAX_UNIVERSE), MAX_UNIVERSE))
    except (TypeError, ValueError):
        return {"error": "limit must be an integer.", "results": [], "scanned": 0, "matched": 0}
    universe = _scanner_universe({"definition": definition}, db.list_instruments(limit))
    # CPU-heavy indicator maths for up to 3000 instruments runs in a worker thread so the broker
    # service keeps processing ticks, exits and API calls while a scan is in progress.
    matched, stats = await asyncio.to_thread(_scan_with_stats, universe, definition, timeframe)
    market_open = bool(session_state().get("open"))
    warmup = None
    if payload.get("warmup", True):
        needs_history = (stats["no_candles"] + stats["insufficient_history"]) > 0 or (market_open and stats["stale"] > 0)
        key = _job_key(timeframe, definition)
        if needs_history and not payload.get("poll"):
            warmup = _public_job(start_warmup_job(universe, timeframe, definition))
        else:
            warmup = _public_job(_WARMUP_JOBS.get(key))
    subscribed = None
    if payload.get("subscribe_matches"):
        subscribed = await _subscribe_manual_matches(matched)
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    rows = [{"trading_symbol": m["instrument"].get("trading_symbol"), "instrument_token": str(m["instrument"]["instrument_token"]),
             "exchange_segment": m["instrument"]["exchange_segment"], "price": m["price"], "candle_at": m.get("candle_at"),
             "details": m["details"]} for m in matched]
    return {"results": matched, "matches": rows, "scanned": len(universe), "matched": len(matched), "timeframe": timeframe,
            "diagnostics": stats, "explanation": _scan_explanation(stats, market_open, warmup), "market_open": market_open,
            "warmup": warmup, "subscribed_matches": subscribed}


def _scan_explanation(stats: dict, market_open: bool, warmup: dict | None) -> str:
    base = explain_scan(stats, market_open=market_open)
    if warmup and warmup.get("status") == "RUNNING":
        done = warmup.get("fetched") or 0
        total = warmup.get("needed")
        progress = f"{done} of {total}" if total else f"{done}"
        return f"Loading candle history in the background ({progress} instruments). This page refreshes automatically; matches appear as history arrives. {base}"
    if warmup and warmup.get("status") in ("STOPPED", "ERROR") and warmup.get("stopped"):
        return f"History loading stopped: {warmup['stopped']}. {base}"
    return base


MANUAL_MATCH_OWNER = "scanner-manual-matches"
MANUAL_MATCH_HOLD_SECONDS = 3600.0
_manual_release_handle = None
MAX_MANUAL_MATCH_SUBSCRIPTIONS = 200


async def _subscribe_manual_matches(matched: list[dict]) -> dict:
    """Replace (not accumulate) the manual-match feed owner so repeated runs cannot leak subscriptions."""
    keys = [(m["instrument"]["exchange_segment"], str(m["instrument"]["instrument_token"])) for m in matched][:MAX_MANUAL_MATCH_SUBSCRIPTIONS]
    try:
        await websocket_manager.release_owner(MANUAL_MATCH_OWNER)
        if not keys:
            return {"subscribed": 0, "skipped": len(matched)}
        r = await websocket_manager.subscribe_many(keys, owner=MANUAL_MATCH_OWNER)
        global _manual_release_handle
        if _manual_release_handle is not None:
            _manual_release_handle.cancel()
        # Manual matches are a temporary watchlist: free the feed after an hour so they do not pile up.
        _manual_release_handle = asyncio.get_running_loop().call_later(
            MANUAL_MATCH_HOLD_SECONDS, lambda: asyncio.ensure_future(websocket_manager.release_owner(MANUAL_MATCH_OWNER)))
        return {"subscribed": len(keys), "skipped": max(0, len(matched) - len(keys)), "total_feed": r.get("total") if isinstance(r, dict) else None}
    except Exception as exc:  # noqa: BLE001 -- surfaced to the UI, never silent
        return {"subscribed": 0, "error": f"{type(exc).__name__}: {exc}"}


async def run_for_strategy(strategy_version_id: int, scanner_id: int, scanner: dict, universe: list[dict]) -> dict:
    """Run one scanner only for the strategy that explicitly references it."""
    definition=scanner.get("definition") or {}
    errors=strategy_engine.validate_strategy(definition)
    if errors:
        logger.warning("Skipping invalid scanner %s: %s", scanner_id, errors)
        return {"matched":0,"scanned":len(universe),"errors":errors}
    timeframe=str(definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"matched":0,"scanned":len(universe),"errors":["unsupported scanner timeframe"]}
    scan_universe=_scanner_universe(scanner, universe)
    try:
        # Single-flight background job: the 30 s cycle never waits for Kotak, and a 3000-stock
        # universe is back-filled progressively while earlier-ready instruments already scan.
        start_warmup_job(scan_universe, timeframe, definition)
    except Exception as exc:  # noqa: BLE001 -- history loading must never stop the scan cycle
        logger.warning("Scanner history warm-up failed for scanner %s: %s", scanner_id, exc)
    matches,_stats=await asyncio.to_thread(_scan_with_stats,scan_universe,definition,timeframe)
    logger.info("Scanner %s (strategy v%s): %s", scanner_id, strategy_version_id, explain_scan(_stats, market_open=True))
    ttl=_expiry_for(timeframe,definition)
    # The strategy may run on a different timeframe / need a longer history than the scanner:
    # give every matched candidate the history the strategy's own entry evaluation requires.
    try:
        sv=db.get_strategy_version(int(strategy_version_id)) or {}
        sdef=sv.get("definition") or {}
        stf=str(sdef.get("timeframe") or timeframe)
        if matches and stf in strategy_engine.TIMEFRAMES:
            await warmup_history([m["instrument"] for m in matches], stf, sdef, time_budget=4.0, max_instruments=MAX_WARMUP_PER_CYCLE)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Candidate history warm-up failed for strategy=%s: %s", strategy_version_id, exc)
    for item in matches:
        inst=item["instrument"]; tok=str(inst["instrument_token"]); seg=str(inst["exchange_segment"])
        candidate=db.upsert_strategy_candidate(
            strategy_version_id=strategy_version_id,scanner_id=int(scanner_id),exchange_segment=seg,
            instrument_token=tok,trading_symbol=inst.get("trading_symbol"),timeframe=timeframe,
            matched_price=float(item["price"]),conditions=item["details"],expires_at=ttl,
        )
        owner=f"strategy:{strategy_version_id}:candidate:{seg}:{tok}"
        try:
            await websocket_manager.subscribe(seg,tok,owner=owner)
            db.mark_strategy_candidate_subscribed(candidate["id"],True)
        except Exception as exc:
            db.mark_strategy_candidate_subscribed(candidate["id"],False,error=f"{type(exc).__name__}: {exc}")
            logger.warning("Candidate subscription failed for strategy=%s token=%s: %s",strategy_version_id,tok,exc)
    # Evaluate the strategy's own entry rules NOW on the last completed bar of each fresh candidate.
    # Otherwise a candidate would sit idle until its next bar closes (up to a full timeframe later),
    # which looks like "the strategy does nothing". Safe: one evaluation per candle (_last_eval),
    # idempotent order key per candle, and every normal gate/risk check still applies.
    try:
        from .algo_engine import algo_engine
        sv=db.get_strategy_version(int(strategy_version_id)) or {}
        stf=str((sv.get("definition") or {}).get("timeframe") or timeframe)
        for item in matches[:30]:
            inst=item["instrument"]
            await algo_engine.on_tick(exchange_segment=str(inst["exchange_segment"]),instrument_token=str(inst["instrument_token"]),
                                      trading_symbol=inst.get("trading_symbol"),timeframe=stf)
    except Exception as exc:  # noqa: BLE001 -- never let an evaluation problem stop the scan cycle
        logger.warning("Immediate candidate evaluation failed for strategy=%s: %s",strategy_version_id,exc)
    return {"matched":len(matches),"scanned":len(universe),"timeframe":timeframe}


async def cleanup_expired_candidates() -> int:
    """Expire candidate rows and release only the corresponding strategy owners."""
    before=db.list_strategy_candidates(active_only=True,limit=10000)
    db.expire_strategy_candidates()
    removed=0
    for c in before:
        if not db.has_active_candidate(strategy_version_id=c["strategy_version_id"], exchange_segment=c["exchange_segment"], instrument_token=c["instrument_token"]):
            owner=f"strategy:{c['strategy_version_id']}:candidate:{c['exchange_segment']}:{c['instrument_token']}"
            removed += await websocket_manager.release_owner(owner)
    return removed


async def run_continuous_cycle() -> dict:
    """Run only scanners referenced by currently LIVE-armed strategies."""
    active=[]
    scanner_by_id={s["id"]:s for s in db.list_scanners() if s.get("is_active")}
    for item in db.list_live_armed_strategy_versions():
        for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
            try: sid=int(raw_id)
            except (TypeError,ValueError): continue
            scanner=scanner_by_id.get(sid)
            if scanner: active.append((int(item["id"]),sid,scanner))
    if not active:
        # No active scanner is currently allowed to drive any armed strategy.
        # Immediately stop existing candidate owners instead of waiting for TTL.
        for item in db.list_live_armed_strategy_versions():
            vid=int(item["id"])
            if (item.get("definition") or {}).get("scanner_ids"):
                for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
                db.deactivate_strategy_candidates(vid)
        await websocket_manager.release_owner("scanner-universe")
        return {"strategies":0,"scanners":0,"matched":0,"universe":0}
    # Deactivate candidates belonging to scanners that are no longer active or
    # no longer referenced by their owning strategy.
    active_by_strategy={}
    for vid,sid,_scanner in active:
        active_by_strategy.setdefault(vid,set()).add(sid)
    for item in db.list_live_armed_strategy_versions():
        vid=int(item["id"]); configured=[int(x) for x in (item.get("definition") or {}).get("scanner_ids") or [] if str(x).isdigit()]
        if configured:
            allowed=active_by_strategy.get(vid,set())
            for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                if int(c["scanner_id"]) not in allowed:
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
            db.deactivate_strategy_candidates_for_scanners(vid,list(allowed))
    market=await ensure_scanner_market_universe(MAX_UNIVERSE)
    universe=db.list_instruments(MAX_UNIVERSE)
    matched=0
    for vid,sid,scanner in active:
        result=await run_for_strategy(vid,sid,scanner,universe)
        matched += int(result.get("matched") or 0)
    removed=await cleanup_expired_candidates()
    await websocket_manager.remove_if_unneeded()
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    return {"strategies":len({v for v,_,_ in active}),"scanners":len(active),"matched":matched,"universe":len(universe),"expired_unsubscribed":removed,"market":market}
