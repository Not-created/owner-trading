# Owner Trading — Clean Single-File Architecture

20 application module files are provided in `src/`. Each major module has one
main file. Shared styling, global theme/context and API transport are kept in
the small core files.

Dark/Light is global and responsive. Trading values are not hardcoded as real
broker data; live values are expected from the backend API.

This ZIP is the clean visible starting project, not a claim that the complete
production backend has already been implemented.
