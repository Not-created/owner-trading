#!/usr/bin/env bash
#
# ==============================================================================
#  OWNER TRADING -- ROOT-LEVEL ONE-CLICK DEPLOYMENT
# ==============================================================================
#
# Intended usage on a fresh Ubuntu VPS:
#   git pull origin main
#   chmod +x deploy.sh      # only needed once, if execute bit wasn't preserved
#   ./deploy.sh
#
# Flow:
#   1.  Detect/verify Ubuntu, Node.js, Python
#   2.  Install required OS packages (best-effort; skipped if not root/apt)
#   3.  Create/verify the Python virtual environment
#   4.  Install/pin the official kotakneoapi SDK + broker-service deps
#   5.  Install backend (Node) dependencies
#   6.  Install frontend dependencies
#   7.  Create/verify the SQLite database + run migrations (idempotent,
#       NEVER drops or recreates an existing database)
#   8.  Create required directories, configure environment files
#       (never overwrites an existing backend/.env or broker.env)
#   9.  Build the frontend for production
#   10. Prompt for the 8-character website access password (the ONLY
#       interactive step in normal operation) -- validate, re-prompt on
#       invalid input, hash + store server-side
#   11. Install/refresh systemd unit files (enable + start if systemd is
#       actually available; otherwise fall back to a background start so
#       this script still works in a plain container/dev box)
#   12. Install/verify the Nginx reverse-proxy config (best-effort; skipped
#       if Nginx isn't installed)
#   13. Health-check both services
#   14. Report final status clearly, including anything that was skipped
#       and why -- this script never claims a step succeeded if it didn't
#       actually run.
#
# THIS PHASE DOES NOT: ask for Kotak consumer key/mobile/UCC/TOTP/MPIN, or
# connect to a real Kotak account. broker-service/.env.example documents the
# variables the NEXT phase will populate.
#
# SAFETY: this script never overwrites an existing backend/.env,
# /etc/owner-trading/broker.env, or the SQLite database file. Migrations are
# additive-only (see backend/src/db/migrate.js). Re-running this script on
# an already-deployed server is safe.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
BROKER_DIR="$ROOT_DIR/broker-service"
DEPLOYMENT_DIR="$ROOT_DIR/deployment"
ENV_FILE="$BACKEND_DIR/.env"
PASSWORD_HASH_FILE="$BACKEND_DIR/src/data/secure/password.hash.json"
DB_PATH="$BACKEND_DIR/data/owner-trading.db"
BROKER_ENV_SYSTEM_PATH="/etc/owner-trading/broker.env"
PORT="${PORT:-4000}"
BROKER_PORT="${BROKER_SERVICE_PORT:-8800}"

info()  { printf '\n\033[1;36m==>\033[0m %s\n' "$1"; }
ok()    { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
warn()  { printf '  \033[1;33m! %s\033[0m\n' "$1"; }
fail()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

echo "=============================================="
echo "   OWNER TRADING -- One-Click Deployment"
echo "=============================================="

# ============================================================
# 1. Detect/verify environment
# ============================================================
info "Checking environment"

if [ -f /etc/os-release ] && grep -qi ubuntu /etc/os-release; then
  ok "Ubuntu detected: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"')"
else
  warn "This does not look like Ubuntu (checked /etc/os-release). Continuing anyway, but this script is written/tested for Ubuntu production hosts."
fi

command -v node >/dev/null 2>&1 || fail "Node.js is required but was not found. Install Node.js 22.5+ and re-run ./deploy.sh."
NODE_VERSION="$(node --version)"
ok "Node.js ${NODE_VERSION}"
command -v npm >/dev/null 2>&1 || fail "npm is required but was not found."
ok "npm $(npm --version)"

# The DB layer (backend/src/db/client.js) uses Node's built-in `node:sqlite`
# module so the project needs zero native-compiled DB dependencies -- but
# that module requires Node 22.5+, newer than a bare ">=20" floor. Check the
# actual capability directly rather than just the version number, so the
# error is unambiguous either way.
if ! node -e "require('node:sqlite')" >/dev/null 2>&1; then
  fail "Node's built-in 'node:sqlite' module is not available on this Node install (found ${NODE_VERSION}). This project's database layer requires Node 22.5 or newer. Upgrade Node (e.g. via nvm or NodeSource) and re-run ./deploy.sh."
fi
ok "node:sqlite is available (Node ${NODE_VERSION} meets the 22.5+ requirement)"

PYTHON_BIN=""
for candidate in python3.12 python3.11 python3.10 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    PY_VER="$("$candidate" -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
    PY_MAJOR="${PY_VER%%.*}"; PY_MINOR="${PY_VER##*.}"
    if [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -ge 10 ]; then
      PYTHON_BIN="$candidate"
      break
    fi
  fi
done
if [ -z "$PYTHON_BIN" ]; then
  fail "Python >=3.10 is required but was not found. Install python3.10+ (e.g. 'sudo apt install python3.12 python3.12-venv') and re-run ./deploy.sh."
fi
ok "Python: $("$PYTHON_BIN" --version) ($PYTHON_BIN)"

# ============================================================
# 2. Install required OS packages (best-effort)
# ============================================================
info "OS packages"
if command -v apt-get >/dev/null 2>&1 && [ "$(id -u)" -eq 0 ]; then
  PY_VENV_PKG="${PYTHON_BIN}-venv"
  DEBIAN_FRONTEND=noninteractive apt-get update -y -qq || warn "apt-get update failed -- continuing with existing package state."
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$PY_VENV_PKG" build-essential curl >/dev/null 2>&1 \
    && ok "Installed/verified: $PY_VENV_PKG, build-essential, curl" \
    || warn "Could not install OS packages automatically ($PY_VENV_PKG, build-essential, curl) -- ensure these are present manually if venv creation fails below."
else
  warn "Not running as root with apt-get available -- skipping automatic OS package installation. Ensure python3-venv, build-essential, and curl are already installed."
fi

# ============================================================
# 3 & 4. Python virtual environment + kotakneoapi SDK
# ============================================================
info "Python broker-service virtual environment"
if [ ! -d "$BROKER_DIR/venv" ]; then
  "$PYTHON_BIN" -m venv "$BROKER_DIR/venv" || fail "Failed to create Python virtual environment at broker-service/venv."
  ok "Created broker-service/venv"
else
  ok "broker-service/venv already exists"
fi

info "Installing official kotakneoapi SDK + broker-service dependencies"
"$BROKER_DIR/venv/bin/pip" install --upgrade pip --quiet || warn "pip self-upgrade failed -- continuing with existing pip."
if "$BROKER_DIR/venv/bin/pip" install -r "$BROKER_DIR/requirements.txt" --quiet; then
  ok "kotakneoapi and broker-service dependencies installed"
else
  warn "pip install failed (commonly: no network access, or kotakneoapi==3.0.6 not yet published on PyPI -- see the version note in broker-service/requirements.txt). The broker service will still start and correctly report CONNECTION_ERROR / degraded mode without the SDK -- it will NOT silently pretend to be connected. Fix connectivity/the version pin and re-run ./deploy.sh to enable real broker functionality."
fi

# ============================================================
# 5 & 6. Node dependencies
# ============================================================
info "Installing backend dependencies"
(cd "$BACKEND_DIR" && npm install --no-audit --no-fund) || fail "Backend dependency install failed."
ok "Backend dependencies installed"

info "Installing frontend dependencies"
(cd "$FRONTEND_DIR" && npm install --no-audit --no-fund) || fail "Frontend dependency install failed."
ok "Frontend dependencies installed"

# ============================================================
# 7. Database + migrations (never drops/recreates existing data)
# ============================================================
info "Database"
if [ -f "$DB_PATH" ]; then
  ok "Existing database found at backend/data/owner-trading.db -- preserving it, applying only new migrations."
  BACKUP_DIR="$ROOT_DIR/backups"
  mkdir -p "$BACKUP_DIR"
  BACKUP_FILE="$BACKUP_DIR/owner-trading.db.$(date +%Y%m%d%H%M%S).bak"
  cp "$DB_PATH" "$BACKUP_FILE"
  ok "Backed up existing database -> ${BACKUP_FILE#$ROOT_DIR/}"
else
  ok "No existing database -- a new one will be created."
fi
node "$BACKEND_DIR/src/db/migrate.js" || fail "Database migration failed."
ok "Migrations applied"

# ============================================================
# 8. Required directories + configuration (never overwrites existing secrets)
# ============================================================
info "Preparing configuration"
mkdir -p "$BACKEND_DIR/src/data/secure" "$BACKEND_DIR/data" "$BROKER_DIR/data"

if [ -f "$ENV_FILE" ] && grep -q '^SESSION_SECRET=' "$ENV_FILE" 2>/dev/null; then
  ok "backend/.env already exists -- preserving it as-is."
else
  SESSION_SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")"
  {
    echo "NODE_ENV=production"
    echo "PORT=${PORT}"
    echo "SESSION_SECRET=${SESSION_SECRET}"
    echo "DB_PATH=${DB_PATH}"
    echo "BROKER_SERVICE_URL=http://127.0.0.1:${BROKER_PORT}"
    echo "TRADING_MODE=PAPER"
  } > "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  ok "Generated backend/.env"
fi

# Broker credentials file: only created as an empty, documented template if
# nothing exists yet -- THIS PHASE never populates real values into it, and
# an existing one (from a later phase) is never touched.
if [ "$(id -u)" -eq 0 ]; then
  if [ -f "$BROKER_ENV_SYSTEM_PATH" ]; then
    ok "$BROKER_ENV_SYSTEM_PATH already exists -- preserving it as-is (not inspecting its contents)."
  else
    mkdir -p "$(dirname "$BROKER_ENV_SYSTEM_PATH")"
    cp "$BROKER_DIR/.env.example" "$BROKER_ENV_SYSTEM_PATH"
    chmod 600 "$BROKER_ENV_SYSTEM_PATH"
    ok "Created empty credential template at $BROKER_ENV_SYSTEM_PATH (no real credentials -- populated in the NEXT phase)."
  fi
else
  warn "Not running as root -- skipped creating $BROKER_ENV_SYSTEM_PATH. The broker service will run with BROKER_SERVICE_PORT=${BROKER_PORT} and no credentials (NOT_CONFIGURED), which is correct for this phase."
fi

# ============================================================
# 9. Build frontend
# ============================================================
info "Building frontend for production"
(cd "$FRONTEND_DIR" && npm run build) || fail "Frontend build failed."
[ -f "$FRONTEND_DIR/dist/index.html" ] || fail "Frontend build did not produce dist/index.html."
ok "Frontend build complete (frontend/dist)"

# ============================================================
# 10. Password setup (the one interactive step)
# ============================================================
info "Website access password setup"
if [ -f "$PASSWORD_HASH_FILE" ]; then
  echo "  An access password is already configured on this server."
  read -r -p "  Set a new one instead? [y/N]: " RESET_PW
  RESET_PW="${RESET_PW:-N}"
else
  RESET_PW="y"
fi

if [[ "$RESET_PW" =~ ^[Yy]$ ]]; then
  while true; do
    read -r -s -p "  Set the website access password (exactly 8 characters): " PW_1
    echo
    read -r -s -p "  Confirm password: " PW_2
    echo
    if [[ "$PW_1" != "$PW_2" ]]; then
      echo "  Passwords do not match. Please try again."
      continue
    fi
    if [[ "${#PW_1}" -ne 8 ]]; then
      echo "  Password must be exactly 8 characters (was ${#PW_1}). Please try again."
      continue
    fi
    if [[ ! "$PW_1" =~ ^[A-Za-z0-9!@#\$%^\&\*\(\)_\-+=\[\]\{\}\;:,.\?]{8}$ ]]; then
      echo "  Password contains an unsupported character. Use letters, numbers, or common symbols. Please try again."
      continue
    fi
    break
  done
  printf '%s' "$PW_1" | node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to store the password hash."
  unset PW_1 PW_2
  ok "Password stored securely (hashed, server-side only)"
else
  ok "Keeping existing password"
fi

# ============================================================
# 11. systemd services (falls back to a background start if systemd isn't
#     available -- e.g. inside a plain container/sandbox, which cannot run
#     systemd)
# ============================================================
info "Process management (systemd)"
USE_SYSTEMD=""
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] && [ "$(id -u)" -eq 0 ]; then
  USE_SYSTEMD="1"
fi

if [ -n "$USE_SYSTEMD" ]; then
  # Both unit files run as User=owner-trading/Group=owner-trading -- create
  # that system user if it doesn't exist yet, and grant it ownership of
  # exactly the directories the units declare writable (ReadWritePaths),
  # nothing broader. Without this, `systemctl start` fails on a fresh VPS
  # because the referenced user doesn't exist.
  if ! id owner-trading >/dev/null 2>&1; then
    useradd --system --no-create-home --shell /usr/sbin/nologin owner-trading
    ok "Created system user 'owner-trading' (no login, no home dir)."
  else
    ok "System user 'owner-trading' already exists."
  fi
  # Writable data directories declared in ReadWritePaths -- owned by the
  # service user so it can actually write to them.
  chown -R owner-trading:owner-trading \
    "$BACKEND_DIR/data" \
    "$BACKEND_DIR/src/data/secure" \
    "$BROKER_DIR/data"

  # Secret files: owned by the service user, mode 600 (readable only by
  # owner-trading, not world-readable) -- otherwise EnvironmentFile=...backend/.env
  # would be unreadable by the process that needs it (it was created earlier
  # by whoever ran this script, typically root).
  for secret_file in "$ENV_FILE" "$PASSWORD_HASH_FILE" "$BROKER_ENV_SYSTEM_PATH"; do
    if [ -f "$secret_file" ]; then
      chown owner-trading:owner-trading "$secret_file"
      chmod 600 "$secret_file"
    fi
  done

  # NOTE: the rest of the checkout (source, node_modules, venv) is left at
  # whatever permissions npm/pip/git produced (default umask -- readable by
  # others on a standard Ubuntu install) so owner-trading can read+execute
  # it. Only the three secret files above and the data directories get
  # explicit ownership changes -- this fix is scoped to what was actually
  # broken, not a general permissions hardening pass.
  sed -e "s#/opt/owner-trading#${ROOT_DIR}#g" "$DEPLOYMENT_DIR/systemd/owner-trading-backend.service" > /etc/systemd/system/owner-trading-backend.service
  sed -e "s#/opt/owner-trading#${ROOT_DIR}#g" -e "s#/etc/owner-trading/broker.env#${BROKER_ENV_SYSTEM_PATH}#g" "$DEPLOYMENT_DIR/systemd/owner-trading-broker.service" > /etc/systemd/system/owner-trading-broker.service
  systemctl daemon-reload
  systemctl enable owner-trading-backend.service owner-trading-broker.service >/dev/null
  systemctl restart owner-trading-broker.service
  systemctl restart owner-trading-backend.service
  ok "systemd units installed, enabled (start on boot), and (re)started."
else
  warn "systemd is not usable in this environment (not root, or no systemd running -- e.g. a container/sandbox) -- falling back to a direct background start. On a real VPS running as root with systemd, this step installs and starts owner-trading-backend.service and owner-trading-broker.service properly; re-run as root there for full systemd management."

  # Broker service (background, stdlib-only, no compiled deps needed).
  BROKER_PID_FILE="$ROOT_DIR/.owner-trading-broker.pid"
  if [ -f "$BROKER_PID_FILE" ] && kill -0 "$(cat "$BROKER_PID_FILE" 2>/dev/null)" 2>/dev/null; then
    kill "$(cat "$BROKER_PID_FILE")" 2>/dev/null || true
    sleep 1
  fi
  (cd "$BROKER_DIR" && BROKER_SERVICE_PORT="$BROKER_PORT" DB_PATH="$DB_PATH" nohup ./venv/bin/python -m app.main > "$ROOT_DIR/owner-trading-broker.log" 2>&1 &
   echo $! > "$BROKER_PID_FILE")
  ok "Broker service started in background (pid $(cat "$BROKER_PID_FILE")), logging to owner-trading-broker.log"

  # Backend service.
  BACKEND_PID_FILE="$ROOT_DIR/.owner-trading-backend.pid"
  if [ -f "$BACKEND_PID_FILE" ] && kill -0 "$(cat "$BACKEND_PID_FILE" 2>/dev/null)" 2>/dev/null; then
    kill "$(cat "$BACKEND_PID_FILE")" 2>/dev/null || true
    sleep 1
  fi
  (cd "$BACKEND_DIR" && nohup npm start > "$ROOT_DIR/owner-trading-backend.log" 2>&1 &
   echo $! > "$BACKEND_PID_FILE")
  ok "Backend started in background (pid $(cat "$BACKEND_PID_FILE")), logging to owner-trading-backend.log"
fi

# ============================================================
# 12. Nginx (best-effort)
# ============================================================
info "Nginx reverse proxy"
if command -v nginx >/dev/null 2>&1 && [ "$(id -u)" -eq 0 ]; then
  cp "$DEPLOYMENT_DIR/nginx/owner-trading.conf" /etc/nginx/sites-available/owner-trading
  ln -sf /etc/nginx/sites-available/owner-trading /etc/nginx/sites-enabled/owner-trading
  if nginx -t 2>&1; then
    systemctl reload nginx
    ok "Nginx config installed and reloaded. EDIT /etc/nginx/sites-available/owner-trading to set your real server_name before going live, then re-run: sudo nginx -t && sudo systemctl reload nginx"
  else
    warn "Nginx config test failed -- config was copied to /etc/nginx/sites-available/owner-trading but NOT enabled/reloaded. Fix the reported error and reload manually."
  fi
else
  warn "Nginx is not installed (or not running as root) -- skipped. Install Nginx and re-run as root to enable the reverse proxy, or configure your own. Template: deployment/nginx/owner-trading.conf"
fi

# ============================================================
# 13. Health checks
# ============================================================
info "Health checks"
BACKEND_HEALTHY=""
for i in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    BACKEND_HEALTHY="1"
    break
  fi
  sleep 1
done
if [ -n "$BACKEND_HEALTHY" ]; then
  ok "Backend healthy on port ${PORT}"
else
  echo "  Backend did not respond within 20 seconds."
  [ -f "$ROOT_DIR/owner-trading-backend.log" ] && tail -n 30 "$ROOT_DIR/owner-trading-backend.log"
  fail "Deployment did not complete successfully -- backend failed its health check."
fi

BROKER_HEALTHY=""
for i in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${BROKER_PORT}/health" >/dev/null 2>&1; then
    BROKER_HEALTHY="1"
    break
  fi
  sleep 1
done
if [ -n "$BROKER_HEALTHY" ]; then
  BROKER_STATUS="$(curl -fsS "http://127.0.0.1:${BROKER_PORT}/status" 2>/dev/null || echo '{}')"
  ok "Broker service healthy on port ${BROKER_PORT} (state: ${BROKER_STATUS})"
else
  echo "  Broker service did not respond within 20 seconds."
  [ -f "$ROOT_DIR/owner-trading-broker.log" ] && tail -n 30 "$ROOT_DIR/owner-trading-broker.log"
  fail "Deployment did not complete successfully -- broker service failed its health check."
fi

READINESS="$(curl -fsS "http://127.0.0.1:${PORT}/api/readiness" 2>/dev/null || echo '{}')"

# ============================================================
# 14. Done
# ============================================================
echo
echo "=============================================="
echo "   Deployment complete."
echo "   Owner Trading backend:  http://127.0.0.1:${PORT}"
echo "   Broker service (local): http://127.0.0.1:${BROKER_PORT}"
echo "   Readiness snapshot:     ${READINESS}"
echo
echo "   Kotak Neo broker status: NOT_CONFIGURED / DISCONNECTED (expected --"
echo "   configure and connect your account from Settings inside the app)."
echo
echo "   Opening the site shows the password screen immediately."
echo "   Point Nginx/your domain at 127.0.0.1:${PORT} for a public URL."
echo "=============================================="
