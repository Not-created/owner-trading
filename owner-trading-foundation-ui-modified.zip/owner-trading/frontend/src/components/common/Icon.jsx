// A small hand-rolled icon set (SVG) so the dashboard shell doesn't need an
// extra icon-library dependency for a handful of glyphs. Add more here as
// needed by future sections.
const paths = {
  grid: "M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm9 0h7v7h-7v-7Z",
  "file-text": "M6 3h8l4 4v14H6V3Zm8 0v4h4M9 12h6M9 16h6M9 8h2",
  activity: "M3 12h4l2 7 4-14 2 7h4",
  layers: "M12 3l9 5-9 5-9-5 9-5Zm-9 9l9 5 9-5M3 16l9 5 9-5",
  briefcase: "M4 8h16v11H4V8Zm4 0V5h8v3M4 13h16",
  clock: "M12 3a9 9 0 1 0 .001 0M12 7v5l3 3",
  target: "M12 3a9 9 0 1 0 .001 0ZM12 8a4 4 0 1 0 .001 0ZM12 11.5a.5.5 0 1 0 .001 0",
  file: "M6 3h9l5 5v13H6V3Z",
  "bar-chart": "M5 20V10M12 20V4M19 20v-7",
  globe: "M12 3a9 9 0 1 0 .001 0ZM3 12h18M12 3c2.5 2.6 4 6 4 9s-1.5 6.4-4 9c-2.5-2.6-4-6-4-9s1.5-6.4 4-9Z",
  settings:
    "M12 15a3 3 0 1 0 .001 0ZM19.4 13a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.04 1.56V19a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 8.94 17.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.58 13 1.7 1.7 0 0 0 3 12h-.09a2 2 0 1 1 0-4H3a1.7 1.7 0 0 0 1.6-1.04 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 3.6 1.7 1.7 0 0 0 10.04 2H10a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.04 1.56 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 8c.18.64.79 1 1.6 1h.09a2 2 0 1 1 0 4H21a1.7 1.7 0 0 0-1.6 1Z",
  user: "M12 12a4 4 0 1 0 .001 0ZM4 20a8 8 0 0 1 16 0",
  "help-circle": "M12 3a9 9 0 1 0 .001 0ZM9.5 9a2.5 2.5 0 0 1 4.9.8c0 1.7-2.4 2-2.4 3.7M12 17.2h.01",
  lock: "M4 11h16v9H4v-9Zm3-4a5 5 0 0 1 10 0v4H7V7Z",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  menu: "M4 6h16M4 12h16M4 18h16",
  close: "M6 6l12 12M18 6L6 18",
  bell: "M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9ZM13.7 21a2 2 0 0 1-3.4 0",
  "chevron-down": "M6 9l6 6 6-6",
  sun: "M12 4V2M12 22v-2M4 12H2M22 12h-2M5 5 3.6 3.6M20.4 20.4 19 19M5 19l-1.4 1.4M20.4 3.6 19 5M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z",
  moon: "M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z",
};

export default function Icon({ name, size = 18, className = "" }) {
  const d = paths[name];
  if (!d) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d={d} />
    </svg>
  );
}
