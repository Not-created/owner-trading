import { useEffect, useState } from "react";
import Icon from "../common/Icon";

const STORAGE_KEY = "owner-trading-theme";

export default function ThemeToggle({ compact = false }) {
  const [theme, setTheme] = useState(() => {
    if (typeof window === "undefined") return "light";
    return window.localStorage.getItem(STORAGE_KEY) === "dark" ? "dark" : "light";
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);

  const nextTheme = theme === "dark" ? "light" : "dark";
  return (
    <button type="button" className={`theme-toggle ${compact ? "theme-toggle--compact" : ""}`} onClick={() => setTheme(nextTheme)} aria-label={`Switch to ${nextTheme} mode`} title={`Switch to ${nextTheme} mode`}>
      <span className={`theme-toggle__option ${theme === "light" ? "theme-toggle__option--active" : ""}`}><Icon name="sun" size={15} /></span>
      <span className={`theme-toggle__option ${theme === "dark" ? "theme-toggle__option--active" : ""}`}><Icon name="moon" size={15} /></span>
    </button>
  );
}
