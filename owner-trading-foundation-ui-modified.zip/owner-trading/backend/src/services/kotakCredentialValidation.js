/**
 * Format-only validation for Kotak credential submission -- mirrors the
 * spirit of the SDK's own req_data_validation.py (reject obviously-wrong
 * input before making a network call), but these are OUR format checks,
 * not anything the SDK itself enforces; the real validity check is the
 * actual totp_login/totp_validate call in the broker service.
 */
function validateCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret }) {
  if (!consumerKey || typeof consumerKey !== "string" || consumerKey.trim().length === 0) {
    return "Consumer Key is required.";
  }
  if (!mobileNumber || !/^\d{10}$/.test(mobileNumber)) {
    return "Mobile number must be exactly 10 digits.";
  }
  if (!ucc || typeof ucc !== "string" || ucc.trim().length === 0) {
    return "UCC / Client Code is required.";
  }
  if (!mpin || !/^\d{4,6}$/.test(mpin)) {
    return "MPIN must be 4-6 digits.";
  }
  if (!totpSecret || typeof totpSecret !== "string" || totpSecret.trim().length < 8) {
    return "TOTP secret is required (the setup key from your authenticator app, not a 6-digit code).";
  }
  return null; // no error
}

module.exports = { validateCredentials };
