"""Minimal async HTTP server, stdlib-only (asyncio streams -- no aiohttp/
FastAPI dependency), so the broker service has zero extra pip packages
beyond the official SDK itself. It runs on the SAME event loop that will
host the WebSocket manager (next phase), rather than spinning up a second
process or a blocking thread per request -- satisfying "do not create a new
Python process for every market-data request" at the transport level too.

Bound to config.host (127.0.0.1 by default) -- never exposed publicly (see
deployment/nginx, which never proxies to this port). No auth of its own:
this interface is trusted only because it is unreachable from outside the
host; the real user-facing auth boundary is the Express session layer.

Endpoints:
  GET  /health       -> liveness only
  GET  /status        -> broker connection state (never fabricated)
  POST /credentials   -> save Kotak credentials (in-memory only, see credential_manager.py)
  POST /test           -> test_connection(): real auth attempt, immediately logged back out, state machine untouched
  POST /connect        -> connect(): real auth attempt, persists session + state on success
  POST /disconnect     -> disconnect(): drops the active session
  POST /reconnect      -> disconnect() then connect()

Request/response bodies are JSON. Credential values are never logged --
see the explicit avoidance of logging `body` anywhere below.
"""
from __future__ import annotations

import asyncio
import json
import logging

from .config import config
from .state import current_state, BrokerState

logger = logging.getLogger("owner_trading.server")

MAX_BODY_BYTES = 8192  # credential payloads are tiny; reject anything larger


def _json_response(status_code: int, payload: dict) -> bytes:
    body = json.dumps(payload).encode("utf-8")
    status_text = {
        200: "OK", 400: "Bad Request", 404: "Not Found",
        405: "Method Not Allowed", 500: "Internal Server Error",
    }.get(status_code, "Error")
    headers = (
        f"HTTP/1.1 {status_code} {status_text}\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    )
    return headers.encode("utf-8") + body


async def _read_headers(reader: asyncio.StreamReader) -> dict:
    headers = {}
    while True:
        line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not line or line in (b"\r\n", b"\n"):
            break
        if b":" in line:
            name, _, value = line.partition(b":")
            headers[name.decode("latin-1").strip().lower()] = value.decode("latin-1").strip()
    return headers


async def _read_json_body(reader: asyncio.StreamReader, headers: dict) -> dict:
    length = int(headers.get("content-length", "0") or "0")
    if length <= 0:
        return {}
    if length > MAX_BODY_BYTES:
        raise ValueError("Request body too large.")
    raw = await asyncio.wait_for(reader.readexactly(length), timeout=10)
    if not raw:
        return {}
    parsed = json.loads(raw.decode("utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("Request body must be a JSON object.")
    return parsed


def _require_fields(body: dict, fields: list[str]) -> str | None:
    for f in fields:
        if not body.get(f):
            return f"Missing required field: {f}"
    return None


async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    from .broker_client import broker_client  # local import avoids a cycle at module load

    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not request_line:
            writer.close()
            return

        parts = request_line.decode("latin-1").strip().split(" ")
        method, path = (parts[0], parts[1]) if len(parts) >= 2 else ("", "")
        headers = await _read_headers(reader)

        if method == "GET" and path == "/health":
            writer.write(_json_response(200, {"status": "ok"}))

        elif method == "GET" and path == "/status":
            writer.write(_json_response(200, current_state.as_dict()))

        elif method == "GET" and path == "/credentials/status":
            from .credential_manager import credential_manager

            writer.write(_json_response(200, credential_manager.masked_summary()))

        elif method == "POST" and path == "/credentials":
            try:
                body = await _read_json_body(reader, headers)
            except (ValueError, json.JSONDecodeError) as exc:
                writer.write(_json_response(400, {"error": str(exc)}))
                await writer.drain()
                return
            missing = _require_fields(body, ["consumerKey", "mobileNumber", "ucc", "mpin", "totpSecret"])
            if missing:
                writer.write(_json_response(400, {"error": missing}))
            else:
                from .credential_manager import credential_manager

                credential_manager.set(
                    consumer_key=body["consumerKey"],
                    mobile_number=body["mobileNumber"],
                    ucc=body["ucc"],
                    mpin=body["mpin"],
                    totp_secret=body["totpSecret"],
                )
                # Credentials were just saved but no connection has been
                # attempted yet -- move off NOT_CONFIGURED to DISCONNECTED
                # (credentials exist, but that is explicitly NOT the same
                # as CONNECTED); leave any other existing state untouched.
                if current_state.state == BrokerState.NOT_CONFIGURED:
                    current_state.transition(BrokerState.DISCONNECTED)
                writer.write(_json_response(200, {"success": True}))

        elif method == "POST" and path == "/test":
            result = await broker_client.test_connection()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/connect":
            result = await broker_client.connect()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/disconnect":
            result = await broker_client.disconnect()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/reconnect":
            result = await broker_client.reconnect()
            writer.write(_json_response(200, result))

        elif method not in ("GET", "POST"):
            writer.write(_json_response(405, {"error": "Method not allowed"}))
        else:
            writer.write(_json_response(404, {"error": "Not found"}))

        await writer.drain()
    except (asyncio.TimeoutError, ConnectionError) as exc:
        logger.debug("Client connection dropped: %s", exc)
    except Exception as exc:  # noqa: BLE001 -- never crash the server loop on a bad request
        logger.warning("Unhandled error serving request: %s", exc)
        try:
            writer.write(_json_response(500, {"error": "Internal server error."}))
            await writer.drain()
        except Exception:  # noqa: BLE001
            pass
    finally:
        writer.close()


async def run_server() -> None:
    server = await asyncio.start_server(_handle_client, config.host, config.port)
    addr = server.sockets[0].getsockname() if server.sockets else (config.host, config.port)
    logger.info("Broker service HTTP interface listening on %s:%s", *addr[:2])
    async with server:
        await server.serve_forever()
