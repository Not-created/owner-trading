"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express.
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")


def _determine_initial_state() -> None:
    """Sets the correct starting state WITHOUT attempting to connect --
    startup never authenticates automatically, only GET /connect does (and
    only Express calling it on the owner's explicit action triggers that).

    If env-provided credentials are fully present (the persistent
    /etc/owner-trading/broker.env path), they're loaded into the same
    CredentialManager the Settings UI writes to -- otherwise a
    fully-configured broker.env would be silently unusable for /connect,
    since credential_manager (not config.py) is what connect() actually
    reads from.
    """
    from .credential_manager import credential_manager

    if not broker_client_module.SDK_AVAILABLE:
        current_state.transition(
            BrokerState.CONNECTION_ERROR,
            "kotakneoapi SDK is not installed in this environment.",
        )
        logger.warning("kotakneoapi is not importable -- broker service running in degraded mode.")
        return

    if config.is_fully_configured():
        credential_manager.set(
            consumer_key=config.consumer_key,
            mobile_number=config.mobile_number,
            ucc=config.ucc,
            mpin=config.mpin,
            totp_secret=config.totp_secret,
        )
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials loaded from environment. Broker state: DISCONNECTED (call /connect to authenticate).")
    else:
        current_state.transition(BrokerState.NOT_CONFIGURED)
        logger.info("Kotak credentials are not configured. Broker state: NOT_CONFIGURED.")


async def _main() -> None:
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())

    await stop_event.wait()
    server_task.cancel()
    try:
        await server_task
    except asyncio.CancelledError:
        pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
