"""In-memory holder for Kotak credentials submitted via the Settings UI.

Design decision for this phase: credentials submitted through the "Save"
action are held ONLY in this process's memory, for the broker-service
process's lifetime -- never written to disk, never logged, never echoed
back to any API response. This is a deliberate, documented tradeoff: a
broker-service restart requires re-saving credentials (or the operator can
still populate /etc/owner-trading/broker.env for the env-var path that
config.py already reads at startup, which IS the persistent option). This
module is the ONLY thing allowed to hold the raw values.

TOTP: the official SDK's own dependency list (kotakneoapi's package
metadata, confirmed during the earlier SDK audit) includes `pyotp` --
strong, source-grounded evidence that the intended integration pattern is
storing the TOTP *secret* (the seed used to set up an authenticator app)
once, and generating a fresh 6-digit code at each login attempt via
`pyotp.TOTP(secret).now()`, rather than requiring a human to type a live
code on every single connect/reconnect. This module stores the secret; the
current numeric code is generated on demand in broker_client.py and is
never itself persisted or logged.
"""
from __future__ import annotations

from dataclasses import dataclass

try:
    import pyotp

    PYOTP_AVAILABLE = True
except ImportError:
    # Same offline-degrade pattern as the NeoAPI import in broker_client.py
    # -- pyotp ships as a transitive dependency of kotakneoapi, so it is
    # only actually importable once that package is installed.
    pyotp = None
    PYOTP_AVAILABLE = False


@dataclass
class KotakCredentials:
    consumer_key: str
    mobile_number: str
    ucc: str
    mpin: str
    totp_secret: str


class CredentialManager:
    def __init__(self) -> None:
        self._creds: KotakCredentials | None = None

    def set(self, *, consumer_key: str, mobile_number: str, ucc: str, mpin: str, totp_secret: str) -> None:
        self._creds = KotakCredentials(
            consumer_key=consumer_key, mobile_number=mobile_number, ucc=ucc, mpin=mpin, totp_secret=totp_secret
        )

    def get(self) -> KotakCredentials | None:
        return self._creds

    def current_totp_code(self) -> str | None:
        """Generates the live 6-digit TOTP code from the stored secret.
        Returns None if no secret is stored or pyotp isn't installed --
        callers must treat that as "cannot authenticate right now", never
        substitute a fake code.
        """
        if self._creds is None or not self._creds.totp_secret:
            return None
        if not PYOTP_AVAILABLE:
            return None
        return pyotp.TOTP(self._creds.totp_secret).now()

    def has_base_credentials(self) -> bool:
        c = self._creds
        return bool(c and c.consumer_key and c.mobile_number and c.ucc and c.mpin and c.totp_secret)

    def clear(self) -> None:
        self._creds = None

    def masked_summary(self) -> dict:
        """Safe-to-return summary for status endpoints -- never the actual
        values, only whether they're present and a masked hint."""
        from .secure_store import redact

        c = self._creds
        if c is None:
            return {"configured": False}
        return {
            "configured": True,
            "consumerKey": redact(c.consumer_key),
            "mobileNumber": redact(c.mobile_number),
            "ucc": redact(c.ucc),
            "totpConfigured": bool(c.totp_secret),
        }


# Module-level singleton -- one broker service process, one credential set.
credential_manager = CredentialManager()
