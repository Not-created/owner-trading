"""Thin wrapper around the official `kotakneoapi` SDK's `NeoAPI` facade.

Method names and call shapes here are verified against the audited
Kotak-Neo/kotak-neo-python source (main branch, v3.0.6) kept read-only at
/home/claude/kotak-neo-sdk-reference in the assistant's workspace during
that audit -- NOT against the legacy v2 `kotak-neo-api-v2` client, and NOT
against invented/guessed method names.

IMPORTANT: authentication (connect/test_connection) now makes REAL calls to
the official SDK's totp_login/totp_validate -- but ONLY when explicitly
invoked via the Express -> broker-service /connect or /test routes, which
in turn only fire when the owner submits credentials through the Settings
UI and clicks Connect/Test. Nothing here runs automatically on startup, and
no route anywhere calls these implicitly.
"""
from __future__ import annotations

import asyncio

from .config import config
from .state import BrokerState, current_state

try:
    from neo_api_client import NeoAPI  # official SDK, package name "kotakneoapi"

    SDK_AVAILABLE = True
except ImportError:
    # Expected in this phase's offline validation (no network to `pip
    # install kotakneoapi`) -- the real VPS deploy installs it via
    # requirements.txt. The service must still start and report a clear
    # state rather than crash.
    NeoAPI = None
    SDK_AVAILABLE = False


class NotConfiguredError(RuntimeError):
    """Raised by any broker-calling method when credentials are missing or
    no session has been established. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """Raised when an order-placing method is reached while LIVE trading
    isn't genuinely allowed. Defense in depth: the Express backend's
    requireLiveTradingAllowed middleware is the primary gate; this is the
    same rule enforced independently on the Python side, so a bug in one
    layer can't silently let an order through.
    """


def assert_live_trading_allowed() -> None:
    from .state import BrokerState as _BrokerState  # local import avoids a cycle at module load
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("TRADING_MODE is not LIVE on this deployment.")
    if _db.is_emergency_stop_active():
        raise LiveTradingBlockedError("Emergency stop is active.")
    if current_state.state != _BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")


class BrokerClient:
    """Owns exactly one `NeoAPI` instance for the process lifetime -- the
    persistent Python service is not restarted per request, per the
    architecture requirement that a new process must not be spawned for
    every market-data request.
    """

    def __init__(self) -> None:
        self._neo: "NeoAPI | None" = None

    # ---------------------------------------------------------------- #
    # Authentication -- REAL implementation, gated on this being explicitly
    # invoked via /connect (never on startup, never implicitly).
    #
    # Call shape verified against the audited Kotak-Neo/kotak-neo-python
    # source (main, v3.0.6): NeoAPI(consumer_key=..., environment=...) ->
    # totp_login(mobile_number=..., ucc=..., totp=...) ->
    # totp_validate(mpin=...). Success/failure detection matches the
    # audited behavior of neo_api.py: a successful call returns a dict
    # containing a truthy "data" key; the SDK itself stores
    # edit_token/edit_sid/data_center onto NeoAPI.configuration (a
    # NeoUtility instance) once totp_validate succeeds -- checking those
    # attributes directly (not just the response dict) is how the audited
    # SDK's own trading methods decide whether a session is usable, so
    # that's the same bar used here for "verified and usable" per this
    # phase's requirement.
    # ---------------------------------------------------------------- #
    def is_ready_to_authenticate(self) -> bool:
        return SDK_AVAILABLE and config.is_fully_configured()

    async def connect(self) -> dict:
        """Performs the real two-step Kotak auth flow and, on success,
        keeps the resulting NeoAPI instance alive on self._neo for
        subsequent market-data/order calls. Transitions the shared state
        machine; never marks CONNECTED unless edit_token/edit_sid are
        genuinely present on the SDK's own configuration object afterward.
        """
        from . import credential_manager as credential_manager_module
        from .credential_manager import credential_manager
        from . import db as _db

        if not SDK_AVAILABLE:
            current_state.transition(
                BrokerState.CONNECTION_ERROR, "kotakneoapi SDK is not installed in this environment."
            )
            return current_state.as_dict()

        creds = credential_manager.get()
        if not credential_manager.has_base_credentials():
            current_state.transition(BrokerState.NOT_CONFIGURED, "Credentials have not been saved yet.")
            return current_state.as_dict()

        totp = credential_manager.current_totp_code()
        if not totp:
            reason = (
                "pyotp is not installed in this environment (transitive kotakneoapi dependency)."
                if not credential_manager_module.PYOTP_AVAILABLE
                else "No TOTP secret is saved."
            )
            current_state.transition(BrokerState.AUTH_FAILED, f"Could not generate a TOTP code: {reason}")
            return current_state.as_dict()

        current_state.transition(BrokerState.VERIFYING)
        loop = asyncio.get_running_loop()
        try:
            neo = NeoAPI(consumer_key=creds.consumer_key, environment=config.environment)
            # totp_login/totp_validate are SYNCHRONOUS in the audited SDK
            # (blocking httpx calls) -- run them off the event loop so a
            # slow/hanging Kotak response can't stall the whole persistent
            # service (including any concurrent WebSocket handling).
            login_resp = await loop.run_in_executor(
                None, lambda: neo.totp_login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp)
            )
        except Exception as exc:  # noqa: BLE001 -- any transport/SDK-level failure here is a connection error, not an auth rejection
            current_state.transition(BrokerState.CONNECTION_ERROR, f"totp_login request failed: {exc}")
            return current_state.as_dict()

        if not isinstance(login_resp, dict) or not login_resp.get("data"):
            current_state.transition(BrokerState.AUTH_FAILED, f"totp_login rejected: {login_resp}")
            return current_state.as_dict()

        try:
            validate_resp = await loop.run_in_executor(None, lambda: neo.totp_validate(mpin=creds.mpin))
        except Exception as exc:  # noqa: BLE001
            current_state.transition(BrokerState.CONNECTION_ERROR, f"totp_validate request failed: {exc}")
            return current_state.as_dict()

        if not isinstance(validate_resp, dict) or not validate_resp.get("data"):
            current_state.transition(BrokerState.AUTH_FAILED, f"totp_validate rejected: {validate_resp}")
            return current_state.as_dict()

        cfg = getattr(neo, "configuration", None)
        edit_token = getattr(cfg, "edit_token", None) if cfg else None
        edit_sid = getattr(cfg, "edit_sid", None) if cfg else None
        if not (edit_token and edit_sid):
            # The SDK reported success but didn't leave a usable session --
            # per this phase's rule, that is NOT "CONNECTED".
            current_state.transition(
                BrokerState.AUTH_FAILED,
                "totp_validate reported success but no usable session (edit_token/edit_sid) was established.",
            )
            return current_state.as_dict()

        self._neo = neo
        data_center = getattr(cfg, "data_center", None)
        from . import session as _session

        _session.mark_session_established(data_center)
        _db.record_reconciliation(
            reconciliation_type="connect", reference_id=creds.ucc, discrepancy_found=False,
            details={"data_center": data_center},
        )
        return current_state.as_dict()

    async def test_connection(self) -> dict:
        """Performs the same real two-step flow to genuinely verify the
        saved credentials, then immediately logs the test session back out
        (SDK's own logout() -- audited as LogoutAPI.logging_out) rather
        than keeping it. Deliberately does NOT transition the persisted
        broker_connection_state -- test and connect are kept separate per
        this phase's requirement, so a test never makes the dashboard show
        CONNECTED.
        """
        from . import credential_manager as credential_manager_module
        from .credential_manager import credential_manager

        if not SDK_AVAILABLE:
            return {"success": False, "error": "kotakneoapi SDK is not installed in this environment."}

        creds = credential_manager.get()
        if not credential_manager.has_base_credentials():
            return {"success": False, "error": "Credentials have not been saved yet."}

        totp = credential_manager.current_totp_code()
        if not totp:
            reason = (
                "pyotp is not installed in this environment."
                if not credential_manager_module.PYOTP_AVAILABLE
                else "No TOTP secret is saved."
            )
            return {"success": False, "error": f"Could not generate a TOTP code: {reason}"}

        loop = asyncio.get_running_loop()
        try:
            neo = NeoAPI(consumer_key=creds.consumer_key, environment=config.environment)
            login_resp = await loop.run_in_executor(
                None, lambda: neo.totp_login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp)
            )
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "error": f"totp_login request failed: {exc}"}

        if not isinstance(login_resp, dict) or not login_resp.get("data"):
            return {"success": False, "error": f"totp_login rejected: {login_resp}"}

        try:
            validate_resp = await loop.run_in_executor(None, lambda: neo.totp_validate(mpin=creds.mpin))
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "error": f"totp_validate request failed: {exc}"}

        if not isinstance(validate_resp, dict) or not validate_resp.get("data"):
            return {"success": False, "error": f"totp_validate rejected: {validate_resp}"}

        try:
            await loop.run_in_executor(None, neo.logout)
        except Exception:  # noqa: BLE001 -- best-effort cleanup, test result already known
            pass

        return {"success": True}

    async def disconnect(self) -> dict:
        """Deliberate disconnect action (distinct from an involuntary
        SESSION_EXPIRED). Best-effort calls the SDK's own logout(), then
        always drops the local session regardless of whether that call
        succeeded -- a failed logout call must never leave the app still
        believing it holds a usable session.
        """
        if self._neo is not None:
            try:
                await asyncio.get_running_loop().run_in_executor(None, self._neo.logout)
            except Exception:  # noqa: BLE001
                pass
        self._neo = None

        from . import session as _session

        _session.current_session.established_at = None
        current_state.transition(BrokerState.DISCONNECTED)
        return current_state.as_dict()

    async def reconnect(self) -> dict:
        await self.disconnect()
        return await self.connect()

    # ---------------------------------------------------------------- #
    # Market data foundation (method names verified against audited SDK)
    # ---------------------------------------------------------------- #
    def quotes(self, *args, **kwargs):
        self._require_connected()
        return self._neo.quotes(*args, **kwargs)

    def scrip_master(self, *args, **kwargs):
        self._require_connected()
        return self._neo.scrip_master(*args, **kwargs)

    def search_scrip(self, *args, **kwargs):
        self._require_connected()
        return self._neo.search_scrip(*args, **kwargs)

    def expiries(self, *args, **kwargs):
        self._require_connected()
        return self._neo.expiries(*args, **kwargs)

    def option_chain(self, *args, **kwargs):
        self._require_connected()
        return self._neo.option_chain(*args, **kwargs)

    def historical_data(self, *args, **kwargs):
        self._require_connected()
        return self._neo.historical_data(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Order foundation
    # ---------------------------------------------------------------- #
    def place_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        # Deliberately not called anywhere yet -- no order route exists in
        # this phase, and both safety gates above (Express middleware +
        # this Python-side assertion) must pass before this line is ever
        # reached.
        return self._neo.place_order(*args, **kwargs)

    def modify_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.modify_order(*args, **kwargs)

    def cancel_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.cancel_order(*args, **kwargs)

    def order_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_report(*args, **kwargs)

    def order_history(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_history(*args, **kwargs)

    def trade_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.trade_report(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Portfolio foundation
    # ---------------------------------------------------------------- #
    def positions(self, *args, **kwargs):
        self._require_connected()
        return self._neo.positions(*args, **kwargs)

    def holdings(self, *args, **kwargs):
        self._require_connected()
        return self._neo.holdings(*args, **kwargs)

    def limits(self, *args, **kwargs):
        self._require_connected()
        return self._neo.limits(*args, **kwargs)

    def margin_required(self, *args, **kwargs):
        self._require_connected()
        return self._neo.margin_required(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # WebSocket foundation -- current SDK factory methods only.
    # Deliberately NOT using the legacy subscribe()/un_subscribe()/
    # subscribe_to_orderfeed() stubs identified as obsolete in the SDK audit.
    # ---------------------------------------------------------------- #
    def create_market_feed(self, **kwargs):
        """Would call self._neo.create_websocket(**kwargs) and return an
        SFeedWebSocket, then subscribe_scrips()/unsubscribe_scrips() per
        instrument -- see websocket_manager.py for the subscription
        registry this plugs into. Not invoked this phase.
        """
        self._require_connected()
        return self._neo.create_websocket(**kwargs)

    def create_order_feed(self, **kwargs):
        """Would call self._neo.create_order_feed(**kwargs). Not invoked
        this phase."""
        self._require_connected()
        return self._neo.create_order_feed(**kwargs)

    # ---------------------------------------------------------------- #
    def _require_connected(self) -> None:
        if current_state.state != BrokerState.CONNECTED or self._neo is None:
            raise NotConfiguredError(
                f"Broker is not connected (state: {current_state.state.value})."
            )


# Module-level singleton -- one broker client per persistent process.
broker_client = BrokerClient()
