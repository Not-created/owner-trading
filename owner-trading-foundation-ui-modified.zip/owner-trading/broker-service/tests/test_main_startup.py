"""Tests for app/main.py's startup state-determination logic, in
particular the env-var -> credential_manager bridge added in Phase 1.
Mocks only the SDK-availability boundary (same pattern as
test_kotak_auth.py) so the actual bridging logic is exercised for real.
"""
from __future__ import annotations

import unittest
from unittest.mock import patch

from app import main as main_module
from app import broker_client as bc_module
from app import credential_manager as cm_module
from app.config import Config
from app.state import BrokerState, current_state


class InitialStateTests(unittest.TestCase):
    def setUp(self):
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()

    def test_sdk_unavailable_short_circuits_to_connection_error(self):
        with patch.object(bc_module, "SDK_AVAILABLE", False):
            main_module._determine_initial_state()
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)
        self.assertFalse(cm_module.credential_manager.has_base_credentials())

    def test_no_env_credentials_reports_not_configured(self):
        empty_config = Config(
            consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None
        )
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(main_module, "config", empty_config):
            main_module._determine_initial_state()
        self.assertEqual(current_state.state, BrokerState.NOT_CONFIGURED)

    def test_full_env_credentials_load_into_credential_manager_but_stay_disconnected(self):
        """The core bridge this test guards: a fully-configured
        broker.env must end up usable by connect() (i.e. present in
        credential_manager) -- but startup must NEVER itself claim
        CONNECTED just because credentials exist.
        """
        full_config = Config(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", totp_secret="SECRET", mpin="1234"
        )
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(main_module, "config", full_config):
            main_module._determine_initial_state()

        self.assertEqual(current_state.state, BrokerState.DISCONNECTED)
        self.assertTrue(cm_module.credential_manager.has_base_credentials())
        loaded = cm_module.credential_manager.get()
        self.assertEqual(loaded.consumer_key, "ck")
        self.assertEqual(loaded.ucc, "ABC123")


if __name__ == "__main__":
    unittest.main()
