"""Tests for BrokerClient's real connect()/test_connection()/disconnect()
logic (Phase 1).

These tests mock ONLY the boundary that requires a real network call to
Kotak -- the NeoAPI class itself -- so that our OWN response-handling logic
(success/failure detection, state transitions, session verification) is
exercised exactly as it runs in production. This is standard unit-testing
practice for an external-API boundary, NOT fabricated broker data: no test
here asserts or displays a fake "Kotak said X" to a user -- they check that
*our code* reacts correctly to a given SDK response shape. Real,
credential-driven authentication against the live Kotak Neo service is
explicitly NOT exercised here and is NOT VERIFIED by this suite -- see the
project's final report for what that requires.

Run from broker-service/:  python -m unittest tests.test_kotak_auth -v
"""
from __future__ import annotations

import asyncio
import unittest
from unittest.mock import MagicMock, patch

from app import broker_client as bc_module
from app import credential_manager as cm_module
from app.state import BrokerState, current_state


def _run(coro):
    return asyncio.run(coro)


class ConnectFlowTests(unittest.TestCase):
    def setUp(self):
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()
        self.client = bc_module.BrokerClient()

    def _save_valid_credentials(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret="SECRET"
        )

    def test_connect_reports_not_configured_when_no_credentials_saved(self):
        with patch.object(bc_module, "SDK_AVAILABLE", True):
            result = _run(self.client.connect())
        self.assertEqual(result["state"], "NOT_CONFIGURED")

    def test_connect_reports_connection_error_when_sdk_unavailable(self):
        self._save_valid_credentials()
        with patch.object(bc_module, "SDK_AVAILABLE", False):
            result = _run(self.client.connect())
        self.assertEqual(result["state"], "CONNECTION_ERROR")

    def test_connect_success_path_reaches_connected_only_with_real_session_tokens(self):
        """Simulates a Kotak response shape matching the audited SDK: a
        truthy "data" key on both calls, AND edit_token/edit_sid present on
        neo.configuration afterward (exactly what the real SDK sets, per
        the earlier source audit) -- only then may state become CONNECTED.
        """
        self._save_valid_credentials()
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"data": {"token": "view"}}
        fake_neo.totp_validate.return_value = {"data": {"token": "edit"}}
        fake_neo.configuration.edit_token = "EDIT_TOKEN"
        fake_neo.configuration.edit_sid = "EDIT_SID"
        fake_neo.configuration.data_center = "e21"

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.connect())

        self.assertEqual(result["state"], "CONNECTED")
        fake_neo.totp_login.assert_called_once_with(mobile_number="9999999999", ucc="ABC123", totp="123456")
        fake_neo.totp_validate.assert_called_once_with(mpin="1234")

    def test_connect_reports_auth_failed_when_login_rejected(self):
        self._save_valid_credentials()
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"error": "invalid totp"}

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.connect())

        self.assertEqual(result["state"], "AUTH_FAILED")
        fake_neo.totp_validate.assert_not_called()

    def test_connect_reports_auth_failed_when_validate_rejected(self):
        self._save_valid_credentials()
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"data": {"token": "view"}}
        fake_neo.totp_validate.return_value = {"error": "wrong mpin"}

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.connect())

        self.assertEqual(result["state"], "AUTH_FAILED")

    def test_connect_reports_auth_failed_when_sdk_claims_success_but_no_session_tokens(self):
        self._save_valid_credentials()
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"data": {"token": "view"}}
        fake_neo.totp_validate.return_value = {"data": {"token": "edit"}}
        fake_neo.configuration.edit_token = None
        fake_neo.configuration.edit_sid = None

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.connect())

        self.assertEqual(result["state"], "AUTH_FAILED")

    def test_connect_reports_connection_error_on_transport_exception(self):
        self._save_valid_credentials()
        fake_neo = MagicMock()
        fake_neo.totp_login.side_effect = ConnectionError("network unreachable")

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.connect())

        self.assertEqual(result["state"], "CONNECTION_ERROR")

    def test_connect_reports_not_configured_when_totp_secret_missing(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret=""
        )
        with patch.object(bc_module, "SDK_AVAILABLE", True):
            result = _run(self.client.connect())
        self.assertEqual(result["state"], "NOT_CONFIGURED")


class TestConnectionTests(unittest.TestCase):
    def setUp(self):
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()
        self.client = bc_module.BrokerClient()

    def test_test_connection_never_mutates_persisted_state(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret="SECRET"
        )
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"data": {"token": "view"}}
        fake_neo.totp_validate.return_value = {"data": {"token": "edit"}}

        state_before = current_state.state
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.test_connection())

        self.assertTrue(result["success"])
        self.assertEqual(current_state.state, state_before)
        fake_neo.logout.assert_called_once()

    def test_test_connection_reports_failure_without_raising(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret="SECRET"
        )
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"error": "bad totp"}

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.test_connection())

        self.assertFalse(result["success"])
        self.assertIn("error", result)


class DisconnectReconnectTests(unittest.TestCase):
    def setUp(self):
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()
        self.client = bc_module.BrokerClient()

    def test_disconnect_with_no_active_session_still_transitions_to_disconnected(self):
        result = _run(self.client.disconnect())
        self.assertEqual(result["state"], "DISCONNECTED")

    def test_disconnect_calls_logout_and_clears_session_even_if_logout_raises(self):
        fake_neo = MagicMock()
        fake_neo.logout.side_effect = RuntimeError("network blip")
        self.client._neo = fake_neo

        result = _run(self.client.disconnect())

        fake_neo.logout.assert_called_once()
        self.assertIsNone(self.client._neo)
        self.assertEqual(result["state"], "DISCONNECTED")

    def test_reconnect_disconnects_then_connects(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret="SECRET"
        )
        fake_neo = MagicMock()
        fake_neo.totp_login.return_value = {"data": {"token": "view"}}
        fake_neo.totp_validate.return_value = {"data": {"token": "edit"}}
        fake_neo.configuration.edit_token = "T"
        fake_neo.configuration.edit_sid = "S"
        fake_neo.configuration.data_center = "e21"

        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(
            bc_module, "NeoAPI", return_value=fake_neo
        ), patch.object(cm_module, "PYOTP_AVAILABLE", True), patch.object(cm_module, "pyotp") as mock_pyotp:
            mock_pyotp.TOTP.return_value.now.return_value = "123456"
            result = _run(self.client.reconnect())

        self.assertEqual(result["state"], "CONNECTED")


class CredentialManagerTests(unittest.TestCase):
    def setUp(self):
        cm_module.credential_manager.clear()

    def test_has_base_credentials_false_when_empty(self):
        self.assertFalse(cm_module.credential_manager.has_base_credentials())

    def test_has_base_credentials_true_when_all_fields_present(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="m", ucc="u", mpin="1234", totp_secret="SECRET"
        )
        self.assertTrue(cm_module.credential_manager.has_base_credentials())

    def test_current_totp_code_none_when_no_secret(self):
        cm_module.credential_manager.set(consumer_key="ck", mobile_number="m", ucc="u", mpin="1234", totp_secret="")
        self.assertIsNone(cm_module.credential_manager.current_totp_code())

    def test_current_totp_code_none_when_pyotp_unavailable(self):
        cm_module.credential_manager.set(
            consumer_key="ck", mobile_number="m", ucc="u", mpin="1234", totp_secret="SECRET"
        )
        with patch.object(cm_module, "PYOTP_AVAILABLE", False):
            self.assertIsNone(cm_module.credential_manager.current_totp_code())

    def test_masked_summary_never_exposes_raw_values(self):
        cm_module.credential_manager.set(
            consumer_key="supersecretkey", mobile_number="9999999999", ucc="ABC123", mpin="1234", totp_secret="SECRET"
        )
        summary = cm_module.credential_manager.masked_summary()
        dumped = str(summary)
        self.assertNotIn("supersecretkey", dumped)
        self.assertNotIn("1234", dumped)
        self.assertNotIn("SECRET", dumped)


if __name__ == "__main__":
    unittest.main()
