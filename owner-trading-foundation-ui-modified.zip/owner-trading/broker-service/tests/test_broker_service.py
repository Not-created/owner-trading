"""Offline test suite for the broker service foundation. Uses only the
standard library (unittest, asyncio) so it runs without `pip install`ing
anything -- including without the `kotakneoapi` SDK itself installed, since
app/broker_client.py is required to degrade gracefully rather than crash
when the SDK is absent (see SDK_AVAILABLE).

Run from broker-service/:  python -m unittest discover -v
"""
import asyncio
import json
import unittest

from app.config import Config
from app.state import BrokerState, StateHolder
from app import broker_client as broker_client_module
from app.broker_client import BrokerClient, NotConfiguredError
from app.websocket_manager import SubscriptionRegistry
from app.secure_store import redact


class ConfigTests(unittest.TestCase):
    def test_not_configured_when_credentials_missing(self):
        cfg = Config(
            consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None
        )
        self.assertFalse(cfg.is_fully_configured())

    def test_configured_when_all_present(self):
        cfg = Config(
            consumer_key="x", mobile_number="y", ucc="z", totp_secret="t", mpin="m"
        )
        self.assertTrue(cfg.is_fully_configured())

    def test_partial_credentials_not_configured(self):
        cfg = Config(consumer_key="x", mobile_number="y", ucc=None, totp_secret=None, mpin=None)
        self.assertFalse(cfg.is_fully_configured())


class StateMachineTests(unittest.TestCase):
    def test_default_state_is_not_configured(self):
        holder = StateHolder()
        self.assertEqual(holder.state, BrokerState.NOT_CONFIGURED)

    def test_transition_updates_state_and_error(self):
        holder = StateHolder()
        holder.transition(BrokerState.CONNECTION_ERROR, "unreachable")
        self.assertEqual(holder.state, BrokerState.CONNECTION_ERROR)
        self.assertEqual(holder.last_error, "unreachable")

    def test_as_dict_is_json_serializable(self):
        holder = StateHolder()
        holder.transition(BrokerState.VERIFYING)
        json.dumps(holder.as_dict())  # raises if not serializable

    def test_all_seven_required_states_exist(self):
        expected = {
            "DISCONNECTED", "VERIFYING", "CONNECTED", "AUTH_FAILED",
            "SESSION_EXPIRED", "CONNECTION_ERROR", "NOT_CONFIGURED",
        }
        actual = {s.value for s in BrokerState}
        self.assertEqual(expected, actual)


class BrokerClientTests(unittest.TestCase):
    def test_market_data_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("quotes", "scrip_master", "search_scrip", "expiries", "option_chain", "historical_data"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_order_placing_methods_blocked_by_live_gate_in_paper_mode(self):
        # TRADING_MODE defaults to PAPER, so the LIVE safety gate fires
        # before the "not connected" check even applies.
        client = BrokerClient()
        for method_name in ("place_order", "modify_order", "cancel_order"):
            with self.assertRaises(broker_client_module.LiveTradingBlockedError, msg=method_name):
                getattr(client, method_name)()

    def test_order_reporting_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("order_report", "order_history", "trade_report"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_portfolio_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("positions", "holdings", "limits", "margin_required"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_websocket_factories_raise_when_not_connected(self):
        client = BrokerClient()
        with self.assertRaises(NotConfiguredError):
            client.create_market_feed()
        with self.assertRaises(NotConfiguredError):
            client.create_order_feed()

    def test_connect_without_credentials_reports_not_configured(self):
        """connect() no longer raises for this phase -- it performs a real
        attempt and returns the resulting state. With nothing saved, that
        must be NOT_CONFIGURED (or CONNECTION_ERROR if the SDK itself isn't
        importable in this environment) -- never CONNECTED.
        """
        client = BrokerClient()

        async def run():
            result = await client.connect()
            self.assertIn(result["state"], ["NOT_CONFIGURED", "CONNECTION_ERROR"])
            self.assertNotEqual(result["state"], "CONNECTED")

        asyncio.run(run())

    def test_sdk_availability_flag_is_boolean(self):
        # Whatever the actual import outcome in this environment, the flag
        # must exist and be a bool -- broker_client.py must not crash the
        # whole module on ImportError.
        self.assertIsInstance(broker_client_module.SDK_AVAILABLE, bool)


class SubscriptionRegistryTests(unittest.TestCase):
    def test_add_remove_and_list(self):
        reg = SubscriptionRegistry()
        reg.add("TOKEN_A")
        reg.add("TOKEN_B")
        self.assertEqual(reg.all(), ["TOKEN_A", "TOKEN_B"])
        reg.remove("TOKEN_A")
        self.assertEqual(reg.all(), ["TOKEN_B"])

    def test_duplicate_add_is_idempotent(self):
        reg = SubscriptionRegistry()
        reg.add("TOKEN_A")
        reg.add("TOKEN_A")
        self.assertEqual(reg.all(), ["TOKEN_A"])


class SecureStoreTests(unittest.TestCase):
    def test_redact_empty(self):
        self.assertEqual(redact(None), "<empty>")
        self.assertEqual(redact(""), "<empty>")

    def test_redact_masks_all_but_last_two_chars(self):
        self.assertEqual(redact("ABCDEFGH"), "******GH")

    def test_redact_never_returns_the_original_for_a_real_looking_secret(self):
        secret = "super-secret-value-123"
        self.assertNotEqual(redact(secret), secret)


class ServerIntegrationTests(unittest.IsolatedAsyncioTestCase):
    """Actually starts the real asyncio server on an ephemeral local port
    and talks to it with a raw socket -- no mocking, no extra dependency.
    """

    async def asyncSetUp(self):
        from app.server import _handle_client  # noqa: PLC0415

        self.server = await asyncio.start_server(_handle_client, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]
        self._serve_task = asyncio.create_task(self.server.serve_forever())

    async def asyncTearDown(self):
        self._serve_task.cancel()
        self.server.close()
        await self.server.wait_closed()

    async def _get(self, path: str) -> tuple[int, dict]:
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        writer.write(f"GET {path} HTTP/1.1\r\nHost: localhost\r\n\r\n".encode())
        await writer.drain()
        raw = await asyncio.wait_for(reader.read(), timeout=5)
        writer.close()
        status_line, _, rest = raw.partition(b"\r\n")
        status_code = int(status_line.decode().split(" ")[1])
        _, _, body = rest.partition(b"\r\n\r\n")
        return status_code, json.loads(body.decode())

    async def test_health_endpoint(self):
        status, body = await self._get("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "ok"})

    async def test_status_endpoint_reflects_current_state(self):
        status, body = await self._get("/status")
        self.assertEqual(status, 200)
        self.assertIn("state", body)
        self.assertIn(body["state"], [s.value for s in BrokerState])

    async def test_unknown_path_is_404(self):
        status, _ = await self._get("/nope")
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
