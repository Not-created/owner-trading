import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMarketData } from '../api/client.js';

const POLL_MS = 3000;

export default function MarketDataPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    let active = true;
    let timer;

    async function load() {
      try {
        const next = await getMarketData();
        if (!active) return;
        setData(next);
        setError(null);
        setLastUpdated(new Date());
        const hasLive = next.symbols?.some((item) => item.mode === 'LIVE');
        timer = hasLive ? window.setTimeout(load, POLL_MS) : undefined;
      } catch (err) {
        if (!active) return;
        setError(err.message);
        timer = window.setTimeout(load, POLL_MS);
      } finally {
        if (active) setLoading(false);
      }
    }

    load();
    return () => {
      active = false;
      if (timer) window.clearTimeout(timer);
    };
  }, []);

  const hasLive = useMemo(() => data?.symbols?.some((item) => item.mode === 'LIVE'), [data]);
  const hasPaper = useMemo(() => data?.symbols?.some((item) => item.mode === 'PAPER'), [data]);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 760 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Market data</h1>

      {hasLive && (
        <p style={{ fontSize: '0.85em', color: '#0a5', background: '#edf9f0', border: '1px solid #5a6', borderRadius: 6, padding: '0.75rem' }}>
          <strong>LIVE market data.</strong> LIVE rows are fetched from the connected Kotak Neo
          account using the official quote API. The page refreshes every {POLL_MS / 1000} seconds;
          this is REST polling, not a WebSocket tick stream.
        </p>
      )}
      {!hasLive && hasPaper && (
        <p style={{ fontSize: '0.85em', color: '#765500', background: '#fff8e6', border: '1px solid #c9a227', borderRadius: 6, padding: '0.75rem' }}>
          <strong>PAPER market data.</strong> These rows use the built-in synthetic simulator and
          must never be treated as real market prices.
        </p>
      )}
      {hasLive && hasPaper && (
        <p style={{ fontSize: '0.8em', color: '#555' }}>
          PAPER rows remain synthetic; LIVE rows are broker-sourced. The two sources are never mixed.
        </p>
      )}

      {error && <p style={{ color: '#b00020' }}>Market data error: {error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && data && data.symbols.length === 0 && <p>No symbols yet — create a strategy first.</p>}
      {!loading && lastUpdated && <p style={{ fontSize: '0.75em', color: '#777' }}>Updated: {lastUpdated.toLocaleTimeString()}</p>}

      {!loading &&
        data &&
        data.symbols.map((s) => (
          <div key={`${s.symbol}-${s.mode}-${s.exchangeSegment}`} style={{ border: '1px solid #ddd', borderRadius: 6, padding: '1rem', marginBottom: '0.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'baseline' }}>
              <strong>{s.symbol}</strong>
              <span style={{ fontSize: '0.8em', fontWeight: 700 }}>{s.mode}</span>
            </div>
            <div style={{ marginTop: 6 }}>
              last: {s.price == null ? 'UNAVAILABLE' : s.price}
            </div>
            <div style={{ fontSize: '0.8em', color: '#777', marginTop: 4 }}>
              exchange: {s.exchangeSegment || '—'} · source: {s.simulated ? 'PAPER simulator' : 'Kotak Neo LIVE'}
            </div>
            {s.error && <div style={{ color: '#b00020', fontSize: '0.8em', marginTop: 6 }}>Error: {s.error}</div>}
            {s.history?.length > 1 && (
              <div style={{ fontSize: '0.75em', color: '#777', marginTop: 6, wordBreak: 'break-all' }}>
                recent: {s.history.slice(-15).join(', ')}
              </div>
            )}
          </div>
        ))}
    </main>
  );
}
