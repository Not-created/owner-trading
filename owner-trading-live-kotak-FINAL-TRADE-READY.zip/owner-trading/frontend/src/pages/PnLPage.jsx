import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getPnlSummary } from '../api/client.js';

function fmt(n) {
  if (n === null || n === undefined) return '—';
  return n.toFixed(2);
}

export default function PnLPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modeFilter, setModeFilter] = useState('PAPER');

  function load(mode) {
    setLoading(true);
    return getPnlSummary(mode || undefined)
      .then(setData)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load(modeFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modeFilter]);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 700 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>P&amp;L</h1>
        <select value={modeFilter} onChange={(e) => setModeFilter(e.target.value)}>
          <option value="PAPER">PAPER</option>
          <option value="LIVE">LIVE</option>
        </select>
      </div>

      {modeFilter === 'LIVE' && (
        <p style={{ fontSize: '0.85em', color: '#555' }}>
          LIVE unrealized P&amp;L is marked from the connected Kotak quote API. If the broker quote is
          unavailable, the value is shown as unknown rather than fabricated.
        </p>
      )}

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {loading && <p>Loading…</p>}

      {!loading && data && (
        <>
          <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
            <div style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, flex: 1 }}>
              <div style={{ fontSize: '0.8em', color: '#777' }}>Realized</div>
              <div style={{ fontSize: '1.3em', color: data.totals.realizedPnl >= 0 ? '#0a7d28' : '#b00020' }}>
                {fmt(data.totals.realizedPnl)}
              </div>
            </div>
            <div style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, flex: 1 }}>
              <div style={{ fontSize: '0.8em', color: '#777' }}>Unrealized</div>
              <div style={{ fontSize: '1.3em', color: data.totals.unrealizedPnl >= 0 ? '#0a7d28' : '#b00020' }}>
                {fmt(data.totals.unrealizedPnl)}
              </div>
            </div>
            <div style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, flex: 1 }}>
              <div style={{ fontSize: '0.8em', color: '#777' }}>Total</div>
              <div style={{ fontSize: '1.3em', color: data.totals.totalPnl >= 0 ? '#0a7d28' : '#b00020' }}>
                {fmt(data.totals.totalPnl)}
              </div>
            </div>
          </div>

          {data.positions.length === 0 && <p>No positions in this mode.</p>}
          {data.positions.length > 0 && (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9em' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
                  <th>Symbol</th>
                  <th>Qty</th>
                  <th>Avg price</th>
                  <th>Reference price</th>
                  <th>Realized</th>
                  <th>Unrealized</th>
                </tr>
              </thead>
              <tbody>
                {data.positions.map((p) => (
                  <tr key={p.id} style={{ borderBottom: '1px solid #eee' }}>
                    <td>{p.symbol}</td>
                    <td>{p.quantity}</td>
                    <td>{fmt(p.avg_price)}</td>
                    <td>{fmt(p.referencePrice)}</td>
                    <td style={{ color: p.realized_pnl >= 0 ? '#0a7d28' : '#b00020' }}>{fmt(p.realized_pnl)}</td>
                    <td style={{ color: (p.unrealizedPnl ?? 0) >= 0 ? '#0a7d28' : '#b00020' }}>
                      {fmt(p.unrealizedPnl)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </>
      )}
    </main>
  );
}
