import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listPositions, reconcileBrokerPositions } from '../api/client.js';

export default function PositionsPage() {
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modeFilter, setModeFilter] = useState('');
  const [brokerCheck, setBrokerCheck] = useState(null);
  const [checkingBroker, setCheckingBroker] = useState(false);

  function load(mode) {
    setLoading(true);
    return listPositions(mode || undefined)
      .then(setPositions)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  async function checkBroker() {
    setCheckingBroker(true);
    setError(null);
    try { setBrokerCheck(await reconcileBrokerPositions()); } catch (err) { setError(err.message); }
    finally { setCheckingBroker(false); }
  }

  useEffect(() => {
    load(modeFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modeFilter]);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 700 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>Positions</h1>
        <button onClick={checkBroker} disabled={checkingBroker}>{checkingBroker ? 'Checking broker…' : 'Reconcile with Kotak'}</button>
        <select value={modeFilter} onChange={(e) => setModeFilter(e.target.value)}>
          <option value="">All modes</option>
          <option value="PAPER">PAPER</option>
          <option value="LIVE">LIVE</option>
        </select>
      </div>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {brokerCheck && (
        <div style={{ margin: '1rem 0', padding: '0.75rem', border: brokerCheck.matched ? '1px solid #5a6' : '1px solid #b00020', borderRadius: 6 }}>
          <strong>Broker reconciliation: {brokerCheck.matched ? 'MATCHED' : 'MISMATCH'}</strong>
          <div style={{ fontSize: '0.8em', marginTop: 4 }}>Checked: {brokerCheck.checkedAt}</div>
          {brokerCheck.mismatches?.map((m) => <div key={m.symbol} style={{ color: '#b00020', fontSize: '0.85em' }}>{m.symbol}: local {m.localQuantity}, Kotak {m.brokerQuantity}</div>)}
        </div>
      )}
      {loading && <p>Loading…</p>}
      {!loading && positions.length === 0 && <p>No positions.</p>}

      {!loading && positions.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9em' }}>
          <thead>
            <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
              <th>Symbol</th>
              <th>Mode</th>
              <th>Quantity</th>
              <th>Avg price</th>
              <th>Realized P&amp;L</th>
              <th>Updated</th>
            </tr>
          </thead>
          <tbody>
            {positions.map((p) => (
              <tr key={p.id} style={{ borderBottom: '1px solid #eee' }}>
                <td>{p.symbol}</td>
                <td>{p.mode}</td>
                <td style={{ color: p.quantity > 0 ? '#0a7d28' : p.quantity < 0 ? '#b00020' : '#777' }}>
                  {p.quantity > 0 ? `+${p.quantity} (long)` : p.quantity < 0 ? `${p.quantity} (short)` : '0 (flat)'}
                </td>
                <td>{p.avg_price?.toFixed ? p.avg_price.toFixed(2) : p.avg_price}</td>
                <td style={{ color: p.realized_pnl >= 0 ? '#0a7d28' : '#b00020' }}>
                  {p.realized_pnl?.toFixed ? p.realized_pnl.toFixed(2) : p.realized_pnl}
                </td>
                <td style={{ fontSize: '0.85em', color: '#777' }}>{p.updated_at}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
