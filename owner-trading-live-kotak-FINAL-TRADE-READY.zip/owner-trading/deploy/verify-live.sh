#!/usr/bin/env bash
set -Eeuo pipefail

# Final VPS safety/readiness check. This script never places, modifies, or
# cancels an order and never prints broker credentials.
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_PORT="${PORT:-4000}"
KOTAK_PORT="${KOTAK_SERVICE_PORT:-5055}"

ok(){ echo "[verify] OK: $*"; }
fail(){ echo "[verify] FAIL: $*" >&2; exit 1; }

curl -fsS "http://127.0.0.1:${BACKEND_PORT}/api/health" >/dev/null || fail "backend health failed"
ok "backend health"
curl -fsS "http://127.0.0.1:${KOTAK_PORT}/health" >/dev/null || fail "Kotak service health failed"
ok "Kotak service health"

systemctl is-active --quiet owner-trading-backend || fail "owner-trading-backend is not active"
ok "owner-trading-backend active"
systemctl is-active --quiet kotak-service || fail "kotak-service is not active"
ok "kotak-service active"

if ss -ltn 2>/dev/null | grep -Eq ":${KOTAK_PORT}[[:space:]]"; then
  if ! ss -ltn 2>/dev/null | grep -Eq "127\.0\.0\.1:${KOTAK_PORT}[[:space:]]"; then
    fail "Kotak service port is not localhost-only"
  fi
fi
ok "Kotak service is localhost-only"

[ -f "$PROJECT_ROOT/backend/.env" ] || fail "backend/.env is missing"
[ -f "$PROJECT_ROOT/kotak_service/.env" ] || fail "kotak_service/.env is missing"
[ "$(stat -c '%a' "$PROJECT_ROOT/backend/.env")" = "600" ] || fail "backend/.env permissions are not 600"
[ "$(stat -c '%a' "$PROJECT_ROOT/kotak_service/.env")" = "600" ] || fail "kotak_service/.env permissions are not 600"
ok "production secret files exist with mode 600"

echo
cat <<'MSG'
[verify] READ-ONLY broker verification is still a human step:
[verify] 1. Settings -> Save & Connect with the real Kotak credentials.
[verify] 2. Confirm CONNECTED.
[verify] 3. Market Data -> LIVE row must say Kotak Neo LIVE and show an LTP.
[verify] 4. Check positions/holdings/limits/trade history.
[verify] 5. Keep LIVE disabled until all checks succeed.
[verify] 6. If a real order is intentionally tested, use the smallest controlled order and verify it at Kotak.
[verify] This script itself never submits a trade.
MSG
