#!/usr/bin/env bash
set -Eeuo pipefail

# Static release audit. This script never connects to Kotak and never places a trade.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fail(){ echo "[audit] FAIL: $*" >&2; exit 1; }
ok(){ echo "[audit] OK: $*"; }

[ -f "$ROOT/backend/src/brokers/kotakBrokerAdapter.js" ] || fail "Kotak adapter missing"
[ -f "$ROOT/backend/src/services/fillService.js" ] || fail "fill service missing"
[ -f "$ROOT/backend/src/db/migrations/010_live_execution_hardening.sql" ] || fail "migration 010 missing"
[ -f "$ROOT/kotak_service/app.py" ] || fail "Kotak service missing"
[ -f "$ROOT/frontend/src/pages/OrdersPage.jsx" ] || fail "Orders UI missing"

if grep -RniE 'NOT_IMPLEMENTED|trade_report\([^)]*order_id|limits\([^)]*(segment|exchange|product)|product=(CO|BO)|exchange_segment=(cde_fo|CDS|BCD)' \
  "$ROOT/backend" "$ROOT/kotak_service" "$ROOT/frontend/src" >/tmp/owner-trading-stale-patterns 2>/dev/null; then
  cat /tmp/owner-trading-stale-patterns >&2
  fail "obsolete LIVE/Kotak pattern found"
fi
rm -f /tmp/owner-trading-stale-patterns

bash -n "$ROOT/deploy/deploy.sh"
python3 -m py_compile "$ROOT/kotak_service/app.py"
for f in $(find "$ROOT/backend" -type f -name '*.js' | sort); do node --check "$f" >/dev/null || fail "backend syntax: $f"; done
ok "static LIVE/Kotak audit passed"
