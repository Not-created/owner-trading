# LIVE Trading Acceptance Checklist

## A. Build / deployment
- [ ] `./deploy/deploy.sh` completes without errors.
- [ ] `owner-trading-backend` is active.
- [ ] `kotak-service` is active.
- [ ] nginx is active and frontend loads.
- [ ] `/api/health` returns healthy.
- [ ] `/health` on the localhost-only Kotak service returns healthy.
- [ ] `./deploy/verify-live.sh` passes.

## B. Kotak connection
- [ ] Enter real credentials only in Settings.
- [ ] Save & Connect succeeds.
- [ ] Connection state is `CONNECTED`.
- [ ] Test Connection succeeds.
- [ ] Market Data shows `Kotak Neo LIVE`.
- [ ] LTP is real and changes with the market.
- [ ] No simulator value is used by LIVE code.

## C. Broker account read-only verification
- [ ] Positions load from Kotak.
- [ ] Holdings load from Kotak.
- [ ] Limits load from Kotak.
- [ ] Local LIVE positions vs Kotak reconciliation shows `MATCHED` before first real trade.
- [ ] Broker order book can be read.

## D. Strategy path
- [ ] Strategy is configured for the correct Kotak exchange segment.
- [ ] Product is one of `CNC/NRML/MIS/MTF`.
- [ ] Symbol resolves through official Kotak scrip search.
- [ ] Strategy run-once in PAPER produces the expected signal/order path.
- [ ] LIVE strategy cannot start while global mode is PAPER.
- [ ] LIVE strategy cannot start without a connected Kotak session.
- [ ] Two concurrent ticks do not create duplicate submissions.

## E. LIVE safety
- [ ] Global mode is LIVE.
- [ ] LIVE enable requires explicit confirmation.
- [ ] Emergency stop blocks new LIVE orders.
- [ ] Clearing emergency stop does not re-enable LIVE automatically.
- [ ] Restart forces LIVE enable OFF.
- [ ] Restart does not auto-start strategies.
- [ ] Restarted broker sessions require reconnect.
- [ ] UNKNOWN/RECONCILIATION_REQUIRED orders block LIVE re-arming until reconciled.

## F. First real order
- [ ] Use the smallest controlled quantity.
- [ ] Confirm the order is allowed by risk limits.
- [ ] Confirm broker margin preflight succeeds.
- [ ] Submit only once.
- [ ] Record the Kotak broker order ID.
- [ ] Verify broker status independently.
- [ ] Verify trade report fill(s).
- [ ] Verify local fill ledger.
- [ ] Verify local position.
- [ ] Verify P&L.
- [ ] Run broker position reconciliation.

## G. Lifecycle / failure checks
- [ ] OPEN order can be cancelled and final broker status is reconciled.
- [ ] LIMIT order can be modified and final broker status is reconciled.
- [ ] Partial fills accumulate without duplicate position changes.
- [ ] Timeout after submission never becomes an assumed rejection.
- [ ] Timeout during cancel/modify becomes reconciliation-required.
- [ ] Broker session expiry blocks further LIVE orders.
- [ ] Reconnect restores the ability to reconcile.

## H. Multi-strategy isolation
- [ ] Strategy A cannot read/write Strategy B's local position.
- [ ] Strategy A's order carries only Strategy A's ID.
- [ ] Strategy B continues if Strategy A fails.
- [ ] A strategy restart does not silently restart another strategy.

## Final automatic safety layer
- Background reconciliation runs without placing orders.
- LIVE order uncertainty is retained until broker truth is available.
- Broker/local position mismatch automatically disables LIVE and requires deliberate re-enable after reconciliation.
- Restart never auto-enables LIVE or auto-restarts strategies.
- Deployment creates a SQLite backup before dependency/build changes.
