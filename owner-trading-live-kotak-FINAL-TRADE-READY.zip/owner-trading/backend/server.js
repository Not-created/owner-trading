const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const config = require('./src/config/env');
const healthRoutes = require('./src/routes/health');
const authRoutes = require('./src/routes/auth');
const brokerRoutes = require('./src/routes/broker');
const tradingRoutes = require('./src/routes/trading');
const strategyRoutes = require('./src/routes/strategies');
const orderRoutes = require('./src/routes/orders');
const positionRoutes = require('./src/routes/positions');
const riskRoutes = require('./src/routes/risk');
const logRoutes = require('./src/routes/logs');
const marketDataRoutes = require('./src/routes/marketData');
const { errorHandler, notFoundHandler } = require('./src/middleware/errorHandler');

const app = express();

app.use(cors({ origin: config.frontendOrigin, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

app.use('/api', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/broker', brokerRoutes);
app.use('/api/trading', tradingRoutes);
app.use('/api/strategies', strategyRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/positions', positionRoutes);
app.use('/api/risk', riskRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/market-data', marketDataRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

// Only run startup side-effects (DB open + migrations, admin bootstrap,
// credentials file write, listening) when this file is run directly — not
// when required by tests. Tests import `app` and drive the DB/bootstrap
// themselves for deterministic, filesystem-free assertions.
if (require.main === module) {
(async () => {
  const { getDb } = require('./src/db/connection');
  const { ensureAdminBootstrap } = require('./src/services/adminBootstrap');
  const { writeInitialAdminCredentialsFile } = require('./src/services/writeInitialAdminCredentialsFile');

  const db = getDb();
  const bootstrapResult = ensureAdminBootstrap(db);

  // Safety: LIVE trading must NEVER auto-enable after a restart. Force it
  // off unconditionally before this process accepts any requests, and log
  // loudly if it actually had to change anything (that would mean the
  // process previously crashed/restarted while live was on).
  const { forceLiveDisabledOnStartup } = require('./src/services/tradingStateService');
  const hadToDisableLive = forceLiveDisabledOnStartup(db);
  if (hadToDisableLive) {
    console.warn(
      '\n[safety] LIVE trading was enabled before this restart. It has been forced OFF.\n' +
        '[safety] Re-enable it explicitly from Settings/Trading if this was intentional.\n'
    );
  }

  // Safety: no in-memory strategy scheduler interval can survive a
  // restart. Any strategy row still claiming RUNNING is stale — correct
  // it. Strategies are NOT auto-restarted; resuming automated execution
  // after a crash/restart must be a deliberate human action.
  const { resetStrategyStatusOnStartup } = require('./src/services/strategyService');
  const correctedCount = resetStrategyStatusOnStartup(db);
  if (correctedCount > 0) {
    console.warn(
      `\n[safety] ${correctedCount} strategy(ies) were marked RUNNING before this restart. ` +
        'Corrected to STOPPED. Restart them explicitly from Strategies if intended.\n'
    );
  }

  // Safety: no in-memory Kotak session (held in the Python integration
  // service) can survive a restart of either process. A broker_kotak_
  // credentials row still claiming CONNECTED from before this restart is
  // stale — correct it to SESSION_EXPIRED so the UI shows an honest state
  // and LIVE stays blocked (isLiveOrderAllowed() checks isConnected(),
  // which reads this same field) until the user explicitly reconnects.
  const brokerCredentialService = require('./src/services/brokerCredentialService');
  const staleConnectionRow = db
    .prepare("SELECT user_id FROM broker_kotak_credentials WHERE connection_state = 'CONNECTED'")
    .get();
  if (staleConnectionRow) {
    brokerCredentialService.setConnectionState(db, staleConnectionRow.user_id, 'SESSION_EXPIRED', {
      errorCode: 'RESTART',
      errorMessage: 'Session cleared on restart — reconnect required.',
    });
    console.warn(
      '\n[safety] Broker connection was CONNECTED before this restart. Marked SESSION_EXPIRED.\n' +
        '[safety] Use Settings > Test Connection (or Save & Connect) to re-establish it.\n'
    );
  }

  // Restart recovery: any order left in a non-terminal/uncertain state by
  // an unclean shutdown (SUBMITTED/OPEN/PARTIALLY_FILLED/UNKNOWN/
  // RECONCILIATION_REQUIRED) is reconciled against the broker adapter
  // right now, before the server accepts requests — never left to silently
  // sit there assumed-fine. For a paper order that was OPEN at restart,
  // the paper adapter's in-memory book is gone (paper orders are
  // synthetic and correctly do not persist across a restart), so this
  // will honestly resolve it to RECONCILIATION_REQUIRED rather than
  // guessing — that is the correct behavior per "never assume", not a bug.
  const reconciliationService = require('./src/services/reconciliationService');
  try {
    const results = await reconciliationService.reconcileAll(db);
    if (results.length > 0) {
      console.warn(`\n[safety] Startup reconciliation processed ${results.length} order(s) left non-terminal by the previous run.\n`);
    }
  } catch (err) {
    console.error('[safety] Startup reconciliation failed:', err.message);
  }

  if (bootstrapResult.created) {
    const filePath = writeInitialAdminCredentialsFile(
      bootstrapResult.username,
      bootstrapResult.password
    );
    console.warn(
      `\n[bootstrap] Created initial admin user "${bootstrapResult.username}".\n` +
        `[bootstrap] Temporary password written to: ${filePath}\n` +
        `[bootstrap] Log in, complete the forced password change, then delete that file.\n`
    );
  }

  const server = app.listen(config.port, () => {
    console.log(`Owner Trading backend listening on port ${config.port} (${config.nodeEnv})`);
    // Continuous read-only reconciliation starts only after the server is live.
    // It never submits a trade; it keeps uncertain LIVE orders/fills/positions
    // converged with Kotak and disables LIVE on a confirmed position mismatch.
    const reconciliationWorker = require('./src/services/reconciliationWorker');
    reconciliationWorker.start(db);
  });

  const shutdown = (signal) => {
    console.log(`[shutdown] ${signal} received; stopping reconciliation and HTTP server.`);
    const reconciliationWorker = require('./src/services/reconciliationWorker');
    reconciliationWorker.stop();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
})().catch((err) => {
  console.error('[startup] Fatal initialization error:', err);
  process.exit(1);
});
}

module.exports = app;
