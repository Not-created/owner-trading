-- Migration 010: live execution hardening.
-- Adds broker-routing fields to persisted orders and realized P&L per fill so
-- reconciliation, daily risk, and UI can use the same immutable fill ledger.
ALTER TABLE orders ADD COLUMN exchange_segment TEXT NOT NULL DEFAULT 'nse_cm'
  CHECK (exchange_segment IN ('nse_cm','bse_cm','nse_fo','bse_fo','mcx_fo'));
ALTER TABLE orders ADD COLUMN product TEXT NOT NULL DEFAULT 'MIS'
  CHECK (product IN ('NRML','CNC','MIS','MTF'));
ALTER TABLE order_fills ADD COLUMN realized_pnl REAL NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_orders_broker_order ON orders(broker_order_id);
CREATE INDEX IF NOT EXISTS idx_order_fills_created ON order_fills(created_at);
