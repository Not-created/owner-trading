// Pre-order risk validation — the final application-level gate before any
// broker submission. It fails closed and uses the immutable fill ledger for
// a true trading-day realized-loss calculation (IST), not all-time P&L.
function getLimits(db) {
  return db.prepare('SELECT * FROM risk_limits WHERE id = 1').get();
}

function updateLimits(db, updates) {
  const current = getLimits(db);
  const next = { ...current, ...updates };
  db.prepare(`
    UPDATE risk_limits SET
      max_order_value = ?, max_daily_loss = ?, max_open_positions = ?,
      max_orders_per_minute = ?, updated_at = datetime('now')
    WHERE id = 1
  `).run(next.max_order_value, next.max_daily_loss, next.max_open_positions, next.max_orders_per_minute);
  return getLimits(db);
}

function realizedToday(db, mode) {
  const row = db.prepare(`
    SELECT COALESCE(SUM(f.realized_pnl), 0) AS total
    FROM order_fills f
    JOIN orders o ON o.id = f.order_id
    WHERE o.mode = ?
      AND date(f.created_at, '+5 hours', '+30 minutes') = date('now', '+5 hours', '+30 minutes')
  `).get(mode);
  return Number(row.total || 0);
}

function countOpenPositions(db, mode) {
  return db.prepare('SELECT COUNT(*) AS count FROM positions WHERE mode = ? AND quantity != 0').get(mode).count;
}

function hasOpenPosition(db, mode, symbol) {
  return !!db.prepare('SELECT 1 FROM positions WHERE mode = ? AND symbol = ? AND quantity != 0').get(mode, symbol);
}

function ordersInLastMinute(db, mode) {
  return db.prepare("SELECT COUNT(*) AS count FROM orders WHERE mode = ? AND created_at >= datetime('now', '-60 seconds')").get(mode).count;
}

function validateOrder(db, { symbol, mode, quantity, referencePrice }) {
  const limits = getLimits(db);
  if (!limits || !Number.isFinite(Number(referencePrice)) || Number(referencePrice) <= 0) {
    return { allowed: false, reason: 'REFERENCE_PRICE_UNAVAILABLE' };
  }
  const orderValue = quantity * referencePrice;
  if (orderValue > Number(limits.max_order_value)) return { allowed: false, reason: 'MAX_ORDER_VALUE_EXCEEDED' };

  const realized = realizedToday(db, mode);
  if (realized <= -Math.abs(Number(limits.max_daily_loss))) return { allowed: false, reason: 'MAX_DAILY_LOSS_EXCEEDED' };

  if (!hasOpenPosition(db, mode, symbol) && countOpenPositions(db, mode) >= Number(limits.max_open_positions)) {
    return { allowed: false, reason: 'MAX_OPEN_POSITIONS_EXCEEDED' };
  }
  if (ordersInLastMinute(db, mode) >= Number(limits.max_orders_per_minute)) {
    return { allowed: false, reason: 'RATE_LIMIT_EXCEEDED' };
  }
  return { allowed: true };
}

module.exports = { getLimits, updateLimits, validateOrder, realizedToday };
