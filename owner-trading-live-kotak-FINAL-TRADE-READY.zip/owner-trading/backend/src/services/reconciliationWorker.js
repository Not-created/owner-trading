// Background LIVE reconciliation worker.
// Keeps broker truth synchronized without making WebSocket delivery a correctness dependency.
// It never places, modifies, or cancels orders; it only reconciles existing state.

const reconciliationService = require('./reconciliationService');
const brokerCredentialService = require('./brokerCredentialService');
const { getAdminUserId } = require('./adminBootstrap');
const tradingStateService = require('./tradingStateService');
const executionLogService = require('./executionLogService');

const ORDER_INTERVAL_MS = 10_000;
const POSITION_INTERVAL_MS = 30_000;

let orderTimer = null;
let positionTimer = null;
let orderRun = null;
let positionRun = null;

async function reconcileOrders(db) {
  if (orderRun) return orderRun;
  orderRun = reconciliationService.reconcileAll(db)
    .catch((err) => {
      console.error('[reconciliation] order pass failed:', err.message);
      return [];
    })
    .finally(() => { orderRun = null; });
  return orderRun;
}

async function reconcilePositions(db) {
  if (positionRun) return positionRun;
  const adminId = getAdminUserId(db);
  if (!adminId || !brokerCredentialService.isConnected(db, adminId)) return [];

  positionRun = reconciliationService.reconcileBrokerPositions(db)
    .then((result) => {
      if (result.mismatches.length > 0 && tradingStateService.getState(db).liveEnabled) {
        tradingStateService.disableLive(db);
        executionLogService.error(
          db,
          null,
          `LIVE automatically disabled: broker/local position mismatch (${result.mismatches.length} symbol(s))`
        );
        console.error('[safety] LIVE disabled because broker/local positions are mismatched.');
      }
      return result;
    })
    .catch((err) => {
      // Do not disable LIVE merely because the broker is temporarily unavailable;
      // the order gate already requires a connected session and the next pass retries.
      if (err.code !== 'BROKER_NOT_CONNECTED') {
        console.error('[reconciliation] position pass failed:', err.message);
      }
      return null;
    })
    .finally(() => { positionRun = null; });
  return positionRun;
}

function start(db) {
  if (orderTimer || positionTimer) return;

  const runOrders = () => { void reconcileOrders(db); };
  const runPositions = () => { void reconcilePositions(db); };

  // First pass is intentionally delayed until after the HTTP server is listening.
  // This keeps startup deterministic while still converging quickly after boot.
  orderTimer = setInterval(runOrders, ORDER_INTERVAL_MS);
  positionTimer = setInterval(runPositions, POSITION_INTERVAL_MS);
  orderTimer.unref?.();
  positionTimer.unref?.();
}

function stop() {
  if (orderTimer) clearInterval(orderTimer);
  if (positionTimer) clearInterval(positionTimer);
  orderTimer = null;
  positionTimer = null;
}

module.exports = { start, stop, reconcileOrders, reconcilePositions };
