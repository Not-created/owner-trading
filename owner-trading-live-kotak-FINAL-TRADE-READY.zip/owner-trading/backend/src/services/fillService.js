// Fill ledger — the single authoritative path from a broker fill to position/P&L.
// Every fill is idempotent by (local order, broker fill id). Reconciliation can
// therefore be retried safely without double-counting positions or realized P&L.
const positionService = require('./positionService');

function recordFill(db, { order, brokerFillId, quantity, price, exchangeOrderId = null, fillTime = null }) {
  const qty = Number(quantity);
  const fillPrice = Number(price);
  if (!(qty > 0) || !(fillPrice >= 0)) return { inserted: false, realizedPnl: 0 };

  const existing = db.prepare(
    'SELECT id FROM order_fills WHERE order_id = ? AND broker_fill_id = ?'
  ).get(order.id, String(brokerFillId));
  if (existing) return { inserted: false, realizedPnl: 0 };

  let result;
  const tx = db.transaction(() => {
    const before = positionService.getOrCreate(db, order.strategy_id, order.symbol, order.mode);
    const after = positionService.applyFill(db, {
      strategyId: order.strategy_id,
      symbol: order.symbol,
      mode: order.mode,
      side: order.side,
      quantity: qty,
      price: fillPrice,
    });
    const realizedPnl = Number(after.realized_pnl) - Number(before.realized_pnl);
    db.prepare(`
      INSERT INTO order_fills
        (order_id, broker_fill_id, broker_order_id, quantity, price, exchange_order_id, fill_time, realized_pnl)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      order.id,
      String(brokerFillId),
      String(order.broker_order_id || ''),
      qty,
      fillPrice,
      exchangeOrderId,
      fillTime,
      realizedPnl
    );
    result = { inserted: true, realizedPnl };
  });
  tx();
  return result;
}

function summarizeOrderFills(db, orderId) {
  return db.prepare(`
    SELECT
      COALESCE(SUM(quantity), 0) AS filledQuantity,
      CASE WHEN SUM(quantity) > 0 THEN SUM(quantity * price) / SUM(quantity) END AS avgFillPrice,
      COALESCE(SUM(realized_pnl), 0) AS realizedPnl
    FROM order_fills WHERE order_id = ?
  `).get(orderId);
}

module.exports = { recordFill, summarizeOrderFills };
