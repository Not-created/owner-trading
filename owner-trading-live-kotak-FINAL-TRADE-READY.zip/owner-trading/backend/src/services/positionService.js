// Position accounting — fills are the only source of position changes.
// Returns the updated row so the fill ledger can derive realized P&L per fill.
function getOrCreate(db, strategyId, symbol, mode) {
  let row = db.prepare(
    'SELECT * FROM positions WHERE strategy_id = ? AND symbol = ? AND mode = ?'
  ).get(strategyId, symbol, mode);
  if (!row) {
    db.prepare(
      'INSERT INTO positions (strategy_id, symbol, mode, quantity, avg_price, realized_pnl) VALUES (?, ?, ?, 0, 0, 0)'
    ).run(strategyId, symbol, mode);
    row = db.prepare(
      'SELECT * FROM positions WHERE strategy_id = ? AND symbol = ? AND mode = ?'
    ).get(strategyId, symbol, mode);
  }
  return row;
}

function sign(n) { return n > 0 ? 1 : n < 0 ? -1 : 0; }

function applyFill(db, { strategyId, symbol, mode, side, quantity, price }) {
  const position = getOrCreate(db, strategyId, symbol, mode);
  const oldQty = position.quantity;
  const oldAvg = position.avg_price;
  const fillSignedQty = side === 'BUY' ? quantity : -quantity;
  const newQtyRaw = oldQty + fillSignedQty;
  let newAvg;
  let realizedDelta = 0;
  const sameDirectionOrOpening = oldQty === 0 || sign(oldQty) === sign(fillSignedQty);

  if (sameDirectionOrOpening) {
    newAvg = (Math.abs(oldQty) * oldAvg + quantity * price) / Math.abs(newQtyRaw);
  } else {
    const closingQty = Math.min(Math.abs(oldQty), quantity);
    const direction = sign(oldQty);
    realizedDelta = closingQty * (price - oldAvg) * direction;
    if (Math.abs(fillSignedQty) > Math.abs(oldQty)) newAvg = price;
    else if (newQtyRaw === 0) newAvg = 0;
    else newAvg = oldAvg;
  }

  db.prepare(`
    UPDATE positions
    SET quantity = ?, avg_price = ?, realized_pnl = realized_pnl + ?, updated_at = datetime('now')
    WHERE strategy_id = ? AND symbol = ? AND mode = ?
  `).run(newQtyRaw, newAvg, realizedDelta, strategyId, symbol, mode);
  return getOrCreate(db, strategyId, symbol, mode);
}

function listPositions(db, { mode = null, strategyId = null } = {}) {
  const clauses = [];
  const params = [];
  if (mode) { clauses.push('mode = ?'); params.push(mode); }
  if (strategyId) { clauses.push('strategy_id = ?'); params.push(strategyId); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  return db.prepare(`SELECT * FROM positions ${where} ORDER BY updated_at DESC`).all(...params);
}

module.exports = { applyFill, listPositions, getOrCreate };
