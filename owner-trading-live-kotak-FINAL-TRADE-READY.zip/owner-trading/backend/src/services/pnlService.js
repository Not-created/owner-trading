// P&L summary — realized P&L comes from positions; unrealized LIVE P&L is
// marked only with a real Kotak quote using each strategy's exchange segment.
const positionService = require('./positionService');
const marketDataService = require('./marketDataService');

async function referencePriceFor(symbol, mode, exchangeSegment = 'nse_cm') {
  try {
    return await marketDataService.getReferencePrice(symbol, mode, exchangeSegment);
  } catch {
    return null;
  }
}

async function positionWithPnl(db, position) {
  const strategy = db.prepare('SELECT exchange_segment FROM strategies WHERE id = ?').get(position.strategy_id);
  const exchangeSegment = strategy?.exchange_segment || 'nse_cm';
  const refPrice = await referencePriceFor(position.symbol, position.mode, exchangeSegment);
  const unrealizedPnl = refPrice === null ? null : (refPrice - position.avg_price) * position.quantity;
  return { ...position, exchangeSegment, referencePrice: refPrice, unrealizedPnl };
}

async function summary(db, { mode = null, strategyId = null } = {}) {
  const rawPositions = positionService.listPositions(db, { mode, strategyId });
  const positions = await Promise.all(rawPositions.map((p) => positionWithPnl(db, p)));
  const totals = positions.reduce((acc, p) => {
    acc.realizedPnl += Number(p.realized_pnl || 0);
    if (p.unrealizedPnl !== null) acc.unrealizedPnl += p.unrealizedPnl;
    return acc;
  }, { realizedPnl: 0, unrealizedPnl: 0 });
  return {
    positions,
    totals: {
      realizedPnl: totals.realizedPnl,
      unrealizedPnl: totals.unrealizedPnl,
      totalPnl: totals.realizedPnl + totals.unrealizedPnl,
    },
  };
}

module.exports = { summary, positionWithPnl };
