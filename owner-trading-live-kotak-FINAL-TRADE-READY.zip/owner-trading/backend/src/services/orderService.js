// Order Manager — the single place that creates and transitions orders.
//
// Flow: structural validation -> duplicate/idempotency check -> persist
// CREATED -> VALIDATING (emergency-stop + LIVE-gate + risk engine) ->
// REJECTED or SUBMITTING -> broker adapter call -> final state.
//
// Two different kinds of "rejection" are deliberately NOT the same thing:
//   - Structurally invalid input (bad symbol/side/qty/price) never becomes
//     an order row — it's not a real order attempt, it's a bad API call.
//     Thrown as a plain Error with .code, caught by the route as 400.
//   - A well-formed order that fails emergency-stop/LIVE-gate/risk IS
//     persisted, as REJECTED with a reason — it's a real attempt that the
//     system correctly refused, and that refusal is exactly what audit
//     logging and order history are for.
//
// A broker call that errors (timeout, thrown exception, anything that
// isn't a clean placeOrder() resolution) NEVER gets mapped to FAILED or
// REJECTED by guessing — it goes to UNKNOWN, for reconciliationService to
// resolve later by actually asking the broker, never by assuming.

const crypto = require('node:crypto');
const executionLogService = require('./executionLogService');
const riskService = require('./riskService');
const tradingStateService = require('./tradingStateService');
const fillService = require('./fillService');
const marketDataService = require('./marketDataService');
const { getAdapter } = require('../brokers');

const DUPLICATE_WINDOW_MS = 5000;
const inFlightOrderIntents = new Set();
const VALID_SIDES = ['BUY', 'SELL'];
const VALID_ORDER_TYPES = ['MARKET', 'LIMIT'];
const VALID_MODES = ['PAPER', 'LIVE'];
const VALID_EXCHANGE_SEGMENTS = ['nse_cm', 'bse_cm', 'nse_fo', 'bse_fo', 'mcx_fo'];
const VALID_PRODUCTS = ['NRML', 'CNC', 'MIS', 'MTF'];

function validationError(code, message) {
  const err = new Error(message || code);
  err.code = code;
  return err;
}

function validateIntent({ symbol, side, quantity, orderType, limitPrice, mode, exchangeSegment, product }) {
  if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
    throw validationError('INVALID_SYMBOL', 'symbol is required');
  }
  if (!VALID_SIDES.includes(side)) {
    throw validationError('INVALID_SIDE', 'side must be BUY or SELL');
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw validationError('INVALID_QUANTITY', 'quantity must be a positive integer');
  }
  if (!VALID_ORDER_TYPES.includes(orderType)) {
    throw validationError('INVALID_ORDER_TYPE', 'orderType must be MARKET or LIMIT');
  }
  if (orderType === 'LIMIT' && !(typeof limitPrice === 'number' && limitPrice > 0)) {
    throw validationError('INVALID_PRICE', 'limitPrice must be a positive number for LIMIT orders');
  }
  if (!VALID_MODES.includes(mode)) {
    throw validationError('INVALID_MODE', 'mode must be PAPER or LIVE');
  }
  if (!VALID_EXCHANGE_SEGMENTS.includes(exchangeSegment || 'nse_cm')) {
    throw validationError('INVALID_EXCHANGE_SEGMENT', 'Unsupported Kotak exchange segment');
  }
  if (!VALID_PRODUCTS.includes(product || 'MIS')) {
    throw validationError('INVALID_PRODUCT', 'Unsupported Kotak product');
  }
}

function computeClientOrderId({ strategyId, symbol, side, quantity, orderType, limitPrice, exchangeSegment = 'nse_cm', product = 'MIS' }) {
  const bucket = Math.floor(Date.now() / DUPLICATE_WINDOW_MS);
  const raw = `${strategyId}|${symbol}|${side}|${quantity}|${orderType}|${limitPrice || ''}|${exchangeSegment}|${product}|${bucket}`;
  return crypto.createHash('sha256').update(raw).digest('hex');
}

function getOrder(db, id) {
  return db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
}

function setState(db, orderId, state, extra = {}) {
  const fields = ['state = ?'];
  const params = [state];
  for (const [key, value] of Object.entries(extra)) {
    fields.push(`${key} = ?`);
    params.push(value);
  }
  params.push(orderId);
  db.prepare(`UPDATE orders SET ${fields.join(', ')}, updated_at = datetime('now') WHERE id = ?`).run(
    ...params
  );
}

// Creates (or returns the existing, if this is a duplicate within the
// idempotency window) order, running it through the full state machine.
async function createOrderInternal(db, intent) {
  const {
    strategyId,
    symbol,
    side,
    quantity,
    orderType = 'MARKET',
    limitPrice = null,
    mode,
    exchangeSegment = null,
    product = null,
  } = intent;
  const routedExchangeSegment = exchangeSegment || 'nse_cm';
  const routedProduct = product || 'MIS';

  validateIntent({ symbol, side, quantity, orderType, limitPrice, mode, exchangeSegment: routedExchangeSegment, product: routedProduct });

  const clientOrderId = computeClientOrderId({ strategyId, symbol, side, quantity, orderType, limitPrice, exchangeSegment: routedExchangeSegment, product: routedProduct });
  const existing = db.prepare('SELECT * FROM orders WHERE client_order_id = ?').get(clientOrderId);
  if (existing) {
    executionLogService.warn(
      db,
      strategyId,
      `Duplicate order intent suppressed (same strategy/symbol/side/qty within ${DUPLICATE_WINDOW_MS}ms) — returning existing order #${existing.id}`
    );
    return existing;
  }

  const insertInfo = db
    .prepare(
      `INSERT INTO orders (client_order_id, strategy_id, symbol, side, quantity, order_type, limit_price, mode, exchange_segment, product, state)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CREATED')`
    )
    .run(clientOrderId, strategyId, symbol, side, quantity, orderType, limitPrice, mode, routedExchangeSegment, routedProduct);
  const orderId = insertInfo.lastInsertRowid;

  setState(db, orderId, 'VALIDATING');

  const tradingState = tradingStateService.getState(db);
  if (tradingState.emergency_stop) {
    setState(db, orderId, 'REJECTED', { reject_reason: 'EMERGENCY_STOP_ACTIVE' });
    executionLogService.warn(db, strategyId, `Order #${orderId} rejected: emergency stop is active`);
    return getOrder(db, orderId);
  }

  if (mode === 'LIVE' && !tradingStateService.isLiveOrderAllowed(db)) {
    setState(db, orderId, 'REJECTED', { reject_reason: 'LIVE_NOT_ALLOWED' });
    executionLogService.warn(db, strategyId, `Order #${orderId} rejected: LIVE trading is not currently allowed`);
    return getOrder(db, orderId);
  }

  // PAPER mode's "market price" is the simulator; LIVE mode uses a real
  // broker quote — marketDataService is the single choke point for this
  // decision (see its header comment for the bug this fixed).
  let referencePrice;
  try {
    referencePrice = await marketDataService.getReferencePrice(symbol, mode, routedExchangeSegment);
  } catch (err) {
    setState(db, orderId, 'FAILED', { reject_reason: `MARKET_DATA_UNAVAILABLE: ${err.message}` });
    executionLogService.error(db, strategyId, `Order #${orderId} could not get a reference price: ${err.message}`);
    return getOrder(db, orderId);
  }

  const risk = riskService.validateOrder(db, { symbol, mode, quantity, referencePrice });
  if (!risk.allowed) {
    setState(db, orderId, 'REJECTED', { reject_reason: risk.reason });
    executionLogService.warn(db, strategyId, `Order #${orderId} rejected by risk engine: ${risk.reason}`);
    return getOrder(db, orderId);
  }

  const adapter = getAdapter(mode);
  if (mode === 'LIVE' && typeof adapter.getMarginRequired === 'function') {
    try {
      const margin = await adapter.getMarginRequired({
        symbol,
        exchangeSegment: routedExchangeSegment,
        product: routedProduct,
        quantity,
        orderType,
        price: orderType === 'LIMIT' ? limitPrice : referencePrice,
        side,
      });
      const insufficient = Number(margin?.insufFund ?? margin?.insufficientFunds ?? 0);
      if (Number.isFinite(insufficient) && insufficient > 0) {
        setState(db, orderId, 'REJECTED', { reject_reason: 'BROKER_INSUFFICIENT_FUNDS' });
        executionLogService.warn(db, strategyId, `Order #${orderId} rejected by Kotak margin preflight`);
        return getOrder(db, orderId);
      }
    } catch (err) {
      setState(db, orderId, 'REJECTED', { reject_reason: `BROKER_MARGIN_PREFLIGHT_FAILED: ${err.message}` });
      executionLogService.error(db, strategyId, `Order #${orderId} margin preflight failed: ${err.message}`);
      return getOrder(db, orderId);
    }
  }

  setState(db, orderId, 'SUBMITTING');

  let result;
  try {
    result = await adapter.placeOrder({
      clientOrderId,
      symbol,
      side,
      quantity,
      orderType,
      limitPrice,
      referencePrice,
      exchangeSegment: routedExchangeSegment,
      product: routedProduct,
    });
  } catch (err) {
    // A broker exception does not prove whether a remote submission occurred.
    // Preserve UNKNOWN so reconciliation can ask the broker before any retry.
    setState(db, orderId, 'UNKNOWN', { reject_reason: err.message });
    executionLogService.error(db, strategyId, `Order #${orderId} broker call error (${adapter.name}): ${err.message}`);
    return getOrder(db, orderId);
  }

  setState(db, orderId, result.state, {
    broker_order_id: result.brokerOrderId,
    filled_quantity: result.filledQuantity || 0,
    avg_fill_price: result.avgFillPrice,
  });

  if ((result.state === 'FILLED' || result.state === 'PARTIALLY_FILLED') && result.filledQuantity > 0 && result.avgFillPrice != null) {
    fillService.recordFill(db, {
      order: getOrder(db, orderId),
      brokerFillId: `${result.brokerOrderId}:initial:${result.filledQuantity}:${result.avgFillPrice}`,
      quantity: result.filledQuantity,
      price: result.avgFillPrice,
    });
  }

  executionLogService.info(
    db,
    strategyId,
    `Order #${orderId} (${side} ${quantity} ${symbol}, ${mode}) -> ${result.state}`
  );

  return getOrder(db, orderId);
}


// Prevent overlapping scheduler/manual executions from submitting the same
// logical intent concurrently. UNKNOWN broker outcomes remain UNKNOWN; this
// lock only covers local concurrency and never retries a broker call.
async function createOrder(db, intent) {
  const key = `${intent.strategyId}|${intent.symbol}|${intent.side}|${intent.quantity}|${intent.orderType || 'MARKET'}|${intent.limitPrice || ''}|${intent.exchangeSegment || 'nse_cm'}|${intent.product || 'MIS'}`;
  if (inFlightOrderIntents.has(key)) {
    executionLogService.warn(db, intent.strategyId, 'Duplicate order suppressed: identical order intent is already in flight');
    return null;
  }
  inFlightOrderIntents.add(key);
  try {
    return await createOrderInternal(db, intent);
  } finally {
    inFlightOrderIntents.delete(key);
  }
}

async function modifyOrder(db, orderId, updates = {}) {
  const order = getOrder(db, orderId);
  if (!order) throw validationError('ORDER_NOT_FOUND', `No order #${orderId}`);
  if (!['OPEN', 'PARTIALLY_FILLED', 'SUBMITTED'].includes(order.state)) {
    throw validationError('ORDER_NOT_MODIFIABLE', `Order #${orderId} is in state ${order.state}`);
  }
  const adapter = getAdapter(order.mode);
  try {
    const result = await adapter.modifyOrder(order.broker_order_id, {
      quantity: updates.quantity !== undefined ? Number(updates.quantity) : order.quantity,
      limitPrice: updates.limitPrice !== undefined ? Number(updates.limitPrice) : order.limit_price,
      orderType: updates.orderType || order.order_type,
      triggerPrice: updates.triggerPrice,
      disclosedQuantity: updates.disclosedQuantity,
      validity: updates.validity || 'DAY',
    });
    setState(db, orderId, result.state || 'OPEN');
  } catch (err) {
    setState(db, orderId, 'RECONCILIATION_REQUIRED', { reject_reason: `MODIFY_UNKNOWN: ${err.message}` });
    executionLogService.error(db, order.strategy_id, `Order #${orderId} modify outcome unknown: ${err.message}`);
    return getOrder(db, orderId);
  }
  executionLogService.info(db, order.strategy_id, `Order #${orderId} modify -> ${result.state || 'OPEN'}`);
  return getOrder(db, orderId);
}

async function cancelOrder(db, orderId) {
  const order = getOrder(db, orderId);
  if (!order) {
    throw validationError('ORDER_NOT_FOUND', `No order #${orderId}`);
  }
  if (!['OPEN', 'PARTIALLY_FILLED', 'SUBMITTED'].includes(order.state)) {
    throw validationError('ORDER_NOT_CANCELLABLE', `Order #${orderId} is in state ${order.state}`);
  }

  const adapter = getAdapter(order.mode);
  try {
    const result = await adapter.cancelOrder(order.broker_order_id);
    setState(db, orderId, result.state);
    executionLogService.info(db, order.strategy_id, `Order #${orderId} cancel -> ${result.state}`);
  } catch (err) {
    setState(db, orderId, 'RECONCILIATION_REQUIRED', { reject_reason: `CANCEL_UNKNOWN: ${err.message}` });
    executionLogService.error(db, order.strategy_id, `Order #${orderId} cancel outcome unknown: ${err.message}`);
  }
  return getOrder(db, orderId);
}

function listOrders(db, { strategyId = null, limit = 100 } = {}) {
  if (strategyId) {
    return db
      .prepare('SELECT * FROM orders WHERE strategy_id = ? ORDER BY id DESC LIMIT ?')
      .all(strategyId, limit);
  }
  return db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT ?').all(limit);
}

module.exports = { createOrder, modifyOrder, cancelOrder, listOrders, getOrder, computeClientOrderId };
