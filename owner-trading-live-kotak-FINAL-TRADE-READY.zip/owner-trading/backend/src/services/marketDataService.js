// Market data routing — the ONLY place that decides where a price comes from.
// PAPER uses the synthetic simulator; LIVE uses the real broker adapter.
// LIVE history is an in-memory observation buffer built only from prices that
// were actually returned by Kotak. It is deliberately not persisted as if it
// were historical market data; a process restart starts a fresh observation
// window rather than fabricating candles/ticks.

const marketDataSimulator = require('./marketDataSimulator');
const { getAdapter } = require('../brokers');

const MAX_LIVE_HISTORY = 120;
const liveHistory = new Map();

function appendLiveObservation(symbol, exchangeSegment, price) {
  const key = `${exchangeSegment}:${symbol}`;
  const history = liveHistory.get(key) || [];
  history.push(price);
  if (history.length > MAX_LIVE_HISTORY) history.splice(0, history.length - MAX_LIVE_HISTORY);
  liveHistory.set(key, history);
  return history.slice();
}

// Returns a plain number for risk sizing / fill checks.
// LIVE failures throw — there is intentionally no synthetic fallback.
async function getReferencePrice(symbol, mode, exchangeSegment = 'nse_cm') {
  if (mode === 'LIVE') {
    const adapter = getAdapter('LIVE');
    const quote = await adapter.getQuote(symbol, exchangeSegment);
    return quote.ltp;
  }
  return marketDataSimulator.getLastPrice(symbol);
}

// Strategy cycles call this function. LIVE observations are real Kotak quote
// results; PAPER observations come only from the simulator.
async function getMarketSnapshot(symbol, mode, exchangeSegment = 'nse_cm') {
  if (mode === 'LIVE') {
    const adapter = getAdapter('LIVE');
    const quote = await adapter.getQuote(symbol, exchangeSegment);
    const history = appendLiveObservation(symbol, exchangeSegment, quote.ltp);
    return {
      price: quote.ltp,
      history,
      source: 'KOTAK_NEO_LIVE',
      timestamp: quote.timestamp,
      bid: quote.bid,
      ask: quote.ask,
      volume: quote.volume,
    };
  }

  const price = marketDataSimulator.tick(symbol);
  return { price, history: marketDataSimulator.getHistory(symbol), source: 'PAPER_SIMULATOR' };
}

function clearLiveHistory() {
  liveHistory.clear();
}

module.exports = { getReferencePrice, getMarketSnapshot, clearLiveHistory };
