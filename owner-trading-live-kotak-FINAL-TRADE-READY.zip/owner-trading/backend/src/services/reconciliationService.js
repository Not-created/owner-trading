// Broker reconciliation — broker state is authoritative for LIVE execution.
// Order status comes from order_report(); fill truth comes from trade_report(),
// filtered client-side by broker order number as required by Kotak Neo v3.
const executionLogService = require('./executionLogService');
const fillService = require('./fillService');
const marketDataSimulator = require('./marketDataSimulator');
const { getAdapter, paperAdapter } = require('../brokers');
const brokerCredentialService = require('./brokerCredentialService');
const { getAdminUserId } = require('./adminBootstrap');

const NEEDS_RECONCILIATION_STATES = ['SUBMITTED', 'OPEN', 'PARTIALLY_FILLED', 'UNKNOWN', 'RECONCILIATION_REQUIRED'];

function applyLiveFills(db, order, fills) {
  for (const fill of fills || []) {
    const fillId = String(
      fill.flId || fill.trade_id || fill.fill_id ||
      `${fill.exOrdId || ''}:${fill.flDt || ''}:${fill.flTm || ''}:${fill.fldQty || fill.qty || ''}:${fill.avgPrc || fill.prc || ''}`
    );
    const qty = Number(fill.fldQty || fill.qty || fill.fillQty || 0);
    const price = Number(fill.avgPrc || fill.prc || fill.fillPrice || 0);
    if (!(qty > 0) || !(price >= 0)) continue;
    fillService.recordFill(db, {
      order,
      brokerFillId: fillId,
      quantity: qty,
      price,
      exchangeOrderId: fill.exOrdId || fill.exchangeOrderId || null,
      fillTime: fill.flDt && fill.flTm ? `${fill.flDt} ${fill.flTm}` : fill.fillTime || null,
    });
  }
}

async function reconcileOrder(db, order) {
  if (!NEEDS_RECONCILIATION_STATES.includes(order.state)) return order;

  if (order.mode === 'LIVE') {
    const adminId = getAdminUserId(db);
    if (!adminId || !brokerCredentialService.isConnected(db, adminId)) {
      // A restart destroys the in-memory broker session. Do not manufacture a
      // failure merely because reconciliation cannot run until the user
      // reconnects; leave the order visibly uncertain and block new LIVE flow.
      executionLogService.warn(db, order.strategy_id, `Order #${order.id} awaits broker reconnect before reconciliation`);
      return order;
    }
  }

  if (order.mode === 'PAPER' && order.state === 'OPEN' && order.broker_order_id) {
    paperAdapter.tryFillPending(order.broker_order_id, marketDataSimulator.getLastPrice(order.symbol));
  }

  const adapter = getAdapter(order.mode);
  try {
    const status = await adapter.getOrderStatus(order.broker_order_id);
    if (order.mode === 'LIVE' && typeof adapter.reconcileFills === 'function') {
      const fills = await adapter.reconcileFills(order.broker_order_id);
      applyLiveFills(db, order, fills);
    } else if (order.mode === 'PAPER' && status.filledQuantity > order.filled_quantity && status.avgFillPrice != null) {
      fillService.recordFill(db, {
        order,
        brokerFillId: `${order.broker_order_id}:paper:${status.filledQuantity}`,
        quantity: status.filledQuantity - order.filled_quantity,
        price: status.avgFillPrice,
      });
    }

    const total = fillService.summarizeOrderFills(db, order.id);
    let state = status.state;
    const filledQuantity = Number(total.filledQuantity || status.filledQuantity || 0);
    const avgFillPrice = total.avgFillPrice == null
      ? (status.avgFillPrice == null ? null : Number(status.avgFillPrice))
      : Number(total.avgFillPrice);

    if (filledQuantity >= order.quantity) state = 'FILLED';
    else if (filledQuantity > 0 && !['REJECTED', 'CANCELLED'].includes(state)) state = 'PARTIALLY_FILLED';
    else if (state === 'UNKNOWN' && order.state === 'UNKNOWN') state = 'RECONCILIATION_REQUIRED';

    db.prepare(`
      UPDATE orders SET state=?, filled_quantity=?, avg_fill_price=?, updated_at=datetime('now') WHERE id=?
    `).run(state, filledQuantity, avgFillPrice, order.id);
    return db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
  } catch (err) {
    db.prepare(`UPDATE orders SET state='RECONCILIATION_REQUIRED', reject_reason=?, updated_at=datetime('now') WHERE id=?`)
      .run(err.message, order.id);
    executionLogService.error(db, order.strategy_id, `Order #${order.id} reconciliation failed: ${err.message}`);
    return db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
  }
}

async function reconcileAll(db) {
  const pending = db.prepare(`SELECT * FROM orders WHERE state IN (${NEEDS_RECONCILIATION_STATES.map(() => '?').join(',')})`)
    .all(...NEEDS_RECONCILIATION_STATES);
  const out = [];
  for (const order of pending) out.push(await reconcileOrder(db, order));
  return out;
}

function normalizeBrokerPosition(row) {
  return {
    symbol: row.trdSym || row.tradingSymbol || row.symbol || row.displaySymbol || row.display_symbol,
    quantity: Number(row.flBuyQty || row.buyQty || row.buy_quantity || 0) - Number(row.flSellQty || row.sellQty || row.sell_quantity || 0) || Number(row.netQty || row.net_quantity || row.quantity || 0),
    avgPrice: Number(row.avgPrc || row.avgPrice || row.averagePrice || 0),
    exchangeSegment: row.exSeg || row.exchangeSegment || row.exchange || null,
    raw: row,
  };
}

async function reconcileBrokerPositions(db) {
  const adminId = getAdminUserId(db);
  if (!adminId || !brokerCredentialService.isConnected(db, adminId)) {
    const err = new Error('Kotak broker must be CONNECTED before account reconciliation');
    err.code = 'BROKER_NOT_CONNECTED';
    throw err;
  }
  const adapter = getAdapter('LIVE');
  const brokerRows = (await adapter.getPositions()).map(normalizeBrokerPosition).filter((x) => x.symbol);
  const localRows = db.prepare(`
    SELECT symbol, SUM(quantity) AS quantity, SUM(realized_pnl) AS realized_pnl
    FROM positions WHERE mode='LIVE' GROUP BY symbol
  `).all();
  const localBySymbol = new Map(localRows.map((x) => [String(x.symbol).toUpperCase(), x]));
  const brokerBySymbol = new Map();
  for (const row of brokerRows) {
    const key = String(row.symbol).toUpperCase();
    const existing = brokerBySymbol.get(key) || { symbol: row.symbol, quantity: 0, avgPrice: 0, exchangeSegment: row.exchangeSegment };
    existing.quantity += Number(row.quantity || 0);
    if (row.avgPrice) existing.avgPrice = row.avgPrice;
    brokerBySymbol.set(key, existing);
  }
  const symbols = new Set([...localBySymbol.keys(), ...brokerBySymbol.keys()]);
  const mismatches = [];
  for (const key of symbols) {
    const local = localBySymbol.get(key) || { symbol: key, quantity: 0 };
    const broker = brokerBySymbol.get(key) || { symbol: key, quantity: 0 };
    if (Number(local.quantity) !== Number(broker.quantity)) {
      mismatches.push({ symbol: key, localQuantity: Number(local.quantity), brokerQuantity: Number(broker.quantity), status: 'MISMATCH' });
    }
  }
  return { checkedAt: new Date().toISOString(), brokerPositions: [...brokerBySymbol.values()], localPositions: localRows, mismatches, matched: mismatches.length === 0 };
}

module.exports = { reconcileOrder, reconcileAll, reconcileBrokerPositions, NEEDS_RECONCILIATION_STATES };
