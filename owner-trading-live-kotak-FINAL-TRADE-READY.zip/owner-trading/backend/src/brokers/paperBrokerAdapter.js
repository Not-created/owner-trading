// Paper broker adapter — fully functional simulated execution.
//
// Implements the exact same interface (see brokerAdapter.js) that a real
// broker adapter would. This is deliberate: it means the ENTIRE rest of
// the trading engine (risk, order state machine, positions, P&L) runs
// through the identical code path in PAPER as it eventually would in
// LIVE — only this file's internals differ.
//
// Simplification (documented, not hidden): fills are always either
// "immediate full fill" or "stays OPEN" — no partial-fill simulation.
// Real partial fills are a LIVE-broker behavior this adapter does not
// attempt to fabricate; the order STATE MACHINE itself fully supports
// PARTIALLY_FILLED (see orderService.js), it's just that this simulator
// never produces one.

const crypto = require('node:crypto');
const { BrokerAdapter } = require('./brokerAdapter');
const marketDataSimulator = require('../services/marketDataSimulator');

// In-memory book of paper orders. Fine to be memory-only: paper orders are
// synthetic by definition and a process restart correctly starting a
// fresh paper book is reasonable behavior, not a bug.
const paperOrders = new Map(); // brokerOrderId -> order record

function crosses(side, orderType, limitPrice, referencePrice) {
  if (orderType === 'MARKET') return true;
  if (side === 'BUY') return referencePrice <= limitPrice;
  return referencePrice >= limitPrice; // SELL
}

class PaperBrokerAdapter extends BrokerAdapter {
  // eslint-disable-next-line class-methods-use-this
  get name() {
    return 'paper';
  }

  // eslint-disable-next-line class-methods-use-this
  async placeOrder({ clientOrderId, symbol, side, quantity, orderType, limitPrice, referencePrice }) {
    const brokerOrderId = `PAPER-${crypto.randomUUID()}`;
    const willFill = crosses(side, orderType, limitPrice, referencePrice);

    const record = {
      brokerOrderId,
      clientOrderId,
      symbol,
      side,
      quantity,
      orderType,
      limitPrice,
      state: willFill ? 'FILLED' : 'OPEN',
      filledQuantity: willFill ? quantity : 0,
      avgFillPrice: willFill ? referencePrice : null,
    };
    paperOrders.set(brokerOrderId, record);

    return {
      brokerOrderId,
      state: record.state,
      filledQuantity: record.filledQuantity,
      avgFillPrice: record.avgFillPrice,
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async getOrderStatus(brokerOrderId) {
    const record = paperOrders.get(brokerOrderId);
    if (!record) {
      // Genuinely unknown to this adapter — never fabricate a state.
      return { state: 'UNKNOWN', filledQuantity: 0, avgFillPrice: null };
    }
    return {
      state: record.state,
      filledQuantity: record.filledQuantity,
      avgFillPrice: record.avgFillPrice,
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async cancelOrder(brokerOrderId) {
    const record = paperOrders.get(brokerOrderId);
    if (!record) return { state: 'UNKNOWN' };
    if (record.state === 'OPEN') {
      record.state = 'CANCELLED';
    }
    return { state: record.state };
  }

  // eslint-disable-next-line class-methods-use-this
  async getPositions() {
    // The paper adapter has no independent position ledger of its own —
    // this app's positions table IS the source of truth for paper mode
    // (unlike LIVE, where the broker's ledger is authoritative and this
    // app's table must reconcile against it). Returning an empty array is
    // correct here, not a stub: there's nothing else to reconcile against.
    return [];
  }

  // eslint-disable-next-line class-methods-use-this
  async getHoldings() {
    return []; // paper mode has no separate holdings concept
  }

  // eslint-disable-next-line class-methods-use-this
  async getLimits() {
    // Paper trading has no real margin/limits system. Returning an
    // explicit "not applicable" shape rather than a fabricated number.
    return { availableMargin: null, note: 'PAPER mode has no real margin/limits' };
  }

  // eslint-disable-next-line class-methods-use-this
  async getQuote(symbol, _exchangeSegment) {
    const ltp = marketDataSimulator.getLastPrice(symbol);
    return {
      symbol,
      ltp,
      bid: Math.round((ltp - 0.05) * 100) / 100,
      ask: Math.round((ltp + 0.05) * 100) / 100,
      volume: null,
      timestamp: new Date().toISOString(),
      exchange: 'SIMULATED',
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async modifyOrder(brokerOrderId, { quantity, limitPrice } = {}) {
    const record = paperOrders.get(brokerOrderId);
    if (!record) return { state: 'UNKNOWN' };
    if (record.state !== 'OPEN') {
      return { state: record.state }; // can't modify a terminal/filled order
    }
    if (Number.isInteger(quantity) && quantity > 0) record.quantity = quantity;
    if (typeof limitPrice === 'number' && limitPrice > 0) record.limitPrice = limitPrice;
    return { state: record.state };
  }

  // Lets a pending OPEN limit order fill later once price crosses —
  // called by the reconciliation pass, not by placeOrder itself.
  // eslint-disable-next-line class-methods-use-this
  tryFillPending(brokerOrderId, referencePrice) {
    const record = paperOrders.get(brokerOrderId);
    if (!record || record.state !== 'OPEN') return record ? { ...record } : null;

    if (crosses(record.side, record.orderType, record.limitPrice, referencePrice)) {
      record.state = 'FILLED';
      record.filledQuantity = record.quantity;
      record.avgFillPrice = referencePrice;
    }
    return { ...record };
  }

  // Test/ops utility.
  // eslint-disable-next-line class-methods-use-this
  reset() {
    paperOrders.clear();
  }
}

module.exports = { PaperBrokerAdapter, paperOrders };
