// Broker adapter interface.
//
// The trading engine (orderService.js) only ever talks to whatever object
// implements THIS shape — it never knows or cares whether that's the
// paper simulator or a real broker. This is what "broker-independent
// trading engine" means in practice: swapping brokers means writing a new
// file that implements these five methods, and nothing else in the
// codebase changes.
//
// Every method is async and must resolve/reject — never throw
// synchronously — so orderService can uniformly await + try/catch every
// call regardless of adapter.
//
// Contract:
//
//   name: string — for logging ("paper", "kotak-neo", ...)
//
//   async placeOrder({ clientOrderId, symbol, side, quantity, orderType,
//                       limitPrice, referencePrice })
//     -> { brokerOrderId, state, filledQuantity, avgFillPrice }
//     `state` must be one of the order states in migration 005.
//     MUST NOT fabricate a success state if the outcome is genuinely
//     unknown (e.g. a network timeout after sending the request) — return
//     state: 'UNKNOWN' in that case, never guess FILLED or REJECTED.
//
//   async getOrderStatus(brokerOrderId)
//     -> { state, filledQuantity, avgFillPrice }
//     Used by reconciliation to resolve UNKNOWN/RECONCILIATION_REQUIRED
//     orders against the broker's own record — never guess, always ask.
//
//   async cancelOrder(brokerOrderId) -> { state }
//
//   async getQuote(symbol)
//     -> { symbol, ltp, bid, ask, volume, timestamp, exchange }
//     The reference price for risk sizing and order-fill logic. PAPER
//     uses the market data simulator; LIVE must use a real quote — never
//     the simulator (see marketDataService.js, which is what callers
//     actually use — never call an adapter's getQuote directly from
//     order/risk code, so PAPER vs LIVE routing stays in one place).
//
//   async getPositions() -> [{ symbol, quantity, avgPrice }]
//     Broker's own view of positions, for reconciliation against this
//     app's locally computed positions table.

class BrokerAdapter {
  // eslint-disable-next-line class-methods-use-this
  get name() {
    throw new Error('BrokerAdapter subclasses must implement get name()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async placeOrder(_orderIntent) {
    throw new Error('BrokerAdapter subclasses must implement placeOrder()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async modifyOrder(_brokerOrderId, _updates) {
    throw new Error('BrokerAdapter subclasses must implement modifyOrder()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async getOrderStatus(_brokerOrderId) {
    throw new Error('BrokerAdapter subclasses must implement getOrderStatus()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async cancelOrder(_brokerOrderId) {
    throw new Error('BrokerAdapter subclasses must implement cancelOrder()');
  }

  // eslint-disable-next-line class-methods-use-this
  async getPositions() {
    throw new Error('BrokerAdapter subclasses must implement getPositions()');
  }

  // eslint-disable-next-line class-methods-use-this
  async getHoldings() {
    throw new Error('BrokerAdapter subclasses must implement getHoldings()');
  }

  // eslint-disable-next-line class-methods-use-this
  async getLimits() {
    throw new Error('BrokerAdapter subclasses must implement getLimits()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async getMarginRequired(_orderIntent) { return null; }

  async getQuote(_symbol, _exchangeSegment) {
    throw new Error('BrokerAdapter subclasses must implement getQuote()');
  }

  // Optional broker-native order/fill history used by reconciliation/UI.
  async reconcileFills(_brokerOrderId) { return []; }

  async getOrderHistory() { return []; }
}

module.exports = { BrokerAdapter };
