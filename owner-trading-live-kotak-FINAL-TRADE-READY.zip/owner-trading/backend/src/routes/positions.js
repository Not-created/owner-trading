const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const positionService = require('../services/positionService');
const pnlService = require('../services/pnlService');
const reconciliationService = require('../services/reconciliationService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

router.get('/', (req, res) => {
  const mode = req.query.mode || null;
  res.json(positionService.listPositions(getDb(), { mode }));
});

router.get('/broker-reconciliation', async (req, res) => {
  try {
    res.json(await reconciliationService.reconcileBrokerPositions(getDb()));
  } catch (err) {
    res.status(409).json({ error: err.code || 'BROKER_RECONCILIATION_FAILED', message: err.message });
  }
});

router.get('/pnl', async (req, res) => {
  const mode = req.query.mode || null;
  res.json(await pnlService.summary(getDb(), { mode }));
});

module.exports = router;
