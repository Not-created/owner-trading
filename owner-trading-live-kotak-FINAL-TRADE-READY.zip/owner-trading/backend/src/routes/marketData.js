const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const marketDataSimulator = require('../services/marketDataSimulator');
const marketDataService = require('../services/marketDataService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

// Returns broker-sourced data for LIVE strategies and simulator data only for PAPER.
// Provider identity is explicit in every row so the frontend cannot accidentally
// present synthetic values as live market data.
router.get('/', async (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT symbol, mode, exchange_segment FROM strategies GROUP BY symbol, mode, exchange_segment').all();
  const data = [];

  for (const row of rows) {
    try {
      if (row.mode === 'LIVE') {
        const snap = await marketDataService.getMarketSnapshot(row.symbol, 'LIVE', row.exchange_segment);
        data.push({
          symbol: row.symbol,
          mode: 'LIVE',
          exchangeSegment: row.exchange_segment,
          price: snap.price,
          history: snap.history,
          source: snap.source,
          timestamp: snap.timestamp,
          bid: snap.bid,
          ask: snap.ask,
          volume: snap.volume,
          simulated: false,
        });
      } else {
        data.push({
          symbol: row.symbol,
          mode: 'PAPER',
          exchangeSegment: row.exchange_segment,
          price: marketDataSimulator.getLastPrice(row.symbol),
          history: marketDataSimulator.getHistory(row.symbol),
          source: 'PAPER_SIMULATOR',
          timestamp: new Date().toISOString(),
          simulated: true,
        });
      }
    } catch (err) {
      data.push({
        symbol: row.symbol,
        mode: row.mode,
        exchangeSegment: row.exchange_segment,
        price: null,
        history: [],
        source: row.mode === 'LIVE' ? 'KOTAK_NEO_LIVE' : 'PAPER_SIMULATOR',
        timestamp: null,
        simulated: row.mode !== 'LIVE',
        error: err.message,
      });
    }
  }

  res.json({ simulated: data.every((x) => x.simulated), symbols: data });
});

module.exports = router;
