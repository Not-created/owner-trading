const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const svc = require('../services/tradingStateService');
const { KotakBrokerAdapter } = require('../brokers/kotakBrokerAdapter');
const brokerCredentialService = require('../services/brokerCredentialService');

const router = express.Router();

router.use(requireAuth, requirePasswordChangeComplete);

// GET /api/trading/state
router.get('/state', (req, res) => {
  const db = getDb();
  res.json(svc.toApiShape(svc.getState(db)));
});

// PUT /api/trading/mode — switch target mode. Does NOT by itself allow
// live orders; see POST /live-enable.
router.put('/mode', (req, res) => {
  const { mode } = req.body || {};
  const db = getDb();
  try {
    res.json(svc.toApiShape(svc.setMode(db, mode)));
  } catch (err) {
    res.status(400).json({ error: err.code || 'INVALID_MODE' });
  }
});

// POST /api/trading/live-enable — explicit, confirmed action. Requires
// { confirm: true } in the body so this can never be triggered by a stray
// click or a retried request without intent.
router.post('/live-enable', async (req, res) => {
  const { confirm } = req.body || {};
  if (confirm !== true) {
    return res.status(400).json({ error: 'CONFIRMATION_REQUIRED' });
  }

  const db = getDb();
  try {
    if (!brokerCredentialService.isConnected(db, req.user.userId)) {
      return res.status(409).json({ error: 'BROKER_NOT_CONNECTED' });
    }
    // Final pre-enable read-only broker health check. LIVE cannot be armed
    // merely because credentials are present; Kotak must answer a real
    // limits request successfully immediately before arming.
    await new KotakBrokerAdapter().getLimits();
    const unresolved = db.prepare("SELECT COUNT(*) AS count FROM orders WHERE mode='LIVE' AND state IN ('UNKNOWN','RECONCILIATION_REQUIRED')").get().count;
    if (unresolved > 0) {
      return res.status(409).json({ error: 'LIVE_ORDERS_REQUIRE_RECONCILIATION', count: unresolved });
    }
    res.json(svc.toApiShape(svc.enableLive(db, req.user.userId)));
  } catch (err) {
    res.status(409).json({ error: err.code || 'CANNOT_ENABLE_LIVE', message: err.message });
  }
});

// POST /api/trading/live-disable — always allowed, no confirmation needed
// (turning safety OFF should never require a confirmation step).
router.post('/live-disable', (req, res) => {
  const db = getDb();
  res.json(svc.toApiShape(svc.disableLive(db)));
});

// POST /api/trading/emergency-stop — global kill switch.
router.post('/emergency-stop', (req, res) => {
  const db = getDb();
  res.json(svc.toApiShape(svc.triggerEmergencyStop(db, req.user.userId)));
});

// POST /api/trading/emergency-stop/clear — clears the stop flag only.
// live trading remains OFF until separately re-enabled.
router.post('/emergency-stop/clear', (req, res) => {
  const db = getDb();
  res.json(svc.toApiShape(svc.clearEmergencyStop(db)));
});

module.exports = router;
