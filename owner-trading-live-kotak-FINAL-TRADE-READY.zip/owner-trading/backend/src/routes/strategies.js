const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const strategyService = require('../services/strategyService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

function handleServiceError(res, err) {
  const knownCodes = [
    'INVALID_NAME', 'INVALID_CODE', 'INVALID_SYMBOL', 'INVALID_MODE',
    'INVALID_POSITION_SIZING_TYPE', 'INVALID_POSITION_SIZING_VALUE',
    'STRATEGY_NOT_FOUND', 'STRATEGY_RUNNING', 'INVALID_EXCHANGE_SEGMENT', 'INVALID_PRODUCT', 'GLOBAL_MODE_NOT_LIVE', 'BROKER_NOT_CONNECTED',
  ];
  if (knownCodes.includes(err.code)) {
    const status = err.code === 'STRATEGY_NOT_FOUND' ? 404 : 400;
    return res.status(status).json({ error: err.code, message: err.message });
  }
  throw err; // let the global error handler deal with anything unexpected
}

router.get('/', (req, res) => {
  res.json(strategyService.listStrategies(getDb()));
});

router.post('/', (req, res) => {
  try {
    res.status(201).json(strategyService.createStrategy(getDb(), req.body || {}));
  } catch (err) {
    handleServiceError(res, err);
  }
});

router.get('/:id', (req, res) => {
  const strategy = strategyService.getStrategy(getDb(), Number(req.params.id));
  if (!strategy) return res.status(404).json({ error: 'STRATEGY_NOT_FOUND' });
  res.json(strategy);
});

router.put('/:id', (req, res) => {
  try {
    res.json(strategyService.updateStrategy(getDb(), Number(req.params.id), req.body || {}));
  } catch (err) {
    handleServiceError(res, err);
  }
});

router.delete('/:id', (req, res) => {
  try {
    strategyService.deleteStrategy(getDb(), Number(req.params.id));
    res.json({ success: true });
  } catch (err) {
    handleServiceError(res, err);
  }
});

router.post('/:id/start', (req, res) => {
  try {
    res.json(strategyService.startStrategy(getDb(), Number(req.params.id)));
  } catch (err) {
    handleServiceError(res, err);
  }
});

router.post('/:id/stop', (req, res) => {
  res.json(strategyService.stopStrategy(getDb(), Number(req.params.id)));
});

// Manual single-tick trigger — useful for testing a strategy without
// waiting for the interval, and for the UI's "run once" button.
router.post('/:id/run-once', async (req, res) => {
  await strategyService.runOnce(getDb(), Number(req.params.id));
  const strategy = strategyService.getStrategy(getDb(), Number(req.params.id));
  res.json(strategy);
});

module.exports = router;
