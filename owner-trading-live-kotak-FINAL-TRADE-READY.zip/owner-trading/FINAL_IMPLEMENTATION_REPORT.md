# Owner Trading — Final LIVE Kotak Hardening Report

## Scope

This release hardens the supplied `owner-trading-live-kotak-final-ready.zip` as one interconnected system:

`LIVE UI -> strategy -> real Kotak quote -> signal -> risk -> LIVE safety gate -> broker preflight -> Kotak Neo v3 order -> broker order status -> trade fills -> immutable fill ledger -> position/P&L -> reconciliation -> UI`

The integration targets the official actively maintained `kotakneoapi` Python SDK v3.0.6.

## Implemented fixes

### 1. Kotak v3 contract
- Keyword-based `NeoAPI(consumer_key=..., environment=...)`.
- TOTP login + MPIN validation.
- Correct v3 order products: `CNC`, `NRML`, `MIS`, `MTF`.
- Correct v3 order segments: `nse_cm`, `bse_cm`, `nse_fo`, `bse_fo`, `mcx_fo`.
- Correct order types used by the engine: `L` and `MKT`.
- `limits()` called with no arguments.
- `trade_report()` fetched as the full day report and filtered locally by `nOrdNo`.
- `modify_order()` uses only its current v3 parameters.
- Official `search_scrip()` is used for symbol/token resolution; no guessed instrument tokens.
- Broker REST error dictionaries are never treated as successful responses.

### 2. Order safety and lifecycle
- LIVE orders pass through emergency stop, explicit LIVE enable, broker connection, market-data, risk, and broker-margin preflight gates.
- Broker submission exceptions remain `UNKNOWN`/reconciliation-required rather than being guessed as rejected or filled.
- Modify/cancel timeouts also become reconciliation-required.
- Local order state is refreshed by broker order status and trade report.
- Broker order IDs are displayed in the Orders UI.

### 3. Fill ledger and partial fills
- Migration 010 adds routing fields to orders and realized P&L per fill.
- `fillService` is now the single idempotent fill-to-position path.
- Broker fill IDs are deduplicated.
- Partial fills accumulate safely.
- Reconciliation can be repeated without double-applying positions/P&L.

### 4. Strategy execution
- Fixed a real scope bug where the LIVE market snapshot variable was used outside its declaration scope.
- Added one in-flight execution lock per strategy to prevent overlapping scheduler/manual ticks.
- LIVE strategies cannot be started unless global trading mode is LIVE and Kotak is actually connected.
- Existing per-strategy failure isolation remains intact.

### 5. Risk
- Daily realized-loss calculation now uses the fill ledger and the IST trading date rather than all-time realized P&L.
- Order value, daily loss, open-position count, and order-rate limits remain fail-closed.
- LIVE broker margin preflight is performed before submission.

### 6. Broker/account reconciliation
- Added broker-native account snapshot endpoints for positions, holdings, and limits.
- Added local-vs-Kotak position reconciliation by symbol.
- Positions UI now exposes a `Reconcile with Kotak` control and clearly shows mismatches.
- Startup does not pretend an in-memory Kotak session survived a process restart.

### 7. LIVE UI
- Orders page polls for lifecycle changes and shows broker order IDs.
- LIVE order modification is exposed only for LIVE limit orders.
- P&L page correctly marks LIVE positions using real Kotak quotes and reports unavailable marks as unknown rather than synthetic.
- Market Data continues to keep PAPER simulator data and LIVE Kotak data strictly separated.

### 8. Deployment
- Deployment script remains one-command.
- OS dependency detection now also checks Python venv support independently of nginx/systemd presence.
- Stock nginx default site is disabled only when it is recognizably the stock Ubuntu site; custom default servers are not silently overwritten.
- Deployment health checks retry for up to 30 seconds.
- Systemd templates remain intentionally simple and do not reintroduce the VPS namespace hardening that previously caused startup failures.

## Validation performed in this build environment

PASS:
- JavaScript syntax checks for all backend `.js` files.
- Python syntax/compile check for `kotak_service/app.py`.
- SQLite migration chain 002 through 010 applied successfully to an in-memory database.
- New order routing and fill-ledger columns verified.
- Kotak bridge response-normalization tests verified for success, broker error, and session-expired responses.
- Static scan found no obsolete Kotak v2 call patterns in the broker bridge.
- Static scan found no `NOT_IMPLEMENTED` broker placeholder.

NOT RUN HERE:
- Full `npm test` / production frontend build, because dependency installation in this isolated build environment timed out. The VPS deployment script will install the declared Node/Python dependencies and run the real frontend build there.
- A real Kotak account order cannot be truthfully marked as executed from this build environment without the user's live credentials and broker session.

## Final LIVE acceptance gate

The supplied package is code-hardened for the live path, but the final real-money acceptance test remains an external VPS/broker verification:

1. Settings -> Save & Connect.
2. Confirm Kotak `CONNECTED`.
3. Confirm LIVE market data.
4. Confirm broker positions/holdings/limits.
5. Run broker reconciliation and require `MATCHED`.
6. Switch global mode to LIVE.
7. Enable LIVE only after the preflight passes.
8. Start a LIVE strategy deliberately.
9. Use the smallest controlled order size for the first real order.
10. Verify broker order number, status, fill quantity, fill price, local order, fill ledger, position and P&L.
11. Test reconciliation again.
12. Disable LIVE after the controlled test.

This report intentionally does **not** claim that a real-money order was executed during packaging.


## Final trade-readiness hardening pass

- Added a read-only background reconciliation worker: uncertain orders/fills are reconciled every 10 seconds; broker/local positions are checked every 30 seconds while Kotak is connected.
- A confirmed broker/local position mismatch automatically disables LIVE trading; it never liquidates positions automatically.
- Added graceful SIGTERM/SIGINT shutdown for the reconciliation worker.
- Fixed backend test discovery to execute the actual `backend/test/*.test.js` suite.
- Deployment remains the same one-command entrypoint (`./deploy/deploy.sh`) and now creates a consistent SQLite backup before dependency/build work and promotes the frontend build atomically after a successful build.
- No broker WebSocket was made a correctness dependency; the official current Kotak v3 SDK remains the broker contract, with REST reconciliation as the safety authority.
- Real-money acceptance still requires the user's actual VPS + Kotak session; this archive does not claim that a real order was executed.
