# v13 - Phase 6: scanner UI diagnostics and release certification

## Scanner page (frontend/src/pages/Scanner.jsx, src/lib/scanDiagnostics.js, styles in maBuilder.css)
Phone-first (cards, no wide tables); the existing layout and controls are kept.
* **Four status cards:** Universe coverage (`2,800 / 2,947`, "147 stocks over the limit"), Data readiness (`2,771 ready`, `29 not ready`), Scan status
  (Complete / Partial / Waiting for data / Failed, duration, matches, "try N") and Live feed (`2,845 / 3,000`, slots free or waiting).
* **Banners:** a partial scan says "Zero matches does not mean there are no setups"; waiting-for-data, failed and invalid scans have their own
  banner; stocks beyond the feed limit get a separate notice even when the scan is complete.
* **Matched stocks as cards** with badges: Data fresh, Feed subscribed / No live feed, Candle HH:MM (last completed candle).
* **Scan history as cards:** bar, timeframe, status (with "try N"), ready %, coverage %, universe / evaluated / matched, duration, error.
* **"Check data and feed" (read-only):** one button that reports this installation's real numbers - stocks synced, per active scanner how many stocks
  are ready / without candles / short of bars / stale, what it covers, last run, the live feed by tier, the tick writer, bars forming. It records,
  subscribes and downloads nothing (`scanner_engine.diagnostics`, `GET /api/algo/scanner-diagnostics`, test-proven read-only).
* Every number comes from the broker service; a missing value shows as a dash. The pure logic (`scanDiagnostics.js`) has 10 unit tests.
* Backend: manual scans are classified and recorded like scheduled ones; each match row carries `data_status`, `subscription`, `last_completed_candle`.

## Release certification (what was run, and what could not be)
| Check | Result |
|---|---|
| Python broker-service, fresh ZIP extraction | 607 tests pass under unittest; 0 fail |
| 4 test files written for pytest (18 tests; this machine has no pytest) | run through a pytest shim: 18 pass; `deploy.sh` runs them with real pytest |
| Frontend `node --test` | 33 pass, 0 fail |
| Backend `node --test` | 29 pass, 0 fail, 6 skipped (the Express session E2E tests need the npm dependencies, which are not installed here) |
| Frontend bundle | the whole app bundles with esbuild (336 KB, externals react / react-router), no errors; TypeScript finds no undefined names in Scanner.jsx; the same 8 type-noise diagnostics as v12. NOT run: `vite build` itself (no npm packages here; `deploy.sh` runs it) |
| Migrations | none added in v13; all existing migrations apply in every test database |
| Vendored Kotak SDK | 52 files match `VENDOR_MANIFEST.sha256`; byte-identical to `kotak-neo-python-main` |
| Synthetic large universe (`broker-service/tools/load_test_scanner.py`, in tests too) | see numbers below |
| Real Kotak feed, real VPS | NOT measured here: use the in-app "Check data and feed" and `tools/load_test_scanner.py` on the VPS |

Load test, this machine, 2,800 stocks x 160 five-minute bars (448,000 candle rows, `required_bars` 155):
candle read 1.1 s - what-is-missing check 1.2 s - full scan with a rich definition 2.7 s (readiness 100 %, COMPLETE) - feed manager: 2,800 scanner keys
+ 150 candidates + 120 positions on a full 3,000 feed evicts 70 scanner stocks in 18 ms, total exactly 3,000 - tick path 24 us per tick - closing all
2,800 bars 29 ms on the event-loop thread, 238 ms written by the background thread.
Heaviest definition (ema200, 600-bar window, 1.7 million rows): candle read 4.6 s, full scan 6.4 s (runs once per bar in a worker thread).

## Repository tidy-up
The 25 old audit/fix reports moved from the project root to `docs/history/`; the v13 phase reports are in `docs/v13/`. Nothing in the code reads them.
