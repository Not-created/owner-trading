# Owner Trading v13 - release report

v13 = v12 plus six phases that make the scanner and the live data path trustworthy. No order logic, risk gate, strategy chain or Kotak
SDK code was changed in meaning; saved strategies and scanners keep working unchanged.

| Phase | What it fixes | Report |
|---|---|---|
| 1 | The tick handler blocked the event loop that runs protective exits (SQLite connection per tick) | PHASE_1 |
| 2 | Bars written only on the next tick; fake pre-open/post-close bars; the last bar of the day never scanned | PHASE_2 |
| 3 | Daily prep warmed different stocks than the scanner scans; no coverage numbers; very slow candle queries | PHASE_3 |
| 4 | A full feed refused open positions; failed scans never retried; no scan status | PHASE_4 |
| 5 | Same condition, different answers in scanner / strategy / exit / backtest; MACD crashed; VWAP wrong in the scanner | PHASE_5 |
| 6 | Scanner page showed none of this; no way to see real numbers on the VPS | PHASE_6 |

## The ten findings that mattered most (all fixed and tested)
1. Every tick opened up to three SQLite connections on the event loop that also runs SL/target exits (4.5 ms per tick measured; now 0.12 ms, then 24 us).
2. A bar reached the database only when the same stock ticked again: scans at bar close silently read the bar before.
3. A full feed rejected the whole batch, so an open position could be denied a slot while 2,800 scanner stocks held them all (now evicts the least important).
4. Any condition using MACD raised an exception in v12 (scanner and live strategy).
5. EMA / RSI / ADX / ATR / MACD / VWAP gave different values in the scanner (22 bars), live strategy (250), exit (250) and backtest (300).
6. Daily prep warmed the first 3,000 instruments of all series alphabetically, not the EQ stocks the scanner scans.
7. The candle query ranked every row of the timeframe (6.1 s for 2,800 stocks, ~18 s on 30 days of history); now 0.18 s. The "what is missing" check took 10.9 s; now 0.22 s.
8. A failed scan was never retried for its bar and left no record; retry state is now durable (restart-safe) with backoff.
9. Strategy evaluation read the previous bar (introduced in Phase 1, found and fixed in the re-audit): closed bars are written before they are evaluated.
10. MCX (commodities) segments were governed by the equity session rule (introduced in Phase 2, found and fixed in the re-audit).

## Found by re-auditing earlier phases (each round found real problems; all are fixed)
Phase 1: strategy evaluation read the previous bar; no flush on service restart (a second of candles lost per deploy); `last_tick_at` was the write time.
Phase 2: bar close hit the strategy engine 2,800 times at once; a bar forming at a crash was lost; manual scans did not flush due bars; the session rule broke MCX; `bar_end` for bars starting after the close.
Phase 3: see the follow-up section of the Phase 3 report. Phase 4: a released scanner could be resurrected by the retry; evicted candidates were not restored.
Phase 5: the exit path used a different window than the entry.

## Known limitations (read before relying on it)
* **Not measured on the real VPS or the real Kotak feed.** Use Scanner page -> "Check data and feed" and `python tools/load_test_scanner.py` there.
* `vite build` and the 6 Express session E2E tests were not run here (no npm packages in the build environment); `deploy.sh` runs the build and the full Python suite and refuses to continue if they fail.
* Stocks beyond the live-feed budget (2,800, less what positions/candidates hold) are scanned on stored candles only and are reported, not rotated through the feed.
* Live bars (from LTP ticks) and broker history bars can differ slightly in OHLCV for the same bar; the condition logic is identical.
* Daily prep's 10-minute budget may not finish 2,800 stocks in one attempt on a slow API; it resumes with only the missing stocks on each 5-minute retry.
* "No trade in the last bar" and "data stale" still share one `stale` counter.
* A condition needing the full 600-bar window (ema200) makes a scan take ~6 s on this machine; it runs once per bar in a worker thread.

## Behaviour changes you will notice
* Indicator values are the converged ones (closer to charting platforms): scans can match slightly different stocks than v12.
* A stock is judged only with its full window (ema20 65 bars instead of 22, rsi14 87 instead of 17). Until history is back-filled it shows as "insufficient history".
* Scan runs now say COMPLETE / PARTIAL / WAITING_FOR_DATA / FAILED / INVALID (older rows say OK = complete).
* Pre-open and post-close ticks no longer create bars; the startup removes the old fake intraday bars (equity segments only).
* Optional setting `HISTORY_FETCH_CONCURRENCY` (1-6, default 2): raise only if Kotak's limits allow.

## Deploy (from the VPS shell)
1. Upload and unzip the release; run `./deploy.sh` as before (it backs up, builds, migrates, runs the tests, restarts, health-checks; no migrations are new in v13).
2. Open Scanner -> "Run check". Healthy: stocks synced > 0; each active scanner "Complete" or "Partial" with readiness rising on every refresh; live feed used < 3,000;
   tick writer "running" with 0 errors and a last write in tens of milliseconds.
3. During market hours, after a bar closes (+ a few seconds): scan history shows the bar with status Complete and "ready" near 100 %.
Rollback: `deploy.sh` keeps a backup of the previous release (see its output).

## After deployment: what to watch on the first trading day
Partial scans for the first minutes while history loads (normal: the banner says so); `GET /status` -> `tickWriter.errors` stays 0; no "Open position(s) without a live feed" error in the log.
