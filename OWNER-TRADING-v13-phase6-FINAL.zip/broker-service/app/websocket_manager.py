"""Market (SFeed) and order-feed supervision on the official async SDK clients.

Uses ONLY the SDK's modern clients (`NeoAPI.create_websocket()` -> SFeedWebSocket,
`NeoAPI.create_order_feed()` -> OrderFeedWebSocket) with their documented
callbacks (on_message / on_connect / on_disconnect / on_error) and
`subscribe_scrips(list[WsToken])`. The legacy v2 callback-attribute /
`subscribe(instrument_tokens=...)` handling has been removed.

Division of labour (from the SDK source):
  * The SDK client reconnects on its own (reconnect_delay x max_reconnect_attempts)
    and re-sends its own subscriptions.
  * THIS supervisor covers what the SDK does not: (a) a client that gave up
    (is_connected stays False past the SDK's own retry window) -> build a new
    client from the current session, back off, resubscribe from our registry;
    (b) after ANY (re)connect of the order feed -> REST reconciliation, because
    order events sent while disconnected are not replayed;
    (c) repeated failures -> probe the session with a read-only limits() call so
    an expired session moves the service to SESSION_EXPIRED instead of looping.
"""
from __future__ import annotations

import asyncio
import logging
import random
import math
import time
from typing import Any

from . import db as _db
from . import order_sync, sdk_adapter
from .broker_client import NotConfiguredError, broker_client
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket")

# SDK retries internally for about reconnect_delay * max_reconnect_attempts (5s * 5).
SDK_RECONNECT_WINDOW_SECONDS = 30
LOST_GRACE_SECONDS = SDK_RECONNECT_WINDOW_SECONDS + 10
BACKOFF_START, BACKOFF_MAX = 2.0, 60.0
PROBE_AFTER_FAILURES = 3
TICK_WRITE_INTERVAL_SECONDS = 1.0
STALE_AFTER_SECONDS = 90   # informational only: silence is normal outside market hours
_TICK_TYPES = ("scrip", "scrip_lite", "index")


def _sane_circuit(raw, ltp, *, upper: bool):
    """A circuit limit is only trusted when it is a finite positive number on the correct side of the
    LTP and within a plausible distance of it (guards against unscaled/sentinel values)."""
    try:
        value = float(raw)
        price = float(ltp)
    except (TypeError, ValueError):
        return None
    if not (math.isfinite(value) and value > 0 and price > 0):
        return None
    if upper and not (price * 0.999 <= value <= price * 2.5):
        return None
    if not upper and not (price * 0.4 <= value <= price * 1.001):
        return None
    return value



def _tick_writer_status() -> dict:
    """Write-behind health: pending buffers, last flush duration and the last database error (if any)."""
    try:
        from .tick_writer import tick_writer
        return {"running": tick_writer.running, "pending": tick_writer.pending(), **tick_writer.stats}
    except Exception as exc:  # noqa: BLE001 -- diagnostics must never break /status
        return {"running": False, "error": str(exc)[:120]}


class WebSocketManager:
    def __init__(self) -> None:
        # Actual SFeed subscriptions are the union of logical owners. A token
        # can simultaneously belong to the scanner universe, multiple strategy
        # candidates, and a manually selected market-data subscription. We only
        # send the broker unsubscribe frame when the final owner releases it.
        self._subs: dict[tuple[str, str], None] = {}
        self._owners: dict[tuple[str, str], set[str]] = {}
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()
        self._market: Any = None
        self._order: Any = None
        self._last_market_msg: float | None = None
        self._last_order_msg: float | None = None
        self._last_tick_write: dict[tuple[str, str], float] = {}
        self._reconnects = {"market": 0, "order": 0}
        self._reconcile_task: asyncio.Task | None = None
        self._market_status: dict[str, dict] = {}
        self._max_subscriptions = 3000
        # Feed-manager state (Phase 4): keys that could not be subscribed and must be retried, and what was evicted.
        self._pending: dict[tuple[str, str], str] = {}          # key -> owner that wanted it
        self._resubscribe_needed = False
        self._evicted_total = 0
        self._last_eviction: dict | None = None
        self._last_rejection: dict | None = None

    # ------------------------------------------------------------ lifecycle
    @property
    def running(self) -> bool:
        return any(not t.done() for t in self._tasks)

    async def start(self) -> None:
        if self.running:
            return
        self._stop = asyncio.Event()
        # Phase 1: tick-path database writes are batched by a background thread (see tick_writer.py).
        # The forming-bar checkpoints are loaded once here so no tick ever needs its own SQLite read.
        try:
            from .candle_engine import candle_engine
            loaded = await asyncio.to_thread(candle_engine.preload_runtime_state)
            logger.info("Loaded %d forming-bar checkpoint(s) before starting the market feed.", loaded)
        except Exception as exc:  # noqa: BLE001 -- falls back to per-key reads; never blocks the feed
            logger.warning("Could not preload forming-bar checkpoints: %s", exc)
        try:
            from .tick_writer import tick_writer
            tick_writer.start()
        except Exception as exc:  # noqa: BLE001 -- without it every write is synchronous (the old behaviour)
            logger.warning("Could not start the tick writer: %s", exc)
        self._tasks = [
            asyncio.create_task(self._supervise("market", self._run_market)),
            asyncio.create_task(self._supervise("order", self._run_order)),
        ]

    async def ensure_started_and_wait(self, timeout: float = 15.0) -> dict:
        """Start both LIVE feeds and wait briefly for their initial connection.

        The supervisor is intentionally asynchronous for long-term recovery, but
        the initial connect path must not report a healthy broker while the order
        feed is still booting. Waiting here removes that startup race without
        weakening the normal reconnect supervisor. A timeout is reported as a
        diagnostic result; the supervisor continues retrying in the background.
        """
        await self.start()
        # A test/dry harness may deliberately stub start() and provide no
        # supervisor tasks. In that case there is nothing real to wait for;
        # production start() always creates both supervisor tasks.
        if not self._tasks:
            status = self.status()
            return {
                "ready": bool(status["market"]["connected"] and status["orderFeed"]["connected"]),
                "market": bool(status["market"]["connected"]),
                "order": bool(status["orderFeed"]["connected"]),
            }
        deadline = asyncio.get_running_loop().time() + max(0.0, float(timeout))
        while asyncio.get_running_loop().time() < deadline:
            m = self._market
            o = self._order
            if m is not None and o is not None and m.is_connected and o.is_connected:
                return {"ready": True, "market": True, "order": True}
            await asyncio.sleep(0.25)
        status = self.status()
        return {
            "ready": bool(status["market"]["connected"] and status["orderFeed"]["connected"]),
            "market": bool(status["market"]["connected"]),
            "order": bool(status["orderFeed"]["connected"]),
        }

    async def stop(self) -> None:
        self._stop.set()
        try:
            from .candle_engine import candle_engine
            candle_engine.flush()
        except Exception as exc:
            logger.warning("Failed to flush forming candles during websocket stop: %s", exc)
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        self._tasks = []
        for feed in (self._market, self._order):
            await self._safe_close(feed)
        self._market = self._order = None
        try:
            from .tick_writer import tick_writer
            await asyncio.to_thread(tick_writer.stop)   # writes everything still buffered
        except Exception as exc:  # noqa: BLE001
            logger.warning("Tick writer did not stop cleanly: %s", exc)

    @staticmethod
    async def _safe_close(feed) -> None:
        if feed is None:
            return
        try:
            await feed.close()
        except Exception:  # noqa: BLE001
            pass

    # -------------------------------------------------------- subscriptions
    async def subscribe(self, exchange_segment: str, instrument_token: str, owner: str = "manual") -> None:
        result = await self.subscribe_many([(exchange_segment, str(instrument_token))], owner=owner)
        if result.get("rejected"):       # callers mark candidates/positions as "subscribed" only when this returns normally
            raise ValueError(result.get("reason") or f"SFeed subscription limit reached ({self._max_subscriptions}).")

    async def unsubscribe(self, exchange_segment: str, instrument_token: str, owner: str = "manual") -> None:
        await self.unsubscribe_many([(exchange_segment, str(instrument_token))], owner=owner)

    def _key_rank(self, key: tuple[str, str]) -> int:
        """Priority rank of a subscribed key = its MOST important owner (0 = open position ... 6 = other)."""
        owners = self._owners.get(key) or set()
        return min((self.TIER_ORDER.index(self._tier_of(o)) for o in owners), default=len(self.TIER_ORDER) - 1)

    def _eviction_candidates(self, requester_rank: int, exclude: set) -> list[tuple[str, str]]:
        """Subscriptions that may be dropped to make room for an owner of rank ``requester_rank``: only keys whose best
        owner is strictly LESS important. Least important first; within a tier the least liquid stock first."""
        try:
            volume = _db.volume_rank_map()
        except Exception:  # noqa: BLE001 -- ordering only
            volume = {}
        victims = [k for k in self._subs if k not in exclude and self._key_rank(k) > requester_rank]
        victims.sort(key=lambda k: (-self._key_rank(k), volume.get(k, 0)))
        return victims

    async def _evict(self, keys: list[tuple[str, str]], *, for_owner: str) -> None:
        feed = self._market
        if feed is not None and feed.is_connected:
            for i in range(0, len(keys), 500):
                try:
                    await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*k) for k in keys[i:i + 500]])
                except Exception as exc:  # noqa: BLE001 -- drop them from the registry regardless; the slot is what matters
                    logger.warning("Broker unsubscribe during eviction failed: %s", exc)
        tiers: dict[str, int] = {}
        for k in keys:
            t = self.TIER_ORDER[self._key_rank(k)]
            tiers[t] = tiers.get(t, 0) + 1
            if t not in ("scanner_universe", "other"):
                # something a strategy or the user asked for: queue it so retry_pending() restores it when a slot frees up
                best = min(self._owners.get(k) or {for_owner}, key=lambda o: self.TIER_ORDER.index(self._tier_of(o)))
                self._pending[k] = best
            self._subs.pop(k, None)
            self._owners.pop(k, None)
        self._evicted_total += len(keys)
        self._last_eviction = {"count": len(keys), "for_owner": for_owner, "tiers": tiers, "at": time.time()}
        logger.warning("Feed full: dropped %d lower-priority subscription(s) %s to make room for %s.", len(keys), tiers, for_owner)

    async def subscribe_many(self, keys: list[tuple[str, str]], owner: str = "manual") -> dict:
        """Add a logical subscription owner and ensure its SFeed membership, within the hard feed limit.

        `owner` is deliberately separate from the broker's actual subscription: shared instruments therefore cannot be
        accidentally unsubscribed when one strategy disarms or one candidate expires.

        Admission control (Phase 4). The limit used to reject the WHOLE batch, so an open position or a fresh
        candidate could be refused a feed slot while 2,800 scanner stocks held them all. Now:
          * keys that fit are admitted;
          * when full, less important subscriptions are evicted (open positions > candidates > strategy stocks > orders >
            manual > scanner universe > other); equal or more important ones are never touched;
          * what still does not fit is NOT recorded as owned: it is returned in ``rejected`` (and queued for a retry);
          * a failing broker batch no longer abandons the batches after it.
        """
        owner = str(owner or "manual")
        normalized = []
        for exchange_segment, instrument_token in keys:
            if exchange_segment not in sdk_adapter.EXCHANGE_SEGMENTS:
                raise ValueError(f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}.")
            normalized.append((exchange_segment, str(instrument_token)))
        normalized = list(dict.fromkeys(normalized))
        new_keys = [k for k in normalized if k not in self._subs]
        rank = self.TIER_ORDER.index(self._tier_of(owner))
        evicted = 0
        free = self._max_subscriptions - len(self._subs)
        if len(new_keys) > free:
            victims = self._eviction_candidates(rank, exclude=set(normalized))[:len(new_keys) - free]
            if victims:
                await self._evict(victims, for_owner=owner)
                evicted = len(victims)
            free = self._max_subscriptions - len(self._subs)
        admit, rejected = (new_keys, []) if len(new_keys) <= free else (new_keys[:max(0, free)], new_keys[max(0, free):])
        failed: list[tuple[str, str]] = []
        feed = self._market
        added = []
        if feed is not None and feed.is_connected and admit:
            for i in range(0, len(admit), 500):
                batch = admit[i:i + 500]
                try:
                    await feed.subscribe_scrips([sdk_adapter.make_ws_token(*k) for k in batch])
                except Exception as exc:  # noqa: BLE001 -- keep going: one bad batch must not drop the rest
                    logger.warning("SFeed subscription batch of %d failed: %s", len(batch), exc)
                    failed.extend(batch)
                    continue
                for key in batch:
                    self._subs[key] = None
                    self._owners.setdefault(key, set()).add(owner)
                    added.append(key)
        else:
            for key in admit:
                self._subs[key] = None
                self._owners.setdefault(key, set()).add(owner)
                added.append(key)
        # Existing broker subscriptions still need the new logical owner.
        for key in normalized:
            if key in self._subs:
                self._owners.setdefault(key, set()).add(owner)
        not_done = rejected + failed
        for key in not_done:
            self._pending[key] = owner                       # retried by retry_pending()
        reason = None
        if not_done:
            reason = (f"SFeed subscription limit reached ({self._max_subscriptions}): {len(rejected)} not admitted"
                      + (f", {len(failed)} failed at the broker" if failed else "") + ".")
            self._last_rejection = {"owner": owner, "rejected": len(rejected), "failed": len(failed), "at": time.time()}
        for key in normalized:
            if key in self._pending and key in self._subs:
                self._pending.pop(key, None)                 # it made it in (a retry succeeded)
        return {"requested": len(normalized), "added": len(added), "total": len(self._subs), "owner": owner,
                "evicted": evicted, "rejected": [list(k) for k in not_done], "reason": reason}

    async def retry_pending(self) -> dict:
        """Re-attempt subscriptions that were not admitted or failed at the broker, and re-send the whole registry after a
        failed resubscribe. Cheap when there is nothing pending; called from the scanner loop."""
        retried = recovered = 0
        if self._resubscribe_needed and self._market is not None and self._market.is_connected:
            self._resubscribe_needed = False
            await self._resubscribe(self._market)
        by_owner: dict[str, list[tuple[str, str]]] = {}
        for key, owner in list(self._pending.items()):
            if key in self._subs:
                self._pending.pop(key, None)
                continue
            by_owner.setdefault(owner, []).append(key)
        for owner, keys in by_owner.items():
            retried += len(keys)
            try:
                result = await self.subscribe_many(keys, owner=owner)
                recovered += result["added"]
            except Exception as exc:  # noqa: BLE001
                logger.warning("Retry of pending subscriptions for %s failed: %s", owner, exc)
        return {"retried": retried, "recovered": recovered, "still_pending": len(self._pending)}

    def non_scanner_used(self) -> int:
        """Subscriptions held for something MORE important than the scanner universe (positions, candidates, strategy
        stocks, orders, manual). The scanner may only use what is left."""
        limit_rank = self.TIER_ORDER.index("scanner_universe")
        return sum(1 for k in self._subs if self._key_rank(k) < limit_rank)

    def feed_status(self) -> dict:
        """The numbers behind the 'Live feed  used / 3,000' card."""
        counts = self.tier_counts()
        used = len(self._subs)
        return {"used": used, "limit": self._max_subscriptions, "free": max(0, self._max_subscriptions - used), "tiers": counts,
                "pending": len(self._pending), "evicted_total": self._evicted_total, "last_eviction": self._last_eviction,
                "last_rejection": self._last_rejection}

    async def unsubscribe_many(self, keys: list[tuple[str, str]], owner: str = "manual") -> dict:
        owner = str(owner or "manual")
        normalized=list(dict.fromkeys((s,str(t)) for s,t in keys))
        feed=self._market
        removed=0; released=0
        open_positions=self._open_position_owner_map() if not owner.startswith(self.POSITION_OWNER_PREFIX) else {}
        to_drop: list[tuple[str, str]] = []
        for key in normalized:
            owners=self._owners.get(key,set())
            if owner in owners:
                owners.discard(owner); released += 1
            if not owners and key in open_positions and key in self._subs:
                # Last strategy/candidate/manual owner is leaving, but an OPEN position still
                # needs this instrument's ticks for its protective exits: hand it to the position.
                owners.add(open_positions[key]); self._owners[key]=owners
            if owners:
                continue
            if key not in self._subs:
                self._owners.pop(key,None)
                continue
            to_drop.append(key)
        if to_drop and feed is not None and feed.is_connected:
            for i in range(0,len(to_drop),500):      # one broker call per 500 keys (it was one call per key)
                try:
                    await feed.unsubscribe_scrips([sdk_adapter.make_ws_token(*k) for k in to_drop[i:i+500]])
                except Exception as exc:  # noqa: BLE001 -- the registry is authoritative; do not strand the other keys
                    logger.warning("Broker unsubscribe of %d token(s) failed: %s", len(to_drop[i:i+500]), exc)
        for key in normalized:
            if self._pending.get(key) == owner:
                self._pending.pop(key, None)
        for key in to_drop:
            self._subs.pop(key,None); self._owners.pop(key,None); self._pending.pop(key,None); removed += 1
        return {"requested":len(normalized),"released":released,"removed":removed,"total":len(self._subs),"owner":owner}

    async def release_owner(self, owner: str) -> int:
        """Release every logical subscription owned by one runtime component."""
        owner=str(owner)
        for key in [k for k, o in self._pending.items() if o == owner]:
            self._pending.pop(key, None)          # a released owner must not be brought back by retry_pending()
        keys=[key for key,owners in self._owners.items() if owner in owners]
        if not keys:return 0
        result=await self.unsubscribe_many(keys, owner=owner)
        return int(result.get("removed") or 0)

    POSITION_OWNER_PREFIX = "position:"

    def _open_position_owner_map(self) -> dict[tuple[str, str], str]:
        from . import db as _db
        out: dict[tuple[str, str], str] = {}
        try:
            for p in _db.list_algo_positions():
                if int(p.get("remaining_quantity") or 0) > 0:
                    out.setdefault((str(p["exchange_segment"]), str(p["instrument_token"])), f"{self.POSITION_OWNER_PREFIX}{int(p['id'])}")
        except Exception as exc:  # noqa: BLE001 -- never let a DB hiccup break feed management
            logger.error("Could not read open positions while releasing a subscription: %s", exc)
        return out

    async def sync_position_owners(self) -> dict:
        """Keep every OPEN algo position's instrument subscribed under its own owner.

        Tick-driven protective exits (stop / target / trailing / time) need live prices for as
        long as a position is open -- independent of whether the strategy that opened it is
        still LIVE-armed, its scanner candidate expired, or the process just restarted.
        DISARM therefore releases strategy/candidate owners (removing unneeded feed load) but
        can never starve an open position of ticks. Owners of closed positions are released.
        """
        from . import db as _db
        wanted: dict[str, tuple[str, str]] = {}
        for p in _db.list_algo_positions():
            if int(p.get("remaining_quantity") or 0) <= 0:
                continue
            wanted[f"{self.POSITION_OWNER_PREFIX}{int(p['id'])}"] = (str(p["exchange_segment"]), str(p["instrument_token"]))
        errors: list[str] = []
        subscribed = 0
        for owner, key in wanted.items():
            if owner in self._owners.get(key, set()):
                subscribed += 1
                continue
            try:
                result = await self.subscribe_many([key], owner=owner)
                if result.get("rejected"):
                    raise ValueError(result.get("reason") or "feed full")
                subscribed += 1
            except Exception as exc:  # noqa: BLE001 -- surface, never silently drop exit monitoring
                errors.append(f"{owner}: {type(exc).__name__}: {exc}")
                logger.error("Cannot subscribe open position feed %s: %s", owner, exc)
        released = 0
        current = {o for owners in self._owners.values() for o in owners if o.startswith(self.POSITION_OWNER_PREFIX)}
        for owner in current - set(wanted):
            released += await self.release_owner(owner)
        return {"positions": len(wanted), "subscribed": subscribed, "released": released, "errors": errors}

    async def ensure_owner_subscriptions(self, keys: list[tuple[str,str]], owner: str) -> dict:
        return await self.subscribe_many(keys, owner=owner)

    async def restore_armed_strategy_subscriptions(self) -> dict:
        """Rebuild persisted strategy/candidate owners after a process restart.

        Scanner-linked strategies restore only their still-active candidates;
        scanner-less strategies restore their explicit universe. This preserves
        the candidate architecture instead of subscribing an entire strategy
        universe merely because it is LIVE armed.
        """
        from . import db as _db
        # Remove stale strategy owners while preserving manual/scanner-universe
        # owners.
        for owner in list({o for owners in self._owners.values() for o in owners if o.startswith("strategy:")}):
            await self.release_owner(owner)
        restored=0
        for item in _db.list_live_armed_strategy_versions():
            vid=int(item["id"]); definition=item.get("definition") or {}
            scanner_ids=definition.get("scanner_ids") or []
            try:
                if scanner_ids:
                    for c in _db.list_strategy_candidates(strategy_version_id=vid, active_only=True):
                        owner=f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}"
                        try:
                            await self.subscribe(c["exchange_segment"],c["instrument_token"],owner=owner)
                            _db.mark_strategy_candidate_subscribed(c["id"],True)
                            restored += 1
                        except Exception as exc:
                            _db.mark_strategy_candidate_subscribed(c["id"],False,error=f"{type(exc).__name__}: {exc}")
                            logger.warning("Failed to restore candidate subscription strategy=%s token=%s: %s", vid, c.get("instrument_token"), exc)
                else:
                    universe=definition.get("universe") or {}
                    keys=[("nse_cm",str(t).strip()) for t in (universe.get("instrument_tokens") or []) if str(t).strip()] if isinstance(universe,dict) else []
                    if keys:
                        try:
                            await self.subscribe_many(keys,owner=f"strategy:{vid}:universe")
                            restored += len(keys)
                        except Exception as exc:
                            logger.warning("Failed to restore scanner-less strategy=%s subscriptions: %s", vid, exc)
            except Exception as exc:
                logger.warning("Strategy subscription recovery failed for version=%s: %s", vid, exc)
        logger.info("Restored %d persisted LIVE strategy subscription owner(s).", restored)
        try:
            pos = await self.sync_position_owners()
        except Exception as exc:  # noqa: BLE001
            pos = {"errors": [f"{type(exc).__name__}: {exc}"]}
            logger.error("Open-position subscription recovery failed: %s", exc)
        return {"restored": restored, "positions": pos}

    async def remove_if_unneeded(self, keys: list[tuple[str, str]] | None = None) -> int:
        """Remove stale strategy owners; never let one strategy block another.

        The actual broker subscription is retained whenever any owner still
        needs the token (scanner universe, another strategy, or manual UI).
        """
        from . import db as _db
        desired_candidates={(s,t,vid) for s,t,vid in _db.list_active_candidate_subscription_keys()}
        desired_strategy_owners=set()
        for s,t,vid in desired_candidates:
            desired_strategy_owners.add(f"strategy:{vid}:candidate:{s}:{t}")
        for item in _db.list_live_armed_strategy_versions():
            vid=int(item["id"]); definition=item.get("definition") or {}
            if definition.get("scanner_ids"):continue
            desired_strategy_owners.add(f"strategy:{vid}:universe")
        owners={o for owners in self._owners.values() for o in owners if o.startswith("strategy:")}
        removed=0
        for owner in owners-desired_strategy_owners:
            removed += await self.release_owner(owner)
        if keys is not None:
            # Caller-provided keys are retained if any non-strategy owner still
            # holds them; otherwise the strategy-owner cleanup above is enough.
            pass
        return removed

    def subscription_owners(self, key: tuple[str,str] | None = None):
        if key is not None:
            return sorted(self._owners.get(key,set()))
        return {f"{s}:{t}": sorted(owners) for (s,t),owners in self._owners.items()}

    # Highest priority first. A feed key belongs to its most important owner, so open positions are never
    # counted (or treated) as "just scanner universe".
    TIER_ORDER = ("positions", "candidates", "strategy_stocks", "orders", "manual", "scanner_universe", "other")

    @staticmethod
    def _tier_of(owner: str) -> str:
        if owner.startswith("position:"):
            return "positions"
        if owner.startswith("strategy:") and "candidate" in owner:
            return "candidates"
        if owner.startswith("strategy:"):
            return "strategy_stocks"
        if owner.startswith("order:"):
            return "orders"
        if owner.startswith("scanner-manual") or owner.startswith("manual"):
            return "manual"
        if owner.startswith("scanner-universe"):
            return "scanner_universe"
        return "other"

    @property
    def max_subscriptions(self) -> int:
        return self._max_subscriptions

    def has_owner(self, owner: str) -> bool:
        return any(owner in owners for owners in self._owners.values())

    def tier_counts(self) -> dict:
        """How the live feed budget is used, by priority tier (each subscribed token counted once)."""
        counts = {t: 0 for t in self.TIER_ORDER}
        for key in self._subs:
            owners = self._owners.get(key) or set()
            best = min((self.TIER_ORDER.index(self._tier_of(o)) for o in owners), default=len(self.TIER_ORDER) - 1)
            counts[self.TIER_ORDER[best]] += 1
        counts["total"] = len(self._subs)
        counts["limit"] = self._max_subscriptions
        return counts

    def subscriptions(self) -> list[dict]:
        # Resolve display metadata in one bounded DB lookup so a large (up to 3000)
        # subscription set does not cause one SQLite query per row.
        metadata = _db.get_instruments_for_keys(list(self._subs))
        out = []
        for s, t in self._subs:
            item = {"exchange_segment": s, "instrument_token": t}
            instrument = metadata.get((s, t))
            if instrument:
                item["trading_symbol"] = instrument.get("trading_symbol")
                item["name"] = instrument.get("name")
            out.append(item)
        return out

    # ------------------------------------------------------------- status
    def is_stale(self) -> bool:
        """True when a market subscription exists, the feed claims to be
        connected, and nothing arrived for STALE_AFTER_SECONDS. Informational
        (no ticks is normal when the market is closed); never forces a reconnect."""
        if not self._subs or self._market is None or not self._market.is_connected:
            return False
        if self._last_market_msg is None:
            return False
        return (time.time() - self._last_market_msg) > STALE_AFTER_SECONDS

    def status(self) -> dict:
        m, o = self._market, self._order
        return {
            "running": self.running,
            "market": {"connected": bool(m and m.is_connected), "subscriptions": len(self._subs),
                       "lastMessageAt": self._last_market_msg, "reconnects": self._reconnects["market"], "stale": self.is_stale(),
                       "maxSubscriptions": self._max_subscriptions, "marketStatus": self._market_status,
                       "ownedSubscriptions": sum(len(v) for v in self._owners.values())},
            "orderFeed": {"connected": bool(o and o.is_connected), "lastMessageAt": self._last_order_msg,
                          "reconnects": self._reconnects["order"]},
            "tickWriter": _tick_writer_status(),
            "feed": self.feed_status(),
        }

    # ----------------------------------------------------------- supervisor
    async def _supervise(self, name: str, runner) -> None:
        backoff, failures = BACKOFF_START, 0
        while not self._stop.is_set():
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                await self._sleep(2.0)   # no valid session: nothing to (re)connect to
                continue
            started = time.time()
            try:
                await runner()
                failures = 0
            except asyncio.CancelledError:
                raise
            except NotConfiguredError:
                await self._sleep(2.0)
                continue
            except Exception as exc:  # noqa: BLE001
                failures += 1
                logger.warning("%s feed failed (%s: %s); failure %d.", name, type(exc).__name__, exc, failures)
            self._reconnects[name] += 1
            if time.time() - started > 60:      # a long healthy run resets backoff
                backoff, failures = BACKOFF_START, 0
            if failures >= PROBE_AFTER_FAILURES:
                await self._probe_session()
                failures = 0
            await self._sleep(backoff * (1 + random.uniform(0, 0.25)))
            backoff = min(backoff * 2, BACKOFF_MAX)

    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _probe_session(self) -> None:
        """Read-only limits(); an AUTH outcome flips state to SESSION_EXPIRED inside broker_client."""
        try:
            await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("limits"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session probe failed: %s", exc)

    async def _hold_until_lost(self, feed) -> None:
        """Returns once `feed` has been disconnected longer than the SDK's own retry window."""
        down_since: float | None = None
        while not self._stop.is_set():
            await asyncio.sleep(1.0)
            if current_state.state not in (BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING):
                return
            if feed.is_connected:
                down_since = None
            else:
                down_since = down_since or time.time()
                if time.time() - down_since > LOST_GRACE_SECONDS:
                    return

    # ------------------------------------------------------------- market
    async def _run_market(self) -> None:
        feed = broker_client.create_market_feed()
        self._market = feed
        feed.on_message = self._on_market_message
        feed.on_error = lambda e: logger.warning("SFeed error: %s", e)
        feed.on_connect = lambda: self._on_market_connect(feed)
        try:
            await feed.connect()
            try:
                await feed.subscribe_exchange()
            except Exception as exc:
                logger.warning("Market-status subscription unavailable: %s", exc)
            await self._resubscribe(feed)
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    async def _resubscribe(self, feed) -> None:
        tokens = [sdk_adapter.make_ws_token(s, t) for s, t in self._subs]
        for i in range(0, len(tokens), 500):
            try:
                await feed.subscribe_scrips(tokens[i:i + 500])
            except Exception as exc:  # noqa: BLE001 -- the batches after a failing one must still be sent
                logger.warning("Resubscribe batch %d failed: %s", i // 500, exc)
                self._resubscribe_needed = True      # retry_pending() sends the whole registry again

    def _on_market_connect(self, feed) -> None:
        # SDK-internal reconnects re-send its own subscriptions; if the counts
        # disagree (e.g. a new client), our registry is authoritative.
        if feed.subscription_count < len(self._subs):
            asyncio.get_running_loop().create_task(self._resubscribe(feed))

    def _on_market_message(self, message) -> None:
        self._last_market_msg = time.time()
        mtype = getattr(message, "type", None)
        if mtype == "market_status":
            seg = getattr(message, "exchange_segment", None)
            if seg:
                self._market_status[str(seg)] = {"status_code": getattr(message, "status_code", None), "status": getattr(message, "status", None), "updatedAt": time.time()}
            return
        if mtype not in _TICK_TYPES:
            return
        seg, tok = getattr(message, "exchange_segment", None), getattr(message, "instrument_token", None)
        ltp = getattr(message, "last_traded_price", None)
        if not tok or ltp is None:
            return
        # Malformed ticks (non-numeric, NaN/inf, zero/negative price) must never reach exits,
        # candles or the persisted LTP used by the final LIVE gate.
        try:
            ltp = float(ltp)
        except (TypeError, ValueError):
            logger.warning("Dropped malformed tick for %s|%s: non-numeric LTP %r", seg, tok, ltp)
            return
        if not math.isfinite(ltp) or ltp <= 0:
            logger.warning("Dropped malformed tick for %s|%s: invalid LTP %r", seg, tok, ltp)
            return
        now = time.time()
        key = (seg or "", str(tok))
        # Protective exits are deliberately NOT throttled with the 1-second
        # persistence writer. They consume every valid market tick.
        try:
            from .exit_engine import on_tick as exit_tick, may_have_position
            if may_have_position(seg, str(tok)):      # no task at all for the ~2,800 instruments without an open position
                asyncio.get_running_loop().create_task(
                    exit_tick(exchange_segment=seg, instrument_token=str(tok), price=float(ltp))
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Protective exit tick dispatch failed: %s", exc)
        # Candle construction must consume EVERY valid tick. SQLite persistence
        # remains throttled independently so database load does not distort OHLC.
        try:
            from .candle_engine import candle_engine
            import datetime as dt
            from zoneinfo import ZoneInfo
            raw_ts = getattr(message, "last_trade_time", None) or getattr(message, "last_update_time", None)
            tick_ts = None
            if raw_ts:
                epoch = float(raw_ts) / (1000.0 if float(raw_ts) > 1_000_000_000_000 else 1.0)
                tick_ts = dt.datetime.fromtimestamp(epoch, tz=dt.timezone.utc)
            candle_engine.on_tick(exchange_segment=seg, instrument_token=str(tok),
                                  trading_symbol=getattr(message, "trading_symbol", None), price=float(ltp),
                                  volume=getattr(message, "volume_traded_today", None), timestamp=tick_ts)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Candle/algo processing failed: %s", exc)

        if now - self._last_tick_write.get(key, 0) < TICK_WRITE_INTERVAL_SECONDS:
            return
        self._last_tick_write[key] = now
        try:
            from .tick_writer import tick_writer
            tick_writer.put_tick(      # in-memory only; a background thread writes it once per second
                instrument_token=str(tok), exchange_segment=seg, last_traded_price=float(ltp),
                trading_symbol=getattr(message, "trading_symbol", None),
                close_price=getattr(message, "close_price", None),
                volume=getattr(message, "volume_traded_today", None),
                upper_circuit=_sane_circuit(getattr(message, "upper_circuit_limit", None), ltp, upper=True),
                lower_circuit=_sane_circuit(getattr(message, "lower_circuit_limit", None), ltp, upper=False),
            )
        except Exception as exc:  # noqa: BLE001 -- a DB hiccup must not kill the receive loop
            logger.warning("Failed to persist tick: %s", exc)

    # -------------------------------------------------------- order feed
    async def _run_order(self) -> None:
        feed = broker_client.create_order_feed()
        self._order = feed
        feed.on_message = self._on_order_message
        feed.on_error = lambda e: logger.warning("Order feed error: %s", e)
        feed.on_connect = lambda: self._schedule_reconcile("order feed connected")
        try:
            await feed.connect()
            await self._hold_until_lost(feed)
        finally:
            await self._safe_close(feed)

    def _on_order_message(self, message) -> None:
        self._last_order_msg = time.time()
        mtype = getattr(message, "type", None)
        try:
            if mtype == "order":
                if getattr(message, "data", None) is None:
                    logger.warning("Ignoring order-feed message with no data payload")
                    return
                row = message.data.model_dump(by_alias=True)
                res = order_sync.apply_order_row(row, source="order_feed")
                if res["matched"] and res["changed"]:
                    self._schedule_reconcile("order update")   # picks up fills/positions via REST (authoritative)
            elif mtype == "position":
                self._schedule_reconcile("position update")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to process order-feed message: %s", exc)

    def _schedule_reconcile(self, reason: str) -> None:
        """Debounced: at most one pending reconciliation task."""
        if self._reconcile_task and not self._reconcile_task.done():
            return
        from . import reconciliation

        async def _go():
            await asyncio.sleep(1.5)
            try:
                await reconciliation.run_full_reconciliation()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconciliation (%s) failed: %s", reason, exc)

        try:
            self._reconcile_task = asyncio.get_running_loop().create_task(_go())
        except RuntimeError:
            pass


websocket_manager = WebSocketManager()
