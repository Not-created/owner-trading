// Strategy lifecycle + the per-tick execution loop.
//
// No-duplicate-workers guarantee: `runningIntervals` is a module-level
// Map keyed by strategy id. startStrategy() checks it before scheduling
// anything — calling start twice on the same strategy is a no-op, not a
// second interval.
//
// Failure isolation: if a strategy's code throws (or times out) on a
// tick, ONLY that strategy is stopped and marked ERROR with the reason
// recorded — its interval is cleared so it doesn't keep failing every
// tick, but every other running strategy is completely unaffected.
//
// SL/target takes precedence over the strategy's own signal for that
// tick: if an open position has breached its configured stop-loss or
// target percentage, an EXIT is issued and the strategy's code is not
// even invoked for that tick.

const executionLogService = require('./executionLogService');
const marketDataService = require('./marketDataService');
const strategyExecutor = require('./strategyExecutor');
const orderService = require('./orderService');
const positionService = require('./positionService');

const DEFAULT_INTERVAL_MS = 5000;
const runningIntervals = new Map(); // strategyId -> interval handle

const VALID_EXCHANGE_SEGMENTS = ['nse_cm', 'bse_cm', 'nse_fo', 'bse_fo', 'mcx_fo'];
const VALID_PRODUCTS = ['NRML', 'CNC', 'MIS', 'MTF'];

function validationError(code, message) {
  const err = new Error(message || code);
  err.code = code;
  return err;
}

function validateStrategyInput({
  name,
  code,
  symbol,
  mode,
  positionSizingType,
  positionSizingValue,
  exchangeSegment,
  product,
}) {
  if (!name || typeof name !== 'string' || !name.trim()) {
    throw validationError('INVALID_NAME', 'name is required');
  }
  if (!code || typeof code !== 'string' || !code.includes('function strategy')) {
    throw validationError(
      'INVALID_CODE',
      'code must define a `function strategy({ market, position, indicators })`'
    );
  }
  if (!symbol || typeof symbol !== 'string') {
    throw validationError('INVALID_SYMBOL', 'symbol is required');
  }
  if (mode && !['PAPER', 'LIVE'].includes(mode)) {
    throw validationError('INVALID_MODE', 'mode must be PAPER or LIVE');
  }
  if (positionSizingType && !['FIXED_QTY', 'FIXED_VALUE'].includes(positionSizingType)) {
    throw validationError('INVALID_POSITION_SIZING_TYPE', 'positionSizingType must be FIXED_QTY or FIXED_VALUE');
  }
  if (positionSizingValue !== undefined && !(Number(positionSizingValue) > 0)) {
    throw validationError('INVALID_POSITION_SIZING_VALUE', 'positionSizingValue must be a positive number');
  }
  if (exchangeSegment && !VALID_EXCHANGE_SEGMENTS.includes(exchangeSegment)) {
    throw validationError('INVALID_EXCHANGE_SEGMENT', `exchangeSegment must be one of: ${VALID_EXCHANGE_SEGMENTS.join(', ')}`);
  }
  if (product && !VALID_PRODUCTS.includes(product)) {
    throw validationError('INVALID_PRODUCT', `product must be one of: ${VALID_PRODUCTS.join(', ')}`);
  }
}

function createStrategy(db, input) {
  validateStrategyInput(input);
  const {
    name,
    code,
    symbol,
    mode = 'PAPER',
    positionSizingType = 'FIXED_QTY',
    positionSizingValue = 1,
    stopLossPercent = null,
    targetPercent = null,
    exchangeSegment = 'nse_cm',
    product = 'MIS',
  } = input;

  const info = db
    .prepare(
      `INSERT INTO strategies (name, code, symbol, mode, position_sizing_type, position_sizing_value, stop_loss_percent, target_percent, exchange_segment, product)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      name,
      code,
      symbol,
      mode,
      positionSizingType,
      positionSizingValue,
      stopLossPercent,
      targetPercent,
      exchangeSegment,
      product
    );

  return getStrategy(db, info.lastInsertRowid);
}

function getStrategy(db, id) {
  return db.prepare('SELECT * FROM strategies WHERE id = ?').get(id);
}

function listStrategies(db) {
  return db.prepare('SELECT * FROM strategies ORDER BY id DESC').all();
}

function updateStrategy(db, id, updates) {
  const strategy = getStrategy(db, id);
  if (!strategy) throw validationError('STRATEGY_NOT_FOUND', `No strategy #${id}`);
  if (strategy.status === 'RUNNING') {
    throw validationError('STRATEGY_RUNNING', 'Stop the strategy before editing it');
  }

  // Explicit field-by-field merge: `updates` arrives camelCase (from the
  // frontend/API), `strategy` is the snake_case DB row. Spreading them
  // together directly (`{...strategy, ...updates}`) was a real bug — the
  // camelCase keys never matched the snake_case ones they were meant to
  // override (e.g. `updates.positionSizingType` never touched
  // `strategy.position_sizing_type`), so editing sizing/SL/target/mode
  // silently did nothing. Found and fixed during the Kotak integration pass.
  const merged = {
    name: updates.name ?? strategy.name,
    code: updates.code ?? strategy.code,
    symbol: updates.symbol ?? strategy.symbol,
    mode: updates.mode ?? strategy.mode,
    position_sizing_type: updates.positionSizingType ?? strategy.position_sizing_type,
    position_sizing_value: updates.positionSizingValue ?? strategy.position_sizing_value,
    stop_loss_percent: updates.stopLossPercent !== undefined ? updates.stopLossPercent : strategy.stop_loss_percent,
    target_percent: updates.targetPercent !== undefined ? updates.targetPercent : strategy.target_percent,
    exchange_segment: updates.exchangeSegment ?? strategy.exchange_segment,
    product: updates.product ?? strategy.product,
  };

  validateStrategyInput({
    name: merged.name,
    code: merged.code,
    symbol: merged.symbol,
    mode: merged.mode,
    positionSizingType: merged.position_sizing_type,
    positionSizingValue: merged.position_sizing_value,
    exchangeSegment: merged.exchange_segment,
    product: merged.product,
  });

  db.prepare(
    `UPDATE strategies SET name = ?, code = ?, symbol = ?, mode = ?, position_sizing_type = ?,
       position_sizing_value = ?, stop_loss_percent = ?, target_percent = ?,
       exchange_segment = ?, product = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    merged.name,
    merged.code,
    merged.symbol,
    merged.mode,
    merged.position_sizing_type,
    merged.position_sizing_value,
    merged.stop_loss_percent,
    merged.target_percent,
    merged.exchange_segment,
    merged.product,
    id
  );

  return getStrategy(db, id);
}

function deleteStrategy(db, id) {
  const strategy = getStrategy(db, id);
  if (!strategy) throw validationError('STRATEGY_NOT_FOUND', `No strategy #${id}`);
  if (runningIntervals.has(id)) {
    stopStrategy(db, id);
  }
  db.prepare('DELETE FROM strategies WHERE id = ?').run(id);
}

function setEnabled(db, id, enabled) {
  db.prepare("UPDATE strategies SET enabled = ?, updated_at = datetime('now') WHERE id = ?").run(
    enabled ? 1 : 0,
    id
  );
  return getStrategy(db, id);
}

function computeQuantity(strategy, action, referencePrice, currentPosition) {
  if (action === 'EXIT') {
    return Math.abs(currentPosition.quantity);
  }
  if (strategy.position_sizing_type === 'FIXED_VALUE') {
    return Math.floor(strategy.position_sizing_value / referencePrice);
  }
  return Math.floor(strategy.position_sizing_value);
}

function checkStopLossOrTarget(strategy, position, referencePrice) {
  if (!position || position.quantity === 0) return null;

  const direction = position.quantity > 0 ? 1 : -1;
  const pnlPercent = ((referencePrice - position.avg_price) / position.avg_price) * 100 * direction;

  if (strategy.stop_loss_percent && pnlPercent <= -Math.abs(strategy.stop_loss_percent)) {
    return { action: 'EXIT', reason: `STOP_LOSS_HIT (${pnlPercent.toFixed(2)}%)` };
  }
  if (strategy.target_percent && pnlPercent >= Math.abs(strategy.target_percent)) {
    return { action: 'EXIT', reason: `TARGET_HIT (${pnlPercent.toFixed(2)}%)` };
  }
  return null;
}

// Runs exactly one execution cycle for one strategy. Exported directly so
// tests can call it deterministically without waiting on a real interval.
async function runOnce(db, strategyId) {
  const strategy = getStrategy(db, strategyId);
  if (!strategy) return;

  let referencePrice;
  let history;
  try {
    const snapshot = await marketDataService.getMarketSnapshot(strategy.symbol, strategy.mode, strategy.exchange_segment);
    referencePrice = snapshot.price;
    history = snapshot.history;
  } catch (err) {
    db.prepare(
      "UPDATE strategies SET status = 'ERROR', last_error = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(`MARKET_DATA_UNAVAILABLE: ${err.message}`, strategyId);
    executionLogService.error(db, strategyId, `Could not get market data, strategy stopped: ${err.message}`);
    const handle = runningIntervals.get(strategyId);
    if (handle) {
      clearInterval(handle);
      runningIntervals.delete(strategyId);
    }
    return;
  }
  const position = positionService.getOrCreate(db, strategyId, strategy.symbol, strategy.mode);

  db.prepare("UPDATE strategies SET last_run_at = datetime('now') WHERE id = ?").run(strategyId);

  const forcedExit = checkStopLossOrTarget(strategy, position, referencePrice);
  let signal;
  let execLogs = [];

  if (forcedExit) {
    signal = forcedExit;
    executionLogService.info(db, strategyId, `SL/Target override: ${forcedExit.reason}`);
  } else {
    const result = await strategyExecutor.runStrategy({
      code: strategy.code,
      context: {
        market: { price: referencePrice, history, source: snapshot.source, timestamp: snapshot.timestamp, bid: snapshot.bid, ask: snapshot.ask, volume: snapshot.volume },
        position: { quantity: position.quantity, avgPrice: position.avg_price },
      },
    });
    execLogs = result.logs;
    if (result.error) {
      // Clear the scheduler interval directly — do NOT call stopStrategy()
      // here, since it unconditionally sets status='STOPPED' and would
      // clobber the ERROR status being set below. Failure isolation means
      // this strategy stops running AND the error is visibly recorded,
      // not silently reset to a normal "stopped" look.
      const handle = runningIntervals.get(strategyId);
      if (handle) {
        clearInterval(handle);
        runningIntervals.delete(strategyId);
      }
      db.prepare(
        "UPDATE strategies SET status = 'ERROR', last_error = ?, updated_at = datetime('now') WHERE id = ?"
      ).run(result.error, strategyId);
      executionLogService.error(db, strategyId, `Execution failed, strategy stopped: ${result.error}`);
      return;
    }
    signal = result.signal;
  }

  for (const line of execLogs) {
    executionLogService.info(db, strategyId, `[strategy log] ${line}`);
  }

  if (signal.action === 'HOLD') {
    return;
  }

  if (signal.action === 'EXIT' && position.quantity === 0) {
    executionLogService.info(db, strategyId, 'EXIT signal received but there is no open position — skipping');
    return;
  }

  const quantity = computeQuantity(strategy, signal.action, referencePrice, position);
  if (!Number.isInteger(quantity) || quantity <= 0) {
    executionLogService.warn(
      db,
      strategyId,
      `Signal ${signal.action} produced an invalid quantity (${quantity}) — skipping order`
    );
    return;
  }

  const side =
    signal.action === 'EXIT' ? (position.quantity > 0 ? 'SELL' : 'BUY') : signal.action; // BUY/SELL pass through

  await orderService.createOrder(db, {
    strategyId,
    symbol: strategy.symbol,
    side,
    quantity,
    orderType: 'MARKET',
    mode: strategy.mode,
    exchangeSegment: strategy.exchange_segment,
    product: strategy.product,
  });
}

function startStrategy(db, id, intervalMs = DEFAULT_INTERVAL_MS) {
  const strategy = getStrategy(db, id);
  if (!strategy) throw validationError('STRATEGY_NOT_FOUND', `No strategy #${id}`);

  if (runningIntervals.has(id)) {
    return strategy; // already running — no duplicate worker
  }

  setEnabled(db, id, true);
  db.prepare("UPDATE strategies SET status = 'RUNNING', last_error = NULL, updated_at = datetime('now') WHERE id = ?").run(
    id
  );
  executionLogService.info(db, id, `Strategy started (interval: ${intervalMs}ms)`);

  const handle = setInterval(() => {
    runOnce(db, id).catch((err) => {
      // runOnce is designed not to throw, but guard anyway — a truly
      // unexpected error here must not crash the whole process.
      executionLogService.error(db, id, `Unexpected scheduler error: ${err.message}`);
    });
  }, intervalMs);
  handle.unref?.(); // don't keep the process alive just for this timer

  runningIntervals.set(id, handle);
  return getStrategy(db, id);
}

function stopStrategy(db, id) {
  const handle = runningIntervals.get(id);
  if (handle) {
    clearInterval(handle);
    runningIntervals.delete(id);
  }
  db.prepare("UPDATE strategies SET status = 'STOPPED', updated_at = datetime('now') WHERE id = ?").run(id);
  executionLogService.info(db, id, 'Strategy stopped');
  return getStrategy(db, id);
}

// Called once at process startup. No in-memory interval can have survived
// a restart, so any row still claiming RUNNING is lying — correct it.
// Deliberately does NOT auto-restart strategies: resuming automated
// execution silently after a crash/restart is a real-money-domain
// decision that must be a human action, not implicit.
function resetStrategyStatusOnStartup(db) {
  const result = db
    .prepare("UPDATE strategies SET status = 'STOPPED' WHERE status != 'STOPPED'")
    .run();
  return result.changes; // number of rows corrected, for startup logging
}

// Test/ops utility — clears all in-memory interval handles.
function stopAll(db) {
  for (const id of [...runningIntervals.keys()]) {
    stopStrategy(db, id);
  }
}

module.exports = {
  createStrategy,
  getStrategy,
  listStrategies,
  updateStrategy,
  deleteStrategy,
  setEnabled,
  startStrategy,
  stopStrategy,
  stopAll,
  runOnce,
  resetStrategyStatusOnStartup,
  computeQuantity,
  checkStopLossOrTarget,
};
