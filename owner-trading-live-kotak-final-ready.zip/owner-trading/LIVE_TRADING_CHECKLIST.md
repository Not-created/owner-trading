# Owner Trading — Final Controlled LIVE Checklist

This release is code-ready for controlled LIVE trading. It does not place a real order during deployment.

## What is real in LIVE mode

- Kotak Neo v3 authentication via TOTP + MPIN.
- Official Kotak scrip search and token resolution.
- Official Kotak real-time `quotes()` LTP path.
- LIVE risk reference prices come from Kotak only; there is no simulator fallback.
- Kotak order placement, status, modify and cancel.
- Broker trade-report reconciliation with an immutable `order_fills` ledger.
- Partial fills are aggregated by broker fill ID.
- Explicit LIVE enable gate plus global emergency stop.
- Startup forces LIVE off and reconciles uncertain orders before accepting requests.

## Market-data behavior

The Market Data page polls LIVE Kotak quotes every 3 seconds. It explicitly labels each row as `Kotak Neo LIVE` or `PAPER simulator`. This release does not claim SFeed WebSocket streaming.

## VPS verification

```bash
cd /home/ubuntu/owner-trading
chmod +x deploy/verify-live.sh
deploy/verify-live.sh
```

Then in the UI:

1. Settings → Save & Connect.
2. Confirm `CONNECTED` and a fresh verification timestamp.
3. Market Data → create/use a LIVE strategy and confirm a real Kotak LTP.
4. Verify positions, holdings, limits/funds and trade history.
5. Trading Control → keep LIVE disabled while doing the above.
6. Only after read-only checks succeed: set mode LIVE and explicitly enable LIVE.
7. For the first real test, use the smallest controlled order appropriate for the account.
8. Verify the broker order ID, broker status, fill, local `order_fills`, position and P&L.
9. If any broker response is uncertain, do **not** retry blindly. Reconcile first.

## Important

PAPER data is synthetic by design. It must never be used as evidence that a LIVE strategy or broker connection is working.
