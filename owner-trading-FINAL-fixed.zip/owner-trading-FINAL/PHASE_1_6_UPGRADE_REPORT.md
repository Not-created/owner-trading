# Owner Trading — Phase 1–6 Upgrade Report

## Implemented in this release

### Phase 1–3 retained and validated
- Production deployment hardening from the Phase 1–3 baseline is retained.
- `/opt/owner-trading` production runtime path and systemd ProtectHome design are retained.
- HTTPS/session handling, Node 22.5+ requirement, encrypted credential lifecycle, SFeed 3000 cap, IST candle buckets, cumulative-volume delta and completed-bar evaluation are retained.

### Phase 4 — Strategy/Scanner engine
- Added a canonical strategy DSL validation layer.
- Added BUY/SELL strategy direction.
- Added MACD, MACD signal/histogram, ADX, VWAP and price-action fields.
- Added timeframe/product validation and sizing validation.
- Added ATR-aware risk sizing support.
- Strategy versions cannot be saved as VALIDATED when their definition is invalid.
- Added Express/API validation endpoint.
- Scanner definitions use the same validation contract.
- Scanner activate/deactivate/update APIs added.
- Active scanners can gate live strategy candidates before signal creation.
- Runtime active strategy count is refreshed from armed versions.

### Phase 5 — LIVE execution/exit lifecycle
- Algo entry direction is no longer hard-coded BUY.
- Position limit is enforced per strategy version.
- Exit engine supports BUY/SELL-aware stop and target logic.
- Trailing stop state is persisted and moved monotonically.
- Time-based exit and partial-exit quantity are supported by the exit engine.
- Fill reconciliation updates/creates algo positions from the immutable signal → internal order chain.
- Partial fills update remaining quantity; full broker-flat reconciliation closes stale local algo positions.
- Reconciliation no longer leaves an OPEN local position merely because the broker returned no corresponding position row.

### Phase 6 — Backtest/reporting/UI integration
- Backtest supports BUY and SELL.
- Backtest evaluates candle high/low for stop/target instead of only close.
- Backtest supports trailing and time exits.
- Backtest results are persisted to `backtests` and `backtest_trades`.
- Backtest history API and UI were added.
- Strategy Builder UI now exposes side, timeframe, indicators, operators, risk and exit controls.
- Scanner UI now uses a condition builder rather than raw JSON as its primary input.
- API route contract updated for every new frontend call.

## Validation executed

- Python full test suite: **240 tests, 0 failures, 0 errors, 3 skipped**.
- Added Phase 4–6 strategy regression tests: **3 passed**.
- Python compileall: passed.
- Node syntax checks for changed backend JS: passed.
- Bash syntax checks: passed.
- Fresh SQLite migration replay for migrations 001–005: passed; 28 tables created.
- Strategy indicator/validation/backtest smoke test: passed.
- No Kotak credentials were used and no real broker order was placed.

## Environment limitation

The frontend dependency installation could not complete within the available environment timeout, so `vite build` could not be executed here because `node_modules` was not installed. This is intentionally reported as unverified rather than marked passed. The production deploy script must perform the frontend install/build on the target VPS and fail closed if it cannot.

## LIVE safety

This release does not claim that live-money trading is verified. Real Kotak authentication, SFeed/order-feed behavior and broker-side execution still require a controlled VPS smoke test with the owner's credentials. No real order should be sent merely to validate the ZIP.
