import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Dev-only proxy so the Vite dev server can forward /api/* to the backend
// on port 4000 without CORS friction. Not used in production — the backend
// serves the built frontend directly from the same origin.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:4000",
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: "dist",
  },
});
