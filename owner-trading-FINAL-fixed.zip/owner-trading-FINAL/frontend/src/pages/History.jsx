import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import usePolling from "../hooks/usePolling";
import { fmt } from "../lib/format";

export default function History() {
  const { loading, error, body } = usePolling(() => api.getTrades(), 10000);
  const trades = ((body && body.trades) || []).slice().reverse();
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Trade history</h2>
        <p className="page__subtitle">Every recorded fill is reconciled from Kotak's trade report and order feed.</p>
      </div>
      <div className="card">
        {loading && <EmptyState title="Loading…" />}
        {!loading && error && <EmptyState title="Trades unavailable" hint={error} icon="clock" />}
        {!loading && !error && trades.length === 0 && <EmptyState title="No trades yet" icon="clock" />}
        {trades.length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Price</th><th>Product</th></tr></thead>
              <tbody>
                {trades.map((t) => (
                  <tr key={t.id}>
                    <td>{t.fill_time || "--"}</td><td>{t.trading_symbol}</td><td>{t.transaction_type}</td>
                    <td>{t.fill_quantity}</td><td>{fmt(t.fill_price)}</td><td>{t.product}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
