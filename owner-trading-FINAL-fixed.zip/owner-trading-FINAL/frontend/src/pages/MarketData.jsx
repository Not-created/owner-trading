import { useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import MiniLineChart from "../components/common/MiniLineChart";
import usePolling from "../hooks/usePolling";
import { EXCHANGE_SEGMENTS, fmt } from "../lib/format";

const DERIVATIVE_SEGMENTS = [
  { value: "nse_fo", label: "NSE F&O" }, { value: "bse_fo", label: "BSE F&O" }, { value: "mcx_fo", label: "MCX" },
];
const HISTORICAL_INTERVALS = ["1min", "3min", "5min", "10min", "15min", "30min", "60min", "D", "W"];

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}
function daysAgoIso(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

export default function MarketData() {
  const ticks = usePolling(() => api.getMarketTicks(), 3000);
  const subs = usePolling(() => api.getSubscriptions(), 8000);

  // ---- instrument search (existing search_scrip flow, unchanged) ----
  const [seg, setSeg] = useState("nse_cm");
  const [symbol, setSymbol] = useState("");
  const [results, setResults] = useState(null);
  const [searchError, setSearchError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [quote, setQuote] = useState(null);
  const [message, setMessage] = useState(null);

  async function search(e) {
    e.preventDefault();
    setBusy(true); setSearchError(null); setResults(null);
    const { ok, body, status } = await api.searchScrip({ exchange_segment: seg, symbol });
    setBusy(false);
    if (!ok) return setSearchError((body && body.error) || `Search failed (HTTP ${status}).`);
    const data = body.data;
    setResults(Array.isArray(data) ? data.slice(0, 50) : []);
  }

  async function getQuote(row) {
    setQuote(null); setMessage(null);
    const { ok, body, status } = await api.getQuotes([{ exchange_segment: seg, instrument_token: String(row.pSymbol) }], "ltp");
    if (ok) setQuote({ symbol: row.pTrdSymbol, data: body.data });
    else setMessage((body && body.error) || `Quote failed (HTTP ${status}).`);
  }

  async function subscribe(row) {
    setMessage(null);
    const { ok, body } = await api.subscribeInstrument(seg, String(row.pSymbol));
    setMessage(ok ? `Subscribed ${row.pTrdSymbol} to the live feed.` : (body && body.error) || "Subscribe failed.");
    subs.reload();
  }

  async function unsubscribe(s) {
    const { ok, body } = await api.unsubscribeInstrument(s.exchange_segment, s.instrument_token);
    if (!ok) setMessage((body && body.error) || "Unsubscribe failed.");
    subs.reload();
  }

  function sendToChart(row) {
    setHistNeosymbol(`${seg}|${row.pSymbol}`);
    setHistError(null); setHistData(null);
  }

  // ---- scrip master (official scrip_master(); search_scrip() above is unchanged) ----
  const [smSeg, setSmSeg] = useState("");
  const [smBusy, setSmBusy] = useState(false);
  const [smError, setSmError] = useState(null);
  const [smResult, setSmResult] = useState(null); // { url } | { baseFolder, filesPaths }

  async function loadScripMaster(e) {
    e.preventDefault();
    setSmBusy(true); setSmError(null); setSmResult(null);
    const { ok, body, status } = await api.getScripMaster(smSeg || undefined);
    setSmBusy(false);
    if (!ok) return setSmError((body && body.error) || `Request failed (HTTP ${status}).`);
    const data = body.data;
    if (typeof data === "string") setSmResult({ url: data });
    else if (data && Array.isArray(data.filesPaths)) setSmResult({ baseFolder: data.baseFolder, filesPaths: data.filesPaths });
    else setSmResult({ raw: data });
  }

  // ---- expiries + option chain (official expiries() / option_chain()) ----
  const [ocExchange, setOcExchange] = useState("nse_fo");
  const [ocUnderlying, setOcUnderlying] = useState("");
  const [ocInstrumentType, setOcInstrumentType] = useState("option");
  const [expiriesBusy, setExpiriesBusy] = useState(false);
  const [expiriesError, setExpiriesError] = useState(null);
  const [expiryList, setExpiryList] = useState(null);
  const [selectedExpiry, setSelectedExpiry] = useState("");
  const [chainBusy, setChainBusy] = useState(false);
  const [chainError, setChainError] = useState(null);
  const [chain, setChain] = useState(null); // { common_data, call, put, fut }

  async function loadExpiries(e) {
    e.preventDefault();
    setExpiriesBusy(true); setExpiriesError(null); setExpiryList(null); setSelectedExpiry(""); setChain(null); setChainError(null);
    const { ok, body, status } = await api.getExpiries(ocExchange, ocUnderlying.trim(), ocInstrumentType);
    setExpiriesBusy(false);
    if (!ok) return setExpiriesError((body && body.error) || `Request failed (HTTP ${status}).`);
    const list = (body.data && body.data.expiries) || [];
    setExpiryList(list);
    if (ocInstrumentType === "fut") loadOptionChain(undefined);
  }

  async function loadOptionChain(expiry) {
    setChainBusy(true); setChainError(null); setChain(null);
    const { ok, body, status } = await api.getOptionChain({
      exchange: ocExchange, underlying: ocUnderlying.trim(), expiry, instrument_type: ocInstrumentType, count: 20,
    });
    setChainBusy(false);
    if (!ok) return setChainError((body && body.error) || `Request failed (HTTP ${status}).`);
    setChain(body.data && body.data.data);
  }

  function pickExpiry(exp) {
    setSelectedExpiry(exp);
    loadOptionChain(exp);
  }

  // ---- historical data (official historical_data()) ----
  const [histNeosymbol, setHistNeosymbol] = useState("");
  const [histInterval, setHistInterval] = useState("D");
  const [histFrom, setHistFrom] = useState(daysAgoIso(30));
  const [histTo, setHistTo] = useState(todayIso());
  const [histBusy, setHistBusy] = useState(false);
  const [histError, setHistError] = useState(null);
  const [histData, setHistData] = useState(null); // array of candle rows

  async function loadHistorical(e) {
    e.preventDefault();
    setHistBusy(true); setHistError(null); setHistData(null);
    const { ok, body, status } = await api.getHistoricalData({
      neosymbol: histNeosymbol.trim(), interval: histInterval, from_date: histFrom, to_date: histTo,
    });
    setHistBusy(false);
    if (!ok) return setHistError((body && body.error) || `Request failed (HTTP ${status}).`);
    const candles = (body.data && body.data.data && body.data.data.candles) || [];
    setHistData(candles);
  }

  const chartPoints = (histData || []).map((row) => ({ x: row[0], y: Number(row[4]) })); // close price per candle

  const tickRows = (ticks.body && ticks.body.ticks) || [];
  const subRows = (subs.body && subs.body.subscriptions) || [];

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Market Data</h2>
        <p className="page__subtitle">Instrument search, scrip master, expiries &amp; option chain, historical data, REST quotes, and live SFeed subscriptions — all from the official Kotak Neo SDK.</p>
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Find an instrument</h3></div>
        <form onSubmit={search} className="order-form">
          <select value={seg} onChange={(e) => setSeg(e.target.value)}>
            {EXCHANGE_SEGMENTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <input placeholder="Symbol (e.g. yesbank)" value={symbol} onChange={(e) => setSymbol(e.target.value)} required />
          <button type="submit" disabled={busy}>{busy ? "Searching…" : "Search"}</button>
        </form>
        {message && <div className="form-hint">{message}</div>}
        {searchError && <EmptyState title="Search unavailable" hint={searchError} icon="globe" />}
        {results && results.length === 0 && <EmptyState title="No matches" icon="globe" />}
        {results && results.length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Trading symbol</th><th>Name</th><th>Token</th><th>Lot</th><th></th></tr></thead>
              <tbody>
                {results.map((r) => (
                  <tr key={r.pSymbol}>
                    <td>{r.pTrdSymbol}</td><td>{r.pSymbolName}</td><td>{r.pSymbol}</td><td>{r.lLotSize ?? "--"}</td>
                    <td>
                      <button type="button" onClick={() => getQuote(r)}>Quote</button>{" "}
                      <button type="button" onClick={() => subscribe(r)}>Subscribe</button>{" "}
                      <button type="button" onClick={() => sendToChart(r)}>Chart</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {quote && <pre className="raw-json">{quote.symbol}: {JSON.stringify(quote.data, null, 2)}</pre>}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Scrip master</h3></div>
        <p className="page__subtitle">Official <code>scrip_master()</code> file index — the raw daily CSV files Kotak publishes. Leave the exchange blank for the full index of every segment.</p>
        <form onSubmit={loadScripMaster} className="order-form">
          <select value={smSeg} onChange={(e) => setSmSeg(e.target.value)}>
            <option value="">All segments (file index)</option>
            {EXCHANGE_SEGMENTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <button type="submit" disabled={smBusy}>{smBusy ? "Loading…" : "Load"}</button>
        </form>
        {smError && <EmptyState title="Scrip master unavailable" hint={smError} icon="globe" />}
        {smResult && smResult.url && (
          <p className="form-hint"><a href={smResult.url} target="_blank" rel="noreferrer">{smResult.url}</a></p>
        )}
        {smResult && smResult.filesPaths && (
          <ul className="scrip-master-list">
            {smResult.filesPaths.map((u) => (
              <li key={u}><a href={u} target="_blank" rel="noreferrer">{u.split("/").pop()}</a></li>
            ))}
          </ul>
        )}
        {smResult && smResult.raw && <pre className="raw-json">{JSON.stringify(smResult.raw, null, 2)}</pre>}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Expiries &amp; option chain</h3></div>
        <form onSubmit={loadExpiries} className="order-form">
          <select value={ocExchange} onChange={(e) => setOcExchange(e.target.value)}>
            {DERIVATIVE_SEGMENTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <input placeholder="Underlying (e.g. NIFTY, RELIANCE)" value={ocUnderlying} onChange={(e) => setOcUnderlying(e.target.value)} required />
          <select value={ocInstrumentType} onChange={(e) => setOcInstrumentType(e.target.value)}>
            <option value="option">Option</option><option value="fut">Futures</option>
          </select>
          <button type="submit" disabled={expiriesBusy}>{expiriesBusy ? "Loading…" : ocInstrumentType === "fut" ? "Load futures chain" : "Load expiries"}</button>
        </form>
        {expiriesError && <EmptyState title="Expiries unavailable" hint={expiriesError} icon="globe" />}
        {expiryList && expiryList.length === 0 && <EmptyState title="No expiries found" icon="globe" />}
        {expiryList && expiryList.length > 0 && (
          <div className="expiry-picker">
            {expiryList.map((exp) => (
              <button type="button" key={exp} className={exp === selectedExpiry ? "expiry-picker__btn expiry-picker__btn--active" : "expiry-picker__btn"} onClick={() => pickExpiry(exp)}>
                {exp}
              </button>
            ))}
          </div>
        )}
        {chainBusy && <EmptyState title="Loading chain…" />}
        {chainError && <EmptyState title="Option chain unavailable" hint={chainError} icon="globe" />}
        {chain && chain.common_data && (
          <p className="form-hint">
            Lot size {chain.common_data.mktLot ?? "--"} · multiplier {chain.common_data.multiplier ?? "--"}
            {chain.common_data.expiryDt ? ` · expiry ${chain.common_data.expiryDt}` : ""}
          </p>
        )}
        {chain && (chain.call || []).length + (chain.put || []).length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Strike</th><th>Type</th><th>Symbol</th><th>LTP</th><th>Volume</th><th>OI</th><th>OI Δ%</th></tr></thead>
              <tbody>
                {[...(chain.call || []), ...(chain.put || [])].map((row) => (
                  <tr key={row.instrument.neoSymbol}>
                    <td>{row.instrument.strikePrice}</td><td>{row.instrument.optionType}{row.instrument.moneyness ? ` (${row.instrument.moneyness})` : ""}</td>
                    <td>{row.instrument.symbol}</td><td>{fmt(row.quote.ltp)}</td><td>{row.quote.volume ?? "--"}</td>
                    <td>{row.openInterest ? row.openInterest.current : "--"}</td>
                    <td>{row.openInterest ? fmt(row.openInterest.changePct) : "--"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {chain && (chain.fut || []).length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Symbol</th><th>Expiry</th><th>LTP</th><th>Volume</th><th>OI</th></tr></thead>
              <tbody>
                {chain.fut.map((row) => (
                  <tr key={row.inst.neoSymbol}>
                    <td>{row.inst.symbol}</td><td>{row.inst.expiryDt}</td><td>{fmt(row.quote.ltp)}</td>
                    <td>{row.quote.vol ?? "--"}</td><td>{row.oi ? row.oi.cur : "--"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Historical data</h3></div>
        <p className="page__subtitle">Official <code>historical_data()</code>. Use "Chart" on a search result above to fill in the instrument, or enter it directly as <code>exchange_segment|instrument_token</code>.</p>
        <form onSubmit={loadHistorical} className="order-form">
          <input placeholder="e.g. nse_cm|1333" value={histNeosymbol} onChange={(e) => setHistNeosymbol(e.target.value)} required />
          <select value={histInterval} onChange={(e) => setHistInterval(e.target.value)}>
            {HISTORICAL_INTERVALS.map((i) => <option key={i} value={i}>{i}</option>)}
          </select>
          <input type="date" value={histFrom} onChange={(e) => setHistFrom(e.target.value)} required />
          <input type="date" value={histTo} onChange={(e) => setHistTo(e.target.value)} required />
          <button type="submit" disabled={histBusy}>{histBusy ? "Loading…" : "Load chart"}</button>
        </form>
        {histError && <EmptyState title="Historical data unavailable" hint={histError} icon="globe" />}
        {histData && histData.length === 0 && <EmptyState title="No candles for this range" icon="globe" />}
        {chartPoints.length > 1 && (
          <>
            <MiniLineChart points={chartPoints} />
            <p className="form-hint">{chartPoints.length} candles · close {fmt(chartPoints[0].y)} → {fmt(chartPoints[chartPoints.length - 1].y)}</p>
          </>
        )}
        {histData && histData.length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Time</th><th>Open</th><th>High</th><th>Low</th><th>Close</th><th>Volume</th></tr></thead>
              <tbody>
                {histData.slice(-50).reverse().map((row) => (
                  <tr key={row[0]}><td>{row[0]}</td><td>{fmt(row[1])}</td><td>{fmt(row[2])}</td><td>{fmt(row[3])}</td><td>{fmt(row[4])}</td><td>{row[5]}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Live ticks</h3></div>
        {tickRows.length === 0 ? (
          <EmptyState title="No live ticks" hint="Connect the broker and subscribe an instrument. Ticks only flow while the market is open." icon="globe" />
        ) : (
          <table className="data-table">
            <thead><tr><th>Symbol</th><th>Token</th><th>Exchange</th><th>LTP</th><th>Close</th><th>Volume</th><th>Updated (UTC)</th></tr></thead>
            <tbody>
              {tickRows.map((t) => (
                <tr key={t.exchange_segment + t.instrument_token}>
                  <td>{t.trading_symbol || "--"}</td><td>{t.instrument_token}</td><td>{t.exchange_segment || "--"}</td>
                  <td>{fmt(t.last_traded_price)}</td><td>{fmt(t.close_price)}</td><td>{t.volume ?? "--"}</td><td>{t.last_tick_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Subscriptions</h3></div>
        {subRows.length === 0 ? <EmptyState title="Nothing subscribed" icon="globe" /> : (
          <table className="data-table">
            <thead><tr><th>Exchange</th><th>Token</th><th></th></tr></thead>
            <tbody>{subRows.map((s) => (
              <tr key={s.exchange_segment + s.instrument_token}><td>{s.exchange_segment}</td><td>{s.instrument_token}</td>
                <td><button type="button" onClick={() => unsubscribe(s)}>Unsubscribe</button></td></tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </div>
  );
}
