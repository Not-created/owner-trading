import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function Holdings() {
  const [state, setState] = useState({ loading: true, error: null, holdings: null });

  useEffect(() => {
    let cancelled = false;
    api.getHoldings().then(({ ok, status, body }) => {
      if (cancelled) return;
      if (ok) {
        setState({ loading: false, error: null, holdings: body.holdings || [] });
      } else {
        setState({ loading: false, error: (body && body.error) || `Request failed (HTTP ${status}).`, holdings: null });
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Holdings</h2>
        <p className="page__subtitle">Long-term holdings from your connected Kotak account.</p>
      </div>
      <div className="card">
        {state.loading && <EmptyState title="Loading…" />}
        {!state.loading && state.error && <EmptyState title="Holdings unavailable" hint={state.error} icon="briefcase" />}
        {!state.loading && !state.error && state.holdings.length === 0 && (
          <EmptyState title="No holdings" hint="Your delivery holdings will appear here." icon="briefcase" />
        )}
        {!state.loading && !state.error && state.holdings.length > 0 && (
          <table className="data-table">
            <thead>
              <tr>
                <th>Symbol</th>
                <th>Exchange</th>
                <th>Quantity</th>
                <th>Avg. Price</th>
              </tr>
            </thead>
            <tbody>
              {state.holdings.map((h, i) => (
                <tr key={i}>
                  <td>{h.trading_symbol || "--"}</td>
                  <td>{h.exchange_segment || "--"}</td>
                  <td>{h.quantity ?? "--"}</td>
                  <td>{h.average_price ?? "--"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
