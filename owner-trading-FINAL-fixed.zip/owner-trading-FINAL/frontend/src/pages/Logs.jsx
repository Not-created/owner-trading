import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function Logs() {
  const [state, setState] = useState({ loading: true, error: null, logs: null });

  useEffect(() => {
    let cancelled = false;
    api.getAuditLogs().then(({ ok, status, body }) => {
      if (cancelled) return;
      if (ok) {
        setState({ loading: false, error: null, logs: body.logs || [] });
      } else {
        setState({ loading: false, error: (body && body.error) || `Request failed (HTTP ${status}).`, logs: null });
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Logs</h2>
        <p className="page__subtitle">Audit trail of orders, connections, and risk actions.</p>
      </div>
      <div className="card">
        {state.loading && <EmptyState title="Loading…" />}
        {!state.loading && state.error && <EmptyState title="Logs unavailable" hint={state.error} icon="list" />}
        {!state.loading && !state.error && state.logs.length === 0 && (
          <EmptyState title="No log entries yet" icon="list" />
        )}
        {!state.loading && !state.error && state.logs.length > 0 && (
          <table className="data-table">
            <thead>
              <tr><th>Time</th><th>Actor</th><th>Action</th><th>Details</th></tr>
            </thead>
            <tbody>
              {state.logs.map((l) => (
                <tr key={l.id}>
                  <td>{l.created_at}</td>
                  <td>{l.actor}</td>
                  <td>{l.action}</td>
                  <td><code>{l.details ? JSON.stringify(l.details) : "--"}</code></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
