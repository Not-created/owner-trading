import { useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function MarketOverview(){
 const ticks=usePolling(()=>api.getMarketTicks(),3000); const rows=ticks.body?.ticks||[];
 return <div className="page"><div className="page__header"><h2 className="page__title">Market Overview</h2><p className="page__subtitle">Real-time Kotak Neo SFeed market state.</p></div><div className="card"><div className="card__head"><h3 className="card__title">Live market</h3></div>{!rows.length?<EmptyState title="No live ticks" hint="Connect Kotak Neo and subscribe instruments from Market Data."/>:<table className="data-table"><thead><tr><th>Symbol</th><th>LTP</th><th>Close</th><th>Volume</th><th>Time</th></tr></thead><tbody>{rows.map(r=><tr key={r.exchange_segment+r.instrument_token}><td>{r.trading_symbol||r.instrument_token}</td><td>{r.last_traded_price}</td><td>{r.close_price??"—"}</td><td>{r.volume??"—"}</td><td>{r.last_tick_at}</td></tr>)}</tbody></table>}</div></div>;
}
