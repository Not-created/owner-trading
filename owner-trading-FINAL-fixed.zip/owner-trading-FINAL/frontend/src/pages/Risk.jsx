import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import usePolling from "../hooks/usePolling";

const LIMITS = [
  ["max_order_quantity", "Max quantity per order"],
  ["max_order_value", "Max value per order (₹)"],
  ["max_orders_per_day", "Max orders per day"],
  ["max_daily_loss", "Max daily loss (₹) — blocks new LIVE orders"],
  ["max_open_positions", "Max open positions"],
];

export default function Risk() {
  const status = usePolling(() => api.getRiskStatus(), 5000);
  const settings = usePolling(() => api.getRiskSettings(), 0);
  const readiness = usePolling(() => api.getLiveReadiness(), 8000);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState({});
  const [msg, setMsg] = useState(null);
  const [confirmText, setConfirmText] = useState("");

  useEffect(() => {
    if (settings.body && settings.body.risk) {
      const d = {};
      for (const [k] of LIMITS) d[k] = settings.body.risk[k] ?? "";
      setDraft(d);
    }
  }, [settings.body]);

  const stop = status.body && status.body.emergencyStop;
  const rd = readiness.body;
  const risk = settings.body && settings.body.risk;

  async function saveLimits(e) {
    e.preventDefault();
    setMsg(null);
    const payload = {};
    for (const [k] of LIMITS) payload[k] = draft[k] === "" ? null : Number(draft[k]);
    const { ok, body } = await api.saveRiskSettings(payload);
    setMsg(ok ? "Limits saved." : (body && body.error) || "Save failed.");
    settings.reload(); readiness.reload();
  }
  async function act(fn) { setBusy(true); setMsg(null); const r = await fn(); setBusy(false); return r; }
  async function arm() {
    const { ok, body } = await act(() => api.armLive(confirmText));
    setMsg(ok ? "LIVE trading armed." : (body && body.error) || "Could not arm.");
    setConfirmText(""); settings.reload(); readiness.reload();
  }
  async function disarm() { await act(() => api.disarmLive()); settings.reload(); readiness.reload(); }

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Risk &amp; LIVE readiness</h2>
        <p className="page__subtitle">Limits, the emergency stop, and the checks that must all pass before LIVE orders can be armed.</p>
      </div>
      {msg && <div className="card"><div className="form-hint">{msg}</div></div>}

      <div className="card">
        <div className="card__head"><h3 className="card__title">Emergency stop</h3></div>
        {status.loading && <EmptyState title="Loading…" />}
        {status.error && <EmptyState title="Risk status unavailable" hint={status.error} icon="alert-triangle" />}
        {status.body && (
          <div className="risk-status">
            <div><strong>Execution:</strong> LIVE</div>
            <div><strong>Broker:</strong> {status.body.brokerConnection.state}</div>
            <div><strong>Emergency stop:</strong> {stop.is_active ? `ACTIVE — all LIVE orders blocked${stop.reason ? ` (${stop.reason})` : ""}` : "Not active"}</div>
            {stop.is_active ? (
              <button type="button" disabled={busy} onClick={async () => { await act(() => api.clearEmergencyStop()); status.reload(); readiness.reload(); }}>Clear emergency stop</button>
            ) : (
              <div className="order-form">
                <input placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} />
                <button type="button" disabled={busy} onClick={async () => { await act(() => api.activateEmergencyStop(reason || undefined)); setReason(""); status.reload(); readiness.reload(); }}>Activate emergency stop</button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Order &amp; loss limits</h3></div>
        <form onSubmit={saveLimits} className="order-form">
          {LIMITS.map(([k, label]) => (
            <label key={k} className="form-field">
              <span>{label}</span>
              <input type="number" min="0" step="any" placeholder="not set" value={draft[k] ?? ""} onChange={(e) => setDraft((d) => ({ ...d, [k]: e.target.value }))} />
            </label>
          ))}
          <p className="form-hint">Empty = no limit. Limits that cannot be evaluated (e.g. order value with no price) block the order rather than pass it.</p>
          <button type="submit">Save limits</button>
        </form>
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">LIVE readiness</h3></div>
        {readiness.error && <EmptyState title="Readiness unavailable" hint={readiness.error} icon="alert-triangle" />}
        {rd && (
          <>
            <table className="data-table">
              <thead><tr><th>Check</th><th>Result</th><th>Detail</th></tr></thead>
              <tbody>
                {rd.gates.map((g) => (
                  <tr key={g.id}><td>{g.id}{g.blocking ? "" : " (advisory)"}</td><td>{g.ok ? "PASS" : "FAIL"}</td><td>{g.detail}</td></tr>
                ))}
              </tbody>
            </table>
            <p><strong>Ready:</strong> {rd.ready ? "yes" : "no"} · <strong>Armed:</strong> {rd.armed ? "yes" : "no"} · <strong>LIVE orders can be sent:</strong> {rd.live_orders_can_be_sent ? "YES" : "no"}</p>
            {rd.armed ? (
              <button type="button" disabled={busy} onClick={disarm}>Disarm LIVE trading</button>
            ) : (
              <div className="order-form">
                <input placeholder='Type ARM LIVE TRADING to confirm' value={confirmText} onChange={(e) => setConfirmText(e.target.value)} />
                <button type="button" disabled={busy || !rd.ready || confirmText !== "ARM LIVE TRADING"} onClick={arm}>Arm LIVE trading</button>
              </div>
            )}
            <button type="button" disabled={busy} onClick={async () => { await act(() => api.reconcileNow()); readiness.reload(); }}>Reconcile with broker now</button>
          </>
        )}
        {risk && risk.armed_at && <p className="form-hint">Armed at {risk.armed_at} (UTC).</p>}
      </div>
    </div>
  );
}
