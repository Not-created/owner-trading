import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import MetricCard from "../components/common/MetricCard";

export default function Funds() {
  const [state, setState] = useState({ loading: true, error: null, funds: null });

  useEffect(() => {
    let cancelled = false;
    api.getFunds().then(({ ok, status, body }) => {
      if (cancelled) return;
      if (ok) {
        setState({ loading: false, error: null, funds: body.funds || null });
      } else {
        setState({ loading: false, error: (body && body.error) || `Request failed (HTTP ${status}).`, funds: null });
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Funds</h2>
        <p className="page__subtitle">Margin/funds from your connected Kotak account.</p>
      </div>
      {state.loading && <div className="card"><EmptyState title="Loading…" /></div>}
      {!state.loading && state.error && <div className="card"><EmptyState title="Funds unavailable" hint={state.error} icon="dollar-sign" /></div>}
      {!state.loading && !state.error && (
        <div className="metrics-grid">
          <MetricCard
            label="Available Margin"
            icon="dollar-sign"
            value={state.funds?.available_margin != null ? state.funds.available_margin : undefined}
            hint={state.funds?.available_margin != null ? undefined : "No data available"}
          />
          <MetricCard
            label="Used Margin"
            icon="dollar-sign"
            value={state.funds?.used_margin != null ? state.funds.used_margin : undefined}
            hint={state.funds?.used_margin != null ? undefined : "No data available"}
          />
        </div>
      )}
    </div>
  );
}
