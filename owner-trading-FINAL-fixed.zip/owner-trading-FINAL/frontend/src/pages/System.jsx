import { useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function System(){const r=usePolling(()=>api.getReadiness(),3000);const b=usePolling(()=>api.getBrokerStatus(),3000);return <div className="page"><div className="page__header"><h2 className="page__title">System</h2><p className="page__subtitle">Application and broker readiness.</p></div><div className="card"><h3 className="card__title">Application</h3><p>{r.body?.application||"—"}</p><h3 className="card__title">Kotak Neo</h3><p>{b.body?.state||"—"}</p><pre style={{whiteSpace:"pre-wrap"}}>{JSON.stringify(b.body?.websocket||{},null,2)}</pre></div></div>;}
