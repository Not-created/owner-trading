import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import MetricCard from "../components/common/MetricCard";
import EmptyState from "../components/common/EmptyState";
import SystemStatusCard from "../components/common/SystemStatusCard";
import usePolling from "../hooks/usePolling";
import { fmt } from "../lib/format";

export default function Dashboard() {
  const navigate = useNavigate();
  const summary = usePolling(() => api.getSummary(), 6000);
  const orders = usePolling(() => api.getOrders(5), 6000);
  const trades = usePolling(() => api.getTrades(), 10000);
  const ticks = usePolling(() => api.getMarketTicks(), 4000);

  const s = summary.body;
  const live = s && s.pnl && s.pnl.live;
  const ledger = live;
  const recentOrders = (orders.body && orders.body.orders) || [];
  const recentTrades = ((trades.body && trades.body.trades) || []).slice(-5).reverse();
  const tickRows = ((ticks.body && ticks.body.ticks) || []).slice(0, 6);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Dashboard</h2>
        <p className="page__subtitle">LIVE algorithmic trading</p>
      </div>
      {summary.error && <div className="card"><EmptyState title="Summary unavailable" hint={summary.error} icon="alert-triangle" /></div>}
      {s && s.errors && s.errors.length > 0 && <div className="card"><div className="form-error">{s.errors.join(" · ")}</div></div>}

      <div className="metrics-grid">
        <MetricCard label="Available funds" icon="briefcase" value={s && s.funds ? fmt(s.funds.available_margin) : undefined} hint="Connect the broker to load funds" />
        <MetricCard label={"P&L (LIVE)"} icon="activity" value={ledger ? `${fmt(ledger.total)}${ledger.complete ? "" : "*"}` : undefined} hint="No P&L data" />
        <MetricCard label="Open orders" icon="file-text" value={s && s.orders ? s.orders.open : undefined} />
        <MetricCard label="Orders needing attention" icon="alert-triangle" value={s && s.orders ? s.orders.needingAttention : undefined} />
      </div>

      <div className="dashboard-row dashboard-row--portfolio">
        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Recent orders</h3>
            <button type="button" className="card__link" onClick={() => navigate("/dashboard/orders")}>View all</button>
          </div>
          {recentOrders.length === 0 ? <EmptyState icon="file-text" title="No orders yet" /> : (
            <table className="data-table">
              <thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Status</th></tr></thead>
              <tbody>{recentOrders.map((o) => (
                <tr key={o.internal_order_id}><td>{o.created_at}</td><td>{o.trading_symbol}</td><td>{o.transaction_type}</td><td>{o.quantity}</td><td>{o.status}</td></tr>
              ))}</tbody>
            </table>
          )}
        </div>
        <div className="card">
          <div className="card__head"><h3 className="card__title">Recent trades</h3></div>
          {recentTrades.length === 0 ? <EmptyState icon="activity" title="No trades yet" /> : (
            <table className="data-table">
              <thead><tr><th>Symbol</th><th>Side</th><th>Qty</th><th>Price</th></tr></thead>
              <tbody>{recentTrades.map((t) => (
                <tr key={t.id}><td>{t.trading_symbol}</td><td>{t.transaction_type}</td><td>{t.fill_quantity}</td><td>{fmt(t.fill_price)}</td></tr>
              ))}</tbody>
            </table>
          )}
        </div>
      </div>

      <div className="dashboard-row dashboard-row--split">
        <div className="card">
          <div className="card__head"><h3 className="card__title">Live prices</h3></div>
          {tickRows.length === 0 ? <EmptyState icon="globe" title="No live ticks" hint="Subscribe instruments on Market Data" /> : (
            <table className="data-table">
              <thead><tr><th>Symbol</th><th>LTP</th><th>Close</th></tr></thead>
              <tbody>{tickRows.map((t) => (
                <tr key={t.exchange_segment + t.instrument_token}><td>{t.trading_symbol || t.instrument_token}</td><td>{fmt(t.last_traded_price)}</td><td>{fmt(t.close_price)}</td></tr>
              ))}</tbody>
            </table>
          )}
        </div>
        <SystemStatusCard />
      </div>
      {ledger && !ledger.complete && <p className="form-hint">* some open positions have no live price; unrealised P&amp;L excludes them.</p>}
    </div>
  );
}
