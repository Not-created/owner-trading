import {useState} from "react";
import usePolling from "../hooks/usePolling";
import {api} from "../api/client";
import EmptyState from "../components/common/EmptyState";

const FIELDS=["close","open","high","low","volume","sma20","ema20","ema50","rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_upper","bb_lower","volume_sma20","bullish_candle","bearish_candle"];
const OPS=[">",">=","<","<=","==","!=","cross_above","cross_below"];
const blank=(l="ema20",r="ema50")=>({left:l,operator:">",right:r});

function Group({title,rows,setRows}) {
  const change=(i,k,v)=>setRows(x=>x.map((r,n)=>n===i?{...r,[k]:v}:r));
  return <div><h4>{title}</h4>
    {rows.map((r,i)=><div className="order-form" key={i}>
      <select value={r.left} onChange={e=>change(i,"left",e.target.value)}>{FIELDS.map(x=><option key={x}>{x}</option>)}</select>
      <select value={r.operator} onChange={e=>change(i,"operator",e.target.value)}>{OPS.map(x=><option key={x}>{x}</option>)}</select>
      <input value={r.right} onChange={e=>change(i,"right",e.target.value)} placeholder="indicator / number"/>
      <button type="button" onClick={()=>setRows(x=>x.filter((_,n)=>n!==i))}>Remove</button>
    </div>)}
    <button type="button" onClick={()=>setRows(x=>[...x,blank()])}>+ Condition</button>
  </div>;
}

export default function Strategies(){
 const data=usePolling(()=>api.getAlgoStrategies(),5000);
 const [name,setName]=useState(""); const [side,setSide]=useState("BUY"); const [tf,setTf]=useState("5m");
 const [group,setGroup]=useState("AND"); const [entry,setEntry]=useState([blank()]);
 const [exit,setExit]=useState([{left:"rsi14",operator:"<",right:45}]);
 const [stop,setStop]=useState(""); const [target,setTarget]=useState(""); const [trail,setTrail]=useState(""); const [timeExit,setTimeExit]=useState("");
 const [qty,setQty]=useState(1); const [capitalPct,setCapitalPct]=useState(""); const [riskPerTrade,setRiskPerTrade]=useState("");
 const [maxPos,setMaxPos]=useState(1); const [cooldown,setCooldown]=useState(0); const [product,setProduct]=useState("MIS");
 const [universe,setUniverse]=useState(""); const [msg,setMsg]=useState("");

 const definition=()=>({
   timeframe:tf,side,
   entry:{op:group,conditions:entry},
   exit:{op:"OR",conditions:exit},
   max_positions:Number(maxPos)||1,
   universe:{instrument_tokens:universe.split(",").map(x=>x.trim()).filter(Boolean)},
   risk:{stop_loss:stop?Number(stop):null,target:target?Number(target):null,trailing_stop_pct:trail?Number(trail):null,time_exit_bars:timeExit?Number(timeExit):null},
   position_sizing:{quantity:(!capitalPct&&!riskPerTrade&&qty)?Number(qty):undefined,capital_pct:capitalPct?Number(capitalPct):undefined,risk_per_trade:riskPerTrade?Number(riskPerTrade):undefined},
   execution:{product,cooldown_bars:Number(cooldown)||0}
 });
 async function create(){
   if(!name.trim())return setMsg("Strategy name is required.");
   const d=definition();
   if(!d.universe.instrument_tokens.length)delete d.universe;
   if(!d.position_sizing.quantity)delete d.position_sizing.quantity;
   const vld=await api.validateAlgoStrategy(d);
   if(!vld.ok||!vld.body?.valid)return setMsg(vld.body?.errors?.join("; ")||"Definition is invalid.");
   const r=await api.createAlgoStrategy({name:name.trim()});
   if(!r.ok)return setMsg(r.body?.error||"Create failed");
   const v=await api.saveAlgoStrategyVersion(r.body.strategy.id,{definition:d,status:"VALIDATED"});
   setMsg(v.ok?"Validated and saved. LIVE arming remains a separate owner action.":v.body?.error||"Save failed.");
   if(v.ok){setName("");data.reload();}
 }
 async function arm(v){const r=await api.armAlgoStrategy(v.id);setMsg(r.ok?"LIVE strategy armed after readiness gates.":r.body?.error||"Arm failed");data.reload();}
 async function disarm(v){const r=await api.disarmAlgoStrategy(v.id);setMsg(r.ok?"Strategy disarmed.":r.body?.error||"Disarm failed");data.reload();}

 return <div className="page">
  <div className="page__header"><h2 className="page__title">Strategies</h2><p className="page__subtitle">Validated LIVE-only DSL with BUY/SELL, sizing, universe binding, cooldown and protective exits.</p></div>
  <div className="card"><div className="card__head"><h3 className="card__title">Strategy Builder</h3></div>
   <div className="order-form">
    <input placeholder="Strategy name" value={name} onChange={e=>setName(e.target.value)}/>
    <select value={side} onChange={e=>setSide(e.target.value)}><option>BUY</option><option>SELL</option></select>
    <select value={tf} onChange={e=>setTf(e.target.value)}>{["1m","3m","5m","15m","30m","1h","1d"].map(x=><option key={x}>{x}</option>)}</select>
    <select value={product} onChange={e=>setProduct(e.target.value)}>{["MIS","CNC","NRML","MTF"].map(x=><option key={x}>{x}</option>)}</select>
    <select value={group} onChange={e=>setGroup(e.target.value)}><option>AND</option><option>OR</option></select>
    <input type="number" min="1" value={maxPos} onChange={e=>setMaxPos(e.target.value)} placeholder="max positions"/>
    <input type="number" min="0" value={cooldown} onChange={e=>setCooldown(e.target.value)} placeholder="cooldown bars"/>
    <input type="number" min="1" value={qty} onChange={e=>setQty(e.target.value)} placeholder="fixed quantity"/>
    <input type="number" min="0" max="100" step="any" value={capitalPct} onChange={e=>setCapitalPct(e.target.value)} placeholder="capital %"/>
    <input type="number" min="0" step="any" value={riskPerTrade} onChange={e=>setRiskPerTrade(e.target.value)} placeholder="risk ₹ / trade"/>
    <input type="number" step="any" value={stop} onChange={e=>setStop(e.target.value)} placeholder="stop price"/>
    <input type="number" step="any" value={target} onChange={e=>setTarget(e.target.value)} placeholder="target price"/>
    <input type="number" step="any" value={trail} onChange={e=>setTrail(e.target.value)} placeholder="trailing %"/>
    <input type="number" min="1" value={timeExit} onChange={e=>setTimeExit(e.target.value)} placeholder="time exit bars"/>
    <input value={universe} onChange={e=>setUniverse(e.target.value)} placeholder="optional instrument tokens, comma separated (≤3000)"/>
   </div>
   <Group title="ENTRY" rows={entry} setRows={setEntry}/><Group title="EXIT" rows={exit} setRows={setExit}/>
   <button onClick={create}>Validate &amp; Save Version</button>{msg&&<p className="form-hint">{msg}</p>}
  </div>
  {(data.body?.strategies||[]).map(s=><div className="card" key={s.id}><div className="card__head"><h3 className="card__title">{s.name}</h3></div>
    {s.versions.map(v=><div key={v.id} style={{marginBottom:20}}><strong>v{v.version}</strong> · {v.status} · {v.is_live_armed?"LIVE ARMED":"not armed"}
      {v.validation_errors?.length?<p className="form-error">{v.validation_errors.join("; ")}</p>:null}
      <pre style={{whiteSpace:"pre-wrap",overflowX:"auto"}}>{JSON.stringify(v.definition,null,2)}</pre>
      {v.is_live_armed?<button onClick={()=>disarm(v)}>Disarm</button>:v.status==="VALIDATED"?<button onClick={()=>arm(v)}>Arm LIVE</button>:null}
    </div>)}
  </div>)}
  {!data.loading&&!data.body?.strategies?.length&&<div className="card"><EmptyState title="No strategies yet" description="Build and validate a strategy above."/></div>}
 </div>;
}
