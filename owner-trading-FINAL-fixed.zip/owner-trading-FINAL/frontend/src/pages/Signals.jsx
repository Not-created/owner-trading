import { useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function Signals(){const d=usePolling(()=>api.getAlgoSignals(200),3000);const rows=d.body?.signals||[];return <div className="page"><div className="page__header"><h2 className="page__title">Signals</h2><p className="page__subtitle">Strategy decisions with condition and risk evidence.</p></div><div className="card">{!rows.length?<EmptyState title="No signals yet" hint="Arm a validated strategy and wait for live market data."/>:<table className="data-table"><thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Price</th><th>Status</th><th>Order</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.created_at}</td><td>{r.trading_symbol}</td><td>{r.side}</td><td>{r.signal_price}</td><td>{r.status}</td><td>{r.internal_order_id||"—"}</td></tr>)}</tbody></table>}</div></div>;}
