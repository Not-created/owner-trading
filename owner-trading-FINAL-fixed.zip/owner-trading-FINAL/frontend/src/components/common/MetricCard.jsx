import Icon from "./Icon";

/**
 * BUGFIX (Phase 1C): value used to be hardcoded to "--" always, even once
 * real data existed -- no page could ever show a real number through this
 * component. Now: if `value` is passed, it's shown for real; otherwise
 * this falls back to the original placeholder-dash + hint behavior
 * unchanged, so every page that hasn't been wired to real data yet keeps
 * behaving exactly as before.
 */
export default function MetricCard({ label, icon, value, hint = "No data available" }) {
  const hasValue = value !== undefined && value !== null;
  return (
    <div className="metric-card">
      <div className="metric-card__icon">
        <Icon name={icon} size={18} />
      </div>
      <div className="metric-card__label">{label}</div>
      <div className="metric-card__value">{hasValue ? value : "--"}</div>
      {!hasValue && hint && <div className="metric-card__hint">{hint}</div>}
    </div>
  );
}
