import Icon from "./Icon";

/**
 * Standard "nothing here yet" state used by every foundation-stage page.
 * Deliberately generic -- no invented data, no fake numbers, no fake
 * status. `hint` is optional supporting text (e.g. "Coming soon"). Pass
 * `icon` to render a small icon instead of the plain dash (used by the
 * richer dashboard-card empty states).
 */
export default function EmptyState({ title = "No data available", hint, icon }) {
  return (
    <div className="empty-state">
      {icon ? (
        <div className="empty-state__icon">
          <Icon name={icon} size={20} />
        </div>
      ) : (
        <div className="empty-state__dash">—</div>
      )}
      <div className="empty-state__title">{title}</div>
      {hint && <div className="empty-state__hint">{hint}</div>}
    </div>
  );
}
