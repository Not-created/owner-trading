import { useEffect, useState } from "react";
import { api } from "../../api/client";

// Human-readable label per backend state, and a severity bucket used for
// the dot/pill color. Matches the reference design's green "Not Connected"
// pill: NOT_CONFIGURED/DISCONNECTED are the expected foundation-stage
// resting state, not an error, so they render the same "ok" (green) style
// as CONNECTED. Only a genuine problem (auth failure, expired session,
// connection error) renders red.
const LABELS = {
  CONNECTED: "Kotak Neo: Connected",
  VERIFYING: "Kotak Neo: Verifying…",
  RECONNECTING: "Kotak Neo: Reconnecting…",
  RECONCILING: "Kotak Neo: Reconciling…",
  AUTH_FAILED: "Kotak Neo: Authentication Failed",
  SESSION_EXPIRED: "Kotak Neo: Session Expired",
  CONNECTION_ERROR: "Kotak Neo: Connection Error",
  DISCONNECTED: "Kotak Neo: Not Connected",
  NOT_CONFIGURED: "Kotak Neo: Not Connected",
};

const SEVERITY = {
  CONNECTED: "ok",
  NOT_CONFIGURED: "ok",
  DISCONNECTED: "ok",
  VERIFYING: "warn",
  RECONNECTING: "warn",
  RECONCILING: "warn",
  AUTH_FAILED: "error",
  SESSION_EXPIRED: "error",
  CONNECTION_ERROR: "error",
};

const POLL_INTERVAL_MS = 30000;

export default function BrokerStatusBadge() {
  const [state, setState] = useState(null); // null while first load is in flight

  useEffect(() => {
    let cancelled = false;

    async function poll() {
      const { ok, body } = await api.getBrokerStatus();
      if (cancelled) return;
      setState(ok && body ? body.state : "CONNECTION_ERROR");
    }

    poll();
    const id = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  const label = state ? LABELS[state] || "Kotak Neo: Not Connected" : "Kotak Neo: —";
  const severity = state ? SEVERITY[state] || "error" : "neutral";

  return (
    <span className={`broker-badge broker-badge--${severity}`}>
      <span className="broker-badge__dot" aria-hidden="true" />
      {label}
    </span>
  );
}
