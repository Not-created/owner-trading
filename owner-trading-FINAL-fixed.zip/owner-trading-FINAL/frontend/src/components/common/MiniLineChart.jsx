// Small, dependency-free SVG line chart. No charting library is installed in
// this project, so this is the shared building block for any page that needs
// a quick price chart (currently: Market Data's historical-data viewer).
export default function MiniLineChart({ points, width = 640, height = 220, formatY }) {
  if (!points || points.length < 2) return null;
  const pad = 28;
  const xs = points.map((_, i) => i);
  const ys = points.map((p) => p.y);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);
  const spanY = maxY - minY || 1;
  const x = (i) => pad + (i / (xs.length - 1)) * (width - pad * 2);
  const y = (v) => height - pad - ((v - minY) / spanY) * (height - pad * 2);
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(p.y).toFixed(1)}`).join(" ");
  const first = points[0].y;
  const last = points[points.length - 1].y;
  const color = last >= first ? "#3ecf8e" : "#ff6b6b";
  const fmtY = formatY || ((v) => v.toFixed(2));
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} role="img" aria-label="Price chart">
      <line x1={pad} y1={height - pad} x2={width - pad} y2={height - pad} stroke="#2a3644" strokeWidth="1" />
      <line x1={pad} y1={pad} x2={pad} y2={height - pad} stroke="#2a3644" strokeWidth="1" />
      <text x={pad} y={pad - 8} fill="#9caebf" fontSize="11">{fmtY(maxY)}</text>
      <text x={pad} y={height - pad + 14} fill="#9caebf" fontSize="11">{fmtY(minY)}</text>
      <path d={path} fill="none" stroke={color} strokeWidth="1.75" />
    </svg>
  );
}
