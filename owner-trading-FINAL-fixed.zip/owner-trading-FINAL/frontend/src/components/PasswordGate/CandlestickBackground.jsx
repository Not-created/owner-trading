// Decorative candlestick-chart backdrop for the password screen, matching
// the "trading-chart visual language" direction. Generated procedurally
// with a seeded pattern (not a copy of any reference artwork/photo) so it
// renders identically on every load without shipping an image asset.
const SEED_HEIGHTS = [
  40, 65, 30, 80, 55, 95, 45, 70, 35, 60, 85, 50, 75, 40, 90, 55, 65, 30, 80, 45,
];
const SEED_UP = [1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1];

function Candles({ flip = false }) {
  const barWidth = 18;
  const gap = 10;
  const baseline = 220;

  return (
    <svg
      className={`candlestick-bg__svg ${flip ? "candlestick-bg__svg--flip" : ""}`}
      viewBox="0 0 560 260"
      preserveAspectRatio="xMidYMax slice"
      aria-hidden="true"
    >
      {SEED_HEIGHTS.map((h, i) => {
        const x = i * (barWidth + gap) + 10;
        const up = SEED_UP[i] === 1;
        const bodyTop = baseline - h;
        const wickExtra = 14;
        return (
          <g key={i} opacity={0.5}>
            <line
              x1={x + barWidth / 2}
              y1={bodyTop - wickExtra}
              x2={x + barWidth / 2}
              y2={baseline + wickExtra * 0.4}
              stroke={up ? "#22c55e" : "#ef4444"}
              strokeWidth="2"
            />
            <rect
              x={x}
              y={bodyTop}
              width={barWidth}
              height={h}
              rx="2"
              fill={up ? "#16a34a" : "#dc2626"}
            />
          </g>
        );
      })}
    </svg>
  );
}

export default function CandlestickBackground() {
  return (
    <div className="candlestick-bg" aria-hidden="true">
      <div className="candlestick-bg__panel candlestick-bg__panel--left">
        <Candles />
      </div>
      <div className="candlestick-bg__panel candlestick-bg__panel--right">
        <Candles flip />
      </div>
    </div>
  );
}
