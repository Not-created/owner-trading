export default function Footer() {
  return (
    <footer className="app-footer">
      <span className="app-footer__quote">"Discipline Today, Financial Freedom Tomorrow"</span>
      <span className="app-footer__brand">Owner Trading</span>
    </footer>
  );
}
