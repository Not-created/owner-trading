import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Icon from "../common/Icon";
import BrokerStatusBadge from "../common/BrokerStatusBadge";

export default function Header({ onToggleSidebar, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="app-header">
      <button
        type="button"
        className="app-header__menu-btn"
        onClick={onToggleSidebar}
        aria-label="Toggle navigation menu"
      >
        <Icon name="menu" size={22} />
      </button>

      <div className="app-header__spacer" />

      <BrokerStatusBadge />

      <div className="app-header__user" ref={menuRef}>
        <button
          type="button"
          className="app-header__user-btn"
          onClick={() => setMenuOpen((v) => !v)}
          aria-haspopup="true"
          aria-expanded={menuOpen}
        >
          <span className="app-header__avatar">
            <Icon name="user" size={16} />
          </span>
          <span className="app-header__user-label">User</span>
          <Icon name="chevron-down" size={14} />
        </button>

        {menuOpen && (
          <div className="app-header__menu" role="menu">
            <button
              type="button"
              role="menuitem"
              className="app-header__menu-item"
              onClick={() => {
                setMenuOpen(false);
                navigate("/dashboard/profile");
              }}
            >
              <Icon name="user" size={15} />
              <span>Profile</span>
            </button>
            <button
              type="button"
              role="menuitem"
              className="app-header__menu-item"
              onClick={() => {
                setMenuOpen(false);
                navigate("/dashboard/settings");
              }}
            >
              <Icon name="settings" size={15} />
              <span>Settings</span>
            </button>
            <div className="app-header__menu-divider" />
            <button
              type="button"
              role="menuitem"
              className="app-header__menu-item app-header__menu-item--danger"
              onClick={() => {
                setMenuOpen(false);
                onLogout();
              }}
            >
              <Icon name="logout" size={15} />
              <span>Logout</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
