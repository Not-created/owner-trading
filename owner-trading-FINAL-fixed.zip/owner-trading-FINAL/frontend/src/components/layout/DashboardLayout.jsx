import { useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";
import Footer from "./Footer";
import { useAuth } from "../../context/AuthContext";
import "./layout.css";

export default function DashboardLayout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/", { replace: true });
  }

  return (
    <div className="app-shell">
      <Sidebar
        open={mobileNavOpen}
        onNavigate={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      {mobileNavOpen && (
        <div
          className="app-shell__overlay"
          onClick={() => setMobileNavOpen(false)}
          aria-hidden="true"
        />
      )}

      <div className="app-shell__main">
        <Header onToggleSidebar={() => setMobileNavOpen((v) => !v)} onLogout={handleLogout} />
        <main className="app-shell__content">
          <Outlet />
        </main>
        <Footer />
      </div>
    </div>
  );
}
