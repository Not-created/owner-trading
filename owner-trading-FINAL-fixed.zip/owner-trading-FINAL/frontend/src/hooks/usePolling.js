import { useCallback, useEffect, useRef, useState } from "react";

// Calls `fetcher` (an api.* function returning { ok, status, body }) now and
// every `intervalMs`. Stale responses from an earlier tick never overwrite a newer one.
export default function usePolling(fetcher, intervalMs = 5000, deps = []) {
  const [state, setState] = useState({ loading: true, error: null, body: null });
  const seq = useRef(0);
  const load = useCallback(async () => {
    const mine = ++seq.current;
    const r = await fetcher();
    if (mine !== seq.current) return;
    if (r.ok) setState({ loading: false, error: null, body: r.body });
    else setState((s) => ({ loading: false, error: (r.body && r.body.error) || `Request failed (HTTP ${r.status}).`, body: s.body }));
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    load();
    if (!intervalMs) return undefined;
    const t = setInterval(load, intervalMs);
    return () => { clearInterval(t); seq.current++; };
  }, [load, intervalMs]);
  return { ...state, reload: load };
}
