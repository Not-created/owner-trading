import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/**
 * Client-side gate: redirects to the password screen when not
 * authenticated. This is a UX convenience, NOT the real security boundary
 * -- the actual enforcement is server-side (backend/src/middleware/requireAuth.js
 * rejects any /api/dashboard/* call without a valid session, regardless of
 * what route the browser is on). Directly navigating to a dashboard URL
 * without a valid session cannot retrieve any protected data.
 */
export default function ProtectedRoute({ children }) {
  const { authenticated, checkingSession } = useAuth();

  if (checkingSession) {
    return (
      <div className="full-screen-center">
        <div className="spinner" aria-label="Loading" />
      </div>
    );
  }

  if (!authenticated) {
    return <Navigate to="/" replace />;
  }

  return children;
}
