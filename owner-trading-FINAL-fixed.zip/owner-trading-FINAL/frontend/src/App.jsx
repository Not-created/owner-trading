import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./routes/ProtectedRoute";
import PasswordGate from "./components/PasswordGate/PasswordGate";
import DashboardLayout from "./components/layout/DashboardLayout";

import Dashboard from "./pages/Dashboard";
import Orders from "./pages/Orders";
import Positions from "./pages/Positions";
import Holdings from "./pages/Holdings";
import History from "./pages/History";
import Reports from "./pages/Reports";
import MarketData from "./pages/MarketData";
import Funds from "./pages/Funds";
import Risk from "./pages/Risk";
import Logs from "./pages/Logs";
import Settings from "./pages/Settings";
import Help from "./pages/Help";
import AlgoTrading from "./pages/AlgoTrading";
import Strategies from "./pages/Strategies";
import Signals from "./pages/Signals";
import Scanner from "./pages/Scanner";
import Backtest from "./pages/Backtest";
import ExecutionMonitor from "./pages/ExecutionMonitor";
import MarketOverview from "./pages/MarketOverview";
import System from "./pages/System";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<PasswordGate />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="market-overview" element={<MarketOverview />} />
          <Route path="scanner" element={<Scanner />} />
          <Route path="strategies" element={<Strategies />} />
          <Route path="algo" element={<AlgoTrading />} />
          <Route path="signals" element={<Signals />} />
          <Route path="backtest" element={<Backtest />} />
          <Route path="execution" element={<ExecutionMonitor />} />
          <Route path="system" element={<System />} />
          <Route path="orders" element={<Orders />} />
          <Route path="positions" element={<Positions />} />
          <Route path="holdings" element={<Holdings />} />
          <Route path="history" element={<History />} />
          <Route path="reports" element={<Reports />} />
          <Route path="market-data" element={<MarketData />} />
          <Route path="funds" element={<Funds />} />
          <Route path="risk" element={<Risk />} />
          <Route path="logs" element={<Logs />} />
          <Route path="settings" element={<Settings />} />
          <Route path="help" element={<Help />} />
        </Route>

        {/* Logout is an action (see Sidebar/Header), not a route — any
            unknown path falls back to the password screen. */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  );
}
