// Thin fetch wrapper. In production the frontend is served by the same
// origin as the backend, so relative "/api/..." paths work directly; in
// local dev, Vite's proxy (see vite.config.js) forwards them to :4000.
// `credentials: "include"` ensures the session cookie is sent/received.

async function request(path, options = {}) {
  const res = await fetch(path, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch {
    // Non-JSON response — leave body null, ok/status still tell the caller enough.
  }

  // A protected API can return 401 after a deployment/restart has invalidated
  // the server-side session while React still believes the browser is logged in.
  // Notify AuthContext so ProtectedRoute immediately returns the user to the
  // password gate instead of leaving a stale dashboard that cannot save data.
  if (res.status === 401 && !path.startsWith("/api/auth/")) {
    window.dispatchEvent(new Event("owner-trading-auth-expired"));
  }

  return { ok: res.ok, status: res.status, body };
}

export const api = {
  login: (password) =>
    request("/api/auth/login", { method: "POST", body: JSON.stringify({ password }) }),
  logout: () => request("/api/auth/logout", { method: "POST" }),
  getSession: () => request("/api/auth/session", { method: "GET" }),
  getDashboardSection: (section) => request(`/api/dashboard/${section}`, { method: "GET" }),
  getBrokerStatus: () => request("/api/broker/status", { method: "GET" }),
  getReadiness: () => request("/api/readiness", { method: "GET" }),
  getBrokerAccounts: () => request("/api/broker/accounts", { method: "GET" }),
  saveBrokerAccount: (accountLabel) =>
    request("/api/broker/accounts", { method: "POST", body: JSON.stringify({ accountLabel }) }),
  getKotakCredentialsStatus: () => request("/api/broker/kotak/credentials/status", { method: "GET" }),
  saveKotakCredentials: (creds) =>
    request("/api/broker/kotak/credentials", { method: "POST", body: JSON.stringify(creds) }),
  testKotakConnection: () => request("/api/broker/kotak/test", { method: "POST" }),
  connectKotak: () => request("/api/broker/kotak/connect", { method: "POST" }),
  disconnectKotak: () => request("/api/broker/kotak/disconnect", { method: "POST" }),
  reconnectKotak: () => request("/api/broker/kotak/reconnect", { method: "POST" }),

  // Portfolio / orders / market data / risk / logs -- all backed by the official-SDK broker service.
  getFunds: (refresh) => request(`/api/funds${refresh ? "?refresh=1" : ""}`, { method: "GET" }),
  getPositions: (refresh) => request(`/api/dashboard/positions${refresh ? "?refresh=1" : ""}`, { method: "GET" }),
  getHoldings: (refresh) => request(`/api/dashboard/holdings${refresh ? "?refresh=1" : ""}`, { method: "GET" }),
  getPnl: () => request("/api/dashboard/pnl", { method: "GET" }),
  getSummary: () => request("/api/dashboard/summary", { method: "GET" }),
  getOrders: (limit = 200) => request(`/api/orders?limit=${limit}`, { method: "GET" }),
  placeOrder: (order) => request("/api/orders", { method: "POST", body: JSON.stringify(order) }),
  modifyOrder: (internalOrderId, changes) =>
    request("/api/orders/modify", { method: "POST", body: JSON.stringify({ internalOrderId, ...changes }) }),
  cancelOrder: (internalOrderId) =>
    request("/api/orders/cancel", { method: "POST", body: JSON.stringify({ internalOrderId }) }),
  getTrades: () => request("/api/orders/trades", { method: "GET" }),
  getOrderHistory: (internalOrderId) =>
    request(`/api/orders/history?internalOrderId=${encodeURIComponent(internalOrderId)}`, { method: "GET" }),
  getQuotes: (instruments, quoteType) =>
    request("/api/market-data/quotes", { method: "POST", body: JSON.stringify({ instruments, quote_type: quoteType }) }),
  searchScrip: (params) => request("/api/market-data/scrip-search", { method: "POST", body: JSON.stringify(params) }),
  getScripMaster: (exchangeSegment) =>
    request(`/api/market-data/scrip-master${exchangeSegment ? `?exchange_segment=${encodeURIComponent(exchangeSegment)}` : ""}`, { method: "GET" }),
  getExpiries: (exchange, underlying, instrumentType) =>
    request("/api/market-data/expiries", { method: "POST", body: JSON.stringify({ exchange, underlying, instrument_type: instrumentType }) }),
  getOptionChain: (params) => request("/api/market-data/option-chain", { method: "POST", body: JSON.stringify(params) }),
  getHistoricalData: (params) => request("/api/market-data/historical-data", { method: "POST", body: JSON.stringify(params) }),
  getMarginRequired: (params) => request("/api/market-data/margin", { method: "POST", body: JSON.stringify(params) }),
  getWhatsMyIp: () => request("/api/broker/whatsmyip", { method: "GET" }),
  getMarketTicks: () => request("/api/market-data/ticks", { method: "GET" }),
  getSubscriptions: () => request("/api/market-data/subscriptions", { method: "GET" }),
  subscribeInstrument: (exchange_segment, instrument_token) =>
    request("/api/market-data/subscribe", { method: "POST", body: JSON.stringify({ exchange_segment, instrument_token }) }),
  unsubscribeInstrument: (exchange_segment, instrument_token) =>
    request("/api/market-data/unsubscribe", { method: "POST", body: JSON.stringify({ exchange_segment, instrument_token }) }),
  getAuditLogs: () => request("/api/logs", { method: "GET" }),
  getRiskStatus: () => request("/api/risk", { method: "GET" }),
  getRiskSettings: () => request("/api/risk/settings", { method: "GET" }),
  saveRiskSettings: (settings) => request("/api/risk/settings", { method: "POST", body: JSON.stringify(settings) }),
  getLiveReadiness: () => request("/api/risk/readiness", { method: "GET" }),
  armLive: (confirm) => request("/api/risk/arm-live", { method: "POST", body: JSON.stringify({ confirm }) }),
  disarmLive: () => request("/api/risk/disarm-live", { method: "POST" }),
  reconcileNow: () => request("/api/risk/reconcile", { method: "POST" }),
  activateEmergencyStop: (reason) => request("/api/risk/emergency-stop/activate", { method: "POST", body: JSON.stringify({ reason }) }),
  clearEmergencyStop: () => request("/api/risk/emergency-stop/clear", { method: "POST" }),
};


// LIVE algorithmic trading APIs. Backtest is historical-only and never places broker orders.
api.getAlgoStrategies = () => request("/api/algo/strategies", { method: "GET" });
api.validateAlgoStrategy = (definition) => request("/api/algo/strategy-validate", { method: "POST", body: JSON.stringify({ definition }) });
api.createAlgoStrategy = (payload) => request("/api/algo/strategies", { method: "POST", body: JSON.stringify(payload) });
api.saveAlgoStrategyVersion = (id, payload) => request(`/api/algo/strategies/${id}/versions`, { method: "POST", body: JSON.stringify(payload) });
api.armAlgoStrategy = (versionId) => request(`/api/algo/strategies/versions/${versionId}/arm`, { method: "POST" });
api.disarmAlgoStrategy = (versionId) => request(`/api/algo/strategies/versions/${versionId}/disarm`, { method: "POST" });
api.syncAlgoUniverse = (limit=0) => request("/api/algo/sync-universe", { method: "POST", body: JSON.stringify({ limit }) });
api.getAlgoSignals = (limit=200) => request(`/api/algo/signals?limit=${limit}`, { method: "GET" });
api.getAlgoRuntime = () => request("/api/algo/runtime", { method: "GET" });
api.getScanners = () => request("/api/algo/scanners", { method: "GET" });
api.createScanner = (payload) => request("/api/algo/scanners", { method: "POST", body: JSON.stringify(payload) });
api.updateScanner = (payload) => request("/api/algo/scanners/update", { method: "POST", body: JSON.stringify(payload) });
api.activateScanner = (scanner_id) => request("/api/algo/scanners/activate", { method: "POST", body: JSON.stringify({ scanner_id }) });
api.deactivateScanner = (scanner_id) => request("/api/algo/scanners/deactivate", { method: "POST", body: JSON.stringify({ scanner_id }) });
api.runScanner = (payload) => request("/api/algo/scanners/run", { method: "POST", body: JSON.stringify(payload) });
api.runBacktest = (payload) => request("/api/algo/backtest", { method: "POST", body: JSON.stringify(payload) });
api.getBacktests = (limit=50) => request(`/api/algo/backtests?limit=${limit}`, { method: "GET" });
api.getExecutionChain = (internalOrderId) => request(`/api/algo/execution-chain?internalOrderId=${encodeURIComponent(internalOrderId)}`, { method: "GET" });
api.getFinalAudit = () => request("/api/final-audit", { method: "GET" });
