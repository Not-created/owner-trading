# P0: Nginx 502 from "Failed at step CHDIR" under ProtectHome=true

## Symptom
```
systemd[1]: owner-trading-backend.service: Changing to the requested working directory failed: Permission denied
systemd[1]: owner-trading-backend.service: Failed at step CHDIR spawning /usr/bin/node
```
...and the equivalent for `owner-trading-broker.service`. Nginx then 502s because nothing is listening on
`127.0.0.1:4000`/`127.0.0.1:8800`. Manually editing the installed unit to `ProtectHome=false` made it work, but that
change lives outside the repo and is silently undone by the next `sudo ./deploy.sh`.

## Root cause
Both unit templates run as the dedicated `owner-trading` user with `ProtectHome=true`, which makes `/home`, `/root`
and `/run/user` **entirely inaccessible** to the service, regardless of on-disk ownership/permissions. When the
project is deployed under `/opt/owner-trading` (the templates' placeholder) this is a no-op — `/opt` is untouched by
`ProtectHome=`. But deployed under `/home/ubuntu/owner-trading/owner-trading` (this server), `ProtectHome=true` hides
`WorkingDirectory` itself. The units already had `ReadWritePaths=` for the *data* subdirectories (`backend/data`,
`backend/src/data/secure`, `broker-service/data`) — but never for `WorkingDirectory` (`backend/`, `broker-service/`)
itself, so those stayed hidden and `chdir()` failed before `node`/`python` ever ran. This is unrelated to real file
permissions on `/home/ubuntu` — `ProtectHome=true` hides the tree unconditionally.

## Fix
Added one line to each unit (`deployment/systemd/owner-trading-{backend,broker}.service`):
```
ReadOnlyPaths=/opt/owner-trading/backend          # backend unit
ReadOnlyPaths=/opt/owner-trading/broker-service   # broker unit
```
`systemd.exec(5)` applies `ProtectSystem=`, `ProtectHome=`, `ReadOnlyPaths=`, `InaccessiblePaths=`, `ReadWritePaths=`
**in that fixed order, later entries winning on overlap** — regardless of the order the directives appear in the unit
file. So `ReadOnlyPaths=` re-exposes exactly the service's own directory (read-only) after `ProtectHome=` hides it,
and the existing `ReadWritePaths=` entries (nested under it) continue to grant write access to only the data/secure
directories, same as before. `ProtectHome=true` is **unchanged** — still `true`, still hides everything else under
`/home` (other users' home directories, `/root`, `/run/user`). This is a no-op when deployed under `/opt` (already
read-only there via `ProtectSystem=strict`), so the same templates work at either location without a
deploy-path-specific branch. `deploy.sh`'s existing `sed -e "s#/opt/owner-trading#${ROOT_DIR}#g"` substitution
applies to the new line exactly like every other path in the unit — no deploy.sh change was needed for that part.

`deploy.sh` also now: chmod's `o+rx` (traverse-only, non-recursive, not the contents) on `backend/` and
`broker-service/` themselves if the "other" permission bit is missing, satisfying "owner-trading can traverse every
parent directory" defensively, even though in the reported case `ProtectHome`'s own re-exposure mechanism (systemd
creates the ancestor directories as fresh `root:root 0755` mount points inside the service's private namespace, not
the real `/home/ubuntu`) already makes real `/home/ubuntu` permissions irrelevant to this specific failure.

## Files changed
- `deployment/systemd/owner-trading-backend.service` — added `ReadOnlyPaths=/opt/owner-trading/backend`
- `deployment/systemd/owner-trading-broker.service` — added `ReadOnlyPaths=/opt/owner-trading/broker-service`
- `deploy.sh` — ancestor-traversal guard; moved backend/broker local health checks (with effective `systemctl show`
  dump and a CHDIR-in-journal regression check) to run immediately after starting the services and **before** the
  Nginx section; added an explicit Nginx-upstream 502 check after Nginx is configured
- `deployment/verify-deployment.sh` — added the same CHDIR/ProtectHome/ReadOnlyPaths checks for standalone use
- `broker-service/tests/test_systemd_workinghome.py` (new) — **empirically** reproduces the failure and the fix
  using real Linux mount namespaces (`unshare`+`mount`), including a negative control proving the pre-fix config
  really does fail. Runs (not skipped) under `deploy.sh`'s own test-suite step, since that runs as root on the
  target host — every future deploy re-verifies this exact fix before touching systemd.
- `broker-service/tests/test_deployment_config.py` — added static checks (ProtectHome stays true, ReadOnlyPaths
  covers WorkingDirectory, ReadWritePaths stays a strict subtree, deploy.sh checks ordered correctly)

## Verified
- `systemd-analyze verify` on both units, substituted exactly as `deploy.sh` does, against
  `/home/ubuntu/owner-trading/owner-trading/...` (the reported path): **exit 0, no errors** for both.
- **Empirical, not just documented**: a real Linux mount namespace was built with `unshare`+`mount`, replaying the
  documented systemd order (tmpfs over `/home` for `ProtectHome=true`, then the unit's own `ReadOnlyPaths=`/
  `ReadWritePaths=`), and a real unprivileged test user (no relationship to the tree's owner, exactly like
  `owner-trading`) was confirmed to: `chdir()` into `WorkingDirectory` successfully, read real file content there,
  get correctly refused when writing to the read-only tree, successfully write to the designated data directory, and
  get correctly refused reading an unrelated `/home` sibling (proving `ProtectHome` still isolates everything else).
  A negative control with the line removed reproduces the exact original failure. All of this runs as
  `broker-service/tests/test_systemd_workinghome.py`; 250/250 broker-service tests pass including it.
- 23/23 backend `node:test` cases pass; frontend syntax/import-resolution clean.
- `bash -n` on `deploy.sh`, `deployment/set-mode.sh`, `deployment/verify-deployment.sh`.

## NOT verified (requires your actual server)
- The real `owner-trading-backend.service`/`owner-trading-broker.service` were not started under a live `systemd`
  PID 1 (none is available in the build sandbox) — `systemd-analyze verify` confirms the units are valid and all
  referenced paths/binaries exist at the exact substituted path, and the namespace test confirms the underlying
  mechanism works, but neither is a substitute for `sudo ./deploy.sh` actually running on
  `/home/ubuntu/owner-trading/owner-trading`.
- Real ports 4000/8800 listening, real Nginx upstream connectivity, and the public site no longer 502ing must be
  confirmed by running `deploy.sh` (it now checks all of this itself and fails loudly if any of it is wrong) and/or
  `deployment/verify-deployment.sh` on the server.
