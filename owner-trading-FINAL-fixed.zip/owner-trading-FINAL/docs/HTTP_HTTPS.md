# HTTP + HTTPS and the session cookie

## Root cause of the earlier failure
`app.js` hard-wired `cookie.secure = (NODE_ENV === "production")`. `deploy.sh` (and any browser) reaching the app over
plain HTTP therefore received a `Secure` cookie it must not store or return, so `POST /api/auth/login` returned 200
(password authentication was fine) but no session could ever be established over HTTP.

## Design
| Setting | Behaviour |
|---|---|
| `SESSION_COOKIE_SECURE=auto` (default) | per request: **Secure** when the request is HTTPS (direct, or via nginx's `X-Forwarded-Proto: https`), plain on HTTP |
| `true` | always Secure → login works on HTTPS only. **Required for `LIVE_EXECUTION=LIVE`** (enforced at startup; `set-mode.sh LIVE` sets it) |
| `false` | never Secure (HTTP-only bootstrap/dev); warning at startup |

`HttpOnly` and `SameSite=Lax` are fixed. Session secret and lifetime (`SESSION_MAX_AGE_MS`, default 12 h) are unchanged.
Code: `backend/src/config/sessionCookie.js` (policy), `backend/src/app.js` (uses it; `trust proxy` = 1 = the local nginx).

## nginx
`deployment/nginx/`: `owner-trading.http.conf` (port 80, always installed, **no redirect**), `owner-trading.https.conf`
(port 443, appended only when a domain **and** a certificate exist), `owner-trading-locations.conf` (identical locations
for both ports), `owner-trading-proxy.conf` (Host / X-Real-IP / X-Forwarded-For / **X-Forwarded-Proto**; included in every
proxying location because nginx does not inherit `proxy_set_header` into a location that sets its own), `owner-trading-zones.conf`.
No domain or certificate ⇒ deployment succeeds with HTTP only. If your setup puts another TLS-terminating proxy in front of
nginx, forward its `X-Forwarded-Proto` instead of `$scheme`.

## What `deploy.sh` verifies (after you set a password in that run)
1. HTTP → Express: cookie issued, HttpOnly, SameSite=Lax, **not** Secure; authenticated `/api/risk` = 200; logout destroys it.
2. HTTPS → Express: the exact header nginx adds on 443 (`X-Forwarded-Proto: https`) is sent — labelled *simulated* — cookie must be Secure.
3. HTTP → nginx:80 (real reverse proxy), if nginx is active.
4. HTTPS → nginx:443 over real TLS with certificate verification, if a certificate was issued.
The plain-HTTP flows send no proxy headers. Password goes to curl via stdin, never argv.

## To get real HTTPS you still need
A domain whose DNS A/AAAA record points at the server, ports 80/443 reachable, and `DOMAIN` + `CERTBOT_EMAIL` on the
`deploy.sh` command line. HTTPS cannot be verified from inside the build environment; do it with `deployment/verify-deployment.sh`.
