"""LIVE strategy runtime.

Phase 7-9 keeps the original execution chain but makes it restart-safe:
completed-candle -> validated scanner/strategy -> immutable signal -> durable
order -> broker -> fill reconciliation -> algo position. No simulator calls.
"""
from __future__ import annotations
import asyncio,datetime as dt,logging
from . import db,strategy_engine,order_service,live_readiness
from .market_session import session_state
from .state import current_state,BrokerState

logger=logging.getLogger('owner_trading.algo')

class AlgoEngine:
    def __init__(self):
        self._lock=asyncio.Lock()
        self._last_eval={}

    def active_versions(self):
        out=[]
        for st in db.list_strategies():
            for v in st['versions']:
                if v['is_live_armed'] and not v.get('validation_errors'):
                    out.append((st,v))
        return out

    async def on_tick(self,*,exchange_segment,instrument_token,trading_symbol,timeframe='5m'):
        if current_state.state!=BrokerState.CONNECTED:return
        versions=self.active_versions()
        db.refresh_algo_runtime()
        if not versions:return
        async with self._lock:
            for st,v in versions:
                definition=v['definition']
                tf=str(definition.get('timeframe') or timeframe)
                if tf not in strategy_engine.TIMEFRAMES:continue
                candles=db.recent_candles(exchange_segment,instrument_token,tf,250)
                if len(candles)<20:continue
                candle_at=str(candles[-1]['candle_at'])
                key=(v['id'],exchange_segment,str(instrument_token),tf)
                if self._last_eval.get(key)==candle_at:continue
                self._last_eval[key]=candle_at

                errors=strategy_engine.validate_strategy(definition)
                if errors:continue

                # Optional strategy universe binding. Empty/missing means the
                # normal synced universe; explicit tokens are authoritative.
                bound=(definition.get('universe') or {}).get('instrument_tokens') if isinstance(definition.get('universe'),dict) else None
                if bound and str(instrument_token) not in {str(x) for x in bound}:continue

                # Never generate new automated entries outside the normal cash
                # continuous session. Broker/readiness remains the final gate.
                if not session_state()['open']:
                    continue

                max_positions=int(definition.get('max_positions') or 1)
                open_for_strategy=[p for p in db.list_algo_positions() if p['strategy_version_id']==v['id']]
                if len(open_for_strategy)>=max_positions:continue

                # Cooldown after a closed position is optional and candle based.
                cooldown=int((definition.get('execution') or {}).get('cooldown_bars') or 0)
                if cooldown:
                    recent=db.latest_closed_algo_position(v['id'],exchange_segment,str(instrument_token))
                    if recent and recent.get('closed_at'):
                        try:
                            closed=dt.datetime.fromisoformat(str(recent['closed_at']).replace(' ','T')).replace(tzinfo=dt.timezone.utc)
                            cur=dt.datetime.fromisoformat(candle_at.replace(' ','T')).replace(tzinfo=dt.timezone.utc)
                            if (cur-closed).total_seconds() < cooldown*strategy_engine.TIMEFRAMES[tf]*60:continue
                        except ValueError:pass

                passed,detail=strategy_engine.evaluate_entry(definition,candles)
                if not passed:continue

                active_scanners=[x for x in db.list_scanners() if x.get('is_active')]
                scanner_matches=[]
                for scanner in active_scanners:
                    scanner_errors=strategy_engine.validate_strategy(scanner['definition'])
                    if scanner_errors:continue
                    sm,_=strategy_engine.evaluate_entry(scanner['definition'],candles)
                    if sm:scanner_matches.append(scanner['id'])
                if active_scanners and not scanner_matches:continue

                price=float(candles[-1]['close'])
                side=str(definition.get('side','BUY')).upper()
                funds=db.latest_funds_snapshot()
                available=funds.get('available_margin') if funds else None
                inst=db.get_instrument(exchange_segment,str(instrument_token)) or {}
                lot_size=inst.get('lot_size') or 1
                rs=db.get_risk_settings()
                qty=strategy_engine.size_position(
                    definition,price,available_funds=available,
                    atr_value=detail.get('indicators',{}).get('atr14'),
                    lot_size=lot_size,max_quantity=rs.get('max_order_quantity'))
                readiness=live_readiness.evaluate()
                if qty<=0:
                    continue
                risk={'readiness':readiness,'quantity':qty,'side':side,
                      'scanner_ids':scanner_matches,'available_margin':available,
                      'lot_size':lot_size,'session':session_state()}

                # Signal is persisted BEFORE the broker call. This is the
                # immutable parent of the eventual order.
                signal_id=db.record_signal(
                    scanner_id=(scanner_matches[0] if scanner_matches else None),
                    strategy_version_id=v['id'],exchange_segment=exchange_segment,
                    instrument_token=str(instrument_token),trading_symbol=trading_symbol,
                    timeframe=tf,side=side,signal_price=price,conditions=detail,
                    risk=risk,status='DETECTED',candle_at=candle_at)
                existing=db.get_signal(signal_id)
                # The signal is immutable: once this candle has produced a signal,
                # never create a second broker order for the same execution key.
                if existing and (existing.get('internal_order_id') or existing.get('status') in ('ORDERED','BLOCKED','CANCELLED','REJECTED')):
                    continue

                status='BLOCKED';oid=None
                if readiness['ready'] and readiness['armed'] and readiness['live_orders_can_be_sent']:
                    try:
                        order=await order_service.place_order({
                            'trading_symbol':trading_symbol,'exchange_segment':exchange_segment,
                            'transaction_type':'B' if side=='BUY' else 'S',
                            'order_type':'MKT',
                            'product':definition.get('execution',{}).get('product','MIS'),
                            'validity':'DAY','quantity':qty,'instrument_token':str(instrument_token),
                            'signal_id':signal_id,'order_role':'ENTRY',
                            'idempotency_key':f'algo-{v["id"]}-{exchange_segment}-{instrument_token}-{tf}-{candle_at}',
                        })
                        if order:
                            oid=order.get('internal_order_id')
                            status='ORDERED' if order.get('status') in ('SUBMITTING','SUBMITTED','OPEN','PARTIALLY_FILLED','PENDING_RECONCILE') else 'BLOCKED'
                    except Exception as exc:
                        logger.exception('algo order blocked')
                        risk['error']=str(exc)

                db.update_signal_execution(signal_id,status=status,internal_order_id=oid,risk=risk)
                now=dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
                db.set_algo_runtime(last_signal_at=now,last_execution_at=now if oid else None,status='RUNNING')

algo_engine=AlgoEngine()
