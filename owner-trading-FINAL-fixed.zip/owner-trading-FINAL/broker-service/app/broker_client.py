"""Session owner for the official Kotak Neo SDK (v3.0.7).

This module owns exactly one authenticated `KotakSdk` (see sdk_adapter.py,
the only module that imports `neo_api_client`) for the process lifetime and
drives the state machine. It contains NO legacy v2 calls, NO guessed
parameter names; every executable order is routed to the official Kotak SDK
(see order_service.py), and every method here talks to the real SDK.

Authentication runs only when /connect or /test is explicitly invoked --
never on startup. CONNECTED is reported only after: totp_login OK ->
totp_validate OK -> a Trade session (edit_token + edit_sid) exists -> a
read-only limits() call is accepted by the broker.
"""
from __future__ import annotations

import asyncio
import logging

from . import sdk_adapter, sdk_conformance
from .config import config
from .sdk_adapter import AUTH, UNKNOWN, KotakSdk, Outcome
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.broker_client")


class NotConfiguredError(RuntimeError):
    """No usable broker session. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """A state-changing broker call was attempted while LIVE is not allowed.
    Enforced here independently of the Express middleware (defence in depth)."""


def sdk_ready() -> tuple[bool, str]:
    """(ok, reason). The official SDK must import AND be the pinned version."""
    if not sdk_adapter.SDK_AVAILABLE:
        return False, f"Official kotakneoapi SDK is not importable: {sdk_adapter.SDK_IMPORT_ERROR}"
    v = sdk_adapter.SDK_VERSION
    if v is not None and v != sdk_adapter.REQUIRED_SDK_VERSION:
        return False, f"Installed SDK is {v}; this service is built and verified against {sdk_adapter.REQUIRED_SDK_VERSION}."
    return True, ""


def assert_live_trading_allowed(*, exclude_internal_order_id: str | None = None, allow_controlled_exit: bool = False) -> None:
    """Canonical defense-in-depth LIVE gate. Entries require every blocking readiness
    condition; controlled exits may bypass ONLY emergency-stop/arming so an existing
    position can still be flattened, but all broker/session/reconciliation/feed gates remain.
    """
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("LIVE execution is not available.")
    if _db.is_emergency_stop_active() and not allow_controlled_exit:
        raise LiveTradingBlockedError("Emergency stop is active; new exposure is blocked.")
    if current_state.state != BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")
    if not allow_controlled_exit and not _db.is_live_armed():
        raise LiveTradingBlockedError("LIVE trading has not been armed by the owner (Risk page).")
    # Vendor integrity is a hard LIVE prerequisite.
    vend = sdk_conformance.check_vendor_integrity()
    if not vend.ok:
        raise LiveTradingBlockedError("Vendored official Kotak SDK integrity check failed: " + "; ".join(vend.errors[:3]))
    # The latest clean broker reconciliation is mandatory, not merely advisory.
    rr = _db.latest_reconciliation_run()
    if not rr or rr.get("status") != "COMPLETE" or not rr.get("sections_ok") or int(rr.get("discrepancy_count") or 0) != 0:
        raise LiveTradingBlockedError("Latest broker reconciliation is not clean; LIVE execution is blocked.")
    # Defense-in-depth: every state-changing LIVE path also requires a recent
    # reconciliation and no unresolved broker outcome. This intentionally does
    # not call the full readiness evaluator here (which can recurse through the
    # broker client); the critical durable gates are checked directly.
    unresolved=[o for o in _db.list_unresolved_live_orders() if (o.get("outcome_unknown") or o.get("status") in ("SUBMITTING","PENDING_RECONCILE")) and o.get("internal_order_id") != exclude_internal_order_id]
    if unresolved:
        raise LiveTradingBlockedError(f"{len(unresolved)} LIVE order(s) require reconciliation before another order can be sent.")
    funds=_db.latest_funds_snapshot()
    if not funds:
        raise LiveTradingBlockedError("No broker funds reconciliation snapshot is available.")
    try:
        from .live_readiness import _age_seconds
        age=_age_seconds(funds.get("snapshot_at"))
        if age is None or age >= 20*60:
            raise LiveTradingBlockedError("Broker reconciliation snapshot is stale; reconcile before LIVE execution.")
    except LiveTradingBlockedError:
        raise
    except Exception:
        raise LiveTradingBlockedError("Broker reconciliation freshness could not be verified.")


class BrokerClient:
    def __init__(self) -> None:
        self._sdk: KotakSdk | None = None
        # connect/test/disconnect/reconnect are serialised: two overlapping
        # requests must never race on the SDK session or state machine.
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ #
    # Session
    # ------------------------------------------------------------------ #
    def is_connected(self) -> bool:
        return self._sdk is not None and current_state.state in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        )

    @property
    def sdk(self) -> KotakSdk | None:
        return self._sdk

    async def _login(self) -> tuple[Outcome, KotakSdk | None]:
        from .credential_manager import credential_manager

        ok, reason = sdk_ready()
        if not ok:
            return Outcome(UNKNOWN, message=reason, code="SDK"), None
        creds = credential_manager.get()
        if not credential_manager.has_base_credentials() or creds is None:
            return Outcome("REJECTED", message="Credentials have not been saved yet.", code="NOT_CONFIGURED"), None
        totp = credential_manager.current_totp_code()
        if not totp:
            return Outcome("REJECTED", message="Could not generate a TOTP code (no secret saved or pyotp unavailable).", code="TOTP"), None
        loop = asyncio.get_running_loop()
        try:
            sdk = KotakSdk(creds.consumer_key, config.environment)
            outcome = await loop.run_in_executor(
                None, lambda: sdk.login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp, mpin=creds.mpin)
            )
        except Exception as exc:  # noqa: BLE001 -- transport/SDK failure is a connection error, not a rejection
            return Outcome(UNKNOWN, message=f"login failed: {type(exc).__name__}", code="TRANSPORT_ERROR"), None
        if not outcome.ok:
            return outcome, None
        # Read-only verification: the broker must accept the new session.
        try:
            verify = await loop.run_in_executor(None, sdk.limits)
        except Exception as exc:  # noqa: BLE001
            return Outcome(UNKNOWN, message=f"read-only verification (limits) failed: {type(exc).__name__}", code="TRANSPORT_ERROR"), None
        if not verify.ok:
            return Outcome("REJECTED", message=f"Session established but limits() was not accepted: {verify.message}",
                           code="SESSION_VERIFICATION_FAILED"), None
        return outcome, sdk

    async def connect(self) -> dict:
        async with self._lock:
            return await self._connect_locked()

    async def _connect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session
        from .credential_manager import credential_manager

        if not credential_manager.has_base_credentials():
            current_state.transition(BrokerState.NOT_CONFIGURED, "Credentials have not been saved yet.")
            return current_state.as_dict()
        current_state.transition(BrokerState.VERIFYING)
        outcome, sdk = await self._login()
        if sdk is None:
            self._sdk = None
            target = BrokerState.CONNECTION_ERROR if outcome.kind == UNKNOWN else BrokerState.AUTH_FAILED
            current_state.transition(target, (outcome.message or "Authentication failed.")[:300])
            return current_state.as_dict()

        self._sdk = sdk
        dc = sdk.data_center()
        _session.mark_session_established(dc)
        _db.record_reconciliation(
            reconciliation_type="connect", reference_id=credential_manager.get().ucc,
            discrepancy_found=False, details={"data_center": dc, "verification_call": "limits"},
        )
        # Best-effort layers on top of an already-verified REST session.
        try:
            from . import reconciliation as _reconciliation
            await _reconciliation.run_full_reconciliation()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Post-connect reconciliation failed (state remains CONNECTED): %s", exc)
        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.start()
        except Exception as exc:  # noqa: BLE001
            logger.warning("WebSocket start failed after connect (REST-only): %s", exc)
        return current_state.as_dict()

    async def test_connection(self) -> dict:
        async with self._lock:
            outcome, sdk = await self._login()
            if sdk is not None:
                try:
                    await asyncio.get_running_loop().run_in_executor(None, sdk.logout)
                except Exception:  # noqa: BLE001 -- test result already known
                    pass
                return {"success": True}
            return {"success": False, "error": (outcome.message or "Test failed.")[:300], "code": outcome.code}

    async def disconnect(self) -> dict:
        async with self._lock:
            return await self._disconnect_locked()

    async def _disconnect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session

        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.stop()
        except Exception:  # noqa: BLE001
            pass
        if self._sdk is not None:
            try:
                await asyncio.get_running_loop().run_in_executor(None, self._sdk.logout)
            except Exception:  # noqa: BLE001
                pass
        self._sdk = None
        _session.current_session.established_at = None
        try:
            _db.record_session_ended()
        except Exception:  # noqa: BLE001
            pass
        current_state.transition(BrokerState.DISCONNECTED)
        return current_state.as_dict()

    async def reconnect(self) -> dict:
        async with self._lock:
            await self._disconnect_locked()
            return await self._connect_locked()

    # ------------------------------------------------------------------ #
    # Calls (synchronous; run in an executor by callers)
    # ------------------------------------------------------------------ #
    def _require_connected(self) -> KotakSdk:
        if self._sdk is None or current_state.state not in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        ):
            raise NotConfiguredError(f"Broker is not connected (state: {current_state.state.value}).")
        return self._sdk

    def _after(self, outcome: Outcome) -> Outcome:
        """A broker answer that says the session is invalid downgrades our
        state immediately instead of waiting for a TTL guess."""
        if outcome.kind == AUTH and current_state.state in (BrokerState.CONNECTED, BrokerState.RECONCILING):
            from . import session as _session
            logger.warning("Broker reported an invalid/absent session; marking SESSION_EXPIRED.")
            _session.mark_session_expired()
        return outcome

    def read(self, method: str, *args, **kwargs) -> Outcome:
        """Read-only SDK call by adapter method name."""
        allowed = {
            "order_report", "order_history", "trade_report", "positions", "holdings", "limits",
            "margin_required", "quotes", "scrip_master", "search_scrip", "whatsmyip",
            "expiries", "option_chain", "historical_data",
        }
        if method not in allowed:
            raise ValueError(f"{method} is not a permitted read call.")
        return self._after(getattr(self._require_connected(), method)(*args, **kwargs))

    def place_order(self, req: sdk_adapter.OrderRequest, *, internal_order_id: str | None = None, allow_controlled_exit: bool = False, instrument_token: str | None = None) -> Outcome:
        # The local order row is deliberately created BEFORE this broker call.
        # Exclude that one durable SUBMITTING row from the gate so the safety
        # check does not block the very order it is validating. All other
        # pending/unknown submissions remain a hard block.
        assert_live_trading_allowed(exclude_internal_order_id=internal_order_id, allow_controlled_exit=allow_controlled_exit)
        if req.transaction_type == "B" and instrument_token:
            ref = req.price or req.trigger_price
            if ref is None:
                raise LiveTradingBlockedError("LIVE BUY margin cannot be verified without a reference price.")
            margin = self.read("margin_required", exchange_segment=req.exchange_segment, price=ref,
                               order_type=req.order_type, product=req.product, quantity=req.quantity,
                               instrument_token=instrument_token, transaction_type=req.transaction_type,
                               trigger_price=req.trigger_price)
            if margin.kind != sdk_adapter.OK:
                raise LiveTradingBlockedError("Kotak margin_required failed; LIVE BUY blocked.")
            from .order_service import _extract_margin_required
            required_margin = _extract_margin_required(margin.data)
            from . import db as _db
            funds = _db.latest_funds_snapshot()
            if not funds or funds.get("available_margin") is None or required_margin is None:
                raise LiveTradingBlockedError("Available margin or Kotak required margin is unavailable; LIVE BUY blocked.")
            if required_margin > float(funds["available_margin"]):
                raise LiveTradingBlockedError(f"Required margin {required_margin:.2f} exceeds available margin {float(funds['available_margin']):.2f}.")
        return self._after(self._require_connected().place_order(req))

    def modify_order(self, **kwargs) -> Outcome:
        assert_live_trading_allowed()
        return self._after(self._require_connected().modify_order(**kwargs))

    def cancel_order(self, **kwargs) -> Outcome:
        assert_live_trading_allowed()
        return self._after(self._require_connected().cancel_order(**kwargs))

    def create_market_feed(self, **kwargs):
        return self._require_connected().create_market_feed(**kwargs)

    def create_order_feed(self, **kwargs):
        return self._require_connected().create_order_feed(**kwargs)


broker_client = BrokerClient()
