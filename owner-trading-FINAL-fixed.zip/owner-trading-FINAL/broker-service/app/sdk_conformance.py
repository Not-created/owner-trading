"""Verifies that the SDK this service will actually call matches the exact
signatures sdk_adapter.py was written against (official v3.0.7).

Two independent checks over the SAME table:
  * runtime  : `inspect.signature` on the INSTALLED neo_api_client (startup gate)
  * static   : `ast` over vendored source (works with no dependencies installed;
               used by the test-suite and by deploy.sh before installing)
plus an integrity check of the vendored tree against VENDOR_MANIFEST.sha256.
"""
from __future__ import annotations

import ast
import hashlib
import os
from dataclasses import dataclass, field

from . import sdk_adapter

# method -> (parameters the adapter PASSES, parameters that are REQUIRED upstream)
EXPECTED: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "__init__": (("consumer_key", "environment"), ()),
    "totp_login": (("mobile_number", "ucc", "totp"), ("mobile_number", "ucc", "totp")),
    "totp_validate": (("mpin",), ("mpin",)),
    "place_order": (("exchange_segment", "product", "price", "order_type", "quantity", "validity", "trading_symbol",
                     "transaction_type", "amo", "disclosed_quantity", "trigger_price", "tag"),
                    ("exchange_segment", "product", "price", "order_type", "quantity", "validity", "trading_symbol", "transaction_type")),
    "modify_order": (("order_id", "price", "order_type", "quantity", "validity", "trigger_price", "disclosed_quantity", "amo"),
                     ("order_id", "price", "order_type", "quantity", "validity")),
    "cancel_order": (("order_id", "amo"), ("order_id",)),
    "order_report": (("order_id",), ()),
    "order_history": (("order_id",), ("order_id",)),
    "trade_report": ((), ()),
    "positions": ((), ()),
    "holdings": ((), ()),
    "limits": ((), ()),
    "whatsmyip": ((), ()),
    "logout": ((), ()),
    "margin_required": (("exchange_segment", "price", "order_type", "product", "quantity", "instrument_token",
                         "transaction_type", "trigger_price"),
                        ("exchange_segment", "price", "order_type", "product", "quantity", "instrument_token", "transaction_type")),
    "quotes": (("instrument_tokens", "quote_type"), ()),
    "scrip_master": (("exchange_segment",), ()),
    "search_scrip": (("exchange_segment", "symbol", "expiry", "option_type", "strike_price"), ()),
    "expiries": (("exchange", "underlying", "instrument_type"), ("exchange", "underlying")),
    "option_chain": (("exchange", "underlying", "expiry", "instrument_type", "count"), ("exchange", "underlying")),
    "historical_data": (("neosymbol", "interval", "from_date", "to_date"),
                        ("neosymbol", "interval", "from_date", "to_date")),
    "create_websocket": ((), ()),      # **kwargs
    "create_order_feed": ((), ()),     # **kwargs
}

_HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR_DIR = os.path.normpath(os.path.join(_HERE, "..", "vendor"))


@dataclass
class ConformanceResult:
    ok: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checked: int = 0

    def summary(self) -> str:
        if self.ok:
            return f"SDK conformance OK ({self.checked} methods match official {sdk_adapter.REQUIRED_SDK_VERSION})."
        return "SDK conformance FAILED: " + "; ".join(self.errors)


def _check_method(res: ConformanceResult, name: str, params: list[str], required: list[str]) -> None:
    passes, must = EXPECTED[name]
    res.checked += 1
    missing = [p for p in passes if p not in params]
    if missing:
        res.ok = False
        res.errors.append(f"NeoAPI.{name} no longer accepts {missing}")
    new_required = [r for r in required if r not in must]
    if new_required:
        res.ok = False
        res.errors.append(f"NeoAPI.{name} now REQUIRES {new_required} which the adapter does not pass")


def check_static(source_path: str | None = None) -> ConformanceResult:
    """AST check of neo_api.py (no imports of the SDK needed)."""
    path = source_path or os.path.join(VENDOR_DIR, "kotakneoapi", "neo_api_client", "neo_api.py")
    res = ConformanceResult()
    try:
        with open(path, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
    except OSError as exc:
        return ConformanceResult(ok=False, errors=[f"cannot read {path}: {exc}"])
    methods = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "NeoAPI":
            for f in node.body:
                if isinstance(f, ast.FunctionDef):
                    methods[f.name] = f
    for name in EXPECTED:
        f = methods.get(name)
        if f is None:
            res.ok = False
            res.errors.append(f"NeoAPI.{name} not found")
            continue
        a = f.args
        pos = [x.arg for x in a.posonlyargs + a.args][1:]
        kwonly = [x.arg for x in a.kwonlyargs]
        n_def = len(a.defaults)
        required = pos[: len(pos) - n_def] if n_def else pos
        required += [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None]
        _check_method(res, name, pos + kwonly, required)
    return res


def check_runtime() -> ConformanceResult:
    import inspect

    res = ConformanceResult()
    if not sdk_adapter.SDK_AVAILABLE:
        return ConformanceResult(ok=False, errors=[f"SDK not importable: {sdk_adapter.SDK_IMPORT_ERROR}"])
    if sdk_adapter.SDK_VERSION not in (None, sdk_adapter.REQUIRED_SDK_VERSION):
        res.ok = False
        res.errors.append(f"SDK version {sdk_adapter.SDK_VERSION} != {sdk_adapter.REQUIRED_SDK_VERSION}")
    for name in EXPECTED:
        fn = getattr(sdk_adapter.NeoAPI, name, None)
        if fn is None:
            res.ok = False
            res.errors.append(f"NeoAPI.{name} not found")
            continue
        sig = inspect.signature(fn)
        params = [p for p in sig.parameters if p != "self"]
        required = [p for p, v in sig.parameters.items() if p != "self" and v.default is inspect.Parameter.empty
                    and v.kind in (v.POSITIONAL_OR_KEYWORD, v.KEYWORD_ONLY)]
        _check_method(res, name, params, required)
    return res


def check_vendor_integrity(vendor_dir: str | None = None) -> ConformanceResult:
    """Every file listed in VENDOR_MANIFEST.sha256 must exist and hash identically."""
    vd = vendor_dir or VENDOR_DIR
    res = ConformanceResult()
    manifest = os.path.join(vd, "VENDOR_MANIFEST.sha256")
    try:
        with open(manifest, encoding="utf-8") as fh:
            lines = [ln.split(None, 1) for ln in fh.read().splitlines() if ln.strip()]
    except OSError as exc:
        return ConformanceResult(ok=False, errors=[f"manifest unreadable: {exc}"])
    for digest, rel in lines:
        rel = rel.strip().lstrip("*")
        p = os.path.join(vd, "kotakneoapi", rel)
        res.checked += 1
        try:
            with open(p, "rb") as fh:
                actual = hashlib.sha256(fh.read()).hexdigest()
        except OSError:
            res.ok = False
            res.errors.append(f"vendored file missing: {rel}")
            continue
        if actual != digest:
            res.ok = False
            res.errors.append(f"vendored file modified: {rel}")
    return res


def check_sdk_conformance() -> ConformanceResult:
    """Startup gate: runtime signatures of the installed SDK (+ version)."""
    return check_runtime()
