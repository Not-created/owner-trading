"""Pure (no I/O) normalisation and P&L math for Kotak Neo responses.

Field names come from the official SDK docs/source shipped with this
project (docs/functions/portfolio/{positions,holdings,limits}.md, v3.0.7):

positions() row: trdSym, sym, exSeg, prod, tok, cfBuyQty, flBuyQty,
  cfSellQty, flSellQty, cfBuyAmt, buyAmt, cfSellAmt, sellAmt, lotSz,
  multiplier, genNum, genDen, prcNum, prcDen (all numeric fields are strings).
holdings() row: symbol/displaySymbol, quantity, averagePrice, closingPrice,
  instrumentToken, exchangeSegment, mktValue.
limits() (flat dict): Net, MarginUsed, {Cash,Fo,Com,Cur}UnRlsMtomPrsnt,
  {Cash,Fo,Com,Cur}RlsMtomPrsnt.

P&L (documented formula):
  PnL = (TotalSellAmt - TotalBuyAmt) + NetQty * LTP * multiplier*(genNum/genDen)*(prcNum/prcDen)
We compute realised + unrealised separately and assert they sum to it (tested).

ASSUMPTION FLAGGED AS UNVERIFIED: the docs say F&O quantities are divided by
lotSz for display. P&L here uses raw unit quantities together with the money
amounts Kotak returns (per-unit price = amount / units), which is
dimensionally consistent for cash and, by the sample row, for futures. Confirm
against one real F&O position before trusting F&O P&L in LIVE.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

ZERO = Decimal(0)


def dec(v: Any, default: Decimal | None = ZERO) -> Decimal | None:
    if v is None or v == "":
        return default
    try:
        return Decimal(str(v).strip())
    except (InvalidOperation, ValueError):
        return default


def _f(d: Decimal | None) -> float | None:
    return None if d is None else float(d)


def price_factor(row: dict) -> Decimal:
    """multiplier * (genNum/genDen) * (prcNum/prcDen); missing/zero parts count as 1."""
    def one(v):
        d = dec(v, None)
        return d if d not in (None, ZERO) else Decimal(1)
    return one(row.get("multiplier")) * (one(row.get("genNum")) / one(row.get("genDen"))) * (one(row.get("prcNum")) / one(row.get("prcDen")))


def normalize_position(row: dict) -> dict:
    buy_q = dec(row.get("cfBuyQty")) + dec(row.get("flBuyQty"))
    sell_q = dec(row.get("cfSellQty")) + dec(row.get("flSellQty"))
    buy_a = dec(row.get("cfBuyAmt")) + dec(row.get("buyAmt"))
    sell_a = dec(row.get("cfSellAmt")) + dec(row.get("sellAmt"))
    net = buy_q - sell_q
    factor = price_factor(row)
    # Average price per the docs: amount / (qty * factor); the side that is open.
    if net > 0 and buy_q:
        avg = buy_a / (buy_q * factor)
    elif net < 0 and sell_q:
        avg = sell_a / (sell_q * factor)
    else:
        avg = ZERO
    return {
        "trading_symbol": row.get("trdSym"),
        "exchange_segment": row.get("exSeg"),
        "product": row.get("prod"),
        "instrument_token": str(row["tok"]) if row.get("tok") not in (None, "") else None,
        "buy_quantity": int(buy_q),
        "sell_quantity": int(sell_q),
        "quantity": int(net),
        "buy_amount": _f(buy_a),
        "sell_amount": _f(sell_a),
        "average_price": _f(avg.quantize(Decimal("0.0001"))),
        "price_factor": _f(factor),
        "lot_size": int(dec(row.get("lotSz"))) if row.get("lotSz") not in (None, "") else None,
        "raw": row,
    }


def position_pnl(pos: dict, ltp: float | None) -> dict:
    """Realised + unrealised P&L for one normalised position.
    `ltp` None => unrealised (and total) are None: never fabricated."""
    buy_q, sell_q, net = dec(pos["buy_quantity"]), dec(pos["sell_quantity"]), dec(pos["quantity"])
    buy_a, sell_a = dec(pos["buy_amount"]), dec(pos["sell_amount"])
    factor = dec(pos.get("price_factor"), Decimal(1)) or Decimal(1)
    pb = buy_a / buy_q if buy_q else ZERO      # money per unit
    ps = sell_a / sell_q if sell_q else ZERO
    matched = min(buy_q, sell_q)
    realized = matched * (ps - pb)
    if net == 0:
        unrealized: Decimal | None = ZERO
    elif ltp is None:
        unrealized = None
    else:
        open_cost = pb if net > 0 else ps
        unrealized = net * (dec(ltp) * factor - open_cost)
    total = None if unrealized is None else realized + unrealized
    return {"realized": _f(realized), "unrealized": _f(unrealized), "total": _f(total), "net_quantity": int(net)}


def documented_pnl(pos: dict, ltp: float) -> float:
    """The SDK docs' formula verbatim (used by tests to cross-check position_pnl)."""
    factor = dec(pos.get("price_factor"), Decimal(1)) or Decimal(1)
    return float((dec(pos["sell_amount"]) - dec(pos["buy_amount"])) + dec(pos["quantity"]) * dec(ltp) * factor)


def normalize_holding(row: dict) -> dict:
    qty = dec(row.get("quantity"))
    return {
        "trading_symbol": row.get("displaySymbol") or row.get("symbol"),
        "exchange_segment": row.get("exchangeSegment"),
        "instrument_token": str(row["instrumentToken"]) if row.get("instrumentToken") not in (None, "") else None,
        "quantity": int(qty),
        "average_price": _f(dec(row.get("averagePrice"), None)),
        "closing_price": _f(dec(row.get("closingPrice"), None)),
        "market_value": _f(dec(row.get("mktValue"), None)),
        "raw": row,
    }


_RLS = ("CashRlsMtomPrsnt", "FoRlsMtomPrsnt", "ComRlsMtomPrsnt", "CurRlsMtomPrsnt")
_UNRLS = ("CashUnRlsMtomPrsnt", "FoUnRlsMtomPrsnt", "ComUnRlsMtomPrsnt", "CurUnRlsMtomPrsnt")


def parse_limits(payload: dict) -> dict:
    """limits() returns ONE flat dict (not a list). `Net` = available cash/margin."""
    if not isinstance(payload, dict):
        return {"available_margin": None, "used_margin": None, "realized_mtom": None, "unrealized_mtom": None}
    return {
        "available_margin": _f(dec(payload.get("Net"), None)),
        "used_margin": _f(dec(payload.get("MarginUsed"), None)),
        "realized_mtom": _f(sum((dec(payload.get(k)) for k in _RLS), ZERO)),
        "unrealized_mtom": _f(sum((dec(payload.get(k)) for k in _UNRLS), ZERO)),
    }


def aggregate(positions: list[dict], ltp_by_key: dict[tuple, float]) -> dict:
    """Totals across positions. Keys are (exchange_segment, instrument_token).
    `complete` is False when any open position has no LTP (total then excludes it)."""
    realized = ZERO
    unrealized = ZERO
    complete = True
    rows = []
    for p in positions:
        ltp = ltp_by_key.get((p.get("exchange_segment"), p.get("instrument_token")))
        r = position_pnl(p, ltp)
        realized += dec(r["realized"])
        if r["unrealized"] is None:
            complete = False
        else:
            unrealized += dec(r["unrealized"])
        rows.append({**{k: p.get(k) for k in ("trading_symbol", "exchange_segment", "product", "instrument_token")}, "ltp": ltp, **r})
    return {"realized": _f(realized), "unrealized": _f(unrealized), "total": _f(realized + unrealized),
            "complete": complete, "positions": rows}


