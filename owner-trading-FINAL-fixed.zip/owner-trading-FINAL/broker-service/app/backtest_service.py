from __future__ import annotations
import hashlib, json, datetime as dt
from . import db,strategy_engine

ENGINE_VERSION="OT-BACKTEST-11.0"

def _hash_rows(rows):
    canonical=json.dumps(rows,sort_keys=True,separators=(",",":"),default=str).encode()
    return hashlib.sha256(canonical).hexdigest()

async def run(payload):
    sid=int(payload.get('strategy_id') or 0); requested_version_id=int(payload.get('strategy_version_id') or 0); definition=payload.get('definition')
    if not definition and sid:
        st=db.get_strategy(sid)
        if st and st['versions']:
            chosen=next((v for v in st['versions'] if int(v['id'])==requested_version_id), None) if requested_version_id else None
            if requested_version_id and not chosen: return 400,{'error':'strategy_version_id does not belong to strategy_id'}
            definition=(chosen or st['versions'][0])['definition']
    if not isinstance(definition,dict): return 400,{'error':'strategy_id or definition is required'}
    strategy_version_id=None
    if sid:
        st=db.get_strategy(sid)
        if st and st['versions']:
            chosen=next((v for v in st['versions'] if int(v['id'])==requested_version_id), None) if requested_version_id else None
            if requested_version_id and not chosen: return 400,{'error':'strategy_version_id does not belong to strategy_id'}
            strategy_version_id=(chosen or st['versions'][0])['id']
    errors=strategy_engine.validate_strategy(definition)
    if errors:return 422,{'error':'Invalid strategy definition','validation_errors':errors}
    seg=str(payload.get('exchange_segment') or 'nse_cm'); token=str(payload.get('instrument_token') or ''); symbol=str(payload.get('trading_symbol') or token)
    timeframe=str(payload.get('timeframe') or definition.get('timeframe') or '5m')
    if timeframe not in strategy_engine.TIMEFRAMES:return 400,{"error":"Unsupported backtest timeframe."}
    try: slippage=float(payload.get('slippage') or 0); fees=float(payload.get('fees') or 0)
    except (TypeError,ValueError):return 400,{"error":"slippage and fees must be numeric."}
    if slippage<0 or slippage>0.10:return 400,{"error":"slippage must be between 0 and 0.10 (10%)."}
    if fees<0:return 400,{"error":"fees cannot be negative."}
    candles=db.recent_candles(seg,token,timeframe,int(payload.get('limit') or 2000))
    frm=str(payload.get('from_date') or '')[:10]; to=str(payload.get('to_date') or '')[:10]
    if frm or to:
        filtered=[]
        for c in candles:
            ts=str(c.get('candle_at',''))[:10]
            if frm and ts < frm: continue
            if to and ts > to: continue
            filtered.append(c)
        candles=filtered
    if len(candles)<20 and token:
        from .broker_client import broker_client
        import asyncio,datetime as dt
        frm=str(payload.get('from_date') or (dt.date.today()-dt.timedelta(days=60)).isoformat());to=str(payload.get('to_date') or dt.date.today().isoformat())
        interval={'1m':'1min','3m':'3min','5m':'5min','15m':'15min','30m':'30min','1h':'60min','1d':'D'}.get(timeframe,timeframe)
        out=await asyncio.get_running_loop().run_in_executor(None,lambda:broker_client.read('historical_data',neosymbol=f'{seg}|{token}',interval=interval,from_date=frm,to_date=to))
        if out.ok:
            rows=out.data.get('data',out.data) if isinstance(out.data,dict) else out.data
            if isinstance(rows,list):
                for r in rows:
                    try:
                        ca=str(r.get('datetime') or r.get('timestamp') or r.get('date') or r.get('time'));candles.append({'candle_at':ca,'open':float(r.get('open')),'high':float(r.get('high')),'low':float(r.get('low')),'close':float(r.get('close')),'volume':float(r.get('volume') or 0)})
                    except (TypeError,ValueError):pass
    if frm or to:
        candles=[c for c in candles if (not frm or str(c.get('candle_at',''))[:10]>=frm) and (not to or str(c.get('candle_at',''))[:10]<=to)]
    if len(candles)<20:return 400,{'error':'Not enough historical candles in the requested date range. Kotak returned insufficient historical data for this instrument/timeframe.'}
    # Historical rows must have parseable timestamps; the backtest never invents a session date.
    for c in candles:
        try:
            dt.datetime.fromisoformat(str(c['candle_at']).replace('Z','+00:00'))
        except (TypeError,ValueError):
            return 400,{"error":f"Invalid historical candle timestamp: {c.get('candle_at')}"}
    request=dict(payload);request.pop('definition',None)
    request['engine_version']=ENGINE_VERSION
    dataset_hash=_hash_rows(candles)
    parameters_hash=_hash_rows({"definition":definition,"symbol":symbol,"quantity":int(payload.get('quantity') or 1),"slippage":slippage,"fees":fees,"timeframe":timeframe})
    bt_id=db.create_backtest(strategy_version_id,request)
    with db._connection() as conn:
        conn.execute("UPDATE backtests SET engine_version=?,dataset_hash=?,parameters_hash=? WHERE id=?",(ENGINE_VERSION,dataset_hash,parameters_hash,bt_id))
    try:
        result=strategy_engine.run_backtest(candles,definition,symbol,int(payload.get('quantity') or 1),slippage,fees)
        db.complete_backtest(bt_id,result)
        result['backtest_id']=bt_id
        return 200,{'result':result}
    except Exception as exc:
        db.complete_backtest(bt_id,{},str(exc));raise
