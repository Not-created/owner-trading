"""Phase 13 final production safety audit. No broker writes are performed."""
from __future__ import annotations
import os, re, subprocess
from pathlib import Path
from . import db, sdk_conformance
from .broker_client import sdk_ready
from .config import config
from .state import BrokerState, current_state

ROOT=Path(__file__).resolve().parents[2]

def _check(id,ok,detail,blocking=True): return {"id":id,"ok":bool(ok),"blocking":blocking,"detail":detail}

def _static_scan():
    """Scan executable tokens only; comments/docstrings must not fail the gate."""
    import io, tokenize
    bad=[]
    forbidden={"PAPER","SIMULATOR","SIMULATED","NotImplemented"}
    for base in (ROOT/'broker-service/app',ROOT/'backend/src',ROOT/'frontend/src'):
        for p in base.rglob('*'):
            if p.suffix not in ('.py','.js','.jsx','.sql'): continue
            try:
                text=p.read_text(errors='ignore')
                if p.suffix=='.py':
                    toks=tokenize.generate_tokens(io.StringIO(text).readline)
                    for tok in toks:
                        if tok.type==tokenize.NAME and tok.string.upper() in {x.upper() for x in forbidden}:
                            bad.append(f'{p.relative_to(ROOT)}:{tok.string}')
                else:
                    # Strip comments/quoted strings conservatively before scanning.
                    clean=re.sub(r'/\*.*?\*/|//[^\n]*|[#][^\n]*|[\"\'](?:\\.|[^\\])*?[\"\']',' ',text,flags=re.S)
                    for pat in (r'\bPAPER\b',r'\bSIMULATOR\b',r'\bSIMULATED\b',r'\bNotImplemented\b'):
                        if re.search(pat,clean,re.I): bad.append(f'{p.relative_to(ROOT)}:{pat}')
            except Exception: continue
    return bad

async def run():
    rid=db.create_final_audit(); checks=[]
    try:
        ok,why=sdk_ready(); checks.append(_check('sdk',ok,why or 'kotakneoapi 3.0.7 ready'))
        conf=sdk_conformance.check_runtime() if ok else None; checks.append(_check('sdk_signatures',bool(conf and conf.ok),conf.summary() if conf else 'SDK unavailable'))
        vend=sdk_conformance.check_vendor_integrity(); checks.append(_check('sdk_vendor_integrity',vend.ok,'; '.join(vend.errors) or 'vendored SDK matches manifest'))
        checks.append(_check('live_mode',config.trading_mode=='LIVE',f'trading_mode={config.trading_mode}'))
        checks.append(_check('internal_token',bool(os.environ.get('BROKER_SERVICE_TOKEN')),'BROKER_SERVICE_TOKEN is set'))
        checks.append(_check('broker_connected',current_state.state==BrokerState.CONNECTED,f'state={current_state.state.value}'))
        checks.append(_check('emergency_stop_clear',not db.is_emergency_stop_active(),'emergency stop clear'))
        checks.append(_check('live_armed',db.is_live_armed(),'owner LIVE arm is enabled'))
        from .websocket_manager import websocket_manager
        ws=websocket_manager.status(); checks.append(_check('feeds_healthy',bool(ws['market'].get('connected')) and bool(ws['orderFeed'].get('connected')),'market + order feeds connected'))
        rr=db.latest_reconciliation_run(); checks.append(_check('clean_reconciliation',bool(rr and rr['status']=='COMPLETE' and rr['sections_ok'] and not rr['discrepancy_count']),str(rr)))
        unknown=[o['internal_order_id'] for o in db.list_unresolved_live_orders() if o.get('outcome_unknown')]; checks.append(_check('no_unknown_orders',not unknown,f'unknown={unknown}'))
        checks.append(_check('no_pending_submissions',not [o for o in db.list_unresolved_live_orders() if o.get('status') in ('SUBMITTING','PENDING_RECONCILE')],'no unresolved submissions'))
        checks.append(_check('no_simulator_artifacts',not _static_scan(), 'static scan clean'))
        db.complete_final_audit(rid,checks)
        return 200,{'status':'PASS' if all(c['ok'] for c in checks if c['blocking']) else 'FAIL','run_id':rid,'checks':checks,'latest':db.latest_final_audit()}
    except Exception as exc:
        checks.append(_check('final_audit_exception',False,f'{type(exc).__name__}: {exc}'))
        db.complete_final_audit(rid,checks)
        return 500,{'status':'FAIL','run_id':rid,'checks':checks}
