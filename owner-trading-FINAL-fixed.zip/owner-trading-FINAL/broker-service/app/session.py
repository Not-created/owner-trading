"""Session lifecycle architecture.

Kotak's TOTP flow (per the audited SDK: totp_login -> totp_validate)
produces edit_token/edit_sid that are valid for a limited time. This module
defines how the broker service is meant to track that expiry and react --
implemented now, invoked only once real authentication exists (next phase).
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from .state import BrokerState, current_state

# Kotak does not publish a fixed session TTL in the audited SDK/docs; this
# is a conservative operating assumption or the next phase to confirm
# against real observed behavior (e.g. via a 401/session-expired response),
# not a value taken from the SDK itself.
ASSUMED_SESSION_TTL_SECONDS = 8 * 60 * 60  # 8 hours


@dataclass
class SessionInfo:
    established_at: float | None = None
    data_center: str | None = None

    def is_expired(self, now: float | None = None) -> bool:
        if self.established_at is None:
            return True
        now = now if now is not None else time.time()
        return (now - self.established_at) > ASSUMED_SESSION_TTL_SECONDS

    def seconds_remaining(self, now: float | None = None) -> float:
        if self.established_at is None:
            return 0.0
        now = now if now is not None else time.time()
        return max(0.0, ASSUMED_SESSION_TTL_SECONDS - (now - self.established_at))


# Process-local only -- never persisted (see secure_store.py for the
# reasoning: session artifacts are intentionally not written to disk).
current_session = SessionInfo()


def mark_session_established(data_center: str | None) -> None:
    current_session.established_at = time.time()
    current_session.data_center = data_center
    current_state.transition(BrokerState.CONNECTED)

    from . import db as _db
    import datetime

    expires_at = datetime.datetime.fromtimestamp(
        current_session.established_at + ASSUMED_SESSION_TTL_SECONDS, tz=datetime.timezone.utc
    ).isoformat()
    try:
        _db.record_session_started(data_center=data_center, expires_at_iso=expires_at)
    except Exception:  # noqa: BLE001 -- audit-trail write must not block a real successful connect
        pass


def mark_session_expired() -> None:
    current_session.established_at = None
    current_state.transition(BrokerState.SESSION_EXPIRED, "Session TTL exceeded or broker rejected the session.")

    from . import db as _db

    try:
        _db.record_session_ended()
    except Exception:  # noqa: BLE001
        pass


def check_and_handle_expiry() -> bool:
    """Call periodically (next phase: from a scheduled task in main.py).
    Returns True if the session was found expired and the state machine was
    transitioned; False if the session is still considered valid.
    """
    if current_state.state == BrokerState.CONNECTED and current_session.is_expired():
        mark_session_expired()
        return True
    return False
