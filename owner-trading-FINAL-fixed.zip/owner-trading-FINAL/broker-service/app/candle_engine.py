from __future__ import annotations

import datetime as dt
from zoneinfo import ZoneInfo

from . import db

IST = ZoneInfo("Asia/Kolkata")
TIMEFRAMES = {"1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "1d": 1440}


class CandleEngine:
    """Builds completed bars from SFeed ticks.

    SFeed volume is cumulative day volume, so persisted candle volume is the
    delta from the previous tick/day baseline, never the cumulative value.
    Strategy evaluation is emitted only when a bar is completed.
    """
    def __init__(self):
        self._state = {}
        self._last_cum_volume: dict[tuple[str, str], int] = {}

    @staticmethod
    def _bucket(now: dt.datetime, minutes: int) -> dt.datetime:
        if minutes >= 1440:
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        total = now.hour * 60 + now.minute
        bucket_minute = (total // minutes) * minutes
        return now.replace(hour=bucket_minute // 60, minute=bucket_minute % 60, second=0, microsecond=0)

    def on_tick(self, *, exchange_segment, instrument_token, trading_symbol, price, volume=None, timestamp=None):
        now = timestamp.astimezone(IST) if timestamp else dt.datetime.now(IST)
        price = float(price)
        key_base = (exchange_segment or "", str(instrument_token))
        cumulative = int(volume or 0)
        previous_cumulative = self._last_cum_volume.get(key_base)
        if previous_cumulative is None or cumulative < previous_cumulative:
            delta_volume = 0 if previous_cumulative is None else cumulative
        else:
            delta_volume = cumulative - previous_cumulative
        self._last_cum_volume[key_base] = cumulative

        completed = []
        for tf, minutes in TIMEFRAMES.items():
            bucket = self._bucket(now, minutes)
            key = (*key_base, tf)
            st = self._state.get(key)
            if not st or st["at"] != bucket:
                if st:
                    db.upsert_candle(exchange_segment=exchange_segment, instrument_token=instrument_token,
                                     trading_symbol=trading_symbol, timeframe=tf,
                                     candle_at=st["at"].strftime("%Y-%m-%d %H:%M:%S"), open_=st["open"],
                                     high=st["high"], low=st["low"], close=st["close"], volume=st["volume"])
                    completed.append(tf)
                st = {"at": bucket, "open": price, "high": price, "low": price,
                      "close": price, "volume": int(delta_volume)}
                self._state[key] = st
            else:
                st["high"] = max(st["high"], price)
                st["low"] = min(st["low"], price)
                st["close"] = price
                st["volume"] += int(delta_volume)

        # Automated strategy evaluation is emitted only for completed bars.
        # Protective exits are separate and receive the raw tick path from the
        # WebSocket supervisor, so a stop/target never waits for a 5m close.
        if completed:
            try:
                import asyncio
                from .algo_engine import algo_engine
                loop = asyncio.get_running_loop()
                for tf in completed:
                    loop.create_task(algo_engine.on_tick(
                        exchange_segment=exchange_segment,
                        instrument_token=str(instrument_token),
                        trading_symbol=trading_symbol,
                        timeframe=tf,
                    ))
            except RuntimeError:
                pass


candle_engine = CandleEngine()
