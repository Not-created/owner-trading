"""sdk_adapter -- the ONLY module in this service that imports the official
Kotak Neo SDK (`neo_api_client`, distribution `kotakneoapi`).

Everything here is written against the SDK source shipped with this project
(vendor/kotakneoapi, v3.0.7, byte-identical to the official ZIP -- see
vendor/VENDOR_MANIFEST.sha256). Exact call signatures used below
(NeoAPI.__init__, totp_login, totp_validate, place_order, modify_order,
cancel_order, order_report, order_history, trade_report, positions,
holdings, limits, margin_required, quotes, scrip_master, search_scrip,
create_websocket, create_order_feed, logout, whatsmyip) are re-checked
against the vendored source by tests/test_sdk_conformance.py using `ast`,
so a signature drift fails the test suite instead of failing a live order.

RESPONSE CONTRACT (read from the SDK source, not guessed):
  * NeoAPI trading methods NEVER raise for API problems. They return a dict.
    Error shapes seen in the source: {"Error": <exception object or str>},
    {"error": <ApiException | list of {"code","message"}>},
    {"Error Message": "Complete the 2fa process ..."} (no session), and
    backend rejections such as {"stCode": 1021, "errMsg": ..., "stat": ...,
    "status_code": 400}. HTTP >= 400 does NOT raise (raise_on_error is off),
    so a 4xx/5xx body is returned as parsed JSON.
  * Success bodies carry stat "Ok"/"ok" and stCode 200; order placement /
    modify / cancel carry the order id in `nOrdNo`.
  * Transport failures (timeout / connection error) surface as
    {"Error": ApiException(status=0, ...)} -- for order-changing calls the
    request MAY have reached the broker, so the outcome is UNKNOWN, never
    "rejected". Callers must reconcile by client tag (`GuiOrdId`).
This module turns those shapes into one JSON-safe `Outcome`.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any, Callable

logger = logging.getLogger("owner_trading.sdk_adapter")

REQUIRED_SDK_VERSION = "3.0.7"

# The SDK writes a rotating log file relative to the CWD by default and, at
# INFO, logs call parameters. Pin conservative defaults BEFORE importing it
# (the SDK reads these env vars at import time). Operators may override.
os.environ.setdefault("NEO_LOG_LEVEL", "WARNING")
os.environ.setdefault("NEO_LOG_FILE_LEVEL", "WARNING")

SDK_IMPORT_ERROR: str | None = None
SDK_VERSION: str | None = None
try:  # pragma: no cover - exercised only where the real SDK + deps are installed
    import neo_api_client as _sdk_pkg
    from neo_api_client import NeoAPI  # noqa: F401
    SDK_VERSION = getattr(_sdk_pkg, "__version__", None)
    SDK_AVAILABLE = True
except Exception as _exc:  # ImportError, or a missing transitive dependency
    NeoAPI = None  # type: ignore[assignment]
    SDK_AVAILABLE = False
    SDK_IMPORT_ERROR = f"{type(_exc).__name__}: {_exc}"

# ------------------------------------------------------------------------ #
# Exact enums accepted by NeoAPI.place_order / modify_order / margin_required
# (neo_api_client/settings.py + req_data_validation.py, v3.0.7).
# Kept identical by tests/test_sdk_conformance.py.
# ------------------------------------------------------------------------ #
EXCHANGE_SEGMENTS = ("nse_cm", "bse_cm", "nse_fo", "bse_fo", "mcx_fo")
# expiries()/option_chain() only accept the three derivative segments (docs/functions/market_data).
DERIVATIVE_SEGMENTS = ("nse_fo", "bse_fo", "mcx_fo")
INSTRUMENT_TYPES = ("option", "fut")
HISTORICAL_INTERVALS = ("1min", "3min", "5min", "10min", "15min", "30min", "60min", "D", "W")
# historical_data() is documented as unsupported for these segments (backend-enforced, not SDK-validated).
HISTORICAL_UNSUPPORTED_SEGMENTS = ("mcx_fo", "nse_com")
PRODUCTS = ("CNC", "NRML", "MIS", "MTF")
ORDER_TYPES = ("L", "MKT", "SL", "SL-M")
TRANSACTION_TYPES = ("B", "S")
VALIDITY_BY_SEGMENT = {
    "nse_cm": ("DAY", "IOC"),
    "bse_cm": ("DAY", "IOC"),
    "nse_fo": ("DAY", "IOC"),
    "bse_fo": ("DAY", "IOC"),
    "mcx_fo": ("DAY",),
}
PRICE_REQUIRED_ORDER_TYPES = ("L", "SL")
TRIGGER_REQUIRED_ORDER_TYPES = ("SL", "SL-M")


# ------------------------------------------------------------------------ #
# Outcome
# ------------------------------------------------------------------------ #
OK = "OK"
REJECTED = "REJECTED"        # definitive: never sent (validation) or broker said no
AUTH = "AUTH"                # no session / session invalid -> re-login needed
UNKNOWN = "UNKNOWN"          # transport failure or unrecognised body: may or may not have happened


@dataclass
class Outcome:
    kind: str
    message: str = ""
    code: str | None = None
    order_id: str | None = None
    data: Any = None
    raw: Any = None
    extra: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.kind == OK

    def as_dict(self) -> dict:
        return {
            "kind": self.kind, "message": self.message, "code": self.code,
            "order_id": self.order_id, "data": self.data,
        }


def jsonable(obj: Any, _depth: int = 0) -> Any:
    """Make an SDK response JSON-safe. SDK error dicts embed live exception
    objects ({"Error": ApiException(...)}); those become their str()."""
    if _depth > 8:
        return str(obj)
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {str(k): jsonable(v, _depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [jsonable(v, _depth + 1) for v in obj]
    if isinstance(obj, BaseException):
        return f"{type(obj).__name__}: {obj}"
    if hasattr(obj, "model_dump"):
        try:
            return jsonable(obj.model_dump(), _depth + 1)
        except Exception:  # noqa: BLE001
            return str(obj)
    return str(obj)


_SESSION_MARKERS = ("invalid session", "session expired", "session has expired", "re-login", "relogin", "invalid token", "token expired")
_NOT_AUTH_MARKER = "2fa process"


def _text_of(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts = []
        for item in value:
            if isinstance(item, dict):
                parts.append(str(item.get("message") or item.get("errMsg") or item))
            else:
                parts.append(str(item))
        return "; ".join(parts)
    return str(value)


def _status_of_exception(exc: Any) -> int | None:
    st = getattr(exc, "status", None)
    return st if isinstance(st, int) else None


def _int_or_none(v: Any) -> int | None:
    try:
        return int(str(v))
    except (TypeError, ValueError):
        return None


def classify(resp: Any, *, expect_order_id: bool = False, state_changing: bool = False) -> Outcome:
    """Classify one raw SDK return value. `state_changing` is True for
    place/modify/cancel, where an unrecognised or transport-level failure is
    UNKNOWN (must be reconciled) rather than a clean rejection."""
    safe = jsonable(resp)

    if not isinstance(resp, dict):
        if isinstance(resp, list):
            return Outcome(OK, data=safe, raw=safe)
        if isinstance(resp, str) and resp.startswith("http"):  # scrip_master(segment) returns a file URL
            return Outcome(OK, data=resp, raw=safe)
        return Outcome(UNKNOWN if state_changing else REJECTED, message="Unrecognised broker response type.", raw=safe)

    # 1. Not authenticated (SDK guard before any network call) -> definitive, nothing was sent.
    em = resp.get("Error Message")
    if isinstance(em, str) and _NOT_AUTH_MARKER in em.lower():
        return Outcome(AUTH, message="No trade session: complete login (totp_login + totp_validate) first.", raw=safe)

    # 2. SDK / transport / validation errors carried in an "Error" or "error" key.
    for key in ("Error", "error"):
        if key in resp and resp[key] not in (None, "", [], {}):
            err = resp[key]
            text = _text_of(err) or "Broker call failed."
            low = text.lower()
            if any(m in low for m in _SESSION_MARKERS):
                return Outcome(AUTH, message=text[:300], raw=safe)
            if isinstance(err, BaseException):
                name = type(err).__name__
                st = _status_of_exception(err)
                if name in ("ApiValueError", "ApiTypeError", "ApiKeyError", "ApiAttributeError", "ValueError", "TypeError"):
                    return Outcome(REJECTED, message=text[:300], code="VALIDATION", raw=safe)
                if st == 403:
                    return Outcome(AUTH, message=text[:300], code="403", raw=safe)
                if st is not None and st >= 400:
                    return Outcome(REJECTED, message=text[:300], code=str(st), raw=safe)
                # status 0 / None: timeout, connect error, or unknown failure inside the SDK
                return Outcome(UNKNOWN if state_changing else REJECTED, message=text[:300], code="TRANSPORT", raw=safe)
            # str / list errors: client-side validation text or "[{code,message}]" shapes
            if state_changing and ("exception has been occurred" in low or "connecting to api" in low):
                return Outcome(UNKNOWN, message=text[:300], code="TRANSPORT", raw=safe)
            return Outcome(REJECTED, message=text[:300], code=_first_code(err), raw=safe)

    # 3. Backend rejection bodies (HTTP >= 400 comes back as parsed JSON).
    #    Two documented shapes exist: the order/portfolio-API shape
    #    ({"stCode":..,"errMsg":..,"stat":..,"status_code":..}) and the
    #    auth-API shape used by totp_login/totp_validate on rejection
    #    ({"status":"error","message":..,"errorCode":..}). Both are
    #    real, source-grounded Kotak response bodies -- missing either
    #    one meant a real rejection fell through to the "success, no
    #    data" branch below and lost its message (see totp_login/
    #    totp_validate handling in KotakSdk.login()).
    st_code = resp.get("stCode")
    http_status = _int_or_none(resp.get("status_code"))
    err_msg = resp.get("errMsg") or resp.get("emsg") or resp.get("message")
    st_code_i = _int_or_none(st_code)
    stat = str(resp.get("stat", "")).strip().lower()
    status_field = str(resp.get("status", "")).strip().lower()
    error_code = resp.get("errorCode")
    error_code_i = _int_or_none(error_code)
    failed = (
        (st_code_i is not None and st_code_i != 200)
        or (http_status is not None and http_status >= 400)
        or bool(resp.get("errMsg"))
        or stat in ("not_ok", "notok")
        or status_field in ("error", "failed", "failure")
        or (error_code_i is not None and error_code_i >= 400)
    )
    if failed:
        text = _text_of(err_msg) or _text_of(resp.get("stat")) or "Broker rejected the request."
        low = text.lower()
        effective_code = st_code if st_code is not None else (http_status if http_status is not None else error_code)
        if st_code_i == 403 or http_status == 403 or error_code_i == 403 or any(m in low for m in _SESSION_MARKERS):
            return Outcome(AUTH, message=text[:300], code="403", raw=safe)
        if error_code_i == 429 or http_status == 429 or "too many requests" in low or "rate limit" in low:
            return Outcome(REJECTED, message=text[:300], code="429", raw=safe)
        return Outcome(REJECTED, message=text[:300], code=str(effective_code) if effective_code is not None else None, raw=safe)

    # 4. Success shapes.
    if expect_order_id:
        oid = resp.get("nOrdNo")
        if oid:
            return Outcome(OK, order_id=str(oid), data=safe, raw=safe)
        # A 2xx body with no order number: we cannot claim success OR failure.
        return Outcome(UNKNOWN, message="Broker response carried no order number (nOrdNo).", raw=safe)

    return Outcome(OK, data=safe, raw=safe)


def _auth_stage_code(outcome: "Outcome", stage: str) -> str:
    """Maps a classify() outcome for one login sub-step to the exact
    authentication stage that failed, so the Settings UI and tests can
    distinguish a wrong TOTP from a wrong MPIN from a broker-side/
    transport problem instead of one generic "auth failed".

    Checked via classify()'s own `code` marker first, not just `kind`:
    totp_login/totp_validate are not "state_changing" calls, so a
    transport failure (status 0 -- timeout/connect error) classifies as
    REJECTED there, not UNKNOWN (see classify()'s docstring) -- `code`
    is what actually says "we don't know what happened", so it must be
    checked ahead of, and independently of, `kind`.
    """
    if outcome.code == "429":
        return "RATE_LIMITED"
    if outcome.code == "TRANSPORT" or outcome.kind == UNKNOWN:
        return "TRANSPORT_ERROR"
    if stage == "totp_login":
        return "TOTP_LOGIN_FAILED"
    if stage == "totp_validate":
        return "MPIN_VALIDATION_FAILED"
    return "BROKER_REJECTED"


def _first_code(err: Any) -> str | None:
    if isinstance(err, list) and err and isinstance(err[0], dict):
        c = err[0].get("code")
        return str(c) if c is not None else None
    return None


def rows_of(outcome: Outcome) -> list[dict]:
    """Extract the list of row dicts from an OK outcome's `data`. Orders,
    trades, positions and holdings responses are {"data": [ {...}, ... ]};
    order_history is {"data": {"stat":..,"data":[...]}} (per the SDK docs)."""
    d = outcome.data
    if isinstance(d, list):
        return [r for r in d if isinstance(r, dict)]
    if isinstance(d, dict):
        inner = d.get("data")
        if isinstance(inner, list):
            return [r for r in inner if isinstance(r, dict)]
        if isinstance(inner, dict) and isinstance(inner.get("data"), list):
            return [r for r in inner["data"] if isinstance(r, dict)]
    return []


# ------------------------------------------------------------------------ #
# Order request -> exact SDK kwargs
# ------------------------------------------------------------------------ #
class OrderRequestError(ValueError):
    """The request violates the SDK's own validation rules; raised BEFORE any
    network call so it is always a clean, definitive rejection."""


def fmt_price(value: Any) -> str:
    """Decimal-exact price string, at least 2 decimals ("9.39", "100.00").
    Avoids float artefacts like 0.1+0.2. Never scientific notation."""
    try:
        d = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise OrderRequestError(f"Invalid price {value!r}.")
    if not d.is_finite() or d < 0:
        raise OrderRequestError("Price must be a finite, non-negative number.")
    d = d.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)   # kills float noise (0.1+0.2); NSE/BSE tick is <= 4 dp
    s = format(d.normalize(), "f")
    if "." not in s:
        s += ".00"
    elif len(s.split(".")[1]) < 2:
        s += "0" * (2 - len(s.split(".")[1]))
    return s


@dataclass
class OrderRequest:
    exchange_segment: str
    trading_symbol: str
    transaction_type: str
    order_type: str
    product: str
    quantity: int
    validity: str = "DAY"
    price: Any = None
    trigger_price: Any = None
    tag: str | None = None
    amo: str = "NO"
    disclosed_quantity: int = 0

    def validate(self) -> None:
        if self.exchange_segment not in EXCHANGE_SEGMENTS:
            raise OrderRequestError(f"exchange_segment must be one of {list(EXCHANGE_SEGMENTS)}.")
        if self.product not in PRODUCTS:
            raise OrderRequestError(f"product must be one of {list(PRODUCTS)}.")
        if self.order_type not in ORDER_TYPES:
            raise OrderRequestError(f"order_type must be one of {list(ORDER_TYPES)}.")
        if self.transaction_type not in TRANSACTION_TYPES:
            raise OrderRequestError("transaction_type must be 'B' or 'S'.")
        if self.validity not in VALIDITY_BY_SEGMENT[self.exchange_segment]:
            raise OrderRequestError(
                f"validity must be one of {list(VALIDITY_BY_SEGMENT[self.exchange_segment])} for {self.exchange_segment}."
            )
        if not str(self.trading_symbol or "").strip():
            raise OrderRequestError("trading_symbol is required (pTrdSymbol from the scrip master).")
        if not isinstance(self.quantity, int) or isinstance(self.quantity, bool) or self.quantity <= 0:
            raise OrderRequestError("quantity must be a positive integer.")
        if self.amo not in ("YES", "NO"):
            raise OrderRequestError("amo must be 'YES' or 'NO'.")
        if self.order_type in PRICE_REQUIRED_ORDER_TYPES and (self.price is None or Decimal(str(self.price)) <= 0):
            raise OrderRequestError(f"price must be > 0 for order_type={self.order_type}.")
        if self.order_type in TRIGGER_REQUIRED_ORDER_TYPES and (self.trigger_price is None or Decimal(str(self.trigger_price)) <= 0):
            raise OrderRequestError(f"trigger_price must be > 0 for order_type={self.order_type}.")
        if self.tag is not None and not str(self.tag).strip():
            raise OrderRequestError("tag must be non-blank when provided.")

    def to_sdk_kwargs(self) -> dict[str, str | None]:
        """The exact keyword arguments of NeoAPI.place_order (all strings)."""
        self.validate()
        price = fmt_price(self.price) if self.price is not None else "0"
        if self.order_type in ("MKT", "SL-M") and self.price is None:
            price = "0"
        trigger = fmt_price(self.trigger_price) if self.trigger_price is not None else "0"
        kwargs: dict[str, str | None] = {
            "exchange_segment": self.exchange_segment,
            "product": self.product,
            "price": price,
            "order_type": self.order_type,
            "quantity": str(int(self.quantity)),
            "validity": self.validity,
            "trading_symbol": self.trading_symbol.strip(),
            "transaction_type": self.transaction_type,
            "amo": self.amo,
            "disclosed_quantity": str(int(self.disclosed_quantity)),
            "trigger_price": trigger,
        }
        if self.tag:
            kwargs["tag"] = str(self.tag)
        return kwargs


# ------------------------------------------------------------------------ #
# The adapter
# ------------------------------------------------------------------------ #
class KotakSdk:
    """One authenticated NeoAPI session. All methods are SYNCHRONOUS (the SDK
    uses blocking httpx); callers run them in an executor."""

    def __init__(self, consumer_key: str, environment: str = "prod", *, neo_factory: Callable[..., Any] | None = None):
        factory = neo_factory or NeoAPI
        if factory is None:
            raise RuntimeError(f"Official SDK not importable: {SDK_IMPORT_ERROR}")
        # NeoAPI.__init__(consumer_key, environment, access_token, neo_fin_key, transport, limits, http2, timeout)
        self._neo = factory(consumer_key=consumer_key, environment=environment)

    # -- authentication ---------------------------------------------------
    def login(self, *, mobile_number: str, ucc: str, totp: str, mpin: str) -> Outcome:
        """totp_login(mobile_number, ucc, totp) then totp_validate(mpin).
        Returns OK only when a TRADE session (edit_token + edit_sid) exists.

        Every non-OK return carries a `code` naming the exact stage that
        failed (TOTP_LOGIN_FAILED / MPIN_VALIDATION_FAILED /
        SESSION_VERIFICATION_FAILED / TRANSPORT_ERROR / RATE_LIMITED /
        BROKER_REJECTED) so callers -- and the Settings UI -- can tell a
        rejected TOTP apart from a rejected MPIN apart from a broker-side
        session-verification problem, instead of one flat "auth failed".
        The underlying broker message (already sanitised by classify(),
        never a secret) is preserved in `message`.
        """
        r1 = self._neo.totp_login(mobile_number=mobile_number, ucc=ucc, totp=totp)
        o1 = classify(r1)
        data1 = r1.get("data") if isinstance(r1, dict) else None
        if not o1.ok or not isinstance(data1, dict):
            code1 = _auth_stage_code(o1, "totp_login")
            outer1 = UNKNOWN if code1 in ("TRANSPORT_ERROR", "RATE_LIMITED") else REJECTED
            return Outcome(
                outer1,
                message=f"Kotak rejected the TOTP login step: {o1.message or 'no data in response'}",
                code=code1,
            )
        r2 = self._neo.totp_validate(mpin=mpin)
        o2 = classify(r2)
        data2 = r2.get("data") if isinstance(r2, dict) else None
        if not o2.ok or not isinstance(data2, dict):
            code2 = _auth_stage_code(o2, "totp_validate")
            outer2 = UNKNOWN if code2 in ("TRANSPORT_ERROR", "RATE_LIMITED") else REJECTED
            return Outcome(
                outer2,
                message=f"Kotak rejected the MPIN validation step: {o2.message or 'no data in response'}",
                code=code2,
            )
        ktype = data2.get("kType")
        if ktype not in (None, "Trade"):
            return Outcome(REJECTED, message=f"totp_validate returned kType={ktype!r}, not a Trade session.",
                           code="SESSION_VERIFICATION_FAILED")
        if not (self.has_trade_session()):
            return Outcome(REJECTED, message="totp_validate reported success but no usable trade session was established.",
                           code="SESSION_VERIFICATION_FAILED")
        return Outcome(OK, data={"data_center": self.data_center(), "ucc": data2.get("ucc") or data1.get("ucc")})

    def has_trade_session(self) -> bool:
        cfg = getattr(self._neo, "configuration", None)
        return bool(getattr(cfg, "edit_token", None) and getattr(cfg, "edit_sid", None))

    def data_center(self) -> str | None:
        return getattr(getattr(self._neo, "configuration", None), "data_center", None)

    def session_summary(self) -> dict:
        cfg = getattr(self._neo, "configuration", None)
        return {
            "trade_session": self.has_trade_session(),
            "data_center": getattr(cfg, "data_center", None),
            "base_url_present": bool(getattr(cfg, "base_url", None)),
            "ucc": getattr(cfg, "ucc", None),
        }

    def logout(self) -> Outcome:
        # SDK 3.0.7 logout() only clears local tokens (no network call).
        return classify(self._neo.logout())

    # -- orders -----------------------------------------------------------
    def place_order(self, req: OrderRequest) -> Outcome:
        kwargs = req.to_sdk_kwargs()  # raises OrderRequestError -> never sent
        return classify(self._neo.place_order(**kwargs), expect_order_id=True, state_changing=True)

    def modify_order(self, *, order_id: str, order_type: str, quantity: int, validity: str,
                     price: Any = None, trigger_price: Any = None, amo: str = "NO", disclosed_quantity: int = 0) -> Outcome:
        if not str(order_id or "").strip():
            raise OrderRequestError("order_id is required.")
        if order_type not in ORDER_TYPES:
            raise OrderRequestError(f"order_type must be one of {list(ORDER_TYPES)}.")
        if validity not in ("DAY", "IOC"):  # modify_order has no segment; SDK checks DAY/IOC
            raise OrderRequestError("validity must be DAY or IOC for modify.")
        if not isinstance(quantity, int) or quantity <= 0:
            raise OrderRequestError("quantity must be a positive integer.")
        if order_type in PRICE_REQUIRED_ORDER_TYPES and (price is None or Decimal(str(price)) <= 0):
            raise OrderRequestError(f"price must be > 0 for order_type={order_type}.")
        if order_type in TRIGGER_REQUIRED_ORDER_TYPES and (trigger_price is None or Decimal(str(trigger_price)) <= 0):
            raise OrderRequestError(f"trigger_price must be > 0 for order_type={order_type}.")
        return classify(
            self._neo.modify_order(
                order_id=str(order_id),
                price=fmt_price(price) if price is not None else "0",
                order_type=order_type,
                quantity=str(int(quantity)),
                validity=validity,
                trigger_price=fmt_price(trigger_price) if trigger_price is not None else "0",
                disclosed_quantity=str(int(disclosed_quantity)),
                amo=amo,
            ),
            expect_order_id=True, state_changing=True,
        )

    def cancel_order(self, *, order_id: str, amo: str = "NO") -> Outcome:
        if not str(order_id or "").strip():
            raise OrderRequestError("order_id is required.")
        return classify(self._neo.cancel_order(order_id=str(order_id), amo=amo), expect_order_id=True, state_changing=True)

    # -- read-only order/portfolio data -----------------------------------
    def order_report(self, order_id: str | None = None) -> Outcome:
        return classify(self._neo.order_report(order_id=order_id) if order_id else self._neo.order_report())

    def order_history(self, order_id: str) -> Outcome:
        return classify(self._neo.order_history(order_id=str(order_id)))

    def trade_report(self) -> Outcome:
        return classify(self._neo.trade_report())

    def positions(self) -> Outcome:
        return classify(self._neo.positions())

    def holdings(self) -> Outcome:
        return classify(self._neo.holdings())

    def limits(self) -> Outcome:
        return classify(self._neo.limits())

    def margin_required(self, *, exchange_segment: str, price: Any, order_type: str, product: str,
                        quantity: int, instrument_token: str, transaction_type: str, trigger_price: Any = None) -> Outcome:
        return classify(self._neo.margin_required(
            exchange_segment=exchange_segment, price=fmt_price(price if price is not None else 0),
            order_type=order_type, product=product, quantity=str(int(quantity)),
            instrument_token=str(instrument_token), transaction_type=transaction_type,
            trigger_price=fmt_price(trigger_price) if trigger_price is not None else None,
        ))

    def whatsmyip(self) -> Outcome:
        return classify(self._neo.whatsmyip())

    # -- derivatives market data (expiries / option_chain / historical_data) --
    # These three accept only consumer_key per the official docs (no totp_validate
    # required), but this adapter still requires a live KotakSdk instance, which
    # broker_client only creates after a successful /connect -- consistent with
    # how quotes()/scrip_master() are already gated in this project.
    def expiries(self, *, exchange: str, underlying: str, instrument_type: str | None = None) -> Outcome:
        if exchange not in DERIVATIVE_SEGMENTS:
            raise OrderRequestError(f"exchange must be one of {list(DERIVATIVE_SEGMENTS)}.")
        if not str(underlying or "").strip():
            raise OrderRequestError("underlying is required.")
        if instrument_type is not None and instrument_type not in INSTRUMENT_TYPES:
            raise OrderRequestError(f"instrument_type must be one of {list(INSTRUMENT_TYPES)}.")
        return classify(self._neo.expiries(exchange=exchange, underlying=underlying.strip(), instrument_type=instrument_type))

    def option_chain(self, *, exchange: str, underlying: str, expiry: str | None = None,
                     instrument_type: str | None = None, count: int | None = None) -> Outcome:
        if exchange not in DERIVATIVE_SEGMENTS:
            raise OrderRequestError(f"exchange must be one of {list(DERIVATIVE_SEGMENTS)}.")
        if not str(underlying or "").strip():
            raise OrderRequestError("underlying is required.")
        if instrument_type is not None and instrument_type not in INSTRUMENT_TYPES:
            raise OrderRequestError(f"instrument_type must be one of {list(INSTRUMENT_TYPES)}.")
        if count is not None and (not isinstance(count, int) or isinstance(count, bool) or count <= 0):
            raise OrderRequestError("count must be a positive integer.")
        return classify(self._neo.option_chain(exchange=exchange, underlying=underlying.strip(), expiry=expiry,
                                               instrument_type=instrument_type, count=count))

    def historical_data(self, *, neosymbol: str, interval: str, from_date: str, to_date: str) -> Outcome:
        if not str(neosymbol or "").strip() or "|" not in str(neosymbol):
            raise OrderRequestError('neosymbol must be "{exchange_segment}|{instrument_token}", e.g. "nse_cm|1333".')
        seg = str(neosymbol).split("|", 1)[0]
        if seg in HISTORICAL_UNSUPPORTED_SEGMENTS:
            raise OrderRequestError(f"historical_data is not available for {seg}.")
        if interval not in HISTORICAL_INTERVALS:
            raise OrderRequestError(f"interval must be one of {list(HISTORICAL_INTERVALS)}.")
        if not str(from_date or "").strip() or not str(to_date or "").strip():
            raise OrderRequestError("from_date and to_date are required (YYYY-MM-DD).")
        return classify(self._neo.historical_data(neosymbol=str(neosymbol), interval=interval,
                                                  from_date=str(from_date), to_date=str(to_date)))

    # -- market data (REST) -----------------------------------------------
    def quotes(self, tokens: list[tuple[str, str]], quote_type: str | None = None) -> Outcome:
        """tokens: [(exchange_segment, instrument_token), ...] (max 50 per call, backend-enforced)."""
        if not tokens:
            raise OrderRequestError("At least one instrument is required.")
        payload = [{"instrument_token": str(t), "exchange_segment": s} for s, t in tokens]
        return classify(self._neo.quotes(instrument_tokens=payload, quote_type=quote_type))

    def scrip_master(self, exchange_segment: str | None = None) -> Outcome:
        return classify(self._neo.scrip_master(exchange_segment=exchange_segment))

    def search_scrip(self, *, exchange_segment: str, symbol: str = "", expiry: str | None = None,
                     option_type: str | None = None, strike_price: str | None = None) -> Outcome:
        return classify(self._neo.search_scrip(
            exchange_segment=exchange_segment, symbol=symbol, expiry=expiry,
            option_type=option_type, strike_price=strike_price,
        ))

    # -- websockets (async SFeed / order feed; legacy subscribe() is NOT used) --
    def create_market_feed(self, **kwargs):
        return self._neo.create_websocket(**kwargs)

    def create_order_feed(self, **kwargs):
        return self._neo.create_order_feed(**kwargs)


def make_ws_token(exchange_segment: str, instrument_token: str):
    """neo_api_client.websocket.feed.WsToken(exchange_segment, instrument_token)."""
    from neo_api_client.websocket.feed import WsToken  # local: keeps import cost/failure contained
    return WsToken(exchange_segment, str(instrument_token))
