"""Canonical strategy DSL, indicators, sizing and historical backtest engine.

The same validated definition is used by scanner/live/backtest.  This module
contains no broker calls and never creates live orders.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Any

TIMEFRAMES={"1m","3m","5m","15m","30m","1h","1d"}
OPS={">",">=","<","<=","==","!=","cross_above","cross_below"}
SIDES={"BUY","SELL"}
PRODUCTS={"CNC","NRML","MIS","MTF"}
INDICATOR_NAMES={"close","open","high","low","volume","sma","ema","rsi","atr","macd","macd_signal","macd_hist","adx","vwap","bb_mid","bb_upper","bb_lower","volume_sma"}


def _num(v):
    try:return float(v)
    except (TypeError,ValueError):return None

def sma(values,n):
    n=int(n); return sum(values[-n:])/n if len(values)>=n and n>0 else None

def ema(values,n):
    n=int(n)
    if len(values)<n or n<=0:return None
    k=2/(n+1); e=sum(values[:n])/n
    for v in values[n:]: e=v*k+e*(1-k)
    return e

def rsi(values,n=14):
    n=int(n)
    if len(values)<n+1:return None
    gains=[];losses=[]
    for a,b in zip(values[-n-1:-1],values[-n:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/n; al=sum(losses)/n
    if al==0:return 100.0
    return 100-(100/(1+ag/al))

def atr(candles,n=14):
    n=int(n)
    if len(candles)<n+1:return None
    trs=[]
    for prev,c in zip(candles[-n-1:-1],candles[-n:]):
        trs.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
    return sum(trs)/n

def macd(values,fast=12,slow=26,signal=9):
    if len(values)<slow+signal:return (None,None,None)
    series=[]
    for i in range(slow,len(values)+1):
        f=ema(values[:i],fast); s=ema(values[:i],slow)
        if f is not None and s is not None:series.append(f-s)
    line=series[-1] if series else None
    sig=ema(series,signal) if len(series)>=signal else None
    return line,sig,(line-sig if line is not None and sig is not None else None)

def adx(candles,n=14):
    n=int(n)
    if len(candles)<n*2+1:return None
    trs=[]; plus=[]; minus=[]
    for prev,c in zip(candles[-(n*2+1):-1],candles[-(n*2):]):
        up=float(c['high'])-float(prev['high']); down=float(prev['low'])-float(c['low'])
        trs.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
        plus.append(up if up>down and up>0 else 0); minus.append(down if down>up and down>0 else 0)
    dx=[]
    for i in range(n,len(trs)+1):
        tr=sum(trs[i-n:i]); p=sum(plus[i-n:i]); m=sum(minus[i-n:i])
        if tr==0:continue
        pi=100*p/tr; mi=100*m/tr; den=pi+mi
        dx.append(100*abs(pi-mi)/den if den else 0)
    return sum(dx[-n:])/n if len(dx)>=n else None

def vwap(candles):
    if not candles:return None
    pv=0.0; vol=0.0
    for c in candles:
        v=float(c.get('volume') or 0); typical=(float(c['high'])+float(c['low'])+float(c['close']))/3
        pv+=typical*v; vol+=v
    return pv/vol if vol else None

def indicators(candles):
    closes=[float(x['close']) for x in candles]; opens=[float(x['open']) for x in candles]
    highs=[float(x['high']) for x in candles]; lows=[float(x['low']) for x in candles]; vols=[float(x.get('volume') or 0) for x in candles]
    out={'close':closes[-1] if closes else None,'open':opens[-1] if opens else None,'high':highs[-1] if highs else None,'low':lows[-1] if lows else None,'volume':vols[-1] if vols else None}
    for n in (5,9,20,50,100,200):out[f'sma{n}']=sma(closes,n);out[f'ema{n}']=ema(closes,n)
    out['rsi14']=rsi(closes,14);out['atr14']=atr(candles,14)
    ml,ms,mh=macd(closes);out.update({'macd':ml,'macd_signal':ms,'macd_hist':mh})
    out['adx14']=adx(candles,14);out['vwap']=vwap(candles)
    if len(closes)>=20:
        m=sma(closes,20);sd=(sum((x-m)**2 for x in closes[-20:])/20)**0.5;out['bb_mid']=m;out['bb_upper']=m+2*sd;out['bb_lower']=m-2*sd
    out['volume_sma20']=sma(vols,20)
    # Common price-action fields for no-code conditions.
    if candles:
        c=candles[-1]; out['body']=abs(float(c['close'])-float(c['open']));out['range']=float(c['high'])-float(c['low']);out['bullish_candle']=1 if float(c['close'])>float(c['open']) else 0;out['bearish_candle']=1 if float(c['close'])<float(c['open']) else 0
    return out


def _value(name,vals,ind):
    if isinstance(name,(int,float)):return float(name)
    if name is None:return None
    key=str(name).lower().strip()
    n=_num(key)
    if n is not None:return n
    return vals.get(key,ind.get(key))


def eval_condition(cond,candles,ind=None):
    if not candles:return False,'no candle data'
    ind=ind or indicators(candles)
    c=candles[-1]; vals={'price':float(c['close']),'close':float(c['close']),'open':float(c['open']),'high':float(c['high']),'low':float(c['low']),'volume':float(c.get('volume') or 0),'previous_close':float(candles[-2]['close']) if len(candles)>1 else None}
    op=str(cond.get('operator') or cond.get('op') or '>').lower(); left=_value(cond.get('left'),vals,ind);right=_value(cond.get('right'),vals,ind)
    if left is None or right is None:return False,f'missing operand: {cond.get("left")} {op} {cond.get("right")}'
    if op in ('cross_above','cross_below') and len(candles)>=2:
        prev=indicators(candles[:-1]); pc=candles[-2]; pv={'price':float(pc['close']),'close':float(pc['close']),'open':float(pc['open']),'high':float(pc['high']),'low':float(pc['low']),'volume':float(pc.get('volume') or 0)}
        pl=_value(cond.get('left'),pv,prev);pr=_value(cond.get('right'),pv,prev)
        ok=(pl<=pr and left>right) if op=='cross_above' else (pl>=pr and left<right)
    elif op=='>':ok=left>right
    elif op=='>=':ok=left>=right
    elif op=='<':ok=left<right
    elif op=='<=':ok=left<=right
    elif op=='==':ok=left==right
    elif op=='!=':ok=left!=right
    else:return False,f'unsupported operator {op}'
    return bool(ok),f'{cond.get("left")} {op} {cond.get("right")} => {ok}'


def eval_group(group,candles):
    """Evaluate a canonical boolean group.

    A group may contain flat ``conditions`` plus nested ``groups``. Items are
    combined with the group's AND/OR operator. The flat form remains fully
    compatible with Phase 1-6 strategies.
    """
    group=group or {}; ind=indicators(candles); op=str(group.get('op','AND')).upper()
    if op not in ('AND','OR'):
        return False,{'reason':f'unsupported group operator {op}','indicators':ind}
    results=[]
    for c in group.get('conditions',[]) or []:
        ok,reason=eval_condition(c,candles,ind); results.append((ok,{'condition':c,'passed':ok,'reason':reason}))
    for child in group.get('groups',[]) or []:
        ok,detail=eval_group(child,candles); results.append((ok,{'group_result':detail,'passed':ok}))
    passed=(all(x[0] for x in results) if op=='AND' else any(x[0] for x in results)) if results else False
    return passed,{'group':op,'items':[x[1] for x in results],'indicators':ind}


def evaluate_entry(definition,candles):return eval_group(definition.get('entry',{}),candles)
def evaluate_exit(definition,candles):return eval_group(definition.get('exit',{}),candles)


OPERANDS={"open","high","low","close","volume"}|{f"sma{x}" for x in (5,9,20,50,100,200)}|{f"ema{x}" for x in (5,9,20,50,100,200)}|{"rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_mid","bb_upper","bb_lower","volume_sma20","body","range","bullish_candle","bearish_candle"}

def validate_strategy(definition:dict)->list[str]:
    errors=[]
    if not isinstance(definition,dict):return ['definition must be an object']
    if str(definition.get('timeframe','5m')) not in TIMEFRAMES:errors.append('timeframe is invalid')
    side=str(definition.get('side','BUY')).upper()
    if side not in SIDES:errors.append('side must be BUY or SELL')
    ex=definition.get('execution',{}) or {}; product=str(ex.get('product','MIS')).upper()
    if product not in PRODUCTS:errors.append(f'unsupported product: {product}')
    def check_group(group,path):
        if not isinstance(group,dict):errors.append(f'{path} group is required');return
        op=str(group.get('op','AND')).upper()
        if op not in ('AND','OR'):errors.append(f'{path}.op must be AND or OR')
        conditions=group.get('conditions',[])
        if conditions is not None and not isinstance(conditions,list):errors.append(f'{path}.conditions must be a list');conditions=[]
        for i,c in enumerate(conditions or []):
            if not isinstance(c,dict):errors.append(f'{path}.conditions[{i}] must be an object');continue
            if c.get('operator') not in OPS:errors.append(f'{path}.conditions[{i}].operator is invalid')
            if c.get('left') is None or c.get('right') is None:errors.append(f'{path}.conditions[{i}] needs left and right')
            for field in ('left','right'):
                val=c.get(field)
                if isinstance(val,str) and val.lower() in ('open','high','low','close','volume'):
                    pass
                elif isinstance(val,str) and val.lower() not in OPERANDS:
                    try: float(val)
                    except (TypeError,ValueError): errors.append(f'{path}.conditions[{i}].{field} is an unknown operand: {val}')
        groups=group.get('groups',[])
        if groups is not None and not isinstance(groups,list):errors.append(f'{path}.groups must be a list');groups=[]
        for i,g in enumerate(groups or []):check_group(g,f'{path}.groups[{i}]')
        if not (conditions or groups):errors.append(f'{path} must contain at least one condition/group')
    check_group(definition.get('entry'), 'entry')
    check_group(definition.get('exit'), 'exit')
    risk=definition.get('risk',{}) or {}
    if not isinstance(risk,dict):errors.append('risk must be an object');risk={}
    for k in ('stop_loss','target','stop_loss_pct','target_pct','trailing_stop_pct','stop_atr_multiple','partial_exit_pct'):
        if k in risk and risk[k] is not None and _num(risk[k]) is None:errors.append(f'risk.{k} must be numeric')
    if risk.get('partial_exit_pct') is not None and not (0<float(risk['partial_exit_pct'])<=100):errors.append('risk.partial_exit_pct must be between 0 and 100')
    for k in ('time_exit_bars','max_positions'):
        if definition.get(k) is not None:
            try:
                if int(definition[k])<1:errors.append(f'{k} must be >= 1')
            except (TypeError,ValueError):errors.append(f'{k} must be an integer')
    sizing=definition.get('position_sizing',{}) or {}
    if not isinstance(sizing,dict):errors.append('position_sizing must be an object');sizing={}
    if sizing.get('quantity') is not None and (not _num(sizing['quantity']) or float(sizing['quantity'])<1):errors.append('position_sizing.quantity must be >= 1')
    if sizing.get('capital_pct') is not None and not (0<float(sizing['capital_pct'])<=100):errors.append('capital_pct must be between 0 and 100')
    if sizing.get('risk_per_trade') is not None and (not _num(sizing['risk_per_trade']) or float(sizing['risk_per_trade'])<=0):errors.append('risk_per_trade must be > 0')
    universe=definition.get('universe',{}) or {}
    if universe and not isinstance(universe,dict):errors.append('universe must be an object')
    if isinstance(universe,dict) and universe.get('instrument_tokens') is not None:
        toks=universe.get('instrument_tokens')
        if not isinstance(toks,list) or not toks:errors.append('universe.instrument_tokens must be a non-empty list')
        elif len(toks)>3000:errors.append('universe.instrument_tokens cannot exceed the SFeed limit of 3000')
    return errors


def size_position(definition,price,available_funds=None,atr_value=None,lot_size=1,max_quantity=None):
    sizing=definition.get('position_sizing',{}) or {}; qty=sizing.get('quantity')
    if qty is not None:
        result=max(1,int(qty))
    else:
        pct=sizing.get('capital_pct')
        if pct and available_funds and price>0:
            result=max(1,int((float(available_funds)*float(pct)/100)/price))
        else:
            risk=sizing.get('risk_per_trade'); stop=(definition.get('risk',{}) or {}).get('stop_loss')
            if stop is None and atr_value and (definition.get('risk',{}) or {}).get('stop_atr_multiple') is not None:
                mult=float(definition['risk']['stop_atr_multiple'])
                stop=price-mult*float(atr_value) if str(definition.get('side','BUY')).upper()=='BUY' else price+mult*float(atr_value)
            result=max(1,int(float(risk)/(abs(price-float(stop))))) if risk and stop and price>0 and price!=float(stop) else 1
    lot=max(1,int(lot_size or 1))
    result=(result//lot)*lot
    if max_quantity is not None:
        cap=(int(max_quantity)//lot)*lot
        if cap < lot:return 0
        result=min(result,cap)
    if result<lot:result=lot
    return result


@dataclass
class BacktestTrade:
    symbol:str;entry_time:str;exit_time:str;side:str;quantity:int;entry_price:float;exit_price:float;gross_pnl:float;costs:float;net_pnl:float;exit_reason:str


def _bar_in_cash_session(candle):
    try:
        from datetime import datetime, time
        from zoneinfo import ZoneInfo
        raw=str(candle.get('candle_at','')).replace('Z','+00:00')
        x=datetime.fromisoformat(raw)
        if x.tzinfo is None:x=x.replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        else:x=x.astimezone(ZoneInfo('Asia/Kolkata'))
        return x.weekday()<5 and time(9,15)<=x.time().replace(tzinfo=None)<time(15,30)
    except (TypeError,ValueError):
        # Unknown historical timezone is not fabricated into a holiday/session.
        return True

def run_backtest(candles,definition,symbol,quantity=1,slippage=0.0,fees=0.0):
    """Conservative historical simulation.

    Signals are evaluated only on completed history and entries execute at the
    NEXT candle open, eliminating same-candle look-ahead. Stops/targets use
    candle high/low with stop checked first when both are touched. Optional
    partial exits, trailing stops and time exits are supported.
    """
    side=str(definition.get('side','BUY')).upper(); trades=[];open_trade=None
    for i in range(1,len(candles)):
        c=candles[i]; close=float(c['close'])
        if open_trade is None:
            hist=candles[:i]
            if not _bar_in_cash_session(c):continue
            ok,_=evaluate_entry(definition,hist)
            if ok:
                ind=indicators(hist)
                q=size_position(definition,float(c['open']),definition.get('_available_funds'),ind.get('atr14')) or quantity
                entry=float(c['open'])*(1+slippage if side=='BUY' else 1-slippage)
                open_trade={'time':c['candle_at'],'price':entry,'qty':q,'remaining':q,'side':side,'bars':0,'partial_taken':False}
            continue

        open_trade['bars']+=1
        risk=definition.get('risk',{}) or {}; entry=open_trade['price']
        stop=risk.get('stop_loss');target=risk.get('target')
        if stop is None and risk.get('stop_loss_pct') is not None:
            stop=entry*(1-float(risk['stop_loss_pct'])/100 if side=='BUY' else 1+float(risk['stop_loss_pct'])/100)
        if target is None and risk.get('target_pct') is not None:
            target=entry*(1+float(risk['target_pct'])/100 if side=='BUY' else 1-float(risk['target_pct'])/100)
        if risk.get('trailing_stop_pct') is not None:
            pct=float(risk['trailing_stop_pct'])/100
            candidate=close*(1-pct) if side=='BUY' else close*(1+pct)
            open_trade['trailing_stop']=max(open_trade.get('trailing_stop',candidate),candidate) if side=='BUY' else min(open_trade.get('trailing_stop',candidate),candidate)

        reason=None;exit_price=close
        if side=='BUY':
            if stop is not None and float(c['low'])<=float(stop):reason='STOP_LOSS';exit_price=float(stop)
            elif target is not None and float(c['high'])>=float(target):reason='TARGET';exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['low'])<=open_trade['trailing_stop']:reason='TRAILING_STOP';exit_price=open_trade['trailing_stop']
        else:
            if stop is not None and float(c['high'])>=float(stop):reason='STOP_LOSS';exit_price=float(stop)
            elif target is not None and float(c['low'])<=float(target):reason='TARGET';exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['high'])>=open_trade['trailing_stop']:reason='TRAILING_STOP';exit_price=open_trade['trailing_stop']

        if reason is None and risk.get('time_exit_bars') and open_trade['bars']>=int(risk['time_exit_bars']):
            reason='TIME_EXIT'
        if reason is None:
            exit_ok,_=evaluate_exit(definition,candles[:i+1])
            if exit_ok:reason='STRATEGY_EXIT'
        if reason is None:continue

        exit_price*=1-slippage if side=='BUY' else 1+slippage
        partial=float(risk.get('partial_exit_pct') or 100)
        exit_qty=open_trade['remaining'] if partial>=100 or open_trade['partial_taken'] else max(1,min(open_trade['remaining'],int(round(open_trade['qty']*partial/100))))
        gross=(exit_price-entry)*exit_qty*(1 if side=='BUY' else -1)
        net=gross-float(fees)
        trades.append(BacktestTrade(symbol,open_trade['time'],c['candle_at'],side,exit_qty,entry,exit_price,gross,float(fees),net,reason))
        open_trade['remaining']-=exit_qty
        if open_trade['remaining']<=0:
            open_trade=None
        else:
            open_trade['partial_taken']=True

    # Close any remaining position at the final available close so a report
    # cannot hide an open simulated position at the end of the dataset.
    if open_trade is not None and candles:
        last=candles[-1]; exit_price=float(last['close'])*(1-slippage if side=='BUY' else 1+slippage)
        qty=int(open_trade['remaining']); gross=(exit_price-open_trade['price'])*qty*(1 if side=='BUY' else -1); net=gross-float(fees)
        trades.append(BacktestTrade(symbol,open_trade['time'],last['candle_at'],side,qty,open_trade['price'],exit_price,gross,float(fees),net,'DATA_END'))
        open_trade=None
    pnl=sum(t.net_pnl for t in trades);wins=[t.net_pnl for t in trades if t.net_pnl>0];losses=[t.net_pnl for t in trades if t.net_pnl<0]
    equity=peak=dd=0; equity_curve=[];consecutive=0;max_consecutive=0
    for t in trades:
        equity+=t.net_pnl;peak=max(peak,equity);draw=peak-equity;dd=max(dd,draw);equity_curve.append({"candle_at":t.exit_time,"equity":equity,"drawdown":draw})
        consecutive=consecutive+1 if t.net_pnl<0 else 0;max_consecutive=max(max_consecutive,consecutive)
    avg=(sum(t.net_pnl for t in trades)/len(trades)) if trades else 0
    gross_profit=sum(wins);gross_loss=abs(sum(losses));
    return {
        'trades':[t.__dict__ for t in trades],
        'total_trades':len(trades),'net_pnl':pnl,
        'win_rate':(len(wins)/len(trades)*100 if trades else 0),
        'profit_factor':(sum(wins)/abs(sum(losses)) if losses else None),
        'max_drawdown':dd,
        'average_win':(sum(wins)/len(wins) if wins else 0),
        'average_loss':(sum(losses)/len(losses) if losses else 0),
        'gross_profit':gross_profit,'gross_loss':gross_loss,'expectancy':avg,'max_consecutive_losses':max_consecutive,'total_costs':sum(t.costs for t in trades),'equity_curve':equity_curve,
        'side':side,
        'execution_model':'next_bar_open',
        'session_filter':'NSE_CASH_WEEKDAY_09:15-15:30_IST',
        'slippage':float(slippage),'fees_per_exit':float(fees),
    }
