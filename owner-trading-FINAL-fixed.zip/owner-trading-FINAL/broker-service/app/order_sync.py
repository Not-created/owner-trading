"""Applies broker order/trade rows to local orders.

ONE code path is used for both the order-feed WebSocket (OrderUpdate.data,
dumped with wire aliases) and REST order_report()/trade_report() rows, so the
two sources can never disagree about how a row is interpreted.

Wire fields (official SDK docs, order_report / order feed models):
  nOrdNo (broker order id), exOrdId, ordSt, qty, fldQty, unFldSz, avgPrc,
  trdSym, exSeg, trnsTp, prcTp, prod, GuiOrdId (== the `tag` we sent),
  updRecvTm / uSec (ordering). Trade rows: flId (fill id), fldQty, avgPrc,
  flDt + flTm, nOrdNo, GuiOrdId.
"""
from __future__ import annotations

import logging

from . import db as _db
from .pnl import dec

logger = logging.getLogger("owner_trading.order_sync")

# Broker `ordSt` strings seen in the SDK docs/models. Anything else is stored
# verbatim in orders.broker_status and does NOT change our local status.
_SUBMITTED = {"put order req received", "validation pending", "open pending", "trigger pending", "after market order req received"}
_OPEN = {"open", "modified"}


def map_status(ord_st: str | None, qty: int, filled: int, unfilled: int | None) -> str | None:
    """Local status for a broker row, or None if the state is not recognised."""
    s = (ord_st or "").strip().lower()
    if s in ("complete", "completed", "traded"):
        return "COMPLETE"
    if s == "rejected":
        return "REJECTED"
    if s in ("cancelled", "canceled"):
        return "CANCELLED"
    if s in _SUBMITTED or s in _OPEN:
        if filled > 0 and (unfilled is None or unfilled > 0) and (qty <= 0 or filled < qty):
            return "PARTIALLY_FILLED"
        return "OPEN" if s in _OPEN else "SUBMITTED"
    if qty > 0 and filled >= qty:
        return "COMPLETE"
    return None


def _to_int(v, default=0) -> int:
    d = dec(v, None)
    return int(d) if d is not None else default


def _clean(v):
    if v is None:
        return None
    v = str(v).strip()
    return None if v in ("", "NA", "--", "-") else v


def row_event_id(row: dict) -> str:
    return "|".join(str(row.get(k, "")) for k in ("nOrdNo", "ordSt", "fldQty", "unFldSz", "updRecvTm", "uSec", "hsUpTm"))


def find_local_order(row: dict) -> dict | None:
    oid = _clean(row.get("nOrdNo"))
    if oid:
        o = _db.get_order_by_broker_order_id(oid)
        if o:
            return o
    tag = _clean(row.get("GuiOrdId"))
    if tag:
        return _db.get_order_by_client_tag(tag)
    return None


def apply_order_row(row: dict, *, source: str) -> dict:
    """Returns {"matched": bool, "internal_order_id": str|None, "status": str|None, "changed": bool}."""
    oid = _clean(row.get("nOrdNo"))
    local = find_local_order(row)
    _db.record_order_event(
        event_source=source, broker_event_id=row_event_id(row), raw_payload=row,
        order_id=local["id"] if local else None, broker_order_id=oid,
    )
    if local is None:
        return {"matched": False, "internal_order_id": None, "status": None, "changed": False}

    qty = _to_int(row.get("qty"), local.get("quantity") or 0)
    filled = _to_int(row.get("fldQty"))
    unfilled = _to_int(row.get("unFldSz"), None) if row.get("unFldSz") not in (None, "") else None
    status = map_status(row.get("ordSt"), qty, filled, unfilled)
    if status is None:
        logger.warning("Unrecognised broker order status %r for order %s; stored verbatim, local status unchanged.",
                       row.get("ordSt"), local["internal_order_id"])
        status = local["status"]
    # Out-of-order / re-delivered rows must not lower an order's progress.
    rank = {"SUBMITTING": 0, "SUBMITTED": 1, "OPEN": 2, "PARTIALLY_FILLED": 3}
    if status in ("SUBMITTED", "OPEN", "PARTIALLY_FILLED") and rank.get(local["status"], -1) > rank[status]:
        status = local["status"]
    avg = dec(row.get("avgPrc"), None)
    reason = None
    if status == "REJECTED":
        reason = _clean(row.get("rejRsn")) or _clean(row.get("ordUsrMsg")) or "Rejected by exchange/broker."
    changed = _db.apply_broker_order_state(
        internal_order_id=local["internal_order_id"], status=status,
        broker_status=(row.get("ordSt") or None),
        filled_quantity=filled if row.get("fldQty") is not None else None,
        average_price=float(avg) if avg and avg > 0 else None,
        exchange_order_id=_clean(row.get("exOrdId")), broker_order_id=oid, status_reason=reason,
    )
    return {"matched": True, "internal_order_id": local["internal_order_id"], "status": status, "changed": changed}


def apply_trade_row(row: dict) -> bool:
    """Idempotently records one fill from trade_report(). Returns True if new."""
    fill_id = _clean(row.get("flId"))
    oid = _clean(row.get("nOrdNo"))
    if not fill_id or not oid:
        return False
    local = find_local_order(row)
    qty = _to_int(row.get("fldQty"))
    price = dec(row.get("avgPrc"), None)
    if qty <= 0 or price is None:
        return False
    inserted=_db.record_trade(
        broker_trade_id=f"{oid}:{fill_id}:{row.get('flLeg', '')}",
        order_id=local["id"] if local else None, broker_order_id=oid,
        fill_quantity=qty, fill_price=float(price),
        fill_time=" ".join(x for x in (_clean(row.get("flDt")), _clean(row.get("flTm"))) if x) or None,
        raw_payload=row, mode="LIVE", trading_symbol=row.get("trdSym"), exchange_segment=row.get("exSeg"),
        transaction_type=row.get("trnsTp"), product=row.get("prod"),
        multiplier=float(dec(row.get("multiplier"), None) or 1),
    )
    if inserted:
        try:_db.apply_trade_to_algo_position(local["internal_order_id"] if local else None,qty,float(price),row.get("trnsTp"))
        except Exception:logger.exception("Failed to apply fill to algo position")
    return inserted
