"""Broker <-> local reconciliation using the official SDK response shapes.

A pass (serialised by a lock, state RECONCILING while running):
  1. order_report()  -> apply every row to local orders (status, partial
     fills, exchange id) via order_sync.apply_order_row -- the SAME path
     the order-feed uses. Rows matched only by our `tag` (GuiOrdId)
     resolve orders whose placement outcome was UNKNOWN.
  2. Local LIVE orders that are still unresolved after step 1 and are
     absent from the broker's order book are flagged (never auto-failed
     silently, never auto-resent).
  3. trade_report()  -> idempotent fills (flId).
  4. positions() / holdings() / limits() -> snapshots with documented
     field names; never invented values.
Any broker call that is not OK aborts that section, records a discrepancy
and leaves the previous snapshot untouched (no partial overwrite).
"""
from __future__ import annotations

import asyncio
import logging

from . import db as _db
from . import order_sync, pnl
from .broker_client import NotConfiguredError, broker_client
from .sdk_adapter import rows_of
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.reconciliation")
_lock = asyncio.Lock()


class _SessionLost(Exception):
    pass


async def _read(method: str, *args, **kwargs):
    """Runs one read-only SDK call. If the session became invalid (this call or an
    earlier one in the same pass), the whole pass is abandoned instead of recording
    a pile of misleading per-section failures."""
    loop = asyncio.get_running_loop()
    try:
        out = await loop.run_in_executor(None, lambda: broker_client.read(method, *args, **kwargs))
    except NotConfiguredError as exc:
        raise _SessionLost(str(exc))
    if out.kind == "AUTH":
        raise _SessionLost(out.message or "session invalid")
    return out


async def run_full_reconciliation() -> dict:
    if _lock.locked():
        return {"skipped": True, "reason": "reconciliation already running"}
    async with _lock:
        run_id=_db.begin_reconciliation_run()
        previous = current_state.state
        if previous == BrokerState.CONNECTED:
            current_state.transition(BrokerState.RECONCILING)
        try:
            result=await _run()
            sections_ok=all(result.get(k) is not None for k in ("orders","trades","positions","holdings","funds")) and not result.get("discrepancies")
            _db.finish_reconciliation_run(run_id,status="COMPLETE" if sections_ok else "DISCREPANCY",
                                          discrepancy_count=len(result.get("discrepancies") or []),sections_ok=sections_ok,details=result)
            result["reconciliation_run_id"]=run_id
            return result
        except _SessionLost as exc:
            details={"error":str(exc)[:200]}
            _db.record_reconciliation(reconciliation_type="aborted_session_lost", reference_id=None,
                                      discrepancy_found=True, details=details)
            _db.finish_reconciliation_run(run_id,status="SESSION_LOST",discrepancy_count=1,sections_ok=False,details=details)
            return {"error": f"reconciliation aborted: {exc}","reconciliation_run_id":run_id}
        except Exception as exc:
            details={"error":f"{type(exc).__name__}: {exc}"[:500]}
            _db.finish_reconciliation_run(run_id,status="FAILED",discrepancy_count=1,sections_ok=False,details=details)
            raise
        finally:
            if current_state.state == BrokerState.RECONCILING:
                current_state.transition(BrokerState.CONNECTED)


async def _run() -> dict:
    result: dict = {"orders": None, "trades": None, "positions": None, "holdings": None, "funds": None, "discrepancies": []}

    def discrepancy(kind: str, ref: str | None, details: dict) -> None:
        result["discrepancies"].append({"kind": kind, "ref": ref, **details})
        _db.record_reconciliation(reconciliation_type=kind, reference_id=ref, discrepancy_found=True, details=details)

    # 1. Orders
    seen_tags: set[str] = set()
    seen_ids: set[str] = set()
    oo = await _read("order_report")
    if oo.ok:
        rows = rows_of(oo)
        matched = unmatched = 0
        for row in rows:
            r = order_sync.apply_order_row(row, source="reconciliation")
            if row.get("nOrdNo"):
                seen_ids.add(str(row["nOrdNo"]))
            if row.get("GuiOrdId"):
                seen_tags.add(str(row["GuiOrdId"]))
            if r["matched"]:
                matched += 1
            else:
                unmatched += 1
        result["orders"] = {"broker_rows": len(rows), "matched": matched, "not_ours": unmatched}
        # Local LIVE orders the broker does not know about.
        for o in _db.list_unresolved_live_orders():
            known = (o["broker_order_id"] and o["broker_order_id"] in seen_ids) or (o["client_tag"] and o["client_tag"] in seen_tags)
            if not known and o["status"] in ("SUBMITTING","PENDING_RECONCILE"):
                discrepancy("order_submission_unresolved", o["internal_order_id"],
                            {"status": o["status"], "outcome_unknown": bool(o["outcome_unknown"])})
            elif not known and o["status"] not in ("SUBMITTING",):
                discrepancy("order_missing_at_broker", o["internal_order_id"],
                            {"status": o["status"], "outcome_unknown": bool(o["outcome_unknown"])})
    else:
        discrepancy("order_report_failed", None, {"outcome": oo.kind, "message": oo.message})

    # 2. Trades
    tr = await _read("trade_report")
    if tr.ok:
        new = sum(1 for row in rows_of(tr) if order_sync.apply_trade_row(row))
        result["trades"] = {"new_fills": new}
    else:
        discrepancy("trade_report_failed", None, {"outcome": tr.kind, "message": tr.message})

    # 3. Positions
    po = await _read("positions")
    if po.ok:
        norm = [pnl.normalize_position(r) for r in rows_of(po)]
        _db.record_positions_snapshot(norm)
        broker_keys={(p.get("exchange_segment"),str(p.get("instrument_token"))) for p in norm if int(p.get("quantity") or 0)!=0}
        # Any local algo position absent from the broker snapshot is reconciled closed;
        # never leave a stale OPEN row merely because the broker returned zero rows.
        with _db._connection() as conn:
            stale=conn.execute("SELECT id,exchange_segment,instrument_token FROM algo_positions WHERE status='OPEN'").fetchall()
        for pid,seg,tok in stale:
            if (seg,str(tok)) not in broker_keys:_db.update_algo_position_from_broker(pid,0,None)
        # Restart recovery is bound only through the immutable strategy ENTRY
        # order chain. Manual/unknown broker positions are never guessed into a
        # strategy merely because the symbol happens to match.
        try:
            from .exit_engine import derive_levels
            import json
            for pos in norm:
                net_qty=int(pos.get("quantity") or 0)
                if net_qty == 0: continue
                seg=pos.get("exchange_segment"); tok=pos.get("instrument_token")
                side='BUY' if net_qty>0 else 'SELL'
                entry=_db.find_strategy_entry_order_for_position(exchange_segment=seg,instrument_token=tok,side=side)
                if not entry or not entry.get("signal_id"):continue
                sig=_db.get_signal(int(entry["signal_id"]))
                if not sig:continue
                sv=_db.get_strategy_version(sig["strategy_version_id"])
                if not sv:continue
                stop,target=derive_levels(sv["definition"],float(pos.get("average_price") or sig.get("signal_price") or 0),sig.get("side","BUY"))
                pid=_db.ensure_algo_position(
                    exchange_segment=seg,instrument_token=tok,
                    trading_symbol=pos.get("trading_symbol"),
                    strategy_version_id=sig["strategy_version_id"],
                    entry_order_id=entry["internal_order_id"],
                    quantity=abs(net_qty),
                    average_entry=pos.get("average_price"),
                    stop_loss=stop,target=target)
                _db.update_algo_position_from_broker(pid,abs(net_qty),pos.get("average_price"))
        except Exception as exc:
            logger.warning("Strategy-position binding failed: %s",exc)
        result["positions"] = {"count": len(norm)}
    else:
        discrepancy("positions_failed", None, {"outcome": po.kind, "message": po.message})

    # 4. Holdings
    ho = await _read("holdings")
    if ho.ok:
        norm_h = [pnl.normalize_holding(r) for r in rows_of(ho)]
        _db.record_holdings_snapshot(norm_h)
        result["holdings"] = {"count": len(norm_h)}
    else:
        discrepancy("holdings_failed", None, {"outcome": ho.kind, "message": ho.message})

    # 5. Funds (flat dict)
    li = await _read("limits")
    if li.ok and isinstance(li.data, dict):
        parsed = pnl.parse_limits(li.data)
        _db.record_funds_snapshot(raw=li.data, **parsed)
        result["funds"] = parsed
    else:
        discrepancy("limits_failed", None, {"outcome": li.kind, "message": li.message})

    _db.record_reconciliation(
        reconciliation_type="full", reference_id=None,
        discrepancy_found=bool(result["discrepancies"]),
        details={k: v for k, v in result.items() if k != "discrepancies"} | {"discrepancy_count": len(result["discrepancies"])},
    )
    return result
