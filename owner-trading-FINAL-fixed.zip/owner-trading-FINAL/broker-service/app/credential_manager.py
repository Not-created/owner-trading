"""Kotak credential lifecycle manager.

Credentials submitted through the Settings UI are kept in process memory while
a connection is being tested. They are persisted ONLY after successful broker
authentication, encrypted with Fernet, and written to the dedicated runtime
state path (normally /var/lib/owner-trading/kotak-credentials.enc). Raw values
are never logged or echoed by the API. On restart the encrypted blob may be
recovered, but authentication is never attempted automatically.

TOTP: the official SDK's own dependency list (kotakneoapi's package
metadata, confirmed during the earlier SDK audit) includes `pyotp` --
strong, source-grounded evidence that the intended integration pattern is
storing the TOTP *secret* (the seed used to set up an authenticator app)
once, and generating a fresh 6-digit code at each login attempt via
`pyotp.TOTP(secret).now()`, rather than requiring a human to type a live
code on every single connect/reconnect. This module stores the secret; the
current numeric code is generated on demand in broker_client.py and is
never itself persisted or logged.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

from .config import config


class CredentialFormatError(ValueError):
    """Raised by CredentialManager.set() when a value is shaped in a way
    the real Kotak API will reject -- caught by the /credentials HTTP
    handler in server.py and reported back as a 400, never silently
    accepted and only failing later inside a real totp_login() call.
    """


# Every official Kotak Neo SDK example (v2.0.2's Kotak-Neo-api-v2 README
# and the kotakneoapi package page, both fetched during this audit) shows
# totp_login() called with the mobile number in full E.164 form, country
# code included: mobile_number="+919876543210". The current Settings UI/
# Express-side validation (kotakCredentialValidation.js) still accepts a
# bare 10-digit number for backward compatibility, so this is the one place
# that normalizes it to what the SDK actually expects before any network
# call is made -- never guessing, always this exact, documented shape.
_BARE_10_DIGIT = re.compile(r"^\d{10}$")
_E164_LIKE = re.compile(r"^\+\d{1,3}\d{6,14}$")
_MPIN = re.compile(r"^\d{4,6}$")
# A TOTP *secret* is the base32 seed shown once at authenticator setup
# (letters A-Z and digits 2-7, RFC 4648 base32 alphabet -- what pyotp.TOTP()
# requires). A live 6-8 digit code is the thing that seed *generates*, not
# the seed itself, and cannot be used to generate future codes.
_TOTP_SECRET_B32 = re.compile(r"^[A-Z2-7]+=*$")
_LIVE_OTP_CODE = re.compile(r"^\d{6,8}$")


def normalize_mobile_number(value: str, *, default_country_code: str = "+91") -> str:
    """Returns the SDK-ready E.164 form. Raises CredentialFormatError for
    anything that isn't clearly one of the two accepted input shapes --
    never silently passes through something malformed."""
    value = (value or "").strip()
    if _E164_LIKE.match(value):
        return value
    if _BARE_10_DIGIT.match(value):
        return f"{default_country_code}{value}"
    raise CredentialFormatError(
        "Mobile number must be a bare 10-digit number or include a country code, e.g. +919876543210."
    )


def normalize_totp_secret(value: str) -> str:
    """Returns the SDK-ready base32 TOTP *secret* (the authenticator-app
    setup seed pyotp.TOTP(secret).now() needs), never a generated code.

    Accepts either the bare base32 secret (surrounding whitespace and any
    spaces an authenticator app inserted for readability are stripped;
    compared case-insensitively since base32 is conventionally upper-case)
    or a full otpauth:// URI, from which the `secret` query parameter is
    extracted. Rejects, with a clear message and BEFORE any network call:
      - a live 6-8 digit code pasted by mistake (that is what the secret
        *produces*, not the secret itself -- using it would authenticate
        once, if at all, and then fail on every subsequent connect), and
      - anything that isn't valid base32 once normalised.
    The secret's value is never altered semantically -- only whitespace/
    case cosmetics are normalised, exactly as an authenticator app would
    treat it, and it is never logged.
    """
    raw = (value or "").strip()
    if not raw:
        raise CredentialFormatError("TOTP secret is required.")
    if raw.lower().startswith("otpauth://"):
        from urllib.parse import parse_qs, urlparse
        try:
            secret = (parse_qs(urlparse(raw).query).get("secret") or [""])[0].strip()
        except Exception as exc:  # noqa: BLE001 -- malformed URI, not a secret to log
            raise CredentialFormatError(f"Could not parse the otpauth:// URI: {type(exc).__name__}.") from exc
        if not secret:
            raise CredentialFormatError(
                "The otpauth:// URI has no 'secret' parameter. Paste the base32 secret "
                "shown under the QR code instead of the full URI."
            )
        raw = secret
    candidate = raw.replace(" ", "").replace("-", "").upper()
    if _LIVE_OTP_CODE.match(candidate):
        raise CredentialFormatError(
            "This looks like a live 6-digit authenticator code, not the TOTP setup secret. "
            "Paste the base32 secret shown once when you set up the authenticator app -- "
            "the service generates a fresh code from it at every connect."
        )
    if not _TOTP_SECRET_B32.match(candidate):
        raise CredentialFormatError(
            "TOTP secret must be the base32 setup secret (letters A-Z and digits 2-7) "
            "or a full otpauth:// URI containing one."
        )
    return candidate


try:
    import pyotp

    PYOTP_AVAILABLE = True
except ImportError:
    # Same offline-degrade pattern as the NeoAPI import in broker_client.py
    # -- pyotp ships as a transitive dependency of kotakneoapi, so it is
    # only actually importable once that package is installed.
    pyotp = None
    PYOTP_AVAILABLE = False


@dataclass
class KotakCredentials:
    consumer_key: str
    mobile_number: str
    ucc: str
    mpin: str
    totp_secret: str


class CredentialManager:
    def __init__(self) -> None:
        self._creds: KotakCredentials | None = None

    def set(self, *, consumer_key: str, mobile_number: str, ucc: str, mpin: str, totp_secret: str) -> None:
        """Validates and normalizes any value that IS supplied before
        storing, so a malformed mobile number or MPIN is rejected here (400
        back to the caller) instead of being stored as-is and only
        discovered later as an opaque totp_login()/totp_validate() failure.

        Deliberately does NOT require every field to be non-empty -- that
        is a separate concern (has_base_credentials()/NOT_CONFIGURED)
        already handled by callers, and the HTTP layer (server.py's
        /credentials handler) already rejects a request missing a field
        before this is ever called.
        """
        consumer_key = (consumer_key or "").strip()
        ucc = (ucc or "").strip()
        mpin = (mpin or "").strip()
        if mpin and not _MPIN.match(mpin):
            raise CredentialFormatError("MPIN must be 4-6 digits.")
        normalized_mobile = normalize_mobile_number(mobile_number) if mobile_number else mobile_number
        normalized_totp = normalize_totp_secret(totp_secret) if totp_secret else totp_secret
        self._creds = KotakCredentials(
            consumer_key=consumer_key,
            mobile_number=normalized_mobile,
            ucc=ucc,
            mpin=mpin,
            totp_secret=normalized_totp,
        )

    def persist(self) -> None:
        """Persist credentials only after a real broker authentication succeeds."""
        if not self.has_base_credentials():
            raise CredentialFormatError("Cannot persist incomplete Kotak credentials.")
        if not config.credential_encryption_key:
            raise CredentialFormatError("Credential encryption key is not configured.")
        try:
            from cryptography.fernet import Fernet
            key = config.credential_encryption_key.encode()
            token = Fernet(key).encrypt(json.dumps(self._creds.__dict__, separators=(",", ":")).encode())
        except Exception as exc:
            raise CredentialFormatError(f"Credential encryption failed: {type(exc).__name__}") from exc
        path = Path(config.credential_store_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(token)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)

    def load_persisted(self) -> bool:
        """Load an encrypted credential blob at process start, never authenticate automatically."""
        path = Path(config.credential_store_path)
        key = config.credential_encryption_key
        if not key or not path.is_file():
            return False
        try:
            from cryptography.fernet import Fernet
            raw = Fernet(key.encode()).decrypt(path.read_bytes())
            data = json.loads(raw.decode())
            self.set(**data)
            return self.has_base_credentials()
        except Exception as exc:
            self.clear()
            raise CredentialFormatError(f"Persisted Kotak credentials could not be decrypted/validated: {type(exc).__name__}") from exc

    def delete_persisted(self) -> None:
        path = Path(config.credential_store_path)
        try:
            path.unlink()
        except FileNotFoundError:
            pass

    def get(self) -> KotakCredentials | None:
        return self._creds

    def current_totp_code(self) -> str | None:
        """Generates the live 6-digit TOTP code from the stored secret.
        Returns None if no secret is stored or pyotp isn't installed --
        callers must treat that as "cannot authenticate right now", never
        substitute a fake code.
        """
        if self._creds is None or not self._creds.totp_secret:
            return None
        if not PYOTP_AVAILABLE:
            return None
        return pyotp.TOTP(self._creds.totp_secret).now()

    def has_base_credentials(self) -> bool:
        c = self._creds
        return bool(c and c.consumer_key and c.mobile_number and c.ucc and c.mpin and c.totp_secret)

    def clear(self) -> None:
        self._creds = None

    def masked_summary(self) -> dict:
        """Safe-to-return summary for status endpoints -- never the actual
        values, only whether they're present and a masked hint."""
        from .secure_store import redact

        c = self._creds
        if c is None:
            return {"configured": False}
        return {
            "configured": True,
            "consumerKey": redact(c.consumer_key),
            "mobileNumber": redact(c.mobile_number),
            "ucc": redact(c.ucc),
            "totpConfigured": bool(c.totp_secret),
        }


# Module-level singleton -- one broker service process, one credential set.
credential_manager = CredentialManager()
