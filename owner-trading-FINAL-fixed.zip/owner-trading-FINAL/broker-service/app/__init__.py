"""Owner Trading — Kotak Neo broker service (foundation stage).

This package is the ONLY part of the application allowed to import and use
the official `kotakneoapi` SDK. Express never talks to Kotak directly.

In this phase, no credentials are configured anywhere and no authentication
is attempted -- every module here is structure/interface only, verified
against the audited kotak-neo-python (main, v3.0.6) source. Real
authentication, order placement, and market-data/WebSocket streaming begin
in the next phase.
"""
