from __future__ import annotations
import asyncio, csv, io, urllib.request, datetime as dt
from . import db
from .broker_client import broker_client
from .websocket_manager import websocket_manager

def _field(row, *names):
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return None

MAX_SFEED_SUBSCRIPTIONS = 3000

async def sync_nse_cash_and_subscribe(limit=0):
    out = await asyncio.get_running_loop().run_in_executor(None, lambda: broker_client.read("scrip_master", exchange_segment="nse_cm"))
    if not out.ok:
        return {"ok": False, "error": out.message}
    url = out.data if isinstance(out.data, str) else None
    if not url:
        return {"ok": False, "error": "Kotak scrip_master did not return the NSE cash file URL."}
    raw = await asyncio.get_running_loop().run_in_executor(None, lambda: urllib.request.urlopen(url, timeout=30).read())
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig", errors="replace"))))
    count = 0
    selected = []
    for r in rows:
        tok = _field(r, "pSymbol", "instrument_token", "token", "symbol_token")
        sym = _field(r, "pTrdSymbol", "trading_symbol", "tradingsymbol", "symbol")
        if not tok or not sym:
            continue
        itype = (_field(r, "pInstType", "instrument_type", "instrument") or "").upper()
        if itype and itype not in ("EQ", "EQUITY", "CASH"):
            continue
        with db._connection() as conn:
            conn.execute(
                """INSERT INTO instruments(exchange_segment,trading_symbol,instrument_token,name,instrument_type,expiry,strike,option_type,lot_size,tick_size,scrip_master_updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))
                   ON CONFLICT(exchange_segment,instrument_token) DO UPDATE SET trading_symbol=excluded.trading_symbol,name=excluded.name,instrument_type=excluded.instrument_type,scrip_master_updated_at=excluded.scrip_master_updated_at""",
                ("nse_cm", str(sym), str(tok), _field(r, "pCompanyName", "name"), itype or "EQ",
                 _field(r, "pExpiryDate", "expiry"), _field(r, "pStrikePrice", "strike"),
                 _field(r, "pOptionType", "option_type"), _field(r, "pLotSize", "lot_size"), _field(r, "pTickSize", "tick_size")),
            )
        selected.append((str(tok), str(sym)))
        count += 1
    requested = int(limit or 0)
    effective_limit = MAX_SFEED_SUBSCRIPTIONS if requested <= 0 else min(requested, MAX_SFEED_SUBSCRIPTIONS)
    selected = selected[:effective_limit]
    subscribed = 0
    rejected = 0
    for tok, _sym in selected:
        try:
            await websocket_manager.subscribe("nse_cm", tok)
            subscribed += 1
        except Exception as exc:
            rejected += 1
            # A rejected subscription is visible to the caller; it is never silently treated as live.
            if subscribed == 0 and rejected > 3:
                break
    db.set_algo_runtime(universe_count=count, status="RUNNING")
    return {"ok": rejected == 0, "synced": count, "candidateCount": len(selected),
            "subscribed": subscribed, "rejected": rejected, "subscriptionLimit": MAX_SFEED_SUBSCRIPTIONS,
            "truncated": count > effective_limit, "updated_at": dt.datetime.now(dt.timezone.utc).isoformat()}
