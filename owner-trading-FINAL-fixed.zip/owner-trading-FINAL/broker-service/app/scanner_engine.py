
from __future__ import annotations
import asyncio
from . import db, strategy_engine
from .broker_client import broker_client

async def run(payload:dict)->dict:
    definition=payload.get('definition') or {}
    timeframe=str(payload.get('timeframe') or '5m')
    universe=db.list_instruments(min(3000,int(payload.get('limit') or 3000)))
    matched=[]
    for i in universe:
        candles=db.recent_candles(i['exchange_segment'],i['instrument_token'],timeframe,250)
        if len(candles)<20: continue
        passed,detail=strategy_engine.evaluate_entry(definition,candles)
        if passed: matched.append({'instrument':i,'price':candles[-1]['close'],'details':detail})
    from datetime import datetime, timezone
    db.set_algo_runtime(last_scan_at=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S'),universe_count=len(universe),status='RUNNING')
    return {'results':matched,'scanned':len(universe),'matched':len(matched)}
