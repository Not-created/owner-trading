"""Indian cash-market session gate used by the LIVE strategy engine.

This is deliberately conservative: it gates automated entries to the normal
NSE cash continuous session on weekdays (09:15-15:30 Asia/Kolkata). It does
not invent exchange-holiday status; broker connectivity/readiness remains the
authoritative gate for actual order submission.
"""
from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo

IST=ZoneInfo("Asia/Kolkata")
OPEN=dt.time(9,15)
CLOSE=dt.time(15,30)

def session_state(now: dt.datetime|None=None)->dict:
    local=(now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    weekday=local.weekday()<5
    in_hours=OPEN <= local.time().replace(tzinfo=None) < CLOSE
    return {
        "open": bool(weekday and in_hours),
        "timezone":"Asia/Kolkata",
        "local_time":local.isoformat(),
        "weekday":weekday,
        "continuous_session":"09:15-15:30",
        "reason":"OPEN" if weekday and in_hours else ("WEEKEND" if not weekday else "OUTSIDE_SESSION"),
    }
