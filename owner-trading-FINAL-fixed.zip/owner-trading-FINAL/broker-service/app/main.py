"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express.
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")

# BUGFIX (final audit): session.check_and_handle_expiry() and
# reconciliation.run_full_reconciliation() were both fully implemented but
# never invoked from anywhere -- dead code. Session expiry would never be
# detected until the next broker call happened to fail, and reconciliation
# never ran on any schedule (only once, right after a successful connect,
# per the fix in broker_client.py). This loop is what actually makes both
# real: it polls every SESSION_CHECK_INTERVAL_SECONDS while the service is
# up, regardless of connection state (check_and_handle_expiry() itself is a
# no-op unless state is CONNECTED), and re-reconciles on the slower
# RECONCILIATION_INTERVAL_SECONDS cadence whenever still CONNECTED.
SESSION_CHECK_INTERVAL_SECONDS = 60
RECONCILIATION_INTERVAL_SECONDS = 15 * 60


def _determine_initial_state() -> None:
    """Sets the starting state WITHOUT authenticating -- only an explicit
    /connect does that. LIVE refuses to start without the internal API token."""
    import os
    from . import sdk_adapter
    from .credential_manager import credential_manager

    if config.trading_mode == "LIVE" and not os.environ.get("BROKER_SERVICE_TOKEN"):
        raise SystemExit("LIVE execution requires BROKER_SERVICE_TOKEN to be set. Refusing to start.")

    if config.trading_mode == "LIVE" or sdk_adapter.SDK_AVAILABLE:
        from .broker_client import sdk_ready
        ok, reason = sdk_ready()
        if not ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, reason)
            logger.error(reason)
            return
        from .sdk_conformance import check_sdk_conformance
        conformance = check_sdk_conformance()
        if not conformance.ok:
            current_state.transition(BrokerState.CONNECTION_ERROR, conformance.summary())
            logger.error(conformance.summary())
            return
        logger.info(conformance.summary())
    else:
        current_state.transition(BrokerState.CONNECTION_ERROR, f"Official SDK not importable: {sdk_adapter.SDK_IMPORT_ERROR}")
        logger.warning("Official SDK not importable -- broker service running in degraded mode.")
        return

    if config.is_fully_configured():
        credential_manager.set(consumer_key=config.consumer_key, mobile_number=config.mobile_number, ucc=config.ucc,
                               mpin=config.mpin, totp_secret=config.totp_secret)
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials loaded from protected environment. State: DISCONNECTED (call /connect to authenticate).")
    else:
        try:
            if credential_manager.load_persisted():
                current_state.transition(BrokerState.DISCONNECTED)
                logger.info("Encrypted Kotak credentials recovered. State: DISCONNECTED (call /connect to authenticate).")
            else:
                current_state.transition(BrokerState.NOT_CONFIGURED)
                logger.info("Kotak credentials are not configured. State: NOT_CONFIGURED.")
        except Exception as exc:
            current_state.transition(BrokerState.AUTH_FAILED, "Persisted credential store could not be loaded.")
            logger.error("Encrypted credential store load failed: %s", exc)


async def _background_maintenance_loop(stop_event: asyncio.Event) -> None:
    """Session-expiry detection and scheduled reconciliation. One failed
    tick never kills the loop."""
    from . import reconciliation as _reconciliation
    from . import session as _session
    from . import websocket_manager as _wsm

    elapsed = 0
    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=SESSION_CHECK_INTERVAL_SECONDS)
            break
        except asyncio.TimeoutError:
            pass
        try:
            if _session.check_and_handle_expiry():
                logger.warning("Broker session TTL exceeded; state -> SESSION_EXPIRED.")
                await _wsm.websocket_manager.stop()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session-expiry check failed: %s", exc)
        elapsed += SESSION_CHECK_INTERVAL_SECONDS
        if elapsed >= RECONCILIATION_INTERVAL_SECONDS:
            elapsed = 0
            if current_state.state == BrokerState.CONNECTED:
                try:
                    await _reconciliation.run_full_reconciliation()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Scheduled reconciliation failed: %s", exc)


async def _main() -> None:
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())
    maintenance_task = asyncio.create_task(_background_maintenance_loop(stop_event))

    await stop_event.wait()
    server_task.cancel()
    maintenance_task.cancel()
    for task in (server_task, maintenance_task):
        try:
            await task
        except asyncio.CancelledError:
            pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
