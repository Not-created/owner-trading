"""LIVE protective-exit supervisor.

Stop/target/trailing decisions use every received SFeed tick. Strategy/time
exits may additionally use completed candles. No simulator is involved.
"""
from __future__ import annotations
import asyncio,datetime as dt,logging
from . import db,strategy_engine,order_service
logger=logging.getLogger('owner_trading.exit')
_inflight:set[int]=set()
_lock=asyncio.Lock()

def derive_levels(definition,entry,side='BUY'):
    risk=definition.get('risk',{}) or {};side=str(side).upper();stop=risk.get('stop_loss');target=risk.get('target')
    if stop is None and risk.get('stop_loss_pct') is not None:
        stop=entry*(1-float(risk['stop_loss_pct'])/100 if side=='BUY' else 1+float(risk['stop_loss_pct'])/100)
    if target is None and risk.get('target_pct') is not None:
        target=entry*(1+float(risk['target_pct'])/100 if side=='BUY' else 1-float(risk['target_pct'])/100)
    return stop,target

def _time_exit_due(position,risk,now):
    bars=risk.get('time_exit_bars')
    if not bars or not position.get('opened_at'):return False
    try:
        opened=dt.datetime.fromisoformat(str(position['opened_at']).replace(' ','T')).replace(tzinfo=dt.timezone.utc)
        minutes=int(bars)*5
        return (now-opened).total_seconds() >= minutes*60
    except (TypeError,ValueError):return False

async def evaluate_position(position, *, price:float, timestamp=None):
    pid=int(position['id'])
    if position.get('status')!='OPEN' or not position.get('remaining_quantity') or db.has_pending_exit(pid):return
    version=db.get_strategy_version(position.get('strategy_version_id') or 0)
    if not version:return
    definition=version['definition'];side=str(definition.get('side','BUY')).upper();risk=definition.get('risk',{}) or {}
    stop=position.get('stop_loss');target=position.get('target')
    trailing=position.get('trailing_stop');trail_pct=risk.get('trailing_stop_pct')
    now=timestamp or dt.datetime.now(dt.timezone.utc)
    db.update_algo_position_risk(pid,last_price=float(price))

    # Monotonic trailing stop: it can tighten, never loosen.
    if trail_pct is not None:
        pct=float(trail_pct)/100
        candidate=float(price)*(1-pct if side=='BUY' else 1+pct)
        if trailing is None:
            trailing=candidate
        elif side=='BUY':
            trailing=max(float(trailing),candidate)
        else:
            trailing=min(float(trailing),candidate)
        db.update_algo_position_risk(pid,trailing_stop=trailing)

    reason=None;trigger=None
    if side=='BUY':
        if stop is not None and float(price)<=float(stop):reason='STOP_LOSS';trigger=float(stop)
        elif target is not None and float(price)>=float(target):reason='TARGET';trigger=float(target)
        elif trailing is not None and float(price)<=float(trailing):reason='TRAILING_STOP';trigger=float(trailing)
    else:
        if stop is not None and float(price)>=float(stop):reason='STOP_LOSS';trigger=float(stop)
        elif target is not None and float(price)<=float(target):reason='TARGET';trigger=float(target)
        elif trailing is not None and float(price)>=float(trailing):reason='TRAILING_STOP';trigger=float(trailing)

    if reason is None and _time_exit_due(position,risk,now):
        reason='TIME_EXIT';trigger=float(price)

    # Strategy-defined exits are evaluated only on completed candle history.
    if reason is None:
        candles=db.recent_candles(position['exchange_segment'],position['instrument_token'],'5m',250)
        if len(candles)>=20:
            ok,_=strategy_engine.evaluate_exit(definition,candles)
            if ok:reason='STRATEGY_EXIT';trigger=float(price)
    if reason is None:return

    async with _lock:
        if pid in _inflight or db.has_pending_exit(pid):return
        _inflight.add(pid)
    try:
        qty=int(position['remaining_quantity'])
        partial_pct=float(risk.get('partial_exit_pct') or 100)
        request_qty=max(1,min(qty,int(round(qty*partial_pct/100))))
        exit_id=db.record_exit_request(pid,reason,request_qty,trigger)
        try:
            order=await order_service.place_order({
                'trading_symbol':position['trading_symbol'],
                'exchange_segment':position['exchange_segment'],
                'transaction_type':'S' if side=='BUY' else 'B',
                'order_type':'MKT',
                'product':definition.get('execution',{}).get('product','MIS'),
                'validity':'DAY','quantity':request_qty,
                'instrument_token':position['instrument_token'],
                'algo_position_id':pid,'order_role':'EXIT',
                'parent_order_id':position.get('entry_order_id'),
                'idempotency_key':f"exit-{pid}-{reason}-{position['remaining_quantity']}-{request_qty}",
            })
            if order:db.mark_exit_order(pid,order.get('internal_order_id'),exit_id)
        except Exception as exc:
            logger.warning('Exit order blocked for %s: %s',position['trading_symbol'],exc)
    finally:
        async with _lock:_inflight.discard(pid)

async def on_tick(*,exchange_segment,instrument_token,price,timestamp=None):
    positions=db.list_algo_positions()
    for position in positions:
        if position['exchange_segment']==exchange_segment and str(position['instrument_token'])==str(instrument_token):
            await evaluate_position(position,price=float(price),timestamp=timestamp)
