"""Last-price lookup from the local market_data_state table (ticks written by the
SFeed handler). Read-only, no broker calls; shared by risk checks."""
from __future__ import annotations

import datetime as _dt

from . import db as _db

MAX_TICK_AGE_SECONDS = 60


def fresh_ltp(instrument_token: str | None, trading_symbol: str, exchange_segment: str | None) -> float | None:
    now = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None)
    ticks = _db.latest_market_ticks_for_instrument(instrument_token=instrument_token, exchange_segment=exchange_segment, trading_symbol=trading_symbol)
    for t in ticks:
        match = (instrument_token and t["instrument_token"] == str(instrument_token)) or (
            t.get("trading_symbol") == trading_symbol and (not exchange_segment or t["exchange_segment"] in ("", exchange_segment))
        )
        if not match or t["last_traded_price"] is None:
            continue
        try:
            age = (now - _dt.datetime.strptime(t["last_tick_at"], "%Y-%m-%d %H:%M:%S")).total_seconds()
        except (TypeError, ValueError):
            continue
        if age <= MAX_TICK_AGE_SECONDS:
            return float(t["last_traded_price"])
    return None
