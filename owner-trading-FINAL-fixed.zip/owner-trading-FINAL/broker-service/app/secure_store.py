"""Secure secret-handling for Kotak credentials and session artifacts.

Design (implemented):
  - Long-lived credentials (consumer key, mobile number, UCC, TOTP secret,
    MPIN) submitted via the Settings UI are held ONLY in this process's
    memory (see credential_manager.py's CredentialManager) -- never
    written to disk, never logged, never echoed back to any API response.
    A broker-service restart requires re-saving them through the UI, UNLESS
    the operator has instead populated /etc/owner-trading/broker.env (mode
    600, root-only-readable, loaded via
    deployment/systemd/owner-trading-broker.service's EnvironmentFile
    directive and read by config.py at startup) -- that IS the persistent
    option, and _determine_initial_state() in main.py loads it into the
    same CredentialManager on boot.
  - Session artifacts (edit_token/edit_sid/data_center from totp_validate())
    are short-lived and process-local: kept ONLY in this process's memory
    (see session.py's SessionInfo), never written to SQLite or disk. If the
    broker service restarts, the session is gone and a fresh TOTP+MPIN
    login is required -- this is intentional; SQLite's reconciliation
    tables and broker_connection_state store only opaque metadata
    (timestamps, state labels, a reference id), never the token itself.
  - The Express backend never receives, stores, or proxies Kotak
    credentials or session tokens at any point -- it forwards the
    Settings UI's credential submission straight through to the broker
    service's /credentials endpoint without storing it, and afterward only
    ever reads the connection STATE (NOT_CONFIGURED / CONNECTED / etc.)
    via /status. See brokerKotak.js's route comments for where this is
    enforced.
"""
from __future__ import annotations


def redact(value: str | None) -> str:
    """Used by any future logging call that might otherwise include a
    credential-shaped value -- never log config.consumer_key,
    config.mpin, etc. directly."""
    if not value:
        return "<empty>"
    return "*" * max(len(value) - 2, 0) + value[-2:] if len(value) > 2 else "**"
