import unittest
from app.strategy_engine import validate_strategy, indicators, run_backtest

class Phase46StrategyTests(unittest.TestCase):
    def setUp(self):
        self.candles=[]
        for i in range(100):
            p=100+(i*0.35)
            self.candles.append({'candle_at':f'2026-01-01 09:{i%60:02d}:00','open':p,'high':p+1,'low':p-1,'close':p+0.4,'volume':100+i})
    def test_indicator_stack(self):
        x=indicators(self.candles)
        for k in ('macd','macd_signal','macd_hist','adx14','vwap','rsi14','atr14'):
            self.assertIn(k,x)
    def test_validation_rejects_invalid_definition(self):
        errors=validate_strategy({'side':'NOPE','entry':{'op':'X','conditions':[]},'exit':{'op':'OR','conditions':[]},'execution':{'product':'BO'}})
        self.assertGreaterEqual(len(errors),4)
    def test_backtest_supports_sell_and_risk_exits(self):
        d={'timeframe':'5m','side':'SELL','entry':{'op':'AND','conditions':[{'left':'ema20','operator':'>','right':'ema50'}]},'exit':{'op':'OR','conditions':[{'left':'rsi14','operator':'<','right':45}]},'risk':{'stop_loss_pct':1,'target_pct':2,'trailing_stop_pct':0.5,'time_exit_bars':5},'position_sizing':{'quantity':2},'execution':{'product':'MIS'}}
        self.assertEqual(validate_strategy(d),[])
        result=run_backtest(self.candles,d,'TEST')
        self.assertEqual(result['side'],'SELL')
        self.assertTrue(result['total_trades']>=0)

if __name__=='__main__':unittest.main()
