import asyncio
import os
import tempfile
import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
from unittest.mock import patch

from app import db
from app.candle_engine import CandleEngine
from app.credential_manager import CredentialManager
from app.websocket_manager import WebSocketManager


class Phase123UpgradeTests(unittest.TestCase):
    def test_encrypted_credentials_survive_manager_restart(self):
        tmp = tempfile.mkdtemp()
        key = __import__("cryptography.fernet", fromlist=["Fernet"]).Fernet.generate_key().decode()
        cfg = __import__("app.config", fromlist=["config"]).config
        old_key, old_path = cfg.credential_encryption_key, cfg.credential_store_path
        object.__setattr__(cfg, "credential_encryption_key", key)
        object.__setattr__(cfg, "credential_store_path", os.path.join(tmp, "kotak.enc"))
        try:
            a = CredentialManager()
            a.set(consumer_key="ck", mobile_number="9876543210", ucc="U1", mpin="1234", totp_secret="JBSWY3DPEHPK3PXP")
            a.persist()
            b = CredentialManager()
            self.assertTrue(b.load_persisted())
            self.assertTrue(b.has_base_credentials())
            self.assertEqual(b.get().mobile_number, "+919876543210")
        finally:
            object.__setattr__(cfg, "credential_encryption_key", old_key)
            object.__setattr__(cfg, "credential_store_path", old_path)

    def test_candle_volume_is_delta_and_bars_are_ist_buckets(self):
        tmp = tempfile.mkdtemp()
        with patch.object(db, "DB_PATH", os.path.join(tmp, "c.db")):
            with db._connection() as c:
                c.execute("CREATE TABLE candles(exchange_segment TEXT,instrument_token TEXT,trading_symbol TEXT,timeframe TEXT,candle_at TEXT,open REAL,high REAL,low REAL,close REAL,volume REAL,UNIQUE(exchange_segment,instrument_token,timeframe,candle_at))")
            e = CandleEngine(); z = ZoneInfo("Asia/Kolkata")
            e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=100, volume=100, timestamp=datetime(2026,9,24,9,15,tzinfo=z))
            e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=101, volume=110, timestamp=datetime(2026,9,24,9,16,tzinfo=z))
            e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=102, volume=130, timestamp=datetime(2026,9,24,9,20,tzinfo=z))
            rows = db.recent_candles(exchange_segment="nse_cm", instrument_token="1", timeframe="5m", limit=5)
            self.assertEqual(rows[0]["candle_at"], "2026-09-24 09:15:00")
            self.assertEqual(rows[0]["volume"], 10)

    def test_subscription_registry_hard_caps_at_official_sdk_limit(self):
        w = WebSocketManager()
        async def run():
            for i in range(3000):
                await w.subscribe("nse_cm", str(i))
            with self.assertRaises(ValueError):
                await w.subscribe("nse_cm", "3000")
        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
