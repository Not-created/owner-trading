import asyncio
import types
import unittest
from unittest.mock import AsyncMock, patch

from app import broker_client as bc
from app import sdk_adapter as a
from app import websocket_manager as wsm
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.test_order_lifecycle import mk


class FakeFeed:
    def __init__(self):
        self.is_connected = False
        self.subscription_count = 0
        self.subscribed = []
        self.on_message = self.on_error = self.on_connect = self.on_disconnect = None
        self.closed = False
        self.connect_error = None

    async def connect(self):
        if self.connect_error:
            raise self.connect_error
        self.is_connected = True
        if self.on_connect:
            self.on_connect()

    async def close(self):
        self.closed = True
        self.is_connected = False

    async def subscribe_scrips(self, tokens):
        self.subscribed.extend(tokens)
        self.subscription_count += len(tokens)

    async def unsubscribe_scrips(self, tokens):
        self.subscription_count -= len(tokens)


def tick(**kw):
    d = dict(type="scrip", exchange_segment="nse_cm", instrument_token="11915", last_traded_price=20.25,
             trading_symbol="YESBANK-EQ", close_price=19.9, volume_traded_today=1000)
    d.update(kw)
    return types.SimpleNamespace(**d)


class OrderMsg:
    type = "order"

    def __init__(self, row):
        self.data = types.SimpleNamespace(model_dump=lambda by_alias=True: row)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.m = wsm.WebSocketManager()
        self.tok = patch.object(a, "make_ws_token", lambda seg, tok: (seg, tok))
        self.tok.start()
        current_state.transition(BrokerState.CONNECTED)

    async def asyncTearDown(self):
        await self.m.stop()
        self.tok.stop()
        current_state.transition(BrokerState.DISCONNECTED)


class MessageTests(Base):
    async def test_tick_is_persisted_with_symbol_and_close(self):
        self.m._on_market_message(tick())
        (t,) = self.db.latest_market_ticks()
        self.assertEqual((t["instrument_token"], t["last_traded_price"], t["trading_symbol"], t["close_price"]), ("11915", 20.25, "YESBANK-EQ", 19.9))

    async def test_ticks_are_throttled_per_instrument_but_not_across(self):
        self.m._on_market_message(tick(last_traded_price=1.0))
        self.m._on_market_message(tick(last_traded_price=2.0))                          # within 1s: skipped
        self.m._on_market_message(tick(instrument_token="1", last_traded_price=3.0))
        got = {t["instrument_token"]: t["last_traded_price"] for t in self.db.latest_market_ticks()}
        self.assertEqual(got, {"11915": 1.0, "1": 3.0})

    async def test_non_tick_messages_ignored_but_mark_liveness(self):
        self.m._on_market_message(types.SimpleNamespace(type="depth", exchange_segment="nse_cm", instrument_token="1"))
        self.assertEqual(self.db.latest_market_ticks(), [])
        self.assertIsNotNone(self.m._last_market_msg)

    async def test_bad_tick_does_not_raise(self):
        self.m._on_market_message(types.SimpleNamespace(type="scrip", exchange_segment="nse_cm", instrument_token="", last_traded_price=None))

    async def test_order_message_updates_local_order(self):
        mk(self.db)
        with patch.object(self.m, "_schedule_reconcile") as sched:
            self.m._on_order_message(OrderMsg({"nOrdNo": "N1", "GuiOrdId": "OTTAG1", "ordSt": "open", "qty": "100", "fldQty": "30",
                                               "unFldSz": "70", "avgPrc": "20.1", "updRecvTm": "9"}))
        o = self.db.get_order("o1")
        self.assertEqual((o["status"], o["filled_quantity"]), ("PARTIALLY_FILLED", 30))
        sched.assert_called_once()

    async def test_foreign_order_message_is_safe(self):
        with patch.object(self.m, "_schedule_reconcile") as sched:
            self.m._on_order_message(OrderMsg({"nOrdNo": "ZZ", "ordSt": "open"}))
        sched.assert_not_called()

    async def test_malformed_order_message_never_raises(self):
        self.m._on_order_message(types.SimpleNamespace(type="order", data=None))

    async def test_position_message_schedules_reconcile(self):
        with patch.object(self.m, "_schedule_reconcile") as sched:
            self.m._on_order_message(types.SimpleNamespace(type="position"))
        sched.assert_called_once()

    async def test_reconcile_is_debounced(self):
        calls = []
        async def fake():
            calls.append(1)
        with patch("app.reconciliation.run_full_reconciliation", fake), patch.object(asyncio, "sleep", AsyncMock()):
            self.m._schedule_reconcile("a")
            self.m._schedule_reconcile("b")
            await self.m._reconcile_task
        self.assertEqual(len(calls), 1)


class SubscriptionTests(Base):
    async def test_validation_and_registry(self):
        with self.assertRaises(ValueError):
            await self.m.subscribe("NSE", "1")
        await self.m.subscribe("nse_cm", "11915")
        self.assertEqual(self.m.subscriptions(), [{"exchange_segment": "nse_cm", "instrument_token": "11915"}])
        await self.m.unsubscribe("nse_cm", "11915")
        self.assertEqual(self.m.subscriptions(), [])

    async def test_live_subscribe_when_connected(self):
        feed = FakeFeed()
        feed.is_connected = True
        self.m._market = feed
        await self.m.subscribe("nse_cm", "5")
        self.assertEqual(feed.subscribed, [("nse_cm", "5")])

    async def test_market_run_resubscribes_registry_after_new_client(self):
        await self.m.subscribe("nse_cm", "1")
        await self.m.subscribe("nse_fo", "2")
        feed = FakeFeed()
        async def hold(f):
            return
        with patch.object(bc.broker_client, "create_market_feed", return_value=feed), patch.object(self.m, "_hold_until_lost", hold):
            await self.m._run_market()
        self.assertEqual(set(feed.subscribed), {("nse_cm", "1"), ("nse_fo", "2")})
        self.assertTrue(feed.closed)
        self.assertEqual(feed.on_message, self.m._on_market_message)

    async def test_status_shape(self):
        s = self.m.status()
        self.assertEqual(set(s), {"running", "market", "orderFeed"})
        self.assertFalse(s["market"]["connected"])


class SupervisorTests(Base):
    async def test_retries_with_backoff_then_recovers(self):
        attempts = []
        async def runner():
            attempts.append(1)
            if len(attempts) < 3:
                raise ConnectionError("down")
            self.m._stop.set()
        with patch.object(wsm, "BACKOFF_START", 0.01), patch.object(wsm, "BACKOFF_MAX", 0.02):
            await asyncio.wait_for(self.m._supervise("market", runner), 5)
        self.assertEqual(len(attempts), 3)
        self.assertEqual(self.m._reconnects["market"], 3)

    async def test_repeated_failures_probe_the_session(self):
        n = []
        async def runner():
            n.append(1)
            if len(n) >= 4:
                self.m._stop.set()
            raise ConnectionError("down")
        probes = []
        async def probe():
            probes.append(1)
        with patch.object(wsm, "BACKOFF_START", 0.001), patch.object(wsm, "BACKOFF_MAX", 0.002), \
             patch.object(self.m, "_probe_session", probe):
            await asyncio.wait_for(self.m._supervise("order", runner), 5)
        self.assertGreaterEqual(len(probes), 1)

    async def test_no_connection_attempts_without_a_valid_session(self):
        current_state.transition(BrokerState.SESSION_EXPIRED)
        ran = []
        async def runner():
            ran.append(1)
        task = asyncio.create_task(self.m._supervise("market", runner))
        with patch.object(wsm, "BACKOFF_START", 0.01):
            await asyncio.sleep(0.2)
        self.m._stop.set()
        await asyncio.wait_for(task, 5)
        self.assertEqual(ran, [])

    async def test_probe_uses_readonly_limits_and_expires_session_on_auth(self):
        fake = types.SimpleNamespace(read=lambda name: a.Outcome(a.AUTH, message="Invalid session"))
        with patch.object(wsm, "broker_client", fake):
            await self.m._probe_session()      # must not raise
        # real expiry transition is covered in broker_client tests via _after()

    async def test_hold_until_lost_waits_out_sdk_internal_reconnect_then_gives_up(self):
        feed = FakeFeed()
        feed.is_connected = True
        with patch.object(wsm, "LOST_GRACE_SECONDS", 0.5), patch.object(asyncio, "sleep", self._fast_sleep()):
            t = asyncio.create_task(self.m._hold_until_lost(feed))
            await asyncio.sleep(0)
            self.assertFalse(t.done())
            feed.is_connected = False                       # SDK is reconnecting internally
            await asyncio.wait_for(t, 5)                    # gives up after the grace window

    def _fast_sleep(self):
        real = asyncio.sleep
        async def s(x, *a, **k):
            await real(0.01)
        return s

    async def test_short_outage_within_grace_is_tolerated(self):
        feed = FakeFeed()
        feed.is_connected = True
        with patch.object(wsm, "LOST_GRACE_SECONDS", 5), patch.object(asyncio, "sleep", self._fast_sleep()):
            t = asyncio.create_task(self.m._hold_until_lost(feed))
            await asyncio.sleep(0.03)
            feed.is_connected = False
            await asyncio.sleep(0.05)
            feed.is_connected = True                        # SDK reconnected by itself
            await asyncio.sleep(0.05)
            self.assertFalse(t.done())
            self.m._stop.set()
            await asyncio.wait_for(t, 5)

    async def test_order_feed_connect_triggers_reconciliation(self):
        feed = FakeFeed()
        async def hold(f):
            return
        with patch.object(bc.broker_client, "create_order_feed", return_value=feed), patch.object(self.m, "_hold_until_lost", hold), \
             patch.object(self.m, "_schedule_reconcile") as sched:
            await self.m._run_order()
        sched.assert_called_once()
        self.assertTrue(feed.closed)

    async def test_start_and_stop_lifecycle(self):
        current_state.transition(BrokerState.DISCONNECTED)      # supervisors idle harmlessly
        await self.m.start()
        self.assertTrue(self.m.running)
        await self.m.start()                                    # idempotent
        self.assertEqual(len(self.m._tasks), 2)
        await self.m.stop()
        self.assertFalse(self.m.running)

    async def test_stale_detection_is_informational(self):
        feed = FakeFeed()
        feed.is_connected = True
        self.m._market = feed
        self.m._subs[("nse_cm", "1")] = None
        self.m._last_market_msg = 0.0
        self.assertTrue(self.m.is_stale())
        self.m._subs.clear()
        self.assertFalse(self.m.is_stale())


if __name__ == "__main__":
    unittest.main()
