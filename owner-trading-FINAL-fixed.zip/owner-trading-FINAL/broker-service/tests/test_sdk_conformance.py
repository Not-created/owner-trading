import os
import shutil
import tempfile
import unittest

from app import sdk_conformance as c


class StaticConformanceTests(unittest.TestCase):
    def test_vendored_official_source_matches_adapter_signatures(self):
        r = c.check_static()
        self.assertTrue(r.ok, r.errors)
        self.assertEqual(r.checked, len(c.EXPECTED))

    def test_detects_removed_parameter(self):
        tmp = tempfile.mkdtemp()
        src = open(os.path.join(c.VENDOR_DIR, "kotakneoapi", "neo_api_client", "neo_api.py"), encoding="utf-8").read()
        mutated = src.replace('        trigger_price: str | None = "0",\n        tag: str | None = None,\n    ) -> dict[str, Any]:\n        """\n        Places an order',
                              '        trigger_price: str | None = "0",\n    ) -> dict[str, Any]:\n        """\n        Places an order')
        self.assertNotEqual(mutated, src)
        p = os.path.join(tmp, "neo_api.py")
        open(p, "w", encoding="utf-8").write(mutated)
        r = c.check_static(p)
        self.assertFalse(r.ok)
        self.assertTrue(any("place_order" in e and "tag" in e for e in r.errors), r.errors)

    def test_detects_new_required_parameter(self):
        tmp = tempfile.mkdtemp()
        src = open(os.path.join(c.VENDOR_DIR, "kotakneoapi", "neo_api_client", "neo_api.py"), encoding="utf-8").read()
        mutated = src.replace('self, order_id: str, amo: str = "NO", isVerify: bool = False',
                              'self, order_id: str, brand_new: str, amo: str = "NO", isVerify: bool = False')
        self.assertNotEqual(mutated, src)
        p = os.path.join(tmp, "neo_api.py")
        open(p, "w", encoding="utf-8").write(mutated)
        r = c.check_static(p)
        self.assertFalse(r.ok)
        self.assertTrue(any("cancel_order" in e and "REQUIRES" in e for e in r.errors), r.errors)


class VendorIntegrityTests(unittest.TestCase):
    def test_vendored_tree_matches_manifest(self):
        r = c.check_vendor_integrity()
        self.assertTrue(r.ok, r.errors)
        self.assertGreaterEqual(r.checked, 50)

    def test_detects_tampering_and_missing_files(self):
        tmp = tempfile.mkdtemp()
        dst = os.path.join(tmp, "vendor")
        shutil.copytree(c.VENDOR_DIR, dst)
        target = os.path.join(dst, "kotakneoapi", "neo_api_client", "neo_api.py")
        open(target, "a", encoding="utf-8").write("\n# tampered\n")
        os.remove(os.path.join(dst, "kotakneoapi", "LICENSE"))
        r = c.check_vendor_integrity(dst)
        self.assertFalse(r.ok)
        self.assertTrue(any("modified" in e for e in r.errors))
        self.assertTrue(any("missing" in e for e in r.errors))

    def test_version_pin_matches_vendored_package(self):
        from app import sdk_adapter
        ver = open(os.path.join(c.VENDOR_DIR, "kotakneoapi", "neo_api_client", "__version__.py")).read()
        self.assertIn(sdk_adapter.REQUIRED_SDK_VERSION, ver)


if __name__ == "__main__":
    unittest.main()
