import asyncio
import importlib
import os
import sys
from pathlib import Path

import pytest

HERE=Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:sys.path.insert(0,str(HERE.parent))
from .dbutil import fresh_db


def _strategy(db, side="BUY"):
    st=db.create_strategy("chain")
    definition={
        "side":side,"timeframe":"5m",
        "entry":{"op":"AND","conditions":[{"left":"close","operator":">","right":"sma5"}]},
        "exit":{"op":"OR","conditions":[{"left":"rsi14","operator":">","right":90}]},
        "execution":{"product":"MIS"},
        "risk":{"stop_loss_pct":1,"target_pct":2,"partial_exit_pct":50},
        "position_sizing":{"quantity":10},
    }
    v=db.save_strategy_version(st["id"],definition)
    return v,definition


def _order(db, internal, **kw):
    defaults=dict(
        internal_order_id=internal,trading_symbol="ABC",exchange_segment="nse_cm",
        transaction_type="B",order_type="MKT",product="MIS",validity="DAY",
        quantity=10,price=None,trigger_price=None,mode="LIVE",status="SUBMITTED",
        client_tag="TAG"+internal[-4:],instrument_token="123",order_role="ENTRY",
    )
    defaults.update(kw)
    return db.create_order(**defaults)


def test_entry_fill_uses_signal_chain_and_short_is_supported():
    db=fresh_db()
    v,_=_strategy(db,"BUY")
    sid=db.record_signal(strategy_version_id=v["id"],exchange_segment="nse_cm",
        instrument_token="123",trading_symbol="ABC",timeframe="5m",side="BUY",
        signal_price=100,conditions={},risk={},status="DETECTED",candle_at="2026-09-24 10:00:00")
    _order(db,"entry-1",signal_id=sid,transaction_type="B")
    db.apply_trade_to_algo_position("entry-1",10,101,"B")
    ps=db.list_algo_positions()
    assert len(ps)==1 and ps[0]["entry_order_id"]=="entry-1" and ps[0]["remaining_quantity"]==10
    # A different symbol cannot accidentally consume the exit fill.
    _order(db,"exit-1",transaction_type="S",order_role="EXIT",algo_position_id=ps[0]["id"],parent_order_id="entry-1")
    db.apply_trade_to_algo_position("exit-1",5,102,"S")
    assert db.list_algo_positions()[0]["remaining_quantity"]==5


def test_signal_execution_key_is_restart_idempotent():
    db=fresh_db()
    v,_=_strategy(db)
    a=db.record_signal(strategy_version_id=v["id"],exchange_segment="nse_cm",instrument_token="123",
        trading_symbol="ABC",timeframe="5m",side="BUY",signal_price=100,conditions={},risk={},
        candle_at="2026-09-24 10:00:00")
    b=db.record_signal(strategy_version_id=v["id"],exchange_segment="nse_cm",instrument_token="123",
        trading_symbol="ABC",timeframe="5m",side="BUY",signal_price=101,conditions={},risk={},
        candle_at="2026-09-24 10:00:00")
    assert a==b


def test_nested_strategy_and_lot_sizing():
    db=fresh_db()
    import app.strategy_engine as se
    definition={
        "side":"SELL","timeframe":"5m",
        "entry":{"op":"AND","conditions":[{"left":"close","operator":">","right":100}],
                 "groups":[{"op":"OR","conditions":[{"left":"rsi14","operator":">","right":70},{"left":"volume","operator":">","right":10}]}]},
        "exit":{"op":"OR","conditions":[{"left":"close","operator":"<","right":99}]},
        "execution":{"product":"MIS","cooldown_bars":2},
        "risk":{"stop_atr_multiple":2},
        "position_sizing":{"capital_pct":10},
    }
    assert se.validate_strategy(definition)==[]
    assert se.size_position(definition,100,available_funds=100000,lot_size=25)==100


def test_tick_stop_dispatches_exit_without_waiting_for_candle(monkeypatch):
    db=fresh_db()
    v,definition=_strategy(db,"BUY")
    sid=db.record_signal(strategy_version_id=v["id"],exchange_segment="nse_cm",
        instrument_token="123",trading_symbol="ABC",timeframe="5m",side="BUY",
        signal_price=100,conditions={},risk={},status="ORDERED",candle_at="2026-09-24 10:00:00")
    _order(db,"entry-tick",signal_id=sid,transaction_type="B")
    db.apply_trade_to_algo_position("entry-tick",10,100,"B")
    pos=db.list_algo_positions()[0]
    calls=[]
    async def fake_place(payload):
        calls.append(payload)
        return {"internal_order_id":"exit-tick-1","status":"SUBMITTED"}
    import app.exit_engine as ee
    monkeypatch.setattr(ee.order_service,"place_order",fake_place)
    asyncio.run(ee.on_tick(exchange_segment="nse_cm",instrument_token="123",price=98.0))
    assert calls and calls[0]["order_role"]=="EXIT"
    assert calls[0]["algo_position_id"]==pos["id"]
    assert calls[0]["transaction_type"]=="S"
