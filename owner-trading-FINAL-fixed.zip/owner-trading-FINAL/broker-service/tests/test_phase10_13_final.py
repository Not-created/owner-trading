import os,re,subprocess,sys
from pathlib import Path
import pytest
from .dbutil import fresh_db

ROOT=Path(__file__).resolve().parents[2]

def read(*p):return (ROOT.joinpath(*p)).read_text(encoding='utf-8')

def test_entry_order_chain_is_required_and_persisted():
    db=fresh_db()
    st=db.create_strategy('chain-final'); d={'side':'BUY','timeframe':'5m','entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':'sma5'}]},'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':'sma5'}]},'execution':{'product':'MIS'},'position_sizing':{'quantity':1}}
    v=db.save_strategy_version(st['id'],d); sid=db.record_signal(strategy_version_id=v['id'],exchange_segment='nse_cm',instrument_token='1',trading_symbol='ABC',timeframe='5m',side='BUY',signal_price=100,conditions={},risk={},candle_at='2026-09-24 10:00:00')
    oid=db.create_order(internal_order_id='entry-final',trading_symbol='ABC',exchange_segment='nse_cm',transaction_type='B',order_type='MKT',product='MIS',validity='DAY',quantity=1,price=None,trigger_price=None,mode='LIVE',status='SUBMITTED',client_tag='TAGFINAL',instrument_token='1',signal_id=sid,order_role='ENTRY')
    db.apply_trade_to_algo_position('entry-final',1,100,'B')
    chain=db.execution_chain('entry-final')
    assert chain['signal']['id']==sid and chain['position']['entry_order_id']=='entry-final'

def test_new_order_gate_excludes_its_own_durable_submission_row():
    import os
    import app.broker_client as bc
    from app.state import BrokerState, current_state
    db=fresh_db(); db.set_live_armed(True); db.record_funds_snapshot(available_margin=1000,used_margin=0,raw={},realized_mtom=0,unrealized_mtom=0); rid=db.begin_reconciliation_run(); db.finish_reconciliation_run(rid,status='COMPLETE',discrepancy_count=0,sections_ok=True,details={})
    db.create_order(internal_order_id='self-order',trading_symbol='ABC',exchange_segment='nse_cm',transaction_type='B',order_type='MKT',product='MIS',validity='DAY',quantity=1,price=None,trigger_price=None,mode='LIVE',status='SUBMITTING',client_tag='TAGSELF',instrument_token='1')
    os.environ['BROKER_SERVICE_TOKEN']='x'*32; current_state.transition(BrokerState.CONNECTED)
    try: bc.assert_live_trading_allowed(exclude_internal_order_id='self-order')
    except Exception as exc: raise AssertionError(exc)

def test_pending_submission_blocks_live_readiness():
    db=fresh_db(); db.create_order(internal_order_id='pending-1',trading_symbol='ABC',exchange_segment='nse_cm',transaction_type='B',order_type='MKT',product='MIS',validity='DAY',quantity=1,price=None,trigger_price=None,mode='LIVE',status='SUBMITTING',client_tag='TAGPENDING',instrument_token='1')
    import app.live_readiness as lr
    g=next(x for x in lr.evaluate()['gates'] if x['id']=='no_pending_submission_reconciliation')
    assert not g['ok']

def test_reconciliation_run_requires_clean_sections():
    db=fresh_db(); rid=db.begin_reconciliation_run(); db.finish_reconciliation_run(rid,status='DISCREPANCY',discrepancy_count=1,sections_ok=False,details={'x':1}); rr=db.latest_reconciliation_run(); assert rr['status']=='DISCREPANCY' and not rr['sections_ok']

def test_frontend_new_routes_are_mounted():
    app=read('backend','src','app.js'); assert 'finalAuditRoutes' in app and '/api/final-audit' in app
    algo=read('backend','src','routes','algo.js'); assert '/execution-chain' in algo
    client=read('frontend','src','api','client.js'); assert '/api/algo/execution-chain' in client and '/api/final-audit' in client

def test_no_legacy_paper_simulator_executable_paths():
    for rel in ('broker-service/app','backend/src','frontend/src'):
        for p in (ROOT/rel).rglob('*'):
            if p.suffix in ('.py','.js','.jsx'):
                t=p.read_text(errors='ignore').lower()
                assert not re.search(r'(?:from|import)\s+[\w.]*?(?:paper|simulator)|\b(?:PAPER|SIMULATOR|SIMULATED)\s*(?:==|!=|in|not\s+in)', t, re.I), str(p)


def test_vendor_integrity_is_blocking_in_live_gate():
    import app.broker_client as bc
    from app.state import BrokerState, current_state
    from unittest.mock import patch
    db=fresh_db(); db.set_live_armed(True); db.record_funds_snapshot(available_margin=1000,used_margin=0,raw={},realized_mtom=0,unrealized_mtom=0)
    rid=db.begin_reconciliation_run(); db.finish_reconciliation_run(rid,status='COMPLETE',discrepancy_count=0,sections_ok=True,details={})
    current_state.transition(BrokerState.CONNECTED)
    with patch('app.broker_client.sdk_conformance.check_vendor_integrity', return_value=type('R',(),{'ok':False,'errors':['tampered']})()):
        try: bc.assert_live_trading_allowed(exclude_internal_order_id='x')
        except bc.LiveTradingBlockedError as e: assert 'integrity' in str(e).lower()
        else: raise AssertionError('vendor tamper must block LIVE')

def test_emergency_stop_blocks_entry_but_not_controlled_exit_gate():
    import app.broker_client as bc
    from app.state import BrokerState, current_state
    from unittest.mock import patch
    db=fresh_db(); db.set_live_armed(True); db.record_funds_snapshot(available_margin=1000,used_margin=0,raw={},realized_mtom=0,unrealized_mtom=0)
    rid=db.begin_reconciliation_run(); db.finish_reconciliation_run(rid,status='COMPLETE',discrepancy_count=0,sections_ok=True,details={})
    current_state.transition(BrokerState.CONNECTED)
    with patch.object(db,'is_emergency_stop_active',return_value=True), patch('app.broker_client.sdk_conformance.check_vendor_integrity', return_value=type('R',(),{'ok':True,'errors':[]})()):
        try: bc.assert_live_trading_allowed(exclude_internal_order_id='x')
        except bc.LiveTradingBlockedError: pass
        else: raise AssertionError('entry must be blocked by emergency stop')
        bc.assert_live_trading_allowed(exclude_internal_order_id='x', allow_controlled_exit=True)
