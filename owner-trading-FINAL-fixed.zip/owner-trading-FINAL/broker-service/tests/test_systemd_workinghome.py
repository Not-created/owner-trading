"""Empirically verifies the exact kernel mechanism the P0 502 fix depends on:
that ReadOnlyPaths=/ReadWritePaths= in the systemd unit templates correctly
re-expose WorkingDirectory (and only the intended data directories) when
ProtectHome=true hides /home -- the root cause of

    "Changing to the requested working directory failed: Permission denied"
    "Failed at step CHDIR spawning /usr/bin/node"

reported when this project is deployed under /home/<user>/... instead of /opt.

This does NOT start systemd or the real services -- there is no live systemd
instance in most sandboxes/CI. It reproduces the underlying Linux mount-
namespace primitives systemd itself uses (tmpfs over /home for ProtectHome=
true, then bind-mounts for ReadOnlyPaths=/ReadWritePaths=, in the same
"later wins" order systemd.exec(5) documents) directly with `unshare`+`mount`,
against a throwaway directory tree that mimics a /home/<user>/... deployment,
and a real low-privilege test user with no relationship to the tree's owner
-- exactly like the dedicated `owner-trading` system user.

Skips (does not fail) unless run as root with a kernel that supports mount
namespaces, since that is required to test real namespace behaviour at all;
this is satisfied by deploy.sh's own test run (root, on the target host, as
part of every `sudo ./deploy.sh`), which is where this test earns its keep.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
UNIT_FILES = {
    "backend": os.path.join(ROOT, "deployment", "systemd", "owner-trading-backend.service"),
    "broker": os.path.join(ROOT, "deployment", "systemd", "owner-trading-broker.service"),
}
TEST_USER = "ot-nstest"


def _parse_unit(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    def grab(key):
        m = re.search(rf"^{key}=(.*)$", text, re.MULTILINE)
        return m.group(1).strip() if m else None
    return {
        "WorkingDirectory": grab("WorkingDirectory"),
        "ProtectHome": grab("ProtectHome"),
        "ProtectSystem": grab("ProtectSystem"),
        "ReadOnlyPaths": (grab("ReadOnlyPaths") or "").split(),
        "ReadWritePaths": (grab("ReadWritePaths") or "").split(),
    }


def _can_test_namespaces() -> tuple[bool, str]:
    if os.geteuid() != 0:
        return False, "not running as root"
    if shutil.which("unshare") is None or shutil.which("mount") is None or shutil.which("runuser") is None:
        return False, "unshare/mount/runuser not available"
    probe = subprocess.run(["unshare", "--mount", "--pid", "--fork", "--", "true"], capture_output=True, text=True)
    if probe.returncode != 0:
        return False, f"unprivileged mount namespaces unavailable here: {probe.stderr.strip()[:200]}"
    return True, ""


SKIP, SKIP_REASON = _can_test_namespaces()


def _ensure_test_user() -> None:
    if subprocess.run(["id", TEST_USER], capture_output=True).returncode != 0:
        subprocess.run(["useradd", "--system", "--no-create-home", "--shell", "/usr/sbin/nologin", TEST_USER], check=True)


def _run_ns_script(script: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["unshare", "--mount", "--pid", "--fork", "--", "bash", "-eo", "pipefail", "-c", script],
        capture_output=True, text=True, timeout=30,
    )


@unittest.skipUnless(SKIP, SKIP_REASON if not SKIP else "")
class ProtectHomeReadOnlyPathsTests(unittest.TestCase):
    """Reproduces the fix's mechanism for a project living under /home/<user>/...,
    which is exactly this task's reported production layout."""

    @classmethod
    def setUpClass(cls):
        _ensure_test_user()

    def _build_tree(self, home_root: str, project_root: str, service_key: str) -> dict:
        """Lays out a fake /home/<user>/.../<project> tree matching the unit's
        WorkingDirectory + ReadWritePaths (with /opt substituted for home_root's
        project_root), owned by a neutral non-test, non-root user (root here,
        simulating "whoever ran deploy.sh" -- never owner-trading)."""
        unit = _parse_unit(UNIT_FILES[service_key])
        sub = lambda p: p.replace("/opt/owner-trading", os.path.join(home_root, project_root))
        working_dir = sub(unit["WorkingDirectory"])
        ro_paths = [sub(p) for p in unit["ReadOnlyPaths"]]
        rw_paths = [sub(p) for p in unit["ReadWritePaths"]]
        self.assertTrue(ro_paths, f"{service_key}: unit has no ReadOnlyPaths -- the fix regressed")
        self.assertIn(working_dir, ro_paths, f"{service_key}: WorkingDirectory {working_dir} is not covered by ReadOnlyPaths {ro_paths}")
        os.makedirs(working_dir, mode=0o755, exist_ok=True)
        marker = os.path.join(working_dir, "marker.txt")
        with open(marker, "w", encoding="utf-8") as fh:
            fh.write("real content\n")
        for p in rw_paths:
            os.makedirs(p, mode=0o755, exist_ok=True)
            # deploy.sh chowns exactly these data/secure directories to owner-trading:owner-trading
            # before the service starts; replicate that so the test proves the mount mechanism,
            # not an unrelated ownership gap in the test fixture itself.
            subprocess.run(["chown", "-R", f"{TEST_USER}:{TEST_USER}", p], check=True)
        # A sibling under the same fake /home that nothing re-exposes -- must stay hidden.
        sibling = os.path.join(home_root, "someoneelse", "secrets")
        os.makedirs(sibling, exist_ok=True)
        with open(os.path.join(sibling, "s.txt"), "w", encoding="utf-8") as fh:
            fh.write("do not read\n")
        return {"working_dir": working_dir, "ro_paths": ro_paths, "rw_paths": rw_paths, "marker": marker, "sibling": sibling}

    def _protecthome_script(self, home_root: str, t: dict) -> str:
        """Builds the exact mount sequence: save a live reference to each real
        path BEFORE the tmpfs hides /home (systemd keeps this open internally;
        `unshare`+`mount` needs it done explicitly), then tmpfs over /home
        (ProtectHome=true), then re-apply in systemd's documented order:
        ReadOnlyPaths first, ReadWritePaths after (later wins on overlap)."""
        lines = ["set -e"]
        refs = {}
        for i, p in enumerate(dict.fromkeys(t["ro_paths"] + t["rw_paths"])):
            ref = f"/root/.ref{i}"
            refs[p] = ref
            lines.append(f"mkdir -p {ref}")
            lines.append(f"mount --bind {p} {ref}")
        lines.append(f"mount -t tmpfs tmpfs {home_root}")
        for p in t["ro_paths"]:
            lines.append(f"mkdir -p {p}")
            lines.append(f"mount --bind {refs[p]} {p}")
            lines.append(f"mount -o remount,bind,ro {p}")
        for p in t["rw_paths"]:
            lines.append(f"mkdir -p {p}")
            lines.append(f"mount --bind {refs[p]} {p}")
        return "\n".join(lines)

    def _assert_fix_works(self, service_key: str):
        with tempfile.TemporaryDirectory(prefix="ot-ns-") as tmp:
            os.chmod(tmp, 0o755)  # mkdtemp defaults to 0700; irrelevant to the fix itself, just needed so the test's own scaffolding doesn't block traversal
            home_root = os.path.join(tmp, "home")
            os.makedirs(home_root, mode=0o755)
            t = self._build_tree(home_root, "ubuntu/owner-trading/owner-trading", service_key)
            mounts = self._protecthome_script(home_root, t)
            rw_dir = t["rw_paths"][0]
            script = f'''
{mounts}
runuser -u {TEST_USER} -- bash -c "
  cd {t['working_dir']} && echo NS_CHDIR_OK &&
  cat marker.txt &&
  (echo x > should_fail 2>&1 || echo NS_RO_BLOCKED) &&
  echo written > {rw_dir}/w.txt && cat {rw_dir}/w.txt &&
  (cat {t['sibling']}/s.txt 2>&1 || echo NS_SIBLING_HIDDEN)
"
'''
            res = _run_ns_script(script)
            out = res.stdout + res.stderr
            self.assertEqual(res.returncode, 0, f"{service_key}: namespace script failed:\n{out}")
            self.assertIn("NS_CHDIR_OK", out, f"{service_key}: CHDIR into WorkingDirectory failed under simulated ProtectHome=true -- this is the exact reported P0 bug.\n{out}")
            self.assertIn("real content", out, f"{service_key}: WorkingDirectory content unreadable.\n{out}")
            self.assertIn("NS_RO_BLOCKED", out, f"{service_key}: the read-only tree accepted a write -- hardening regressed.\n{out}")
            self.assertIn("written", out, f"{service_key}: the designated data directory ({rw_dir}) was not writable.\n{out}")
            self.assertIn("NS_SIBLING_HIDDEN", out, f"{service_key}: an unrelated /home sibling was readable -- ProtectHome is not actually isolating other directories.\n{out}")

    def test_backend_workingdirectory_survives_protecthome_under_home(self):
        self._assert_fix_works("backend")

    def test_broker_workingdirectory_survives_protecthome_under_home(self):
        self._assert_fix_works("broker")

    def test_without_the_fix_chdir_would_fail(self):
        """Negative control: prove the failure mode is real by omitting
        ReadOnlyPaths entirely (i.e. simulating the unit as it was before this
        fix) and confirming CHDIR fails exactly as the reported journal error
        describes."""
        with tempfile.TemporaryDirectory(prefix="ot-ns-neg-") as tmp:
            home_root = os.path.join(tmp, "home")
            working_dir = os.path.join(home_root, "ubuntu", "owner-trading", "owner-trading", "backend")
            os.makedirs(working_dir, mode=0o755)
            script = f"mount -t tmpfs tmpfs {home_root}\n"
            res = _run_ns_script(script + f'runuser -u {TEST_USER} -- bash -c "cd {working_dir}"')
            self.assertNotEqual(res.returncode, 0, "CHDIR unexpectedly succeeded without ReadOnlyPaths -- the negative control is invalid.")

    @classmethod
    def tearDownClass(cls):
        subprocess.run(["userdel", TEST_USER], capture_output=True)


if __name__ == "__main__":
    unittest.main()
