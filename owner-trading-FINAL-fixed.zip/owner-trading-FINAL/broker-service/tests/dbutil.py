"""Test helper: a real temporary SQLite DB migrated with ALL project migrations."""
import glob
import importlib
import os
import sqlite3
import tempfile

MIGRATIONS = os.path.join(os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations")


def fresh_db():
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "test.db")
    conn = sqlite3.connect(path)
    for f in sorted(glob.glob(os.path.join(MIGRATIONS, "*.sql"))):
        with open(f, encoding="utf-8") as fh:
            conn.executescript(fh.read())
    conn.commit()
    conn.close()
    os.environ["DB_PATH"] = path
    from app import db as db_module
    importlib.reload(db_module)
    return db_module
