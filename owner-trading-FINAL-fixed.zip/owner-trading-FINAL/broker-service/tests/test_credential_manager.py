import unittest

from app.credential_manager import (
    CredentialFormatError,
    CredentialManager,
    normalize_totp_secret,
)


class WhitespaceNormalizationTests(unittest.TestCase):
    """Point: credentials with accidental surrounding whitespace must be
    normalized before authentication -- never sent to Kotak (or rejected)
    with stray spaces still attached."""

    def setUp(self):
        self.cm = CredentialManager()

    def test_consumer_key_ucc_mpin_are_trimmed(self):
        self.cm.set(consumer_key="  ck123  ", mobile_number="9999999999", ucc="  U1  ",
                    mpin=" 1234 ", totp_secret="JBSWY3DPEHPK3PXP")
        c = self.cm.get()
        self.assertEqual(c.consumer_key, "ck123")
        self.assertEqual(c.ucc, "U1")
        self.assertEqual(c.mpin, "1234")

    def test_mobile_number_with_surrounding_whitespace_is_normalized(self):
        self.cm.set(consumer_key="ck", mobile_number="  9876543210  ", ucc="U1",
                    mpin="1234", totp_secret="JBSWY3DPEHPK3PXP")
        self.assertEqual(self.cm.get().mobile_number, "+919876543210")

    def test_totp_secret_surrounding_whitespace_and_internal_spaces_are_stripped(self):
        self.cm.set(consumer_key="ck", mobile_number="9876543210", ucc="U1", mpin="1234",
                    totp_secret="  JBSW Y3DP EHPK 3PXP  ")
        self.assertEqual(self.cm.get().totp_secret, "JBSWY3DPEHPK3PXP")

    def test_mpin_with_whitespace_still_validated_after_trim(self):
        with self.assertRaises(CredentialFormatError):
            self.cm.set(consumer_key="ck", mobile_number="9876543210", ucc="U1",
                        mpin="  12  ", totp_secret="JBSWY3DPEHPK3PXP")  # 2 digits after trim: invalid


class TotpSecretValidationTests(unittest.TestCase):
    """Points: the TOTP field must hold the setup *secret*, never a live
    6-digit code; an otpauth:// URI is safely parsed or clearly rejected;
    the secret's actual value is never altered semantically."""

    def test_bare_base32_secret_is_accepted_unchanged_in_value(self):
        self.assertEqual(normalize_totp_secret("JBSWY3DPEHPK3PXP"), "JBSWY3DPEHPK3PXP")

    def test_lowercase_base32_is_uppercased_not_rejected(self):
        self.assertEqual(normalize_totp_secret("jbswy3dpehpk3pxp"), "JBSWY3DPEHPK3PXP")

    def test_otpauth_uri_extracts_secret(self):
        uri = "otpauth://totp/Kotak:UCC1?secret=JBSWY3DPEHPK3PXP&issuer=Kotak"
        self.assertEqual(normalize_totp_secret(uri), "JBSWY3DPEHPK3PXP")

    def test_otpauth_uri_without_secret_param_is_rejected_clearly(self):
        with self.assertRaises(CredentialFormatError):
            normalize_totp_secret("otpauth://totp/Kotak:UCC1?issuer=Kotak")

    def test_live_6_digit_code_is_rejected_not_silently_accepted(self):
        with self.assertRaises(CredentialFormatError) as ctx:
            normalize_totp_secret("123456")
        self.assertIn("live 6-digit", str(ctx.exception))

    def test_live_8_digit_code_is_also_rejected(self):
        with self.assertRaises(CredentialFormatError):
            normalize_totp_secret("12345678")

    def test_non_base32_characters_are_rejected(self):
        with self.assertRaises(CredentialFormatError):
            normalize_totp_secret("not-a-valid-secret-!!!")

    def test_empty_secret_is_rejected(self):
        with self.assertRaises(CredentialFormatError):
            normalize_totp_secret("   ")


if __name__ == "__main__":
    unittest.main()
