"""Static checks of the HTTP + HTTPS deployment files (nginx is not installed in CI, so these assert
the properties that matter directly on the templates and on deploy.sh)."""
import os
import re
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as fh:
        return fh.read()


def code(text):
    return "\n".join(l for l in text.splitlines() if not l.strip().startswith("#"))


class NginxTemplateTests(unittest.TestCase):
    def test_http_block_redirects_to_https_for_live_control(self):
        http = code(read("deployment", "nginx", "owner-trading.http.conf"))
        self.assertIn("listen 80 default_server", http)
        self.assertNotIn("return 302", http)
        self.assertNotIn("rewrite", http)
        self.assertIn("/.well-known/acme-challenge/", http)
        self.assertIn("location / {", http)
        self.assertIn("return 301 https://$host$request_uri;", http)

    def test_https_block_has_tls_and_shares_the_same_locations(self):
        https = code(read("deployment", "nginx", "owner-trading.https.conf"))
        self.assertIn("listen 443 ssl", https)
        self.assertIn("ssl_certificate", https)
        self.assertIn("__CERT__", https)
        self.assertIn("__KEY__", https)
        self.assertIn("TLSv1.2 TLSv1.3", https)
        self.assertNotIn("TLSv1.0", https)
        self.assertIn("include snippets/owner-trading-locations.conf", https)   # identical behaviour on both ports

    def test_every_proxying_location_forwards_scheme_host_and_client_ip(self):
        loc = code(read("deployment", "nginx", "owner-trading-locations.conf"))
        proxy = code(read("deployment", "nginx", "owner-trading-proxy.conf"))
        # nginx does not inherit proxy_set_header into a location that sets its own: each proxying
        # location must include the proxy snippet (which carries all the headers).
        blocks = re.findall(r"location [^{]+\{(.*?)\n\}", loc, flags=re.S)
        proxying = [b for b in blocks if "proxy_pass" in b or "owner-trading-proxy.conf" in b]
        self.assertGreaterEqual(len(proxying), 3)
        for b in proxying:
            self.assertIn("include snippets/owner-trading-proxy.conf", b)
            self.assertNotIn("proxy_set_header", b, "a location-level proxy_set_header would drop the inherited headers")
        for h in ("Host              $host", "X-Real-IP         $remote_addr", "X-Forwarded-For   $proxy_add_x_forwarded_for", "X-Forwarded-Proto $scheme"):
            self.assertIn(h, proxy)

    def test_http_forces_https_and_no_hsts_header_is_emitted(self):
        for f in ("owner-trading-locations.conf", "owner-trading.http.conf", "owner-trading.https.conf", "owner-trading-proxy.conf"):
            self.assertNotIn("Strict-Transport-Security", code(read("deployment", "nginx", f)))

    def test_login_endpoint_is_rate_limited_and_secrets_paths_denied(self):
        loc = code(read("deployment", "nginx", "owner-trading-locations.conf"))
        self.assertRegex(loc, r"location = /api/auth/login \{[^}]*limit_req zone=ot_login")
        self.assertIn("deny all", loc)
        self.assertIn("limit_req_zone", read("deployment", "nginx", "owner-trading-zones.conf"))

    def test_old_bootstrap_template_is_gone(self):
        self.assertFalse(os.path.exists(os.path.join(ROOT, "deployment", "nginx", "owner-trading.bootstrap.conf")))
        self.assertFalse(os.path.exists(os.path.join(ROOT, "deployment", "nginx", "owner-trading.conf")))


class SystemdWorkingDirectoryUnderHomeTests(unittest.TestCase):
    """Static checks for the P0 502 fix (CHDIR under ProtectHome=true when deployed
    under /home/<user>/...). The runtime mechanism itself is verified empirically
    in test_systemd_workinghome.py (real mount namespaces); these are the
    lightweight, always-runnable static complements."""

    def _unit(self, name):
        return read("deployment", "systemd", f"owner-trading-{name}.service")

    def test_protecthome_still_true_in_both_units(self):
        """The fix must not "solve" this by disabling hardening."""
        for name in ("backend", "broker"):
            self.assertIn("ProtectHome=true", code(self._unit(name)), f"{name}: ProtectHome must remain true")

    def test_readonlypaths_covers_each_units_own_workingdirectory(self):
        for name in ("backend", "broker"):
            unit = self._unit(name)
            wd = re.search(r"^WorkingDirectory=(.*)$", unit, re.MULTILINE).group(1).strip()
            ro = re.search(r"^ReadOnlyPaths=(.*)$", unit, re.MULTILINE)
            self.assertIsNotNone(ro, f"{name}: no ReadOnlyPaths= line -- WorkingDirectory will be hidden by ProtectHome under /home")
            self.assertIn(wd, ro.group(1).split(), f"{name}: ReadOnlyPaths does not list WorkingDirectory ({wd})")

    def test_readwritepaths_unchanged_and_still_more_specific_than_readonlypaths(self):
        """ReadWritePaths must remain a subtree of (not equal to) the read-only root,
        so source/vendor stay read-only and only data/secure directories are writable."""
        for name, expect_rw in (("backend", ["/opt/owner-trading/backend/data", "/opt/owner-trading/backend/src/data/secure"]),
                                ("broker", ["/opt/owner-trading/broker-service/data", "/opt/owner-trading/backend/data", "/var/lib/owner-trading"])):
            unit = self._unit(name)
            rw = re.search(r"^ReadWritePaths=(.*)$", unit, re.MULTILINE).group(1).split()
            self.assertEqual(rw, expect_rw, f"{name}: ReadWritePaths changed unexpectedly")
            ro = re.search(r"^ReadOnlyPaths=(.*)$", unit, re.MULTILINE).group(1).split()
            for p in rw:
                self.assertFalse(p in ro, f"{name}: {p} should be a subtree of ReadOnlyPaths, not equal to it")
                nested_locally = any(p.startswith(r + "/") for r in ro)
                # The broker also writes the shared backend/data DB, which is legitimately
                # outside its own ReadOnlyPaths (it doesn't otherwise read the backend tree).
                is_known_cross_service_path = name == "broker" and p in ("/opt/owner-trading/backend/data", "/var/lib/owner-trading")
                self.assertTrue(nested_locally or is_known_cross_service_path,
                               f"{name}: {p} is not nested under any ReadOnlyPaths entry {ro}")

    def test_deploy_uses_opt_runtime_root_with_protecthome(self):
        s = read("deploy.sh")
        self.assertIn('RUNTIME_ROOT="${RUNTIME_ROOT:-/opt/owner-trading}"', s)
        self.assertIn('rsync -a --delete', s)
        self.assertIn("Keep production services outside /home", s)

    def test_deploy_sh_verifies_effective_readonlypaths_and_chdir_regression(self):
        s = read("deploy.sh")
        block = s[s.index("Verifying effective systemd configuration"):s.index("Verifying backend and broker respond locally")]
        self.assertIn("ReadOnlyPaths", block)
        self.assertIn("ReadWritePaths", block)
        self.assertIn("ProtectHome", block)
        self.assertIn("CHDIR", block)
        self.assertIn("systemctl show", block)

    def test_deploy_does_not_reexpose_home_under_protecthome(self):
        s = read("deploy.sh")
        self.assertNotIn("chmod o+rx", s)
        self.assertIn("RUNTIME_ROOT", s)

    def test_deploy_sh_checks_nginx_upstream_for_502_before_login_verification(self):
        s = read("deploy.sh")
        nginx_check = s.index("Verifying Nginx upstream connectivity")
        login_check = s.index('info "Verifying login')
        self.assertLess(nginx_check, login_check)
        block = s[nginx_check:login_check]
        self.assertIn("502", block)

    def test_verify_deployment_checks_chdir_and_protecthome(self):
        s = read("deployment", "verify-deployment.sh")
        self.assertIn("CHDIR", s)
        self.assertIn("ReadOnlyPaths", s)
        self.assertIn("ProtectHome", s)


class DeployScriptTests(unittest.TestCase):
    def setUp(self):
        self.s = read("deploy.sh")

    def test_installs_all_nginx_pieces_and_never_fails_without_domain_or_certificate(self):
        for f in ("owner-trading-zones.conf", "owner-trading-proxy.conf", "owner-trading-locations.conf", "owner-trading.http.conf", "owner-trading.https.conf"):
            self.assertIn(f, self.s)
        block = self.s[self.s.index("Nginx reverse proxy"):self.s.index("Health checks")]
        # LIVE deployment always provisions HTTPS: Let's Encrypt for a DNS name,
        # or a self-signed IP bootstrap certificate for a one-click bare VPS deployment.
        self.assertIn("self-signed HTTPS certificate", block)
        self.assertIn("certbot could not issue", block)
        self.assertIn("HTTP -> HTTPS redirect", block)

    def test_http_verification_flow_sends_no_forwarded_proto_header(self):
        """The plain-HTTP verification must be real HTTP -- the https header is only ever used on the flow labelled as the HTTPS simulation."""
        lines = [l for l in self.s.splitlines() if l.strip().startswith('session_flow "')]
        http_direct = [l for l in lines if l.startswith('  session_flow "HTTP  -> Express')][0]
        self.assertNotIn("X-Forwarded-Proto", http_direct)
        self.assertNotIn("HTTP  -> nginx", "\n".join(lines))
        https_sim = [l for l in lines if "HTTPS -> Express" in l][0]
        self.assertIn("X-Forwarded-Proto: https", https_sim)
        self.assertIn("simulated", https_sim)
        real_tls = [l for l in lines if "real TLS" in l][0]
        self.assertIn("https://${DOMAIN}", real_tls)
        self.assertIn("-k", self.s)  # IP bootstrap uses -k only for the local self-signed certificate

    def test_verification_checks_cookie_attributes_session_protected_api_and_logout(self):
        f = self.s[self.s.index("session_flow() {"):self.s.index('if [ -n "$NEW_PW" ]; then\n  info "Verifying login')]
        for needle in ("httponly", "samesite=lax", "; *secure", "/api/auth/session", "/api/risk", "/api/auth/logout", "after logout"):
            self.assertIn(needle, f)

    def test_password_never_passed_on_a_command_line(self):
        self.assertIn("--data-binary @-", self.s)
        self.assertNotIn("-d \"$LOGIN_JSON\"", self.s)

    def test_project_password_policy_not_changed(self):
        self.assertNotIn("at least 12", self.s)

    def test_cookie_policy_default_written_and_used(self):
        self.assertIn("SESSION_COOKIE_SECURE true", self.s)
        self.assertIn("COOKIE_POLICY", self.s)


class ExpressWiringTests(unittest.TestCase):
    def test_app_uses_config_driven_cookie_not_hardcoded_production_flag(self):
        app = read("backend", "src", "app.js")
        self.assertNotIn('secure: config.env === "production"', app)
        self.assertIn("buildSessionCookieOptions(config)", app)
        self.assertIn('app.set("trust proxy", 1)', app)
        self.assertNotIn("secure: false", app)
        sc = read("backend", "src", "config", "sessionCookie.js")
        self.assertIn("httpOnly: true", sc)
        self.assertIn('sameSite: "lax"', sc)
        self.assertNotIn("secure: false", sc)

    def test_session_secret_and_lifetime_preserved(self):
        app = read("backend", "src", "app.js")
        self.assertIn("secret: config.sessionSecret", app)
        cfg = read("backend", "src", "config", "index.js")
        self.assertIn('SESSION_MAX_AGE_MS || "43200000"', cfg)

    def test_frontend_uses_same_origin_relative_api_and_sends_cookies(self):
        client = read("frontend", "src", "api", "client.js")
        self.assertIn('credentials: "include"', client)
        self.assertNotRegex(client, r"https?://")
        for dp, _, fs in os.walk(os.path.join(ROOT, "frontend", "src")):
            for f in fs:
                if f.endswith((".js", ".jsx")):
                    src = read(os.path.relpath(os.path.join(dp, f), ROOT))
                    self.assertNotRegex(re.sub(r"xmlns=\"http://www\.w3\.org/2000/svg\"", "", src), r"fetch\(\s*[\"'`]https?://", f)


if __name__ == "__main__":
    unittest.main()
