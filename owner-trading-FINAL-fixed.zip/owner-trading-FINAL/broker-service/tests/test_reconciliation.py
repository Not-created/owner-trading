import unittest

from app import broker_client as bc
from app import reconciliation as rec
from app import sdk_adapter as a
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI
from tests.test_order_lifecycle import mk

# Shapes copied from the official docs (docs/functions/orders + portfolio)
ORDER_ROW = {"nOrdNo": "N1", "GuiOrdId": "OTTAG1", "ordSt": "open", "qty": "100", "fldQty": "40", "unFldSz": "60", "avgPrc": "20.10",
             "trdSym": "YESBANK-EQ", "exSeg": "nse_cm", "trnsTp": "B", "prod": "CNC"}
TRADE_ROW = {"nOrdNo": "N1", "flId": "F1", "fldQty": "40", "avgPrc": "20.10", "trdSym": "YESBANK-EQ", "exSeg": "nse_cm",
             "trnsTp": "B", "prod": "CNC", "GuiOrdId": "OTTAG1"}
POS_ROW = {"trdSym": "YESBANK-EQ", "exSeg": "nse_cm", "prod": "CNC", "tok": "11915", "cfBuyQty": "0", "flBuyQty": "40", "cfSellQty": "0",
           "flSellQty": "0", "cfBuyAmt": "0", "buyAmt": "804.00", "cfSellAmt": "0", "sellAmt": "0", "lotSz": "1", "multiplier": "1",
           "genNum": "1", "genDen": "1", "prcNum": "1", "prcDen": "1"}
LIMITS = {"stat": "Ok", "stCode": 200, "Net": "90000.00", "MarginUsed": "804.00", "CashRlsMtomPrsnt": "0", "CashUnRlsMtomPrsnt": "3.5"}


class ReconBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.sdk = a.KotakSdk("ck", "prod", neo_factory=FakeNeoAPI)
        self.neo = self.sdk._neo
        self.sdk.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1")
        bc.broker_client._sdk = self.sdk
        current_state.transition(BrokerState.CONNECTED)
        self.neo.responses.update({
            "order_report": {"stat": "Ok", "stCode": 200, "data": [ORDER_ROW]},
            "trade_report": {"stat": "ok", "stCode": 200, "data": [TRADE_ROW]},
            "positions": {"stat": "Ok", "stCode": 200, "data": [POS_ROW]},
            "holdings": {"data": [{"displaySymbol": "TCS", "quantity": 2, "averagePrice": 3500, "closingPrice": 3600, "instrumentToken": 11536, "exchangeSegment": "nse_cm"}]},
            "limits": LIMITS,
        })

    async def asyncTearDown(self):
        bc.broker_client._sdk = None
        current_state.transition(BrokerState.DISCONNECTED)


class ReconciliationTests(ReconBase):
    async def test_full_pass_syncs_orders_fills_positions_holdings_funds(self):
        mk(self.db)
        r = await rec.run_full_reconciliation()
        self.assertEqual(r["discrepancies"], [])
        o = self.db.get_order("o1")
        self.assertEqual((o["status"], o["filled_quantity"], o["average_price"]), ("PARTIALLY_FILLED", 40, 20.10))
        self.assertEqual(len(self.db.list_trades(mode="LIVE")), 1)
        (p,) = self.db.latest_positions_snapshot()
        self.assertEqual((p["quantity"], p["instrument_token"], p["buy_amount"]), (40, "11915", 804.0))
        self.assertEqual(self.db.latest_holdings_snapshot()[0]["quantity"], 2)
        f = self.db.latest_funds_snapshot()
        self.assertEqual((f["available_margin"], f["used_margin"], f["unrealized_mtom"]), (90000.0, 804.0, 3.5))
        self.assertEqual(current_state.state, BrokerState.CONNECTED)

    async def test_pass_is_idempotent(self):
        mk(self.db)
        await rec.run_full_reconciliation()
        await rec.run_full_reconciliation()
        self.assertEqual(len(self.db.list_trades(mode="LIVE")), 1)

    async def test_unknown_outcome_order_found_by_tag(self):
        mk(self.db, status="PENDING_RECONCILE", broker_id=None)
        self.db.update_order(internal_order_id="o1", outcome_unknown=True)
        await rec.run_full_reconciliation()
        o = self.db.get_order("o1")
        self.assertEqual((o["broker_order_id"], o["outcome_unknown"]), ("N1", 0))

    async def test_order_absent_at_broker_is_flagged_not_silently_failed_or_resent(self):
        mk(self.db, oid="ghost", tag="GHOST", broker_id="NOPE", status="SUBMITTED")
        r = await rec.run_full_reconciliation()
        kinds = [d["kind"] for d in r["discrepancies"]]
        self.assertIn("order_missing_at_broker", kinds)
        self.assertEqual(self.db.get_order("ghost")["status"], "SUBMITTED")
        self.assertNotIn("place_order", [n for n, _ in self.neo.calls])

    async def test_failed_section_keeps_previous_snapshot(self):
        await rec.run_full_reconciliation()
        self.neo.responses["positions"] = {"Error": "Exception has been occurred while connecting to API"}
        r = await rec.run_full_reconciliation()
        self.assertIn("positions_failed", [d["kind"] for d in r["discrepancies"]])
        self.assertEqual(len(self.db.latest_positions_snapshot()), 1)      # not wiped

    async def test_session_invalid_during_recon_expires_session(self):
        self.neo.responses["order_report"] = {"stCode": 403, "errMsg": "Invalid session"}
        await rec.run_full_reconciliation()
        self.assertEqual(current_state.state, BrokerState.SESSION_EXPIRED)

    async def test_no_session_returns_error_not_crash(self):
        bc.broker_client._sdk = None
        r = await rec.run_full_reconciliation()
        self.assertIn("error", r)


if __name__ == "__main__":
    unittest.main()
