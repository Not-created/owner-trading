import unittest

from app import sdk_adapter as a
from tests.fakes import FakeNeoAPI


def sdk():
    s = a.KotakSdk("ck", "prod", neo_factory=FakeNeoAPI)
    return s, s._neo


def logged_in():
    s, neo = sdk()
    assert s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234").ok
    return s, neo


class ClassifyTests(unittest.TestCase):
    def test_success_with_order_number(self):
        o = a.classify({"stat": "Ok", "nOrdNo": "2606000001", "stCode": 200}, expect_order_id=True, state_changing=True)
        self.assertTrue(o.ok)
        self.assertEqual(o.order_id, "2606000001")

    def test_no_session_is_auth(self):
        o = a.classify({"Error Message": "Complete the 2fa process before accessing this application"}, state_changing=True)
        self.assertEqual(o.kind, a.AUTH)

    def test_capital_Error_with_validation_exception_is_definitive_rejection(self):
        # the SDK raises ApiValueError for its own validation failures; match by class name
        class ApiValueError(Exception):
            pass
        o = a.classify({"Error": ApiValueError("Invalid quantity")}, state_changing=True)
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "VALIDATION")

    def test_transport_exception_on_state_change_is_unknown_not_rejected(self):
        class ApiException(Exception):
            status = 0
        o = a.classify({"Error": ApiException("timed out")}, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_transport_exception_on_read_is_not_unknown(self):
        class ApiException(Exception):
            status = 0
        self.assertEqual(a.classify({"Error": ApiException("x")}).kind, a.REJECTED)

    def test_modify_generic_string_error_on_state_change_is_unknown(self):
        o = a.classify({"Error": "Exception has been occurred while connecting to API"}, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_http_403_exception_is_auth(self):
        class ApiException(Exception):
            status = 403
        self.assertEqual(a.classify({"Error": ApiException("Forbidden")}, state_changing=True).kind, a.AUTH)

    def test_backend_rejection_body(self):
        o = a.classify({"stCode": 1021, "errMsg": "Order is completed", "stat": "Not_Ok", "status_code": 400}, state_changing=True)
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "1021")

    def test_backend_403_body_is_auth(self):
        self.assertEqual(a.classify({"stCode": 403, "errMsg": "Invalid session, please re-login"}).kind, a.AUTH)

    def test_error_list_shape(self):
        o = a.classify({"error": [{"code": "10300", "message": "Validation Errors!"}]})
        self.assertEqual((o.kind, o.code), (a.REJECTED, "10300"))

    def test_2xx_without_order_number_is_unknown(self):
        o = a.classify({"stat": "Ok", "stCode": 200}, expect_order_id=True, state_changing=True)
        self.assertEqual(o.kind, a.UNKNOWN)

    def test_result_is_json_safe(self):
        import json
        class ApiException(Exception):
            status = 0
        json.dumps(a.classify({"Error": ApiException("x")}, state_changing=True).as_dict())
        json.dumps(a.jsonable({"Error": ApiException("boom")}))

    def test_official_auth_error_shape_is_rejected_with_real_message(self):
        # Official Kotak auth-API rejection shape (totp_login/totp_validate),
        # distinct from the order/portfolio-API shape used elsewhere in this
        # file ({"stCode","errMsg","stat"}). Before this fix, classify() only
        # recognised the order/portfolio shape, so this fell through to the
        # "success, no data" branch and its real message was lost.
        o = a.classify({"status": "error", "message": "Invalid credentials or TOTP.", "errorCode": "401"})
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.message, "Invalid credentials or TOTP.")
        self.assertEqual(o.code, "401")

    def test_official_auth_error_shape_403_is_auth(self):
        o = a.classify({"status": "error", "message": "Session invalid, please re-login.", "errorCode": "403"})
        self.assertEqual(o.kind, a.AUTH)

    def test_official_auth_error_shape_429_is_rate_limited(self):
        o = a.classify({"status": "error", "message": "Too many requests, please try again later.", "errorCode": "429"})
        self.assertEqual(o.kind, a.REJECTED)
        self.assertEqual(o.code, "429")

    def test_rows_of_handles_documented_shapes(self):
        self.assertEqual(a.rows_of(a.classify({"data": [{"a": 1}]})), [{"a": 1}])
        self.assertEqual(a.rows_of(a.classify({"data": {"stat": "Ok", "data": [{"b": 2}]}})), [{"b": 2}])
        self.assertEqual(a.rows_of(a.classify({"stat": "Ok", "stCode": 200})), [])


class OrderRequestTests(unittest.TestCase):
    def base(self, **kw):
        d = dict(exchange_segment="nse_cm", trading_symbol="YESBANK-EQ", transaction_type="B", order_type="L",
                 product="CNC", quantity=10, validity="DAY", price=20.5, tag="OTABC")
        d.update(kw)
        return a.OrderRequest(**d)

    def test_exact_kwargs_are_all_strings(self):
        kw = self.base().to_sdk_kwargs()
        self.assertEqual(kw["price"], "20.50")
        self.assertEqual(kw["quantity"], "10")
        self.assertEqual(kw["tag"], "OTABC")
        self.assertTrue(all(isinstance(v, str) for v in kw.values()))

    def test_market_order_sends_zero_price(self):
        self.assertEqual(self.base(order_type="MKT", price=None).to_sdk_kwargs()["price"], "0")

    def test_kwargs_accepted_by_real_signature(self):
        s, neo = logged_in()
        neo.responses["place_order"] = {"stat": "Ok", "nOrdNo": "1", "stCode": 200}
        self.assertTrue(s.place_order(self.base()).ok)   # FakeNeoAPI raises TypeError on any guessed kwarg

    def test_validation(self):
        bad = [dict(exchange_segment="NSE"), dict(exchange_segment="NSECM"), dict(product="DELIVERY"), dict(order_type="LIMIT"),
               dict(transaction_type="BUY"), dict(quantity=0), dict(quantity="10"), dict(price=None),
               dict(order_type="SL", trigger_price=None), dict(validity="GTC"), dict(exchange_segment="mcx_fo", validity="IOC"),
               dict(trading_symbol=" "), dict(tag="  "), dict(amo="MAYBE")]
        for kw in bad:
            with self.assertRaises(a.OrderRequestError, msg=str(kw)):
                self.base(**kw).to_sdk_kwargs()

    def test_fmt_price(self):
        self.assertEqual(a.fmt_price(0.1 + 0.2), "0.30")
        self.assertEqual(a.fmt_price(100), "100.00")
        self.assertEqual(a.fmt_price("9.4"), "9.40")
        self.assertEqual(a.fmt_price(1e-05).count("e"), 0)
        with self.assertRaises(a.OrderRequestError):
            a.fmt_price(-1)

    def test_not_sent_when_invalid(self):
        s, neo = logged_in()
        with self.assertRaises(a.OrderRequestError):
            s.place_order(self.base(quantity=0))
        self.assertFalse([c for c in neo.calls if c[0] == "place_order"])


class LoginTests(unittest.TestCase):
    def test_success_requires_trade_session(self):
        s, neo = sdk()
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertTrue(o.ok)
        self.assertTrue(s.has_trade_session())
        self.assertEqual(o.data["data_center"], "e21")

    def test_bad_mpin_is_rejected(self):
        s, neo = sdk()
        neo.login_ok = False
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="0000")
        self.assertFalse(o.ok)
        self.assertFalse(s.has_trade_session())

    def test_validate_reporting_view_ktype_is_rejected(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "View", "status": "success"}}
        self.assertFalse(s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1").ok)

    def test_success_body_without_session_is_rejected(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "Trade", "status": "success"}}  # config never populated
        self.assertFalse(s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1").ok)

    def test_session_summary_has_no_tokens(self):
        s, _ = logged_in()
        self.assertNotIn("TOK", str(s.session_summary()))
        self.assertNotIn("SID", str(s.session_summary()))

    def test_totp_login_rejection_preserves_broker_message_and_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_login"] = {"status": "error", "message": "Invalid credentials or TOTP.", "errorCode": "401"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="000000", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "TOTP_LOGIN_FAILED")
        self.assertIn("Invalid credentials or TOTP.", o.message)
        self.assertNotIn("no data in response", o.message)
        self.assertFalse(s.has_trade_session())

    def test_mpin_validation_rejection_has_its_own_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_validate"] = {"status": "error", "message": "Invalid MPIN.", "errorCode": "401"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="0000")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "MPIN_VALIDATION_FAILED")
        self.assertIn("Invalid MPIN.", o.message)
        self.assertFalse(s.has_trade_session())
        # totp_login itself must have been called and accepted -- this is
        # specifically the "totp_login OK, totp_validate rejected" case.
        self.assertTrue(any(n == "totp_login" for n, _ in neo.calls))

    def test_transport_error_during_totp_login_is_its_own_stage_code(self):
        class ApiException(Exception):
            status = 0
        s, neo = sdk()
        neo.responses["totp_login"] = {"Error": ApiException("Connection timed out")}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.kind, a.UNKNOWN)  # ambiguous -- may or may not have reached the broker
        self.assertEqual(o.code, "TRANSPORT_ERROR")

    def test_rate_limited_during_totp_login_is_its_own_stage_code(self):
        s, neo = sdk()
        neo.responses["totp_login"] = {"status": "error", "message": "Too many requests.", "errorCode": "429"}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="123456", mpin="1234")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "RATE_LIMITED")

    def test_session_verification_failure_has_its_own_stage_code(self):
        # totp_validate succeeds and reports a Trade session, but the SDK
        # config never actually populated tokens -- has_trade_session() is
        # False, which is the "session established but unusable" case.
        s, neo = sdk()
        neo.responses["totp_validate"] = {"data": {"kType": "Trade", "status": "success"}}
        o = s.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1")
        self.assertFalse(o.ok)
        self.assertEqual(o.code, "SESSION_VERIFICATION_FAILED")


class MethodCoverageTests(unittest.TestCase):
    def test_every_adapter_call_matches_official_signature(self):
        s, neo = logged_in()
        s.modify_order(order_id="1", order_type="L", quantity=5, validity="DAY", price=10, trigger_price=None)
        s.cancel_order(order_id="1")
        s.order_report(); s.order_report("1"); s.order_history("1"); s.trade_report()
        s.positions(); s.holdings(); s.limits(); s.whatsmyip()
        s.margin_required(exchange_segment="nse_cm", price=10, order_type="L", product="CNC", quantity=1,
                          instrument_token="11536", transaction_type="B")
        s.quotes([("nse_cm", "11536")], "ltp")
        s.scrip_master("nse_cm")
        s.search_scrip(exchange_segment="nse_cm", symbol="yes")
        called = {c[0] for c in neo.calls}
        self.assertTrue({"modify_order", "cancel_order", "order_report", "order_history", "trade_report", "positions",
                         "holdings", "limits", "whatsmyip", "margin_required", "quotes", "scrip_master", "search_scrip"} <= called)

    def test_modify_sends_new_quantity_price_as_strings(self):
        s, neo = logged_in()
        s.modify_order(order_id="9", order_type="L", quantity=5, validity="DAY", price=10.5)
        kw = dict(neo.calls)["modify_order"]
        self.assertEqual((kw["quantity"], kw["price"], kw["order_id"]), ("5", "10.50", "9"))

    def test_quotes_payload_shape(self):
        s, neo = logged_in()
        s.quotes([("nse_cm", "11536")])
        self.assertEqual(dict(neo.calls)["quotes"]["instrument_tokens"], [{"instrument_token": "11536", "exchange_segment": "nse_cm"}])

    def test_empty_ids_rejected_before_sdk(self):
        s, neo = logged_in()
        for fn in (lambda: s.cancel_order(order_id=""), lambda: s.modify_order(order_id="", order_type="L", quantity=1, validity="DAY", price=1)):
            with self.assertRaises(a.OrderRequestError):
                fn()


class DerivativesAndMiscTests(unittest.TestCase):
    def test_expiries_validates_segment_and_sends_exact_kwargs(self):
        s, neo = logged_in()
        neo.responses["expiries"] = {"exchange": "nse_fo", "underlying": "NIFTY", "expiries": ["2026-06-25"]}
        o = s.expiries(exchange="nse_fo", underlying="NIFTY", instrument_type="option")
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["expiries"], {"exchange": "nse_fo", "underlying": "NIFTY", "instrument_type": "option"})
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_cm", underlying="NIFTY")
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_fo", underlying="")
        with self.assertRaises(a.OrderRequestError):
            s.expiries(exchange="nse_fo", underlying="NIFTY", instrument_type="swap")

    def test_option_chain_validates_and_sends_exact_kwargs(self):
        s, neo = logged_in()
        neo.responses["option_chain"] = {"data": {"common_data": {}, "call": [], "put": []}}
        o = s.option_chain(exchange="nse_fo", underlying="NIFTY", expiry="2026-06-25", instrument_type="option", count=20)
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["option_chain"],
                         {"exchange": "nse_fo", "underlying": "NIFTY", "expiry": "2026-06-25", "instrument_type": "option", "count": 20})
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="mcx_fo", underlying="", count=1)
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="nse_fo", underlying="NIFTY", count=0)
        with self.assertRaises(a.OrderRequestError):
            s.option_chain(exchange="nse_fo", underlying="NIFTY", count="20")

    def test_historical_data_validates_neosymbol_interval_and_unsupported_segment(self):
        s, neo = logged_in()
        neo.responses["historical_data"] = {"status": "success", "interval": "D", "data": {"candles": [["t", 1, 2, 0.5, 1.5, 100, 0]]}}
        o = s.historical_data(neosymbol="nse_cm|1333", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        self.assertTrue(o.ok)
        self.assertEqual(dict(neo.calls)["historical_data"],
                         {"neosymbol": "nse_cm|1333", "interval": "D", "from_date": "2026-08-01", "to_date": "2026-09-01"})
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm1333", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="mcx_fo|1", interval="D", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm|1333", interval="2min", from_date="2026-08-01", to_date="2026-09-01")
        with self.assertRaises(a.OrderRequestError):
            s.historical_data(neosymbol="nse_cm|1333", interval="D", from_date="", to_date="2026-09-01")

    def test_scrip_master_with_and_without_segment(self):
        s, neo = logged_in()
        neo.responses["scrip_master"] = "https://lapi.kotaksecurities.com/wso2-scripmaster/v1/prod/2026-07-14/transformed-v1/nse_cm-v1.csv"
        o = s.scrip_master(exchange_segment="nse_cm")
        self.assertTrue(o.ok)
        self.assertTrue(o.data.startswith("https://"))
        neo.responses["scrip_master"] = {"baseFolder": "https://x", "filesPaths": ["https://x/a.csv"]}
        o2 = s.scrip_master()
        self.assertTrue(o2.ok)
        self.assertIn("filesPaths", o2.data)

    def test_whatsmyip(self):
        s, neo = logged_in()
        neo.responses["whatsmyip"] = {"ip": "1.2.3.4"}
        o = s.whatsmyip()
        self.assertTrue(o.ok)
        self.assertEqual(o.data["ip"], "1.2.3.4")


if __name__ == "__main__":
    unittest.main()
