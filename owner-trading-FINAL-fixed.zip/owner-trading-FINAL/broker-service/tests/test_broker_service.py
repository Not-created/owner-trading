"""Offline test suite for the broker service foundation. Uses only the
standard library (unittest, asyncio) so it runs without `pip install`ing
anything -- including without the `kotakneoapi` SDK itself installed, since
app/broker_client.py is required to degrade gracefully rather than crash
when the SDK is absent (see SDK_AVAILABLE).

Run from broker-service/:  python -m unittest discover -v
"""
import asyncio
import json
import unittest

from app.config import Config
from app.state import BrokerState, StateHolder

from app.secure_store import redact


class ConfigTests(unittest.TestCase):
    def test_not_configured_when_credentials_missing(self):
        cfg = Config(
            consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None
        )
        self.assertFalse(cfg.is_fully_configured())

    def test_configured_when_all_present(self):
        cfg = Config(
            consumer_key="x", mobile_number="y", ucc="z", totp_secret="t", mpin="m"
        )
        self.assertTrue(cfg.is_fully_configured())

    def test_partial_credentials_not_configured(self):
        cfg = Config(consumer_key="x", mobile_number="y", ucc=None, totp_secret=None, mpin=None)
        self.assertFalse(cfg.is_fully_configured())


class StateMachineTests(unittest.TestCase):
    def test_default_state_is_not_configured(self):
        holder = StateHolder()
        self.assertEqual(holder.state, BrokerState.NOT_CONFIGURED)

    def test_transition_updates_state_and_error(self):
        holder = StateHolder()
        holder.transition(BrokerState.CONNECTION_ERROR, "unreachable")
        self.assertEqual(holder.state, BrokerState.CONNECTION_ERROR)
        self.assertEqual(holder.last_error, "unreachable")

    def test_as_dict_is_json_serializable(self):
        holder = StateHolder()
        holder.transition(BrokerState.VERIFYING)
        json.dumps(holder.as_dict())  # raises if not serializable

    def test_all_nine_required_states_exist(self):
        expected = {
            "DISCONNECTED", "VERIFYING", "CONNECTED", "AUTH_FAILED",
            "SESSION_EXPIRED", "CONNECTION_ERROR", "NOT_CONFIGURED",
            # Added (final production pass): transient states surfaced
            # during an active reconciliation pass / WebSocket reconnect
            # -- see state.py's BrokerState docstring.
            "RECONNECTING", "RECONCILING",
        }
        actual = {s.value for s in BrokerState}
        self.assertEqual(expected, actual)



class SecureStoreTests(unittest.TestCase):
    def test_redact_empty(self):
        self.assertEqual(redact(None), "<empty>")
        self.assertEqual(redact(""), "<empty>")

    def test_redact_masks_all_but_last_two_chars(self):
        self.assertEqual(redact("ABCDEFGH"), "******GH")

    def test_redact_never_returns_the_original_for_a_real_looking_secret(self):
        secret = "super-secret-value-123"
        self.assertNotEqual(redact(secret), secret)



if __name__ == "__main__":
    unittest.main()
