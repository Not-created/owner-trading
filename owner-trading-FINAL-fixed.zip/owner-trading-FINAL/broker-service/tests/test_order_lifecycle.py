"""db.py order-state rules + order_sync, against a real migrated SQLite DB."""
import unittest

from tests.dbutil import fresh_db


def mk(db, oid="o1", tag="OTTAG1", qty=100, mode="LIVE", status="SUBMITTED", broker_id="N1"):
    db.create_order(internal_order_id=oid, trading_symbol="YESBANK-EQ", exchange_segment="nse_cm", transaction_type="B",
                    order_type="L", product="CNC", validity="DAY", quantity=qty, price=20.0, trigger_price=None,
                    mode=mode, status=status, client_tag=tag, broker_order_id=broker_id)


def feed(**kw):
    row = {"nOrdNo": "N1", "ordSt": "open", "qty": "100", "fldQty": "0", "unFldSz": "100", "avgPrc": "0.00", "GuiOrdId": "OTTAG1",
           "trdSym": "YESBANK-EQ", "exSeg": "nse_cm", "updRecvTm": "1"}
    row.update(kw)
    return row


class OrderStateTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app import order_sync
        self.sync = order_sync

    def test_partial_then_complete(self):
        mk(self.db)
        r = self.sync.apply_order_row(feed(fldQty="40", unFldSz="60", avgPrc="20.10", updRecvTm="2"), source="order_feed")
        self.assertEqual(r["status"], "PARTIALLY_FILLED")
        o = self.db.get_order("o1")
        self.assertEqual((o["filled_quantity"], o["average_price"], o["status"]), (40, 20.10, "PARTIALLY_FILLED"))
        self.sync.apply_order_row(feed(ordSt="complete", fldQty="100", unFldSz="0", avgPrc="20.05", updRecvTm="3"), source="order_feed")
        o = self.db.get_order("o1")
        self.assertEqual((o["filled_quantity"], o["status"], o["average_price"]), (100, "COMPLETE", 20.05))

    def test_out_of_order_and_duplicate_messages_do_not_regress(self):
        mk(self.db)
        self.sync.apply_order_row(feed(fldQty="60", unFldSz="40", avgPrc="20.20", updRecvTm="5"), source="order_feed")
        self.sync.apply_order_row(feed(fldQty="30", unFldSz="70", avgPrc="20.00", updRecvTm="4"), source="order_feed")  # older
        self.sync.apply_order_row(feed(ordSt="open", fldQty="0", unFldSz="100", updRecvTm="3"), source="order_feed")     # older, stale status
        o = self.db.get_order("o1")
        self.assertEqual((o["filled_quantity"], o["status"], o["average_price"]), (60, "PARTIALLY_FILLED", 20.20))

    def test_terminal_state_is_never_reopened(self):
        mk(self.db)
        self.sync.apply_order_row(feed(ordSt="cancelled", updRecvTm="2"), source="order_feed")
        self.sync.apply_order_row(feed(ordSt="open", updRecvTm="9"), source="order_feed")
        self.assertEqual(self.db.get_order("o1")["status"], "CANCELLED")

    def test_cancel_after_partial_keeps_fills(self):
        mk(self.db)
        self.sync.apply_order_row(feed(fldQty="25", unFldSz="75", avgPrc="20.00"), source="order_feed")
        self.sync.apply_order_row(feed(ordSt="cancelled", fldQty="25", unFldSz="75", avgPrc="20.00", updRecvTm="3"), source="order_feed")
        o = self.db.get_order("o1")
        self.assertEqual((o["status"], o["filled_quantity"]), ("CANCELLED", 25))

    def test_rejection_records_reason(self):
        mk(self.db)
        self.sync.apply_order_row(feed(ordSt="rejected", rejRsn="RMS:Insufficient funds"), source="order_feed")
        o = self.db.get_order("o1")
        self.assertEqual(o["status"], "REJECTED")
        self.assertIn("Insufficient", o["status_reason"])

    def test_unknown_status_is_stored_verbatim_without_changing_local_status(self):
        mk(self.db)
        self.sync.apply_order_row(feed(ordSt="some new state"), source="order_feed")
        o = self.db.get_order("o1")
        self.assertEqual((o["status"], o["broker_status"]), ("SUBMITTED", "some new state"))

    def test_unknown_outcome_order_recovered_by_client_tag(self):
        mk(self.db, status="PENDING_RECONCILE", broker_id=None)
        self.db.update_order(internal_order_id="o1", outcome_unknown=True)
        r = self.sync.apply_order_row(feed(nOrdNo="N77", GuiOrdId="OTTAG1", ordSt="open"), source="reconciliation")
        self.assertTrue(r["matched"])
        o = self.db.get_order("o1")
        self.assertEqual((o["broker_order_id"], o["status"], o["outcome_unknown"]), ("N77", "OPEN", 0))

    def test_foreign_order_is_recorded_as_event_but_not_matched(self):
        mk(self.db)
        r = self.sync.apply_order_row(feed(nOrdNo="X9", GuiOrdId="", ordSt="open"), source="order_feed")
        self.assertFalse(r["matched"])

    def test_duplicate_event_is_idempotent(self):
        mk(self.db)
        row = feed(fldQty="10", unFldSz="90")
        self.sync.apply_order_row(row, source="order_feed")
        self.sync.apply_order_row(row, source="order_feed")
        o = self.db.get_order("o1")
        self.assertEqual(o["filled_quantity"], 10)

    def test_trade_rows_are_idempotent_and_linked(self):
        mk(self.db)
        t = {"nOrdNo": "N1", "flId": "F1", "fldQty": "40", "avgPrc": "20.10", "trdSym": "YESBANK-EQ", "exSeg": "nse_cm",
             "trnsTp": "B", "prod": "CNC", "GuiOrdId": "OTTAG1", "flDt": "20 Sep 2026", "flTm": "10:00:00"}
        self.assertTrue(self.sync.apply_trade_row(t))
        self.assertFalse(self.sync.apply_trade_row(t))
        tr = self.db.list_trades(mode="LIVE")
        self.assertEqual(len(tr), 1)
        self.assertEqual(tr[0]["order_id"], self.db.get_order("o1")["id"])
        self.assertEqual(self.db.sum_filled_quantity(self.db.get_order("o1")["id"]), 40)

    def test_map_status_table(self):
        m = self.sync.map_status
        self.assertEqual(m("put order req received", 10, 0, 10), "SUBMITTED")
        self.assertEqual(m("validation pending", 10, 0, 10), "SUBMITTED")
        self.assertEqual(m("modified", 10, 0, 10), "OPEN")
        self.assertEqual(m("Complete", 10, 10, 0), "COMPLETE")
        self.assertIsNone(m("weird", 10, 0, 10))

    def test_unresolved_live_orders_query(self):
        mk(self.db, oid="a", tag="TA", status="SUBMITTED", broker_id="A")
        mk(self.db, oid="b", tag="TB", status="COMPLETE", broker_id="B")
        mk(self.db, oid="c", tag="TC", status="PENDING_RECONCILE", broker_id=None)
        self.db.update_order(internal_order_id="c", outcome_unknown=True)
        ids = {o["internal_order_id"] for o in self.db.list_unresolved_live_orders()}
        self.assertEqual(ids, {"a", "c"})

    def test_client_tag_is_unique(self):
        mk(self.db)
        with self.assertRaises(Exception):
            mk(self.db, oid="o2", broker_id="N2")   # same tag OTTAG1


if __name__ == "__main__":
    unittest.main()
