"""Tests the deploy.sh login/session verification LOGIC (bash + curl) against a small Node mock server
that reproduces the documented behaviour of the app's auth endpoints (cookie policy auto/true/false,
Secure only when the request is HTTPS, protected endpoint, logout). This proves the SCRIPT neither
false-fails on a correct deployment nor false-passes on a broken one. It does NOT exercise Express itself
(that is backend/test/session-e2e.test.js, which runs where npm dependencies are installed)."""
import os
import shutil
import subprocess
import tempfile
import time
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
DEPLOY = os.path.join(ROOT, "deploy.sh")

MOCK = r'''
const http = require("http");
const policy = process.env.POLICY || "auto";       // auto | true | false
const bug = process.env.BUG || "";
const sessions = new Set();
const cookieOf = (req) => (req.headers.cookie || "").match(/owner_trading_sid=([^;]+)/)?.[1];
http.createServer((req, res) => {
  const https = (req.headers["x-forwarded-proto"] || "").toLowerCase() === "https";
  const send = (code, obj, extra = {}) => { res.writeHead(code, { "Content-Type": "application/json", ...extra }); res.end(JSON.stringify(obj)); };
  if (req.method === "POST" && req.url === "/api/auth/login") {
    let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => {
      let pw; try { pw = JSON.parse(b).password; } catch {}
      if (pw !== "pw") return send(401, { error: "Incorrect password." });
      const secure = bug === "secure_on_http" ? true : policy === "true" ? https : policy === "false" ? false : https;
      if (policy === "true" && !https) return send(200, { success: true });          // browser would drop it: no cookie issued
      if (bug === "nocookie") return send(200, { success: true });
      const id = Math.random().toString(36).slice(2); sessions.add(id);
      let c = `owner_trading_sid=${id}; Path=/; Expires=Wed, 01 Jan 2031 00:00:00 GMT`;
      if (bug !== "no_httponly") c += "; HttpOnly";
      c += "; SameSite=Lax";
      const useSecure = policy === "true" ? true : policy === "false" ? false : secure;
      if (useSecure) c += "; Secure";
      send(200, { success: true }, { "Set-Cookie": c });
    });
  } else if (req.url === "/api/auth/session") send(200, { authenticated: sessions.has(cookieOf(req)) });
  else if (req.url === "/api/risk") sessions.has(cookieOf(req)) ? send(200, {}) : send(401, { error: "Not authenticated." });
  else if (req.method === "POST" && req.url === "/api/auth/logout") { if (bug !== "logout_noop") sessions.delete(cookieOf(req)); send(200, { success: true }); }
  else send(404, {});
}).listen(0, "127.0.0.1", function () { console.log(this.address().port); });
'''


def extract_function():
    with open(DEPLOY, encoding="utf-8") as fh:
        src = fh.read()
    a = src.index("session_flow() {")
    b = src.index('\nif [ -n "$NEW_PW" ]; then\n  info "Verifying login')
    return src[a:b]


@unittest.skipUnless(shutil.which("node") and shutil.which("curl") and shutil.which("bash"), "needs node, curl, bash")
class SessionVerificationTests(unittest.TestCase):
    def start(self, policy="auto", bug=""):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "mock.js")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(MOCK)
        proc = subprocess.Popen(["node", p], stdout=subprocess.PIPE, env={**os.environ, "POLICY": policy, "BUG": bug}, text=True)
        self.addCleanup(proc.stdout.close)
        self.addCleanup(proc.wait)
        self.addCleanup(proc.kill)
        port = proc.stdout.readline().strip()
        self.assertTrue(port.isdigit())
        return f"http://127.0.0.1:{port}"

    def run_flow(self, base, expect, *extra, password="pw"):
        harness = (
            "set -uo pipefail\n"
            "ok(){ echo \"OK: $1\"; }\n"
            "fail(){ echo \"FAIL: $1\" >&2; exit 1; }\n"
            "LOGIN_JSON=$(node -e 'process.stdout.write(JSON.stringify({password: process.argv[1]}))' \"$PW\")\n"
            + extract_function() +
            f"\nsession_flow \"test\" \"{base}\" \"{expect}\" " + " ".join(f"'{e}'" for e in extra) + "\n"
        )
        return subprocess.run(["bash", "-c", harness], capture_output=True, text=True, env={**os.environ, "PW": password}, timeout=60)

    def test_http_login_with_auto_policy_passes_with_plain_cookie(self):
        r = self.run_flow(self.start("auto"), "plain")
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)
        self.assertIn("non-Secure", r.stdout)

    def test_https_via_forwarded_header_passes_with_secure_cookie(self):
        r = self.run_flow(self.start("auto"), "secure", "-H", "X-Forwarded-Proto: https")
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)
        self.assertIn("Secure", r.stdout)

    def test_http_flow_does_not_borrow_the_https_header(self):
        """The plain-HTTP flow must be a genuine HTTP request: with policy=true (HTTPS-only) it must NOT get a cookie."""
        r = self.run_flow(self.start("true"), "none")
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)
        self.assertIn("expected", r.stdout)

    def test_policy_true_over_https_gets_secure_cookie(self):
        r = self.run_flow(self.start("true"), "secure", "-H", "X-Forwarded-Proto: https")
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)

    def test_policy_false_plain_cookie_even_over_https(self):
        r = self.run_flow(self.start("false"), "plain", "-H", "X-Forwarded-Proto: https")
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)

    # ---- the script must FAIL on genuinely broken behaviour (no false passes) ----
    def test_fails_when_http_login_gets_a_secure_cookie(self):
        r = self.run_flow(self.start("auto", "secure_on_http"), "plain")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("Secure", r.stderr)

    def test_fails_when_no_cookie_is_issued(self):
        r = self.run_flow(self.start("auto", "nocookie"), "plain")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("NO session cookie", r.stderr)

    def test_fails_when_cookie_not_httponly(self):
        r = self.run_flow(self.start("auto", "no_httponly"), "plain")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("HttpOnly", r.stderr)

    def test_fails_when_logout_does_not_destroy_session(self):
        r = self.run_flow(self.start("auto", "logout_noop"), "plain")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("after logout", r.stderr)

    def test_fails_on_wrong_password(self):
        r = self.run_flow(self.start("auto"), "plain", password="nope")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("HTTP 401", r.stderr)

    def test_fails_when_server_unreachable(self):
        r = self.run_flow("http://127.0.0.1:9", "plain")
        self.assertNotEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main()
