import dataclasses
import unittest
from unittest.mock import patch
from app import broker_client as bc
from app import order_service as osvc
from app import sdk_adapter as a
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI

class ApiException(Exception):

    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status
PAYLOAD = dict(trading_symbol='YESBANK-EQ', exchange_segment='nse_cm', transaction_type='B', order_type='L', product='CNC', validity='DAY', quantity=10, price=20.5, instrument_token='11915')

class Base(unittest.IsolatedAsyncioTestCase):
    MODE = 'LIVE'

    async def asyncSetUp(self):
        self.db = fresh_db()
        cfg = dataclasses.replace(osvc.config, trading_mode=self.MODE, max_order_quantity=0, max_orders_per_day=0)
        self.patches = [patch.object(osvc, 'config', cfg), patch.object(bc, 'config', cfg)]
        for p in self.patches:
            p.start()
        self.sdk = a.KotakSdk('ck', 'prod', neo_factory=FakeNeoAPI)
        self.neo = self.sdk._neo
        self.sdk.login(mobile_number='+919999999999', ucc='U1', totp='123456', mpin='1234')
        bc.broker_client._sdk = self.sdk
        current_state.transition(BrokerState.CONNECTED)
        if self.MODE == 'LIVE':
            self.db.set_live_armed(True)
            # Phase 7-9 defence-in-depth requires a recent broker funds
            # reconciliation snapshot before any state-changing LIVE call.
            self.db.record_funds_snapshot(available_margin=100000, used_margin=0, raw={"test": True}, realized_mtom=0, unrealized_mtom=0)
            rid=self.db.begin_reconciliation_run(); self.db.finish_reconciliation_run(rid,status="COMPLETE",discrepancy_count=0,sections_ok=True,details={})
        self.reconciles = 0
        self.rp = patch.object(osvc, '_schedule_reconcile', lambda: setattr(self, 'reconciles', self.reconciles + 1))
        self.rp.start()

    async def asyncTearDown(self):
        self.rp.stop()
        for p in self.patches:
            p.stop()
        bc.broker_client._sdk = None
        current_state.transition(BrokerState.DISCONNECTED)

    def placed(self):
        return [kw for n, kw in self.neo.calls if n == 'place_order']

class LivePlaceTests(Base):

    async def test_happy_path_sends_exact_sdk_kwargs_and_tag(self):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': '2609200001', 'stCode': 200}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual((o['status'], o['broker_order_id'], o['mode']), ('SUBMITTED', '2609200001', 'LIVE'))
        kw, = self.placed()
        self.assertEqual(kw['exchange_segment'], 'nse_cm')
        self.assertEqual((kw['price'], kw['quantity'], kw['order_type'], kw['product']), ('20.50', '10', 'L', 'CNC'))
        self.assertEqual(kw['tag'], o['client_tag'])
        self.assertTrue(o['client_tag'].startswith('OT') and len(o['client_tag']) == 18)

    async def test_broker_params_field_is_not_used(self):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': '1', 'stCode': 200}
        await osvc.place_order(dict(PAYLOAD, broker_params={'exchange_segment': 'EVIL', 'quantity': '9999'}))
        self.assertEqual(self.placed()[0]['exchange_segment'], 'nse_cm')
        self.assertEqual(self.placed()[0]['quantity'], '10')

    async def test_not_armed_blocks_and_never_calls_broker(self):
        self.db.set_live_armed(False)
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'REJECTED')
        self.assertIn('armed', o['status_reason'])
        self.assertEqual(self.placed(), [])

    async def test_emergency_stop_blocks(self):
        with patch.object(self.db, 'is_emergency_stop_active', return_value=True):
            o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'REJECTED')
        self.assertEqual(self.placed(), [])

    async def test_not_connected_blocks(self):
        current_state.transition(BrokerState.SESSION_EXPIRED)
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'REJECTED')
        self.assertEqual(self.placed(), [])

    async def test_broker_rejection_is_recorded_with_reason(self):
        self.neo.responses['place_order'] = {'stCode': 1021, 'errMsg': 'RMS: Margin exceeds', 'stat': 'Not_Ok', 'status_code': 400}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'REJECTED')
        self.assertIn('Margin', o['status_reason'])
        self.assertEqual(o['outcome_unknown'], 0)

    async def test_timeout_is_unknown_never_rejected_and_never_retried(self):
        self.neo.responses['place_order'] = {'Error': ApiException('read timeout')}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'PENDING_RECONCILE')
        self.assertEqual(o['outcome_unknown'], 1)
        self.assertEqual(len(self.placed()), 1)
        self.assertEqual(self.reconciles, 1)

    async def test_session_invalid_response_rejects_and_expires_session(self):
        self.neo.responses['place_order'] = {'stCode': 403, 'errMsg': 'Invalid session, please re-login'}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'REJECTED')
        self.assertEqual(current_state.state, BrokerState.SESSION_EXPIRED)

    async def test_response_without_order_number_is_unknown(self):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'stCode': 200}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual((o['status'], o['outcome_unknown']), ('PENDING_RECONCILE', 1))

    async def test_idempotent_replay_places_once(self):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': '5', 'stCode': 200}
        o1 = await osvc.place_order(dict(PAYLOAD, idempotency_key='key-1'))
        o2 = await osvc.place_order(dict(PAYLOAD, idempotency_key='key-1'))
        self.assertEqual(o1['internal_order_id'], o2['internal_order_id'])
        self.assertEqual(len(self.placed()), 1)

    async def test_validation_errors(self):
        for bad in (dict(exchange_segment=''), dict(exchange_segment='NSE'), dict(quantity=0), dict(order_type='LIMIT'), dict(product='DELIVERY'), dict(price=None), dict(validity='GTC'), dict(transaction_type='BUY')):
            with self.assertRaises(osvc.OrderValidationError, msg=str(bad)):
                await osvc.place_order(dict(PAYLOAD, **bad))
        self.assertEqual(self.placed(), [])
        self.assertEqual(self.db.list_orders(), [])

    async def test_risk_max_quantity_and_value_and_fail_closed(self):
        self.db.set_risk_settings({'max_order_quantity': 5})
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))
        self.db.set_risk_settings({'max_order_quantity': None, 'max_order_value': 100})
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD, order_type='MKT', price=None))
        self.assertEqual(self.placed(), [])

    async def test_daily_loss_limit(self):
        with self.db._connection() as conn:
            conn.execute("DELETE FROM funds_snapshot")
        self.db.set_risk_settings({'max_daily_loss': 500})
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))
        self.db.record_funds_snapshot(available_margin=1000000.0, used_margin=0, raw={}, realized_mtom=-450.0, unrealized_mtom=-100.0)
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))
        self.db.record_funds_snapshot(available_margin=1000000.0, used_margin=0, raw={}, realized_mtom=-100.0, unrealized_mtom=0.0)
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': '9', 'stCode': 200}
        o = await osvc.place_order(dict(PAYLOAD))
        self.assertEqual(o['status'], 'SUBMITTED')

    async def test_max_orders_per_day(self):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': '9', 'stCode': 200}
        self.db.set_risk_settings({'max_orders_per_day': 1})
        await osvc.place_order(dict(PAYLOAD))
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))

    async def test_cnc_buy_over_available_funds_blocked(self):
        self.db.record_funds_snapshot(available_margin=100.0, used_margin=0, raw={})
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.place_order(dict(PAYLOAD))

class LiveModifyCancelTests(Base):

    async def _live_order(self, **fill):
        self.neo.responses['place_order'] = {'stat': 'Ok', 'nOrdNo': 'N1', 'stCode': 200}
        o = await osvc.place_order(dict(PAYLOAD))
        if fill:
            self.db.apply_broker_order_state(internal_order_id=o['internal_order_id'], status='PARTIALLY_FILLED', broker_status='open', **fill)
        return o['internal_order_id']

    async def test_cancel_sends_broker_order_id(self):
        oid = await self._live_order()
        self.neo.responses['cancel_order'] = {'stat': 'Ok', 'nOrdNo': 'N1', 'stCode': 200}
        o = await osvc.cancel_order(oid)
        self.assertEqual(o['status'], 'CANCEL_REQUESTED')
        self.assertEqual(dict(self.neo.calls)['cancel_order']['order_id'], 'N1')

    async def test_cancel_terminal_order_is_refused_locally(self):
        oid = await self._live_order()
        self.db.apply_broker_order_state(internal_order_id=oid, status='COMPLETE', broker_status='complete', filled_quantity=10)
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.cancel_order(oid)

    async def test_cancel_broker_rejection_surfaces(self):
        oid = await self._live_order()
        self.neo.responses['cancel_order'] = {'stCode': 1021, 'errMsg': 'Order is completed', 'status_code': 400}
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.cancel_order(oid)

    async def test_cancel_timeout_flags_unknown(self):
        oid = await self._live_order()
        self.neo.responses['cancel_order'] = {'Error': ApiException('timeout')}
        o = await osvc.cancel_order(oid)
        self.assertEqual(o['outcome_unknown'], 1)
        self.assertEqual(self.reconciles, 1)

    async def test_modify_updates_price_and_adopts_new_order_number(self):
        oid = await self._live_order()
        self.neo.responses['modify_order'] = {'stat': 'Ok', 'nOrdNo': 'N2', 'stCode': 200}
        o = await osvc.modify_order(oid, {'price': 21.25})
        kw = dict(self.neo.calls)['modify_order']
        self.assertEqual((kw['order_id'], kw['price'], kw['quantity'], kw['order_type']), ('N1', '21.25', '10', 'L'))
        self.assertEqual((o['broker_order_id'], o['price'], o['status']), ('N2', 21.25, 'MODIFY_REQUESTED'))

    async def test_modify_quantity_of_partially_filled_order_refused(self):
        oid = await self._live_order(filled_quantity=4, average_price=20.0)
        with self.assertRaises(osvc.OrderValidationError):
            await osvc.modify_order(oid, {'quantity': 20})
        self.assertNotIn('modify_order', [n for n, _ in self.neo.calls])

    async def test_modify_price_of_partially_filled_order_allowed(self):
        oid = await self._live_order(filled_quantity=4, average_price=20.0)
        self.neo.responses['modify_order'] = {'stat': 'Ok', 'nOrdNo': 'N1', 'stCode': 200}
        o = await osvc.modify_order(oid, {'price': 22})
        self.assertEqual(o['price'], 22.0)
if __name__ == '__main__':
    unittest.main()
