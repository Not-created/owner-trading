const passwordStore = require("../services/passwordStore");

/**
 * POST /api/auth/login
 * Body: { password: "12345678" }
 *
 * Verifies the submitted password against the server-side bcrypt hash and,
 * on success, marks the session authenticated. The response never reveals
 * whether the password format was wrong, the password didn't match, or no
 * password has been configured -- callers only ever see a generic failure.
 */
async function login(req, res) {
  const { password } = req.body || {};

  if (!passwordStore.hasPasswordConfigured()) {
    // Deployment wasn't completed correctly. Deliberately vague -- no
    // internal file paths or setup details leak into the response.
    return res.status(503).json({ error: "Access is not configured yet." });
  }

  const isValid = await passwordStore.verifyPassword(password);
  if (!isValid) {
    return res.status(401).json({ error: "Incorrect password." });
  }

  req.session.authenticated = true;
  req.session.authenticatedAt = new Date().toISOString();

  req.session.save((err) => {
    if (err) {
      return res.status(500).json({ error: "Could not start session." });
    }
    return res.json({ success: true });
  });
}

/**
 * POST /api/auth/logout
 * Destroys the session server-side and clears the session cookie, so the
 * next request (even to a protected route) is treated as unauthenticated.
 */
function logout(req, res) {
  if (!req.session) {
    return res.json({ success: true });
  }
  const cookieName = req.session.cookie && req.sessionID ? "owner_trading_sid" : "owner_trading_sid";
  req.session.destroy((err) => {
    res.clearCookie(cookieName);
    if (err) {
      return res.status(500).json({ error: "Could not end session." });
    }
    return res.json({ success: true });
  });
}

/**
 * GET /api/auth/session
 * Lets the frontend silently check "am I still logged in?" on load/refresh
 * without submitting a password.
 */
function getSession(req, res) {
  const authenticated = !!(req.session && req.session.authenticated === true);
  return res.json({ authenticated });
}

module.exports = { login, logout, getSession };
