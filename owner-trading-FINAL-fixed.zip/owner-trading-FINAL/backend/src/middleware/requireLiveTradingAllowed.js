const config = require("../config");
const { getBrokerConnectionState, isEmergencyStopActive, BROKER_STATES } = require("../services/brokerState");

// Defense-in-depth gate for every executable LIVE order request.
function requireLiveTradingAllowed(req, res, next) {
  if (config.tradingMode !== "LIVE") return res.status(403).json({ error: "LIVE trading is unavailable." });
  if (isEmergencyStopActive()) return res.status(423).json({ error: "Emergency stop is active. No LIVE orders are permitted." });
  const { state } = getBrokerConnectionState();
  if (state !== BROKER_STATES.CONNECTED) return res.status(409).json({ error: `Broker is not connected (state: ${state}). LIVE orders are blocked.` });
  return next();
}

module.exports = { requireLiveTradingAllowed };
