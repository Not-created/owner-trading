/**
 * Protects an API route -- rejects with 401 unless the request carries a
 * valid, authenticated session. This is the server-side enforcement point:
 * even if a caller bypasses the frontend entirely (curl, direct route
 * navigation), no protected data or action is reachable without it.
 */
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated === true) {
    return next();
  }
  return res.status(401).json({ error: "Not authenticated." });
}

module.exports = requireAuth;
