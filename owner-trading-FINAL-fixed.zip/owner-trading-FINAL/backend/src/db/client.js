const { DatabaseSync } = require("node:sqlite");
const path = require("path");
const fs = require("fs");
const config = require("../config");

let db = null;

/**
 * Returns a singleton synchronous SQLite connection using Node's built-in
 * `node:sqlite` module (Node 22+) -- deliberately chosen so the database
 * layer has zero extra npm dependencies (no native bindings to compile,
 * e.g. better-sqlite3), which keeps `npm install` fast and reliable on a
 * fresh VPS.
 */
function getDb() {
  if (db) return db;
  fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
  db = new DatabaseSync(config.dbPath);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  return db;
}

module.exports = { getDb };
