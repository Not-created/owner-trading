#!/usr/bin/env node
/**
 * Idempotent migration runner. Applies every .sql file in
 * backend/src/db/migrations/, in filename order, that hasn't already been
 * recorded in the `_migrations` table. Safe to run on every deploy --
 * already-applied migrations are skipped, and the production database is
 * never dropped or recreated.
 *
 * Usage: node backend/src/db/migrate.js
 */
const fs = require("fs");
const path = require("path");
const { getDb } = require("./client");

function run() {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS _migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL UNIQUE,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const alreadyApplied = new Set(
    db
      .prepare("SELECT filename FROM _migrations")
      .all()
      .map((row) => row.filename)
  );

  const migrationsDir = path.join(__dirname, "migrations");
  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  let appliedCount = 0;
  for (const file of files) {
    if (alreadyApplied.has(file)) {
      console.log(`  skip (already applied): ${file}`);
      continue;
    }
    const sql = fs.readFileSync(path.join(migrationsDir, file), "utf-8");
    db.exec("BEGIN");
    try {
      db.exec(sql);
      db.prepare("INSERT INTO _migrations (filename) VALUES (?)").run(file);
      db.exec("COMMIT");
      console.log(`  applied: ${file}`);
      appliedCount++;
    } catch (err) {
      db.exec("ROLLBACK");
      console.error(`  FAILED: ${file} -- ${err.message}`);
      throw err;
    }
  }

  console.log(`Migrations complete. ${appliedCount} newly applied, ${files.length - appliedCount} already up to date.`);
}

if (require.main === module) {
  try {
    run();
    process.exit(0);
  } catch (err) {
    console.error("Migration run failed:", err.message);
    process.exit(1);
  }
}

module.exports = { run };
