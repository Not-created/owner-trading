-- 002_broker_account_fields.sql
-- Phase 1 (Kotak Neo account connection) needs two fields the foundation
-- schema didn't include: a human-readable account label, and a timestamp
-- that only updates on a SUCCESSFUL connection (last_transition_at already
-- exists but updates on every transition, including failures -- not the
-- same thing).

ALTER TABLE broker_accounts ADD COLUMN account_label TEXT;
ALTER TABLE broker_connection_state ADD COLUMN last_connected_at TEXT;
