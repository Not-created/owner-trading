-- Phase 12: durable execution-chain snapshots for the owner UI.
CREATE TABLE IF NOT EXISTS execution_audit_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  internal_order_id TEXT NOT NULL,
  chain_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_execution_audit_snapshots_order ON execution_audit_snapshots(internal_order_id, id DESC);
