-- Phase 11: reproducible backtest metadata and report metrics.
ALTER TABLE backtests ADD COLUMN engine_version TEXT;
ALTER TABLE backtests ADD COLUMN dataset_hash TEXT;
ALTER TABLE backtests ADD COLUMN parameters_hash TEXT;
ALTER TABLE backtests ADD COLUMN metrics_json TEXT;
ALTER TABLE backtests ADD COLUMN error_message TEXT;
CREATE INDEX IF NOT EXISTS idx_backtests_dataset_hash ON backtests(dataset_hash);
CREATE TABLE IF NOT EXISTS backtest_equity_points (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  backtest_id INTEGER NOT NULL REFERENCES backtests(id),
  point_no INTEGER NOT NULL,
  candle_at TEXT,
  equity REAL NOT NULL,
  drawdown REAL NOT NULL DEFAULT 0,
  UNIQUE(backtest_id, point_no)
);
CREATE INDEX IF NOT EXISTS idx_backtest_equity_backtest ON backtest_equity_points(backtest_id, point_no);
