-- Phase 7-9: immutable strategy/order/position execution chain.
-- Every strategy-generated order records its role and parent linkage.
-- This removes symbol-only exit binding and makes restart reconciliation auditable.

ALTER TABLE signals ADD COLUMN candle_at TEXT;
ALTER TABLE orders ADD COLUMN signal_id INTEGER REFERENCES signals(id);
ALTER TABLE orders ADD COLUMN algo_position_id INTEGER REFERENCES algo_positions(id);
ALTER TABLE orders ADD COLUMN order_role TEXT NOT NULL DEFAULT 'MANUAL';
ALTER TABLE orders ADD COLUMN parent_order_id TEXT;

CREATE INDEX IF NOT EXISTS idx_orders_signal_id ON orders(signal_id);
CREATE INDEX IF NOT EXISTS idx_orders_algo_position ON orders(algo_position_id, order_role);
CREATE INDEX IF NOT EXISTS idx_orders_parent ON orders(parent_order_id);

CREATE INDEX IF NOT EXISTS idx_algo_positions_instrument_status
  ON algo_positions(exchange_segment, instrument_token, status);

CREATE INDEX IF NOT EXISTS idx_trades_order_id ON trades(order_id);

-- A unique execution key on signals makes strategy evaluation idempotent across
-- process restarts/reconnects when the same completed candle is evaluated again.
CREATE INDEX IF NOT EXISTS idx_signals_execution_lookup
  ON signals(strategy_version_id, exchange_segment, instrument_token, timeframe, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_signals_candle_key ON signals(strategy_version_id, exchange_segment, instrument_token, timeframe, side, candle_at);

ALTER TABLE algo_exits ADD COLUMN filled_quantity INTEGER NOT NULL DEFAULT 0;
ALTER TABLE algo_exits ADD COLUMN completed_at TEXT;
CREATE INDEX IF NOT EXISTS idx_algo_exits_position_status ON algo_exits(algo_position_id,status);
