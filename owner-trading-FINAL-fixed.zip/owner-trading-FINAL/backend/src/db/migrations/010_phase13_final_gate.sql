-- Phase 13: immutable final safety-audit records.
CREATE TABLE IF NOT EXISTS final_audit_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT,
  status TEXT NOT NULL DEFAULT 'RUNNING',
  blocking_failures INTEGER NOT NULL DEFAULT 0,
  checks_json TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_final_audit_runs_time ON final_audit_runs(id DESC);
