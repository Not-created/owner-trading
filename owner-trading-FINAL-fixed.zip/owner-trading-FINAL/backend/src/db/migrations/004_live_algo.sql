
-- 004_live_algo.sql
-- LIVE-only algorithmic trading data model. Historical backtests never create
-- broker orders. All executable order paths write LIVE only.

CREATE TABLE IF NOT EXISTS strategy_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  strategy_id INTEGER NOT NULL REFERENCES strategies(id),
  version INTEGER NOT NULL,
  definition_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  is_live_armed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(strategy_id, version)
);
CREATE INDEX IF NOT EXISTS idx_strategy_versions_status ON strategy_versions(status, is_live_armed);

CREATE TABLE IF NOT EXISTS scanners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  definition_json TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS candles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  trading_symbol TEXT,
  timeframe TEXT NOT NULL,
  candle_at TEXT NOT NULL,
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume INTEGER,
  source TEXT NOT NULL DEFAULT 'kotak_sfeed',
  UNIQUE(exchange_segment, instrument_token, timeframe, candle_at)
);
CREATE INDEX IF NOT EXISTS idx_candles_lookup ON candles(exchange_segment, instrument_token, timeframe, candle_at DESC);

CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  strategy_version_id INTEGER REFERENCES strategy_versions(id),
  scanner_id INTEGER REFERENCES scanners(id),
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  trading_symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  side TEXT NOT NULL,
  signal_price REAL,
  conditions_json TEXT NOT NULL,
  risk_json TEXT,
  status TEXT NOT NULL DEFAULT 'DETECTED',
  internal_order_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(strategy_version_id, exchange_segment, instrument_token, timeframe, side, created_at)
);
CREATE INDEX IF NOT EXISTS idx_signals_recent ON signals(created_at DESC, status);

CREATE TABLE IF NOT EXISTS algo_positions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  trading_symbol TEXT NOT NULL,
  strategy_version_id INTEGER REFERENCES strategy_versions(id),
  entry_order_id TEXT,
  quantity INTEGER NOT NULL DEFAULT 0,
  average_entry REAL,
  stop_loss REAL,
  target REAL,
  trailing_stop REAL,
  remaining_quantity INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'OPEN',
  exit_reason TEXT,
  opened_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_algo_positions_open ON algo_positions(status, exchange_segment, instrument_token);

CREATE TABLE IF NOT EXISTS algo_exits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  algo_position_id INTEGER NOT NULL REFERENCES algo_positions(id),
  reason TEXT NOT NULL,
  requested_quantity INTEGER NOT NULL,
  internal_order_id TEXT,
  trigger_price REAL,
  status TEXT NOT NULL DEFAULT 'REQUESTED',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS backtests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  strategy_version_id INTEGER REFERENCES strategy_versions(id),
  request_json TEXT NOT NULL,
  result_json TEXT,
  status TEXT NOT NULL DEFAULT 'RUNNING',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS backtest_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  backtest_id INTEGER NOT NULL REFERENCES backtests(id),
  trading_symbol TEXT NOT NULL,
  entry_time TEXT,
  exit_time TEXT,
  side TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  entry_price REAL NOT NULL,
  exit_price REAL NOT NULL,
  gross_pnl REAL NOT NULL,
  costs REAL NOT NULL DEFAULT 0,
  net_pnl REAL NOT NULL,
  exit_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_backtest_trades_backtest ON backtest_trades(backtest_id);

CREATE TABLE IF NOT EXISTS algo_runtime_state (
  id INTEGER PRIMARY KEY CHECK(id=1),
  last_scan_at TEXT,
  last_signal_at TEXT,
  last_execution_at TEXT,
  active_strategy_count INTEGER NOT NULL DEFAULT 0,
  universe_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'STOPPED',
  last_error TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO algo_runtime_state(id) VALUES(1);

CREATE TABLE IF NOT EXISTS audit_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Remove any legacy non-LIVE executable rows during the explicit migration.
DELETE FROM orders WHERE mode <> 'LIVE';
DELETE FROM trades WHERE mode <> 'LIVE';
DELETE FROM strategies WHERE mode <> 'LIVE';
