-- Phase 10: authoritative reconciliation runs and position binding metadata.
CREATE TABLE IF NOT EXISTS reconciliation_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT,
  status TEXT NOT NULL DEFAULT 'RUNNING',
  discrepancy_count INTEGER NOT NULL DEFAULT 0,
  sections_ok INTEGER NOT NULL DEFAULT 0,
  details_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_reconciliation_runs_status_time ON reconciliation_runs(status, id DESC);
ALTER TABLE algo_positions ADD COLUMN entry_side TEXT;
ALTER TABLE algo_positions ADD COLUMN broker_quantity INTEGER;
ALTER TABLE algo_positions ADD COLUMN broker_average_entry REAL;
CREATE INDEX IF NOT EXISTS idx_algo_positions_entry_order ON algo_positions(entry_order_id, status);
