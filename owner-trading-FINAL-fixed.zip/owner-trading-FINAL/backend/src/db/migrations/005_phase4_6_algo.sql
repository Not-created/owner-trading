-- Phase 4-6 schema additions. Migration runner treats duplicate-column errors as safe.
ALTER TABLE strategy_versions ADD COLUMN validation_errors_json TEXT;
ALTER TABLE algo_positions ADD COLUMN exit_quantity INTEGER;
ALTER TABLE algo_positions ADD COLUMN last_price REAL;
ALTER TABLE algo_positions ADD COLUMN trailing_stop_pct REAL;
ALTER TABLE algo_positions ADD COLUMN time_exit_bars INTEGER;
CREATE INDEX IF NOT EXISTS idx_signals_order_chain ON signals(internal_order_id, strategy_version_id);
CREATE INDEX IF NOT EXISTS idx_algo_positions_strategy ON algo_positions(strategy_version_id, status);
