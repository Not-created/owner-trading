const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const { getBrokerConnectionState } = require("../services/brokerState");
const { fetchBrokerStatus } = require("../services/brokerClient");
const brokerAccountService = require("../services/brokerAccountService");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/broker/whatsmyip
 * Official whatsmyip() -- Kotak's view of this server's outbound IP, for
 * verifying static-IP whitelisting from the Settings page. Requires an
 * active broker session (relayed as 409 by the broker service otherwise).
 */
router.get("/whatsmyip", wrap(async (req, res) => relay(res, await brokerClient.getWhatsMyIp())));

/**
 * GET /api/broker/status
 * Refreshes from the Python broker service (best-effort, short timeout)
 * then returns the current state. Never fabricates CONNECTED -- if the
 * broker service is unreachable or hasn't been configured, this reports
 * exactly that, which is what the dashboard's "Kotak Neo: Not Connected"
 * badge reads from.
 */
router.get("/status", async (req, res) => {
  const state = await fetchBrokerStatus();
  res.json({
    state: state.state,
    lastError: state.last_error,
    lastTransitionAt: state.last_transition_at,
  });
});

/**
 * GET /api/broker/status/cached
 * Same shape, but reads only what's already in SQLite -- no outbound call
 * to the broker service. Useful for a fast dashboard poll that shouldn't
 * block on the broker service's response time.
 */
router.get("/status/cached", (req, res) => {
  const state = getBrokerConnectionState();
  res.json({
    state: state.state,
    lastError: state.last_error,
    lastTransitionAt: state.last_transition_at,
  });
});

/**
 * GET /api/broker/accounts
 * This phase supports exactly one Kotak account (see
 * brokerAccountService.js) -- returns an array of 0 or 1 items for a
 * forward-compatible response shape, never any secret field.
 */
router.get("/accounts", (req, res) => {
  const account = brokerAccountService.getAccount();
  res.json({ accounts: account ? [account] : [] });
});

/**
 * POST /api/broker/accounts
 * Upserts account metadata (label/environment). Does NOT accept or store
 * credentials -- those go through POST /api/broker/kotak/credentials.
 */
router.post("/accounts", (req, res) => {
  const { accountLabel, environment } = req.body || {};
  if (environment && environment !== "prod") {
    // UAT is documented in the audited SDK as internal/undocumented --
    // not offered as a normal user-facing option.
    return res.status(400).json({ error: "Only the 'prod' environment is supported." });
  }
  const account = brokerAccountService.upsertAccount({ accountLabel, environment: "prod" });
  res.json({ account });
});

module.exports = router;
