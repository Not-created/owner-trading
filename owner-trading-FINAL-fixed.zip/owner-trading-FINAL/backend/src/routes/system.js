const express = require("express");
const { getReadinessSnapshot } = require("../services/readiness");

const router = express.Router();

// Unauthenticated on purpose -- a process supervisor / load balancer /
// systemd health check needs to reach this without a session.
router.get("/readiness", (req, res) => {
  res.json(getReadinessSnapshot());
});

module.exports = router;
