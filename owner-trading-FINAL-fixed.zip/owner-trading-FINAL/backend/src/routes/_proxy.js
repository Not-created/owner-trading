// Shared response helper: relays a broker-service result to the browser without
// ever masking a failure as success.
function relay(res, result) {
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
}

function wrap(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = { relay, wrap };
