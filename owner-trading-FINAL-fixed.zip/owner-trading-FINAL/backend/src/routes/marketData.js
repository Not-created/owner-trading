const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

// Exact shapes (validated again by the broker service against the official SDK):
//   POST /quotes       { instruments: [{ exchange_segment, instrument_token }], quote_type? }
//   POST /scrip-search { exchange_segment, symbol, expiry?, option_type?, strike_price? }
//   POST /subscribe | /unsubscribe { exchange_segment, instrument_token }   (live SFeed)
router.post("/quotes", wrap(async (req, res) => {
  const { instruments, quote_type } = req.body || {};
  relay(res, await brokerClient.getQuotes({ instruments, quote_type }));
}));

router.post("/scrip-search", wrap(async (req, res) => {
  const { exchange_segment, symbol, expiry, option_type, strike_price } = req.body || {};
  relay(res, await brokerClient.searchScrip({ exchange_segment, symbol, expiry, option_type, strike_price }));
}));

// GET /scrip-master?exchange_segment=   official scrip_master(); omit the query param for the full file index.
router.get("/scrip-master", wrap(async (req, res) => relay(res, await brokerClient.getScripMaster(req.query.exchange_segment))));

// POST /expiries { exchange, underlying, instrument_type? }
router.post("/expiries", wrap(async (req, res) => {
  const { exchange, underlying, instrument_type } = req.body || {};
  relay(res, await brokerClient.getExpiries({ exchange, underlying, instrument_type }));
}));

// POST /option-chain { exchange, underlying, expiry?, instrument_type?, count? }
router.post("/option-chain", wrap(async (req, res) => {
  const { exchange, underlying, expiry, instrument_type, count } = req.body || {};
  relay(res, await brokerClient.getOptionChain({ exchange, underlying, expiry, instrument_type, count }));
}));

// POST /historical-data { neosymbol, interval, from_date, to_date }
router.post("/historical-data", wrap(async (req, res) => {
  const { neosymbol, interval, from_date, to_date } = req.body || {};
  relay(res, await brokerClient.getHistoricalData({ neosymbol, interval, from_date, to_date }));
}));

// POST /margin -- official margin_required(), used for the order-preview margin estimate.
router.post("/margin", wrap(async (req, res) => {
  const { exchange_segment, price, order_type, product, quantity, instrument_token, transaction_type, trigger_price } = req.body || {};
  relay(res, await brokerClient.getMarginRequired({ exchange_segment, price, order_type, product, quantity, instrument_token, transaction_type, trigger_price }));
}));

router.get("/ticks", wrap(async (req, res) => relay(res, await brokerClient.getMarketTicks())));
router.get("/subscriptions", wrap(async (req, res) => relay(res, await brokerClient.getSubscriptions())));
router.post("/subscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token } = req.body || {};
  relay(res, await brokerClient.subscribe({ exchange_segment, instrument_token }));
}));
router.post("/unsubscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token } = req.body || {};
  relay(res, await brokerClient.unsubscribe({ exchange_segment, instrument_token }));
}));

module.exports = router;
