const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const config = require("../config");
const { requireLiveTradingAllowed } = require("../middleware/requireLiveTradingAllowed");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

// In LIVE mode every state-changing order call is additionally gated here
// (mode, emergency stop, broker CONNECTED). The broker service re-checks the
// same conditions plus the owner's explicit arming step: defence in depth.
function gateIfLive(req, res, next) {
  if (config.tradingMode === "LIVE") return requireLiveTradingAllowed(req, res, next);
  return next();
}

// Request body is forwarded as structured fields only. The legacy
// raw-parameter pass-through of earlier versions no longer exists.
const ORDER_FIELDS = [
  "trading_symbol", "exchange_segment", "transaction_type", "order_type", "product",
  "validity", "quantity", "price", "trigger_price", "instrument_token", "idempotency_key",
];
function pick(body) {
  const out = {};
  for (const k of ORDER_FIELDS) if (body && body[k] !== undefined) out[k] = body[k];
  return out;
}

router.get("/", wrap(async (req, res) => relay(res, await brokerClient.getOrders(req.query.limit))));
router.post("/", gateIfLive, wrap(async (req, res) => relay(res, await brokerClient.placeOrder(pick(req.body)))));

router.post("/cancel", gateIfLive, wrap(async (req, res) => {
  const { internalOrderId } = req.body || {};
  if (!internalOrderId) return res.status(400).json({ error: "internalOrderId is required." });
  return relay(res, await brokerClient.cancelOrder(internalOrderId));
}));

router.post("/modify", gateIfLive, wrap(async (req, res) => {
  const { internalOrderId, ...rest } = req.body || {};
  if (!internalOrderId) return res.status(400).json({ error: "internalOrderId is required." });
  const { price, trigger_price, quantity, order_type, validity } = rest;
  const changes = {};
  for (const [k, v] of Object.entries({ price, trigger_price, quantity, order_type, validity })) if (v !== undefined) changes[k] = v;
  return relay(res, await brokerClient.modifyOrder(internalOrderId, changes));
}));

router.get("/trades", wrap(async (req, res) => relay(res, await brokerClient.getTrades())));

router.get("/history", wrap(async (req, res) => {
  if (!req.query.internalOrderId) return res.status(400).json({ error: "internalOrderId query parameter is required." });
  return relay(res, await brokerClient.getOrderHistory(req.query.internalOrderId));
}));

module.exports = router;
