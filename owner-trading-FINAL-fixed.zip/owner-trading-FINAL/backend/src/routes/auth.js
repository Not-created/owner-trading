const express = require("express");
const rateLimit = require("express-rate-limit");
const authController = require("../controllers/authController");

const router = express.Router();

// Slows down password-guessing: 10 attempts per 10 minutes per IP. This is a
// foundation-stage default appropriate for a single shared 8-character password;
// revisit alongside real deployment/infra hardening later.
const loginLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again later." },
});

router.post("/login", loginLimiter, authController.login);
router.post("/logout", authController.logout);
router.get("/session", authController.getSession);

module.exports = router;
