const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

router.get("/", wrap(async (req, res) => relay(res, await brokerClient.getFunds(req.query.refresh === "1"))));

module.exports = router;
