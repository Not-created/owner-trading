const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const config = require("../config");
const { getDb } = require("../db/client");
const brokerClient = require("../services/brokerClient");
const { getBrokerConnectionState, getEmergencyStopState, setEmergencyStop } = require("../services/brokerState");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

function writeAuditLog(action, details) {
  getDb().prepare("INSERT INTO audit_logs (actor, action, details) VALUES (?, ?, ?)").run("owner", action, details ? JSON.stringify(details) : null);
}

router.get("/", (req, res) => {
  res.json({ tradingMode: config.tradingMode, emergencyStop: getEmergencyStopState(), brokerConnection: getBrokerConnectionState() });
});

router.post("/emergency-stop/activate", (req, res) => {
  const reason = (req.body && req.body.reason) || "Activated by owner.";
  setEmergencyStop(true, reason);
  writeAuditLog("risk.emergency_stop.activated", { reason });
  res.json({ emergencyStop: getEmergencyStopState() });
});

router.post("/emergency-stop/clear", (req, res) => {
  setEmergencyStop(false);
  writeAuditLog("risk.emergency_stop.cleared", {});
  res.json({ emergencyStop: getEmergencyStopState() });
});

router.get("/settings", wrap(async (req, res) => relay(res, await brokerClient.getRiskSettings())));
router.post("/settings", wrap(async (req, res) => {
  const allowed = ["max_order_quantity", "max_order_value", "max_orders_per_day", "max_daily_loss", "max_open_positions"];
  const body = {};
  for (const k of allowed) if (req.body && req.body[k] !== undefined) body[k] = req.body[k];
  relay(res, await brokerClient.setRiskSettings(body));
}));

// Real gate evaluation from the broker service (SDK, session, feeds, limits, reconciliation ...).
router.get("/readiness", wrap(async (req, res) => relay(res, await brokerClient.getLiveReadiness())));

// Arming is a deliberate, separate owner action; the broker service refuses it unless every blocking gate passes.
router.post("/arm-live", wrap(async (req, res) => {
  const result = await brokerClient.armLive({ confirm: req.body && req.body.confirm });
  writeAuditLog("risk.arm_live.requested", { status: result.status });
  relay(res, result);
}));
router.post("/disarm-live", wrap(async (req, res) => {
  writeAuditLog("risk.disarm_live", {});
  relay(res, await brokerClient.disarmLive());
}));

router.post("/reconcile", wrap(async (req, res) => relay(res, await brokerClient.reconcile())));

module.exports = router;
