const config = require("../config");
const { BROKER_STATES, getBrokerConnectionState, setBrokerConnectionState } = require("./brokerState");

/**
 * Talks to the persistent Python broker service over local HTTP only.
 * Express never talks to Kotak directly.
 *
 * Phase 1: Express DOES receive Kotak credentials from the Settings UI (an
 * authenticated session is required -- see routes/brokerKotak.js) and
 * forwards them to the broker service over the loopback HTTP call below.
 * Express itself never stores, logs, or returns them -- every function
 * here that carries a `credentials` argument passes it straight through
 * in the request body and nowhere else; nothing in this file or its
 * caller writes that argument to a log, a database column, or an HTTP
 * response.
 */

function _headers(extra) {
  const h = { ...(extra || {}) };
  if (config.brokerServiceToken) h["X-Internal-Token"] = config.brokerServiceToken;
  return h;
}

async function _request(method, path, body, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs || config.brokerServiceTimeoutMs);
  try {
    const res = await fetch(`${config.brokerServiceUrl}${path}`, {
      method,
      signal: controller.signal,
      headers: _headers(body ? { "Content-Type": "application/json" } : {}),
      body: body ? JSON.stringify(body) : undefined,
    });
    clearTimeout(timeout);
    let parsed = null;
    try {
      parsed = await res.json();
    } catch {
      // Non-JSON body: ok/status still tell the caller enough.
    }
    return { ok: res.ok, status: res.status, body: parsed };
  } catch (err) {
    clearTimeout(timeout);
    return { ok: false, status: 0, body: null, networkError: err.message };
  }
}

const _postToBroker = (path, body, timeoutMs) => _request("POST", path, body, timeoutMs);
const _getFromBroker = (path, timeoutMs) => _request("GET", path, null, timeoutMs);

// Connect/reconnect run TOTP login + verification + reconciliation on the
// broker service and can legitimately take longer than a status poll.
const SLOW_CALL_MS = 60000;
// Order placement waits for the broker's answer; an aborted request here means
// "outcome unknown" on the Python side, which never retries -- so give it room.
const ORDER_CALL_MS = 20000;

async function fetchBrokerStatus() {
  const r = await _getFromBroker("/status");
  if (r.networkError) {
    setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, "broker service unreachable: " + r.networkError);
    return getBrokerConnectionState();
  }
  if (!r.ok || !r.body) {
    setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, `broker service returned HTTP ${r.status}`);
    return getBrokerConnectionState();
  }
  const state = Object.values(BROKER_STATES).includes(r.body.state) ? r.body.state : BROKER_STATES.CONNECTION_ERROR;
  setBrokerConnectionState(state, r.body.last_error || null);
  return getBrokerConnectionState();
}

/** Full broker-service status (state + SDK + websocket health) for the UI. */
const getBrokerDetail = () => _getFromBroker("/status");

async function saveCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret }) {
  const result = await _postToBroker("/credentials", { consumerKey, mobileNumber, ucc, mpin, totpSecret });
  if (!result.ok) {
    setBrokerConnectionState(
      BROKER_STATES.CONNECTION_ERROR,
      result.networkError ? `broker service unreachable: ${result.networkError}` : "broker service rejected credentials"
    );
  }
  return result;
}

const credentialsStatus = () => _getFromBroker("/credentials/status");
const testConnection = () => _postToBroker("/test", null, SLOW_CALL_MS);

function _applyState(result, fallback) {
  if (result.ok && result.body) {
    const state = Object.values(BROKER_STATES).includes(result.body.state) ? result.body.state : fallback;
    setBrokerConnectionState(state, result.body.last_error || null);
  }
}

async function connect() {
  const result = await _postToBroker("/connect", null, SLOW_CALL_MS);
  if (result.ok && result.body) _applyState(result, BROKER_STATES.CONNECTION_ERROR);
  else setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, result.networkError ? `broker service unreachable: ${result.networkError}` : "connect request failed");
  return result;
}

async function disconnect() {
  const result = await _postToBroker("/disconnect", null, SLOW_CALL_MS);
  _applyState(result, BROKER_STATES.DISCONNECTED);
  return result;
}

async function reconnect() {
  const result = await _postToBroker("/reconnect", null, SLOW_CALL_MS);
  if (result.ok && result.body) _applyState(result, BROKER_STATES.CONNECTION_ERROR);
  else setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, result.networkError ? `broker service unreachable: ${result.networkError}` : "reconnect request failed");
  return result;
}

const q = (params) => {
  const p = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "");
  return p.length ? "?" + p.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join("&") : "";
};

module.exports = {
  fetchBrokerStatus, getBrokerDetail, saveCredentials, credentialsStatus, testConnection, connect, disconnect, reconnect,
  getFunds: (refresh) => _getFromBroker(`/funds${q({ refresh: refresh ? 1 : undefined })}`, refresh ? SLOW_CALL_MS : undefined),
  getPositions: (refresh) => _getFromBroker(`/positions${q({ refresh: refresh ? 1 : undefined })}`, refresh ? SLOW_CALL_MS : undefined),
  getHoldings: (refresh) => _getFromBroker(`/holdings${q({ refresh: refresh ? 1 : undefined })}`, refresh ? SLOW_CALL_MS : undefined),
  getOrders: (limit) => _getFromBroker(`/orders${q({ limit })}`),
  placeOrder: (payload) => _postToBroker("/orders", payload, ORDER_CALL_MS),
  modifyOrder: (internalOrderId, payload) => _postToBroker("/orders/modify", { ...payload, internal_order_id: internalOrderId }, ORDER_CALL_MS),
  cancelOrder: (internalOrderId) => _postToBroker("/orders/cancel", { internal_order_id: internalOrderId }, ORDER_CALL_MS),
  getTrades: () => _getFromBroker(`/trades${q({})}`),
  getOrderHistory: (internalOrderId) => _getFromBroker(`/order-history${q({ internal_order_id: internalOrderId })}`, SLOW_CALL_MS),
  getQuotes: (payload) => _postToBroker("/quotes", payload, SLOW_CALL_MS),
  searchScrip: (payload) => _postToBroker("/scrip-search", payload, SLOW_CALL_MS),
  getScripMaster: (exchangeSegment) => _getFromBroker(`/scrip-master${q({ exchange_segment: exchangeSegment })}`, SLOW_CALL_MS),
  getExpiries: (payload) => _postToBroker("/expiries", payload, SLOW_CALL_MS),
  getOptionChain: (payload) => _postToBroker("/option-chain", payload, SLOW_CALL_MS),
  getHistoricalData: (payload) => _postToBroker("/historical-data", payload, SLOW_CALL_MS),
  getMarginRequired: (payload) => _postToBroker("/margin", payload, SLOW_CALL_MS),
  getWhatsMyIp: () => _getFromBroker("/whatsmyip", SLOW_CALL_MS),
  getMarketTicks: () => _getFromBroker("/market-ticks"),
  getSubscriptions: () => _getFromBroker("/subscriptions"),
  subscribe: (payload) => _postToBroker("/subscribe", payload, SLOW_CALL_MS),
  unsubscribe: (payload) => _postToBroker("/unsubscribe", payload, SLOW_CALL_MS),
  getPnl: () => _getFromBroker("/pnl"),
  getRiskSettings: () => _getFromBroker("/risk-settings"),
  setRiskSettings: (payload) => _postToBroker("/risk-settings", payload),
  armLive: (payload) => _postToBroker("/risk/arm-live", payload, SLOW_CALL_MS),
  disarmLive: () => _postToBroker("/risk/disarm-live", {}),
  getLiveReadiness: () => _getFromBroker("/live-readiness"),
  reconcile: () => _postToBroker("/reconcile", {}, SLOW_CALL_MS),
  getAuditLogs: (limit) => _getFromBroker(`/audit-logs${q({ limit })}`),
  getAlgoStrategies: () => _getFromBroker("/algo/strategies"),
  validateAlgoStrategy: (definition) => _postToBroker("/algo/strategy-validate", { definition }),
  createAlgoStrategy: (payload) => _postToBroker("/algo/strategies", payload),
  saveAlgoStrategyVersion: (id, payload) => _postToBroker("/algo/strategy-version", { ...payload, strategy_id: id }),
  armAlgoStrategy: (versionId) => _postToBroker("/algo/arm", { version_id: versionId }),
  disarmAlgoStrategy: (versionId) => _postToBroker("/algo/disarm", { version_id: versionId }),
  syncAlgoUniverse: (payload) => _postToBroker("/algo/sync-universe", payload || {}, SLOW_CALL_MS),
  getAlgoSignals: (limit) => _getFromBroker(`/algo/signals${q({ limit })}`),
  getAlgoRuntime: () => _getFromBroker("/algo/runtime"),
  getScanners: () => _getFromBroker("/algo/scanners"),
  createScanner: (payload) => _postToBroker("/algo/scanners", payload),
  updateScanner: (payload) => _postToBroker("/algo/scanners/update", payload),
  activateScanner: (scannerId) => _postToBroker("/algo/scanners/activate", { scanner_id: scannerId }),
  deactivateScanner: (scannerId) => _postToBroker("/algo/scanners/deactivate", { scanner_id: scannerId }),
  runScanner: (payload) => _postToBroker("/algo/scanners/run", payload, SLOW_CALL_MS),
  runBacktest: (payload) => _postToBroker("/algo/backtest", payload, SLOW_CALL_MS),
  getBacktests: (limit) => _getFromBroker(`/algo/backtests${q({ limit })}`),
  getExecutionChain: (internalOrderId) => _getFromBroker(`/algo/execution-chain${q({ internal_order_id: internalOrderId })}`),
  getFinalAudit: () => _getFromBroker('/final-audit', SLOW_CALL_MS),
};
