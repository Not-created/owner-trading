const { getDb } = require("../db/client");

// Exactly the states specified for this phase. CONNECTED must only ever be
// set by the broker service after a real, verified Kotak session -- never
// merely because credentials exist in config.
const BROKER_STATES = Object.freeze({
  DISCONNECTED: "DISCONNECTED",
  VERIFYING: "VERIFYING",
  CONNECTED: "CONNECTED",
  AUTH_FAILED: "AUTH_FAILED",
  SESSION_EXPIRED: "SESSION_EXPIRED",
  CONNECTION_ERROR: "CONNECTION_ERROR",
  NOT_CONFIGURED: "NOT_CONFIGURED",
  // Must mirror app/state.py's BrokerState exactly (see that file's
  // docstring) -- added alongside the same two transient states there.
  RECONNECTING: "RECONNECTING",
  RECONCILING: "RECONCILING",
});

function getBrokerConnectionState() {
  const db = getDb();
  const row = db.prepare("SELECT state, last_error, last_transition_at FROM broker_connection_state WHERE id = 1").get();
  return row || { state: BROKER_STATES.NOT_CONFIGURED, last_error: null, last_transition_at: null };
}

/**
 * Persists a broker connection state transition. This is the ONLY function
 * allowed to write broker_connection_state -- callers (the broker-status
 * poller in services/brokerClient.js) must pass one of BROKER_STATES.
 */
function setBrokerConnectionState(state, lastError = null) {
  if (!Object.values(BROKER_STATES).includes(state)) {
    throw new Error(`Invalid broker connection state: ${state}`);
  }
  const db = getDb();
  // BUGFIX (final audit): last_connected_at (migration 002) was added to
  // the schema but nothing ever wrote to it -- every "last successful
  // connection" read would have been NULL forever. Only a transition INTO
  // CONNECTED updates it; transitioning OUT (disconnect, session expiry,
  // a later error) intentionally leaves the last successful timestamp
  // alone, since "when did we last successfully connect" and "what is our
  // state right now" are different questions.
  if (state === BROKER_STATES.CONNECTED) {
    db.prepare(
      `UPDATE broker_connection_state
       SET state = ?, last_error = ?, last_transition_at = datetime('now'),
           last_connected_at = datetime('now'), updated_at = datetime('now')
       WHERE id = 1`
    ).run(state, lastError);
  } else {
    db.prepare(
      `UPDATE broker_connection_state
       SET state = ?, last_error = ?, last_transition_at = datetime('now'), updated_at = datetime('now')
       WHERE id = 1`
    ).run(state, lastError);
  }
}

function isEmergencyStopActive() {
  const db = getDb();
  const row = db.prepare("SELECT is_active FROM emergency_stop_state WHERE id = 1").get();
  return !!(row && row.is_active === 1);
}

function getEmergencyStopState() {
  const db = getDb();
  const row = db.prepare("SELECT is_active, reason, activated_at, cleared_at FROM emergency_stop_state WHERE id = 1").get();
  return row || { is_active: 0, reason: null, activated_at: null, cleared_at: null };
}

/**
 * BUGFIX (Phase 1C audit): requireLiveTradingAllowed.js already reads this
 * flag on every LIVE order attempt, but nothing anywhere ever WROTE it --
 * there was no way for an owner to actually trigger the emergency stop
 * this codebase otherwise so carefully enforces. Wired up now (see
 * routes/risk.js) as an explicit, owner-triggered, audited action.
 */
function setEmergencyStop(active, reason = null) {
  const db = getDb();
  if (active) {
    db.prepare(
      `UPDATE emergency_stop_state SET is_active = 1, reason = ?, activated_at = datetime('now'), updated_at = datetime('now') WHERE id = 1`
    ).run(reason);
  } else {
    db.prepare(
      `UPDATE emergency_stop_state SET is_active = 0, cleared_at = datetime('now'), updated_at = datetime('now') WHERE id = 1`
    ).run();
  }
}

module.exports = {
  BROKER_STATES,
  getBrokerConnectionState,
  setBrokerConnectionState,
  isEmergencyStopActive,
  getEmergencyStopState,
  setEmergencyStop,
};
