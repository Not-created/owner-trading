/**
 * Format-only validation for Kotak credential submission -- mirrors the
 * spirit of the SDK's own req_data_validation.py (reject obviously-wrong
 * input before making a network call), but these are OUR format checks,
 * not anything the SDK itself enforces; the real validity check is the
 * actual totp_login/totp_validate call in the broker service.
 */
function validateCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret }) {
  if (!consumerKey || typeof consumerKey !== "string" || consumerKey.trim().length === 0) {
    return "Consumer Key is required.";
  }
  // BUGFIX (final audit): every official Kotak Neo SDK example --
  // v2.0.2 (Kotak-Neo/kotak-neo-api-v2) and the kotakneoapi package page --
  // shows totp_login() being called with the country code included
  // (mobile_number="+919876543210"), never a bare 10-digit number. This
  // used to require exactly 10 digits and nothing else, so a value that
  // passed this check would still have been rejected or misrouted by the
  // real totp_login() call. Accept either a bare 10-digit Indian mobile
  // number (normalized to +91-prefixed before it ever reaches the SDK --
  // see broker-service/app/credential_manager.py's normalize_mobile_number)
  // or an already-E.164 +<countrycode><number> value, so existing
  // 10-digit-only input from the current Settings UI keeps working.
  if (!mobileNumber || !/^(\+\d{1,3}\d{6,14}|\d{10})$/.test(mobileNumber)) {
    return "Mobile number must be 10 digits, or include a country code (e.g. +919876543210).";
  }
  if (!ucc || typeof ucc !== "string" || ucc.trim().length === 0) {
    return "UCC / Client Code is required.";
  }
  if (!mpin || !/^\d{4,6}$/.test(mpin)) {
    return "MPIN must be 4-6 digits.";
  }
  if (!totpSecret || typeof totpSecret !== "string" || totpSecret.trim().length < 8) {
    return "TOTP secret is required (the setup key from your authenticator app, not a 6-digit code).";
  }
  return null; // no error
}

module.exports = { validateCredentials };
