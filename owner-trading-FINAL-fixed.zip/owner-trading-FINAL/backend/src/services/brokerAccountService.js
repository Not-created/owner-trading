const { getDb } = require("../db/client");

/**
 * Manages the broker_accounts table. This phase supports exactly ONE
 * Kotak account (matching the persistent single-process broker-service
 * architecture -- a second concurrent account would need a second
 * process, which is out of scope here). "Save" upserts the single row
 * rather than creating a new one each time; there is no multi-account
 * CRUD (PUT/DELETE /:id) in this phase -- see the final report for why
 * that was deliberately not built rather than faked.
 *
 * Never stores a raw secret -- only account metadata (label, UCC,
 * environment, active flag). Actual credentials live only in the broker
 * service's in-memory CredentialManager (see broker-service/app/credential_manager.py).
 */

function getAccount() {
  const db = getDb();
  return db.prepare("SELECT * FROM broker_accounts ORDER BY id ASC LIMIT 1").get() || null;
}

/**
 * Upserts the single account row. `ucc` is safe to store (it's an account
 * identifier, not a secret -- same as a username).
 */
function upsertAccount({ accountLabel, ucc, environment }) {
  const db = getDb();
  const existing = getAccount();

  if (existing) {
    db.prepare(
      `UPDATE broker_accounts
       SET account_label = ?, ucc = ?, environment = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(accountLabel || existing.account_label, ucc || existing.ucc, environment || existing.environment, existing.id);
    return getAccount();
  }

  const result = db
    .prepare(
      `INSERT INTO broker_accounts (broker_name, account_label, ucc, environment, is_active)
       VALUES ('kotak_neo', ?, ?, ?, 0)`
    )
    .run(accountLabel || null, ucc || null, environment || "prod");

  // Point the singleton connection-state row at this account now that one exists.
  db.prepare("UPDATE broker_connection_state SET broker_account_id = ? WHERE id = 1").run(result.lastInsertRowid);

  return getAccount();
}

module.exports = { getAccount, upsertAccount };
