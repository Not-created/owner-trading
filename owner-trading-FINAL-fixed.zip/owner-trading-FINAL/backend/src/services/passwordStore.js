const fs = require("fs");
const bcrypt = require("bcryptjs");
const config = require("../config");

const SALT_ROUNDS = 12;

/**
 * Server-side storage for the single Owner Trading access password.
 *
 * The plaintext password is NEVER written to disk, logged, or returned by
 * any function here -- only its bcrypt hash is persisted, to a gitignored
 * JSON file (see config.passwordHashFile). This module is the only place
 * in the backend allowed to touch that file.
 */

// Any password the owner chooses is accepted as-is -- no fixed length, no
// character-set restriction. The only real constraint is bcrypt's own,
// well-known limitation: it only uses the first 72 BYTES of the input,
// silently ignoring anything beyond that (not a product decision made
// here -- an actual property of the bcrypt algorithm every bcrypt-based
// system has). MIN_PASSWORD_BYTES=1 (must not be empty); MAX is exactly
// that bcrypt ceiling, so every accepted password is honored in full by
// the hash, and nothing longer is silently truncated without the owner
// knowing.
const MIN_PASSWORD_BYTES = 1;
const MAX_PASSWORD_BYTES = 72;

function isValidPasswordFormat(password) {
  if (typeof password !== "string") return false;
  const byteLength = Buffer.byteLength(password, "utf-8");
  return byteLength >= MIN_PASSWORD_BYTES && byteLength <= MAX_PASSWORD_BYTES;
}

function hasPasswordConfigured() {
  return fs.existsSync(config.passwordHashFile);
}

/**
 * Hash and persist a new access password, exactly as entered (subject only
 * to bcrypt's own 72-byte input limit -- see isValidPasswordFormat). Used
 * only by the deployment-time setup script (deployment/set-password.js),
 * never by any HTTP route -- there is no API endpoint that lets a caller
 * set the password over the network.
 */
async function setPassword(plainPassword) {
  if (!isValidPasswordFormat(plainPassword)) {
    throw new Error(
      `Password must be between ${MIN_PASSWORD_BYTES} and ${MAX_PASSWORD_BYTES} bytes long (bcrypt's own input limit).`
    );
  }
  const hash = await bcrypt.hash(plainPassword, SALT_ROUNDS);
  const payload = {
    hash,
    algorithm: "bcrypt",
    updatedAt: new Date().toISOString(),
  };
  fs.mkdirSync(require("path").dirname(config.passwordHashFile), { recursive: true });
  fs.writeFileSync(config.passwordHashFile, JSON.stringify(payload, null, 2), {
    mode: 0o600,
  });
}

/**
 * Verify a submitted password against the stored hash. Returns false (never
 * throws for a wrong password) so callers can't distinguish "wrong
 * password" from other failures via exception type/message.
 */
async function verifyPassword(submittedPassword) {
  if (!isValidPasswordFormat(submittedPassword)) return false;
  if (!hasPasswordConfigured()) return false;

  try {
    const raw = fs.readFileSync(config.passwordHashFile, "utf-8");
    const { hash } = JSON.parse(raw);
    if (!hash) return false;
    return await bcrypt.compare(submittedPassword, hash);
  } catch {
    return false;
  }
}

module.exports = {
  isValidPasswordFormat,
  hasPasswordConfigured,
  setPassword,
  verifyPassword,
};
