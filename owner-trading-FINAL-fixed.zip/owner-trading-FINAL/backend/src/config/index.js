const path = require("path");

/**
 * Central configuration for the backend.
 *
 * Nothing sensitive lives in this file itself -- values are read from
 * environment variables at runtime (populated by deployment/deploy.sh
 * during one-click setup, or from backend/.env in local development).
 */
const config = {
  env: process.env.NODE_ENV || "development",
  port: parseInt(process.env.PORT || "4000", 10),

  // Signs/encrypts the session cookie. Must be set in production; the
  // deploy script generates a random one if missing.
  sessionSecret: process.env.SESSION_SECRET || "dev-only-insecure-secret-change-me",

  // How long an authenticated session stays valid without re-entering the
  // password (in milliseconds). Default: 12 hours.
  // "auto" (default) | "true" | "false" -- see src/config/sessionCookie.js
  sessionCookieSecure: process.env.SESSION_COOKIE_SECURE || "auto",
  sessionMaxAgeMs: parseInt(process.env.SESSION_MAX_AGE_MS || "43200000", 10),

  // Where the hashed website-access password is stored. Never committed --
  // backend/src/data/secure/ is gitignored except for a .gitkeep placeholder.
  passwordHashFile:
    process.env.PASSWORD_HASH_FILE ||
    path.join(__dirname, "..", "data", "secure", "password.hash.json"),

  // Absolute path to the built frontend (frontend/dist), served as static
  // assets in production so the whole app runs from a single process/port.
  frontendDistPath:
    process.env.FRONTEND_DIST_PATH || path.join(__dirname, "..", "..", "..", "frontend", "dist"),

  // SQLite database file. Never deleted/recreated by the app itself --
  // only migrated (see db/migrate.js), so redeploying never destroys data.
  dbPath: process.env.DB_PATH || path.join(__dirname, "..", "..", "data", "owner-trading.db"),

  // The persistent Python broker service (see /broker-service). The
  // backend talks to it over local HTTP only -- it is never exposed
  // outside the server, and the backend never talks to Kotak directly.
  brokerServiceUrl: process.env.BROKER_SERVICE_URL || "http://127.0.0.1:8800",
  brokerServiceTimeoutMs: parseInt(process.env.BROKER_SERVICE_TIMEOUT_MS || "3000", 10),

  // Owner Trading is LIVE-only. Backtest is historical analysis and never
  // reaches the broker order API; historical analysis is kept separate from execution.
  tradingMode: "LIVE",
  // Shared secret for Express -> broker-service calls (X-Internal-Token). Mandatory for LIVE execution.
  brokerServiceToken: process.env.BROKER_SERVICE_TOKEN || "",
};

module.exports = config;
