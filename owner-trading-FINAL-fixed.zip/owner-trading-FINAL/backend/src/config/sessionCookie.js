// Session-cookie `Secure` policy, in one place.
//
// SESSION_COOKIE_SECURE
//   "auto"  (default)  express-session decides PER REQUEST from the connection: the cookie is
//                      Secure when the request arrived over HTTPS -- directly, or through a
//                      trusted proxy that sent `X-Forwarded-Proto: https` (see `trust proxy` in
//                      app.js) -- and plain when it arrived over HTTP. So the same deployment
//                      works on http://SERVER_IP/ and on https://DOMAIN/, and every HTTPS login
//                      gets a Secure cookie.
//   "true"             always Secure. The browser only keeps/returns the cookie over HTTPS, so
//                      login works on HTTPS only. Required for LIVE execution.
//   "false"            never Secure (HTTP-only bootstrap/dev). Logged as a warning at startup.
//
// HttpOnly and SameSite=Lax are fixed and not configurable here.
const VALUES = { auto: "auto", true: true, false: false, 1: true, 0: false, yes: true, no: false, on: true, off: false };

function parseSessionCookieSecure(raw) {
  if (raw === undefined || raw === null || String(raw).trim() === "") return { value: "auto", valid: true };
  const key = String(raw).trim().toLowerCase();
  if (Object.prototype.hasOwnProperty.call(VALUES, key)) return { value: VALUES[key], valid: true };
  return { value: "auto", valid: false };
}

function buildSessionCookieOptions(cfg) {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: parseSessionCookieSecure(cfg.sessionCookieSecure).value,
    maxAge: cfg.sessionMaxAgeMs,
  };
}

module.exports = { parseSessionCookieSecure, buildSessionCookieOptions };
