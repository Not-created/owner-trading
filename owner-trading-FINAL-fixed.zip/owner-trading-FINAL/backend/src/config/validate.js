// Startup validation of production-critical configuration. Pure function so it
// is unit-testable; server.js calls it and exits non-zero on any problem.
const { parseSessionCookieSecure } = require("./sessionCookie");
const INSECURE_DEFAULTS = new Set(["dev-only-insecure-secret-change-me", "change-me", "changeme", "secret"]);

function validateConfig(cfg) {
  const problems = [];
  const prod = cfg.env === "production";
  if (prod) {
    if (!cfg.sessionSecret || INSECURE_DEFAULTS.has(cfg.sessionSecret) || cfg.sessionSecret.length < 32) {
      problems.push("SESSION_SECRET must be set to a random value of at least 32 characters in production.");
    }
  }
  if (cfg.tradingMode !== "LIVE") {
    problems.push("Owner Trading is LIVE-only; only the protected live execution path is supported.");
  }
  const cookie = parseSessionCookieSecure(cfg.sessionCookieSecure);
  if (!cookie.valid) {
    problems.push(`SESSION_COOKIE_SECURE must be auto, true or false (got "${cfg.sessionCookieSecure}").`);
  }
  if (cfg.tradingMode === "LIVE") {
    if (cookie.valid && cookie.value !== true) {
      problems.push("LIVE execution requires SESSION_COOKIE_SECURE=true (LIVE control is HTTPS-only).");
    }
    if (!prod) problems.push("LIVE execution requires NODE_ENV=production.");
    if (!cfg.brokerServiceToken || cfg.brokerServiceToken.length < 32) {
      problems.push("LIVE execution requires BROKER_SERVICE_TOKEN (>= 32 chars), the same value as the broker service.");
    }
  }
  if (!/^https?:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(cfg.brokerServiceUrl)) {
    problems.push(`BROKER_SERVICE_URL must point at loopback (got ${cfg.brokerServiceUrl}); the broker service must never be exposed.`);
  }
  return problems;
}

// Non-fatal advisories printed at startup.
function configWarnings(cfg) {
  const warnings = [];
  const cookie = parseSessionCookieSecure(cfg.sessionCookieSecure);
  if (cfg.env === "production" && cookie.valid && cookie.value === false) {
    warnings.push("SESSION_COOKIE_SECURE=false: session cookies are never Secure. Use only for an HTTP-only bootstrap; prefer 'auto'.");
  }
  if (cfg.env === "production" && cookie.valid && cookie.value === "auto") {
    warnings.push("SESSION_COOKIE_SECURE=auto: logins over plain HTTP are accepted with a non-Secure cookie. HTTPS logins get a Secure cookie.");
  }
  return warnings;
}

module.exports = { validateConfig, configWarnings };
