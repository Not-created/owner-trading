const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const cors = require("cors");

const config = require("./config");
const { buildSessionCookieOptions } = require("./config/sessionCookie");
const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");
const brokerRoutes = require("./routes/broker");
const brokerKotakRoutes = require("./routes/brokerKotak");
const systemRoutes = require("./routes/system");
const fundsRoutes = require("./routes/funds");
const ordersRoutes = require("./routes/orders");
const marketDataRoutes = require("./routes/marketData");
const logsRoutes = require("./routes/logs");
const riskRoutes = require("./routes/risk");
  const algoRoutes = require("./routes/algo");
const finalAuditRoutes = require("./routes/finalAudit");

function createApp() {
  const app = express();

  app.disable("x-powered-by");
  // Exactly one trusted hop: the local nginx. req.secure / req.ip then follow its
  // X-Forwarded-Proto / X-Forwarded-For, which is what `secure: "auto"` relies on.
  app.set("trust proxy", 1);

  app.use(express.json());
  app.use(cookieParser());

  // In production the frontend is served by this same process (see below),
  // so CORS is same-origin and this is mostly a no-op. In local development
  // the frontend dev server runs on a different port, so it's allowlisted.
  if (config.env !== "production") {
    app.use(
      cors({
        origin: true,
        credentials: true,
      })
    );
  }

  app.use(
    session({
      name: "owner_trading_sid",
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      // httpOnly, sameSite=lax and the env-aware `secure` policy (auto/true/false)
      // live in config/sessionCookie.js. With "auto" the cookie is Secure exactly
      // when the request is HTTPS (directly or via the trusted proxy's
      // X-Forwarded-Proto), so HTTP and HTTPS deployments both keep working.
      cookie: buildSessionCookieOptions(config),
      // NOTE: this uses express-session's default in-memory store, which is
      // fine for a single-process foundation deployment but does not
      // survive a process restart or scale across multiple instances. If
      // the deployment target changes (multi-instance, serverless), swap in
      // a persistent store (e.g. Redis) here -- no other code needs to
      // change.
    })
  );

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", env: config.env });
  });

  app.use("/api", systemRoutes); // GET /api/readiness (unauthenticated, for process supervisors)
  app.use("/api/auth", authRoutes);
  app.use("/api/dashboard", dashboardRoutes);
  app.use("/api/broker", brokerRoutes);
  app.use("/api/broker/kotak", brokerKotakRoutes);
  app.use("/api/funds", fundsRoutes);
  app.use("/api/orders", ordersRoutes);
  app.use("/api/market-data", marketDataRoutes);
  app.use("/api/logs", logsRoutes);
  app.use("/api/risk", riskRoutes);
  app.use("/api/algo", algoRoutes);
  app.use("/api/final-audit", finalAuditRoutes);

  // Serve the built frontend (frontend/dist) as static assets, and fall back
  // to index.html for any non-API route so client-side routing (React
  // Router) works on a hard refresh/direct URL. This lets the whole app run
  // from a single process/port in production.
  if (fs.existsSync(config.frontendDistPath)) {
    app.use(express.static(config.frontendDistPath));
    app.get(/^(?!\/api).*/, (req, res) => {
      res.sendFile(path.join(config.frontendDistPath, "index.html"));
    });
  } else {
    app.get("/", (req, res) => {
      res.status(200).send(
        "Owner Trading backend is running, but no frontend build was found at " +
          config.frontendDistPath +
          ". Run the frontend build step (see deployment/deploy.sh) first."
      );
    });
  }

  // Central error handler -- never leak stack traces or internal details to
  // the client; log server-side only, and never log request bodies (which
  // could contain the password) at this layer.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error("[owner-trading] unhandled error:", err && err.message);
    res.status(500).json({ error: "Internal server error." });
  });

  return app;
}

module.exports = createApp;
