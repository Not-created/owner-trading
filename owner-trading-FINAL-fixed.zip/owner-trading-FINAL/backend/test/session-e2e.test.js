// End-to-end session/login test against the REAL Express app (express-session, bcrypt, rate limiter).
// Runs wherever `npm install` has been done (deploy.sh runs it on the VPS). In an environment without
// the npm dependencies it SKIPS with an explicit reason instead of pretending to pass.
const test = require("node:test");
const assert = require("node:assert");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const missing = ["express", "express-session", "cookie-parser", "express-rate-limit", "bcryptjs", "cors"].filter((m) => {
  try { require.resolve(m); return false; } catch { return true; }
});
const SKIP = missing.length ? `npm dependencies not installed here: ${missing.join(", ")}` : false;

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ot-e2e-"));
process.env.NODE_ENV = "production";
process.env.SESSION_SECRET = "s".repeat(48);
process.env.DB_PATH = path.join(tmp, "t.db");
process.env.PASSWORD_HASH_FILE = path.join(tmp, "pw.json");

process.env.BROKER_SERVICE_URL = "http://127.0.0.1:9";   // unreachable on purpose: these tests never need the broker
const PASSWORD = "e2e-test-password";

let createApp, config;
if (!SKIP) {
  require("../src/db/migrate").run();
  config = require("../src/config");
  createApp = require("../src/app");
}

async function withServer(secureSetting, fn) {
  config.sessionCookieSecure = secureSetting;
  const server = createApp().listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (p, { method = "GET", headers = {}, body, cookie } = {}) => {
    const res = await fetch(base + p, {
      method, redirect: "manual",
      headers: { ...(body ? { "Content-Type": "application/json" } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined,
    });
    let json = null;
    try { json = await res.json(); } catch {}
    return { status: res.status, json, setCookie: res.headers.getSetCookie() };
  };
  try { await fn(call); } finally { await new Promise((r) => server.close(r)); }
}

const sid = (setCookie) => {
  const c = setCookie.find((x) => x.startsWith("owner_trading_sid="));
  return c ? { header: c, pair: c.split(";")[0] } : null;
};
const attrs = (header) => header.split(";").slice(1).map((s) => s.trim().toLowerCase());

test("set the access password (bcrypt hash only)", { skip: SKIP }, async () => {
  await require("../src/services/passwordStore").setPassword(PASSWORD);
  const raw = fs.readFileSync(process.env.PASSWORD_HASH_FILE, "utf8");
  assert.ok(!raw.includes(PASSWORD), "plaintext must never be stored");
  assert.match(raw, /\$2[aby]\$/);
});

test("HTTP (auto): login succeeds, cookie is HttpOnly + SameSite=Lax and NOT Secure, session works, logout destroys it", { skip: SKIP }, async () => {
  await withServer("auto", async (call) => {
    const login = await call("/api/auth/login", { method: "POST", body: { password: PASSWORD } });
    assert.strictEqual(login.status, 200);
    assert.deepStrictEqual(login.json, { success: true });
    const c = sid(login.setCookie);
    assert.ok(c, "a session cookie must be issued over plain HTTP in auto mode");
    const a = attrs(c.header);
    assert.ok(a.includes("httponly"));
    assert.ok(a.includes("samesite=lax"));
    assert.ok(!a.includes("secure"), "HTTP login must not receive a Secure cookie (the browser would drop it)");
    assert.deepStrictEqual((await call("/api/auth/session", { cookie: c.pair })).json, { authenticated: true });
    assert.strictEqual((await call("/api/risk", { cookie: c.pair })).status, 200);
    assert.strictEqual((await call("/api/risk")).status, 401, "no cookie -> no access");
    assert.strictEqual((await call("/api/auth/logout", { method: "POST", cookie: c.pair })).status, 200);
    assert.deepStrictEqual((await call("/api/auth/session", { cookie: c.pair })).json, { authenticated: false });
    assert.strictEqual((await call("/api/risk", { cookie: c.pair })).status, 401, "destroyed session must be rejected");
  });
});

test("HTTPS via trusted proxy (auto): X-Forwarded-Proto=https -> Secure cookie, session works", { skip: SKIP }, async () => {
  await withServer("auto", async (call) => {
    const https = { "X-Forwarded-Proto": "https" };
    const login = await call("/api/auth/login", { method: "POST", body: { password: PASSWORD }, headers: https });
    assert.strictEqual(login.status, 200);
    const c = sid(login.setCookie);
    assert.ok(c);
    const a = attrs(c.header);
    assert.ok(a.includes("secure"), "HTTPS login must receive a Secure cookie");
    assert.ok(a.includes("httponly") && a.includes("samesite=lax"));
    assert.strictEqual((await call("/api/risk", { cookie: c.pair, headers: https })).status, 200);
    assert.strictEqual((await call("/api/auth/logout", { method: "POST", cookie: c.pair, headers: https })).status, 200);
    assert.strictEqual((await call("/api/risk", { cookie: c.pair, headers: https })).status, 401);
  });
});

test("SESSION_COOKIE_SECURE=true: HTTPS-only -- no cookie is issued over HTTP, Secure cookie over HTTPS", { skip: SKIP }, async () => {
  await withServer("true", async (call) => {
    const http = await call("/api/auth/login", { method: "POST", body: { password: PASSWORD } });
    assert.strictEqual(sid(http.setCookie), null, "a Secure-only deployment must not issue a session over HTTP");
    const https = await call("/api/auth/login", { method: "POST", body: { password: PASSWORD }, headers: { "X-Forwarded-Proto": "https" } });
    assert.strictEqual(https.status, 200);
    assert.ok(attrs(sid(https.setCookie).header).includes("secure"));
  });
});

test("wrong password: 401 and no session cookie on HTTP or HTTPS", { skip: SKIP }, async () => {
  await withServer("auto", async (call) => {
    for (const headers of [{}, { "X-Forwarded-Proto": "https" }]) {
      const r = await call("/api/auth/login", { method: "POST", body: { password: "wrong" }, headers });
      assert.strictEqual(r.status, 401);
      assert.strictEqual(sid(r.setCookie), null);
    }
  });
});

test("forged / unsigned session cookies are rejected", { skip: SKIP }, async () => {
  await withServer("auto", async (call) => {
    assert.strictEqual((await call("/api/risk", { cookie: "owner_trading_sid=s%3Aforged.invalid" })).status, 401);
  });
});
