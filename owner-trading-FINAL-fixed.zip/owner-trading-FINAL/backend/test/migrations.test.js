const test = require("node:test");
const assert = require("node:assert");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const dbPath = path.join(os.tmpdir(), `ot-mig-${process.pid}.db`);
try { fs.unlinkSync(dbPath); } catch {}
process.env.DB_PATH = dbPath;

test("all migrations apply cleanly on a fresh database and are idempotent", () => {
  const { run } = require("../src/db/migrate");
  run();
  run();
  const { DatabaseSync } = require("node:sqlite");
  const db = new DatabaseSync(dbPath);
  const cols = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  for (const c of ["client_tag", "exchange_order_id", "filled_quantity", "average_price", "broker_status", "outcome_unknown"]) {
    assert.ok(cols("orders").includes(c), `orders.${c}`);
  }
  assert.ok(cols("positions_snapshot").includes("buy_amount"));
  assert.ok(cols("funds_snapshot").includes("unrealized_mtom"));
  assert.ok(cols("risk_settings").includes("live_trading_armed"));
  const rs = db.prepare("SELECT live_trading_armed FROM risk_settings WHERE id = 1").get();
  assert.strictEqual(rs.live_trading_armed, 0, "LIVE must start disarmed");
  const applied = db.prepare("SELECT COUNT(*) AS n FROM _migrations").get().n;
  assert.strictEqual(applied, fs.readdirSync(path.join(__dirname, "../src/db/migrations")).filter((f) => f.endsWith(".sql")).length);
  db.close();
});
