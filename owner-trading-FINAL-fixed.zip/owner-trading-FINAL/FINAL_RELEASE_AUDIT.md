# Owner Trading — Phase 1–13 Final Release Audit (Hardened)

## Architecture
React/Vite → Node/Express → SQLite → Python broker-service → official Kotak Neo SDK 3.0.7; systemd + Nginx; LIVE execution only.

## Fixes applied in this final hardening pass
- Fixed the broken session-cookie unit test contract: `httpOnly=true`, `SameSite=Lax`, configured lifetime, and `secure` now correctly assert `auto|true|false` behavior.
- Fixed LIVE configuration tests so a valid LIVE configuration includes the required 32+ character internal broker token and requires `SESSION_COOKIE_SECURE=true`.
- Fixed `deployment/verify-deployment.sh` undefined `M1` logic and aligned its checks with the HTTPS-only LIVE deployment.
- Backend now binds to `127.0.0.1`; Nginx is the public entry point.
- One-command deployment now self-elevates through `sudo` when launched by the normal Ubuntu user, instead of silently falling back to a non-persistent HTTP process.
- One-command deployment now provisions HTTPS for both supported paths: Let's Encrypt for a DNS name, or a self-signed IP bootstrap certificate when no domain is supplied. HTTP redirects to HTTPS.
- HTTPS deployment smoke checks correctly handle the self-signed IP bootstrap certificate with `curl -k` only for that local certificate case.
- Encrypted Kotak credential storage moved to `/var/lib/owner-trading/kotak-credentials.enc`, a dedicated writable state directory compatible with `ProtectSystem=strict`; an existing old `/etc/owner-trading/kotak-credentials.enc` is migrated automatically.
- `verify-deployment.sh` now reads the deployed runtime from `/opt/owner-trading` rather than incorrectly depending on a source-tree `.env`.
- Removed generated Python caches and other runtime artifacts from the release tree.

## Verification completed in the build environment
- Backend Node tests: **23 passed, 6 skipped**. The 6 skipped tests require npm runtime dependencies that are intentionally not installed in this build environment; deployment installs them before running the suite.
- Broker-service pytest: **249 passed, 3 skipped, 0 failed**.
- Deployment/session/config/systemd targeted tests: **34 passed, 3 skipped, 0 failed**.
- Python compileall: PASS.
- Node syntax checks across backend source: PASS.
- Shell syntax checks for `deploy.sh`, `deployment/verify-deployment.sh`, and `deployment/set-mode.sh`: PASS.
- Fresh SQLite migration replay through migrations 001–010: PASS through the backend migration test; migrations are idempotent.
- Vendored Kotak SDK integrity/conformance tests: PASS within the broker-service suite.
- Static LIVE safety checks: PASS within the broker-service suite.
- No `.env`, private key, database, WAL/SHM, node_modules, or Python cache artifacts are included in the release tree.

## Frontend build verification limitation
The build environment used for packaging has no working DNS/network access to `registry.npmjs.org`, so a fresh frontend `npm install` and `vite build` could not be executed here. The deployment script remains fail-closed: it installs frontend dependencies and refuses to continue if `npm run build` fails or `frontend/dist/index.html` is missing. No frontend build PASS is falsely claimed.

## LIVE-money boundary
No Kotak credentials were used and no real-money order was submitted during this audit. Software verification is not the same as broker-side live-money verification.
