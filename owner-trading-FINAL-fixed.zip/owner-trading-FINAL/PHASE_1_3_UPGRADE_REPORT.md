# Owner Trading — Phase 1–3 Upgrade Report

## Scope
This release modifies the existing Owner Trading LIVE-only architecture without replacing React/Vite, Node/Express, SQLite, the Python Kotak service, systemd, Nginx, or the vendored official `kotakneoapi` 3.0.7 SDK.

## Phase 1 — Deployment / Production Runtime
- Production services now run from `/opt/owner-trading`, even when the Git checkout is under `/home/ubuntu/...`.
- `ProtectHome=true` is retained; the deployment no longer tries to re-expose `/home` with `ReadOnlyPaths`.
- Deployment synchronizes source to `/opt/owner-trading` with persistent `.env`, DB, secure password hash, broker data, and virtualenv excluded from deletion.
- Node 22.5+ is explicitly checked; when running as root on Ubuntu and `node:sqlite` is unavailable, deployment installs/upgrades system Node 22.
- Required OS package installation is fail-closed instead of warning and continuing.
- LIVE deployment now requires `DOMAIN` + `CERTBOT_EMAIL` and verified HTTPS. HTTP port 80 redirects to HTTPS except the ACME challenge path.
- Session cookie remains `SESSION_COOKIE_SECURE=true` for LIVE control.
- Nginx verification now checks the real HTTP→HTTPS redirect and real HTTPS upstream path.
- `npm ci` is used automatically when a package-lock exists; this release could not generate lockfiles in the offline build environment because the npm registry/cache was unavailable.

## Phase 2 — Credentials / Restart Recovery
- Kotak credentials submitted from Settings are authenticated against the real broker **before** they are persisted.
- Failed authentication is never reported as saved.
- Successful credentials are encrypted with Fernet and stored in `/etc/owner-trading/kotak-credentials.enc` with restrictive permissions.
- The encryption key is generated once by deployment and kept in the protected broker/backend environment configuration.
- Broker restart recovers the encrypted credentials into memory but does **not** auto-login; an explicit Connect action still performs real Kotak authentication and verification.
- No credential or session token is returned by API status responses.

## Phase 3 — Market Data / SFeed / Candle Engine
- SFeed subscription registry has a hard 3000-instrument cap matching official SDK v3.0.7.
- NSE cash universe synchronization truncates candidates to the supported 3000 subscription maximum and reports candidate/subscribed/rejected/truncated counts instead of silently swallowing subscription failures.
- SFeed exchange market-status subscription is enabled and its status is exposed in broker WebSocket status.
- Malformed order-feed messages with missing data are ignored safely.
- Candle timestamps use Asia/Kolkata market time.
- Added live `1d` candle support.
- Cumulative SFeed day volume is converted into per-candle delta volume, including day-rollover handling.
- Strategy evaluation is triggered only after a completed 5-minute candle, not on the first tick of a new 5-minute candle.
- LIVE price lookup now uses direct indexed instrument lookup instead of scanning only the latest 1000 ticks.
- Daily order-limit accounting uses the India trading-day boundary (UTC+05:30).

## Validation performed
- `bash -n deploy.sh` — PASS
- Python `compileall` — PASS
- Node syntax checks — PASS
- Broker-service test suite: **237 tests, 0 failures, 0 errors, 3 skipped**
- Added Phase 1–3 regression tests for encrypted credential recovery, IST candle/volume behavior, and the 3000-token SFeed cap.
- Candle smoke test confirmed a 5-minute 09:15 IST bar with cumulative volumes 100→110 persisted volume delta 10.
- Credential persistence smoke test confirmed encrypted save → clear → decrypt/load recovery.

## Explicit environment limitation
The current build environment has no usable npm registry/cache, so production `npm install`/frontend build and lockfile generation could not be executed here. The deployment script will fail closed if the VPS cannot reach npm/PyPI as required.

## LIVE safety
No real Kotak credentials were used and no real-money order was placed during this build. The existing LIVE safety gates remain in place.
