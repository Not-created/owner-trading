# Owner Trading — Final Build Audit

## Scope implemented

- LIVE-only executable trading path.
- Historical Backtest remains analysis-only and cannot place broker orders.
- Removed executable local trading simulator and all UI/API references to it.
- Added strategy versions and no-code strategy builder UI.
- Added centralized indicator/condition evaluation engine.
- Added live candle aggregation for 1m/3m/5m/15m/30m/1h.
- Added stock scanner service using Kotak-backed instrument/candle data.
- Added LIVE signal engine.
- Added LIVE entry path through the existing Kotak Neo order service.
- Added broker-confirmed strategy-position binding and LIVE exit engine.
- Added stop-loss, target, strategy-exit and partial-quantity-aware exit foundation.
- Added backtest engine with configurable slippage/fees and trade statistics.
- Added algo runtime, signal, scanner, backtest and execution-monitor UI pages.
- Added LIVE-only database migration 004 for strategy/scanner/candle/signal/position/exit/backtest state.
- Added deployment cleanup so legacy execution-mode variables are removed and no database backup is created.
- Deployment password policy is exactly 8 characters.
- Preserved official vendored Kotak Neo SDK 3.0.7 and existing SDK conformance checks.

## Validation completed in this build environment

- Python syntax/import compilation: PASS.
- Node JavaScript syntax checks: PASS.
- Shell syntax checks: PASS.
- Clean SQLite migration 001 → 010: PASS.
- Broker-service test suite: PASS — 247 tests, 3 skipped.
- Cross-layer frontend → Express → broker-service route contract tests: PASS within the broker-service suite.
- Repository scan for executable PAPER/simulator references: PASS.
- Repository scan for obsolete TRADING_MODE configuration: PASS for application configuration; deploy.sh contains only the cleanup line that removes any legacy variable.
- Official Kotak Neo SDK 3.0.7 vendored integrity/signature conformance tests: PASS as covered by the test suite.

## Not externally verifiable inside this build environment

- The frontend production build could not be executed because this environment could not resolve registry.npmjs.org, so npm dependencies could not be downloaded. The deploy.sh build step remains configured to run `npm install` and `npm run build` on the VPS.
- No real Kotak credentials were available, so an actual authenticated live order, fill, SFeed connection and exit order could not be placed here. The existing SDK adapter/conformance and live safety tests were run instead.

## Live execution safety

A LIVE order is blocked unless the defense-in-depth checks pass, including broker connection, emergency stop, risk limits, reconciliation/unknown-order state, and explicit owner arming. Unknown broker submission outcomes remain reconciliation-required and are never blindly retried.

## Deployment

Run from the extracted project root:

```bash
chmod +x deploy.sh
sudo ./deploy.sh
```

The deploy script does not place orders and does not arm an algorithm. After deployment, configure Kotak, connect, configure risk, reconcile, create/validate a strategy, sync the market universe, and explicitly arm LIVE execution.


## Phase 1–13 final re-audit

- Phase 10 authoritative reconciliation-run ledger added; LIVE readiness requires a recent clean reconciliation with orders, trades, positions, holdings and funds all successful and discrepancy-free.
- Phase 11 backtests now persist engine version, dataset/parameter hashes, equity curve and expanded report metrics; end-of-data positions are explicitly closed.
- Phase 12 execution-chain inspection is wired frontend → Express → Python and displays Strategy Version → Signal → Internal Order → Broker Order → Trade → Position → Exit.
- Phase 13 final audit is durable and fail-closed.
- Critical Phase 1–9 re-audit fix: strategy ENTRY/EXIT metadata is now actually propagated through `order_service` into the durable `orders` row; ENTRY requires `signal_id`, EXIT requires `algo_position_id` + `parent_order_id`.
- Critical gate fix: the newly-created SUBMITTING order is excluded only from its own second defense-in-depth check; unrelated pending/unknown orders still block new LIVE submissions.

## Final verification limitation
The package has **not** been authenticated against the user's Kotak account and no real-money order has been sent. The software can be validated deeply offline, but that cannot prove broker-side live execution without the actual VPS, credentials, live SFeed/order feed and a separately authorised controlled live order.
