# Owner Trading — Phase 1–13 Final Upgrade / Deep Route Audit

## Locked architecture
React + Vite → Node/Express → SQLite → Python broker-service → official Kotak Neo SDK 3.0.7; systemd + Nginx; LIVE execution only.

## Phase 10 — Reconciliation hardening
- Durable reconciliation run ledger.
- LIVE readiness now requires a recent **clean** reconciliation with all five authoritative sections: orders, trades, positions, holdings and funds.
- Session loss, failed sections and discrepancies fail the reconciliation run closed.
- Strategy position recovery remains bound to the immutable ENTRY order chain.

## Phase 11 — Backtest/report hardening
- Reproducible engine version, dataset hash and parameter hash persisted.
- Strict historical timestamp validation.
- Slippage/fees validation.
- End-of-dataset positions are explicitly closed at the last available price.
- Equity curve, drawdown, gross P&L, costs, expectancy and consecutive-loss metrics persisted.
- Backtest remains historical-only; it never enters the live order service.

## Phase 12 — Final UI/API integration
- Added immutable execution-chain inspection: Strategy Version → Signal → Internal Order → Broker Order → Trade → Position → Exit.
- Added owner-facing final-audit status in Execution Monitor.
- Added full frontend → Express → Python route wiring checks.

## Phase 13 — Final safety gate
- Final audit endpoint and durable audit record.
- Checks SDK/version/conformance, LIVE mode, broker connection, emergency stop, clean reconciliation, unknown-order state and simulator/paper static leakage.
- Deployment remains fail-closed.

## Critical fixes discovered while re-auditing Phase 1–9
- Strategy `ENTRY`/`EXIT` metadata was being supplied by the algo engine but was not being propagated by the order validation/persistence path; this is now fixed.
- ENTRY orders now require `signal_id`; EXIT orders require `algo_position_id` and `parent_order_id`.
- Same-candle immutable signals are not retried into duplicate broker orders after restart.

## Verification limitation
No Kotak credentials were used and no real-money order was placed. A live-money claim requires actual VPS + valid credentials + broker session + a separately authorised real order. This package therefore reports software/static/integration verification only, not proof that a live Kotak order will execute successfully.
