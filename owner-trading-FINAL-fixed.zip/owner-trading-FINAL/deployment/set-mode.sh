#!/usr/bin/env bash
set -euo pipefail
echo "Owner Trading is LIVE-only. There is no executable mode switch."
echo "Use the protected Risk page to ARM/DISARM LIVE execution after readiness checks pass."
exit 2
