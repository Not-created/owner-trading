#!/usr/bin/env node
/**
 * Deployment-time helper: reads an exactly-8-character password from stdin (never from
 * argv, so it can't appear in `ps`/shell history) and stores its bcrypt
 * hash via backend/src/services/passwordStore.js.
 *
 * Usage (called by the root-level deploy.sh, not meant to be run standalone
 * unless you deliberately want to (re)set the password):
 *   printf '%s' 'Ab12@X9!' | node deployment/set-password.js
 */
const path = require("path");
const passwordStore = require(path.join(__dirname, "..", "backend", "src", "services", "passwordStore"));

function readStdin() {
  return new Promise((resolve, reject) => {
    let data = "";
    process.stdin.setEncoding("utf-8");
    process.stdin.on("data", (chunk) => (data += chunk));
    process.stdin.on("end", () => resolve(data.trim()));
    process.stdin.on("error", reject);
  });
}

async function main() {
  const password = await readStdin();

  if (!passwordStore.isValidPasswordFormat(password)) {
    console.error("ERROR: password must be exactly 8 characters.");
    process.exit(1);
  }

  await passwordStore.setPassword(password);
  console.log("Access password stored (hashed). Plaintext was not written to disk.");
}

main().catch((err) => {
  console.error("ERROR: failed to set password:", err.message);
  process.exit(1);
});
