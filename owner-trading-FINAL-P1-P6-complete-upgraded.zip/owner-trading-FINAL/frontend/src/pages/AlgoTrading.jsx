import usePolling from "../hooks/usePolling";
import {api} from "../api/client";

export default function AlgoTrading(){
 const d=usePolling(()=>api.getAlgoRuntime(),2000);
 const r=d.body?.runtime;
 const ready=usePolling(()=>api.getLiveReadiness(),3000);
 async function syncMetadata(){
   const x=await api.syncAlgoUniverse(0);
   alert(x.ok
     ? `NSE cash metadata refreshed: ${x.body.synced} instruments. No live subscriptions were created.`
     : (x.body?.error||"Metadata sync failed"));
   d.reload();
 }
 return <div className="page">
  <div className="page__header"><h2 className="page__title">Algo Trading</h2><p className="page__subtitle">LIVE-only strategy execution monitor.</p></div>
  <div className="metrics-grid">
   <div className="card"><strong>Runtime</strong><h2>{r?.status||"—"}</h2></div>
   <div className="card"><strong>Strategies</strong><h2>{r?.active_strategy_count??0}</h2></div>
   <div className="card"><strong>Scrip metadata</strong><h2>{r?.universe_count??0}</h2></div>
   <div className="card"><strong>LIVE readiness</strong><h2>{ready.body?.ready?"READY":"BLOCKED"}</h2></div>
  </div>
  <div className="card">
   <button onClick={syncMetadata}>Refresh NSE Cash Metadata</button>
   <p className="form-hint">This downloads the official NSE cash scrip master into the instrument database only. It does not subscribe the entire market. LIVE strategies subscribe only their explicit instrument-token universe when armed.</p>
  </div>
  <div className="card"><h3 className="card__title">Execution path</h3><p>Selected market data → completed candles → indicators → scanner → strategy → signal → risk → Kotak order → fill reconciliation → position → exit.</p><p className="form-hint">Backtest is historical-only; executable orders use the official Kotak path.</p></div>
 </div>;
}
