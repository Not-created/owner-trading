"""Instrument-universe synchronisation and explicit live-feed subscriptions.

The scrip master is metadata, not a live-feed universe.  Live SFeed
subscriptions are opt-in and are limited to instruments explicitly selected
by the owner/strategy.  This prevents an NSE cash metadata refresh from
silently subscribing thousands of instruments.
"""
from __future__ import annotations
import asyncio, csv, io, urllib.request, datetime as dt
from . import db
from .broker_client import broker_client
from .websocket_manager import websocket_manager

MAX_SFEED_SUBSCRIPTIONS = 3000

def _field(row, *names):
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return None

async def sync_nse_cash_and_subscribe(limit=0, instrument_tokens=None):
    """Refresh NSE cash metadata and optionally subscribe explicit instruments.

    ``limit=0`` now means metadata-only.  For backward compatibility, a
    positive ``limit`` subscribes the first N valid NSE cash rows.  New code
    should pass ``instrument_tokens`` so the live universe is explicit.
    """
    out = await asyncio.get_running_loop().run_in_executor(
        None, lambda: broker_client.read("scrip_master", exchange_segment="nse_cm")
    )
    if not out.ok:
        return {"ok": False, "error": out.message}

    url = out.data if isinstance(out.data, str) else None
    if not url:
        return {"ok": False, "error": "Kotak scrip_master did not return the NSE cash file URL."}

    raw = await asyncio.get_running_loop().run_in_executor(
        None, lambda: urllib.request.urlopen(url, timeout=30).read()
    )
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig", errors="replace"))))

    by_token = {}
    count = 0
    for r in rows:
        tok = _field(r, "pSymbol", "instrument_token", "token", "symbol_token")
        sym = _field(r, "pTrdSymbol", "trading_symbol", "tradingsymbol", "symbol")
        if not tok or not sym:
            continue
        itype = (_field(r, "pInstType", "instrument_type", "instrument") or "").upper()
        if itype and itype not in ("EQ", "EQUITY", "CASH"):
            continue
        tok, sym = str(tok), str(sym)
        # Preserve the authoritative company name exactly as published.  Do
        # not fabricate a display name from the trading symbol.
        name = _field(r, "pCompanyName", "company_name", "pSymbolName", "name")
        with db._connection() as conn:
            conn.execute(
                """INSERT INTO instruments(
                     exchange_segment,trading_symbol,instrument_token,name,
                     instrument_type,expiry,strike,option_type,lot_size,tick_size,
                     scrip_master_updated_at
                   ) VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))
                   ON CONFLICT(exchange_segment,instrument_token) DO UPDATE SET
                     trading_symbol=excluded.trading_symbol,
                     name=CASE WHEN excluded.name IS NOT NULL AND trim(excluded.name) <> ''
                              THEN excluded.name ELSE instruments.name END,
                     instrument_type=excluded.instrument_type,
                     expiry=excluded.expiry,
                     strike=excluded.strike,
                     option_type=excluded.option_type,
                     lot_size=excluded.lot_size,
                     tick_size=excluded.tick_size,
                     scrip_master_updated_at=excluded.scrip_master_updated_at""",
                ("nse_cm", sym, tok, name, itype or "EQ",
                 _field(r, "pExpiryDate", "expiry"),
                 _field(r, "pStrikePrice", "strike"),
                 _field(r, "pOptionType", "option_type"),
                 _field(r, "pLotSize", "lot_size"),
                 _field(r, "pTickSize", "tick_size")),
            )
        by_token[tok] = sym
        count += 1

    # Explicit token list is authoritative for live subscriptions.  Unknown
    # tokens are rejected rather than silently subscribing an arbitrary row.
    requested_tokens = [str(x).strip() for x in (instrument_tokens or []) if str(x).strip()]
    requested_tokens = list(dict.fromkeys(requested_tokens))
    requested_limit = int(limit or 0)
    if not requested_tokens and requested_limit > 0:
        requested_tokens = list(by_token.keys())[:min(requested_limit, MAX_SFEED_SUBSCRIPTIONS)]

    if len(requested_tokens) > MAX_SFEED_SUBSCRIPTIONS:
        return {
            "ok": False,
            "error": f"Requested live universe has {len(requested_tokens)} instruments; SFeed allows at most {MAX_SFEED_SUBSCRIPTIONS}.",
            "synced": count,
        }

    invalid = [t for t in requested_tokens if t not in by_token]
    if invalid:
        return {
            "ok": False,
            "error": f"{len(invalid)} requested instrument token(s) were not found in the NSE cash scrip master.",
            "invalid_tokens": invalid[:20],
            "synced": count,
        }

    subscribed = 0
    rejected = 0
    for tok in requested_tokens:
        try:
            await websocket_manager.subscribe("nse_cm", tok)
            subscribed += 1
        except Exception:
            rejected += 1

    db.set_algo_runtime(universe_count=count, status="RUNNING")
    return {
        "ok": rejected == 0,
        "synced": count,
        "candidateCount": len(requested_tokens),
        "subscribed": subscribed,
        "rejected": rejected,
        "subscriptionLimit": MAX_SFEED_SUBSCRIPTIONS,
        "metadataOnly": not bool(requested_tokens),
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    }
