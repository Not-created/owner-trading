const test = require("node:test");
const assert = require("node:assert");

const required = ["dotenv"];
const missing = required.filter((m) => {
  try { require.resolve(m); return false; } catch { return true; }
});
const SKIP = missing.length ? `npm dependencies not installed here: ${missing.join(", ")}` : false;

test("emergency stop blocks new exposure but permits explicitly classified EXIT orders", { skip: SKIP }, () => {
  process.env.NODE_ENV = "production";
  process.env.SESSION_SECRET = "s".repeat(48);
  process.env.BROKER_SERVICE_TOKEN = "t".repeat(32);
  process.env.BROKER_SERVICE_URL = "http://127.0.0.1:8800";
  process.env.TRADING_MODE = "LIVE";

  const brokerState = require("../src/services/brokerState");
  const { requireLiveTradingAllowed } = require("../src/middleware/requireLiveTradingAllowed");

  brokerState.setEmergencyStop(true, "test");
  brokerState.setBrokerConnectionState(brokerState.BROKER_STATES.CONNECTED, null);

  const run = (body) => new Promise((resolve) => {
    const req = { body };
    const res = {
      statusCode: 200,
      body: null,
      status(code) { this.statusCode = code; return this; },
      json(payload) { this.body = payload; resolve({ status: this.statusCode, body: payload }); },
    };
    requireLiveTradingAllowed(req, res, () => resolve({ status: 200 }));
  });

  return Promise.all([
    run({ order_role: "ENTRY" }).then((r) => assert.strictEqual(r.status, 423)),
    run({ order_role: "EXIT" }).then((r) => assert.strictEqual(r.status, 200)),
  ]).finally(() => brokerState.setEmergencyStop(false));
});
