# Owner Trading — Final P0–P16 Fix Report

Source project: `OWNER-TRADING-FINAL-LIVE-READY-UPGRADED-2026-10-02.zip`

Broker reference cross-check: official `kotak-neo-python` source archive supplied with this delivery.

## Scope

Only the requested production/LIVE execution, deployment, persistence, validation, and regression-test fixes were changed. Existing strategy/UI features and Dark/Light theme were preserved.

## Fixed

1. Reconciliation blocker hardening: unresolved orders now use the official order-history path when a broker order ID exists before being declared missing; empty portfolio sections remain successful empty snapshots.
2. Scanner binding: only explicitly declared `scanner_ids` gate a strategy; unrelated active scanners no longer suppress unbound strategies.
3. Risk-per-trade sizing: percentage/ATR/price stops are converted to actual per-unit risk distance; quantity is never rounded upward beyond the risk budget.
4. Exit state machine/crash recovery: durable exit states mirror order states; orphan requests without an internal order are released after a short recovery window; UNKNOWN broker outcomes are never blindly retried.
5. Manual LIVE order token validation: instrument token is mandatory and is cross-checked against the authoritative scrip-master symbol before the SDK order call.
6. Strategy Builder sizing UI: one explicit sizing mode at a time (quantity / capital % / risk per trade).
7. Strict numeric schema: finite-number checks plus strict integer validation for bars/limits/cooldowns/quantities.
8. Candle/tick SQLite batching: forming-candle runtime state and completed candles are persisted in bounded batches rather than one transaction per tick/instrument.
9. Regression tests added for scanner binding, risk sizing, token mismatch, exit recovery, and strict numeric validation.
10. Release directories: `/opt/owner-trading/releases/<release>` staging/release layout.
11. Atomic `current` symlink cutover.
12. Persistent shared data outside releases (`shared/data`, `shared/secure`) and persistent broker state under `/var/lib/owner-trading`.
13. Rollback: failed service/health/cutover paths restore the previous `current` release when one exists.
14. npm package-lock support: package-lock files are included; deployment resolves them in the staged release and verifies a complete npm v3 lockfile before cutover.
15. Clean release packaging: generated Python caches, test caches, node_modules, and frontend build output are excluded from the final source ZIP.
16. Deployment verification: SDK integrity/signatures, Python tests, Node tests, frontend build, migration backup/integrity, systemd effective config, local health, Nginx 502/503/504 checks, and session verification remain in the deployment path.

## Broker SDK integrity

The supplied project vendor tree was byte-compared against the supplied official Kotak Neo source archive. Result: **0 differing files** across the vendored SDK. The project's 52-file vendor SHA-256 manifest also verifies with **0 errors**.

The application remains pinned to official `kotakneoapi` **3.0.7**. No broker SDK/API method names were changed.

## Theme preservation

All existing frontend CSS/theme files were byte-for-byte compared with the supplied source ZIP. Result: **unchanged**.

## Validation performed

- Broker-service pytest: **309 passed, 3 skipped**.
- Backend Node tests: **26 passed, 6 skipped** in the available local environment; the six skipped tests require npm runtime dependencies that are intentionally not installed in the offline build environment. The production deploy script installs npm dependencies before running tests.
- `deploy.sh`: shell syntax check passed.
- Official Kotak vendor manifest: **52 files checked, 0 errors**.
- Official Kotak source comparison: **0 differences**.

## Important deployment behavior

The deployment script does not delete the currently running release first. It stages and validates the new release, safely quiesces services only for the short migration/cutover window, switches the atomic `current` link, verifies health, and retains previous releases for rollback.

Kotak credentials, encrypted credential store, SQLite database, and website password hash are kept outside immutable releases. Existing encryption keys are preserved; deployment refuses silent key rotation when an encrypted credential store exists.
