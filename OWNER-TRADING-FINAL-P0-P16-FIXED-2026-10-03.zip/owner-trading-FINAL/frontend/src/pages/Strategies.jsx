import {useMemo, useState} from "react";
import usePolling from "../hooks/usePolling";
import {api} from "../api/client";
import EmptyState from "../components/common/EmptyState";

const FIELDS=["close","open","high","low","volume","sma20","ema20","ema50","rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_upper","bb_lower","volume_sma20","bullish_candle","bearish_candle"];
const OPS=[">",">=","<","<=","==","!=","cross_above","cross_below"];
const blank=(l="ema20",r="ema50")=>({left:l,operator:">",right:r});

function Group({title,rows,setRows}) {
  const change=(i,k,v)=>setRows(x=>x.map((r,n)=>n===i?{...r,[k]:v}:r));
  return <div className="strategy-group">
    <h4>{title}</h4>
    {rows.map((r,i)=><div className="order-form" key={i}>
      <select aria-label={`${title} left operand`} value={r.left} onChange={e=>change(i,"left",e.target.value)}>{FIELDS.map(x=><option key={x}>{x}</option>)}</select>
      <select aria-label={`${title} operator`} value={r.operator} onChange={e=>change(i,"operator",e.target.value)}>{OPS.map(x=><option key={x}>{x}</option>)}</select>
      <input aria-label={`${title} right operand`} value={r.right} onChange={e=>change(i,"right",e.target.value)} placeholder="indicator or number"/>
      <button type="button" onClick={()=>setRows(x=>x.filter((_,n)=>n!==i))}>Remove</button>
    </div>)}
    <button type="button" onClick={()=>setRows(x=>[...x,blank()])}>+ Condition</button>
  </div>;
}

export default function Strategies(){
 const data=usePolling(()=>api.getAlgoStrategies(),5000);
 const [name,setName]=useState(""); const [side,setSide]=useState("BUY"); const [tf,setTf]=useState("15m");
 const [group,setGroup]=useState("AND"); const [entry,setEntry]=useState([blank()]);
 const [exit,setExit]=useState([{left:"rsi14",operator:"<",right:45}]);
 const [stop,setStop]=useState("1"); const [target,setTarget]=useState("2"); const [trail,setTrail]=useState("0.5"); const [timeExit,setTimeExit]=useState("12");
 const [sizingMode,setSizingMode]=useState("quantity"); const [qty,setQty]=useState(1); const [capitalPct,setCapitalPct]=useState(""); const [riskPerTrade,setRiskPerTrade]=useState("");
 const [maxPos,setMaxPos]=useState(1); const [cooldown,setCooldown]=useState(0); const [product,setProduct]=useState("MIS");
 const [universe,setUniverse]=useState("");
 const [selectedStocks,setSelectedStocks]=useState([]);
 const [stockQuery,setStockQuery]=useState("");
 const [stockResults,setStockResults]=useState([]);
 const [stockBusy,setStockBusy]=useState(false);
 const [msg,setMsg]=useState("");

 async function searchStocks(e){
   e?.preventDefault();
   const q=stockQuery.trim();
   if(!q)return setStockResults([]);
   setStockBusy(true); setMsg("");
   const r=await api.searchScrip({exchange_segment:"nse_cm",symbol:q});
   setStockBusy(false);
   if(!r.ok){setMsg(r.body?.error||"Stock search failed.");return;}
   const rows=Array.isArray(r.body?.data)?r.body.data:[];
   setStockResults(rows.slice(0,50));
 }
 function addStock(row){
   const token=String(row.pSymbol||"").trim();
   const symbol=String(row.pTrdSymbol||row.pSymbolName||token).trim();
   if(!token)return;
   setSelectedStocks(prev=>prev.some(x=>x.token===token)?prev:[...prev,{token,symbol,name:row.pSymbolName||symbol}]);
   setStockResults(prev=>prev.filter(x=>String(x.pSymbol||"")!==token));
 }
 function removeStock(token){
   setSelectedStocks(prev=>prev.filter(x=>x.token!==token));
 }
 const selectedTokens=useMemo(()=>selectedStocks.map(x=>x.token),[selectedStocks]);

 const definition=()=>({
   timeframe:tf,side,
   entry:{op:group,conditions:entry},
   exit:{op:"OR",conditions:exit},
   max_positions:Number(maxPos)||1,
   universe:{instrument_tokens:selectedTokens.length?selectedTokens:universe.split(",").map(x=>x.trim()).filter(Boolean)},
   risk:{
     stop_loss_pct:stop?Number(stop):null,
     target_pct:target?Number(target):null,
     trailing_stop_pct:trail?Number(trail):null,
     time_exit_bars:timeExit?Number(timeExit):null
   },
   position_sizing:{
     quantity:sizingMode==="quantity"&&qty?Number(qty):undefined,
     capital_pct:sizingMode==="capital_pct"&&capitalPct?Number(capitalPct):undefined,
     risk_per_trade:sizingMode==="risk_per_trade"&&riskPerTrade?Number(riskPerTrade):undefined
   },
   execution:{product,cooldown_bars:Number(cooldown)||0}
 });

 async function create(){
   setMsg("");
   if(!name.trim())return setMsg("Strategy name is required.");
   const d=definition();
   if(!d.universe.instrument_tokens.length)return setMsg("LIVE strategy universe is required. Search and select one or more NSE equity stocks.");
   if(d.universe.instrument_tokens.length>3000)return setMsg("Maximum 3000 instrument tokens are allowed.");
   if(!d.risk.stop_loss_pct && !d.risk.stop_loss && !d.risk.stop_atr_multiple)return setMsg("Stop-loss is required before saving a strategy intended for LIVE use.");
   const vld=await api.validateAlgoStrategy(d);
   if(!vld.ok||!vld.body?.valid)return setMsg(vld.body?.errors?.join("; ")||"Definition is invalid.");
   const r=await api.createAlgoStrategy({name:name.trim()});
   if(!r.ok)return setMsg(r.body?.error||"Create failed");
   const v=await api.saveAlgoStrategyVersion(r.body.strategy.id,{definition:d,status:"VALIDATED"});
   setMsg(v.ok?"Validated and saved. LIVE arming remains a separate owner action.":v.body?.error||"Save failed.");
   if(v.ok){setName("");data.reload();}
 }
 async function arm(v){const r=await api.armAlgoStrategy(v.id);setMsg(r.ok?"LIVE strategy armed after readiness gates.":r.body?.error||"Arm failed");data.reload();}
 async function disarm(v){const r=await api.disarmAlgoStrategy(v.id);setMsg(r.ok?"Strategy disarmed.":r.body?.error||"Disarm failed");data.reload();}

 return <div className="page">
  <div className="page__header"><h2 className="page__title">Strategies</h2><p className="page__subtitle">Validated strategy DSL. A strategy never becomes LIVE until its universe, sizing, protective stop and global readiness gates are satisfied.</p></div>
  <div className="card"><div className="card__head"><h3 className="card__title">Strategy Builder</h3></div>
   <div className="form-hint">Build the strategy definition first. Use instrument tokens from Market Data search; the token list is the only live-feed universe.</div>
   <div className="order-form">
    <input placeholder="Strategy name" value={name} onChange={e=>setName(e.target.value)}/>
    <select aria-label="Action" value={side} onChange={e=>setSide(e.target.value)}><option>BUY</option><option>SELL</option></select>
    <select aria-label="Timeframe" value={tf} onChange={e=>setTf(e.target.value)}>{["1m","3m","5m","10m","15m","30m","1h","1d"].map(x=><option key={x}>{x}</option>)}</select>
    <select aria-label="Product" value={product} onChange={e=>setProduct(e.target.value)}>{["MIS","CNC","NRML","MTF"].map(x=><option key={x}>{x}</option>)}</select>
    <select aria-label="Entry logic" value={group} onChange={e=>setGroup(e.target.value)}><option>AND</option><option>OR</option></select>
    <input type="number" min="1" step="1" value={maxPos} onChange={e=>setMaxPos(e.target.value)} placeholder="max open positions"/>
    <input type="number" min="0" step="1" value={cooldown} onChange={e=>setCooldown(e.target.value)} placeholder="cooldown bars"/>
    <select aria-label="Position sizing mode" value={sizingMode} onChange={e=>setSizingMode(e.target.value)}>
      <option value="quantity">Position sizing: Fixed quantity</option>
      <option value="capital_pct">Position sizing: Capital %</option>
      <option value="risk_per_trade">Position sizing: Risk ₹ / trade</option>
    </select>
    {sizingMode==="quantity"&&<input type="number" min="1" step="1" value={qty} onChange={e=>setQty(e.target.value)} placeholder="fixed quantity"/>}
    {sizingMode==="capital_pct"&&<input type="number" min="0.01" max="100" step="any" value={capitalPct} onChange={e=>setCapitalPct(e.target.value)} placeholder="capital %"/>}
    {sizingMode==="risk_per_trade"&&<input type="number" min="0.01" step="any" value={riskPerTrade} onChange={e=>setRiskPerTrade(e.target.value)} placeholder="risk ₹ / trade"/>}
    <input type="number" min="0" step="any" value={stop} onChange={e=>setStop(e.target.value)} placeholder="stop-loss %"/>
    <input type="number" min="0" step="any" value={target} onChange={e=>setTarget(e.target.value)} placeholder="target %"/>
    <input type="number" min="0" step="any" value={trail} onChange={e=>setTrail(e.target.value)} placeholder="trailing stop %"/>
    <input type="number" min="1" value={timeExit} onChange={e=>setTimeExit(e.target.value)} placeholder="time exit bars"/>
    <div style={{gridColumn:"1 / -1"}}>
     <form onSubmit={searchStocks} className="order-form" style={{marginBottom:8}}>
       <input aria-label="Search NSE stock" value={stockQuery} onChange={e=>setStockQuery(e.target.value)} placeholder="Search NSE stock by symbol/name (e.g. RELIANCE)"/>
       <button type="submit" disabled={stockBusy}>{stockBusy?"Searching…":"Search Stock"}</button>
     </form>
     {stockResults.length>0&&<div className="card" style={{marginBottom:8}}>
       {stockResults.map(row=><div key={String(row.pSymbol)} style={{display:"flex",justifyContent:"space-between",gap:8,padding:"6px 0"}}>
         <span><strong>{row.pTrdSymbol}</strong> · {row.pSymbolName||"NSE Equity"} · token {row.pSymbol}</span>
         <button type="button" onClick={()=>addStock(row)}>Add</button>
       </div>)}
     </div>}
     {selectedStocks.length>0&&<div className="form-hint">Selected LIVE universe: {selectedStocks.length}/3000</div>}
     {selectedStocks.map(row=><span key={row.token} style={{display:"inline-flex",gap:6,alignItems:"center",margin:"4px 6px 4px 0",padding:"4px 8px",border:"1px solid var(--border)",borderRadius:6}}>
       {row.symbol}<button type="button" onClick={()=>removeStock(row.token)} aria-label={`Remove ${row.symbol}`}>×</button>
     </span>)}
     {!selectedStocks.length&&<input value={universe} onChange={e=>setUniverse(e.target.value)} placeholder="Optional legacy fallback: NSE instrument tokens, comma separated (max 3000)"/>}
   </div>
   </div>
   <Group title="ENTRY" rows={entry} setRows={setEntry}/><Group title="EXIT" rows={exit} setRows={setExit}/>
   <button onClick={create}>Validate &amp; Save Version</button>{msg&&<p className={msg.includes("saved")||msg.includes("armed")||msg.includes("disarmed")?"form-hint":"form-error"}>{msg}</p>}
  </div>
  {(data.body?.strategies||[]).map(s=><div className="card" key={s.id}><div className="card__head"><h3 className="card__title">{s.name}</h3></div>
    {s.versions.map(v=><div key={v.id} style={{marginBottom:20}}><strong>v{v.version}</strong> · {v.status} · {v.is_live_armed?"LIVE ARMED":"not armed"}
      {v.validation_errors?.length?<p className="form-error">{v.validation_errors.join("; ")}</p>:null}
      <pre style={{whiteSpace:"pre-wrap",overflowX:"auto"}}>{JSON.stringify(v.definition,null,2)}</pre>
      {v.is_live_armed?<button onClick={()=>disarm(v)}>Disarm</button>:v.status==="VALIDATED"?<button onClick={()=>arm(v)}>Arm LIVE</button>:null}
    </div>)}
  </div>)}
  {!data.loading&&!data.body?.strategies?.length&&<div className="card"><EmptyState title="No strategies yet" description="Build and validate a strategy above."/></div>}
 </div>;
}
