import asyncio
import unittest
from unittest.mock import patch

from app import algo_engine, db, strategy_engine
from tests.dbutil import fresh_db


class LiveExecutionSafetyTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def _definition(self, **extra):
        d = {
            "timeframe": "5m",
            "side": "BUY",
            "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
            "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
            "risk": {"stop_loss_pct": 1},
            "position_sizing": {"quantity": 1},
            "execution": {"product": "MIS"},
        }
        d.update(extra)
        return d

    def test_unrelated_active_scanner_does_not_gate_unbound_strategy(self):
        candles = [{"candle_at": "2026-10-03 09:15:00", "open": 100, "high": 101, "low": 99, "close": 100.5, "volume": 10}] * 20
        scanner = self._definition(entry={"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1000}]})
        self.db.create_scanner("Unrelated", scanner)
        self.db.set_scanner_active(1, True)
        self.assertEqual(algo_engine._bound_scanner_matches(self._definition(), candles), [])

    def test_bound_scanner_must_be_the_declared_id_and_pass(self):
        candles = [{"candle_at": "2026-10-03 09:15:00", "open": 100, "high": 101, "low": 99, "close": 100.5, "volume": 10}] * 20
        good = self._definition(entry={"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 100}]})
        bad = self._definition(entry={"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1000}]})
        a = self.db.create_scanner("Good", good); b = self.db.create_scanner("Bad", bad)
        self.db.set_scanner_active(a["id"], True); self.db.set_scanner_active(b["id"], True)
        self.assertEqual(algo_engine._bound_scanner_matches(self._definition(scanner_ids=[a["id"]]), candles), [a["id"]])
        self.assertEqual(algo_engine._bound_scanner_matches(self._definition(scanner_ids=[b["id"]]), candles), [])

    def test_manual_token_symbol_mismatch_is_blocked(self):
        from app import order_service
        self.db.upsert_instrument_metadata(exchange_segment="nse_cm", instrument_token="11915", trading_symbol="YESBANK-EQ", name="YESBANK")
        with self.assertRaises(order_service.OrderValidationError):
            order_service._validate({
                "trading_symbol": "TATASTEEL-EQ", "exchange_segment": "nse_cm", "transaction_type": "B",
                "order_type": "MKT", "product": "MIS", "validity": "DAY", "quantity": 1,
                "instrument_token": "11915",
            })

    def test_orphaned_exit_request_is_released_but_unknown_order_is_not_auto_retried(self):
        with self.db._connection() as c:
            c.execute("INSERT INTO algo_positions(exchange_segment,instrument_token,trading_symbol,quantity,remaining_quantity,status) VALUES('nse_cm','11915','YESBANK-EQ',10,10,'OPEN')")
            c.execute("INSERT INTO algo_exits(algo_position_id,reason,requested_quantity,status,created_at) VALUES(1,'STOP_LOSS',10,'REQUESTED',datetime('now','-2 minutes'))")
            c.execute("INSERT INTO algo_exits(algo_position_id,reason,requested_quantity,internal_order_id,status) VALUES(1,'TARGET',10,'o-unknown','UNKNOWN')")
        self.assertEqual(self.db.recover_orphaned_exit_requests(60), 1)
        rows = self.db.list_algo_positions()
        with self.db._connection() as c:
            states = [r[0] for r in c.execute("SELECT status FROM algo_exits ORDER BY id").fetchall()]
        self.assertEqual(states, ["FAILED", "UNKNOWN"])
        self.assertTrue(self.db.has_pending_exit(1))


if __name__ == "__main__":
    unittest.main()
