-- One row per scanner pass (what ran, on which bar, how long it took, how many stocks matched).
CREATE TABLE IF NOT EXISTS scan_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scanner_id INTEGER,
  strategy_version_id INTEGER,
  timeframe TEXT NOT NULL,
  bar_at TEXT,
  trigger TEXT NOT NULL DEFAULT 'BAR_CLOSE',
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  duration_ms INTEGER,
  universe INTEGER NOT NULL DEFAULT 0,
  evaluated INTEGER NOT NULL DEFAULT 0,
  matched INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'OK',
  stats_json TEXT,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_scan_runs_recent ON scan_runs(id DESC);
CREATE INDEX IF NOT EXISTS idx_scan_runs_scanner ON scan_runs(scanner_id, id DESC);

-- Retention deletes by timeframe + age; this index keeps that fast on a large candle table.
CREATE INDEX IF NOT EXISTS idx_candles_retention ON candles(timeframe, candle_at);
