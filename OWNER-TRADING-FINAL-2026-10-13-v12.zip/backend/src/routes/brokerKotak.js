const express = require("express");
const rateLimit = require("express-rate-limit");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { validateCredentials } = require("../services/kotakCredentialValidation");

const router = express.Router();
router.use(requireAuth);

// These actions make a real (or real-attempt) outbound call to Kotak, so
// they get the same rate-limiting posture as login -- an attacker who
// somehow got a valid session shouldn't be able to hammer the broker with
// auth attempts.
const kotakActionLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many broker connection attempts. Please wait and try again." },
});
router.use(kotakActionLimiter);

/**
 * GET /api/broker/kotak/credentials/status
 * Masked summary only (booleans + last-two-chars hints) -- never the raw
 * values. Lets the Settings UI show "credentials saved" after a refresh
 * without re-exposing anything sensitive.
 */
router.get("/credentials/status", async (req, res) => {
  const result = await brokerClient.credentialsStatus();
  if (!result.ok) {
    return res.status(502).json({ configured: false, error: "Could not reach the broker service." });
  }
  return res.json(result.body);
});

/**
 * POST /api/broker/kotak/credentials
 * Forwards validated credentials to the broker service, which holds them
 * in memory only while it tests them against Kotak, then persists them
 * encrypted to disk ONLY after that authentication succeeds (see
 * broker-service/app/credential_manager.py: set() -> test_connection() ->
 * persist()). This route body is NEVER logged -- Express has no
 * request-body logging middleware anywhere in app.js, and this handler
 * itself only logs success/failure, never the payload.
 */
router.post("/credentials", async (req, res) => {
  const { consumerKey, mobileNumber, ucc, mpin, totpSecret } = req.body || {};
  const validationError = validateCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret });
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const result = await brokerClient.saveCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret });
  if (!result.ok) {
    // Preserve the distinction between transport failure, internal broker-service
    // authentication failure, Kotak authentication rejection, input validation,
    // and credential-store failure. The broker service never returns raw secrets.
    if (result.networkError) {
      return res.status(502).json({
        success: false,
        saved: false,
        error: "BROKER_SERVICE_UNREACHABLE",
        message: "Broker service is unreachable.",
      });
    }

    if (result.status === 401 && result.body?.error === "Missing or invalid internal token.") {
      return res.status(502).json({
        success: false,
        saved: false,
        error: "INTERNAL_SERVICE_AUTH_ERROR",
        message: "Internal broker-service authentication failed.",
      });
    }

    if (result.status === 422) {
      return res.status(422).json({
        success: false,
        saved: false,
        error: "KOTAK_AUTH_FAILED",
        // Kotak authentication failures are deliberately NOT HTTP 401.
        // HTTP 401 is reserved for Express AUTH_REQUIRED so the frontend can
        // never mistake a broker rejection for an owner web-session expiry.
        code: result.body?.code || "BROKER_REJECTED",
        message: result.body?.error || "Kotak authentication failed.",
      });
    }

    if (result.status === 502) {
      return res.status(502).json({
        success: false,
        saved: false,
        error: "KOTAK_CONNECTION_ERROR",
        code: result.body?.code || "TRANSPORT_ERROR",
        message: result.body?.error || "Kotak connection could not be verified.",
      });
    }

    if (result.status === 400) {
      return res.status(400).json({
        success: false,
        saved: false,
        error: "INVALID_CREDENTIALS",
        message: result.body?.error || "Invalid Kotak credential format.",
      });
    }

    if (result.status === 500) {
      return res.status(500).json({
        success: false,
        saved: false,
        error: "CREDENTIAL_STORAGE_ERROR",
        message: result.body?.error || "Credential storage failed.",
      });
    }

    return res.status(502).json({
      success: false,
      saved: false,
      error: "BROKER_SERVICE_ERROR",
      message: "Broker service rejected the credential request.",
    });
  }
  return res.json({ success: true, saved: true });
});

/**
 * POST /api/broker/kotak/test
 * Real auth attempt via the broker service; does not persist a session or
 * change the dashboard's connection status. See broker_client.py's
 * test_connection() for why.
 */
router.post("/test", async (req, res) => {
  const result = await brokerClient.testConnection();
  if (!result.ok) {
    return res.status(502).json({ success: false, error: "Could not reach the broker service." });
  }
  return res.json(result.body);
});

/**
 * POST /api/broker/kotak/connect
 * Real auth attempt; on success the broker service keeps the session and
 * this route's caller (the Settings UI) should re-poll GET
 * /api/broker/status to see the resulting state -- this endpoint also
 * returns it directly for convenience.
 */
router.post("/connect", async (req, res) => {
  const result = await brokerClient.connect();
  if (!result.ok) {
    if (result.networkError) return res.status(502).json({ error: "BROKER_SERVICE_UNREACHABLE", message: "Broker service is unreachable." });
    const state = result.body?.state;
    const status = result.status === 422 ? 422 : result.status === 409 ? 409 : 502;
    return res.status(status).json({
      error: state === "AUTH_FAILED" ? "KOTAK_AUTH_FAILED" : state || "BROKER_CONNECTION_ERROR",
      code: result.body?.last_error ? undefined : result.body?.code,
      message: result.body?.last_error || "Kotak connection failed.",
      state,
    });
  }
  return res.json({ state: result.body.state, lastError: result.body.last_error });
});

router.post("/disconnect", async (req, res) => {
  const result = await brokerClient.disconnect();
  if (!result.ok) {
    return res.status(502).json({ error: "Could not reach the broker service." });
  }
  return res.json({
    state: result.body.state,
    lastError: result.body.last_error,
  });
});

router.post("/reconnect", async (req, res) => {
  const result = await brokerClient.reconnect();
  if (!result.ok) {
    if (result.networkError) return res.status(502).json({ error: "BROKER_SERVICE_UNREACHABLE", message: "Broker service is unreachable." });
    const state = result.body?.state;
    const status = result.status === 422 ? 422 : result.status === 409 ? 409 : 502;
    return res.status(status).json({
      error: state === "AUTH_FAILED" ? "KOTAK_AUTH_FAILED" : state || "BROKER_CONNECTION_ERROR",
      message: result.body?.last_error || "Kotak reconnection failed.",
      state,
    });
  }
  return res.json({ state: result.body.state, lastError: result.body.last_error });
});

module.exports = router;
