# Scanner upgrade (v12): what changed and how it works

## Flow
1. **Universe** – every NSE cash stock of the chosen series (**EQ by default**; BE / SM optional per scanner). The old
   `ORDER BY trading_symbol LIMIT 3000` (alphabetical cut-off) is gone. Instruments are ordered by token and capped at
   2,800 so **200 feed slots always stay free** for open positions, candidates, manual and order-time subscriptions.
2. **Live candles from ticks** – the scanner universe is subscribed to the Kotak SFeed (limit 3,000) as soon as a
   strategy that uses a scanner is armed. Candles build from ticks (candle engine, unchanged). REST history is only a
   background warm-up (single-flight job, each stock fetched at most once, stops on 429/timeout/session errors).
3. **Scan at bar close** – a scanner runs **once when its bar closes** (+3 s settle): 5m scanner at 09:20, 09:25 … 15:30,
   15m at 09:30 …, 1h at 10:15 … (last shortened bar at 15:30), daily at 15:45. No scan on weekends/holidays. A restart
   mid-day catches up with one scan. `scan_runs` records every pass (bar, universe, evaluated, matched, duration).
4. **Candidates** – matches are filtered (price band, average volume), ranked (volume / turnover / % change / price) and
   capped (default top 50). Each candidate stores **why it matched**. Candidates are subscribed to the feed; the strategy
   evaluates **only candidates**, on its own bar close.
5. **Orders** – unchanged: a match never places an order; ARM, risk limits, margin and the final LIVE gate still apply.
   Open positions keep their own feed owner and the MIS square-off is unchanged.

## Condition engine v2 (scanner, strategy, backtest, live – one engine)
Operands: `close open high low volume vwap macd macd_signal macd_hist`, `ema<N> sma<N>` (1-500), `rsi<N> adx<N>` (2-100),
`atr<N>` (1-100), `volume_sma<N>`, `hh<N> ll<N>` (highest high / lowest low of the previous N bars),
`bb_upper|bb_mid|bb_lower[<N>]`; any operand may take an offset `[k]` (`close[1]`, `ema20[3]`, k 0-50).
Conditions: `> >= < <= == != cross_above cross_below`, optional `mult` (`volume > volume_sma20 x 2`) and `not`.
Groups: `AND`/`OR`, optional `not`, nested `groups`. Evaluation is three-valued: "not enough bars" is never a match,
not even under NOT. Old definitions (fixed periods, flat lists) validate and evaluate unchanged.
Only the operands a rule uses are computed (about 0.25 ms per stock on the reference machine), and MACD is O(n).

## Measure first
On the VPS, from `broker-service/`:  `python3 scripts/measure_scan_load.py /path/to/owner-trading.db`
prints the instrument count per series (does EQ fit in 2,800?) and times the scan maths for that many stocks.
Candle loading from SQLite and live tick handling are measured by running the service; this tool does not touch the broker.

## Decisions worth knowing
* The scan runs in a worker **thread**, not a separate process: with engine v2 a 2,000-stock pass is well under a second,
  so process isolation would add complexity for no measured benefit. Revisit only if the measure script says otherwise.
* "Average volume (20 bars)" in the stock filter is the average volume of the scanner's own timeframe bars.
* Candle retention (run daily in the pre-market preparation): 1m 7 d, 3m 14 d, 5m 30 d, 10m 45 d, 15m 90 d, 30m 180 d, 1h 365 d, 1d 1000 d.
* New: migration `015_scan_runs_retention.sql` (scan_runs table, retention index). Restart both services after deploying.
* New API: `GET /api/algo/scan-runs`, `POST /api/algo/universe-preview`, `POST /api/market-data/instruments`.
