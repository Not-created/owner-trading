import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  parseOperand, formatOperand, operandLabel, validateGroup, describeGroup, cleanGroup, defaultScannerEntry, blankGroup,
  buildScannerDefinition, validateScannerState, defaultScanOptions, minBarsHint, OPERAND_KINDS,
} from "../src/lib/conditionBuilder.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const FIXTURE = path.join(here, "fixtures", "scanner-definitions.json");

export function scannerFixtures() {
  const scan = defaultScanOptions();
  const base = { timeframe: "5m", entry: defaultScannerEntry(), scan };
  return {
    default_scanner: buildScannerDefinition(base),
    filtered_ranked: buildScannerDefinition({ ...base, scan: { ...scan, series: ["EQ", "BE", "SM"], minPrice: "50", maxPrice: "5000", minAvgVolume: "200000", maxCandidates: 20, rankBy: "turnover" } }),
    offsets_mult_not: buildScannerDefinition({ timeframe: "15m", scan, entry: { op: "AND", conditions: [
      { left: "ema13", operator: "cross_above", right: "ema34" },
      { left: "volume", operator: ">", right: "volume_sma20", mult: 2 },
      { left: "close[1]", operator: "<", right: "hh20[2]", not: true }],
      groups: [{ op: "OR", not: true, conditions: [{ left: "rsi7", operator: "<", right: 30 }, { left: "adx14", operator: "<", right: 15 }] }] } }),
    bollinger_macd: buildScannerDefinition({ timeframe: "1d", scan, entry: { op: "OR", conditions: [
      { left: "close", operator: "<", right: "bb_lower20" }, { left: "macd_hist", operator: ">", right: 0 }, { left: "close", operator: ">", right: "vwap" }] } }),
  };
}

test("operands parse and format symmetrically, like the engine", () => {
  for (const s of ["close", "ema20", "ema13[3]", "rsi14", "hh20", "bb_upper20", "volume_sma50[1]", "macd_hist", "vwap", "atr10"]) {
    const p = parseOperand(s);
    assert.ok(p && p.type === "indicator", s);
    assert.equal(formatOperand(p), s);
  }
  assert.deepEqual(parseOperand("55"), { type: "number", value: 55 });
  assert.deepEqual(parseOperand(0.5), { type: "number", value: 0.5 });
  assert.equal(parseOperand("bb_upper").period, 20);
  for (const bad of ["", "ema", "ema0", "ema501", "rsi1", "close5", "foo", "close[51]", "ema20[x]", null, NaN, "inf", "macd12"]) assert.equal(parseOperand(bad), null, String(bad));
});

test("labels are readable", () => {
  assert.equal(operandLabel("ema20"), "EMA 20");
  assert.equal(operandLabel("close[2]"), "Close (2 bars ago)");
  assert.equal(operandLabel("volume_sma20"), "Average volume 20");
  assert.equal(operandLabel("hh20"), "Highest high 20");
  assert.equal(operandLabel(60), "60");
});

test("default scanner rule is EMA20 crosses above EMA50 AND RSI14 above 60", () => {
  const g = defaultScannerEntry();
  assert.deepEqual(g.conditions[1], { left: "rsi14", operator: ">", right: 60 });
  assert.equal(describeGroup(g), "EMA 20 crosses above EMA 50 AND RSI 14 is above 60");
});

test("validation mirrors the engine rules", () => {
  assert.deepEqual(validateGroup(defaultScannerEntry()), []);
  assert.ok(validateGroup({ op: "AND", conditions: [] }).some((e) => e.includes("at least one condition")));
  assert.ok(validateGroup({ op: "AND", conditions: [{ left: "ema0", operator: ">", right: 1 }] }).some((e) => e.includes("left")));
  assert.ok(validateGroup({ op: "AND", conditions: [{ left: "close", operator: ">", right: "foo" }] }).some((e) => e.includes("right")));
  assert.ok(validateGroup({ op: "AND", conditions: [{ left: 1, operator: ">", right: 2 }] }).some((e) => e.includes("two plain numbers")));
  assert.ok(validateGroup({ op: "AND", conditions: [{ left: "close", operator: ">", right: 1, mult: 0 }] }).some((e) => e.includes("multiplier")));
  assert.ok(validateGroup({ op: "XOR", conditions: [{ left: "close", operator: ">", right: 1 }] }).some((e) => e.includes("AND or OR")));
  const deep = { op: "AND", conditions: [], groups: [{ op: "AND", conditions: [], groups: [{ op: "AND", conditions: [], groups: [{ op: "AND", conditions: [{ left: "close", operator: ">", right: 1 }] }] }] }] };
  assert.ok(validateGroup(deep).some((e) => e.includes("nested")));
  assert.deepEqual(validateGroup(blankGroup()), []);
});

test("cleanGroup drops empty options and keeps NOT / multiplier / nesting", () => {
  const cleaned = cleanGroup({ op: "AND", not: true, conditions: [{ left: "volume", operator: ">", right: "volume_sma20", mult: "2", not: true }, { left: "close", operator: ">", right: 1, mult: 1, not: false }],
    groups: [{ op: "OR", conditions: [{ left: "rsi14", operator: "<", right: 30 }] }] });
  assert.deepEqual(cleaned, { op: "AND", not: true, conditions: [{ left: "volume", operator: ">", right: "volume_sma20", mult: 2, not: true }, { left: "close", operator: ">", right: 1 }],
    groups: [{ op: "OR", conditions: [{ left: "rsi14", operator: "<", right: 30 }] }] });
});

test("scanner definition carries the stock filter", () => {
  const d = buildScannerDefinition({ timeframe: "5m", entry: defaultScannerEntry(), scan: { ...defaultScanOptions(), minPrice: "50", maxPrice: "", minAvgVolume: "200000", maxCandidates: "30", rankBy: "turnover" } });
  assert.deepEqual(d.scan, { series: ["EQ"], max_candidates: 30, rank_by: "turnover", min_price: 50, min_avg_volume: 200000 });
  assert.equal(d.timeframe, "5m");
});

test("scanner state validation", () => {
  const ok = { name: "A", timeframe: "5m", entry: defaultScannerEntry(), scan: defaultScanOptions() };
  assert.deepEqual(validateScannerState(ok), []);
  const has = (patch, text) => assert.ok(validateScannerState({ ...ok, ...patch, scan: { ...ok.scan, ...(patch.scan || {}) } }).some((e) => e.includes(text)), text);
  has({ name: "" }, "name");
  has({ timeframe: "7m" }, "timeframe");
  has({ scan: { minPrice: "100", maxPrice: "50" } }, "cannot be above");
  has({ scan: { minPrice: "-1" } }, "Minimum price");
  has({ scan: { maxCandidates: 0 } }, "1 and 500");
  has({ scan: { series: [] } }, "series");
});

test("history hint follows periods and offsets", () => {
  assert.equal(minBarsHint(defaultScannerEntry()), 52);
  assert.equal(minBarsHint({ op: "AND", conditions: [{ left: "ema13[3]", operator: ">", right: "ema200" }] }), 202);
  assert.ok(OPERAND_KINDS.length >= 18);
});

test("fixture of scanner definitions matches the checked-in file", () => {
  const generated = JSON.stringify(scannerFixtures(), null, 2) + "\n";
  if (process.env.UPDATE_FIXTURE === "1") {
    fs.mkdirSync(path.dirname(FIXTURE), { recursive: true });
    fs.writeFileSync(FIXTURE, generated);
  }
  assert.equal(fs.readFileSync(FIXTURE, "utf8"), generated, "run UPDATE_FIXTURE=1 node --test test/conditionBuilder.test.js");
});
