import { useEffect, useRef, useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import ConditionBuilder from "../components/common/ConditionBuilder";
import {
  SERIES_OPTIONS, RANK_OPTIONS, defaultScannerEntry, defaultScanOptions, buildScannerDefinition, validateScannerState,
  validateGroup, describeGroup, minBarsHint,
} from "../lib/conditionBuilder";
import "./strategyBuilder/maBuilder.css";

const TIMEFRAMES = ["1m", "3m", "5m", "10m", "15m", "30m", "1h", "1d"];
const fmt = (v, d = 0) => (v === null || v === undefined || Number.isNaN(Number(v)) ? "—" : Number(v).toLocaleString("en-IN", { maximumFractionDigits: d }));
const tierLabels = [["positions", "Open positions"], ["candidates", "Candidates"], ["strategy_stocks", "Strategy stocks"], ["orders", "Order-time"], ["manual", "Manual"], ["scanner_universe", "Scanner universe"]];

function Stepper({ value, onChange, min, max, step = 1, label }) {
  const bump = (d) => onChange(Math.max(min, Math.min(max, Number(value) + d * step)));
  return (
    <div className="sb__stepper">
      <button type="button" aria-label={`Decrease ${label}`} onClick={() => bump(-1)}>−</button>
      <output aria-label={label}>{value}</output>
      <button type="button" aria-label={`Increase ${label}`} onClick={() => bump(1)}>+</button>
    </div>
  );
}

export default function Scanner() {
  const scanners = usePolling(() => api.getScanners(), 8000);
  const candidates = usePolling(() => api.getAlgoCandidates("", 3000), 8000);
  const runs = usePolling(() => api.getScanRuns(15), 10000);

  const [name, setName] = useState("Momentum Scanner");
  const [timeframe, setTimeframe] = useState("5m");
  const [entry, setEntry] = useState(defaultScannerEntry());
  const [scan, setScan] = useState(defaultScanOptions());
  const [warmup, setWarmup] = useState(true);
  const [subscribeMatches, setSubscribeMatches] = useState(false);
  const [msg, setMsg] = useState("");
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [preview, setPreview] = useState(null);

  const state = { name, timeframe, entry, scan };
  const errors = validateScannerState(state);
  const definition = buildScannerDefinition(state);
  const setScanOpt = (patch) => setScan((s) => ({ ...s, ...patch }));

  const pollTimer = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; if (pollTimer.current) clearTimeout(pollTimer.current); }, []);

  // How many stocks the filter selects and how that sits against Kotak's 3000-token feed limit.
  const filterKey = JSON.stringify(definition.scan);
  useEffect(() => {
    let live = true;
    const t = setTimeout(async () => {
      const r = await api.previewUniverse(definition.scan);
      if (live) setPreview(r.ok ? r.body : null);
    }, 350);
    return () => { live = false; clearTimeout(t); };
  }, [filterKey]);

  async function save() {
    if (errors.length) return setMsg(errors[0]);
    const r = await api.createScanner({ name: name.trim(), definition });
    setMsg(r.ok ? "Scanner saved and validated. It runs automatically when a bar closes while a strategy that uses it is armed." : (r.body?.validation_errors || []).join("; ") || r.body?.error || "Save failed");
    scanners.reload();
  }

  async function scanOnce(poll) {
    const r = await api.runScanner({ definition, timeframe, limit: 3000, warmup, subscribe_matches: subscribeMatches, poll });
    if (!alive.current) return;
    if (!r.ok) {
      setResult(null);
      setMsg((r.body?.validation_errors ? r.body.validation_errors.join("; ") : r.body?.error) || (r.status ? `Scan failed (HTTP ${r.status}).` : "Scan failed: no response from the server."));
      return;
    }
    setResult(r.body);
    setMsg(`Scanned ${r.body.scanned}; matched ${r.body.matched}.`);
    if (r.body.warmup?.status === "RUNNING") {
      pollTimer.current = setTimeout(() => { if (alive.current) scanOnce(true); }, 4000);
    } else {
      candidates.reload(); runs.reload();
    }
  }

  async function run() {
    const ruleErrors = validateGroup(entry, "Conditions");
    if (ruleErrors.length) return setMsg(ruleErrors[0]);
    if (pollTimer.current) clearTimeout(pollTimer.current);
    setRunning(true); setMsg("Scanning…");
    await scanOnce(false);
    if (alive.current) setRunning(false);
  }

  const d = result?.diagnostics;
  const w = result?.warmup;
  const matches = result?.matches || [];
  const list = candidates.body?.candidates || [];
  const recent = runs.body?.runs || [];
  const feed = runs.body?.feed || preview?.feed;
  const bars = minBarsHint(entry);

  return (
    <div className="page sb">
      <div className="page__header">
        <h2 className="page__title">Scanner</h2>
        <p className="page__subtitle">Find stocks that match your conditions. A scanner match never places an order.</p>
      </div>

      <div className="sb__panel">
        <h4>Scanner</h4>
        <input aria-label="Scanner name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Scanner name" style={{ width: "100%", minHeight: 44, boxSizing: "border-box", fontSize: 16 }} />
        <span className="sb__lab">Timeframe</span>
        <div className="sb__chips" role="group" aria-label="Timeframe">
          {TIMEFRAMES.map((t) => <button key={t} type="button" className={`sb__chip ${timeframe === t ? "sb__chip--on" : ""}`} aria-pressed={timeframe === t} onClick={() => setTimeframe(t)}>{t}</button>)}
        </div>
        <p className="sb__note">
          {timeframe === "1d"
            ? "Runs once a day at 15:45 IST, after the day's bar exists."
            : `Runs automatically each time a ${timeframe} bar closes (09:15 IST onward) while a strategy that uses this scanner is armed. Needs about ${bars} bars of history; missing history loads in the background.`}
        </p>
      </div>

      <ConditionBuilder title="Conditions" value={entry} onChange={setEntry} />

      <div className="sb__panel">
        <h4>Stocks scanned</h4>
        <span className="sb__lab">Series</span>
        <div className="sb__chips" role="group" aria-label="Stock series">
          {SERIES_OPTIONS.map((s) => {
            const on = scan.series.includes(s.id);
            return <button key={s.id} type="button" className={`sb__chip ${on ? "sb__chip--on" : ""}`} aria-pressed={on}
              onClick={() => setScanOpt({ series: on ? scan.series.filter((x) => x !== s.id) : [...scan.series, s.id] })}>{s.label}</button>;
          })}
        </div>
        <div className="sb__grid2" style={{ marginTop: 8 }}>
          <div><span className="sb__lab">Minimum price ₹</span><input type="number" min="0" step="any" aria-label="Minimum price" value={scan.minPrice} onChange={(e) => setScanOpt({ minPrice: e.target.value })} style={{ width: "100%", minHeight: 44, boxSizing: "border-box" }} /></div>
          <div><span className="sb__lab">Maximum price ₹</span><input type="number" min="0" step="any" aria-label="Maximum price" value={scan.maxPrice} onChange={(e) => setScanOpt({ maxPrice: e.target.value })} style={{ width: "100%", minHeight: 44, boxSizing: "border-box" }} /></div>
          <div><span className="sb__lab">Average volume (20 bars) at least</span><input type="number" min="0" step="any" aria-label="Minimum average volume" value={scan.minAvgVolume} onChange={(e) => setScanOpt({ minAvgVolume: e.target.value })} style={{ width: "100%", minHeight: 44, boxSizing: "border-box" }} /></div>
          <div><span className="sb__lab">Rank matches by</span>
            <select aria-label="Rank by" value={scan.rankBy} onChange={(e) => setScanOpt({ rankBy: e.target.value })} style={{ width: "100%", minHeight: 44 }}>
              {RANK_OPTIONS.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
            </select></div>
        </div>
        <div className="sb__line"><span>Keep the top matches as candidates</span><Stepper label="Max candidates" value={scan.maxCandidates} onChange={(v) => setScanOpt({ maxCandidates: v })} min={1} max={500} step={5} /></div>
        {preview && (
          <p className="sb__note" role="status">
            {fmt(preview.selected)} stocks selected · {preview.fits_feed ? `fits the live feed (${fmt(preview.feed_budget)} limit, ${fmt(preview.feed_reserved)} always kept free for positions and candidates)` : "MORE than the live feed can hold: narrow the filter"}.
            {preview.by_series?.total ? ` Synced instruments: ${fmt(preview.by_series.total)} (${Object.entries(preview.by_series.by_series || {}).slice(0, 4).map(([k, v]) => `${k} ${fmt(v)}`).join(", ")}).` : " No instruments synced yet: open Market Data and sync the scrip master."}
          </p>
        )}
      </div>

      <div className="sb__panel">
        <label className="sb__line" style={{ cursor: "pointer" }}><span>Load missing candle history from Kotak first</span><input type="checkbox" checked={warmup} onChange={(e) => setWarmup(e.target.checked)} /></label>
        <label className="sb__line" style={{ cursor: "pointer" }}><span>Subscribe matched stocks to the live feed (replaces the previous scan's matches)</span><input type="checkbox" checked={subscribeMatches} onChange={(e) => setSubscribeMatches(e.target.checked)} /></label>
        {errors.length > 0 && <ul className="sb__errors">{errors.map((e) => <li key={e}>{e}</li>)}</ul>}
        <div className="sb__actions">
          <button type="button" onClick={save} disabled={errors.length > 0}>Save scanner</button>
          <button type="button" onClick={run} disabled={running}>{running ? "Scanning…" : (w?.status === "RUNNING" ? "Run now (loading history…)" : "Run now")}</button>
        </div>
        {msg && <p className="sb__msg" role="status">{msg}</p>}
      </div>

      {result && (
        <div className="sb__panel">
          <h4>Scan result</h4>
          {result.explanation && <p><strong>{result.explanation}</strong></p>}
          {d && (
            <p className="sb__note">
              Universe {fmt(d.universe)} · evaluated {fmt(d.evaluated)} · filtered out {fmt(d.filtered_out)} · no candles {fmt(d.no_candles)} · fewer than {d.required_bars} bars {fmt(d.insufficient_history)} · stale {fmt(d.stale)} · matched {fmt(d.matched_total ?? d.matched)}
              {d.took_ms !== undefined ? ` · took ${(d.took_ms / 1000).toFixed(1)} s` : ""}{d.latest_candle_at ? ` · latest completed bar ${d.latest_candle_at} IST` : ""} · market {result.market_open ? "open" : "closed"}
            </p>
          )}
          {w && (
            <div className="sb__note">
              History: {w.status === "RUNNING" ? "loading in background…" : w.status === "DONE" ? "complete" : "stopped"} needed {w.needed ?? "…"} · loaded {w.fetched ?? 0} · failed {w.failed ?? 0}{w.remaining != null ? ` · remaining ${w.remaining}` : ""}
              {w.needed ? <div style={{ height: 6, background: "var(--border)", borderRadius: 3, margin: "6px 0", maxWidth: 360 }}><div style={{ height: 6, width: `${Math.min(100, Math.round(((w.fetched || 0) / w.needed) * 100))}%`, background: "#38bdf8", borderRadius: 3 }} /></div> : null}
              {w.stopped ? <div>Stopped: {w.stopped}. Press Run now again after 30 s to retry.</div> : null}
            </div>
          )}
          {result.subscribed_matches && <p className="sb__note">Live feed: {result.subscribed_matches.error ? `subscription failed: ${result.subscribed_matches.error}` : `${result.subscribed_matches.subscribed} matched stocks subscribed`}</p>}
          {matches.length > 0 ? (
            <div className="table-scroll">
              <table className="data-table">
                <thead><tr><th>Symbol</th><th>Price</th><th>Why it matched</th></tr></thead>
                <tbody>
                  {matches.map((m) => (
                    <tr key={`${m.exchange_segment}:${m.instrument_token}`}>
                      <td>{m.trading_symbol || m.instrument_token}</td><td>{m.price}</td>
                      <td>{(m.why || []).length ? m.why.join("; ") : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p className="sb__note">No matching stocks.</p>}
        </div>
      )}

      <div className="sb__panel">
        <h4>Live candidate registry</h4>
        <p className="sb__note">Strategy-linked scanner matches only. The strategy trades just these rows; open positions keep their own feed.</p>
        {list.length ? (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Strategy</th><th>Symbol</th><th>Status</th><th>Price</th><th>Why</th><th>Expires</th></tr></thead>
              <tbody>
                {list.map((c) => (
                  <tr key={c.id}>
                    <td>v{c.strategy_version_id} · scanner #{c.scanner_id}</td><td>{c.trading_symbol || c.instrument_token}</td>
                    <td>{c.status}{c.subscribed_at ? " · SUBSCRIBED" : ""}{c.subscription_error ? ` · ${c.subscription_error}` : ""}</td>
                    <td>{c.matched_price ?? "—"}</td><td>{(c.conditions?.why || []).join("; ") || "—"}</td><td>{c.expires_at || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="sb__note">No active candidates.</p>}
      </div>

      <div className="sb__panel">
        <h4>Scan history and feed</h4>
        {feed && (
          <p className="sb__note">
            Live feed {fmt(feed.total)} of {fmt(feed.limit)}: {tierLabels.map(([k, label]) => `${label} ${fmt(feed[k])}`).join(" · ")}
          </p>
        )}
        {recent.length ? (
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>When (UTC)</th><th>Bar (IST)</th><th>TF</th><th>Trigger</th><th>Universe</th><th>Evaluated</th><th>Matched</th><th>Time</th><th>Status</th></tr></thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id}>
                    <td>{String(r.started_at || "").slice(5, 16)}</td><td>{String(r.bar_at || "").slice(5, 16) || "—"}</td><td>{r.timeframe}</td><td>{r.trigger}</td>
                    <td>{fmt(r.universe)}</td><td>{fmt(r.evaluated)}</td><td>{fmt(r.matched)}</td><td>{r.duration_ms != null ? `${(r.duration_ms / 1000).toFixed(1)} s` : "—"}</td>
                    <td style={r.status !== "OK" ? { color: "var(--sb-bad)" } : undefined}>{r.status}{r.error ? `: ${r.error}` : ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="sb__note">No scans yet. They appear here each time a bar closes for an armed scanner, or when you press Run now.</p>}
      </div>

      {((scanners.body && scanners.body.scanners) || []).map((s) => (
        <div className="sb__panel" key={s.id}>
          <div className="sb__line" style={{ borderBottom: "none" }}><b>{s.name}</b><span className="sb__note" style={{ margin: 0 }}>{s.is_active ? "ACTIVE" : "inactive"} · {s.definition?.timeframe}</span></div>
          <p className="sb__note">{s.definition?.entry ? describeGroup(s.definition.entry) : "—"}</p>
          {s.definition?.scan && <p className="sb__note">Stocks: {(s.definition.scan.series || ["EQ"]).join("+")}{s.definition.scan.min_price ? ` · from ₹${s.definition.scan.min_price}` : ""}{s.definition.scan.max_price ? ` · up to ₹${s.definition.scan.max_price}` : ""}{s.definition.scan.min_avg_volume ? ` · avg volume ≥ ${fmt(s.definition.scan.min_avg_volume)}` : ""} · top {s.definition.scan.max_candidates || 50}</p>}
          <div className="sb__actions">
            <button type="button" onClick={async () => { await api.activateScanner(s.id); scanners.reload(); }}>Activate</button>
            <button type="button" onClick={async () => { await api.deactivateScanner(s.id); scanners.reload(); }}>Deactivate</button>
          </div>
        </div>
      ))}
    </div>
  );
}
