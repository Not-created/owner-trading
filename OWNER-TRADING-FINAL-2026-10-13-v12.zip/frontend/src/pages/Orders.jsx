import { useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";
import usePolling from "../hooks/usePolling";
import { EXCHANGE_SEGMENTS, TERMINAL_STATUSES, fmt } from "../lib/format";

const EMPTY_FORM = {
  trading_symbol: "", exchange_segment: "nse_cm", instrument_token: "", transaction_type: "B", order_type: "L",
  product: "CNC", validity: "DAY", quantity: "", price: "", trigger_price: "",
};

// Official Kotak margin_required fields: ordMrgn / reqdMrgn (margin needed), avlCash, insufFund (shortfall), rmsVldtd.
function marginSummary(raw) {
  const d = raw && (raw.data && typeof raw.data === "object" && !Array.isArray(raw.data) ? raw.data : raw);
  if (!d || typeof d !== "object") return null;
  const n = (v) => { const x = Number(String(v ?? "").replace(/,/g, "")); return Number.isFinite(x) ? x : null; };
  const need = Math.max(n(d.ordMrgn) ?? 0, n(d.reqdMrgn) ?? 0);
  const cash = n(d.avlCash);
  const short = n(d.insufFund) ?? 0;
  const rms = d.rmsVldtd == null ? null : String(d.rmsVldtd).toUpperCase();
  const money = (v) => (v == null ? "n/a" : `₹${v.toFixed(2)}`);
  if (short > 0 || (rms && rms !== "OK")) {
    return { ok: false, text: `Insufficient funds: this order needs ${money(need)} but available cash is ${money(cash)} (short by ${money(short)}). Kotak RMS check: ${rms || "n/a"}. LIVE entry will be blocked.` };
  }
  return { ok: true, text: `Margin OK: needs ${money(need)}; available cash ${money(cash)}.` };
}

export default function Orders() {
  const { loading, error: listError, body, reload } = usePolling(() => api.getOrders(200), 4000);
  const orders = (body && body.orders) || [];
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [marginBusy, setMarginBusy] = useState(false);
  const [marginResult, setMarginResult] = useState(null);
  const update = (field, value) => setForm((f) => ({ ...f, [field]: value }));
  const needsPrice = form.order_type === "L" || form.order_type === "SL";
  const needsTrigger = form.order_type === "SL" || form.order_type === "SL-M";

  async function estimateMargin() {
    setMarginResult(null);
    if (!form.instrument_token.trim() || !form.quantity) {
      setMarginResult({ error: "Instrument token and quantity are required for a margin estimate (find the token on Market Data)." });
      return;
    }
    setMarginBusy(true);
    const { ok, body: b, status } = await api.getMarginRequired({
      exchange_segment: form.exchange_segment,
      instrument_token: form.instrument_token.trim(),
      price: needsPrice && form.price !== "" ? Number(form.price) : 0,
      trigger_price: needsTrigger && form.trigger_price !== "" ? Number(form.trigger_price) : undefined,
      order_type: form.order_type,
      product: form.product,
      quantity: Number(form.quantity),
      transaction_type: form.transaction_type,
    });
    setMarginBusy(false);
    setMarginResult(ok ? { data: b.data } : { error: (b && b.error) || `Margin check failed (HTTP ${status}).` });
  }

  async function submit(e) {
    e.preventDefault();
    setSubmitError(null);
    setNotice(null);
    const payload = {
      trading_symbol: form.trading_symbol.trim(),
      exchange_segment: form.exchange_segment,
      transaction_type: form.transaction_type,
      order_type: form.order_type,
      product: form.product,
      validity: form.validity,
      quantity: Number(form.quantity),
      price: needsPrice && form.price !== "" ? Number(form.price) : undefined,
      trigger_price: needsTrigger && form.trigger_price !== "" ? Number(form.trigger_price) : undefined,
      instrument_token: form.instrument_token.trim() || undefined,
      idempotency_key: crypto.randomUUID(), // a double-click / retry can never place the order twice
    };
    const summary = `${payload.transaction_type === "B" ? "BUY" : "SELL"} ${payload.quantity} ${payload.trading_symbol} ` +
      `${payload.order_type}${payload.price ? " @ " + payload.price : ""} (${payload.product}, ${payload.exchange_segment})`;
    if (!window.confirm(`Place this order?\n\n${summary}\n\nThis sends a real order to Kotak.`)) return;
    setSubmitting(true);
    const { ok, body: b, status } = await api.placeOrder(payload);
    setSubmitting(false);
    if (!ok) {
      setSubmitError((b && b.error) || `Order failed (HTTP ${status}).`);
      return;
    }
    if (b.status === "REJECTED") setSubmitError(`Order rejected: ${b.status_reason || "no reason given"}`);
    else if (b.outcome_unknown) setNotice("The broker did not confirm this order in time. It has NOT been resent — it is being reconciled; check its status below before doing anything else.");
    else setNotice(`Order ${b.status}.`);
    setForm(EMPTY_FORM);
    reload();
  }

  async function cancel(o) {
    if (!window.confirm(`Cancel ${o.trading_symbol} (${o.quantity})?`)) return;
    const { ok, body: b } = await api.cancelOrder(o.internal_order_id);
    if (!ok) window.alert((b && b.error) || "Cancel failed.");
    reload();
  }

  async function modify(o) {
    const next = window.prompt(`New price for ${o.trading_symbol} (current: ${o.price ?? "market"})`, o.price ?? "");
    if (next === null || next === "" || Number(next) === o.price) return;
    const { ok, body: b } = await api.modifyOrder(o.internal_order_id, { price: Number(next) });
    if (!ok) window.alert((b && b.error) || "Modify failed.");
    reload();
  }

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Orders</h2>
        <p className="page__subtitle">Orders submitted here are LIVE orders and are sent to the connected Kotak Neo account after all safety gates pass.</p>
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Place order</h3></div>
        <form onSubmit={submit} className="order-form">
          <input placeholder="Trading symbol exactly as in the scrip master (e.g. YESBANK-EQ)" value={form.trading_symbol}
                 onChange={(e) => update("trading_symbol", e.target.value)} required />
          <select value={form.exchange_segment} onChange={(e) => update("exchange_segment", e.target.value)}>
            {EXCHANGE_SEGMENTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <input placeholder="Instrument token" value={form.instrument_token}
                 onChange={(e) => update("instrument_token", e.target.value)} />
          <select value={form.transaction_type} onChange={(e) => update("transaction_type", e.target.value)}>
            <option value="B">Buy</option><option value="S">Sell</option>
          </select>
          <select value={form.order_type} onChange={(e) => update("order_type", e.target.value)}>
            <option value="L">Limit</option><option value="MKT">Market</option>
            <option value="SL">Stop-loss limit</option><option value="SL-M">Stop-loss market</option>
          </select>
          <select value={form.product} onChange={(e) => update("product", e.target.value)}>
            <option value="CNC">CNC</option><option value="MIS">MIS</option><option value="NRML">NRML</option><option value="MTF">MTF</option>
          </select>
          <select value={form.validity} onChange={(e) => update("validity", e.target.value)}>
            <option value="DAY">DAY</option>
            {form.exchange_segment !== "mcx_fo" && <option value="IOC">IOC</option>}
          </select>
          <input type="number" placeholder="Quantity" value={form.quantity} onChange={(e) => update("quantity", e.target.value)} required min="1" step="1" />
          {needsPrice && <input type="number" step="0.01" placeholder="Price" value={form.price} onChange={(e) => update("price", e.target.value)} required />}
          {needsTrigger && <input type="number" step="0.01" placeholder="Trigger price" value={form.trigger_price} onChange={(e) => update("trigger_price", e.target.value)} required />}
          {submitError && <div className="form-error">{submitError}</div>}
          {notice && <div className="form-hint">{notice}</div>}
          <button type="submit" disabled={submitting}>{submitting ? "Placing…" : "Place order"}</button>
          <button type="button" onClick={estimateMargin} disabled={marginBusy}>{marginBusy ? "Checking…" : "Estimate margin"}</button>
        </form>
        {marginResult && (
          marginResult.error
            ? <div className="form-error">{marginResult.error}</div>
            : (
              <div>
                {marginSummary(marginResult.data) && (
                  <div className={marginSummary(marginResult.data).ok ? "form-hint" : "form-error"}>
                    <strong>{marginSummary(marginResult.data).text}</strong>
                  </div>
                )}
                <pre className="raw-json">{JSON.stringify(marginResult.data, null, 2)}</pre>
              </div>
            )
        )}
      </div>

      <div className="card">
        <div className="card__head"><h3 className="card__title">Order book</h3></div>
        {loading && <EmptyState title="Loading…" />}
        {!loading && listError && <EmptyState title="Orders unavailable" hint={listError} icon="file-text" />}
        {!loading && !listError && orders.length === 0 && <EmptyState title="No orders yet" hint="Orders you place will appear here." icon="file-text" />}
        {orders.length > 0 && (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr><th>Time</th><th>Symbol</th><th>Side</th><th>Type</th><th>Qty</th><th>Filled</th><th>Avg</th><th>Price</th><th>Status</th><th>Detail</th><th></th></tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.internal_order_id}>
                    <td>{o.created_at}</td><td>{o.trading_symbol}</td><td>{o.transaction_type}</td><td>{o.order_type}</td>
                    <td>{o.quantity}</td><td>{o.filled_quantity}</td><td>{fmt(o.average_price)}</td><td>{fmt(o.price)}</td>
                    
                    <td>{o.status}{o.outcome_unknown ? " ⚠ unconfirmed" : ""}</td>
                    <td>{o.status_reason || o.broker_status || "--"}</td>
                    <td>
                      {!TERMINAL_STATUSES.includes(o.status) && (
                        <>
                          <button type="button" onClick={() => modify(o)} disabled={o.outcome_unknown === 1}>Modify</button>{" "}
                          <button type="button" onClick={() => cancel(o)} disabled={o.outcome_unknown === 1}>Cancel</button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
