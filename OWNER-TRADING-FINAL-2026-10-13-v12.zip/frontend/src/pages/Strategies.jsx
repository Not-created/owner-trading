import {useMemo, useState} from "react";
import usePolling from "../hooks/usePolling";
import {api} from "../api/client";
import EmptyState from "../components/common/EmptyState";
import MaCrossoverBuilder from "./strategyBuilder/MaCrossoverBuilder";
import ConditionBuilder from "../components/common/ConditionBuilder";
import { cleanGroup, validateGroup } from "../lib/conditionBuilder";

const FIELDS=["close","open","high","low","volume","sma20","ema20","ema50","rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_upper","bb_lower","volume_sma20","bullish_candle","bearish_candle"];
const OPS=[">",">=","<","<=","==","!=","cross_above","cross_below"];
export default function Strategies(){
 const data=usePolling(()=>api.getAlgoStrategies(),5000);
 const scanners=usePolling(()=>api.getScanners(),5000);
 const [name,setName]=useState(""); const [side,setSide]=useState("BUY"); const [tf,setTf]=useState("15m");
 const [entryGroup,setEntryGroup]=useState({op:"AND",conditions:[{left:"ema20",operator:">",right:"ema50"}]});
 const [exitGroup,setExitGroup]=useState({op:"OR",conditions:[{left:"rsi14",operator:"<",right:45}]});
 const [stop,setStop]=useState("1"); const [target,setTarget]=useState("2"); const [trail,setTrail]=useState("0.5"); const [timeExit,setTimeExit]=useState("12");
 const [qty,setQty]=useState(1); const [capitalPct,setCapitalPct]=useState(""); const [riskPerTrade,setRiskPerTrade]=useState("");
 const [maxPos,setMaxPos]=useState(1); const [cooldown,setCooldown]=useState(0); const [product,setProduct]=useState("MIS");
 const [universe,setUniverse]=useState("");
 const [selectedScannerIds,setSelectedScannerIds]=useState([]);
 const [selectedStocks,setSelectedStocks]=useState([]);
 const [stockQuery,setStockQuery]=useState("");
 const [stockResults,setStockResults]=useState([]);
 const [stockBusy,setStockBusy]=useState(false);
 const [msg,setMsg]=useState("");
 const [busy,setBusy]=useState("");
 const [builder,setBuilder]=useState("ma");

 async function searchStocks(e){
   e?.preventDefault();
   const q=stockQuery.trim();
   if(!q)return setStockResults([]);
   setStockBusy(true); setMsg("");
   const r=await api.searchScrip({exchange_segment:"nse_cm",symbol:q});
   setStockBusy(false);
   if(!r.ok){setMsg(r.body?.error||"Stock search failed.");return;}
   const rows=Array.isArray(r.body?.data)?r.body.data:[];
   setStockResults(rows.slice(0,50));
 }
 function addStock(row){
   const token=String(row.pSymbol||"").trim();
   const symbol=String(row.pTrdSymbol||row.pSymbolName||token).trim();
   if(!token)return;
   setSelectedStocks(prev=>prev.some(x=>x.token===token)?prev:[...prev,{token,symbol,name:row.pSymbolName||symbol}]);
   setStockResults(prev=>prev.filter(x=>String(x.pSymbol||"")!==token));
 }
 function removeStock(token){
   setSelectedStocks(prev=>prev.filter(x=>x.token!==token));
 }
 const selectedTokens=useMemo(()=>selectedStocks.map(x=>x.token),[selectedStocks]);

 const definition=()=>({
   timeframe:tf,side,
   entry:cleanGroup(entryGroup),
   exit:cleanGroup(exitGroup),
   max_positions:Number(maxPos)||1,
   universe:{instrument_tokens:selectedTokens.length?selectedTokens:universe.split(",").map(x=>x.trim()).filter(Boolean)},
   scanner_ids:selectedScannerIds.map(Number),
   risk:{
     stop_loss_pct:stop?Number(stop):null,
     target_pct:target?Number(target):null,
     trailing_stop_pct:trail?Number(trail):null,
     time_exit_bars:timeExit?Number(timeExit):null
   },
   position_sizing:{
     quantity:(!capitalPct&&!riskPerTrade&&qty)?Number(qty):undefined,
     capital_pct:capitalPct?Number(capitalPct):undefined,
     risk_per_trade:riskPerTrade?Number(riskPerTrade):undefined
   },
   execution:{product,cooldown_bars:Number(cooldown)||0}
 });

 async function create(){
   if(busy)return;
   setBusy("save");
   try{await createInner();}finally{setBusy("");}
 }
 async function createInner(){
   setMsg("");
   const ruleErrors=[...validateGroup(entryGroup,"Entry"),...validateGroup(exitGroup,"Exit")];
   if(ruleErrors.length){setMsg(ruleErrors[0]);return;}
   if(!name.trim())return setMsg("Strategy name is required.");
   const d=definition();
   if(!d.universe.instrument_tokens.length&&!d.scanner_ids.length)return setMsg("LIVE strategy requires either an explicit NSE universe or at least one active strategy-specific scanner.");
   if(d.universe.instrument_tokens.length>3000)return setMsg("Maximum 3000 instrument tokens are allowed.");
   if(!d.risk.stop_loss_pct && !d.risk.stop_loss && !d.risk.stop_atr_multiple)return setMsg("Stop-loss is required before saving a strategy intended for LIVE use.");
   const vld=await api.validateAlgoStrategy(d);
   if(!vld.ok||!vld.body?.valid)return setMsg(vld.body?.errors?.join("; ")||"Definition is invalid.");
   const r=await api.createAlgoStrategy({name:name.trim()});
   if(!r.ok)return setMsg(r.body?.error||"Create failed");
   const v=await api.saveAlgoStrategyVersion(r.body.strategy.id,{definition:d,status:"VALIDATED"});
   setMsg(v.ok?"Validated and saved. LIVE arming remains a separate owner action.":v.body?.error||"Save failed.");
   if(v.ok){setName("");data.reload();}
 }
 function failedGates(body){
   const gates=body?.readiness?.gates||[];
   const bad=gates.filter(g=>!g.ok&&g.blocking!==false).map(g=>`${g.id}: ${g.detail}`);
   return bad.length?` Failing checks — ${bad.join(" | ")}`:"";
 }
 async function arm(v){
   if(busy)return;
   setBusy(`arm-${v.id}`);
   setMsg("Arming… waiting for any running broker reconciliation, then loading candle history (can take up to a minute).");
   try{
     const r=await api.armAlgoStrategy(v.id);
     if(r.ok){
       const w=r.body?.history_warmup;
       const extra=w?.scanner_cycle?" First scanner cycle started.":(w&&typeof w.fetched==="number"?` History loaded for ${w.fetched} instruments${w.remaining?`, ${w.remaining} still loading`:""}.`:"");
       setMsg(`LIVE strategy armed after readiness gates.${extra}`);
     } else {
       setMsg(`Arm failed: ${(r.body?.error||(r.status?`HTTP ${r.status}`:"no response from the server"))}.${failedGates(r.body)}`);
     }
   } finally {setBusy("");data.reload();}
 }
 async function disarm(v){
   if(busy)return;
   setBusy(`arm-${v.id}`);
   try{const r=await api.disarmAlgoStrategy(v.id);setMsg(r.ok?"Strategy disarmed.":r.body?.error||"Disarm failed");}
   finally{setBusy("");data.reload();}
 }

 return <div className="page">
  <div className="page__header"><h2 className="page__title">Strategies</h2><p className="page__subtitle">Validated strategy DSL. A strategy never becomes LIVE until its universe, sizing, protective stop and global readiness gates are satisfied.</p></div>
  <div className="sb sb__steps" role="tablist" aria-label="Builder type" style={{marginTop:0}}>
   <button type="button" role="tab" aria-selected={builder==="ma"} className={`sb__step ${builder==="ma"?"sb__step--on":""}`} onClick={()=>setBuilder("ma")}>Moving average crossover</button>
   <button type="button" role="tab" aria-selected={builder==="custom"} className={`sb__step ${builder==="custom"?"sb__step--on":""}`} onClick={()=>setBuilder("custom")}>Custom rules</button>
  </div>
  {builder==="ma"&&<MaCrossoverBuilder scanners={scanners.body?.scanners||[]} onSaved={()=>data.reload()}/>}
  {builder==="custom"&&<div className="card"><div className="card__head"><h3 className="card__title">Strategy Builder</h3></div>
   <div className="form-hint">Build the strategy definition first. Scanner-linked strategies continuously scan the scanner universe; a scanner match creates a candidate and only that candidate receives the strategy's LIVE subscription. Scanner-less strategies require an explicit NSE universe.</div>
   <div className="order-form" style={{gridColumn:"1 / -1"}}>
    <div><strong>Strategy-specific scanners</strong><div className="form-hint">Select only scanners this strategy is allowed to use. An unrelated active scanner can never block this strategy.</div></div>
    <div style={{display:"grid",gap:6}}>
      {(scanners.body?.scanners||[]).filter(x=>x.is_active).map(sc=><label key={sc.id} style={{display:"flex",gap:8,alignItems:"center"}}><input type="checkbox" checked={selectedScannerIds.includes(Number(sc.id))} onChange={e=>setSelectedScannerIds(ids=>e.target.checked?[...new Set([...ids,Number(sc.id)])]:ids.filter(id=>id!==Number(sc.id)))} />{sc.name} (#{sc.id})</label>)}
      {!scanners.loading && !(scanners.body?.scanners||[]).some(x=>x.is_active) && <span className="form-hint">No ACTIVE scanners. Leave this empty to run directly on the strategy universe.</span>}
    </div>
   </div>
   <div className="order-form">
    <input placeholder="Strategy name" value={name} onChange={e=>setName(e.target.value)}/>
    <select aria-label="Action" value={side} onChange={e=>setSide(e.target.value)}><option>BUY</option><option>SELL</option></select>
    <select aria-label="Timeframe" value={tf} onChange={e=>setTf(e.target.value)}>{["1m","3m","5m","10m","15m","30m","1h","1d"].map(x=><option key={x}>{x}</option>)}</select>
    <select aria-label="Product" value={product} onChange={e=>setProduct(e.target.value)}>{["MIS","CNC","NRML","MTF"].map(x=><option key={x}>{x}</option>)}</select>
    <input type="number" min="1" value={maxPos} onChange={e=>setMaxPos(e.target.value)} placeholder="max open positions"/>
    <input type="number" min="0" value={cooldown} onChange={e=>setCooldown(e.target.value)} placeholder="cooldown bars"/>
    <input type="number" min="1" value={qty} onChange={e=>setQty(e.target.value)} placeholder="fixed quantity"/>
    <input type="number" min="0" max="100" step="any" value={capitalPct} onChange={e=>setCapitalPct(e.target.value)} placeholder="capital %"/>
    <input type="number" min="0" step="any" value={riskPerTrade} onChange={e=>setRiskPerTrade(e.target.value)} placeholder="risk ₹ / trade"/>
    <input type="number" min="0" step="any" value={stop} onChange={e=>setStop(e.target.value)} placeholder="stop-loss %"/>
    <input type="number" min="0" step="any" value={target} onChange={e=>setTarget(e.target.value)} placeholder="target %"/>
    <input type="number" min="0" step="any" value={trail} onChange={e=>setTrail(e.target.value)} placeholder="trailing stop %"/>
    <input type="number" min="1" value={timeExit} onChange={e=>setTimeExit(e.target.value)} placeholder="time exit bars"/>
    <div style={{gridColumn:"1 / -1"}}>
     <form onSubmit={searchStocks} className="order-form" style={{marginBottom:8}}>
       <input aria-label="Search NSE stock" value={stockQuery} onChange={e=>setStockQuery(e.target.value)} placeholder="Search NSE stock by symbol/name (e.g. RELIANCE)"/>
       <button type="submit" disabled={stockBusy}>{stockBusy?"Searching…":"Search Stock"}</button>
     </form>
     {stockResults.length>0&&<div className="card" style={{marginBottom:8}}>
       {stockResults.map(row=><div key={String(row.pSymbol)} style={{display:"flex",justifyContent:"space-between",gap:8,padding:"6px 0"}}>
         <span><strong>{row.pTrdSymbol}</strong> · {row.pSymbolName||"NSE Equity"} · token {row.pSymbol}</span>
         <button type="button" onClick={()=>addStock(row)}>Add</button>
       </div>)}
     </div>}
     {selectedStocks.length>0&&<div className="form-hint">Selected LIVE universe: {selectedStocks.length}/3000</div>}
     {selectedStocks.map(row=><span key={row.token} style={{display:"inline-flex",gap:6,alignItems:"center",margin:"4px 6px 4px 0",padding:"4px 8px",border:"1px solid var(--border)",borderRadius:6}}>
       {row.symbol}<button type="button" onClick={()=>removeStock(row.token)} aria-label={`Remove ${row.symbol}`}>×</button>
     </span>)}
     {!selectedStocks.length&&<input value={universe} onChange={e=>setUniverse(e.target.value)} placeholder={selectedScannerIds.length?"Optional: leave blank to use scanner universe; or enter NSE tokens (max 3000)":"NSE instrument tokens, comma separated (max 3000)"}/>}
   </div>
   </div>
   <ConditionBuilder title="ENTRY" value={entryGroup} onChange={setEntryGroup}/><ConditionBuilder title="EXIT" value={exitGroup} onChange={setExitGroup}/>
   <button onClick={create} disabled={busy==="save"}>{busy==="save"?"Saving…":"Validate & Save Version"}</button>{msg&&<p className={(msg.includes("saved")||msg.includes("armed")||msg.includes("disarmed")||msg.startsWith("Arming"))&&!msg.includes("failed")&&!msg.includes("not")?"form-hint":"form-error"}>{msg}</p>}
  </div>}
  {(data.body?.strategies||[]).map(s=><div className="card" key={s.id}><div className="card__head"><h3 className="card__title">{s.name}</h3></div>
    {s.versions.map(v=><div key={v.id} style={{marginBottom:20}}><strong>v{v.version}</strong> · {v.status} · {v.is_live_armed?"LIVE ARMED":"not armed"}
      {v.validation_errors?.length?<p className="form-error">{v.validation_errors.join("; ")}</p>:null}
      <pre style={{whiteSpace:"pre-wrap",overflowX:"auto"}}>{JSON.stringify(v.definition,null,2)}</pre>
      {v.is_live_armed?<button onClick={()=>disarm(v)} disabled={!!busy}>{busy===`arm-${v.id}`?"Working…":"Disarm"}</button>:v.status==="VALIDATED"?<button onClick={()=>arm(v)} disabled={!!busy}>{busy===`arm-${v.id}`?"Arming…":"Arm LIVE"}</button>:null}
    </div>)}
  </div>)}
  {!data.loading&&!data.body?.strategies?.length&&<div className="card"><EmptyState title="No strategies yet" description="Build and validate a strategy above."/></div>}
 </div>;
}
