import { useEffect, useMemo, useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import StockPicker from "../components/common/StockPicker";
import { buildMaDefinition, defaultMaState } from "../lib/strategyBuilder";
import "./strategyBuilder/maBuilder.css";

const ZERO_COSTS = { entry_brokerage: 0, exit_brokerage: 0, stt_sell_pct: 0, exchange_txn_pct: 0, sebi_pct: 0, gst_pct: 0, stamp_duty_buy_pct: 0 };
const RANGES = [{ label: "1 month", days: 30 }, { label: "3 months", days: 90 }, { label: "6 months", days: 180 }];

function isoDay(offset) {
  return new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
}
const num = (v, d = 2, suffix = "") => (v === null || v === undefined || Number.isNaN(Number(v)) ? "—" : `${Number(v).toFixed(d)}${suffix}`);
// The engine validator wants every definition to name either scanners or stocks; a practice run on one
// stock simply names that stock.
function withUniverse(definition, token) {
  const hasTokens = (definition?.universe?.instrument_tokens || []).length > 0;
  const hasScanners = (definition?.scanner_ids || []).length > 0;
  return hasTokens || hasScanners ? definition : { ...definition, universe: { ...(definition.universe || {}), instrument_tokens: [String(token)] } };
}
const templateJson = () => JSON.stringify(buildMaDefinition({ ...defaultMaState(), name: "x", tokens: [] }), null, 2);

function EquityCurve({ points }) {
  const values = (points || []).map((p) => Number(p.equity)).filter(Number.isFinite);
  if (values.length < 2) return null;
  const W = 340, H = 100;
  const lo = Math.min(...values), hi = Math.max(...values);
  const x = (i) => (i * W) / (values.length - 1);
  const y = (v) => 6 + ((hi - v) / Math.max(1e-9, hi - lo)) * (H - 12);
  const up = values[values.length - 1] >= values[0];
  return (
    <svg className="sb__chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Equity curve">
      <path d={values.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(" ")} fill="none"
        stroke={up ? "var(--sb-good)" : "var(--sb-bad)"} strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

function ResultView({ row }) {
  const r = row.result;
  return (
    <div className="sb__panel">
      <h4>{row.symbol} · result</h4>
      <div className="sb__metrics">
        <div className="sb__metric"><span>Net P&amp;L</span><b>{num(r.net_pnl)}</b></div>
        <div className="sb__metric"><span>Win rate</span><b>{num(r.win_rate, 1, "%")}</b></div>
        <div className="sb__metric"><span>Profit factor</span><b>{num(r.profit_factor)}</b></div>
        <div className="sb__metric"><span>Max drawdown</span><b>{num(r.max_drawdown)}</b></div>
        <div className="sb__metric"><span>Trades</span><b>{r.total_trades ?? "—"}</b></div>
        <div className="sb__metric"><span>Sharpe</span><b>{num(r.sharpe)}</b></div>
      </div>
      <EquityCurve points={r.equity_curve} />
      <p className="sb__note">
        {r.data_window?.candles ?? "—"} candles · {r.data_window?.from_date} to {r.data_window?.to_date}. Past results do not promise future profit.
      </p>
      {(r.trades || []).length > 0 && (
        <div className="table-scroll">
          <table className="data-table">
            <thead><tr><th>Entry</th><th>Exit</th><th>Entry ₹</th><th>Exit ₹</th><th>Qty</th><th>Net P&amp;L</th><th>Why</th></tr></thead>
            <tbody>
              {r.trades.slice(0, 60).map((t, i) => (
                <tr key={i}><td>{String(t.entry_time || "").replace("T", " ").slice(0, 16)}</td><td>{String(t.exit_time || "").replace("T", " ").slice(0, 16)}</td>
                  <td>{num(t.entry_price)}</td><td>{num(t.exit_price)}</td><td>{t.quantity ?? "—"}</td><td>{num(t.net_pnl)}</td><td>{t.exit_reason || "—"}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function Backtest() {
  const history = usePolling(() => api.getBacktests(30), 8000);
  const strategies = usePolling(() => api.getAlgoStrategies(), 30000);

  const [mode, setMode] = useState("strategy");          // "strategy" = test a saved strategy, "stock" = practise on any stock
  const [versionId, setVersionId] = useState("");
  const [stocks, setStocks] = useState([]);              // stocks to run (strategy mode)
  const [single, setSingle] = useState(null);            // the one stock (practice mode)
  const [rulesSource, setRulesSource] = useState("custom");
  const [customJson, setCustomJson] = useState(templateJson());
  const [adder, setAdder] = useState(null);
  const [from, setFrom] = useState(isoDay(-90));
  const [to, setTo] = useState(isoDay(0));
  const [capital, setCapital] = useState("100000");
  const [slippage, setSlippage] = useState("0.0005");
  const [fees, setFees] = useState("0");
  const [costJson, setCostJson] = useState(JSON.stringify(ZERO_COSTS, null, 2));
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [msg, setMsg] = useState("");
  const [rows, setRows] = useState([]);
  const [shown, setShown] = useState(0);

  const versions = useMemo(() => {
    const out = [];
    for (const st of strategies.body?.strategies || []) {
      for (const v of st.versions || []) {
        out.push({ id: String(v.id), strategyId: st.id, label: `${st.name} · v${v.version ?? v.id} · ${v.status}`, definition: v.definition || {} });
      }
    }
    return out;
  }, [strategies.body]);
  const chosen = versions.find((v) => v.id === String(versionId));
  const rulesVersion = mode === "strategy" ? chosen : versions.find((v) => `saved:${v.id}` === rulesSource);

  // Strategy mode: start from the strategy's own stocks (token -> readable symbol).
  useEffect(() => {
    const tokens = chosen?.definition?.universe?.instrument_tokens || [];
    setRows([]); setMsg("");
    if (!chosen) { setStocks([]); return undefined; }
    if (!tokens.length) { setStocks([]); return undefined; }
    let live = true;
    (async () => {
      const r = await api.lookupInstruments({ exchange_segment: "nse_cm", tokens: tokens.map(String) });
      if (!live) return;
      const known = new Map((r.body?.instruments || []).map((i) => [String(i.instrument_token), i.trading_symbol]));
      setStocks(tokens.map((t) => ({ token: String(t), symbol: known.get(String(t)) || `Token ${t}` })));
    })();
    return () => { live = false; };
  }, [versionId, versions.length]);

  function addStock(s) {
    if (!s) { setAdder(null); return; }
    setStocks((p) => (p.some((x) => x.token === s.token) ? p : [...p, { token: s.token, symbol: s.symbol }]));
    setAdder(null);
  }

  async function run() {
    if (busy) return;
    setMsg(""); setRows([]); setShown(0);
    let definition;
    if (mode === "strategy") {
      if (!chosen) return setMsg("Choose one of your strategies first.");
      definition = chosen.definition;
    } else if (rulesVersion) {
      definition = rulesVersion.definition;
    } else {
      try { definition = JSON.parse(customJson); } catch (e) { return setMsg(`Strategy rules JSON is invalid: ${e.message}`); }
    }
    const targets = mode === "strategy" ? stocks : (single ? [single] : []);
    if (!targets.length) return setMsg(mode === "strategy" ? "Add at least one stock to test this strategy on." : "Pick a stock first: start typing its name.");
    if (!from || !to) return setMsg("Choose the From and To dates.");
    if (from > to) return setMsg("From date cannot be after To date.");
    let cost_model;
    try {
      cost_model = JSON.parse(costJson);
      if (!cost_model || typeof cost_model !== "object" || Array.isArray(cost_model)) throw new Error("cost model must be a JSON object");
    } catch (e) { return setMsg(`Cost model JSON is invalid: ${e.message}`); }
    const timeframe = String(definition?.timeframe || "15m");

    setBusy(true);
    const out = [];
    try {
      for (let i = 0; i < targets.length; i += 1) {
        const t = targets[i];
        setProgress(`Running ${i + 1} of ${targets.length}: ${t.symbol}…`);
        const payload = {
          exchange_segment: "nse_cm", instrument_token: t.token, trading_symbol: t.symbol, timeframe, quantity: "1",
          from_date: from, to_date: to, initial_capital: capital, slippage, fees, cost_model, definition: withUniverse(definition, t.token),
        };
        const owner = mode === "strategy" ? chosen : rulesVersion;
        if (owner) { payload.strategy_id = owner.strategyId; payload.strategy_version_id = Number(owner.id); }
        let r;
        try { r = await api.runBacktest(payload); } catch (e) { r = { ok: false, body: { error: e.message } }; }
        if (r.ok) out.push({ symbol: t.symbol, token: t.token, ok: true, result: r.body.result });
        else out.push({ symbol: t.symbol, token: t.token, ok: false, error: r.body?.validation_errors?.join("; ") || r.body?.detail || r.body?.error || (r.status ? `Backtest failed (HTTP ${r.status}).` : "No response from the server.") });
        setRows([...out]);
      }
    } finally {
      setBusy(false); setProgress(""); history.reload();
    }
    setShown(Math.max(0, out.findIndex((x) => x.ok)));
  }

  const okRows = rows.filter((r) => r.ok);
  const detail = rows[shown]?.ok ? rows[shown] : okRows[0];
  return (
    <div className="page sb">
      <div className="page__header">
        <h2 className="page__title">Backtest</h2>
        <p className="page__subtitle">Historical analysis only. No broker order is ever placed here.</p>
      </div>

      <div className="sb__steps" role="tablist" aria-label="Backtest type">
        <button type="button" role="tab" aria-selected={mode === "strategy"} className={`sb__step ${mode === "strategy" ? "sb__step--on" : ""}`} onClick={() => { setMode("strategy"); setRows([]); }}>My strategy</button>
        <button type="button" role="tab" aria-selected={mode === "stock"} className={`sb__step ${mode === "stock" ? "sb__step--on" : ""}`} onClick={() => { setMode("stock"); setRows([]); }}>Practice on any stock</button>
      </div>

      {mode === "strategy" ? (
        <div className="sb__panel">
          <h4>1. Choose your strategy</h4>
          <select aria-label="Strategy" value={versionId} onChange={(e) => setVersionId(e.target.value)} style={{ width: "100%", minHeight: 44, fontSize: 16 }}>
            <option value="">{versions.length ? "Select a saved strategy…" : "No saved strategies yet. Build one on the Strategies page."}</option>
            {versions.map((v) => <option key={v.id} value={v.id}>{v.label}</option>)}
          </select>
          {chosen && <p className="sb__note">{chosen.definition.side} · {chosen.definition.timeframe} chart · {chosen.definition.scanner_ids?.length ? "uses scanner picks" : "fixed stock list"}</p>}
          <h4 style={{ marginTop: 12 }}>2. Stocks to test it on</h4>
          {chosen && !chosen.definition?.universe?.instrument_tokens?.length && <p className="sb__note">This strategy trades whatever its scanner picks, so choose the stocks to test on.</p>}
          <div className="sb__stocks">
            {stocks.map((s) => (
              <span className="sb__tag" key={s.token}>{s.symbol}<button type="button" aria-label={`Remove ${s.symbol}`} onClick={() => setStocks((p) => p.filter((x) => x.token !== s.token))}>×</button></span>
            ))}
          </div>
          <StockPicker value={adder} onSelect={addStock} placeholder="Add another stock: type its name" label="Add stock" />
        </div>
      ) : (
        <div className="sb__panel">
          <h4>1. Pick a stock</h4>
          <StockPicker value={single} onSelect={setSingle} />
          <h4 style={{ marginTop: 12 }}>2. Rules to practise with</h4>
          <select aria-label="Rules" value={rulesSource} onChange={(e) => setRulesSource(e.target.value)} style={{ width: "100%", minHeight: 44, fontSize: 16 }}>
            <option value="custom">Moving average crossover template (editable)</option>
            {versions.map((v) => <option key={v.id} value={`saved:${v.id}`}>{v.label}</option>)}
          </select>
          {!rulesVersion && (
            <details style={{ marginTop: 8 }}>
              <summary className="sb__note">Edit the rules (advanced)</summary>
              <textarea aria-label="Strategy rules JSON" rows="14" value={customJson} onChange={(e) => setCustomJson(e.target.value)} style={{ width: "100%", fontFamily: "monospace", fontSize: 12 }} />
              <button type="button" onClick={() => setCustomJson(templateJson())} style={{ marginTop: 6, minHeight: 40 }}>Reset template</button>
            </details>
          )}
        </div>
      )}

      <div className="sb__panel">
        <h4>Period and money</h4>
        <div className="sb__chips" role="group" aria-label="Quick period">
          {RANGES.map((r) => (
            <button key={r.label} type="button" className="sb__chip" onClick={() => { setFrom(isoDay(-r.days)); setTo(isoDay(0)); }}>{r.label}</button>
          ))}
        </div>
        <div className="sb__grid2" style={{ marginTop: 8 }}>
          <div><span className="sb__lab">From</span><input type="date" aria-label="From date" value={from} onChange={(e) => setFrom(e.target.value)} style={{ width: "100%", minHeight: 44 }} /></div>
          <div><span className="sb__lab">To</span><input type="date" aria-label="To date" value={to} onChange={(e) => setTo(e.target.value)} style={{ width: "100%", minHeight: 44 }} /></div>
          <div><span className="sb__lab">Starting capital ₹</span><input type="number" min="1" aria-label="Initial capital" value={capital} onChange={(e) => setCapital(e.target.value)} style={{ width: "100%", minHeight: 44 }} /></div>
          <div><span className="sb__lab">Slippage (0.0005 = 0.05%)</span><input type="number" min="0" step="any" aria-label="Slippage" value={slippage} onChange={(e) => setSlippage(e.target.value)} style={{ width: "100%", minHeight: 44 }} /></div>
        </div>
        <details style={{ marginTop: 8 }}>
          <summary className="sb__note">Trading costs (advanced)</summary>
          <span className="sb__lab">Flat brokerage ₹ per side</span>
          <input type="number" min="0" step="any" aria-label="Flat fees" value={fees} onChange={(e) => setFees(e.target.value)} style={{ width: "100%", minHeight: 44 }} />
          <span className="sb__lab">Cost model (STT, exchange, SEBI, GST, stamp duty; 0 = off)</span>
          <textarea aria-label="Backtest cost model" rows="7" value={costJson} onChange={(e) => setCostJson(e.target.value)} style={{ width: "100%", fontFamily: "monospace", fontSize: 12 }} />
        </details>
        <p className="sb__note">Kotak history is fetched automatically in the chunks it allows.</p>
        <div className="sb__actions"><button type="button" onClick={run} disabled={busy}>{busy ? "Running…" : "Run backtest"}</button></div>
        {progress && <p className="sb__note" role="status">{progress}</p>}
        {msg && <p className="sb__msg sb__msg--bad" role="alert">{msg}</p>}
      </div>

      {rows.length > 0 && (
        <div className="sb__panel">
          <h4>Results by stock</h4>
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Stock</th><th>Trades</th><th>Win rate</th><th>Net P&amp;L</th><th>Drawdown</th><th /></tr></thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={r.token}>
                    <td>{r.symbol}</td>
                    {r.ok ? (<><td>{r.result.total_trades ?? "—"}</td><td>{num(r.result.win_rate, 1, "%")}</td><td>{num(r.result.net_pnl)}</td><td>{num(r.result.max_drawdown)}</td>
                      <td><button type="button" onClick={() => setShown(i)}>View</button></td></>)
                      : (<td colSpan={5} style={{ color: "var(--sb-bad)" }}>{r.error}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {detail && <ResultView row={detail} />}

      <div className="sb__panel">
        <h4>Run history</h4>
        {(history.body?.backtests || []).length === 0 && <p className="sb__note">No runs yet.</p>}
        {(history.body?.backtests || []).map((x) => (
          <div key={x.id} className="sb__line" style={{ alignItems: "flex-start" }}>
            <span><b>#{x.id}</b> · {x.request?.trading_symbol || "—"} · {String(x.created_at || "").slice(0, 16)}</span>
            <span style={{ textAlign: "right", color: x.status === "FAILED" ? "var(--sb-bad)" : undefined, maxWidth: "55%", overflowWrap: "anywhere" }}>
              {x.status === "FAILED" ? `Failed: ${x.error_message || "unknown error"}` : `${x.status} · P&L ${x.result?.net_pnl ?? "—"}`}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
