import {
  OPERAND_KINDS, KIND_BY_ID, OPERATORS, MAX_OFFSET, MAX_DEPTH, parseOperand, formatOperand, blankCondition, describeGroup,
} from "../../lib/conditionBuilder";
import "./conditionBuilder.css";

const GROUPS = ["Price", "Trend", "Momentum", "Volatility", "Volume"];
const OFFSET_CHOICES = [0, 1, 2, 3, 4, 5, 10];

function OperandEditor({ label, raw, onChange, allowNumber }) {
  const parsed = parseOperand(raw);
  const isNumber = !!allowNumber && (parsed?.type === "number" || (parsed === null && raw !== undefined && !/[a-z]/i.test(String(raw))));
  const ind = parsed?.type === "indicator" ? parsed : { kind: "close", period: null, offset: 0 };
  const kind = KIND_BY_ID[ind.kind];

  function setIndicator(patch) {
    const next = { ...ind, ...patch };
    const k = KIND_BY_ID[next.kind];
    if (k.periodic && (next.period === null || next.period === undefined || patch.kind)) next.period = patch.kind ? k.def : (next.period ?? k.def);
    if (!k.periodic) next.period = null;
    onChange(formatOperand(next));
  }

  return (
    <div className="cb__operand" role="group" aria-label={label}>
      {allowNumber && (
        <div className="cb__chips" role="group" aria-label={`${label} type`}>
          <button type="button" className={`cb__chip ${!isNumber ? "cb__chip--on" : ""}`} aria-pressed={!isNumber} onClick={() => !(!isNumber) && onChange("close")}>Indicator</button>
          <button type="button" className={`cb__chip ${isNumber ? "cb__chip--on" : ""}`} aria-pressed={isNumber} onClick={() => !isNumber && onChange(0)}>Number</button>
        </div>
      )}
      {isNumber ? (
        <input type="number" step="any" aria-label={`${label} number`} className="cb__num" value={parsed?.type === "number" ? parsed.value : (raw ?? "")}
          onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))} />
      ) : (
        <>
          <select aria-label={`${label} indicator`} value={ind.kind} onChange={(e) => setIndicator({ kind: e.target.value })}>
            {GROUPS.map((g) => (
              <optgroup key={g} label={g}>
                {OPERAND_KINDS.filter((k) => k.group === g).map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
              </optgroup>
            ))}
          </select>
          {kind.periodic && (
            <input type="number" aria-label={`${label} period`} className="cb__num" min={kind.min} max={kind.max} value={ind.period ?? kind.def}
              onChange={(e) => setIndicator({ period: e.target.value === "" ? kind.def : Math.max(kind.min, Math.min(kind.max, Math.round(Number(e.target.value)))) })} />
          )}
          <select aria-label={`${label} candle`} value={ind.offset} onChange={(e) => setIndicator({ offset: Number(e.target.value) })}>
            {[...new Set([...OFFSET_CHOICES, ind.offset])].sort((a, b) => a - b).filter((o) => o <= MAX_OFFSET).map((o) => (
              <option key={o} value={o}>{o === 0 ? "Latest completed candle" : `${o} candle${o > 1 ? "s" : ""} ago`}</option>
            ))}
          </select>
        </>
      )}
    </div>
  );
}

function ConditionRow({ cond, index, onChange, onRemove, canRemove }) {
  const set = (patch) => onChange({ ...cond, ...patch });
  const rightIsIndicator = parseOperand(cond.right)?.type === "indicator";
  return (
    <div className="cb__row">
      <div className="cb__rowhead">
        <span>Condition {index + 1}</span>
        <span className="cb__actions">
          <button type="button" className={`cb__chip ${cond.not ? "cb__chip--on" : ""}`} aria-pressed={!!cond.not} aria-label={`Condition ${index + 1} NOT`} onClick={() => set({ not: !cond.not })}>NOT</button>
          {canRemove && <button type="button" className="cb__chip cb__chip--danger" aria-label={`Remove condition ${index + 1}`} onClick={onRemove}>Remove</button>}
        </span>
      </div>
      <div className="cb__side">
        <OperandEditor label={`Condition ${index + 1} left`} raw={cond.left} onChange={(v) => set({ left: v })} />
        <select aria-label={`Condition ${index + 1} comparison`} value={cond.operator} onChange={(e) => set({ operator: e.target.value })}>
          {OPERATORS.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
        </select>
        <OperandEditor label={`Condition ${index + 1} right`} raw={cond.right} onChange={(v) => set({ right: v })} allowNumber />
        {rightIsIndicator && (
          <div className="cb__operand">
            <span className="cb__label">Multiply the right side by</span>
            <input type="number" step="any" min="0" aria-label={`Condition ${index + 1} multiplier`} className="cb__num" placeholder="1" value={cond.mult ?? ""}
              onChange={(e) => set({ mult: e.target.value === "" ? undefined : Number(e.target.value) })} />
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Chartink-style rule editor: AND / OR groups, NOT, nested groups, any indicator period, "N candles ago" and
 * multipliers. `value` / `onChange` carry the engine's group JSON directly.
 */
export default function ConditionBuilder({ title = "Conditions", value, onChange, depth = 0, onRemove, errors = [] }) {
  const group = value || { op: "AND", conditions: [] };
  const conditions = group.conditions || [];
  const groups = group.groups || [];
  const set = (patch) => onChange({ ...group, ...patch });

  return (
    <div className="cb">
      <div className="cb__group">
        <div className="cb__head">
          <span className="cb__title">{title}</span>
          <span className="cb__chips" role="group" aria-label={`${title} logic`}>
            {["AND", "OR"].map((op) => (
              <button key={op} type="button" className={`cb__chip ${group.op === op ? "cb__chip--on" : ""}`} aria-pressed={group.op === op} onClick={() => set({ op })}>{op}</button>
            ))}
          </span>
          <button type="button" className={`cb__chip ${group.not ? "cb__chip--on" : ""}`} aria-pressed={!!group.not} aria-label={`${title} NOT`} onClick={() => set({ not: !group.not })}>NOT (whole group)</button>
          {onRemove && <button type="button" className="cb__chip cb__chip--danger" onClick={onRemove}>Remove group</button>}
        </div>

        {conditions.map((c, i) => (
          <div key={i}>
            {i > 0 && <p className="cb__join">{group.op}</p>}
            <ConditionRow cond={c} index={i} canRemove={conditions.length + groups.length > 1}
              onChange={(next) => set({ conditions: conditions.map((x, n) => (n === i ? next : x)) })}
              onRemove={() => set({ conditions: conditions.filter((_, n) => n !== i) })} />
          </div>
        ))}

        {groups.map((g, i) => (
          <div key={`g${i}`}>
            <p className="cb__join">{group.op}</p>
            <ConditionBuilder title={`Group ${i + 1}`} value={g} depth={depth + 1}
              onChange={(next) => set({ groups: groups.map((x, n) => (n === i ? next : x)) })}
              onRemove={() => { const rest = groups.filter((_, n) => n !== i); set({ groups: rest.length ? rest : undefined }); }} />
          </div>
        ))}

        <div className="cb__actions">
          <button type="button" className="cb__chip" onClick={() => set({ conditions: [...conditions, blankCondition({ operator: ">" })] })}>+ Condition</button>
          {depth + 1 < MAX_DEPTH && (
            <button type="button" className="cb__chip" onClick={() => set({ groups: [...groups, { op: "OR", conditions: [blankCondition({ operator: ">" })] }] })}>+ Group</button>
          )}
        </div>
        {depth === 0 && <p className="cb__sentence">{describeGroup(group)}</p>}
        {errors.map((e) => <p key={e} className="cb__error" role="alert">{e}</p>)}
      </div>
    </div>
  );
}
