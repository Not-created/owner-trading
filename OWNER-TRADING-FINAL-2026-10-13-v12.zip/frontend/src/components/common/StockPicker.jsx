import { useEffect, useRef, useState } from "react";
import { api } from "../../api/client";
import "./stockPicker.css";

/**
 * Type-ahead stock chooser. Typing searches the synced scrip master instantly (no Kotak call per
 * keystroke); picking a row fills token + symbol, so nobody has to know an instrument token.
 * `onSelect({ token, symbol, name })` is called on pick and `onSelect(null)` when the text is edited.
 */
export default function StockPicker({ value, onSelect, exchangeSegment = "nse_cm", placeholder = "Type a stock name, e.g. HDFC", label = "Stock" }) {
  const [query, setQuery] = useState(value?.symbol || "");
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const seq = useRef(0);

  useEffect(() => {
    const q = query.trim();
    if (!open || !q) return undefined;
    const mine = ++seq.current;
    const timer = setTimeout(async () => {
      setBusy(true); setNote("");
      const r = await api.lookupInstruments({ exchange_segment: exchangeSegment, query: q, limit: 12 });
      if (mine !== seq.current) return;           // a newer keystroke superseded this answer
      setBusy(false);
      if (!r.ok) { setItems([]); setNote(r.body?.error || "Search failed."); return; }
      const rows = r.body?.instruments || [];
      setItems(rows);
      if (!rows.length) setNote(r.body?.total_synced ? "No stock matches that. Check the spelling." : "No instruments are synced yet. Open Market Data and sync the scrip master.");
    }, 180);
    return () => clearTimeout(timer);
  }, [query, open, exchangeSegment]);

  function pick(row) {
    const symbol = row.trading_symbol;
    setQuery(symbol); setOpen(false); setItems([]); setNote("");
    onSelect({ token: String(row.instrument_token), symbol, name: row.name || "" });
  }

  async function searchKotak() {
    const q = query.trim();
    if (q.length < 2) return;
    setBusy(true); setNote("");
    const r = await api.searchScrip({ exchange_segment: exchangeSegment, symbol: q });
    setBusy(false);
    if (!r.ok) { setNote(r.body?.error || "Kotak search failed."); return; }
    const rows = (Array.isArray(r.body?.data) ? r.body.data : []).slice(0, 12)
      .map((x) => ({ instrument_token: x.pSymbol, trading_symbol: x.pTrdSymbol, name: x.pSymbolName }))
      .filter((x) => x.instrument_token && x.trading_symbol);
    setItems(rows);
    setNote(rows.length ? "" : "Kotak found nothing for that either.");
  }

  function onChange(e) {
    setQuery(e.target.value); setOpen(true);
    if (value) onSelect(null);                     // editing the text drops the previous selection
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && items.length) { e.preventDefault(); pick(items[0]); }
    if (e.key === "Escape") setOpen(false);
  }

  return (
    <div className="sp">
      <input aria-label={label} role="combobox" aria-expanded={open && items.length > 0} aria-autocomplete="list" autoComplete="off"
        value={query} onChange={onChange} onKeyDown={onKeyDown} placeholder={placeholder} className="sp__input" />
      {value && <div className="sp__picked">Selected: <b>{value.symbol}</b>{value.name ? ` · ${value.name}` : ""}</div>}
      {open && (busy || items.length > 0 || note) && (
        <ul className="sp__list" role="listbox">
          {busy && <li className="sp__hint">Searching…</li>}
          {items.map((row) => (
            <li key={`${row.exchange_segment || exchangeSegment}-${row.instrument_token}`} role="option" aria-selected="false">
              <button type="button" className="sp__item" onClick={() => pick(row)}>
                <b>{row.trading_symbol}</b><span>{row.name || ""}</span>
              </button>
            </li>
          ))}
          {!busy && note && <li className="sp__hint">{note}</li>}
          {!busy && query.trim().length >= 2 && items.length === 0 && (
            <li><button type="button" className="sp__item sp__kotak" onClick={searchKotak}>Not found? Search on Kotak</button></li>
          )}
        </ul>
      )}
    </div>
  );
}
