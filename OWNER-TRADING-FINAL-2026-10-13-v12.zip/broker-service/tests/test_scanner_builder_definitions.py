"""Every scanner definition the frontend condition builder can emit must pass the REAL engine validator,
and the default rule (EMA20 crosses above EMA50 AND RSI14 above 60) must behave as described."""
import json
import os
import unittest

from app import scanner_engine as sc
from app import strategy_engine as se

FIXTURE = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "test", "fixtures", "scanner-definitions.json")


def bars(values, volume=1000):
    return [{"candle_at": f"2026-09-{(i // 60) + 1:02d} {9 + (i % 60) // 4:02d}:{(i % 4) * 15:02d}:00", "open": v, "high": v + 0.5, "low": v - 0.5,
             "close": v, "volume": volume} for i, v in enumerate(values)]


@unittest.skipUnless(os.path.exists(FIXTURE), "frontend fixture not present")
class ScannerDefinitions(unittest.TestCase):
    def setUp(self):
        with open(FIXTURE, encoding="utf-8") as fh:
            self.cases = json.load(fh)

    def test_all_builder_outputs_validate(self):
        self.assertGreaterEqual(len(self.cases), 4)
        for name, d in self.cases.items():
            self.assertEqual(se.validate_scanner(d), [], name)
            self.assertGreaterEqual(sc.required_bars(d), 20, name)

    def test_default_rule_uses_rsi_60(self):
        d = self.cases["default_scanner"]
        self.assertEqual(d["entry"]["conditions"][1], {"left": "rsi14", "operator": ">", "right": 60})

    def test_default_rule_fires_on_a_breakout_and_not_on_a_flat_market(self):
        d = self.cases["default_scanner"]
        flat = bars([100.0] * 120)
        self.assertFalse(se.evaluate_entry(d, flat)[0])
        # quiet market, then a strong sustained rally: EMA20 crosses EMA50 while RSI is high
        rally = bars([100.0] * 80 + [100 + 2.5 * k for k in range(1, 25)])
        hits = [i for i in range(60, len(rally)) if se.evaluate_entry(d, rally[: i + 1])[0]]
        self.assertTrue(hits)
        self.assertGreaterEqual(min(hits), 80)
        # the RSI leg is really part of the AND: demanding a weak RSI on the same rally never fires
        strict = json.loads(json.dumps(d)); strict["entry"]["conditions"][1] = {"left": "rsi14", "operator": "<", "right": 10}
        self.assertFalse(any(se.evaluate_entry(strict, rally[: i + 1])[0] for i in range(60, len(rally))))

    def test_offsets_multiplier_and_not_evaluate_in_the_real_engine(self):
        d = self.cases["offsets_mult_not"]
        series = bars([100.0 + (i % 7) * 0.1 for i in range(120)])
        ok, detail = se.evaluate_entry(d, series)
        self.assertIn(ok, (True, False))
        self.assertTrue(detail["items"])                                   # evaluated without raising on every v2 feature

    def test_filtered_ranked_scanner_options_roundtrip(self):
        opts = sc.scan_options(self.cases["filtered_ranked"])
        self.assertEqual(opts["series"], ["EQ", "BE", "SM"])
        self.assertEqual((opts["min_price"], opts["max_price"], opts["min_avg_volume"], opts["max_candidates"], opts["rank_by"]), (50.0, 5000.0, 200000.0, 20, "turnover"))


if __name__ == "__main__":
    unittest.main()
