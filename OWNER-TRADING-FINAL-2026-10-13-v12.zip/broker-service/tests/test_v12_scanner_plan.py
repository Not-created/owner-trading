import asyncio
import datetime as dt
import os
import time
import unittest
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

from app import scanner_engine as se
from app import strategy_engine as eng
from tests.dbutil import fresh_db
from tests.test_server import ServerBase, call

IST = ZoneInfo("Asia/Kolkata")
THU = dt.date(2026, 10, 8)            # a Thursday


def at(h, m, s=0, day=THU):
    return dt.datetime(day.year, day.month, day.day, h, m, s, tzinfo=IST)


def mk_candles(token, n=80, volume=1000, start=100.0, step=0.4, minutes=5, end=None, symbol=None):
    end = end or dt.datetime.now(IST).replace(second=0, microsecond=0)
    end = end - dt.timedelta(minutes=end.minute % minutes + minutes)           # last completed bar start
    out = []
    for i in range(n):
        ts = end - dt.timedelta(minutes=minutes * (n - 1 - i))
        px = start + i * step
        out.append({"exchange_segment": "nse_cm", "instrument_token": str(token), "trading_symbol": symbol or f"S{token}-EQ", "timeframe": f"{minutes}m",
                    "candle_at": ts.strftime("%Y-%m-%d %H:%M:%S"), "open": px, "high": px + 0.5, "low": px - 0.5, "close": px,
                    "volume": volume(i) if callable(volume) else volume})
    return out


SCANNER = {"side": "BUY", "timeframe": "5m",
           "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "ema20"}, {"left": "rsi14", "operator": ">", "right": 60}]}}


class Universe(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        rows = []
        for i, (sym, tok) in enumerate([("ZEEL-EQ", 3), ("ACC-EQ", 9), ("TATA-BE", 5), ("SMALL-SM", 7), ("JUNK-BZ", 11), ("GOLD-GS", 13), ("NIFTYBEES-EQ", 2)]):
            rows.append({"trading_symbol": sym, "instrument_token": str(tok), "lot_size": 1, "tick_size": 0.05})
        self.db.bulk_upsert_instruments(rows)

    def test_default_is_eq_only_and_series_are_selectable(self):
        syms = lambda s: [r["trading_symbol"] for r in self.db.list_scan_universe(s)]
        self.assertEqual(syms(("EQ",)), ["NIFTYBEES-EQ", "ZEEL-EQ", "ACC-EQ"])
        self.assertEqual(syms(("EQ", "BE", "SM")), ["NIFTYBEES-EQ", "ZEEL-EQ", "TATA-BE", "SMALL-SM", "ACC-EQ"])
        self.assertEqual(syms(("BZ",)), ["JUNK-BZ"])
        self.assertEqual(syms(("bogus",)), ["NIFTYBEES-EQ", "ZEEL-EQ", "ACC-EQ"])        # unknown series fall back to EQ

    def test_no_alphabetical_cutoff_and_stable_order(self):
        rows = [{"trading_symbol": f"{c}{i}-EQ", "instrument_token": str(1000 + n), "lot_size": 1, "tick_size": 0.05}
                for n, (c, i) in enumerate((c, i) for c in "AZ" for i in range(50))]
        self.db.bulk_upsert_instruments(rows)
        got = self.db.list_scan_universe(("EQ",), limit=1000)
        self.assertTrue(any(r["trading_symbol"].startswith("Z") for r in got))             # Z-stocks are reached
        toks = [int(r["instrument_token"]) for r in got]
        self.assertEqual(toks, sorted(toks))

    def test_series_counts_for_the_measurement_step(self):
        c = self.db.count_instruments_by_series()
        self.assertEqual(c["total"], 7); self.assertEqual(c["by_series"]["EQ"], 3); self.assertEqual(c["by_series"]["BZ"], 1)


class ScannerValidation(unittest.TestCase):
    def test_scanner_needs_only_entry_and_timeframe(self):
        self.assertEqual(eng.validate_scanner(SCANNER), [])
        self.assertEqual(eng.validate_scanner(dict(SCANNER, scan={"series": ["EQ", "BE"], "min_price": 50, "max_price": 5000, "min_avg_volume": 200000,
                                                                 "max_candidates": 50, "rank_by": "turnover"})), [])

    def test_bad_scan_options_and_bad_conditions_are_reported(self):
        e = eng.validate_scanner(dict(SCANNER, scan={"series": ["XX"], "min_price": 9, "max_price": 3, "max_candidates": 0, "rank_by": "luck"}))
        self.assertTrue(any("series" in x for x in e)); self.assertTrue(any("min_price cannot be above" in x for x in e))
        self.assertTrue(any("max_candidates" in x for x in e)); self.assertTrue(any("rank_by" in x for x in e))
        bad = dict(SCANNER, entry={"op": "AND", "conditions": [{"left": "ema0", "operator": ">", "right": 1}]})
        self.assertTrue(any("operand" in x for x in eng.validate_scanner(bad)))
        self.assertTrue(eng.validate_scanner({"timeframe": "7m", "entry": SCANNER["entry"]}))
        self.assertTrue(eng.validate_scanner("nope"))


class ScanFiltersRankingCap(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        rows = []
        specs = {1: (100, 5000), 2: (30, 900000), 3: (400, 20000), 4: (900, 50), 5: (250, 700000)}       # token: (start price, volume)
        for tok, (px, vol) in specs.items():
            self.db.bulk_upsert_instruments([{"trading_symbol": f"S{tok}-EQ", "instrument_token": str(tok), "lot_size": 1, "tick_size": 0.05}])
            rows += mk_candles(tok, start=px, volume=vol)
        self.db.upsert_candles(rows)
        self.universe = self.db.list_scan_universe(("EQ",))

    def scan(self, **scan):
        d = dict(SCANNER, scan=scan) if scan else dict(SCANNER)
        return se._scan_with_stats(self.universe, d, "5m")

    def test_all_rising_stocks_match_without_filters(self):
        m, st = self.scan()
        self.assertEqual({x["instrument"]["trading_symbol"] for x in m}, {f"S{i}-EQ" for i in range(1, 6)})
        self.assertEqual((st["evaluated"], st["filtered_out"], st["capped"]), (5, 0, 0))

    def test_price_and_volume_filters(self):
        m, st = self.scan(min_price=100, max_price=500)
        self.assertEqual({x["instrument"]["trading_symbol"] for x in m}, {"S1-EQ", "S3-EQ", "S5-EQ"})
        self.assertEqual(st["filtered_out"], 2)
        m, st = self.scan(min_avg_volume=100000)
        self.assertEqual({x["instrument"]["trading_symbol"] for x in m}, {"S2-EQ", "S5-EQ"})

    def test_rank_and_cap_keep_the_top_stocks(self):
        m, st = self.scan(rank_by="volume", max_candidates=2)
        self.assertEqual([x["instrument"]["trading_symbol"] for x in m], ["S2-EQ", "S5-EQ"])
        self.assertEqual((st["matched"], st["matched_total"], st["capped"]), (2, 5, 3))
        m, _ = self.scan(rank_by="price", max_candidates=1)
        self.assertEqual(m[0]["instrument"]["trading_symbol"], "S4-EQ")
        self.assertIn("top 2 kept of 5", se.explain_scan(self.scan(max_candidates=2)[1], market_open=True))

    def test_why_matched_lists_the_passed_conditions(self):
        m, _ = self.scan()
        why = m[0]["why"]
        self.assertTrue(any("close > ema20" in w for w in why)); self.assertTrue(any("rsi14 > 60" in w for w in why))

    def test_only_the_needed_number_of_bars_is_loaded(self):
        with patch.object(self.db, "recent_candles_for_instruments", wraps=self.db.recent_candles_for_instruments) as spy:
            se._scan_with_stats(self.universe, SCANNER, "5m")
        self.assertLessEqual(spy.call_args.args[2], se.required_bars(SCANNER) + 3)

    def test_required_bars_follow_offsets_and_periods(self):
        d = {"entry": {"op": "AND", "conditions": [{"left": "ema13[3]", "operator": ">", "right": "ema200"}]}}
        self.assertEqual(se.required_bars(d), 202)
        self.assertEqual(se.required_bars({"entry": {"op": "AND", "conditions": [{"left": "close[5]", "operator": ">", "right": "hh30"}]}}), 33)


class BarCloseSchedule(unittest.TestCase):
    def test_five_minute_boundaries(self):
        f = lambda h, m, s=0, tf="5m", day=THU: se.last_bar_boundary(tf, at(h, m, s, day))
        self.assertIsNone(f(9, 14)); self.assertIsNone(f(9, 18))                       # first bar not closed yet
        self.assertIsNone(f(9, 20, 1))                                                  # closed, but still inside the 3 s settle delay
        self.assertEqual(f(9, 20, 3), "2026-10-08 09:20:00")
        self.assertEqual(f(9, 24, 59), "2026-10-08 09:20:00")
        self.assertEqual(f(9, 25, 4), "2026-10-08 09:25:00")
        self.assertEqual(f(9, 25, 1), "2026-10-08 09:20:00")                             # before the delay the previous bar is still the newest due one
        self.assertEqual(f(15, 29, 59), "2026-10-08 15:25:00")
        self.assertEqual(f(15, 30, 4), "2026-10-08 15:30:00")                           # last bar of the day
        self.assertEqual(f(18, 0), "2026-10-08 15:30:00")                               # evening: nothing newer than the close

    def test_fifteen_minute_hour_and_partial_last_bar(self):
        self.assertEqual(se.last_bar_boundary("15m", at(10, 5)), "2026-10-08 10:00:00")
        self.assertEqual(se.last_bar_boundary("15m", at(10, 0, 5)), "2026-10-08 10:00:00")
        self.assertEqual(se.last_bar_boundary("1h", at(11, 40)), "2026-10-08 11:15:00")
        self.assertEqual(se.last_bar_boundary("1h", at(15, 20)), "2026-10-08 15:15:00")
        self.assertEqual(se.last_bar_boundary("1h", at(15, 31)), "2026-10-08 15:30:00")      # the shortened final hourly bar
        self.assertEqual(se.last_bar_boundary("1m", at(9, 16, 5)), "2026-10-08 09:16:00")

    def test_daily_runs_once_after_the_close(self):
        self.assertIsNone(se.last_bar_boundary("1d", at(15, 44)))
        self.assertEqual(se.last_bar_boundary("1d", at(15, 45, 4)), "2026-10-08 15:45:00")
        self.assertEqual(se.last_bar_boundary("1d", at(20, 0)), "2026-10-08 15:45:00")

    def test_weekend_holiday_and_unknown_timeframe(self):
        self.assertIsNone(se.last_bar_boundary("5m", at(10, 0, day=dt.date(2026, 10, 10))))
        with patch.dict(os.environ, {"MARKET_HOLIDAYS": "2026-10-08"}):
            self.assertIsNone(se.last_bar_boundary("5m", at(10, 0)))
        self.assertIsNone(se.last_bar_boundary("7m", at(10, 0)))


class DueCycles(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        se._LAST_RUN.clear()
        sc = self.db.create_scanner("m", dict(SCANNER))
        self.db.activate_scanner(sc["id"]) if hasattr(self.db, "activate_scanner") else self.db.set_scanner_active(sc["id"], True)
        st = self.db.create_strategy("s")
        d = dict(SCANNER, scanner_ids=[sc["id"]], exit={"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
                 position_sizing={"quantity": 1}, risk={"stop_loss_pct": 1}, universe={"instrument_tokens": []}, max_positions=1)
        v = self.db.save_strategy_version(st["id"], d)
        self.db.set_strategy_armed(v["id"], True)
        self.sid = sc["id"]

    async def test_a_bar_is_scanned_once_and_recorded(self):
        calls = []

        async def fake(only_scanner_ids=None, bar_keys=None, trigger="X"):
            calls.append((only_scanner_ids, bar_keys, trigger)); return {"scanners": 1, "matched": 0}
        with patch.object(se, "run_continuous_cycle", fake), patch.object(se, "ensure_scanner_market_universe", AsyncMock(return_value={})):
            r1 = await se.run_due_cycles(at(10, 5, 4))
            r2 = await se.run_due_cycles(at(10, 5, 9))             # same bar: nothing
            r3 = await se.run_due_cycles(at(10, 10, 4))            # next bar
        self.assertEqual(r1["due"], {self.sid: "2026-10-08 10:05:00"})
        self.assertIsNone(r2)
        self.assertEqual(r3["due"], {self.sid: "2026-10-08 10:10:00"})
        self.assertEqual([c[2] for c in calls], ["BAR_CLOSE", "BAR_CLOSE"])

    async def test_a_mid_day_restart_catches_up_with_one_scan(self):
        calls = []

        async def fake(**kw):
            calls.append(kw); return {"scanners": 1, "matched": 0}
        with patch.object(se, "run_continuous_cycle", fake), patch.object(se, "ensure_scanner_market_universe", AsyncMock(return_value={})):
            await se.run_due_cycles(at(13, 2, 30))                 # process restarted at 13:02: the 13:00 bar is scanned immediately
            await se.run_due_cycles(at(13, 3, 10))
        self.assertEqual(len(calls), 1)

    async def test_no_scan_on_a_closed_market_day(self):
        with patch.object(se, "run_continuous_cycle", AsyncMock()) as cyc, patch.object(se, "ensure_scanner_market_universe", AsyncMock(return_value={})):
            self.assertIsNone(await se.run_due_cycles(at(10, 5, 4, day=dt.date(2026, 10, 10))))
        cyc.assert_not_awaited()

    async def test_scan_run_history_is_written_by_a_real_pass(self):
        self.db.bulk_upsert_instruments([{"trading_symbol": "AAA-EQ", "instrument_token": "11", "lot_size": 1, "tick_size": 0.05}])
        self.db.upsert_candles(mk_candles(11, volume=5000))
        with patch.object(se, "start_warmup_job", lambda *a, **k: None), \
             patch.object(se.websocket_manager, "ensure_owner_subscriptions", AsyncMock(return_value={"added": 1, "total": 1})), \
             patch.object(se.websocket_manager, "subscribe", AsyncMock()), patch.object(se.websocket_manager, "release_owner", AsyncMock(return_value=0)), \
             patch.object(se.websocket_manager, "remove_if_unneeded", AsyncMock(return_value=0)), \
             patch("app.algo_engine.algo_engine.on_tick", AsyncMock()):
            r = await se.run_continuous_cycle(only_scanner_ids={self.sid}, bar_keys={self.sid: "2026-10-08 10:05:00"}, trigger="BAR_CLOSE")
        self.assertEqual(r["matched"], 1)
        runs = self.db.list_scan_runs(5)
        self.assertEqual((runs[0]["trigger"], runs[0]["bar_at"], runs[0]["matched"], runs[0]["status"]), ("BAR_CLOSE", "2026-10-08 10:05:00", 1, "OK"))
        self.assertEqual(runs[0]["stats"]["universe"], 1)
        cand = self.db.list_strategy_candidates(active_only=True)[0]
        self.assertTrue(cand["conditions"]["why"])                                       # "why matched" is stored with the candidate


class UniverseFeedLifecycle(unittest.IsolatedAsyncioTestCase):
    async def test_universe_is_subscribed_when_armed_and_released_when_nothing_uses_a_scanner(self):
        db = fresh_db()
        se._LAST_RUN.clear()
        sc = db.create_scanner("m", dict(SCANNER))
        db.activate_scanner(sc["id"]) if hasattr(db, "activate_scanner") else db.set_scanner_active(sc["id"], True)
        st = db.create_strategy("s")
        v = db.save_strategy_version(st["id"], dict(SCANNER, scanner_ids=[sc["id"]], exit={"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
                                                   position_sizing={"quantity": 1}, risk={"stop_loss_pct": 1}, universe={"instrument_tokens": []}, max_positions=1))
        db.set_strategy_armed(v["id"], True)
        ensure = AsyncMock(return_value={}); release = AsyncMock(return_value=0)
        wsm = se.websocket_manager
        with patch.object(se, "ensure_scanner_market_universe", ensure), patch.object(se, "run_continuous_cycle", AsyncMock(return_value={})), \
             patch.object(wsm, "has_owner", return_value=False), patch.object(wsm, "release_owner", release):
            await se.run_due_cycles(at(8, 50))                               # before the open: subscribe so candles form from 09:15
            ensure.assert_awaited_once(); release.assert_not_awaited()
            db.set_strategy_armed(v["id"], False)
        with patch.object(se, "ensure_scanner_market_universe", ensure), patch.object(wsm, "has_owner", return_value=True), patch.object(wsm, "release_owner", release):
            self.assertIsNone(await se.run_due_cycles(at(10, 5, 4)))
            release.assert_awaited_with("scanner-universe")                  # nothing armed: the 2000 stocks leave the feed


class FeedBudget(unittest.IsolatedAsyncioTestCase):
    async def test_universe_subscription_respects_the_reserve_and_reports_truncation(self):
        db = fresh_db()
        db.bulk_upsert_instruments([{"trading_symbol": f"X{i}-EQ", "instrument_token": str(100 + i), "lot_size": 1, "tick_size": 0.05} for i in range(30)])
        sub = AsyncMock(return_value={"added": 10, "total": 10})
        with patch.object(se.websocket_manager, "ensure_owner_subscriptions", sub):
            r = await se.ensure_scanner_market_universe(("EQ",), limit=10)
        self.assertEqual((r["universe"], r["truncated"]), (10, 20))
        self.assertEqual(len(sub.await_args.args[0]), 10)
        self.assertEqual(se.SCAN_UNIVERSE_CAP + se.SCAN_FEED_RESERVE, se.SCAN_FEED_BUDGET)
        with patch.object(se.websocket_manager, "ensure_owner_subscriptions", sub):
            big = await se.ensure_scanner_market_universe(("EQ",), limit=999999)
        self.assertLessEqual(big["universe"], se.SCAN_UNIVERSE_CAP)


class Retention(unittest.TestCase):
    def test_old_candles_are_pruned_per_timeframe(self):
        db = fresh_db()
        now = dt.datetime.now(IST)
        rows = []
        for tf, days in (("1m", 3), ("1m", 20), ("15m", 20), ("15m", 200), ("1d", 200), ("1d", 1500)):
            ts = (now - dt.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
            rows.append({"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "A-EQ", "timeframe": tf, "candle_at": ts,
                         "open": 1, "high": 1, "low": 1, "close": 1, "volume": 1})
        db.upsert_candles(rows)
        removed = db.prune_candles()
        self.assertEqual((removed["1m"], removed["15m"], removed["1d"]), (1, 1, 1))
        with db._connection() as c:
            left = sorted((r[0], r[1]) for r in c.execute("SELECT timeframe, CAST((julianday('now')-julianday(candle_at)) AS INT) FROM candles"))
        self.assertEqual([x[0] for x in left], ["15m", "1d", "1m"])


class Routes(ServerBase):
    async def test_scan_runs_and_universe_preview(self):
        self.db.bulk_upsert_instruments([{"trading_symbol": "A-EQ", "instrument_token": "1", "lot_size": 1, "tick_size": 0.05},
                                         {"trading_symbol": "B-BE", "instrument_token": "2", "lot_size": 1, "tick_size": 0.05}])
        self.db.record_scan_run(timeframe="5m", bar_at="2026-10-08 10:05:00", universe=2, evaluated=2, matched=1, duration_ms=12, stats={"x": 1})
        s, b = await call("GET", "/algo/scan-runs")
        self.assertEqual(s, 200); self.assertEqual(b["runs"][0]["matched"], 1); self.assertIn("5m", b["last_bar_close"])
        s, b = await call("POST", "/algo/universe-preview", {"scan": {"series": ["EQ"]}})
        self.assertEqual((s, b["selected"], b["fits_feed"], b["feed_budget"]), (200, 1, True, 3000))
        s, b = await call("POST", "/algo/universe-preview", {"scan": {"series": ["EQ", "BE"]}})
        self.assertEqual(b["selected"], 2)
        s, b = await call("POST", "/algo/universe-preview", {"scan": {"series": ["ZZ"]}})
        self.assertEqual(s, 422)

    async def test_scanner_create_accepts_a_scanner_without_exit_or_risk(self):
        s, b = await call("POST", "/algo/scanners", {"name": "Chartink-like", "definition": dict(SCANNER, scan={"series": ["EQ"], "max_candidates": 20})})
        self.assertEqual(s, 200)
        s, b = await call("POST", "/algo/scanners", {"name": "bad", "definition": dict(SCANNER, scan={"rank_by": "luck"})})
        self.assertEqual(s, 422)


if __name__ == "__main__":
    unittest.main()


class FeedTiers(unittest.TestCase):
    def test_each_token_is_counted_once_under_its_most_important_owner(self):
        from app.websocket_manager import WebSocketManager
        m = WebSocketManager()
        for key, owners in {("nse_cm", "1"): {"scanner-universe", "position:5"}, ("nse_cm", "2"): {"scanner-universe", "strategy:3:candidate:2"},
                            ("nse_cm", "3"): {"scanner-universe"}, ("nse_cm", "4"): {"order:nse_cm:4"}, ("nse_cm", "5"): {"scanner-manual-matches"}}.items():
            m._subs[key] = object(); m._owners[key] = owners
        c = m.tier_counts()
        self.assertEqual((c["positions"], c["candidates"], c["scanner_universe"], c["orders"], c["manual"], c["total"]), (1, 1, 1, 1, 1, 5))
        self.assertEqual(c["limit"], 3000)


class MinBars(unittest.TestCase):
    def test_definition_min_bars_walks_nested_groups(self):
        d = {"entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": ">", "right": "ema50"}],
                       "groups": [{"op": "OR", "conditions": [{"left": "close[4]", "operator": ">", "right": "hh100"}]}]},
             "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 70}]}}
        self.assertEqual(eng.definition_min_bars(d), 101)
        self.assertEqual(eng.definition_min_bars({}), 0)


class DailyPrepPrunes(unittest.IsolatedAsyncioTestCase):
    async def test_prep_reports_pruned_candles(self):
        from app import daily_prep
        fresh_db()
        with patch("app.daily_prep.universe.sync_nse_cash_metadata", AsyncMock(return_value={"ok": True})):
            r = await daily_prep.run_daily_prep(now=at(8, 45))
        self.assertIn("1m", r["candles_pruned"])
