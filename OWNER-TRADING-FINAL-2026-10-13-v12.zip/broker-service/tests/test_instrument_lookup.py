import unittest
from tests.dbutil import fresh_db
from tests.test_server import ServerBase, call


ROWS = [
    {"trading_symbol": "HDFCBANK-EQ", "instrument_token": "1333", "name": "HDFC BANK LTD", "lot_size": 1, "tick_size": 0.05},
    {"trading_symbol": "HDFCLIFE-EQ", "instrument_token": "467", "name": "HDFC LIFE INSURANCE", "lot_size": 1, "tick_size": 0.05},
    {"trading_symbol": "ARSHIYA-BZ", "instrument_token": "29210", "name": "ARSHIYA", "lot_size": 1, "tick_size": 0.05},
    {"trading_symbol": "BANDHANBNK-EQ", "instrument_token": "2263", "name": "BANDHAN BANK", "lot_size": 1, "tick_size": 0.05},
    {"trading_symbol": "SBIN-EQ", "instrument_token": "3045", "name": "STATE BANK OF INDIA", "lot_size": 1, "tick_size": 0.05},
    {"trading_symbol": "A_B-EQ", "instrument_token": "999", "name": "UNDERSCORE", "lot_size": 1, "tick_size": 0.05},
]


class Lookup(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments(ROWS)

    def syms(self, q, **kw):
        return [r["trading_symbol"] for r in self.db.search_instruments(q, **kw)]

    def test_prefix_matches_rank_first_and_names_are_searched(self):
        self.assertEqual(self.syms("hdfc")[:2], ["HDFCBANK-EQ", "HDFCLIFE-EQ"])
        self.assertIn("SBIN-EQ", self.syms("state bank"))
        self.assertEqual(self.syms("ban")[0].startswith("BAN"), True)         # prefix beats substring ("HDFCBANK")

    def test_wildcards_are_literal_and_blank_is_empty(self):
        self.assertEqual(self.syms("%"), [])
        self.assertEqual(self.syms("_"), ["A_B-EQ"])
        self.assertEqual(self.syms(""), [])
        self.assertEqual(self.syms("   "), [])

    def test_limit_and_tokens(self):
        self.assertEqual(len(self.db.search_instruments("e", limit=2)), 2)
        got = {r["instrument_token"]: r["trading_symbol"] for r in self.db.get_instruments_by_tokens("nse_cm", ["1333", "3045", "nope"])}
        self.assertEqual(got, {"1333": "HDFCBANK-EQ", "3045": "SBIN-EQ"})
        self.assertEqual(self.db.get_instruments_by_tokens("nse_cm", []), [])


class LookupRoute(ServerBase):
    async def test_route_search_tokens_and_validation(self):
        self.db.bulk_upsert_instruments(ROWS)
        s, b = await call("POST", "/instruments-lookup", {"query": "hdfc"})
        self.assertEqual(s, 200); self.assertEqual(b["instruments"][0]["trading_symbol"], "HDFCBANK-EQ")
        s, b = await call("POST", "/instruments-lookup", {"tokens": ["3045"]})
        self.assertEqual(b["instruments"][0]["trading_symbol"], "SBIN-EQ")
        for bad in ({}, {"query": "x" * 41}, {"query": "a", "limit": "z"}, {"tokens": "1"}, {"tokens": list(range(201))}):
            s, _ = await call("POST", "/instruments-lookup", bad)
            self.assertEqual(s, 400, bad)


if __name__ == "__main__":
    unittest.main()
