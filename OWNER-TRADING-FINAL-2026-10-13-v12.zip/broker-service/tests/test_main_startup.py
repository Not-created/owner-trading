"""app/main.py startup state determination (no network, no real SDK)."""
import dataclasses
import os
import unittest
import tempfile
from unittest.mock import patch, AsyncMock
from app import main as main_module
from app import credential_manager as cm_module
from app import sdk_adapter
from app.config import Config
from app.sdk_conformance import ConformanceResult
from app.state import BrokerState, current_state
OK = ConformanceResult(ok=True, checked=20)

def _patched(available=True, version='3.0.7', conf=OK, cfg=None, mode='LIVE'):
    cfg = cfg or Config(consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None)
    cfg = dataclasses.replace(cfg, trading_mode=mode)
    return (patch.object(sdk_adapter, 'SDK_AVAILABLE', available), patch.object(sdk_adapter, 'SDK_VERSION', version), patch.object(main_module, 'config', cfg), patch('app.sdk_conformance.check_sdk_conformance', return_value=conf))

class InitialStateTests(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._old_auto_connect_path = os.environ.get("BROKER_AUTO_CONNECT_PATH")
        os.environ["BROKER_AUTO_CONNECT_PATH"] = os.path.join(self._tmp.name, "broker-auto-connect")
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()
        os.environ.pop('BROKER_SERVICE_TOKEN', None)

    def tearDown(self):
        if self._old_auto_connect_path is None:
            os.environ.pop("BROKER_AUTO_CONNECT_PATH", None)
        else:
            os.environ["BROKER_AUTO_CONNECT_PATH"] = self._old_auto_connect_path
        self._tmp.cleanup()

    def _run(self, **kw):
        os.environ["BROKER_SERVICE_TOKEN"] = "x" * 32
        ps = _patched(**kw)
        with ps[0], ps[1], ps[2], ps[3]:
            main_module._determine_initial_state()
        os.environ.pop("BROKER_SERVICE_TOKEN", None)

    def test_sdk_unavailable_is_connection_error(self):
        self._run(available=False)
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)

    def test_wrong_sdk_version_is_connection_error(self):
        self._run(version='3.0.6')
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)
        self.assertIn('3.0.7', current_state.last_error)

    def test_conformance_failure_is_connection_error(self):
        self._run(conf=ConformanceResult(ok=False, errors=["NeoAPI.place_order no longer accepts ['tag']"]))
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)

    def test_no_credentials_not_configured(self):
        self._run()
        self.assertEqual(current_state.state, BrokerState.NOT_CONFIGURED)

    def test_env_credentials_load_before_startup_auto_connect_lifecycle(self):
        cfg = Config(consumer_key='ck', mobile_number='9999999999', ucc='ABC123', totp_secret='SECRET', mpin='123456')
        self._run(cfg=cfg)
        self.assertEqual(current_state.state, BrokerState.DISCONNECTED)
        self.assertTrue(cm_module.credential_manager.has_base_credentials())


    def test_auto_connect_on_startup_is_noop_without_credentials(self):
        import asyncio
        with patch.object(main_module.broker_client_module.broker_client, "connect", new=AsyncMock()) as connect:
            result = asyncio.run(main_module._auto_connect_on_startup())
        self.assertIsNone(result)
        connect.assert_not_awaited()

    def test_auto_connect_on_startup_uses_verified_connect_path(self):
        import asyncio
        cm_module.credential_manager.set(consumer_key='ck', mobile_number='9999999999', ucc='U1', totp_secret='JBSWY3DPEHPK3PXP', mpin='123456')
        cm_module.credential_manager.set_startup_auto_connect(True)
        current_state.transition(BrokerState.DISCONNECTED)
        expected = {"state": "CONNECTED", "last_error": None}
        with patch.object(main_module.broker_client_module.broker_client, "connect", new=AsyncMock(return_value=expected)) as connect:
            result = asyncio.run(main_module._auto_connect_on_startup())
        self.assertEqual(result, expected)
        connect.assert_awaited_once()

    def test_live_mode_with_token_starts(self):
        os.environ['BROKER_SERVICE_TOKEN'] = 'x' * 32
        try:
            self._run(mode='LIVE')
        finally:
            os.environ.pop('BROKER_SERVICE_TOKEN', None)
        self.assertEqual(current_state.state, BrokerState.NOT_CONFIGURED)
if __name__ == '__main__':
    unittest.main()
