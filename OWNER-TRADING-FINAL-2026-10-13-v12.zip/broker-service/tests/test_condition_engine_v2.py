import math
import random
import time
import unittest

from app import strategy_engine as se


def candles(values, volume=1000, highs=None, lows=None):
    out = []
    for i, c in enumerate(values):
        out.append({"candle_at": f"2026-09-{(i // 20) + 1:02d} {9 + (i % 20) // 4:02d}:{(i % 4) * 15:02d}:00", "open": c, "high": (highs[i] if highs else c + 0.5),
                    "low": (lows[i] if lows else c - 0.5), "close": c, "volume": volume(i) if callable(volume) else volume})
    return out


def old_macd(values, fast=12, slow=26, signal=9):             # the original O(n^2) implementation, kept as the oracle
    if len(values) < slow + signal:
        return (None, None, None)
    series = []
    for i in range(slow, len(values) + 1):
        f = se.ema(values[:i], fast); s = se.ema(values[:i], slow)
        if f is not None and s is not None:
            series.append(f - s)
    line = series[-1] if series else None
    sig = se.ema(series, signal) if len(series) >= signal else None
    return line, sig, (line - sig if line is not None and sig is not None else None)


class Operands(unittest.TestCase):
    def test_grammar(self):
        ok = ["close", "ema13", "sma7", "rsi7", "atr10", "adx20", "volume_sma50", "hh20", "ll10", "bb_upper", "bb_lower30", "macd_hist",
              "close[1]", "ema20[3]", "volume[50]", "55", "0.5", "vwap", "rsi14", "volume_sma20", "bb_mid", "price", "previous_close"]
        for name in ok:
            self.assertTrue(se.operand_valid(name), name)
        for name in ["", "ema", "ema0", "ema501", "rsi1", "rsi101", "close[51]", "close5", "foo", "ema20[x]", "ema20[1][2]", "macd12", "hh0", "bb_upper1", None, True, "inf", "nan"]:
            self.assertFalse(se.operand_valid(name), repr(name))

    def test_min_bars(self):
        self.assertEqual(se.operand_min_bars("ema50"), 50)
        self.assertEqual(se.operand_min_bars("ema50[2]"), 52)
        self.assertEqual(se.operand_min_bars("adx14"), 29)
        self.assertEqual(se.operand_min_bars("30"), 0)

    def test_values_match_the_reference_indicators(self):
        rnd = random.Random(3)
        vals = [100.0]
        for _ in range(299):
            vals.append(vals[-1] + rnd.uniform(-1, 1))
        cs = candles(vals, volume=lambda i: 1000 + i)
        r = se.Resolver(cs)
        self.assertAlmostEqual(r.value("ema13"), se.ema(vals, 13)); self.assertAlmostEqual(r.value("sma7"), se.sma(vals, 7))
        self.assertAlmostEqual(r.value("rsi7"), se.rsi(vals, 7)); self.assertAlmostEqual(r.value("atr10"), se.atr(cs, 10))
        self.assertAlmostEqual(r.value("adx14"), se.adx(cs, 14)); self.assertAlmostEqual(r.value("volume_sma50"), se.sma([c["volume"] for c in cs], 50))
        self.assertAlmostEqual(r.value("ema20[3]"), se.ema(vals[:-3], 20)); self.assertEqual(r.value("close[1]"), vals[-2])
        self.assertEqual(r.value("hh10"), max(c["high"] for c in cs[-11:-1])); self.assertEqual(r.value("ll10"), min(c["low"] for c in cs[-11:-1]))
        ind = se.indicators(cs)
        for k in ("ema20", "ema200", "sma100", "rsi14", "atr14", "macd", "macd_signal", "macd_hist", "adx14", "bb_upper", "bb_lower", "bb_mid", "volume_sma20", "vwap"):
            self.assertAlmostEqual(r.value(k), ind[k], msg=k)

    def test_fast_macd_equals_the_old_implementation(self):
        rnd = random.Random(9)
        for n in (30, 35, 36, 80, 250):
            vals = [100.0]
            for _ in range(n - 1):
                vals.append(vals[-1] + rnd.uniform(-2, 2))
            a, b = se.macd(vals), old_macd(vals)
            for x, y in zip(a, b):
                if y is None:
                    self.assertIsNone(x)
                else:
                    self.assertAlmostEqual(x, y, places=9)


class Conditions(unittest.TestCase):
    def test_offsets_and_multiplier(self):
        cs = candles([100, 101, 102, 103, 120], volume=lambda i: 1000 if i < 4 else 2600)
        ok = lambda cond: se.eval_condition(cond, cs)[0]
        self.assertTrue(ok({"left": "close", "operator": ">", "right": "close[1]"}))
        self.assertTrue(ok({"left": "close[1]", "operator": "==", "right": 103}))
        self.assertTrue(ok({"left": "volume", "operator": ">", "right": "volume_sma4", "mult": 1.5}))
        self.assertFalse(ok({"left": "volume", "operator": ">", "right": "volume_sma4", "mult": 3}))
        self.assertTrue(ok({"left": "close", "operator": ">", "right": "hh3"}))                  # breakout above the previous 3 highs

    def test_not_and_unknown_are_three_valued(self):
        cs = candles([100] * 10)
        gt = {"left": "close", "operator": ">", "right": 50}
        self.assertTrue(se.eval_condition(gt, cs)[0]); self.assertFalse(se.eval_condition(dict(gt, **{"not": True}), cs)[0])
        # not enough bars for ema50: NOT(unknown) must NOT turn into a match
        unknown = {"left": "ema50", "operator": ">", "right": 1}
        self.assertFalse(se.eval_condition(unknown, cs)[0])
        self.assertFalse(se.eval_condition(dict(unknown, **{"not": True}), cs)[0])
        grp = {"op": "AND", "not": True, "conditions": [unknown]}
        self.assertFalse(se.eval_group(grp, cs)[0])
        # but a definite False inside NOT does match
        self.assertTrue(se.eval_group({"op": "AND", "not": True, "conditions": [{"left": "close", "operator": "<", "right": 50}]}, cs)[0])

    def test_and_or_with_unknowns(self):
        cs = candles([100] * 10)
        true_c = {"left": "close", "operator": ">", "right": 1}
        false_c = {"left": "close", "operator": "<", "right": 1}
        unk = {"left": "ema50", "operator": ">", "right": 1}
        self.assertFalse(se.eval_group({"op": "AND", "conditions": [true_c, unk]}, cs)[0])
        self.assertFalse(se.eval_group({"op": "AND", "conditions": [false_c, unk]}, cs)[0])
        self.assertTrue(se.eval_group({"op": "OR", "conditions": [true_c, unk]}, cs)[0])
        self.assertFalse(se.eval_group({"op": "OR", "conditions": [false_c, unk]}, cs)[0])
        nested = {"op": "AND", "conditions": [true_c], "groups": [{"op": "OR", "conditions": [false_c, true_c]}]}
        self.assertTrue(se.eval_group(nested, cs)[0])

    def test_crossover_with_offset_and_multiplier(self):
        vals = [100] * 30 + [100 + 3 * k for k in range(1, 12)]
        cs = candles(vals)
        hits = [i for i in range(25, len(cs)) if se.eval_condition({"left": "ema5", "operator": "cross_above", "right": "ema20"}, cs[:i + 1])[0]]
        self.assertTrue(hits and min(hits) >= 30)
        # cross against "2 bars ago" value of itself
        self.assertTrue(se.eval_condition({"left": "close", "operator": "cross_above", "right": "close[3]", "mult": 1.0}, candles([5, 5, 5, 5, 4, 6]))[0] in (True, False))

    def test_details_expose_values_for_why_matched(self):
        cs = candles([100 + i * 0.3 for i in range(80)])
        ok, detail = se.eval_group({"op": "AND", "conditions": [{"left": "ema20", "operator": ">", "right": "ema50"}, {"left": "rsi14", "operator": ">", "right": 60}]}, cs)
        self.assertTrue(ok)
        self.assertIn("ema20", detail["indicators"]); self.assertIn("rsi14", detail["indicators"]); self.assertIn("atr14", detail["indicators"])
        self.assertTrue(all(i["passed"] for i in detail["items"]))
        self.assertIn("ema20 > ema50 => True", detail["items"][0]["reason"])


class Validation(unittest.TestCase):
    base = {"side": "BUY", "timeframe": "15m", "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 80}]},
            "position_sizing": {"quantity": 1}, "risk": {"stop_loss_pct": 1}, "universe": {"instrument_tokens": ["1"]}}

    def errs(self, entry):
        return se.validate_strategy(dict(self.base, entry=entry))

    def test_v2_features_validate(self):
        entry = {"op": "AND", "conditions": [{"left": "ema13", "operator": "cross_above", "right": "ema34"},
                                              {"left": "volume", "operator": ">", "right": "volume_sma20", "mult": 2},
                                              {"left": "close[1]", "operator": "<", "right": "hh20", "not": True}],
                 "groups": [{"op": "OR", "not": True, "conditions": [{"left": "rsi7", "operator": "<", "right": 30}]}]}
        self.assertEqual(self.errs(entry), [])

    def test_bad_v2_inputs_are_rejected(self):
        bad = {"op": "AND", "conditions": [{"left": "ema0", "operator": ">", "right": 1}, {"left": "close[99]", "operator": ">", "right": 1},
                                           {"left": "close", "operator": ">", "right": "foo"}, {"left": "close", "operator": ">", "right": 1, "mult": 0},
                                           {"left": "close", "operator": ">", "right": 1, "not": "yes"}]}
        e = self.errs(bad)
        self.assertEqual(len([x for x in e if "operand" in x]), 3)
        self.assertTrue(any("mult" in x for x in e)); self.assertTrue(any(".not" in x for x in e))

    def test_old_definitions_still_validate_and_evaluate(self):
        old = {"op": "AND", "conditions": [{"left": "ema20", "operator": ">", "right": "ema50"}, {"left": "rsi14", "operator": "<", "right": 45},
                                           {"left": "volume", "operator": ">", "right": "volume_sma20"}, {"left": "close", "operator": ">", "right": "bb_lower"},
                                           {"left": "macd", "operator": ">", "right": "macd_signal"}, {"left": "adx14", "operator": ">", "right": 10}]}
        self.assertEqual(self.errs(old), [])


class Speed(unittest.TestCase):
    def test_scanning_two_thousand_stocks_is_fast(self):
        rnd = random.Random(5)
        vals = [100.0]
        for _ in range(299):
            vals.append(vals[-1] + rnd.uniform(-1, 1))
        cs = candles(vals)
        group = {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"}, {"left": "rsi14", "operator": ">", "right": 60},
                                              {"left": "volume", "operator": ">", "right": "volume_sma20", "mult": 1.5}]}
        t = time.time()
        for _ in range(2000):
            se.eval_group(group, cs)
        took = time.time() - t
        self.assertLess(took, 12.0, f"2000 stocks took {took:.1f}s")          # the old engine needed ~5 ms/stock for the same rule set... of all indicators


if __name__ == "__main__":
    unittest.main()
