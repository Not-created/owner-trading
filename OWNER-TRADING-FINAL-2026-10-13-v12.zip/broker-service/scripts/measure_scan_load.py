#!/usr/bin/env python3
"""Step 0 of the scanner upgrade: measure, do not guess.

Run on the VPS from broker-service/:   python3 scripts/measure_scan_load.py [path/to/owner-trading.db]

1. Counts the NSE cash instruments by series (how many EQ stocks must fit in Kotak's 3000-token feed).
2. Times the scan maths on synthetic bars for that many stocks, using the engine's real code path.
It only READS the database and never touches the broker."""
import os
import random
import sys
import time
import datetime as dt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from app import db, strategy_engine as se  # noqa: E402


def main():
    if len(sys.argv) > 1:
        db.DB_PATH = sys.argv[1]
    try:
        counts = db.count_instruments_by_series()
    except Exception as exc:  # noqa: BLE001
        print(f"Could not read the database ({type(exc).__name__}: {exc}).\nPass its path:  python3 scripts/measure_scan_load.py /path/to/owner-trading.db\nContinuing with a 2000-stock benchmark only.\n")
        counts = {"total": 0, "by_series": {}}
    print(f"NSE cash instruments: {counts['total']}")
    for series, n in list(counts["by_series"].items())[:12]:
        print(f"  {series:<4} {n}")
    eq = counts["by_series"].get("EQ", 0)
    if counts["total"]:
        print(f"\nEQ stocks: {eq}  |  feed limit 3000, reserve 200  ->  {'FITS' if eq <= 2800 else 'DOES NOT FIT: needs the watch-list approach'}")

    n = max(eq, 2000)
    rnd = random.Random(1)
    base = dt.datetime(2026, 9, 1, 9, 15)
    rule = {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"}, {"left": "rsi14", "operator": ">", "right": 60},
                                         {"left": "volume", "operator": ">", "right": "volume_sma20", "mult": 1.5}]}
    series = []
    for _ in range(min(n, 400)):                      # 400 distinct shapes, reused: the maths cost is per stock, not per shape
        p, rows = 100.0, []
        for i in range(120):
            p += rnd.uniform(-1, 1)
            rows.append({"candle_at": (base + dt.timedelta(minutes=5 * i)).strftime("%Y-%m-%d %H:%M:%S"), "open": p, "high": p + .5, "low": p - .5, "close": p, "volume": 1000 + i})
        series.append(rows)
    start = time.time()
    for k in range(n):
        se.eval_group(rule, series[k % len(series)])
    took = time.time() - start
    print(f"\nScan maths for {n} stocks (3 conditions, 120 bars each): {took:.2f} s  ({took / n * 1000:.2f} ms/stock)")
    print("A 5-minute scanner has 300 s per pass: " + ("plenty of headroom." if took < 60 else "TOO SLOW: reduce the universe or the rule set."))
    print("Note: this measures the evaluation only. Candle loading from SQLite and live tick handling are measured by running the service.")


if __name__ == "__main__":
    main()
