# Owner Trading — Final Hotfix: Raised Kotak 424 Empty-Read Path

Date: 2026-10-05

## Production symptom

Risk readiness was still showing:

- `recent_reconciliation = FAIL`
- `reconciliation_sections_complete = FAIL`
- `holdings_failed`
- Kotak endpoint: `/portfolio/v1/holdings`
- `stCode=424`
- `errMsg=No holdings found for this client V883E`
- `session=NOT_AUTH_FAILURE`

The previous response-normalization code handled a **returned dictionary** containing the endpoint-specific empty-account response, but it did not handle the same broker response when the installed Kotak Neo REST layer raised `ApiException` for HTTP >= 400.

## Root cause

The official/vendored SDK REST layer can raise:

```text
ApiException(status=424, body={
  "stCode": 424,
  "errMsg": "No holdings found for this client V883E",
  "stat": "Not_Ok"
})
```

when `raise_on_error` is enabled. `sdk_adapter.holdings()` previously called the SDK directly without a `try/except`, so `_empty_read_response()` never saw the broker body. The exception then surfaced through the generic classifier as a rejection, which produced `NOT_AUTH_FAILURE` and a reconciliation discrepancy.

## Fix

`broker-service/app/sdk_adapter.py` now has:

1. `_exception_body_as_response()` — extracts and JSON-decodes an SDK exception body while preserving HTTP status.
2. `_classify_read_exception()` — applies the exact same endpoint-specific empty-read rules to raised SDK exceptions before generic classification.
3. `order_report()`, `trade_report()`, `positions()`, and `holdings()` now catch SDK/API/transport exceptions and route them through the new read-exception classifier.
4. Generic 424 exceptions remain blocking.
5. Exact `No <section> found for this client ...` remains an empty collection only for the four read-only collection endpoints.
6. Official 5203 `No Data` behavior remains unchanged and remains endpoint-scoped.
7. No state-changing order path is changed by this fix.

## Safety contract after fix

Accepted empty read cases:

- exact endpoint-specific empty-account 424 response
- official 5203 / `No Data` / `data not found` / `Not_Ok`

Still blocking:

- generic 424 / dependency failure
- 403 / invalid session
- 429 / rate limit
- 500 / 502 / 503 / 504
- timeout / connection error
- malformed JSON/body
- wrong 5203 shape
- unexpected collection shape

## Regression coverage

Added tests for:

- raised HTTP 424 empty order response
- raised HTTP 424 empty trade response
- raised HTTP 424 empty position response
- raised HTTP 424 empty holdings response
- raised generic 424 remains rejected
- raised 424 empty holdings completes full reconciliation

## Verification

Broker service:

`343 passed, 3 skipped`

Backend Node tests:

`26 passed, 6 skipped`

Python compile: PASS

deploy.sh syntax: PASS

SQLite fresh migration/idempotency tests: PASS

## Expected production result

After deploying this release and pressing **Reconcile with broker now**:

```text
Orders       PASS
Trades       PASS
Positions    PASS
Holdings     PASS — 0
Funds        PASS

recent_reconciliation             PASS
reconciliation_sections_complete  PASS

Ready: yes
Armed: no
LIVE orders can be sent: no
```

Only after typing the exact confirmation `ARM LIVE TRADING` and satisfying all remaining gates can global LIVE ARM become active.

No readiness or reconciliation gate was bypassed.
