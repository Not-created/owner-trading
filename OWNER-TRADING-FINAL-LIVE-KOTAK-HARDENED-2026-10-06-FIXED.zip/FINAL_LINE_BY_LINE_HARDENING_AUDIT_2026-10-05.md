# OWNER TRADING — FINAL LINE-BY-LINE HARDENING AUDIT
## 2026-10-05

This release was re-audited from the supplied `OWNER-TRADING-FINAL-LIVE-SCANNER-RISK-HARDENED-KOTAK-5203-FIXED-2026-10-05.zip` rather than starting a new project.

## 1. Root cause fixed

Kotak Neo documented `stCode=5203`, `errMsg=No Data`, `desc=data not found`, `stat=Not_Ok` is now normalized only for the four read-only collection endpoints:
- order_report
- trade_report
- positions
- holdings

HTTP failure status, wrong message/shape, auth failure, timeout/transport failure, or any unrelated error remains blocking.

## 2. New hidden cross-call / response-contract hardening

### A. Malformed successful broker bodies no longer become empty data
A response such as `{stat: Ok, stCode: 200}` without a documented collection/data container used to reach `rows_of()` and silently become `[]`. That is unsafe for reconciliation.

Now collection reads require a real list/nested data list. Malformed responses become `UNKNOWN / MALFORMED_RESPONSE` and block reconciliation.

### B. Malformed limits response no longer passes login/reconciliation
`limits()` now requires the documented flat limits fields before being treated as successful. A malformed OK body cannot manufacture zero/empty funds data.

### C. Strategy-scoped readiness
LIVE execution readiness for a specific strategy now scopes strategy subscription and scanner checks to that strategy. An unrelated armed strategy or unrelated scanner cannot block another strategy's entry.

Global Risk readiness still audits all armed strategies.

### D. Multiple LIVE strategies are independent
Arming a new strategy previously released the feed owners of every other armed strategy. That could silently break another LIVE strategy while leaving its DB `is_live_armed=1`.

That cross-strategy release logic has been removed. Shared SFeed ownership remains reference-counted.

### E. Scanner deactivation is now an immediate boundary
Deactivating a scanner now immediately deactivates its active candidates and releases only that scanner's strategy feed owners. It no longer waits for the background cycle.

### F. Restart subscription recovery is failure-isolated
One bad candidate/subscription during restart recovery no longer aborts recovery of all other strategies. Failed candidates are marked with an error and other strategy subscriptions continue restoring.

### G. LIVE orders require an exact instrument token
Every LIVE order now requires `instrument_token`. This prevents an order from bypassing exact-instrument market-feed freshness and Kotak margin verification.

### H. Order input integer parsing hardened
Malformed `signal_id` / `algo_position_id` values now return validation errors instead of escaping as server 500 errors.

### I. Concurrent LIVE order race closed
A process-wide submission lock serializes LIVE order creation/risk-check/broker-submission. This closes the TOCTOU window where two simultaneous entries could both pass exposure/position limits.

### J. Pending entry exposure included in risk checks
Accepted but not fully filled BUY entries are included in total/strategy/instrument exposure calculations. A stale broker position snapshot can no longer make a pending order invisible to exposure limits.

### K. Modify-order risk/freshness gate hardened
Order modification now:
- rechecks risk policy (without counting the modification as a new daily order),
- passes exact instrument context into the final LIVE gate,
- requires the same broker/reconciliation/feed safety boundary before the broker modify call.

## 3. Safety behavior deliberately preserved

- Global LIVE ARM still requires complete readiness and exact `ARM LIVE TRADING` confirmation.
- Strategy ARM remains separate from global LIVE ARM.
- Scanner match never directly sends an order.
- Candidate subscription never directly sends an order.
- Entry still requires strategy authorization, risk checks, final readiness, fresh market data, broker session, reconciliation and margin/funds verification.
- Broker timeout/unknown outcome is never blindly retried.
- Existing-position exits remain exposure-reducing and are not blocked by new-entry daily-loss/exposure limits.
- 403/session failures remain AUTH/blocking.
- 429 remains rate-limit/rejection.
- 500+/transport failures remain blocking.
- Official vendored Kotak SDK is not replaced or modified.

## 4. Regression validation

Broker service:
- **331 passed, 3 skipped**

Backend Node:
- **26 passed, 6 skipped**

Targeted cross-layer/safety suite:
- **103 passed**

Additional validation:
- Python `compileall`: PASS
- Shell syntax (`deploy.sh`, `set-mode.sh`, `verify-deployment.sh`): PASS
- Nginx HTTP/HTTPS generated-context syntax: PASS
- Fresh SQLite migrations + idempotency: PASS
- SDK conformance/integrity tests: PASS
- Frontend/API/Express/Python route contract tests: PASS

## 5. Frontend build limitation

A fresh `npm install --no-audit --no-fund` in the isolated audit environment timed out because the npm registry/dependency download did not complete. Therefore a fresh Vite production build is **not falsely reported as PASS** here.

The source itself was not changed in this hardening pass, and all available cross-layer/static contract tests passed. The deployment script still fails closed if `npm install` or `npm run build` fails on the VPS.

## 6. Release rule

This ZIP is intended to replace the previous 5203-fixed ZIP. No further patch ZIP is required for the fixes listed above.
