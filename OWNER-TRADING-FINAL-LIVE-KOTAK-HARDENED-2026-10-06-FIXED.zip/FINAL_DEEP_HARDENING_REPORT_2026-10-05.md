# Owner Trading — Deep Hardening / LIVE ARM / Kotak Integration Final Audit
Date: 2026-10-05

## Executive result

This release was rebuilt from the uploaded `OWNER-TRADING-FINAL-LIVE-SCANNER-RISK-HARDENED-KOTAK-COMPLETE-HARDENED-2026-10-05.zip`.

The audit did not assume the previous ZIP was correct. The uploaded official `kotak-neo-python` source was also inspected and compared against the vendored SDK.

The main production symptoms from the screenshots were traced to two independent application problems:

1. Reconciliation could remain blocked by a persisted/stale failed reconciliation result even when the broker could now return an empty portfolio safely.
2. Strategy LIVE arming could be blocked by an empty/stale Scrip Master cache even though the strategy's tokens could be resolved by a fresh official Scrip Master download.

Additional cross-layer request/time-out and backtest timeframe mismatches were hardened.

## 1. Kotak response classification

### 5203

The official Kotak SDK documentation defines:

`stCode=5203, errMsg="No Data", desc="data not found", stat="Not_Ok"`

as the No Data response.

The adapter continues to normalize this only for the four read-only collection endpoints:

- order_report
- trade_report
- positions
- holdings

It does NOT make `classify()` globally accept 5203.

### 424

Important correction: Kotak's general documentation treats HTTP 424 as a dependency failure. Therefore the project must not globally treat 424 as success.

The final adapter now accepts 424 as empty only when the endpoint-specific message is narrowly matched, such as:

`No holdings found for this client V883E`

Generic 424 messages such as:

`Portfolio service unavailable`

remain blocking failures.

The matching was tightened from substring matching to anchored endpoint-specific patterns to avoid false empty-account classification.

## 2. Reconciliation stale-state / ARM deadlock

### Previous flow

Risk page -> readiness -> old failed reconciliation -> `Ready: no` -> frontend disabled ARM -> no explicit action could force a fresh reconciliation from the ARM control.

### Final flow

Owner types the exact confirmation:

`ARM LIVE TRADING`

The ARM endpoint:

1. evaluates all readiness gates;
2. if not ready and the broker is connected, performs one fresh READ-ONLY reconciliation;
3. evaluates readiness again;
4. arms only if the second evaluation passes.

No risk gate is bypassed.

Real broker errors, session failures, stale feeds, unknown orders, daily-loss halt, funds/margin failures, etc. still block LIVE.

The frontend button is now disabled only until the exact confirmation text is entered. When readiness is currently false it displays:

`Reconcile & Arm LIVE trading`

This makes the control actionable without making the backend permissive.

## 3. Strategy LIVE ARM reconciliation

The same stale-reconciliation repair was added to strategy-specific ARM.

A strategy ARM request may perform one fresh read-only reconciliation before the final strategy-specific readiness check.

It still requires:

- valid strategy
- entry conditions
- explicit universe or active scanner
- valid scanner IDs
- protective stop
- position sizing
- authoritative Scrip Master tokens
- feed ownership
- final readiness
- all existing risk gates

## 4. Scrip Master / metadata architecture

A major separation was added:

`_sync_nse_cash_metadata()`

is now metadata-only.

It:

- calls official Kotak Scrip Master;
- resolves the broker-returned NSE cash CSV URL;
- downloads the CSV;
- validates required `pSymbol` / `pTrdSymbol` columns;
- parses rows;
- performs one bulk SQLite import;
- never creates SFeed subscriptions.

Subscriptions are a separate explicit operation.

This prevents a metadata refresh from accidentally becoming a live-market subscription.

### Strategy ARM

If a scanner-less strategy references tokens that are missing from the local metadata table, the strategy ARM action now performs one metadata-only refresh before rejecting the strategy.

After refresh, every token is checked again.

Unknown tokens still block.

No token is guessed.

## 5. Official metadata API session dependency

The official Kotak SDK documents `scrip_master()` and `search_scrip()` as consumer-key-only APIs; completed TOTP/MPIN trade-session authentication is not required.

The broker client now respects that contract:

- if an authenticated session exists, it reuses it;
- otherwise, `scrip_master` / `search_scrip` can use an ephemeral consumer-key-only SDK;
- order/portfolio/trading APIs still require the authenticated trade session.

This prevents an expired trade session from unnecessarily blocking instrument discovery.

## 6. Scrip metadata UI/runtime count

The Algo Trading runtime counter previously relied only on a runtime counter that can be reset to zero after process restart.

It now also reads the authoritative NSE instrument count from SQLite.

Therefore:

`Scrip metadata = 0`

cannot be shown merely because the process restarted while the actual metadata table is populated.

## 7. Cross-layer timeout fix

Strategy ARM can now perform:

- Scrip Master metadata refresh;
- broker reconciliation;
- final readiness.

The Express -> Python broker-service call previously used the normal short timeout.

It now uses the same bounded slow-call timeout as reconciliation/backtest.

This prevents:

Python continuing a valid ARM operation
while
Express/browser prematurely reports a timeout.

## 8. Backtest timeframe mismatch

The screenshot showed a strategy definition using `15m` while the historical dataset form was using `5m`.

The old backend accepted that combination and could silently evaluate 15m strategy semantics on 5m candles.

The final release rejects a mismatch:

`strategy timeframe != historical dataset timeframe`

The UI also reports the mismatch before sending the request.

No implicit resampling is performed.

This prevents misleading zero-trade / incorrect-indicator backtests.

## 9. Safety preserved

No LIVE safety gate was bypassed.

The final order path still requires the existing architecture:

Strategy
-> validation
-> explicit strategy ARM
-> scanner/universe authorization
-> candidate/subscription
-> fresh candle/tick
-> signal
-> risk gate
-> final readiness
-> broker session
-> reconciliation
-> fresh LTP
-> funds/margin
-> duplicate/idempotency protection
-> Kotak order submission
-> fill reconciliation
-> position
-> protective exit

Unknown broker order outcomes are not blindly retried.

## 10. Verification

### Broker service

`335 passed, 3 skipped`

The suite includes:

- 5203 No Data for all four collection endpoints
- 424 exact empty-account response
- 424 generic dependency failure
- malformed collection response
- malformed limits response
- HTTP failure combined with 5203
- stale reconciliation refresh before global ARM
- stale reconciliation refresh before strategy ARM
- metadata-only Scrip Master refresh
- metadata API operation without a trade session
- strategy scanner validation
- subscription isolation
- existing order/risk/reconciliation tests

### Static validation

- Python compileall: PASS
- `bash -n deploy.sh`: PASS
- Node JavaScript syntax checks: PASS
- vendored SDK source vs uploaded official SDK source: byte-identical
- generated cache files removed from final ZIP

### Frontend production build

A fresh Vite production build was not claimed as PASS because this isolated environment does not contain `node_modules`, and previous npm registry installation attempts timed out.

The final ZIP therefore does NOT falsely claim a fresh Vite build.

## 11. Official-source basis

Official Kotak Neo Python SDK:

https://github.com/Kotak-Neo/kotak-neo-python

Official API function documentation:

https://github.com/Kotak-Neo/kotak-neo-python/blob/main/docs/functions/README.md

Scrip Master:

https://github.com/Kotak-Neo/kotak-neo-python/blob/main/docs/functions/market_data/scrip_master.md

Holdings:

https://github.com/Kotak-Neo/kotak-neo-python/blob/main/docs/functions/portfolio/holdings.md

The vendored SDK was compared against the uploaded official SDK source and was not replaced or modified by this hardening pass.

## Final decision

This ZIP is the final hardened candidate from this audit.

The correct deployment procedure is to replace the production application with this release and then run a fresh broker reconciliation before attempting LIVE ARM.

The system must never be forced into LIVE merely because the ARM button is desired. The ARM action now itself performs the required fresh read-only reconciliation and still refuses to arm if any genuine safety gate fails.
