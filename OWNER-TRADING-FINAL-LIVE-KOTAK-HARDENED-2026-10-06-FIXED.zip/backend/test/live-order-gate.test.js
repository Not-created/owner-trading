const test = require("node:test");
const assert = require("node:assert");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

// This test mutates brokerState, which persists through the backend SQLite layer.
// Give it an isolated fresh database and apply the real production migrations so
// the test cannot depend on test-file execution order or touch a developer/VPS DB.
const dbPath = path.join(os.tmpdir(), `owner-trading-live-order-gate-${process.pid}.db`);
for (const suffix of ["", "-wal", "-shm"]) {
  try { fs.unlinkSync(`${dbPath}${suffix}`); } catch (_) {}
}
process.env.DB_PATH = dbPath;


test("emergency stop blocks new exposure but permits explicitly classified EXIT orders", () => {
  process.env.NODE_ENV = "production";
  process.env.SESSION_SECRET = "s".repeat(48);
  process.env.BROKER_SERVICE_TOKEN = "t".repeat(32);
  process.env.BROKER_SERVICE_URL = "http://127.0.0.1:8800";
  process.env.TRADING_MODE = "LIVE";

  require("../src/db/migrate").run();
  const brokerState = require("../src/services/brokerState");
  const { requireLiveTradingAllowed } = require("../src/middleware/requireLiveTradingAllowed");

  brokerState.setEmergencyStop(true, "test");
  brokerState.setBrokerConnectionState(brokerState.BROKER_STATES.CONNECTED, null);

  const run = (body) => new Promise((resolve) => {
    const req = { body };
    const res = {
      statusCode: 200,
      body: null,
      status(code) { this.statusCode = code; return this; },
      json(payload) { this.body = payload; resolve({ status: this.statusCode, body: payload }); },
    };
    requireLiveTradingAllowed(req, res, () => resolve({ status: 200 }));
  });

  return Promise.all([
    run({ order_role: "ENTRY" }).then((r) => assert.strictEqual(r.status, 423)),
    run({ order_role: "EXIT" }).then((r) => assert.strictEqual(r.status, 200)),
  ]).finally(() => brokerState.setEmergencyStop(false));
});
