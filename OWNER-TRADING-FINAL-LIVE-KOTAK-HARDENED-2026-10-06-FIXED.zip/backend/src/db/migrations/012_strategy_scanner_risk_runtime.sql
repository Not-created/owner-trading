-- Phase 14: strategy-specific scanner candidates + production risk runtime.
-- No existing rows are deleted. All new fields are nullable/defaulted so the
-- existing LIVE execution chain remains backward compatible while the new
-- scanner/candidate gates become authoritative for new strategy versions.

CREATE TABLE IF NOT EXISTS strategy_candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  strategy_version_id INTEGER NOT NULL REFERENCES strategy_versions(id),
  scanner_id INTEGER NOT NULL REFERENCES scanners(id),
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  trading_symbol TEXT,
  timeframe TEXT NOT NULL,
  matched_price REAL,
  conditions_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  first_matched_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_matched_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT,
  subscribed_at TEXT,
  last_error TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(strategy_version_id, scanner_id, exchange_segment, instrument_token)
);
CREATE INDEX IF NOT EXISTS idx_strategy_candidates_active
  ON strategy_candidates(strategy_version_id, status, expires_at);
CREATE INDEX IF NOT EXISTS idx_strategy_candidates_instrument
  ON strategy_candidates(exchange_segment, instrument_token, status);

-- Persist a latched daily-loss halt. It automatically resets when the IST
-- trading date changes; it never clears merely because P&L temporarily recovers.
CREATE TABLE IF NOT EXISTS risk_runtime_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  trading_date TEXT,
  daily_loss_halted INTEGER NOT NULL DEFAULT 0,
  halt_reason TEXT,
  halted_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO risk_runtime_state(id) VALUES (1);

ALTER TABLE risk_settings ADD COLUMN max_total_exposure REAL;
ALTER TABLE risk_settings ADD COLUMN max_strategy_exposure REAL;
ALTER TABLE risk_settings ADD COLUMN max_strategy_positions INTEGER;
ALTER TABLE risk_settings ADD COLUMN max_strategy_daily_loss REAL;
ALTER TABLE risk_settings ADD COLUMN max_strategy_capital REAL;
ALTER TABLE risk_settings ADD COLUMN max_instrument_exposure REAL;

ALTER TABLE algo_positions ADD COLUMN realized_pnl REAL NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_algo_positions_strategy_closed
  ON algo_positions(strategy_version_id, status, closed_at);

CREATE INDEX IF NOT EXISTS idx_strategy_versions_scanner_definition
  ON strategy_versions(is_live_armed, updated_at DESC);
