-- Phase 15: per-strategy latched daily-loss runtime state.
-- Existing rows/data are preserved; one state row is created per strategy version
-- only when the runtime first evaluates that strategy.
CREATE TABLE IF NOT EXISTS strategy_risk_runtime_state (
  strategy_version_id INTEGER PRIMARY KEY REFERENCES strategy_versions(id),
  trading_date TEXT,
  daily_loss_halted INTEGER NOT NULL DEFAULT 0,
  halt_reason TEXT,
  halted_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_strategy_risk_runtime_halt
  ON strategy_risk_runtime_state(daily_loss_halted, trading_date);
