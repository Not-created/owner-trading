-- Phase 1-5 runtime safety: persistent web sessions and crash-recoverable
-- forming candle state. No existing production rows are deleted.

CREATE TABLE IF NOT EXISTS web_sessions (
  sid TEXT PRIMARY KEY,
  session_json TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_web_sessions_expiry ON web_sessions(expires_at);

CREATE TABLE IF NOT EXISTS candle_runtime_state (
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  candle_at TEXT NOT NULL,
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume INTEGER NOT NULL DEFAULT 0,
  trading_symbol TEXT,
  cumulative_volume INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY(exchange_segment, instrument_token, timeframe)
);
