const session = require("express-session");
const { getDb } = require("../db/client");

/**
 * SQLite-backed express-session store for the single-owner production app.
 * The browser still holds only the signed session id; session data survives a
 * backend restart, while expired rows are removed opportunistically.
 */
class SQLiteSessionStore extends session.Store {
  constructor(options = {}) {
    super(options);
    this.db = options.db || getDb();
    this.ttlMs = Number(options.ttlMs || 43200000);
    this._cleanup();
  }

  _cleanup() {
    try {
      this.db.prepare("DELETE FROM web_sessions WHERE expires_at <= ?").run(Date.now());
    } catch (_) {
      // Migrations run before the store is constructed. Cleanup is best effort.
    }
  }

  get(sid, callback) {
    try {
      const row = this.db.prepare(
        "SELECT session_json, expires_at FROM web_sessions WHERE sid = ? LIMIT 1"
      ).get(String(sid));
      if (!row) return callback(null, null);
      if (Number(row.expires_at) <= Date.now()) {
        this.destroy(sid, () => callback(null, null));
        return;
      }
      callback(null, JSON.parse(row.session_json));
    } catch (err) {
      callback(err);
    }
  }

  set(sid, sess, callback) {
    try {
      const maxAge = Number(sess?.cookie?.maxAge || this.ttlMs);
      const expiresAt = Date.now() + Math.max(1000, maxAge);
      this.db.prepare(
        `INSERT INTO web_sessions(sid, session_json, expires_at, updated_at)
         VALUES (?, ?, ?, datetime('now'))
         ON CONFLICT(sid) DO UPDATE SET
           session_json=excluded.session_json,
           expires_at=excluded.expires_at,
           updated_at=datetime('now')`
      ).run(String(sid), JSON.stringify(sess), expiresAt);
      callback?.(null);
    } catch (err) {
      callback?.(err);
    }
  }

  touch(sid, sess, callback) {
    try {
      const maxAge = Number(sess?.cookie?.maxAge || this.ttlMs);
      const expiresAt = Date.now() + Math.max(1000, maxAge);
      this.db.prepare(
        "UPDATE web_sessions SET expires_at = ?, updated_at = datetime('now') WHERE sid = ?"
      ).run(expiresAt, String(sid));
      callback?.(null);
    } catch (err) {
      callback?.(err);
    }
  }

  destroy(sid, callback) {
    try {
      this.db.prepare("DELETE FROM web_sessions WHERE sid = ?").run(String(sid));
      callback?.(null);
    } catch (err) {
      callback?.(err);
    }
  }

  clear(callback) {
    try {
      this.db.exec("DELETE FROM web_sessions");
      callback?.(null);
    } catch (err) {
      callback?.(err);
    }
  }

  length(callback) {
    try {
      this._cleanup();
      const row = this.db.prepare("SELECT COUNT(*) AS n FROM web_sessions").get();
      callback?.(null, Number(row.n));
    } catch (err) {
      callback?.(err);
    }
  }
}

module.exports = SQLiteSessionStore;
