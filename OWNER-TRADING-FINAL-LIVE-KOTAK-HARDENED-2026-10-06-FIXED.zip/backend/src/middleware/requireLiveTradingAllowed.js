const config = require("../config");
const { getBrokerConnectionState, isEmergencyStopActive, BROKER_STATES } = require("../services/brokerState");

// Defense-in-depth gate for every executable LIVE order request.
function requireLiveTradingAllowed(req, res, next) {
  if (config.tradingMode !== "LIVE") return res.status(403).json({ error: "LIVE trading is unavailable." });

  // Emergency stop blocks new exposure, but an already-open LIVE position
  // must remain flattenable. The Python broker service independently verifies
  // the EXIT role and keeps session/reconciliation/feed gates in force.
  const controlledExit = String(req.body?.order_role || "").toUpperCase() === "EXIT";
  if (isEmergencyStopActive() && !controlledExit) {
    return res.status(423).json({ error: "Emergency stop is active. New LIVE exposure is blocked." });
  }

  const { state } = getBrokerConnectionState();
  if (state !== BROKER_STATES.CONNECTED) return res.status(409).json({ error: `Broker is not connected (state: ${state}). LIVE orders are blocked.` });
  return next();
}

module.exports = { requireLiveTradingAllowed };
