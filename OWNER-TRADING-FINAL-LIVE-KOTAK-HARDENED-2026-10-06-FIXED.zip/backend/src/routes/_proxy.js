// Shared response helper: relays a broker-service result to the browser without
// ever masking a failure as success.
function relay(res, result) {
  if (result.networkError) {
    return res.status(502).json({ error: "BROKER_SERVICE_UNREACHABLE", message: `broker service unreachable: ${result.networkError}` });
  }
  // A 401 from the Python/Kotak side is downstream broker/session state, not
  // the owner's Express web session. Never expose that as a browser-session
  // 401 because the frontend would incorrectly send the owner to PasswordGate.
  if (result.status === 401) {
    return res.status(502).json({
      error: result.body?.error || "BROKER_DOWNSTREAM_AUTH_ERROR",
      code: result.body?.code || "BROKER_DOWNSTREAM_AUTH_ERROR",
      message: result.body?.message || result.body?.error || "Broker authentication/session request was rejected.",
      downstream_status: 401,
    });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
}

function wrap(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = { relay, wrap };
