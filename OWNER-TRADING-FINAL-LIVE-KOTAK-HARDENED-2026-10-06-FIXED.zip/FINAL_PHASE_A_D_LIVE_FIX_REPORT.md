# Owner Trading — Phase A–D LIVE Fix & Release Report — 2026-10-04

## Scope

This release is a targeted hardening pass over the existing LIVE-only Owner Trading architecture. No new broker, strategy, or trading feature was introduced.

Architecture remains:

React/Vite → Node/Express → SQLite → Python broker-service → official Kotak Neo SDK 3.0.7 → Kotak

## Phase A — Runtime readiness and LIVE feed startup

- Preserved the fail-closed LIVE readiness gates: SDK/version/integrity, credentials, broker session, order feed, market feed, risk limits, emergency stop, unknown/pending orders, clean reconciliation, and internal service token.
- Fixed the initial WebSocket startup race: a successful Kotak REST login now starts the market and order-feed supervisors and waits briefly for their initial connection before reporting the connection lifecycle as fully initialized.
- The background supervisors still continue reconnecting if either feed cannot connect within the startup wait.
- Persisted LIVE strategy subscriptions remain restored from the database after service restart.
- Existing disarm subscription cleanup remains intact.
- MKT BUY margin verification remains fixed: a fresh LTP is used only as the margin reference; the actual broker order remains MKT.

## Phase B — Targeted execution/backtest fixes

- Extended the Express → broker-service slow-call budget from 60s to 300s for bounded historical/backtest/reconciliation operations.
- Extended Nginx `/api/` proxy read timeout to 330s so a valid long backtest cannot be converted into a proxy 502/504 while the backend is still processing it.
- Historical chunking, timestamp validation, candle caching and the backtest cost/equity/risk calculations remain unchanged.
- Backtest remains strictly historical-only and cannot enter the LIVE order path.

## Phase C — LIVE execution integrity

- Official Kotak Neo SDK vendor tree remains byte-identical to the supplied official SDK source for the executable `neo_api_client` package.
- LIVE orders remain blocked unless the complete defense-in-depth gates pass and the owner has explicitly armed LIVE trading.
- Unknown broker submission outcomes remain `PENDING_RECONCILE`; they are never blindly retried.
- Entry/exit execution-chain metadata remains enforced.

## Phase D — Deployment and transport validation

- `deploy.sh` remains the one-click deployment entry point and is executable in the release archive.
- Non-root invocation self-elevates through sudo; no manual chmod/configuration step is required for the packaged script.
- Deployment provisions systemd, Nginx, SQLite migrations, Python venv, Node dependencies, frontend build, internal service token and encrypted credential storage automatically.
- HTTP and HTTPS remain supported simultaneously; HTTP is not forcibly redirected to HTTPS.
- `SESSION_COOKIE_SECURE=auto` makes HTTP sessions non-Secure and HTTPS sessions Secure while retaining HttpOnly/SameSite=Lax.
- IP HTTPS uses the automatic bootstrap certificate path; DNS HTTPS uses the existing certificate/Certbot path.
- Deployment remains fail-closed if dependency installation, tests, frontend build, systemd configuration, Nginx validation or health checks fail.

## Validation

- Broker-service pytest suite: **305 passed, 3 skipped, 0 failed**.
- Python compileall: PASS.
- Backend JavaScript syntax checks: PASS.
- Shell syntax checks: PASS.
- Official Kotak SDK vendor integrity/conformance tests: PASS within the broker-service suite.
- Frontend fresh npm install/Vite build could not be executed in the packaging sandbox because registry/network resolution did not complete. The production deploy script installs dependencies and refuses to continue if the real VPS build fails.
- No real Kotak credentials were included and no real-money order was submitted during packaging validation.

## Release rule

This package does not remove or bypass LIVE safety gates. The software is LIVE-only, but actual order submission still requires a healthy authenticated Kotak session, clean reconciliation/feed state, configured risk limits and explicit owner LIVE arming.
