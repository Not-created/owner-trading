"""Shared-database writer for the broker service.

The Node backend OWNS the SQLite schema (see
backend/src/db/migrations/001_init.sql) and runs all migrations -- this
module only ever INSERTs into tables that already exist, using the same
file (DB_PATH env var, matching backend/src/config/index.js's default of
backend/data/owner-trading.db). SQLite's WAL mode (enabled by the Node side
in db/client.js) safely supports this: one writer at a time, with SQLite
handling the locking -- both processes retry-on-busy rather than corrupt
data.

Every insert here is written to be idempotent against the UNIQUE
constraints already in the schema (order_events.(event_source,
broker_event_id), trades.broker_trade_id) using INSERT OR IGNORE, so a
duplicated WebSocket message or a retried REST reconciliation can never
double-record the same event -- this is the "duplicate-event protection /
idempotency" requirement implemented concretely, not just described.

Order/position/holding/funds persistence and audit logging (Phase 1C) are
called from order_service.py, reconciliation.py, and server.py's new
routes -- see those modules for how each function here is actually used.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
from contextlib import contextmanager

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "data", "owner-trading.db"
)
DB_PATH = os.environ.get("DB_PATH", DEFAULT_DB_PATH)

logger = logging.getLogger("owner_trading.db")


@contextmanager
def _connection():
    # The Node backend owns the database journal mode. The broker service is a
    # second process against the same SQLite file, so changing journal_mode on
    # every connection can itself require a database-wide lock. Keep the Python
    # side read/write connections in the already-established WAL mode and wait
    # for short-lived cross-process writer contention instead of failing fast.
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA busy_timeout = 30000;")
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def record_order_event(
    *,
    event_source: str,
    broker_event_id: str | None,
    raw_payload: dict,
    order_id: int | None = None,
    broker_order_id: str | None = None,
) -> bool:
    """Idempotent insert into order_events. Returns True if a new row was
    written, False if this exact (event_source, broker_event_id) was
    already recorded (duplicate, correctly ignored).
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO order_events
               (order_id, broker_order_id, event_source, broker_event_id, raw_payload)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, event_source, broker_event_id, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def record_trade(
    *, broker_trade_id: str, order_id: int | None, broker_order_id: str | None,
    fill_quantity: int, fill_price: float, fill_time: str | None, raw_payload: dict,
    mode: str = "LIVE", trading_symbol: str | None = None, exchange_segment: str | None = None,
    transaction_type: str | None = None, product: str | None = None, multiplier: float | None = None,
) -> bool:
    """Idempotent insert keyed on broker_trade_id (each partial fill has its
    own id; re-delivery is a no-op)."""
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO trades
               (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, raw_payload,
                mode, trading_symbol, exchange_segment, transaction_type, product, multiplier)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, json.dumps(raw_payload),
             mode, trading_symbol, exchange_segment, transaction_type, product, multiplier),
        )
        return cur.rowcount == 1


def list_trades(*, mode: str | None = None, limit: int = 1000) -> list[dict]:
    limit = max(1, min(limit, 5000))
    sql = ("SELECT id, order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, "
           "mode, trading_symbol, exchange_segment, transaction_type, product, multiplier FROM trades")
    params: list = []
    sql += " WHERE mode = 'LIVE'"
    if mode and mode != "LIVE":
        return []
    sql += " ORDER BY id ASC LIMIT ?"
    keys = ["id", "order_id", "broker_order_id", "broker_trade_id", "fill_quantity", "fill_price", "fill_time",
            "mode", "trading_symbol", "exchange_segment", "transaction_type", "product", "multiplier"]
    with _connection() as conn:
        return [dict(zip(keys, r)) for r in conn.execute(sql, (*params, limit)).fetchall()]


# ---- risk settings / live arming (singleton row id=1, migration 003) ----
_RISK_KEYS = (
    "max_order_quantity", "max_order_value", "max_orders_per_day",
    "max_daily_loss", "max_open_positions", "max_total_exposure",
    "max_strategy_exposure", "max_strategy_positions",
    "max_strategy_daily_loss", "max_strategy_capital",
    "max_instrument_exposure",
)


def get_risk_settings() -> dict:
    with _connection() as conn:
        row = conn.execute(
            "SELECT max_order_quantity, max_order_value, max_orders_per_day, max_daily_loss, max_open_positions, "
            "max_total_exposure, max_strategy_exposure, max_strategy_positions, "
            "max_strategy_daily_loss, max_strategy_capital, max_instrument_exposure, "
            "live_trading_armed, armed_at FROM risk_settings WHERE id = 1"
        ).fetchone()
    if not row:
        return {k: None for k in _RISK_KEYS} | {"live_trading_armed": False, "armed_at": None}
    d = dict(zip(_RISK_KEYS, row[:len(_RISK_KEYS)]))
    d["live_trading_armed"] = bool(row[len(_RISK_KEYS)])
    d["armed_at"] = row[len(_RISK_KEYS) + 1]
    return d


def set_risk_settings(values: dict) -> dict:
    """Update any supported risk limit; None/absent clears that limit."""
    with _connection() as conn:
        for k in _RISK_KEYS:
            if k in values:
                conn.execute(f"UPDATE risk_settings SET {k} = ?, updated_at = datetime('now') WHERE id = 1", (values[k],))
    return get_risk_settings()


def is_live_armed() -> bool:
    with _connection() as conn:
        row = conn.execute("SELECT live_trading_armed FROM risk_settings WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


def set_live_armed(armed: bool) -> None:
    with _connection() as conn:
        conn.execute(
            "UPDATE risk_settings SET live_trading_armed = ?, armed_at = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END, "
            "updated_at = datetime('now') WHERE id = 1", (1 if armed else 0, 1 if armed else 0),
        )


def _ist_date() -> str:
    from zoneinfo import ZoneInfo
    return __import__("datetime").datetime.now(ZoneInfo("Asia/Kolkata")).date().isoformat()


def refresh_daily_loss_halt(*, current_pnl: float | None, limit: float | None) -> dict:
    """Latch the global daily-loss halt for the current IST trading date.

    The halt is intentionally sticky until the next IST date. This prevents a
    temporary P&L recovery from silently re-enabling new exposure after a loss
    limit has already been breached.
    """
    today = _ist_date()
    with _connection() as conn:
        row = conn.execute("SELECT trading_date,daily_loss_halted,halt_reason,halted_at FROM risk_runtime_state WHERE id=1").fetchone()
        if not row or row[0] != today:
            conn.execute("UPDATE risk_runtime_state SET trading_date=?,daily_loss_halted=0,halt_reason=NULL,halted_at=NULL,updated_at=datetime('now') WHERE id=1", (today,))
            row = (today, 0, None, None)
        if limit is not None and current_pnl is not None and float(current_pnl) <= -abs(float(limit)) and not bool(row[1]):
            reason = f"Daily loss limit reached: P&L {float(current_pnl):.2f} <= -{abs(float(limit)):.2f}"
            conn.execute("UPDATE risk_runtime_state SET daily_loss_halted=1,halt_reason=?,halted_at=datetime('now'),updated_at=datetime('now') WHERE id=1", (reason,))
            row = (today, 1, reason, None)
        return {"trading_date": row[0], "daily_loss_halted": bool(row[1]), "halt_reason": row[2], "halted_at": row[3]}


def refresh_strategy_daily_loss_halt(*, strategy_version_id: int, current_pnl: float | None, limit: float | None) -> dict:
    """Latch a strategy-specific daily-loss halt for the current IST date.

    A strategy breach blocks only that strategy's new entries; other strategies
    continue normally. Existing positions remain eligible for protective exits.
    """
    today = _ist_date()
    with _connection() as conn:
        row = conn.execute(
            "SELECT trading_date,daily_loss_halted,halt_reason,halted_at FROM strategy_risk_runtime_state WHERE strategy_version_id=?",
            (int(strategy_version_id),),
        ).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO strategy_risk_runtime_state(strategy_version_id,trading_date) VALUES(?,?)",
                (int(strategy_version_id), today),
            )
            row = (today, 0, None, None)
        elif row[0] != today:
            conn.execute(
                "UPDATE strategy_risk_runtime_state SET trading_date=?,daily_loss_halted=0,halt_reason=NULL,halted_at=NULL,updated_at=datetime('now') WHERE strategy_version_id=?",
                (today, int(strategy_version_id)),
            )
            row = (today, 0, None, None)
        halted = bool(row[1])
        reason = row[2]
        if not halted and limit and current_pnl is not None and float(current_pnl) <= -abs(float(limit)):
            reason = f"Strategy daily-loss limit reached: P&L {float(current_pnl):.2f} <= -{abs(float(limit)):.2f}"
            conn.execute(
                "UPDATE strategy_risk_runtime_state SET daily_loss_halted=1,halt_reason=?,halted_at=datetime('now'),updated_at=datetime('now') WHERE strategy_version_id=?",
                (reason, int(strategy_version_id)),
            )
            halted = True
        current = conn.execute("SELECT trading_date,daily_loss_halted,halt_reason,halted_at FROM strategy_risk_runtime_state WHERE strategy_version_id=?", (int(strategy_version_id),)).fetchone()
        return {"strategy_version_id": int(strategy_version_id), "trading_date": current[0], "daily_loss_halted": bool(current[1]), "halt_reason": current[2], "halted_at": current[3]}


def get_strategy_daily_loss_halt(strategy_version_id: int) -> dict:
    today = _ist_date()
    with _connection() as conn:
        row = conn.execute("SELECT trading_date,daily_loss_halted,halt_reason,halted_at FROM strategy_risk_runtime_state WHERE strategy_version_id=?", (int(strategy_version_id),)).fetchone()
        if row is None or row[0] != today:
            return {"strategy_version_id": int(strategy_version_id), "trading_date": today, "daily_loss_halted": False, "halt_reason": None, "halted_at": None}
        return {"strategy_version_id": int(strategy_version_id), "trading_date": row[0], "daily_loss_halted": bool(row[1]), "halt_reason": row[2], "halted_at": row[3]}


def get_risk_runtime_state() -> dict:
    today = _ist_date()
    with _connection() as conn:
        row = conn.execute("SELECT trading_date,daily_loss_halted,halt_reason,halted_at FROM risk_runtime_state WHERE id=1").fetchone()
        if not row or row[0] != today:
            conn.execute("UPDATE risk_runtime_state SET trading_date=?,daily_loss_halted=0,halt_reason=NULL,halted_at=NULL,updated_at=datetime('now') WHERE id=1", (today,))
            return {"trading_date": today, "daily_loss_halted": False, "halt_reason": None, "halted_at": None}
        return {"trading_date": row[0], "daily_loss_halted": bool(row[1]), "halt_reason": row[2], "halted_at": row[3]}


def record_live_readiness(ready: bool, details: dict) -> None:
    with _connection() as conn:
        conn.execute("INSERT INTO live_readiness_checks (ready, details) VALUES (?, ?)", (1 if ready else 0, json.dumps(details)))


def is_emergency_stop_active() -> bool:
    """Reads the shared emergency_stop_state singleton row (owned/migrated
    by the Node backend). Read-only from this side -- only the Express API
    is meant to toggle it (next phase: an explicit owner-triggered action).
    """
    with _connection() as conn:
        row = conn.execute("SELECT is_active FROM emergency_stop_state WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


# BUGFIX (final audit): broker_sessions (001_init.sql) was defined in the
# schema but never referenced by any code anywhere -- pure dead schema.
# Rather than delete a table that's a genuinely useful audit trail (when
# was each session established/revoked, from which data center), this
# wires it up: session.py calls these two functions on every
# established/ended transition, so broker_sessions becomes a real,
# queryable history instead of an always-empty table.
def record_session_started(*, data_center: str | None, expires_at_iso: str | None) -> None:
    with _connection() as conn:
        account = conn.execute("SELECT id FROM broker_accounts ORDER BY id ASC LIMIT 1").fetchone()
        if account is None:
            # No account row exists yet (Settings UI hasn't saved account
            # metadata) -- session history has nowhere to attach; skip
            # rather than violate the NOT NULL broker_account_id FK.
            return
        conn.execute(
            """INSERT INTO broker_sessions (broker_account_id, session_ref, data_center, established_at, expires_at)
               VALUES (?, ?, ?, datetime('now'), ?)""",
            (account[0], None, data_center, expires_at_iso),
        )


def record_session_ended() -> None:
    """Marks the most recent still-open (revoked_at IS NULL) session row as
    revoked now. Idempotent: a second call with nothing open is a no-op."""
    with _connection() as conn:
        conn.execute(
            """UPDATE broker_sessions SET revoked_at = datetime('now')
               WHERE id = (SELECT id FROM broker_sessions WHERE revoked_at IS NULL ORDER BY id DESC LIMIT 1)"""
        )


def record_reconciliation(
    *, reconciliation_type: str, reference_id: str | None, discrepancy_found: bool, details: dict | None
) -> None:
    """Always inserts (not idempotent by design -- every reconciliation
    pass is its own audit record, even if the result matches the last one).
    """
    with _connection() as conn:
        conn.execute(
            """INSERT INTO reconciliation_records
               (reconciliation_type, reference_id, discrepancy_found, details)
               VALUES (?, ?, ?, ?)""",
            (reconciliation_type, reference_id, 1 if discrepancy_found else 0, json.dumps(details) if details else None),
        )


# ==================================================================== #
# Phase 1C: order/position/holding/funds persistence + audit logging.
# Everything below writes into tables the Node backend already migrated
# (001_init.sql) -- see that file for column definitions. Nothing here
# invents a schema; it only starts actually using what was already there.
# ==================================================================== #


def write_audit_log(*, actor: str, action: str, details: dict | None = None) -> None:
    """Appends to audit_logs. Never raises into the caller's control flow
    for anything except a genuinely broken DB -- an audit-log write failing
    must not itself block a real order/connection action, but every
    call site should still know a total DB outage is a serious problem,
    so this deliberately does NOT swallow exceptions; callers that must
    not fail on audit-log trouble wrap this themselves (see order_service.py).
    """
    with _connection() as conn:
        conn.execute(
            "INSERT INTO audit_logs (actor, action, details) VALUES (?, ?, ?)",
            (actor, action, json.dumps(details) if details is not None else None),
        )


def list_audit_logs(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            "SELECT id, actor, action, details, created_at FROM audit_logs ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {
                "id": r[0],
                "actor": r[1],
                "action": r[2],
                "details": json.loads(r[3]) if r[3] else None,
                "created_at": r[4],
            }
            for r in rows
        ]


_ORDER_COLS = [
    "id", "internal_order_id", "broker_order_id", "trading_symbol", "exchange_segment",
    "transaction_type", "order_type", "product", "validity", "quantity", "price",
    "trigger_price", "mode", "status", "status_reason", "submitted_at", "updated_at", "created_at",
    "client_tag", "exchange_order_id", "filled_quantity", "average_price", "broker_status",
    "outcome_unknown", "last_broker_update_at", "instrument_token", "pnl_realized",
    "signal_id", "algo_position_id", "order_role", "parent_order_id",
]
_ORDER_SELECT = "SELECT " + ", ".join(_ORDER_COLS) + " FROM orders"

# Order status vocabulary. Terminal states never regress (a late/duplicate
# feed message cannot re-open a completed/cancelled/rejected order).
TERMINAL_STATUSES = ("COMPLETE", "CANCELLED", "REJECTED")


def create_order(
    *,
    internal_order_id: str,
    trading_symbol: str,
    exchange_segment: str | None,
    transaction_type: str,
    order_type: str,
    product: str,
    validity: str,
    quantity: int,
    price: float | None,
    trigger_price: float | None,
    mode: str,
    status: str,
    status_reason: str | None = None,
    broker_order_id: str | None = None,
    client_tag: str | None = None,
    instrument_token: str | None = None,
    signal_id: int | None = None,
    algo_position_id: int | None = None,
    order_role: str = "MANUAL",
    parent_order_id: str | None = None,
) -> int:
    """Inserts a new local order row BEFORE any broker call, so every request
    has a durable record (and a client_tag to reconcile by) even if the
    broker call times out ambiguously."""
    role=str(order_role or "MANUAL").upper()
    if role not in ("MANUAL","ENTRY","EXIT"):
        raise ValueError("order_role must be MANUAL, ENTRY or EXIT")
    if role == "ENTRY" and signal_id is None:
        raise ValueError("ENTRY orders require signal_id")
    if role == "EXIT" and algo_position_id is None:
        raise ValueError("EXIT orders require algo_position_id")
    with _connection() as conn:
        cur = conn.execute(
            """INSERT INTO orders
               (internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason, submitted_at, client_tag, instrument_token,
                signal_id, algo_position_id, order_role, parent_order_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), ?, ?, ?, ?, ?, ?)""",
            (
                internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason, client_tag, instrument_token,
                signal_id, algo_position_id, order_role, parent_order_id,
            ),
        )
        return cur.lastrowid


def update_order(
    *, internal_order_id: str, status: str | None = None, status_reason: str | None = None,
    broker_order_id: str | None = None, outcome_unknown: bool | None = None,
) -> None:
    """Partial update by internal_order_id -- only columns explicitly passed
    are changed. Never moves an order OUT of a terminal state."""
    with _connection() as conn:
        sets = ["updated_at = datetime('now')"]
        params: list = []
        if status is not None:
            sets.append("status = ?")
            params.append(status)
        if status_reason is not None:
            sets.append("status_reason = ?")
            params.append(status_reason)
        if broker_order_id is not None:
            sets.append("broker_order_id = ?")
            params.append(broker_order_id)
        if outcome_unknown is not None:
            sets.append("outcome_unknown = ?")
            params.append(1 if outcome_unknown else 0)
        params.append(internal_order_id)
        guard = ""
        if status is not None:
            guard = " AND status NOT IN ('COMPLETE','CANCELLED','REJECTED')"
        conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?{guard}", params)


def update_order_fields(
    *, internal_order_id: str, quantity: int | None = None, price: float | None = None,
    trigger_price: float | None = None,
) -> None:
    """Fields a modify actually changes (what the order IS, not its state)."""
    sets = []
    params: list = []
    if quantity is not None:
        sets.append("quantity = ?")
        params.append(quantity)
    if price is not None:
        sets.append("price = ?")
        params.append(price)
    if trigger_price is not None:
        sets.append("trigger_price = ?")
        params.append(trigger_price)
    if not sets:
        return
    sets.append("updated_at = datetime('now')")
    params.append(internal_order_id)
    with _connection() as conn:
        conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?", params)


def link_order_to_algo(*, internal_order_id:str, signal_id:int|None=None, algo_position_id:int|None=None,
                       order_role:str|None=None, parent_order_id:str|None=None) -> None:
    sets=[]; params=[]
    if signal_id is not None: sets.append("signal_id=?"); params.append(int(signal_id))
    if algo_position_id is not None: sets.append("algo_position_id=?"); params.append(int(algo_position_id))
    if order_role is not None: sets.append("order_role=?"); params.append(str(order_role))
    if parent_order_id is not None: sets.append("parent_order_id=?"); params.append(str(parent_order_id))
    if not sets:return
    params.append(internal_order_id)
    with _connection() as conn:
        conn.execute("UPDATE orders SET "+",".join(sets)+",updated_at=datetime('now') WHERE internal_order_id=?",params)

def get_signal(signal_id:int) -> dict|None:
    with _connection() as conn:
        r=conn.execute("SELECT id,strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,side,signal_price,conditions_json,risk_json,status,internal_order_id,created_at,candle_at FROM signals WHERE id=?",(int(signal_id),)).fetchone()
    if not r:return None
    d=dict(zip(("id","strategy_version_id","scanner_id","exchange_segment","instrument_token","trading_symbol","timeframe","side","signal_price","conditions_json","risk_json","status","internal_order_id","created_at","candle_at"),r))
    d["conditions"]=json.loads(d.pop("conditions_json") or "{}"); d["risk"]=json.loads(d.pop("risk_json") or "{}")
    return d

def find_strategy_entry_order_for_position(*, exchange_segment:str, instrument_token:str, side:str|None=None) -> dict|None:
    """Find only strategy ENTRY orders that are broker-confirmed/fill-bearing.
    Manual orders are never promoted into algo positions."""
    tx = "B" if str(side or "").upper()=="BUY" else "S" if str(side or "").upper()=="SELL" else None
    with _connection() as conn:
        sql=_ORDER_SELECT+" WHERE mode='LIVE' AND order_role='ENTRY' AND signal_id IS NOT NULL AND exchange_segment=? AND instrument_token=? AND filled_quantity>0"
        params=[exchange_segment,str(instrument_token)]
        if tx: sql += " AND transaction_type=?"; params.append(tx)
        sql += " ORDER BY id DESC LIMIT 1"
        r=conn.execute(sql,params).fetchone()
    return _order_row_to_dict(r) if r else None

def apply_broker_order_state(
    *, internal_order_id: str, status: str, broker_status: str | None,
    filled_quantity: int | None = None, average_price: float | None = None,
    exchange_order_id: str | None = None, broker_order_id: str | None = None,
    status_reason: str | None = None,
) -> bool:
    """Applies broker-reported order state (order feed OR REST order_report)
    to a local order. Rules (each covered by tests):
      * a terminal local status is never overwritten;
      * filled_quantity only ever increases (feed messages can arrive
        out of order or be re-delivered);
      * average_price is only replaced when the fill count grows.
    Returns True if any column changed."""
    with _connection() as conn:
        row = conn.execute(
            "SELECT status, filled_quantity FROM orders WHERE internal_order_id = ?", (internal_order_id,)
        ).fetchone()
        if row is None:
            return False
        cur_status, cur_filled = row[0], row[1] or 0
        sets = ["last_broker_update_at = datetime('now')", "updated_at = datetime('now')", "outcome_unknown = 0"]
        params: list = []
        if broker_status is not None:
            sets.append("broker_status = ?")
            params.append(broker_status)
        if cur_status not in TERMINAL_STATUSES:
            sets.append("status = ?")
            params.append(status)
            if status_reason is not None:
                sets.append("status_reason = ?")
                params.append(status_reason)
        new_filled = cur_filled
        if filled_quantity is not None and filled_quantity > cur_filled:
            new_filled = filled_quantity
            sets.append("filled_quantity = ?")
            params.append(filled_quantity)
            if average_price is not None:
                sets.append("average_price = ?")
                params.append(average_price)
        elif filled_quantity is not None and filled_quantity == cur_filled and average_price and cur_filled:
            sets.append("average_price = COALESCE(average_price, ?)")
            params.append(average_price)
        if exchange_order_id:
            sets.append("exchange_order_id = ?")
            params.append(exchange_order_id)
        if broker_order_id:
            sets.append("broker_order_id = COALESCE(broker_order_id, ?)")
            params.append(broker_order_id)
        params.append(internal_order_id)
        cur = conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?", params)
        return cur.rowcount == 1


def get_order(internal_order_id: str) -> dict | None:
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE internal_order_id = ?", (internal_order_id,)).fetchone()
        return _order_row_to_dict(row) if row else None


def get_order_by_broker_order_id(broker_order_id: str) -> dict | None:
    """Maps an incoming feed/report row (identified by the broker's nOrdNo)
    back to our local order."""
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE broker_order_id = ? ORDER BY id DESC LIMIT 1", (broker_order_id,)).fetchone()
        return _order_row_to_dict(row) if row else None


def get_order_by_client_tag(client_tag: str) -> dict | None:
    """Recovers an order whose placement outcome was UNKNOWN: the broker echoes
    our `tag` back as GuiOrdId in order_report()/trade_report()."""
    with _connection() as conn:
        row = conn.execute(_ORDER_SELECT + " WHERE client_tag = ?", (client_tag,)).fetchone()
        return _order_row_to_dict(row) if row else None


def list_orders(*, limit: int = 200, mode: str | None = None, open_only: bool = False) -> list[dict]:
    limit = max(1, min(limit, 1000))
    where, params = [], []
    where.append("mode = 'LIVE'")
    if open_only:
        where.append("status NOT IN ('COMPLETE','CANCELLED','REJECTED')")
    sql = _ORDER_SELECT + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id DESC LIMIT ?"
    with _connection() as conn:
        return [_order_row_to_dict(r) for r in conn.execute(sql, (*params, limit)).fetchall()]


def list_unresolved_live_orders() -> list[dict]:
    """LIVE orders whose broker outcome/state still needs to be established:
    placement outcome UNKNOWN, or submitted but not yet terminal."""
    with _connection() as conn:
        rows = conn.execute(
            _ORDER_SELECT + " WHERE mode = 'LIVE' AND (outcome_unknown = 1 OR "
            "status NOT IN ('COMPLETE','CANCELLED','REJECTED')) ORDER BY id ASC"
        ).fetchall()
        return [_order_row_to_dict(r) for r in rows]


def count_orders_today(*, mode: str | None = None) -> int:
    """Used by order_service.py's max_orders_per_day check. Counts by
    `created_at` (SQLite UTC) on the current UTC calendar day; rejected
    local-validation failures are never inserted, so they don't count."""
    with _connection() as conn:
        row = conn.execute("SELECT COUNT(*) FROM orders WHERE date(created_at, '+330 minutes') = date('now', '+330 minutes') AND mode = 'LIVE'").fetchone()
        return row[0] if row else 0


def sum_filled_quantity(order_id: int) -> int:
    """Sum of recorded fills for one local order (by integer `id`)."""
    with _connection() as conn:
        row = conn.execute("SELECT COALESCE(SUM(fill_quantity), 0) FROM trades WHERE order_id = ?", (order_id,)).fetchone()
        return row[0] if row else 0


def _order_row_to_dict(row) -> dict:
    return dict(zip(_ORDER_COLS, row))


def record_market_tick(
    *, instrument_token: str, exchange_segment: str | None, last_traded_price: float | None,
    trading_symbol: str | None = None, close_price: float | None = None, volume: int | None = None,
) -> None:
    """Upserts the latest tick per instrument. exchange_segment is normalised
    to "" (SQLite treats NULLs as distinct for UNIQUE, which would break the upsert)."""
    exchange_segment = exchange_segment or ""
    with _connection() as conn:
        conn.execute(
            """INSERT INTO market_data_state
                 (instrument_token, exchange_segment, last_traded_price, last_tick_at, trading_symbol, close_price, volume)
               VALUES (?, ?, ?, datetime('now'), ?, ?, ?)
               ON CONFLICT (instrument_token, exchange_segment)
               DO UPDATE SET last_traded_price = excluded.last_traded_price, last_tick_at = excluded.last_tick_at,
                             trading_symbol = COALESCE(excluded.trading_symbol, trading_symbol),
                             close_price = COALESCE(excluded.close_price, close_price),
                             volume = COALESCE(excluded.volume, volume)""",
            (instrument_token, exchange_segment, last_traded_price, trading_symbol, close_price, volume),
        )


def upsert_instrument_metadata(*, exchange_segment: str, instrument_token: str, trading_symbol: str, name: str | None = None) -> None:
    """Persist authoritative instrument display metadata obtained from the broker scrip search.

    This is display metadata only; it is never used to construct or validate an order.
    Existing richer scrip-master fields are preserved.
    """
    if not exchange_segment or not instrument_token or not trading_symbol:
        return
    with _connection() as conn:
        conn.execute(
            """INSERT INTO instruments(exchange_segment, trading_symbol, instrument_token, name)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(exchange_segment, instrument_token) DO UPDATE SET
                 trading_symbol=excluded.trading_symbol,
                 name=COALESCE(excluded.name, instruments.name)""",
            (str(exchange_segment), str(trading_symbol), str(instrument_token), name or None),
        )


def get_instruments_for_keys(keys: list[tuple[str, str]]) -> dict[tuple[str, str], dict]:
    """Return instrument metadata for many exchange/token pairs in bounded SQL batches."""
    wanted = list(dict.fromkeys((str(seg or ""), str(tok)) for seg, tok in keys if tok not in (None, "")))
    if not wanted:
        return {}
    out: dict[tuple[str, str], dict] = {}
    with _connection() as conn:
        for start in range(0, len(wanted), 400):
            chunk = wanted[start:start + 400]
            clauses = ",".join("(?, ?)" for _ in chunk)
            params = [value for pair in chunk for value in pair]
            rows = conn.execute(
                f"SELECT exchange_segment,trading_symbol,instrument_token,name,instrument_type,expiry,strike,option_type,lot_size,tick_size FROM instruments WHERE (exchange_segment,instrument_token) IN ({clauses})",
                params,
            ).fetchall()
            for row in rows:
                item = dict(zip(("exchange_segment","trading_symbol","instrument_token","name","instrument_type","expiry","strike","option_type","lot_size","tick_size"), row))
                out[(item["exchange_segment"], str(item["instrument_token"]))] = item
    return out


def latest_market_ticks_for_instrument(*, instrument_token: str | None, exchange_segment: str | None, trading_symbol: str | None = None) -> list[dict]:
    """Indexed point lookup used by LIVE risk/order checks; never scans an arbitrary recent-tick window."""
    with _connection() as conn:
        if instrument_token and exchange_segment:
            rows = conn.execute(
                """SELECT m.instrument_token, m.exchange_segment, m.last_traded_price, m.last_tick_at,
                          m.trading_symbol, i.name, m.close_price, m.volume
                   FROM market_data_state m
                   LEFT JOIN instruments i ON i.exchange_segment=m.exchange_segment AND i.instrument_token=m.instrument_token
                  WHERE m.instrument_token=? AND m.exchange_segment=? LIMIT 1""",
                (str(instrument_token), exchange_segment or ""),
            ).fetchall()
        elif trading_symbol:
            rows = conn.execute(
                """SELECT m.instrument_token, m.exchange_segment, m.last_traded_price, m.last_tick_at,
                          m.trading_symbol, i.name, m.close_price, m.volume
                   FROM market_data_state m
                   LEFT JOIN instruments i ON i.exchange_segment=m.exchange_segment AND i.instrument_token=m.instrument_token
                  WHERE m.trading_symbol=? ORDER BY m.last_tick_at DESC LIMIT 1""",
                (trading_symbol,),
            ).fetchall()
        else:
            rows = []
        keys = ("instrument_token", "exchange_segment", "last_traded_price", "last_tick_at", "trading_symbol", "name", "close_price", "volume")
        return [dict(zip(keys, r)) for r in rows]


def latest_market_ticks(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            """SELECT m.instrument_token, m.exchange_segment, m.last_traded_price, m.last_tick_at,
                      m.trading_symbol, i.name, m.close_price, m.volume
               FROM market_data_state m
               LEFT JOIN instruments i ON i.exchange_segment=m.exchange_segment AND i.instrument_token=m.instrument_token
              ORDER BY m.last_tick_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        keys = ("instrument_token", "exchange_segment", "last_traded_price", "last_tick_at", "trading_symbol", "name", "close_price", "volume")
        return [dict(zip(keys, r)) for r in rows]


def record_positions_snapshot(rows: list[dict]) -> None:
    """Replaces positions_snapshot with the latest broker fetch (one
    transaction). Row keys: trading_symbol, exchange_segment, product,
    instrument_token, buy_quantity, sell_quantity, quantity (NET),
    buy_amount, sell_amount, average_price, price_factor, lot_size, raw."""
    with _connection() as conn:
        conn.execute("DELETE FROM positions_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO positions_snapshot
                   (trading_symbol, exchange_segment, product, quantity, average_price, raw_payload,
                    instrument_token, buy_quantity, sell_quantity, buy_amount, sell_amount, price_factor, lot_size)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"), r.get("product"),
                    r.get("quantity"), r.get("average_price"), json.dumps(r.get("raw", r)),
                    r.get("instrument_token"), r.get("buy_quantity"), r.get("sell_quantity"),
                    r.get("buy_amount"), r.get("sell_amount"), r.get("price_factor"), r.get("lot_size"),
                ),
            )


def record_holdings_snapshot(rows: list[dict]) -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM holdings_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO holdings_snapshot
                   (trading_symbol, exchange_segment, quantity, average_price, raw_payload,
                    instrument_token, closing_price, market_value)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"), r.get("quantity"), r.get("average_price"),
                    json.dumps(r.get("raw", r)), r.get("instrument_token"), r.get("closing_price"), r.get("market_value"),
                ),
            )


def record_funds_snapshot(
    *, available_margin: float | None, used_margin: float | None, raw: dict,
    realized_mtom: float | None = None, unrealized_mtom: float | None = None,
) -> None:
    with _connection() as conn:
        conn.execute(
            """INSERT INTO funds_snapshot (available_margin, used_margin, raw_payload, realized_mtom, unrealized_mtom)
               VALUES (?, ?, ?, ?, ?)""",
            (available_margin, used_margin, json.dumps(raw), realized_mtom, unrealized_mtom),
        )


def latest_positions_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, product, quantity, average_price, raw_payload, snapshot_at, instrument_token, buy_quantity, sell_quantity, buy_amount, sell_amount, price_factor, lot_size FROM positions_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1], "product": r[2],
                "quantity": r[3], "average_price": r[4], "raw": json.loads(r[5]) if r[5] else None,
                "snapshot_at": r[6], "instrument_token": r[7], "buy_quantity": r[8], "sell_quantity": r[9],
                "buy_amount": r[10], "sell_amount": r[11], "price_factor": r[12], "lot_size": r[13],
            }
            for r in rows
        ]


def latest_holdings_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, quantity, average_price, raw_payload, snapshot_at, instrument_token, closing_price, market_value FROM holdings_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1],
                "quantity": r[2], "average_price": r[3], "raw": json.loads(r[4]) if r[4] else None,
                "snapshot_at": r[5], "instrument_token": r[6], "closing_price": r[7], "market_value": r[8],
            }
            for r in rows
        ]


def latest_funds_snapshot() -> dict | None:
    with _connection() as conn:
        row = conn.execute(
            "SELECT available_margin, used_margin, raw_payload, snapshot_at, realized_mtom, unrealized_mtom FROM funds_snapshot ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        return {
            "available_margin": row[0], "used_margin": row[1],
            "raw": json.loads(row[2]) if row[2] else None, "snapshot_at": row[3],
            "realized_mtom": row[4], "unrealized_mtom": row[5],
        }



# ------------------------------------------------------------------ Reconciliation run ledger (Phase 10)
def begin_reconciliation_run() -> int:
    with _connection() as conn:
        cur=conn.execute("INSERT INTO reconciliation_runs(status) VALUES('RUNNING')")
        return int(cur.lastrowid)

def finish_reconciliation_run(run_id:int, *, status:str, discrepancy_count:int, sections_ok:bool, details:dict|None=None) -> None:
    with _connection() as conn:
        conn.execute("UPDATE reconciliation_runs SET completed_at=datetime('now'),status=?,discrepancy_count=?,sections_ok=?,details_json=? WHERE id=?",
                     (status,int(discrepancy_count),1 if sections_ok else 0,_json(details or {}),int(run_id)))

def latest_reconciliation_run() -> dict|None:
    with _connection() as conn:
        r=conn.execute("SELECT id,started_at,completed_at,status,discrepancy_count,sections_ok,details_json FROM reconciliation_runs ORDER BY id DESC LIMIT 1").fetchone()
    if not r:return None
    d=dict(zip(('id','started_at','completed_at','status','discrepancy_count','sections_ok','details'),r));d['details']=json.loads(d['details'] or '{}');return d

# ------------------------------------------------------------------ Final audit / execution chain helpers (Phases 12-13)
def execution_chain(internal_order_id:str) -> dict|None:
    with _connection() as conn:
        order=conn.execute(_ORDER_SELECT+" WHERE internal_order_id=?",(internal_order_id,)).fetchone()
        if not order:return None
        o=_order_row_to_dict(order)
        signal=None;position=None;trades=[];exits=[]
        if o.get('signal_id'):
            r=conn.execute("SELECT id,strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,side,signal_price,status,internal_order_id,created_at,candle_at FROM signals WHERE id=?",(o['signal_id'],)).fetchone()
            if r: signal=dict(zip(('id','strategy_version_id','scanner_id','exchange_segment','instrument_token','trading_symbol','timeframe','side','signal_price','status','internal_order_id','created_at','candle_at'),r))
        if o.get('algo_position_id'):
            r=conn.execute("SELECT id,exchange_segment,instrument_token,trading_symbol,strategy_version_id,entry_order_id,quantity,average_entry,remaining_quantity,status,exit_reason,opened_at,closed_at,entry_side,broker_quantity,broker_average_entry FROM algo_positions WHERE id=?",(o['algo_position_id'],)).fetchone()
            if r: position=dict(zip(('id','exchange_segment','instrument_token','trading_symbol','strategy_version_id','entry_order_id','quantity','average_entry','remaining_quantity','status','exit_reason','opened_at','closed_at','entry_side','broker_quantity','broker_average_entry'),r))
        rows=conn.execute("SELECT id,broker_trade_id,fill_quantity,fill_price,fill_time,transaction_type,product FROM trades WHERE order_id=? ORDER BY id",(o['id'],)).fetchall()
        trades=[dict(zip(('id','broker_trade_id','fill_quantity','fill_price','fill_time','transaction_type','product'),r)) for r in rows]
        if position:
            rows=conn.execute("SELECT id,reason,requested_quantity,internal_order_id,trigger_price,filled_quantity,status,created_at,completed_at FROM algo_exits WHERE algo_position_id=? ORDER BY id",(position['id'],)).fetchall()
            exits=[dict(zip(('id','reason','requested_quantity','internal_order_id','trigger_price','filled_quantity','status','created_at','completed_at'),r)) for r in rows]
        return {'order':o,'signal':signal,'position':position,'trades':trades,'exits':exits}

def save_execution_audit_snapshot(internal_order_id:str) -> dict|None:
    chain=execution_chain(internal_order_id)
    if not chain:return None
    with _connection() as conn:
        conn.execute("INSERT INTO execution_audit_snapshots(internal_order_id,chain_json) VALUES(?,?)",(internal_order_id,_json(chain)))
    return chain

def create_final_audit() -> int:
    with _connection() as conn:return int(conn.execute("INSERT INTO final_audit_runs(status,checks_json) VALUES('RUNNING','[]')").lastrowid)

def complete_final_audit(run_id:int, checks:list[dict]) -> None:
    failures=sum(1 for c in checks if c.get('blocking') and not c.get('ok'))
    with _connection() as conn:
        conn.execute("UPDATE final_audit_runs SET completed_at=datetime('now'),status=?,blocking_failures=?,checks_json=? WHERE id=?",
                     ('PASS' if failures==0 else 'FAIL',failures,_json(checks),int(run_id)))

def latest_final_audit()->dict|None:
    with _connection() as conn:
        r=conn.execute("SELECT id,started_at,completed_at,status,blocking_failures,checks_json FROM final_audit_runs ORDER BY id DESC LIMIT 1").fetchone()
    if not r:return None
    return dict(zip(('id','started_at','completed_at','status','blocking_failures','checks'),(r[0],r[1],r[2],r[3],r[4],json.loads(r[5] or '[]'))))

# ------------------------------------------------------------------ LIVE ALGO persistence

def _json(value):
    return json.dumps(value, separators=(",", ":"), default=str)

def create_strategy(name: str) -> dict:
    with _connection() as conn:
        cur = conn.execute("INSERT INTO strategies(name, mode, is_active) VALUES (?, 'LIVE', 0)", (name.strip(),))
        sid = cur.lastrowid
        conn.execute("INSERT INTO strategy_versions(strategy_id, version, definition_json) VALUES (?, 1, ?)", (sid, _json({"entry": {"op":"AND","conditions":[]}, "exit": {"op":"OR","conditions":[]}})))
    return get_strategy(sid)

def get_strategy(strategy_id: int) -> dict | None:
    with _connection() as conn:
        row = conn.execute("SELECT id,name,is_active,created_at FROM strategies WHERE id=? AND mode='LIVE'", (strategy_id,)).fetchone()
        if not row: return None
        d = dict(zip(("id","name","is_active","created_at"), row));
        d["versions"] = [dict(zip(("id","version","definition_json","status","is_live_armed","created_at","updated_at","validation_errors_json"), r)) for r in conn.execute("SELECT id,version,definition_json,status,is_live_armed,created_at,updated_at,validation_errors_json FROM strategy_versions WHERE strategy_id=? ORDER BY version DESC", (strategy_id,)).fetchall()]
        for v in d["versions"]:
            v["definition"] = json.loads(v.pop("definition_json")); v["validation_errors"] = json.loads(v.pop("validation_errors_json") or "[]") if "validation_errors_json" in v else []
        return d

def list_strategies() -> list[dict]:
    with _connection() as conn:
        ids = [r[0] for r in conn.execute("SELECT id FROM strategies WHERE mode='LIVE' ORDER BY id DESC").fetchall()]
    return [get_strategy(i) for i in ids]

def save_strategy_version(strategy_id: int, definition: dict, status: str = "VALIDATED", validation_errors: list[str] | None = None) -> dict:
    from .strategy_engine import validate_strategy
    errors = list(validation_errors if validation_errors is not None else validate_strategy(definition))
    if errors:
        status = "INVALID"
    with _connection() as conn:
        row = conn.execute("SELECT COALESCE(MAX(version),0)+1 FROM strategy_versions WHERE strategy_id=?", (strategy_id,)).fetchone()
        v = int(row[0])
        conn.execute("INSERT INTO strategy_versions(strategy_id,version,definition_json,status,validation_errors_json) VALUES (?,?,?,?,?)", (strategy_id,v,_json(definition),status,_json(errors) if errors else None))
        return {"id": conn.execute("SELECT id FROM strategy_versions WHERE strategy_id=? AND version=?", (strategy_id,v)).fetchone()[0], "strategy_id":strategy_id,"version":v,"definition":definition,"status":status,"is_live_armed":False,"validation_errors":errors}

def set_strategy_armed(version_id: int, armed: bool) -> dict | None:
    with _connection() as conn:
        row = conn.execute("SELECT strategy_id,definition_json FROM strategy_versions WHERE id=?", (version_id,)).fetchone()
        if not row: return None
        if armed:
            from .strategy_engine import validate_strategy
            definition=json.loads(row[1])
            errors=validate_strategy(definition)
            risk=definition.get("risk") or {}
            if not any(risk.get(k) is not None for k in ("stop_loss","stop_loss_pct","stop_atr_multiple")):
                errors.append("LIVE strategy requires a protective stop (price, percent or ATR multiple)")
            universe=definition.get("universe") or {}
            tokens=[str(t).strip() for t in universe.get("instrument_tokens",[]) if str(t).strip()] if isinstance(universe,dict) else []
            scanner_ids=definition.get("scanner_ids") or []
            if not tokens and not scanner_ids:
                errors.append("LIVE strategy requires a non-empty instrument universe when no scanner is configured")
            elif tokens:
                missing=[t for t in tokens if not get_instrument("nse_cm",t)]
                if missing:
                    errors.append(f"LIVE strategy universe has {len(missing)} token(s) missing from synced NSE metadata")
            if errors:
                raise ValueError("Strategy cannot be armed: " + "; ".join(errors))
        conn.execute("UPDATE strategy_versions SET is_live_armed=?, status=?, updated_at=datetime('now') WHERE id=?", (1 if armed else 0, "LIVE_RUNNING" if armed else "PAUSED", version_id))
        if armed: conn.execute("UPDATE strategy_versions SET is_live_armed=0 WHERE strategy_id=? AND id<>?", (row[0],version_id))
    refresh_algo_runtime()
    return {"id":version_id,"armed":armed}

def validate_scanner_ids(scanner_ids) -> list[int]:
    """Return only existing scanner IDs; callers can enforce ownership.
    Scanner activation is evaluated separately so a strategy may be saved while
    its scanner is inactive, but an armed strategy can only use valid IDs.
    """
    ids=[]
    for value in scanner_ids or []:
        try:
            n=int(value)
        except (TypeError,ValueError):
            continue
        if n > 0:
            ids.append(n)
    ids=list(dict.fromkeys(ids))
    if not ids:return []
    with _connection() as conn:
        rows=conn.execute(f"SELECT id FROM scanners WHERE id IN ({','.join('?' for _ in ids)})", ids).fetchall()
    return [int(r[0]) for r in rows]


def upsert_strategy_candidate(*, strategy_version_id:int, scanner_id:int, exchange_segment:str, instrument_token:str, trading_symbol:str|None, timeframe:str, matched_price:float|None, conditions:dict, expires_at:str|None) -> dict:
    with _connection() as conn:
        conn.execute(
            """INSERT INTO strategy_candidates
               (strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,matched_price,conditions_json,status,first_matched_at,last_matched_at,expires_at,updated_at)
               VALUES (?,?,?,?,?,?,?,?, 'ACTIVE',datetime('now'),datetime('now'),?,datetime('now'))
               ON CONFLICT(strategy_version_id,scanner_id,exchange_segment,instrument_token) DO UPDATE SET
                 trading_symbol=excluded.trading_symbol, timeframe=excluded.timeframe, matched_price=excluded.matched_price,
                 conditions_json=excluded.conditions_json, status='ACTIVE', last_matched_at=datetime('now'),
                 expires_at=excluded.expires_at, last_error=NULL, updated_at=datetime('now')""",
            (int(strategy_version_id),int(scanner_id),exchange_segment,str(instrument_token),trading_symbol,timeframe,matched_price,_json(conditions),expires_at),
        )
        row=conn.execute("SELECT id,strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,matched_price,conditions_json,status,first_matched_at,last_matched_at,expires_at,subscribed_at,last_error,updated_at FROM strategy_candidates WHERE strategy_version_id=? AND scanner_id=? AND exchange_segment=? AND instrument_token=?", (int(strategy_version_id),int(scanner_id),exchange_segment,str(instrument_token))).fetchone()
    return _candidate_row(row)


def _candidate_row(row) -> dict:
    if not row:return {}
    keys=("id","strategy_version_id","scanner_id","exchange_segment","instrument_token","trading_symbol","timeframe","matched_price","conditions_json","status","first_matched_at","last_matched_at","expires_at","subscribed_at","last_error","updated_at")
    d=dict(zip(keys,row)); d["conditions"]=json.loads(d.pop("conditions_json") or "{}"); return d


def list_strategy_candidates(*, strategy_version_id:int|None=None, active_only:bool=False, limit:int=3000) -> list[dict]:
    clauses=[]; params=[]
    if strategy_version_id is not None: clauses.append("strategy_version_id=?"); params.append(int(strategy_version_id))
    if active_only: clauses.append("status='ACTIVE' AND (expires_at IS NULL OR expires_at > datetime('now'))")
    where=" WHERE " + " AND ".join(clauses) if clauses else ""
    with _connection() as conn:
        rows=conn.execute("SELECT id,strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,matched_price,conditions_json,status,first_matched_at,last_matched_at,expires_at,subscribed_at,last_error,updated_at FROM strategy_candidates"+where+" ORDER BY last_matched_at DESC LIMIT ?", (*params,max(1,min(int(limit),10000)))).fetchall()
    return [_candidate_row(r) for r in rows]


def mark_strategy_candidate_subscribed(candidate_id:int, subscribed:bool, error:str|None=None) -> None:
    with _connection() as conn:
        conn.execute("UPDATE strategy_candidates SET subscribed_at=CASE WHEN ? THEN COALESCE(subscribed_at,datetime('now')) ELSE NULL END,last_error=?,updated_at=datetime('now') WHERE id=?", (1 if subscribed else 0,error,int(candidate_id)))


def expire_strategy_candidates(*, strategy_version_id:int|None=None) -> int:
    clauses=["status='ACTIVE'", "expires_at IS NOT NULL", "expires_at <= datetime('now')"]; params=[]
    if strategy_version_id is not None: clauses.append("strategy_version_id=?"); params.append(int(strategy_version_id))
    with _connection() as conn:
        cur=conn.execute("UPDATE strategy_candidates SET status='EXPIRED',updated_at=datetime('now') WHERE " + " AND ".join(clauses), params)
        return int(cur.rowcount)


def deactivate_strategy_candidates_for_scanners(strategy_version_id:int, scanner_ids:list[int]) -> int:
    ids=[int(x) for x in scanner_ids]
    with _connection() as conn:
        if not ids:
            cur=conn.execute("UPDATE strategy_candidates SET status='DISARMED',updated_at=datetime('now') WHERE strategy_version_id=? AND status='ACTIVE'", (int(strategy_version_id),))
        else:
            placeholders=','.join('?' for _ in ids)
            cur=conn.execute(f"UPDATE strategy_candidates SET status='DISARMED',updated_at=datetime('now') WHERE strategy_version_id=? AND status='ACTIVE' AND scanner_id NOT IN ({placeholders})", (int(strategy_version_id),*ids))
        return int(cur.rowcount)


def deactivate_strategy_candidates(strategy_version_id:int) -> int:
    with _connection() as conn:
        cur=conn.execute("UPDATE strategy_candidates SET status='DISARMED',updated_at=datetime('now') WHERE strategy_version_id=? AND status='ACTIVE'", (int(strategy_version_id),))
        return int(cur.rowcount)


def active_candidates_for_strategy_instrument(*, strategy_version_id:int, exchange_segment:str, instrument_token:str, subscribed_only:bool=False) -> list[dict]:
    rows=list_strategy_candidates(strategy_version_id=int(strategy_version_id), active_only=True, limit=10000)
    rows=[r for r in rows if str(r["exchange_segment"])==str(exchange_segment) and str(r["instrument_token"])==str(instrument_token)]
    if subscribed_only:
        rows=[r for r in rows if r.get("subscribed_at") and not r.get("last_error")]
    return rows


def has_active_candidate(*, strategy_version_id:int, exchange_segment:str, instrument_token:str) -> bool:
    with _connection() as conn:
        row=conn.execute("SELECT 1 FROM strategy_candidates WHERE strategy_version_id=? AND exchange_segment=? AND instrument_token=? AND status='ACTIVE' AND (expires_at IS NULL OR expires_at > datetime('now')) LIMIT 1", (int(strategy_version_id),exchange_segment,str(instrument_token))).fetchone()
    return bool(row)


def list_active_candidate_subscription_keys() -> list[tuple[str,str,int]]:
    with _connection() as conn:
        rows=conn.execute("SELECT exchange_segment,instrument_token,strategy_version_id FROM strategy_candidates WHERE status='ACTIVE' AND subscribed_at IS NOT NULL AND last_error IS NULL AND (expires_at IS NULL OR expires_at > datetime('now'))").fetchall()
    return [(str(r[0]),str(r[1]),int(r[2])) for r in rows]


def strategy_realized_pnl_today(strategy_version_id:int) -> float:
    with _connection() as conn:
        row=conn.execute("SELECT COALESCE(SUM(realized_pnl),0) FROM algo_positions WHERE strategy_version_id=? AND closed_at IS NOT NULL AND date(closed_at,'+330 minutes')=date('now','+330 minutes')", (int(strategy_version_id),)).fetchone()
    return float(row[0] or 0)


def strategy_open_exposure(strategy_version_id:int, *, price_lookup) -> float:
    total=0.0
    for p in list_algo_positions():
        if int(p.get('strategy_version_id') or 0) != int(strategy_version_id): continue
        px=price_lookup(p)
        if px is None: continue
        total += abs(int(p.get('remaining_quantity') or 0)) * float(px)
    return total


def total_algo_exposure(*, price_lookup) -> float:
    total=0.0
    for p in list_algo_positions():
        px=price_lookup(p)
        if px is None: continue
        total += abs(int(p.get('remaining_quantity') or 0)) * float(px)
    return total


def instrument_algo_exposure(exchange_segment:str, instrument_token:str, *, price_lookup) -> float:
    total=0.0
    for p in list_algo_positions():
        if str(p.get('exchange_segment'))!=str(exchange_segment) or str(p.get('instrument_token'))!=str(instrument_token): continue
        px=price_lookup(p)
        if px is None: continue
        total += abs(int(p.get('remaining_quantity') or 0)) * float(px)
    return total


def create_scanner(name: str, definition: dict) -> dict:
    """Create or update a scanner by its unique owner-facing name.

    The Scanner UI's Save action is naturally repeatable; treating a second
    save of the same name as an update avoids UNIQUE(scanners.name) failures
    and keeps the existing active/disarmed state intact. New scanners start
    inactive and therefore cannot unexpectedly begin execution.
    """
    clean_name = str(name or "").strip()
    if not clean_name:
        raise ValueError("scanner name is required")
    with _connection() as conn:
        existing = conn.execute("SELECT id,is_active FROM scanners WHERE name=? LIMIT 1", (clean_name,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE scanners SET definition_json=?, updated_at=datetime('now') WHERE id=?",
                (_json(definition), existing[0]),
            )
            scanner_id = int(existing[0])
            active = bool(existing[1])
        else:
            cur = conn.execute(
                "INSERT INTO scanners(name,definition_json,is_active) VALUES (?,?,0)",
                (clean_name, _json(definition)),
            )
            scanner_id = int(cur.lastrowid)
            active = False
    return {"id": scanner_id, "name": clean_name, "definition": definition, "is_active": active}


def get_scanner(scanner_id: int) -> dict | None:
    with _connection() as conn:
        row=conn.execute("SELECT id,name,definition_json,is_active,created_at,updated_at FROM scanners WHERE id=?", (int(scanner_id),)).fetchone()
    if not row:return None
    d=dict(zip(("id","name","definition_json","is_active","created_at","updated_at"),row))
    d["definition"]=json.loads(d.pop("definition_json"))
    return d


def list_scanners() -> list[dict]:
    with _connection() as conn:
        rows=conn.execute("SELECT id,name,definition_json,is_active,created_at,updated_at FROM scanners ORDER BY id DESC").fetchall()
    return [dict(zip(("id","name","definition_json","is_active","created_at","updated_at"),r)) | {"definition":json.loads(r[2])} for r in rows]


def update_scanner(scanner_id: int, name: str, definition: dict, active: bool | None = None) -> dict | None:
    with _connection() as conn:
        row=conn.execute("SELECT id FROM scanners WHERE id=?",(scanner_id,)).fetchone()
        if not row:return None
        if active is None:
            conn.execute("UPDATE scanners SET name=?,definition_json=?,updated_at=datetime('now') WHERE id=?",(name.strip(),_json(definition),scanner_id))
        else:
            conn.execute("UPDATE scanners SET name=?,definition_json=?,is_active=?,updated_at=datetime('now') WHERE id=?",(name.strip(),_json(definition),1 if active else 0,scanner_id))
    return next((x for x in list_scanners() if x['id']==scanner_id),None)

def set_scanner_active(scanner_id: int, active: bool) -> dict | None:
    with _connection() as conn:
        conn.execute("UPDATE scanners SET is_active=?,updated_at=datetime('now') WHERE id=?",(1 if active else 0,scanner_id))
    return next((x for x in list_scanners() if x['id']==scanner_id),None)

def upsert_candle(*, exchange_segment, instrument_token, trading_symbol, timeframe, candle_at, open_, high, low, close, volume):
    upsert_candles([{
        "exchange_segment": exchange_segment, "instrument_token": instrument_token,
        "trading_symbol": trading_symbol, "timeframe": timeframe, "candle_at": candle_at,
        "open": open_, "high": high, "low": low, "close": close, "volume": volume,
    }])


def upsert_candles(rows: list[dict]) -> int:
    """Bulk candle UPSERT: one SQLite transaction per broker/cache batch."""
    if not rows:
        return 0
    values = [(
        r["exchange_segment"], str(r["instrument_token"]), r.get("trading_symbol") or str(r["instrument_token"]),
        r["timeframe"], r["candle_at"], r["open"], r["high"], r["low"], r["close"], r.get("volume", 0),
    ) for r in rows]
    with _connection() as conn:
        conn.executemany(
            """INSERT INTO candles(exchange_segment,instrument_token,trading_symbol,timeframe,candle_at,open,high,low,close,volume)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(exchange_segment,instrument_token,timeframe,candle_at)
               DO UPDATE SET trading_symbol=excluded.trading_symbol,high=excluded.high,low=excluded.low,
                             close=excluded.close,volume=excluded.volume""",
            values,
        )
    return len(values)




def get_candle_runtime_state(exchange_segment, instrument_token, timeframe):
    try:
        with _connection() as conn:
            r=conn.execute(
                "SELECT candle_at,open,high,low,close,volume,trading_symbol,cumulative_volume FROM candle_runtime_state WHERE exchange_segment=? AND instrument_token=? AND timeframe=?",
                (exchange_segment,str(instrument_token),timeframe)).fetchone()
    except sqlite3.OperationalError as exc:
        logger.warning("Could not read candle runtime state: %s", exc)
        return None
    if not r:return None
    return dict(zip(("candle_at","open","high","low","close","volume","trading_symbol","cumulative_volume"),r))

def upsert_candle_runtime_state(*, exchange_segment, instrument_token, timeframe, candle_at, open_, high, low, close, volume, trading_symbol=None, cumulative_volume=None):
    try:
        with _connection() as conn:
            conn.execute(
                """INSERT INTO candle_runtime_state(exchange_segment,instrument_token,timeframe,candle_at,open,high,low,close,volume,trading_symbol,cumulative_volume,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
                   ON CONFLICT(exchange_segment,instrument_token,timeframe) DO UPDATE SET
                     candle_at=excluded.candle_at,open=excluded.open,high=excluded.high,low=excluded.low,close=excluded.close,
                     volume=excluded.volume,trading_symbol=COALESCE(excluded.trading_symbol,candle_runtime_state.trading_symbol),
                     cumulative_volume=excluded.cumulative_volume,updated_at=datetime('now')""",
                (exchange_segment,str(instrument_token),timeframe,candle_at,open_,high,low,close,int(volume or 0),trading_symbol,cumulative_volume),
            )
    except sqlite3.OperationalError as exc:
        logger.warning("Could not persist candle runtime state: %s", exc)

def delete_candle_runtime_state(exchange_segment, instrument_token, timeframe):
    try:
        with _connection() as conn:
            conn.execute("DELETE FROM candle_runtime_state WHERE exchange_segment=? AND instrument_token=? AND timeframe=?",(exchange_segment,str(instrument_token),timeframe))
    except sqlite3.OperationalError as exc:
        logger.warning("Could not delete candle runtime state: %s", exc)

def get_candle(exchange_segment, instrument_token, timeframe, candle_at) -> dict | None:
    with _connection() as conn:
        r = conn.execute(
            "SELECT candle_at,open,high,low,close,COALESCE(volume,0),trading_symbol FROM candles WHERE exchange_segment=? AND instrument_token=? AND timeframe=? AND candle_at=? LIMIT 1",
            (exchange_segment, str(instrument_token), timeframe, candle_at),
        ).fetchone()
    if not r:
        return None
    return dict(zip(("candle_at","open","high","low","close","volume","trading_symbol"), r))

def recent_candles(exchange_segment, instrument_token, timeframe="5m", limit=250) -> list[dict]:
    with _connection() as conn:
        rows=conn.execute("SELECT candle_at,open,high,low,close,COALESCE(volume,0) FROM candles WHERE exchange_segment=? AND instrument_token=? AND timeframe=? ORDER BY candle_at DESC LIMIT ?",(exchange_segment,str(instrument_token),timeframe,max(1,min(int(limit),1000)))).fetchall()
    return [dict(zip(("candle_at","open","high","low","close","volume"),r)) for r in reversed(rows)]


def recent_candles_for_instruments(instruments: list[dict], timeframe="5m", limit=250) -> dict[tuple[str, str], list[dict]]:
    """Fetch bounded recent candles for many instruments in one SQLite read.

    Scanner runs can cover up to 3000 instruments; opening one connection/query
    per instrument created unnecessary SQLite overhead. The window-function
    query keeps only the newest `limit` rows per instrument and returns them in
    chronological order for the strategy evaluator.
    """
    if not instruments:
        return {}
    limit=max(1,min(int(limit),1000))
    tokens=[]; seen=set()
    for item in instruments:
        seg=str(item.get("exchange_segment") or "nse_cm")
        tok=str(item.get("instrument_token") or "").strip()
        if not tok or (seg,tok) in seen:
            continue
        seen.add((seg,tok)); tokens.append((seg,tok))
    if not tokens:
        return {}
    # SQLite parameters cannot bind a VALUES list directly, so use a temporary
    # in-memory VALUES CTE. This is read-only and exists only for this query.
    values_sql=",".join(["(?,?)"]*len(tokens))
    params=[v for pair in tokens for v in pair]
    params.extend([timeframe, limit])
    sql=f"""
        WITH wanted(exchange_segment,instrument_token) AS (VALUES {values_sql}),
        ranked AS (
          SELECT c.exchange_segment,c.instrument_token,c.candle_at,c.open,c.high,c.low,c.close,COALESCE(c.volume,0) AS volume,
                 ROW_NUMBER() OVER (PARTITION BY c.exchange_segment,c.instrument_token ORDER BY c.candle_at DESC) AS rn
          FROM candles c JOIN wanted w
            ON w.exchange_segment=c.exchange_segment AND w.instrument_token=c.instrument_token
          WHERE c.timeframe=?
        )
        SELECT exchange_segment,instrument_token,candle_at,open,high,low,close,volume
        FROM ranked WHERE rn<=? ORDER BY exchange_segment,instrument_token,candle_at ASC
    """
    out={}
    with _connection() as conn:
        rows=conn.execute(sql,params).fetchall()
    for r in rows:
        key=(r[0],str(r[1])); out.setdefault(key,[]).append(dict(zip(("candle_at","open","high","low","close","volume"),r[2:])))
    return out

def get_signal_strategy_context(signal_id:int) -> dict|None:
    with _connection() as conn:
        r=conn.execute("SELECT id,strategy_version_id,exchange_segment,instrument_token,trading_symbol,timeframe,side FROM signals WHERE id=?", (int(signal_id),)).fetchone()
    if not r:return None
    return dict(zip(("id","strategy_version_id","exchange_segment","instrument_token","trading_symbol","timeframe","side"),r))


def record_signal(**kw):
    """Create one strategy signal before its executable order."""
    with _connection() as conn:
        candle_at=kw.get("candle_at")
        if candle_at is not None:
            existing=conn.execute(
                """SELECT id FROM signals
                   WHERE strategy_version_id=? AND exchange_segment=? AND instrument_token=?
                     AND timeframe=? AND side=? AND candle_at=? ORDER BY id DESC LIMIT 1""",
                (kw.get("strategy_version_id"),kw["exchange_segment"],str(kw["instrument_token"]),
                 kw["timeframe"],kw["side"],candle_at)).fetchone()
            if existing:return existing[0]
        cur=conn.execute(
            "INSERT INTO signals(strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,side,signal_price,conditions_json,risk_json,status,internal_order_id,candle_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (kw.get("strategy_version_id"),kw.get("scanner_id"),kw["exchange_segment"],str(kw["instrument_token"]),
             kw["trading_symbol"],kw["timeframe"],kw["side"],kw.get("signal_price"),_json(kw.get("conditions",{})),
             _json(kw.get("risk",{})),kw.get("status","DETECTED"),kw.get("internal_order_id"),candle_at))
        return cur.lastrowid

def get_signal_by_execution_key(*, strategy_version_id:int, exchange_segment:str, instrument_token:str, timeframe:str, side:str, candle_at:str):
    with _connection() as conn:
        r=conn.execute(
            """SELECT id FROM signals WHERE strategy_version_id=? AND exchange_segment=? AND instrument_token=?
               AND timeframe=? AND side=? AND candle_at=? ORDER BY id DESC LIMIT 1""",
            (int(strategy_version_id),exchange_segment,str(instrument_token),timeframe,side,candle_at)).fetchone()
    return int(r[0]) if r else None

def update_signal_execution(signal_id:int, *, status:str|None=None, internal_order_id:str|None=None, risk:dict|None=None):
    sets=["id=id"]; params=[]
    if status is not None: sets.append("status=?"); params.append(status)
    if internal_order_id is not None: sets.append("internal_order_id=?"); params.append(internal_order_id)
    if risk is not None: sets.append("risk_json=?"); params.append(_json(risk))
    params.append(int(signal_id))
    with _connection() as conn:
        conn.execute("UPDATE signals SET "+",".join(sets)+" WHERE id=?",params)

def list_signals(limit=200):
    with _connection() as conn:
        rows=conn.execute("SELECT id,strategy_version_id,scanner_id,exchange_segment,instrument_token,trading_symbol,timeframe,side,signal_price,conditions_json,risk_json,status,internal_order_id,created_at,candle_at FROM signals ORDER BY id DESC LIMIT ?",(max(1,min(int(limit),1000)),)).fetchall()
    out=[]
    for r in rows:
        d=dict(zip(("id","strategy_version_id","scanner_id","exchange_segment","instrument_token","trading_symbol","timeframe","side","signal_price","conditions_json","risk_json","status","internal_order_id","created_at","candle_at"),r)); d["conditions"]=json.loads(d.pop("conditions_json") or "{}"); d["risk"]=json.loads(d.pop("risk_json") or "{}"); out.append(d)
    return out

def set_algo_runtime(**values):
    allowed={"last_scan_at","last_signal_at","last_execution_at","active_strategy_count","universe_count","status","last_error"}
    sets=[]; params=[]
    for k,v in values.items():
        if k in allowed: sets.append(f"{k}=?"); params.append(v)
    if not sets:return
    sets.append("updated_at=datetime('now')")
    with _connection() as conn: conn.execute("UPDATE algo_runtime_state SET "+",".join(sets)+" WHERE id=1",params)

def refresh_algo_runtime() -> None:
    with _connection() as conn:
        count=conn.execute("SELECT COUNT(*) FROM strategy_versions WHERE is_live_armed=1").fetchone()[0]
        conn.execute("UPDATE algo_runtime_state SET active_strategy_count=?, updated_at=datetime('now') WHERE id=1",(int(count),))

def get_algo_runtime():
    with _connection() as conn:
        r=conn.execute(
            "SELECT id,last_scan_at,last_signal_at,last_execution_at,active_strategy_count,universe_count,status,last_error,updated_at "
            "FROM algo_runtime_state WHERE id=1"
        ).fetchone()
        instrument_count=conn.execute(
            "SELECT COUNT(*) FROM instruments WHERE exchange_segment='nse_cm'"
        ).fetchone()[0]
    if not r:
        return None
    out=dict(zip(("id","last_scan_at","last_signal_at","last_execution_at","active_strategy_count","universe_count","status","last_error","updated_at"),r))
    # universe_count is a runtime statistic and can legitimately be reset to zero
    # on restart. The authoritative metadata count is the instruments table, so
    # the UI must not report "0" merely because the process has just restarted.
    out["metadata_instrument_count"]=int(instrument_count or 0)
    out["universe_count"]=max(int(out.get("universe_count") or 0), int(instrument_count or 0))
    return out

def get_instrument(exchange_segment:str, instrument_token:str) -> dict|None:
    with _connection() as conn:
        r=conn.execute(
            "SELECT exchange_segment,trading_symbol,instrument_token,name,instrument_type,expiry,strike,option_type,lot_size,tick_size FROM instruments WHERE exchange_segment=? AND instrument_token=? LIMIT 1",
            (exchange_segment,str(instrument_token))).fetchone()
    return dict(zip(("exchange_segment","trading_symbol","instrument_token","name","instrument_type","expiry","strike","option_type","lot_size","tick_size"),r)) if r else None

def bulk_upsert_instruments(rows: list[dict]) -> int:
    if not rows:
        return 0
    values = [(
        "nse_cm", str(r["trading_symbol"]), str(r["instrument_token"]), r.get("name"), r.get("instrument_type") or "EQ",
        r.get("expiry"), r.get("strike"), r.get("option_type"), r.get("lot_size"), r.get("tick_size"),
    ) for r in rows]
    with _connection() as conn:
        conn.executemany(
            """INSERT INTO instruments(exchange_segment,trading_symbol,instrument_token,name,instrument_type,expiry,strike,option_type,lot_size,tick_size,scrip_master_updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,datetime('now'))
               ON CONFLICT(exchange_segment,instrument_token) DO UPDATE SET
                 trading_symbol=excluded.trading_symbol,
                 name=CASE WHEN excluded.name IS NOT NULL AND trim(excluded.name)<>'' THEN excluded.name ELSE instruments.name END,
                 instrument_type=excluded.instrument_type, expiry=excluded.expiry, strike=excluded.strike,
                 option_type=excluded.option_type, lot_size=excluded.lot_size, tick_size=excluded.tick_size,
                 scrip_master_updated_at=datetime('now')""",
            values,
        )
    return len(values)


def list_instruments(limit=5000):
    with _connection() as conn:
        rows=conn.execute("SELECT exchange_segment,trading_symbol,instrument_token,name,instrument_type,expiry,strike,option_type,lot_size,tick_size FROM instruments WHERE exchange_segment='nse_cm' ORDER BY trading_symbol LIMIT ?",(limit,)).fetchall()
    return [dict(zip(("exchange_segment","trading_symbol","instrument_token","name","instrument_type","expiry","strike","option_type","lot_size","tick_size"),r)) for r in rows]

# ------------------------------------------------------------------ LIVE exit state

def get_open_algo_position(position_id: int) -> dict | None:
    with _connection() as conn:
        r=conn.execute("SELECT id,exchange_segment,instrument_token,trading_symbol,remaining_quantity,status FROM algo_positions WHERE id=? AND status='OPEN'", (int(position_id),)).fetchone()
    if not r:return None
    return dict(zip(("id","exchange_segment","instrument_token","trading_symbol","remaining_quantity","status"),r))

def list_algo_positions() -> list[dict]:
    with _connection() as conn:
        rows=conn.execute("SELECT id,exchange_segment,instrument_token,trading_symbol,strategy_version_id,entry_order_id,quantity,average_entry,stop_loss,target,trailing_stop,remaining_quantity,status,exit_reason,opened_at,closed_at,exit_quantity,last_price,trailing_stop_pct,time_exit_bars,realized_pnl FROM algo_positions WHERE status='OPEN' ORDER BY id").fetchall()
    keys=("id","exchange_segment","instrument_token","trading_symbol","strategy_version_id","entry_order_id","quantity","average_entry","stop_loss","target","trailing_stop","remaining_quantity","status","exit_reason","opened_at","closed_at","exit_quantity","last_price","trailing_stop_pct","time_exit_bars","realized_pnl")
    return [dict(zip(keys,r)) for r in rows]

def ensure_algo_position(*, exchange_segment, instrument_token, trading_symbol, strategy_version_id, entry_order_id, quantity, average_entry, stop_loss, target):
    with _connection() as conn:
        row=conn.execute("SELECT id FROM algo_positions WHERE entry_order_id=? AND status='OPEN'",(entry_order_id,)).fetchone()
        if row:return row[0]
        cur=conn.execute("INSERT INTO algo_positions(exchange_segment,instrument_token,trading_symbol,strategy_version_id,entry_order_id,quantity,average_entry,stop_loss,target,remaining_quantity) VALUES(?,?,?,?,?,?,?,?,?,?)",(exchange_segment,str(instrument_token),trading_symbol,strategy_version_id,entry_order_id,int(quantity),average_entry,stop_loss,target,int(quantity)))
        return cur.lastrowid

def record_exit_request(position_id, reason, quantity, trigger_price):
    with _connection() as conn:
        cur=conn.execute("INSERT INTO algo_exits(algo_position_id,reason,requested_quantity,trigger_price) VALUES(?,?,?,?)",(position_id,reason,int(quantity),trigger_price))
        conn.execute("UPDATE algo_positions SET exit_reason=?,exit_quantity=? WHERE id=? AND status='OPEN'",(reason,int(quantity),position_id))
        return cur.lastrowid

def mark_exit_order(position_id, internal_order_id, exit_id=None):
    with _connection() as conn:
        if exit_id is None:
            conn.execute("UPDATE algo_exits SET internal_order_id=?,status='SUBMITTED' WHERE id=(SELECT id FROM algo_exits WHERE algo_position_id=? ORDER BY id DESC LIMIT 1)",(internal_order_id,position_id))
        else:
            conn.execute("UPDATE algo_exits SET internal_order_id=?,status='SUBMITTED' WHERE id=? AND algo_position_id=?",(internal_order_id,int(exit_id),position_id))


def latest_algo_signal_for_symbol(exchange_segment, trading_symbol, instrument_token=None):
    with _connection() as conn:
        if instrument_token is not None:
            r=conn.execute("SELECT strategy_version_id,internal_order_id,signal_price,side FROM signals WHERE exchange_segment=? AND trading_symbol=? AND instrument_token=? AND internal_order_id IS NOT NULL ORDER BY id DESC LIMIT 1",(exchange_segment,trading_symbol,str(instrument_token))).fetchone()
        else:
            r=conn.execute("SELECT strategy_version_id,internal_order_id,signal_price,side FROM signals WHERE exchange_segment=? AND trading_symbol=? AND internal_order_id IS NOT NULL ORDER BY id DESC LIMIT 1",(exchange_segment,trading_symbol)).fetchone()
    return dict(zip(("strategy_version_id","internal_order_id","signal_price","side"),r)) if r else None

def has_pending_exit(position_id):
    with _connection() as conn:
        r=conn.execute("SELECT 1 FROM algo_exits WHERE algo_position_id=? AND status IN ('REQUESTED','SUBMITTING','SUBMITTED','PARTIALLY_FILLED','UNKNOWN') LIMIT 1",(position_id,)).fetchone()
    return bool(r)

def latest_closed_algo_position(strategy_version_id:int, exchange_segment:str, instrument_token:str) -> dict|None:
    with _connection() as conn:
        r=conn.execute(
            """SELECT id,closed_at FROM algo_positions
               WHERE strategy_version_id=? AND exchange_segment=? AND instrument_token=? AND status='CLOSED'
               ORDER BY id DESC LIMIT 1""",
            (int(strategy_version_id),exchange_segment,str(instrument_token))).fetchone()
    return {"id":r[0],"closed_at":r[1]} if r else None

def update_algo_position_risk(position_id: int, *, trailing_stop=None, last_price=None) -> None:
    with _connection() as conn:
        conn.execute("UPDATE algo_positions SET trailing_stop=COALESCE(?,trailing_stop), last_price=COALESCE(?,last_price) WHERE id=?",(trailing_stop,last_price,position_id))

def update_algo_position_from_broker(position_id, quantity, average_entry):
    with _connection() as conn:
        conn.execute("UPDATE algo_positions SET quantity=?,average_entry=?,remaining_quantity=?,broker_quantity=?,broker_average_entry=?,status=CASE WHEN ?=0 THEN 'CLOSED' ELSE status END,closed_at=CASE WHEN ?=0 THEN datetime('now') ELSE closed_at END WHERE id=?",(int(quantity),average_entry,int(quantity),int(quantity),average_entry,int(quantity),int(quantity),position_id))



def create_backtest(strategy_version_id: int | None, request: dict) -> int:
    with _connection() as conn:
        cur=conn.execute("INSERT INTO backtests(strategy_version_id,request_json,status) VALUES(?,?,?)",(strategy_version_id,_json(request),"RUNNING"))
        return int(cur.lastrowid)

def complete_backtest(backtest_id: int, result: dict, error: str | None = None) -> None:
    metrics={k:result.get(k) for k in ('total_trades','net_pnl','win_rate','profit_factor','max_drawdown','average_win','average_loss','gross_profit','gross_loss','expectancy','max_consecutive_losses','total_costs') if isinstance(result,dict)}
    with _connection() as conn:
        conn.execute("UPDATE backtests SET result_json=?,status=?,completed_at=datetime('now'),metrics_json=?,error_message=? WHERE id=?",(_json(result) if result is not None else _json({'error':error}),"FAILED" if error else "COMPLETED",_json(metrics),error,backtest_id))
        if error is None:
            for i,p in enumerate(result.get('equity_curve',[]) or []):
                conn.execute("INSERT OR REPLACE INTO backtest_equity_points(backtest_id,point_no,candle_at,equity,drawdown) VALUES(?,?,?,?,?)",(backtest_id,i,p.get('candle_at'),float(p.get('equity') or 0),float(p.get('drawdown') or 0)))
            for t in result.get('trades',[]):
                conn.execute("INSERT INTO backtest_trades(backtest_id,trading_symbol,entry_time,exit_time,side,quantity,entry_price,exit_price,gross_pnl,costs,net_pnl,exit_reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(backtest_id,t.get('symbol',''),t.get('entry_time'),t.get('exit_time'),t.get('side','BUY'),int(t.get('quantity') or 0),t.get('entry_price'),t.get('exit_price'),t.get('gross_pnl',0),t.get('costs',0),t.get('net_pnl',0),t.get('exit_reason')))

def list_backtests(limit: int=50) -> list[dict]:
    with _connection() as conn:
        rows=conn.execute("SELECT id,strategy_version_id,request_json,result_json,status,created_at,completed_at FROM backtests ORDER BY id DESC LIMIT ?",(max(1,min(int(limit),200)),)).fetchall()
    out=[]
    for r in rows:
        d=dict(zip(('id','strategy_version_id','request','result','status','created_at','completed_at'),r)); d['request']=json.loads(d['request'] or '{}'); d['result']=json.loads(d['result']) if d['result'] else None; out.append(d)
    return out


def apply_trade_to_algo_position(order_internal_id: str | None, fill_qty: int, fill_price: float, transaction_type: str | None) -> None:
    """Apply a fill using the immutable order chain.

    ENTRY fills resolve through orders.signal_id. EXIT fills resolve through
    orders.algo_position_id. No symbol-only position selection is permitted.
    """
    if not order_internal_id or fill_qty<=0:return
    side=(transaction_type or '').upper()
    with _connection() as conn:
        order=conn.execute(
            "SELECT id,signal_id,algo_position_id,order_role,parent_order_id FROM orders WHERE internal_order_id=?",
            (order_internal_id,)).fetchone()
        if not order:return
        _,signal_id,algo_position_id,role,parent_order_id=order

        if role=="ENTRY" and side in ('B','BUY','S','SELL'):
            pos=conn.execute("SELECT id,remaining_quantity,quantity,average_entry FROM algo_positions WHERE entry_order_id=? AND status='OPEN'",(order_internal_id,)).fetchone()
            if pos:
                total=int(pos[1] or 0)+fill_qty; old=int(pos[1] or 0); avg=float(pos[3] or fill_price)
                new_avg=((avg*old)+(fill_price*fill_qty))/total if total else fill_price
                conn.execute("UPDATE algo_positions SET quantity=?,remaining_quantity=?,average_entry=? WHERE id=?",(total,total,new_avg,pos[0]))
                return
            if signal_id is None:return
            sig=conn.execute("SELECT strategy_version_id,exchange_segment,instrument_token,trading_symbol FROM signals WHERE id=?",(signal_id,)).fetchone()
            if not sig:return
            sv=conn.execute("SELECT definition_json FROM strategy_versions WHERE id=?",(sig[0],)).fetchone()
            if not sv:return
            definition=json.loads(sv[0]); risk=definition.get('risk',{}) or {}; stop=risk.get('stop_loss'); target=risk.get('target')
            dside=str(definition.get('side','BUY')).upper()
            expected='B' if dside=='BUY' else 'S'
            if side not in (expected, 'BUY' if expected=='B' else 'SELL'): return
            if stop is None and risk.get('stop_loss_pct') is not None:
                stop=fill_price*(1-float(risk['stop_loss_pct'])/100 if dside=='BUY' else 1+float(risk['stop_loss_pct'])/100)
            if target is None and risk.get('target_pct') is not None:
                target=fill_price*(1+float(risk['target_pct'])/100 if dside=='BUY' else 1-float(risk['target_pct'])/100)
            cur=conn.execute(
                """INSERT INTO algo_positions(exchange_segment,instrument_token,trading_symbol,strategy_version_id,entry_order_id,quantity,average_entry,stop_loss,target,trailing_stop,remaining_quantity,exit_quantity,trailing_stop_pct,time_exit_bars,entry_side)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (sig[1],sig[2],sig[3],sig[0],order_internal_id,fill_qty,fill_price,stop,target,None,fill_qty,None,risk.get('trailing_stop_pct'),risk.get('time_exit_bars'),dside))
            pos_id=cur.lastrowid
            conn.execute("UPDATE orders SET algo_position_id=? WHERE internal_order_id=?",(pos_id,order_internal_id))
            return

        if role=="EXIT" and side in ('S','SELL','B','BUY') and algo_position_id:
            pos=conn.execute("SELECT remaining_quantity,average_entry,entry_side,realized_pnl FROM algo_positions WHERE id=? AND status='OPEN'",(algo_position_id,)).fetchone()
            if not pos:return
            remaining=max(0,int(pos[0] or 0)-fill_qty)
            entry_price=float(pos[1] or fill_price)
            entry_side=str(pos[2] or 'BUY').upper()
            fill_pnl=(float(fill_price)-entry_price)*fill_qty if entry_side=='BUY' else (entry_price-float(fill_price))*fill_qty
            realized_total=float(pos[3] or 0)+fill_pnl
            ex=conn.execute(
                "SELECT id,filled_quantity,requested_quantity FROM algo_exits WHERE algo_position_id=? AND internal_order_id=? ORDER BY id DESC LIMIT 1",
                (algo_position_id,order_internal_id)).fetchone()
            if ex:
                new_filled=int(ex[1] or 0)+fill_qty
                ex_status='COMPLETE' if new_filled>=int(ex[2] or 0) else 'PARTIALLY_FILLED'
                conn.execute("UPDATE algo_exits SET filled_quantity=?,status=?,completed_at=CASE WHEN ?='COMPLETE' THEN datetime('now') ELSE completed_at END WHERE id=?",
                             (new_filled,ex_status,ex_status,ex[0]))
            conn.execute(
                "UPDATE algo_positions SET remaining_quantity=?,realized_pnl=?,status=CASE WHEN ?=0 THEN 'CLOSED' ELSE status END,closed_at=CASE WHEN ?=0 THEN datetime('now') ELSE closed_at END WHERE id=?",
                (remaining,realized_total,remaining,remaining,algo_position_id))

def required_strategy_subscription_keys() -> set[tuple[str,str]]:
    """Return subscriptions that are genuinely required for LIVE execution.

    Scanner-linked strategies subscribe only to matched candidates. A strategy
    without a scanner keeps its explicit universe subscribed continuously.
    """
    required=set()
    for item in list_live_armed_strategy_versions():
        definition=item.get("definition") or {}
        scanner_ids=definition.get("scanner_ids") or []
        if scanner_ids:
            continue
        universe=definition.get("universe") or {}
        if isinstance(universe,dict):
            required.update(("nse_cm",str(t).strip()) for t in (universe.get("instrument_tokens") or []) if str(t).strip())
    for seg,tok,_vid in list_active_candidate_subscription_keys():
        required.add((seg,tok))
    return required


def list_live_armed_strategy_versions() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute("SELECT id,definition_json FROM strategy_versions WHERE is_live_armed=1 ORDER BY id").fetchall()
    return [{"id": int(r[0]), "definition": json.loads(r[1])} for r in rows]


def get_strategy_version(version_id):
    with _connection() as conn:
        r=conn.execute("SELECT id,strategy_id,version,definition_json,status,is_live_armed,created_at,updated_at,validation_errors_json FROM strategy_versions WHERE id=?",(version_id,)).fetchone()
    if not r:return None
    d=dict(zip(("id","strategy_id","version","definition_json","status","is_live_armed","created_at","updated_at","validation_errors_json"),r)); d["definition"]=json.loads(d.pop("definition_json")); d["validation_errors"]=json.loads(d.pop("validation_errors_json") or "[]"); return d
