"""LIVE-readiness gates, evaluated from real runtime state -- never assumed.

Each gate is {id, ok, blocking, detail}. `ready` is True only when every
blocking gate passes. Arming LIVE (orders actually reach Kotak) additionally
requires `ready` AND an explicit owner action (risk_settings.live_trading_armed).
Gates that can only be established by a human (first tiny live order
observed, IP whitelist etc.) are listed in LIVE_READINESS.md, not faked here.
"""
from __future__ import annotations

import datetime as _dt
import json
import os

from . import db as _db
from . import sdk_conformance
from .broker_client import sdk_ready
from .config import config
from .state import BrokerState, current_state


def _gate(id_: str, ok: bool, detail: str, blocking: bool = True) -> dict:
    return {"id": id_, "ok": bool(ok), "blocking": blocking, "detail": detail}


def _age_seconds(ts: str | None) -> float | None:
    if not ts:
        return None
    try:
        return (_dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None) - _dt.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")).total_seconds()
    except ValueError:
        return None


def evaluate(*, ignore_strategy_subscriptions: bool = False, strategy_version_id: int | None = None) -> dict:
    from .credential_manager import credential_manager
    from .websocket_manager import websocket_manager

    gates: list[dict] = []
    gates.append(_gate("live_execution_only", config.trading_mode == "LIVE", "execution=LIVE"))
    ok, why = sdk_ready()
    gates.append(_gate("sdk_installed_v3_0_7", ok, why or 'official SDK importable at required version'))
    conf = sdk_conformance.check_runtime() if ok else None
    gates.append(_gate("sdk_signatures_match", bool(conf and conf.ok), conf.summary() if conf else "SDK not importable"))
    vend = sdk_conformance.check_vendor_integrity()
    gates.append(_gate("vendored_sdk_unmodified", vend.ok, "; ".join(vend.errors) or f"{vend.checked} files match manifest",
                       blocking=True))
    gates.append(_gate("credentials_configured", credential_manager.has_base_credentials(), "Kotak credentials saved"))
    gates.append(_gate("broker_connected", current_state.state == BrokerState.CONNECTED, f"state={current_state.state.value}"))
    ws = websocket_manager.status()
    gates.append(_gate("order_feed_connected", ws["orderFeed"]["connected"], "order feed socket"))
    from .market_session import session_state
    session = session_state()
    market_ok = bool(ws["market"]["connected"]) and (not session["open"] or not ws["market"].get("stale"))
    market_detail = "market session closed; feed health will be enforced again at order time" if not session["open"] else ("SFeed connected and receiving data" if market_ok else "SFeed connected but tick stream is stale")
    gates.append(_gate("market_feed_healthy", market_ok, market_detail))
    armed = _db.list_live_armed_strategy_versions()
    actual = set(websocket_manager._subs.keys())

    # Global readiness audits every armed strategy. During a strategy-specific
    # execution/arming check, scope subscription requirements to ONLY that
    # strategy so an unrelated strategy/scanner cannot block it.
    if strategy_version_id is not None:
        target = next((item for item in armed if int(item["id"]) == int(strategy_version_id)), None)
        if target is None:
            target = _db.get_strategy_version(int(strategy_version_id))
        scoped_items = [target] if target else []
    else:
        scoped_items = armed

    required = set()
    for item in scoped_items:
        if not item:
            continue
        definition = item.get("definition") or {}
        scanner_ids = definition.get("scanner_ids") or []
        if scanner_ids:
            required.update(
                (s, t) for s, t, vid in _db.list_active_candidate_subscription_keys()
                if int(vid) == int(item["id"])
            )
        else:
            universe = definition.get("universe") or {}
            if isinstance(universe, dict):
                required.update(("nse_cm", str(t).strip()) for t in (universe.get("instrument_tokens") or []) if str(t).strip())
    missing = sorted(required - actual)
    subscriptions_ok = not missing
    scoped_has_scanner = any((item.get("definition") or {}).get("scanner_ids") for item in scoped_items if item)
    scanner_waiting = scoped_has_scanner and not required
    detail = ("waiting for scanner candidate; no dynamic subscription is required yet" if scanner_waiting and not missing
              else "all required strategy/candidate subscriptions present" if not missing
              else f"missing {len(missing)} required strategy/candidate subscription(s)")
    # During the explicit act of arming a strategy, its subscriptions do not
    # exist yet by definition. All other broker/runtime gates still apply.
    gates.append(_gate(
        "feed_subscriptions_healthy",
        subscriptions_ok and bool(ws["orderFeed"].get("connected")),
        detail,
        blocking=not ignore_strategy_subscriptions,
    ))
    scanner_rows={int(s["id"]):s for s in _db.list_scanners()}
    scanner_failures=[]
    # When arming one strategy, only that strategy's scanner authorization may
    # block it. An unrelated already-armed strategy/scanner must never prevent
    # this strategy from being armed. The unscoped readiness page retains the
    # global audit across all armed strategies.
    scanner_items = scoped_items
    for item in scanner_items:
        for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
            try: sid=int(raw_id)
            except (TypeError,ValueError): scanner_failures.append(str(raw_id)); continue
            if not scanner_rows.get(sid) or not scanner_rows[sid].get("is_active"):
                scanner_failures.append(str(sid))
    gates.append(_gate("strategy_scanners_healthy", not scanner_failures,
                       "all strategy-linked scanners are ACTIVE" if not scanner_failures else "inactive/missing scanner IDs: " + ",".join(scanner_failures)))
    gates.append(_gate("market_feed_connected", ws["market"]["connected"], "SFeed socket"))
    gates.append(_gate("emergency_stop_clear", not _db.is_emergency_stop_active(), "emergency stop"))
    rs = _db.get_risk_settings()
    missing = [k for k in ("max_order_quantity", "max_order_value", "max_orders_per_day", "max_daily_loss") if not rs.get(k)]
    gates.append(_gate("risk_limits_configured", not missing, "unset: " + ", ".join(missing) if missing else "all core limits set"))
    daily_pnl = None
    funds = _db.latest_funds_snapshot()
    if funds and funds.get("realized_mtom") is not None and funds.get("unrealized_mtom") is not None:
        daily_pnl = float(funds["realized_mtom"]) + float(funds["unrealized_mtom"])
    pnl_available = daily_pnl is not None
    gates.append(_gate("daily_loss_data_available", pnl_available if rs.get("max_daily_loss") else True, "reconciled realised+unrealised P&L available" if pnl_available else "P&L is unavailable while max_daily_loss is configured"))
    halt = _db.refresh_daily_loss_halt(current_pnl=daily_pnl, limit=rs.get("max_daily_loss"))
    gates.append(_gate("daily_loss_halt_clear", not halt["daily_loss_halted"], halt["halt_reason"] or "no latched daily-loss halt"))
    unresolved = [o["internal_order_id"] for o in _db.list_unresolved_live_orders() if o["outcome_unknown"]]
    gates.append(_gate("no_unknown_outcome_orders", not unresolved, f"{len(unresolved)} order(s) with unknown outcome" if unresolved else "none"))
    pending_submission = [o["internal_order_id"] for o in _db.list_unresolved_live_orders() if o.get("status") in ("SUBMITTING","PENDING_RECONCILE")]
    gates.append(_gate("no_pending_submission_reconciliation", not pending_submission, f"{len(pending_submission)} order(s) still require submission reconciliation" if pending_submission else "none"))
    funds = _db.latest_funds_snapshot()
    age = _age_seconds(funds["snapshot_at"]) if funds else None
    rr = _db.latest_reconciliation_run()
    rr_ok = bool(rr and rr.get("status") == "COMPLETE" and rr.get("sections_ok") and int(rr.get("discrepancy_count") or 0) == 0)
    if not rr:
        reconciliation_detail = "no successful clean reconciliation yet"
    else:
        reconciliation_detail = f"run #{rr['id']} status={rr['status']} discrepancies={rr['discrepancy_count']}"
        details = rr.get("details") or {}
        discrepancies = details.get("discrepancies") or []
        if discrepancies:
            labels=[]
            for item in discrepancies[:5]:
                kind=str(item.get("kind") or "unknown")
                ref=str(item.get("ref") or "")
                label = kind + (f"[{ref}]" if ref else "")
                bd = item.get("broker_diagnostics") or {}
                if bd:
                    parts=[]
                    if bd.get("http_status") is not None: parts.append(f"HTTP={bd['http_status']}")
                    if bd.get("kotak_st_code") is not None: parts.append(f"stCode={bd['kotak_st_code']}")
                    if bd.get("kotak_err_msg"): parts.append(f"errMsg={str(bd['kotak_err_msg'])[:180]}")
                    if bd.get("endpoint"): parts.append(f"endpoint={bd['endpoint']}")
                    if bd.get("session_auth_indication"): parts.append(f"session={bd['session_auth_indication']}")
                    if bd.get("transport_exception"): parts.append(f"transport={str(bd['transport_exception'])[:180]}")
                    if parts: label += " {" + " | ".join(parts) + "}"
                labels.append(label)
            reconciliation_detail += "; " + ", ".join(labels)
            if len(discrepancies) > 5:
                reconciliation_detail += f" (+{len(discrepancies)-5} more)"
    gates.append(_gate("recent_reconciliation", age is not None and age < 20 * 60 and rr_ok, reconciliation_detail))
    gates.append(_gate("reconciliation_sections_complete", rr_ok, reconciliation_detail if not rr_ok else "orders + trades + positions + holdings + funds all reconciled with no discrepancy"))
    tok = bool(os.environ.get("BROKER_SERVICE_TOKEN"))
    gates.append(_gate("internal_token_set", tok, "BROKER_SERVICE_TOKEN protects the broker-service API"))
    ready = all(g["ok"] for g in gates if g["blocking"])
    result = {"ready": ready, "armed": rs["live_trading_armed"], "gates": gates,
              "live_orders_can_be_sent": ready and rs["live_trading_armed"]}
    try:
        _db.record_live_readiness(ready, {"gates": gates})
    except Exception:  # noqa: BLE001
        pass
    return result
