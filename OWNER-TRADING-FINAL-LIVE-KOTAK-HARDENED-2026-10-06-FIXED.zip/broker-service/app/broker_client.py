"""Session owner for the official Kotak Neo SDK (v3.0.7).

This module owns exactly one authenticated `KotakSdk` (see sdk_adapter.py,
the only module that imports `neo_api_client`) for the process lifetime and
drives the state machine. It contains NO legacy v2 calls, NO guessed
parameter names; every executable order is routed to the official Kotak SDK
(see order_service.py), and every method here talks to the real SDK.

Authentication runs only through the single verified connect path. That path
may be invoked explicitly by /connect or automatically by the persistent service
on startup/session recovery when saved credentials exist. CONNECTED is reported
only after: totp_login OK -> totp_validate OK -> a Trade session (edit_token +
edit_sid) exists -> a read-only limits() call is accepted by the broker.
"""
from __future__ import annotations

import asyncio
import logging

from . import sdk_adapter, sdk_conformance
from .config import config
from .sdk_adapter import AUTH, UNKNOWN, KotakSdk, Outcome
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.broker_client")


class NotConfiguredError(RuntimeError):
    """No usable broker session. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """A state-changing broker call was attempted while LIVE is not allowed.
    Enforced here independently of the Express middleware (defence in depth)."""


def sdk_ready() -> tuple[bool, str]:
    """(ok, reason). The official SDK must import AND be the pinned version."""
    if not sdk_adapter.SDK_AVAILABLE:
        return False, f"Official kotakneoapi SDK is not importable: {sdk_adapter.SDK_IMPORT_ERROR}"
    v = sdk_adapter.SDK_VERSION
    if v is not None and v != sdk_adapter.REQUIRED_SDK_VERSION:
        return False, f"Installed SDK is {v}; this service is built and verified against {sdk_adapter.REQUIRED_SDK_VERSION}."
    return True, ""


def assert_live_trading_allowed(*, exclude_internal_order_id: str | None = None, allow_controlled_exit: bool = False, instrument_token: str | None = None, trading_symbol: str | None = None, exchange_segment: str | None = None) -> None:
    """Canonical defense-in-depth LIVE gate. Entries require every blocking readiness
    condition; controlled exits may bypass ONLY emergency-stop/arming so an existing
    position can still be flattened, but all broker/session/reconciliation/feed gates remain.
    """
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("LIVE execution is not available.")
    if _db.is_emergency_stop_active() and not allow_controlled_exit:
        raise LiveTradingBlockedError("Emergency stop is active; new exposure is blocked.")
    if current_state.state != BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")
    if not allow_controlled_exit and not _db.is_live_armed():
        raise LiveTradingBlockedError("LIVE trading has not been armed by the owner (Risk page).")
    # Strategy orders have a second, strategy-specific permission boundary.
    # A stale signal must never submit after its strategy was disarmed, its
    # scanner candidate disappeared, or the candidate subscription failed.
    if not allow_controlled_exit and exclude_internal_order_id:
        local_order = _db.get_order(exclude_internal_order_id)
        if local_order and local_order.get("order_role") == "ENTRY" and local_order.get("signal_id"):
            ctx = _db.get_signal_strategy_context(int(local_order["signal_id"]))
            if not ctx:
                raise LiveTradingBlockedError("Strategy signal context is missing; LIVE entry blocked.")
            version = _db.get_strategy_version(int(ctx["strategy_version_id"]))
            if not version or not version.get("is_live_armed"):
                raise LiveTradingBlockedError("Strategy is no longer LIVE armed; stale entry blocked.")
            definition = version.get("definition") or {}
            raw_scanner_ids = definition.get("scanner_ids")
            if raw_scanner_ids is not None and not isinstance(raw_scanner_ids, list):
                raise LiveTradingBlockedError("Stored strategy scanner_ids are malformed; LIVE entry blocked.")
            scanner_ids = []
            for raw_id in (raw_scanner_ids or []):
                if isinstance(raw_id, bool):
                    raise LiveTradingBlockedError("Stored strategy scanner_ids contain an invalid ID; LIVE entry blocked.")
                text = str(raw_id).strip()
                if not text.isdigit() or int(text) <= 0:
                    raise LiveTradingBlockedError("Stored strategy scanner_ids contain an invalid ID; LIVE entry blocked.")
                scanner_ids.append(int(text))
            if scanner_ids:
                candidates = _db.active_candidates_for_strategy_instrument(
                    strategy_version_id=int(ctx["strategy_version_id"]),
                    exchange_segment=str(ctx["exchange_segment"]),
                    instrument_token=str(ctx["instrument_token"]),
                    subscribed_only=True,
                )
                if not candidates:
                    raise LiveTradingBlockedError("Strategy candidate is no longer active/subscribed; LIVE entry blocked.")
                active_scanners={int(s["id"]) for s in _db.list_scanners() if s.get("is_active")}
                if not any(int(c["scanner_id"]) in active_scanners for c in candidates):
                    raise LiveTradingBlockedError("Strategy scanner is no longer active; LIVE entry blocked.")
            else:
                allowed = {str(x).strip() for x in ((definition.get("universe") or {}).get("instrument_tokens") or [])}
                if str(ctx["instrument_token"]) not in allowed:
                    raise LiveTradingBlockedError("Instrument is outside the strategy's configured LIVE universe.")
    if not allow_controlled_exit:
        rs = _db.get_risk_settings()
        if rs.get("max_daily_loss"):
            funds = _db.latest_funds_snapshot()
            if not funds or funds.get("realized_mtom") is None or funds.get("unrealized_mtom") is None:
                raise LiveTradingBlockedError("Reconciled P&L is unavailable while max_daily_loss is configured; LIVE entry blocked.")
            pnl = float(funds["realized_mtom"]) + float(funds["unrealized_mtom"])
            halt = _db.refresh_daily_loss_halt(current_pnl=pnl, limit=rs.get("max_daily_loss"))
            if halt["daily_loss_halted"]:
                raise LiveTradingBlockedError(halt["halt_reason"] or "Global daily-loss halt is active.")
    # Vendor integrity is a hard LIVE prerequisite.
    vend = sdk_conformance.check_vendor_integrity()
    if not vend.ok:
        raise LiveTradingBlockedError("Vendored official Kotak SDK integrity check failed: " + "; ".join(vend.errors[:3]))
    # The latest clean broker reconciliation is mandatory, not merely advisory.
    rr = _db.latest_reconciliation_run()
    if not rr or rr.get("status") != "COMPLETE" or not rr.get("sections_ok") or int(rr.get("discrepancy_count") or 0) != 0:
        raise LiveTradingBlockedError("Latest broker reconciliation is not clean; LIVE execution is blocked.")
    # Final feed-health gate: entries require both sockets plus a fresh price
    # for the exact instrument. A disconnected/stale feed must never allow a
    # market order to be emitted on an old price. Controlled exits keep working
    # through a market-feed outage so an existing position can still be flattened.
    if not allow_controlled_exit:
        from .websocket_manager import websocket_manager
        ws = websocket_manager.status()
        if not ws["market"].get("connected"):
            raise LiveTradingBlockedError("Market SFeed is not connected; LIVE entry blocked.")
        if not ws["orderFeed"].get("connected"):
            raise LiveTradingBlockedError("Order feed is not connected; LIVE entry blocked.")
        if instrument_token and trading_symbol:
            from .market_prices import fresh_ltp
            if fresh_ltp(instrument_token, trading_symbol, exchange_segment) is None:
                raise LiveTradingBlockedError("Exact instrument market feed is stale or missing; LIVE entry blocked.")

    # Defense-in-depth: every state-changing LIVE path also requires a recent
    # reconciliation and no unresolved broker outcome. This intentionally does
    # not call the full readiness evaluator here (which can recurse through the
    # broker client); the critical durable gates are checked directly.
    unresolved=[o for o in _db.list_unresolved_live_orders() if (o.get("outcome_unknown") or o.get("status") in ("SUBMITTING","PENDING_RECONCILE")) and o.get("internal_order_id") != exclude_internal_order_id]
    if unresolved:
        raise LiveTradingBlockedError(f"{len(unresolved)} LIVE order(s) require reconciliation before another order can be sent.")
    funds=_db.latest_funds_snapshot()
    if not funds:
        raise LiveTradingBlockedError("No broker funds reconciliation snapshot is available.")
    try:
        from .live_readiness import _age_seconds
        age=_age_seconds(funds.get("snapshot_at"))
        if age is None or age >= 20*60:
            raise LiveTradingBlockedError("Broker reconciliation snapshot is stale; reconcile before LIVE execution.")
    except LiveTradingBlockedError:
        raise
    except Exception:
        raise LiveTradingBlockedError("Broker reconciliation freshness could not be verified.")


class BrokerClient:
    def __init__(self) -> None:
        self._sdk: KotakSdk | None = None
        # connect/test/disconnect/reconnect are serialised: two overlapping
        # requests must never race on the SDK session or state machine.
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ #
    # Session
    # ------------------------------------------------------------------ #
    def is_connected(self) -> bool:
        return self._sdk is not None and current_state.state in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        )

    @property
    def sdk(self) -> KotakSdk | None:
        return self._sdk

    async def _login(self) -> tuple[Outcome, KotakSdk | None]:
        from .credential_manager import credential_manager

        ok, reason = sdk_ready()
        if not ok:
            return Outcome(UNKNOWN, message=reason, code="SDK"), None
        creds = credential_manager.get()
        if not credential_manager.has_base_credentials() or creds is None:
            return Outcome("REJECTED", message="Credentials have not been saved yet.", code="NOT_CONFIGURED"), None
        totp = credential_manager.current_totp_code()
        if not totp:
            return Outcome("REJECTED", message="Could not generate a TOTP code (no secret saved or pyotp unavailable).", code="TOTP"), None
        loop = asyncio.get_running_loop()
        try:
            sdk = KotakSdk(creds.consumer_key, config.environment)
            outcome = await loop.run_in_executor(
                None, lambda: sdk.login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp, mpin=creds.mpin)
            )
        except Exception as exc:  # noqa: BLE001 -- transport/SDK failure is a connection error, not a rejection
            return Outcome(UNKNOWN, message=f"login failed: {type(exc).__name__}", code="TRANSPORT_ERROR"), None
        if not outcome.ok:
            return outcome, None
        # Read-only verification: the broker must accept the new session.
        try:
            verify = await loop.run_in_executor(None, sdk.limits)
        except Exception as exc:  # noqa: BLE001
            return Outcome(UNKNOWN, message=f"read-only verification (limits) failed: {type(exc).__name__}", code="TRANSPORT_ERROR"), None
        if not verify.ok:
            return Outcome("REJECTED", message=f"Session established but limits() was not accepted: {verify.message}",
                           code="SESSION_VERIFICATION_FAILED"), None
        return outcome, sdk

    async def connect(self) -> dict:
        async with self._lock:
            return await self._connect_locked()

    async def _connect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session
        from .credential_manager import credential_manager

        if not credential_manager.has_base_credentials():
            current_state.transition(BrokerState.NOT_CONFIGURED, "Credentials have not been saved yet.")
            return current_state.as_dict()
        current_state.transition(BrokerState.VERIFYING)
        outcome, sdk = await self._login()
        if sdk is None:
            self._sdk = None
            target = BrokerState.CONNECTION_ERROR if outcome.kind == UNKNOWN else BrokerState.AUTH_FAILED
            current_state.transition(target, (outcome.message or "Authentication failed.")[:300])
            return current_state.as_dict()

        self._sdk = sdk
        dc = sdk.data_center()
        _session.mark_session_established(dc)
        try:
            from .credential_manager import credential_manager as _cm
            _cm.set_startup_auto_connect(True)
        except Exception:
            logger.warning("Could not persist broker startup-connect intent.")
        _db.record_reconciliation(
            reconciliation_type="connect", reference_id=credential_manager.get().ucc,
            discrepancy_found=False, details={"data_center": dc, "verification_call": "limits"},
        )
        # Best-effort layers on top of an already-verified REST session.
        try:
            from . import reconciliation as _reconciliation
            await _reconciliation.run_full_reconciliation()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Post-connect reconciliation failed (state remains CONNECTED): %s", exc)
        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.restore_armed_strategy_subscriptions()
            feed_boot = await _wsm.websocket_manager.ensure_started_and_wait(timeout=15.0)
            if not feed_boot.get("ready"):
                logger.warning(
                    "Broker REST session is connected but initial LIVE feeds are not both ready yet: market=%s order=%s; supervisor will continue recovery.",
                    feed_boot.get("market"), feed_boot.get("order"),
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("WebSocket start/recovery failed after connect (REST-only): %s", exc)
        return current_state.as_dict()

    async def test_connection(self) -> dict:
        async with self._lock:
            outcome, sdk = await self._login()
            if sdk is not None:
                try:
                    await asyncio.get_running_loop().run_in_executor(None, sdk.logout)
                except Exception:  # noqa: BLE001 -- test result already known
                    pass
                return {"success": True}
            return {"success": False, "error": (outcome.message or "Test failed.")[:300], "code": outcome.code}

    async def disconnect(self) -> dict:
        async with self._lock:
            return await self._disconnect_locked()

    async def _disconnect_locked(self) -> dict:
        from . import db as _db
        from . import session as _session

        try:
            from . import websocket_manager as _wsm
            await _wsm.websocket_manager.stop()
        except Exception:  # noqa: BLE001
            pass
        if self._sdk is not None:
            try:
                await asyncio.get_running_loop().run_in_executor(None, self._sdk.logout)
            except Exception:  # noqa: BLE001
                pass
        self._sdk = None
        _session.current_session.established_at = None
        try:
            from .credential_manager import credential_manager as _cm
            _cm.set_startup_auto_connect(False)
        except Exception:
            pass
        try:
            _db.record_session_ended()
        except Exception:  # noqa: BLE001
            pass
        current_state.transition(BrokerState.DISCONNECTED)
        return current_state.as_dict()

    async def reconnect(self) -> dict:
        async with self._lock:
            await self._disconnect_locked()
            return await self._connect_locked()

    # ------------------------------------------------------------------ #
    # Calls (synchronous; run in an executor by callers)
    # ------------------------------------------------------------------ #
    def _require_connected(self) -> KotakSdk:
        if self._sdk is None or current_state.state not in (
            BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING,
        ):
            raise NotConfiguredError(f"Broker is not connected (state: {current_state.state.value}).")
        return self._sdk

    def _after(self, outcome: Outcome) -> Outcome:
        """A broker answer that says the session is invalid downgrades our
        state immediately instead of waiting for a TTL guess."""
        if outcome.kind == AUTH and current_state.state in (BrokerState.CONNECTED, BrokerState.RECONCILING):
            from . import session as _session
            logger.warning("Broker reported an invalid/absent session; marking SESSION_EXPIRED.")
            _session.mark_session_expired()
        return outcome

    def _metadata_sdk(self) -> KotakSdk:
        """Create a consumer-key-only SDK for official metadata APIs.

        Kotak documents scrip_master()/search_scrip() as APIs that do not require
        completed TOTP/MPIN 2FA. Keeping these reads independent from the trade
        session prevents an expired order session from incorrectly blocking
        instrument discovery/metadata refresh.
        """
        from .credential_manager import credential_manager
        creds = credential_manager.get()
        if not creds or not creds.consumer_key:
            raise NotConfiguredError("Kotak consumer key is not configured.")
        return KotakSdk(creds.consumer_key, config.environment)

    def read(self, method: str, *args, **kwargs) -> Outcome:
        """Read-only SDK call by adapter method name."""
        allowed = {
            "order_report", "order_history", "trade_report", "positions", "holdings", "limits",
            "margin_required", "quotes", "scrip_master", "search_scrip", "whatsmyip",
            "expiries", "option_chain", "historical_data",
        }
        if method not in allowed:
            raise ValueError(f"{method} is not a permitted read call.")
        if method in ("scrip_master", "search_scrip"):
            # Reuse the persistent session when it exists (avoids needless SDK
            # instances). If it does not, these official consumer-key-only APIs
            # may still run through an ephemeral metadata SDK.
            if self._sdk is not None and current_state.state in (
                BrokerState.CONNECTED, BrokerState.RECONNECTING, BrokerState.RECONCILING
            ):
                sdk = self._sdk
            else:
                sdk = self._metadata_sdk()
        else:
            sdk = self._require_connected()
        return self._after(getattr(sdk, method)(*args, **kwargs))

    def place_order(self, req: sdk_adapter.OrderRequest, *, internal_order_id: str | None = None, allow_controlled_exit: bool = False, instrument_token: str | None = None) -> Outcome:
        # The local order row is deliberately created BEFORE this broker call.
        # Exclude that one durable SUBMITTING row from the gate so the safety
        # check does not block the very order it is validating. All other
        # pending/unknown submissions remain a hard block.
        assert_live_trading_allowed(exclude_internal_order_id=internal_order_id, allow_controlled_exit=allow_controlled_exit,
                                     instrument_token=instrument_token, trading_symbol=req.trading_symbol, exchange_segment=req.exchange_segment)
        if instrument_token and not allow_controlled_exit:
            # Market orders have no execution price. Resolve a fresh reference
            # only for broker margin validation; the actual order remains MKT.
            ref = req.price or req.trigger_price
            if ref is None:
                from .market_prices import fresh_ltp
                ref = fresh_ltp(instrument_token, req.trading_symbol, req.exchange_segment)
            if ref is None or float(ref) <= 0:
                raise LiveTradingBlockedError("LIVE entry margin cannot be verified because no fresh reference price is available.")
            margin = self.read("margin_required", exchange_segment=req.exchange_segment, price=ref,
                               order_type=req.order_type, product=req.product, quantity=req.quantity,
                               instrument_token=instrument_token, transaction_type=req.transaction_type,
                               trigger_price=req.trigger_price)
            if margin.kind != sdk_adapter.OK:
                raise LiveTradingBlockedError("Kotak margin_required failed; LIVE entry blocked.")
            from .order_service import _extract_margin_required
            required_margin = _extract_margin_required(margin.data)
            from . import db as _db
            funds = _db.latest_funds_snapshot()
            if not funds or funds.get("available_margin") is None or required_margin is None:
                raise LiveTradingBlockedError("Available margin or Kotak required margin is unavailable; LIVE entry blocked.")
            if required_margin > float(funds["available_margin"]):
                raise LiveTradingBlockedError(f"Required margin {required_margin:.2f} exceeds available margin {float(funds['available_margin']):.2f}.")
        return self._after(self._require_connected().place_order(req))

    def modify_order(self, **kwargs) -> Outcome:
        internal_order_id=kwargs.pop("internal_order_id", None)
        instrument_token=kwargs.pop("instrument_token", None)
        trading_symbol=kwargs.pop("trading_symbol", None)
        exchange_segment=kwargs.pop("exchange_segment", None)
        assert_live_trading_allowed(
            exclude_internal_order_id=internal_order_id,
            instrument_token=instrument_token,
            trading_symbol=trading_symbol,
            exchange_segment=exchange_segment,
        )
        return self._after(self._require_connected().modify_order(**kwargs))

    def cancel_order(self, **kwargs) -> Outcome:
        # Cancellation reduces exposure and must remain available while an
        # emergency stop or global LIVE arm is active/off. The controlled-exit
        # gate still requires a connected broker, intact SDK, clean reconciliation
        # and fresh broker state.
        assert_live_trading_allowed(allow_controlled_exit=True)
        return self._after(self._require_connected().cancel_order(**kwargs))

    def create_market_feed(self, **kwargs):
        return self._require_connected().create_market_feed(**kwargs)

    def create_order_feed(self, **kwargs):
        return self._require_connected().create_order_feed(**kwargs)


broker_client = BrokerClient()
