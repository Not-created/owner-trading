"""Historical backtest orchestration.

This layer owns the broker's historical-data window limits.  It fetches the
requested date range in documented-size chunks, merges/deduplicates the
result, persists candles into the existing SQLite candle cache, and then
hands one clean chronological dataset to the pure strategy engine.

No broker order path is reachable from this module.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import json

from . import db, strategy_engine

ENGINE_VERSION = "OT-BACKTEST-12.0"

# Kotak historical_data() limits used by this application.  A chunk is one
# calendar-day window and is kept one day below the documented inclusive
# maximum to avoid an off-by-one rejection at the API boundary.
HISTORICAL_MAX_DAYS = {
    "1m": 30, "3m": 30, "5m": 30,
    "10m": 60, "15m": 60, "30m": 90, "1h": 90,
    "1d": 180, "W": 180,
}
# The UI exposes these interval aliases as 1m/3m/5m/.../1d.
INTERVAL_ALIASES = {
    "1m": "1min", "3m": "3min", "5m": "5min",
    "10m": "10min", "15m": "15min", "30m": "30min", "1h": "60min", "1d": "D", "W": "W",
}


def _hash_rows(rows):
    canonical = json.dumps(rows, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(canonical).hexdigest()


def _parse_date(value: str, field: str) -> dt.date:
    try:
        return dt.date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        raise ValueError(f"{field} must be YYYY-MM-DD.")


def _default_range(timeframe: str) -> tuple[str, str]:
    days = HISTORICAL_MAX_DAYS.get(timeframe, 30)
    end = dt.date.today()
    start = end - dt.timedelta(days=days - 1)
    return start.isoformat(), end.isoformat()


def _extract_candles(data):
    """Accept the documented Kotak response shape and safe list variants."""
    if isinstance(data, dict):
        if isinstance(data.get("data"), dict):
            nested = data["data"]
            if isinstance(nested.get("candles"), list):
                return nested["candles"]
            if isinstance(nested.get("data"), list):
                return nested["data"]
        if isinstance(data.get("candles"), list):
            return data["candles"]
        if isinstance(data.get("data"), list):
            return data["data"]
    return data if isinstance(data, list) else []


def _normalise_candle(row):
    # Official historical_data() returns arrays:
    # [timestamp, open, high, low, close, volume, ...]
    if isinstance(row, (list, tuple)) and len(row) >= 6:
        ts, op, hi, lo, cl, vol = row[:6]
    elif isinstance(row, dict):
        ts = row.get("datetime") or row.get("timestamp") or row.get("date") or row.get("time")
        op, hi, lo, cl = row.get("open"), row.get("high"), row.get("low"), row.get("close")
        vol = row.get("volume") or row.get("vol") or 0
    else:
        return None
    try:
        if not str(ts).strip():
            return None
        # Preserve the broker timestamp verbatim. The backtest runner performs
        # the strict timestamp validation before simulation; the Market Data
        # route may legitimately be used to display broker-provided raw rows.
        return {
            "candle_at": str(ts),
            "open": float(op), "high": float(hi), "low": float(lo),
            "close": float(cl), "volume": float(vol or 0),
        }
    except (TypeError, ValueError):
        return None


def _parse_candle_timestamp(value):
    """Parse Kotak candle timestamps across the SDK's common ISO variants.

    Kotak normally returns an IST offset such as
    ``2026-08-17T09:15:00+05:30``.  Cached rows can also originate from older
    runtime versions that stored a space separator, ``+0530`` or ``Z``.
    Normalize only for validation/sorting; the stored broker timestamp remains
    untouched.
    """
    text = str(value or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    candidates = [text, text.replace("Z", "+00:00")]
    # Python 3.10+ handles the ISO offset form, while these fallbacks make the
    # cache tolerant of older broker/runtime representations.
    for candidate in candidates:
        try:
            return dt.datetime.fromisoformat(candidate)
        except (TypeError, ValueError):
            pass
    for fmt in (
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
    ):
        try:
            return dt.datetime.strptime(text, fmt)
        except (TypeError, ValueError):
            pass
    raise ValueError(f"unsupported timestamp format: {text}")


def _dedupe_sort(candles, *, validate_timestamps=True):
    out = {}
    for c in candles:
        if not isinstance(c, dict):
            continue
        try:
            raw = str(c["candle_at"]).strip()
            if not raw:
                continue
            if validate_timestamps:
                parsed = _parse_candle_timestamp(raw)
                # Normalize timezone-aware timestamps to UTC before deduplication.
                # The broker/cache can represent the same candle as IST (+05:30)
                # or UTC (Z); lexicographic/offset-preserving keys would keep both
                # and double-count one candle. Naive legacy rows retain their local
                # representation because their timezone is unknowable.
                if parsed.tzinfo is not None:
                    parsed = parsed.astimezone(dt.timezone.utc)
                key = parsed.isoformat()
            else:
                # Market Data is a raw broker-data display path; preserve an
                # otherwise valid broker row even if a test/legacy source uses
                # a non-ISO timestamp. Backtest validation remains strict via
                # validate_timestamps=True.
                key = raw
            c = dict(c)
            c["candle_at"] = raw
            out[key] = c
        except (KeyError, TypeError, ValueError):
            if validate_timestamps:
                # Malformed cache rows must never poison a new backtest request.
                continue
            continue
    return [out[k] for k in sorted(out)]


async def _fetch_chunks(seg, token, timeframe, frm, to, symbol):
    from .broker_client import broker_client

    interval = INTERVAL_ALIASES.get(timeframe, timeframe)
    max_days = HISTORICAL_MAX_DAYS[timeframe]
    # Use max_days-1 because both endpoints are inclusive at the API boundary.
    span = dt.timedelta(days=max_days - 1)
    cursor = frm
    all_rows = []
    chunks = []

    while cursor <= to:
        chunk_end = min(cursor + span, to)
        from_s, to_s = cursor.isoformat(), chunk_end.isoformat()
        out = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda a=from_s, b=to_s: broker_client.read(
                "historical_data",
                neosymbol=f"{seg}|{token}",
                interval=interval,
                from_date=a,
                to_date=b,
            ),
        )
        if not out.ok:
            return None, {
                "error": out.message or "Kotak historical_data failed.",
                "failed_from": from_s, "failed_to": to_s,
                "chunks_completed": len(chunks),
            }
        rows = _extract_candles(out.data)
        parsed = []
        for raw in rows:
            c = _normalise_candle(raw)
            if c:
                parsed.append(c)
        if parsed:
            db.upsert_candles([{
                "exchange_segment": seg, "instrument_token": token, "trading_symbol": symbol,
                "timeframe": timeframe, **c,
            } for c in parsed])
        all_rows.extend(parsed)
        chunks.append({"from_date": from_s, "to_date": to_s, "candles": len(parsed)})
        cursor = chunk_end + dt.timedelta(days=1)

    return all_rows, {"chunks": chunks, "chunk_count": len(chunks)}


def _filter_range(candles, frm, to):
    """Filter by the candle's local calendar date after timestamp parsing.

    Do not compare raw timestamp strings: timezone offsets and legacy space
    separators make lexicographic date checks brittle.
    """
    out = []
    for c in candles:
        try:
            day = _parse_candle_timestamp(c.get("candle_at")).date().isoformat()
            if frm <= day <= to:
                out.append(c)
        except (TypeError, ValueError):
            continue
    return out


async def fetch_historical_range(seg, token, interval, frm, to, symbol=""):
    """Public chunked historical-data helper for the Market Data page.

    Returns the same candle-array concept as Kotak's response, plus fetch
    metadata. It is read-only with respect to the broker and only populates the
    existing local candle cache.
    """
    raw_to_internal={
        "1min":"1m","3min":"3m","5min":"5m","10min":"10m",
        "15min":"15m","30min":"30m","60min":"1h","D":"1d","W":"W",
    }
    timeframe=raw_to_internal.get(str(interval), str(interval))
    if timeframe not in HISTORICAL_MAX_DAYS:
        raise ValueError(f"Unsupported historical interval: {interval}")
    start=_parse_date(frm,"from_date")
    end=_parse_date(to,"to_date")
    if start>end:
        raise ValueError("from_date cannot be after to_date.")
    rows,meta=await _fetch_chunks(str(seg),str(token),timeframe,start,end,str(symbol or token))
    if rows is None:
        raise RuntimeError(meta.get("error") or "Historical data request failed.")
    rows=_dedupe_sort(rows, validate_timestamps=False)
    return rows,meta


def _data_quality(candles, timeframe, requested_from, requested_to):
    """Return deterministic quality metadata without treating weekends/holidays as gaps."""
    minute_map={"1m":1,"3m":3,"5m":5,"10m":10,"15m":15,"30m":30,"1h":60,"1d":1440}
    step=minute_map.get(timeframe)
    timestamps=[]; malformed=0
    for c in candles:
        try: timestamps.append(_parse_candle_timestamp(c["candle_at"]))
        except (KeyError,TypeError,ValueError): malformed+=1
    timestamps=sorted(timestamps)
    gaps=[]
    if step and timestamps:
        expected=dt.timedelta(minutes=step)
        for a,b in zip(timestamps,timestamps[1:]):
            delta=b-a
            # Ignore ordinary overnight/weekend gaps by only flagging large gaps
            # inside the same local trading day.
            try:
                az=a.astimezone(dt.timezone(dt.timedelta(hours=5,minutes=30))) if a.tzinfo else a
                bz=b.astimezone(dt.timezone(dt.timedelta(hours=5,minutes=30))) if b.tzinfo else b
            except Exception:
                az,bz=a,b
            if az.date()==bz.date() and delta > expected*2:
                gaps.append({"from":a.isoformat(),"to":b.isoformat(),"minutes":int(delta.total_seconds()/60)})
    return {
        "rows":len(candles),"malformed_timestamps":malformed,
        "duplicate_rows_removed":0,
        "intraday_gaps":gaps[:25],"intraday_gap_count":len(gaps),
        "from_date":requested_from,"to_date":requested_to,
    }


async def run(payload):
    try:
        sid = int(payload.get("strategy_id") or 0)
        requested_version_id = int(payload.get("strategy_version_id") or 0)
    except (TypeError,ValueError):
        return 400,{"error":"strategy_id and strategy_version_id must be integers."}
    if sid < 0 or requested_version_id < 0:
        return 400,{"error":"strategy_id and strategy_version_id cannot be negative."}
    definition = payload.get("definition")

    if not definition and sid:
        st = db.get_strategy(sid)
        if st and st["versions"]:
            chosen = next((v for v in st["versions"] if int(v["id"]) == requested_version_id), None) if requested_version_id else None
            if requested_version_id and not chosen:
                return 400, {"error": "strategy_version_id does not belong to strategy_id"}
            definition = (chosen or st["versions"][0])["definition"]
    if not isinstance(definition, dict):
        return 400, {"error": "strategy_id or definition is required"}

    strategy_version_id = None
    if sid:
        st = db.get_strategy(sid)
        if st and st["versions"]:
            chosen = next((v for v in st["versions"] if int(v["id"]) == requested_version_id), None) if requested_version_id else None
            if requested_version_id and not chosen:
                return 400, {"error": "strategy_version_id does not belong to strategy_id"}
            strategy_version_id = (chosen or st["versions"][0])["id"]

    errors = strategy_engine.validate_strategy(definition)
    if errors:
        return 422, {"error": "Invalid strategy definition", "validation_errors": errors}

    seg = str(payload.get("exchange_segment") or "nse_cm").strip().lower()
    from . import sdk_adapter
    if seg not in sdk_adapter.EXCHANGE_SEGMENTS:
        return 400,{"error":f"exchange_segment must be one of {list(sdk_adapter.EXCHANGE_SEGMENTS)}."}
    if seg in sdk_adapter.HISTORICAL_UNSUPPORTED_SEGMENTS:
        return 400,{"error":f"Historical data is not supported for {seg}."}
    token = str(payload.get("instrument_token") or "").strip()
    if not token.isdigit() or int(token) <= 0:
        return 400,{"error":"instrument_token must be a positive integer token."}
    symbol = str(payload.get("trading_symbol") or token).strip()
    if not symbol:
        return 400,{"error":"trading_symbol cannot be empty."}
    timeframe = str(payload.get("timeframe") or definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return 400, {"error": "Unsupported backtest timeframe."}
    definition_timeframe = str(definition.get("timeframe") or timeframe)
    if definition_timeframe not in strategy_engine.TIMEFRAMES:
        return 400, {"error": "Strategy definition timeframe is unsupported."}
    # Historical candles and strategy evaluation must use the same timeframe.
    # The previous UI allowed a 15m strategy to be simulated on a 5m dataset,
    # which silently changed indicator/candle semantics and could produce a
    # misleading zero-trade result. Resampling is not implicit.
    if definition_timeframe != timeframe:
        return 400, {
            "error": "Backtest timeframe does not match the strategy timeframe.",
            "strategy_timeframe": definition_timeframe,
            "dataset_timeframe": timeframe,
            "detail": "Select the same timeframe in the historical dataset or change the strategy definition before running."
        }
    if not token or "|" in token:
        return 400, {"error": "instrument_token is required and must be a token only."}

    try:
        quantity_raw = payload.get("quantity") if payload.get("quantity") not in (None, "") else 1
        if isinstance(quantity_raw, bool) or int(quantity_raw) != float(quantity_raw) or int(quantity_raw) <= 0:
            raise ValueError
        quantity = int(quantity_raw)
        slippage = float(payload.get("slippage") or 0)
        fees = float(payload.get("fees") or 0)
        initial_capital = float(payload.get("initial_capital") or 100000)
    except (TypeError, ValueError):
        return 400, {"error": "slippage, fees and initial_capital must be numeric."}
    if slippage < 0 or slippage > 0.10:
        return 400, {"error": "slippage must be between 0 and 0.10 (10%)."}
    if fees < 0:
        return 400, {"error": "fees cannot be negative."}
    cost_model=payload.get("cost_model") or {}
    if not isinstance(cost_model,dict):
        return 400, {"error": "cost_model must be an object."}
    for key in ("entry_brokerage","exit_brokerage","stt_sell_pct","exchange_txn_pct","sebi_pct","gst_pct","stamp_duty_buy_pct"):
        try:
            value=float(cost_model.get(key,0) or 0)
        except (TypeError,ValueError):
            return 400, {"error": f"cost_model.{key} must be numeric."}
        if value < 0:
            return 400, {"error": f"cost_model.{key} cannot be negative."}
    if initial_capital <= 0:
        return 400, {"error": "initial_capital must be greater than 0."}

    frm_raw, to_raw = payload.get("from_date"), payload.get("to_date")
    if frm_raw or to_raw:
        if not frm_raw or not to_raw:
            return 400, {"error": "from_date and to_date are both required."}
        try:
            frm, to = _parse_date(frm_raw, "from_date"), _parse_date(to_raw, "to_date")
        except ValueError as exc:
            return 400, {"error": str(exc)}
    else:
        frm_s, to_s = _default_range(timeframe)
        frm, to = dt.date.fromisoformat(frm_s), dt.date.fromisoformat(to_s)

    if frm > to:
        return 400, {"error": "from_date cannot be after to_date."}

    # Always fetch the requested range from Kotak in bounded chunks. Add a
    # bounded indicator warm-up before from_date so EMA/RSI/ATR conditions are
    # not calculated from an artificially short history.
    bars_per_day={"1m":375,"3m":125,"5m":75,"10m":37,"15m":25,"30m":13,"1h":6,"60m":6,"1d":1}.get(timeframe,1)
    warmup_days=max(2,int((220+bars_per_day-1)//bars_per_day))
    fetch_from=frm-dt.timedelta(days=warmup_days)
    fetched, fetch_meta = await _fetch_chunks(seg, token, timeframe, fetch_from, to, symbol)
    if fetched is None:
        return 502, fetch_meta

    # Include already-cached rows as a fallback and deduplicate the combined
    # dataset. This is useful after a partial network failure/retry.
    cached = db.recent_candles(seg, token, timeframe, 1000)
    candles = _dedupe_sort(_filter_range(cached + fetched, fetch_from.isoformat(), to.isoformat()))
    requested_candles = _filter_range(candles, frm.isoformat(), to.isoformat())

    if len(requested_candles) < 20:
        return 400, {
            "error": "Not enough historical candles in the requested date range.",
            "detail": "Kotak returned fewer than 20 usable candles after the requested range was fetched.",
            "candles": len(requested_candles),
            "requested": {"from_date": frm.isoformat(), "to_date": to.isoformat(), "timeframe": timeframe},
            "fetch": fetch_meta,
        }

    # A backtest definition can use indicators such as EMA200.  Keep enough
    # history for indicator warm-up while executing only the requested range.
    # `_dedupe_sort()` already removes malformed cached timestamps.  Validate
    # the resulting dataset with the same tolerant parser so valid Kotak IST
    # timestamps such as 2026-08-17T09:15:00+05:30 never fail merely because
    # the row came from the warm-up period.
    invalid = []
    for c in candles:
        try:
            _parse_candle_timestamp(c["candle_at"])
        except (KeyError, TypeError, ValueError):
            invalid.append(c.get("candle_at"))
            if len(invalid) >= 3:
                break
    if invalid:
        return 400, {"error": f"Invalid historical candle timestamp: {invalid[0]}"}

    request = dict(payload)
    request.pop("definition", None)
    request["engine_version"] = ENGINE_VERSION
    request["data_window"] = {
        "from_date": frm.isoformat(), "to_date": to.isoformat(),
        "warmup_from": fetch_from.isoformat(),
        "chunk_count": fetch_meta.get("chunk_count", 0),
    }
    dataset_hash = _hash_rows(candles)
    parameters_hash = _hash_rows({
        "definition": definition, "symbol": symbol,
        "quantity": quantity,
        "slippage": slippage, "fees": fees,
        "initial_capital": initial_capital, "timeframe": timeframe,
        "cost_model": cost_model,
    })
    bt_id = db.create_backtest(strategy_version_id, request)
    with db._connection() as conn:
        conn.execute(
            "UPDATE backtests SET engine_version=?,dataset_hash=?,parameters_hash=? WHERE id=?",
            (ENGINE_VERSION, dataset_hash, parameters_hash, bt_id),
        )
    try:
        definition = dict(definition)
        definition["_available_funds"] = initial_capital
        result = strategy_engine.run_backtest(
            candles, definition, symbol, quantity,
            slippage, fees, initial_capital=initial_capital,
            requested_from=frm.isoformat(), requested_to=to.isoformat(),
            cost_model=cost_model,
        )
        result["backtest_id"] = bt_id
        result["data_quality"] = _data_quality(requested_candles, timeframe, frm.isoformat(), to.isoformat())
        result["data_window"] = {
            "from_date": frm.isoformat(), "to_date": to.isoformat(),
            "warmup_from": fetch_from.isoformat(),
            "candles": len(requested_candles), "warmup_candles": max(0,len(candles)-len(requested_candles)),
            "chunk_count": fetch_meta.get("chunk_count", 0),
            "chunks": fetch_meta.get("chunks", []),
        }
        db.complete_backtest(bt_id, result)
        return 200, {"result": result}
    except Exception as exc:
        db.complete_backtest(bt_id, {}, str(exc))
        raise
