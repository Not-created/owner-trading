"""Instrument-universe synchronisation and explicit live-feed subscriptions.

The scrip master is metadata, not a live-feed universe.  Live SFeed
subscriptions are opt-in and are limited to instruments explicitly selected
by the owner/strategy.  This prevents an NSE cash metadata refresh from
silently subscribing thousands of instruments.
"""
from __future__ import annotations
import asyncio, csv, io, urllib.request, datetime as dt
from . import db
from .broker_client import broker_client
from .websocket_manager import websocket_manager

MAX_SFEED_SUBSCRIPTIONS = 3000

def _field(row, *names):
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return None

async def _sync_nse_cash_metadata() -> dict:
    """Download and atomically import the official NSE cash scrip master.

    This function is metadata-only: it never creates SFeed subscriptions.
    Callers that need subscriptions must explicitly acquire a logical owner
    after the import succeeds. Keeping these operations separate prevents a
    metadata refresh from accidentally becoming a live-market subscription.
    """
    try:
        out = await asyncio.get_running_loop().run_in_executor(
            None, lambda: broker_client.read("scrip_master", exchange_segment="nse_cm")
        )
    except Exception as exc:
        return {"ok": False, "stage": "scrip_master_request",
                "error": f"Kotak scrip_master request failed: {type(exc).__name__}: {exc}"}

    if not out.ok:
        return {"ok": False, "stage": "scrip_master_request",
                "error": out.message or "Kotak scrip_master request failed.",
                "diagnostics": (out.extra or {}).get("broker_diagnostics")}

    url = out.data if isinstance(out.data, str) else None
    if not url:
        return {"ok": False, "stage": "scrip_master_response",
                "error": "Kotak scrip_master did not return the NSE cash file URL."}

    try:
        raw = await asyncio.get_running_loop().run_in_executor(
            None, lambda: urllib.request.urlopen(url, timeout=45).read()
        )
    except Exception as exc:
        return {"ok": False, "stage": "csv_download",
                "error": f"NSE cash CSV download failed: {type(exc).__name__}: {exc}"}

    try:
        text = raw.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise ValueError("CSV has no header row")
        normalized = {str(x).strip().lower() for x in reader.fieldnames if x}
        required = {"psymbol", "ptrdsymbol"}
        if not required.issubset(normalized):
            raise ValueError(
                "required columns pSymbol/pTrdSymbol are missing "
                f"(received: {', '.join(sorted(normalized)[:20])})"
            )
        rows = list(reader)
    except Exception as exc:
        return {"ok": False, "stage": "csv_parse",
                "error": f"NSE cash CSV parsing failed: {type(exc).__name__}: {exc}"}

    parsed = []
    rejected = 0
    for r in rows:
        tok = _field(r, "pSymbol", "instrument_token", "token", "symbol_token")
        sym = _field(r, "pTrdSymbol", "trading_symbol", "tradingsymbol", "symbol")
        if not tok or not sym:
            rejected += 1
            continue
        itype = (_field(r, "pInstType", "instrument_type", "instrument") or "").upper()
        if itype and itype not in ("EQ", "EQUITY", "CASH"):
            continue
        tok, sym = str(tok).strip(), str(sym).strip()
        name = _field(r, "pCompanyName", "company_name", "pSymbolName", "name")
        parsed.append({
            "trading_symbol": sym,
            "instrument_token": tok,
            "name": name,
            "instrument_type": itype or "EQ",
            "expiry": _field(r, "pExpiryDate", "expiry"),
            "strike": _field(r, "pStrikePrice", "strike"),
            "option_type": _field(r, "pOptionType", "option_type"),
            "lot_size": _field(r, "pLotSize", "lot_size"),
            "tick_size": _field(r, "pTickSize", "tick_size"),
        })

    if not parsed:
        return {"ok": False, "stage": "csv_parse",
                "error": "NSE cash scrip master contained no usable equity rows.",
                "parsed": 0, "rejected": rejected}

    try:
        imported = db.bulk_upsert_instruments(parsed)
    except Exception as exc:
        return {"ok": False, "stage": "sqlite_import",
                "error": f"NSE metadata SQLite import failed: {type(exc).__name__}: {exc}",
                "parsed": len(parsed), "rejected": rejected}

    return {
        "ok": True,
        "stage": "metadata_complete",
        "synced": imported,
        "parsed": len(parsed),
        "rejected_metadata_rows": rejected,
        "url": url,
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    }


async def sync_nse_cash_metadata() -> dict:
    """Public metadata-only refresh used by the UI and strategy preflight."""
    return await _sync_nse_cash_metadata()


async def sync_nse_cash_and_subscribe(limit=0, instrument_tokens=None):
    """Refresh metadata and optionally subscribe an explicitly requested set.

    Metadata refresh itself never creates SFeed subscriptions. If tokens are
    requested, each token is verified against the authoritative DB after import
    and then subscribed through the normal owner-aware WebSocket manager.
    """
    result = await _sync_nse_cash_metadata()
    if not result.get("ok"):
        return result

    requested_tokens = [str(x).strip() for x in (instrument_tokens or []) if str(x).strip()]
    requested_tokens = list(dict.fromkeys(requested_tokens))
    requested_limit = int(limit or 0)
    if not requested_tokens and requested_limit > 0:
        requested_tokens = [
            str(x["instrument_token"]).strip()
            for x in db.list_instruments(max(1, min(requested_limit, MAX_SFEED_SUBSCRIPTIONS)))
            if str(x.get("instrument_token") or "").strip()
        ]

    if len(requested_tokens) > MAX_SFEED_SUBSCRIPTIONS:
        return {
            **result,
            "ok": False,
            "stage": "subscription_validation",
            "error": f"Requested live universe has {len(requested_tokens)} instruments; SFeed allows at most {MAX_SFEED_SUBSCRIPTIONS}.",
        }

    invalid = [t for t in requested_tokens if not db.get_instrument("nse_cm", t)]
    if invalid:
        return {
            **result,
            "ok": False,
            "stage": "subscription_validation",
            "error": f"{len(invalid)} requested instrument token(s) were not found in the NSE cash scrip master.",
            "invalid_tokens": invalid[:20],
        }

    subscribed = 0
    rejected_subs = 0
    if requested_tokens:
        try:
            sub_result = await websocket_manager.subscribe_many(
                [("nse_cm", tok) for tok in requested_tokens]
            )
            subscribed = int(sub_result.get("added") or 0)
        except Exception as exc:
            rejected_subs = len(requested_tokens)
            return {
                **result,
                "ok": False,
                "stage": "subscription",
                "error": f"SFeed subscription failed: {type(exc).__name__}: {exc}",
                "candidateCount": len(requested_tokens),
                "subscribed": subscribed,
                "rejected": rejected_subs,
                "subscriptionLimit": MAX_SFEED_SUBSCRIPTIONS,
            }

    db.set_algo_runtime(universe_count=result.get("synced", 0), status="RUNNING")
    return {
        **result,
        "ok": rejected_subs == 0,
        "stage": "complete",
        "candidateCount": len(requested_tokens),
        "subscribed": subscribed,
        "rejected": rejected_subs,
        "subscriptionLimit": MAX_SFEED_SUBSCRIPTIONS,
        "metadataOnly": not bool(requested_tokens),
    }

