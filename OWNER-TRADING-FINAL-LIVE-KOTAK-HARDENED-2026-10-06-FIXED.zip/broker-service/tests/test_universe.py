import asyncio
import unittest
from unittest.mock import patch

from app import universe
from app import broker_client as bc
from app import sdk_adapter as a
from app.state import BrokerState, current_state
from tests.fakes import FakeNeoAPI
from tests.dbutil import fresh_db


class UniverseMetadataTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.db = fresh_db()
        sdk = a.KotakSdk("ck", "prod", neo_factory=FakeNeoAPI)
        sdk.login(mobile_number="+919999999999", ucc="U1", totp="1", mpin="1")
        bc.broker_client._sdk = sdk
        current_state.transition(BrokerState.CONNECTED)

    def tearDown(self):
        bc.broker_client._sdk = None
        current_state.transition(BrokerState.DISCONNECTED)

    async def test_metadata_refresh_is_metadata_only(self):
        neo = bc.broker_client._sdk._neo
        neo.responses["scrip_master"] = "https://example.test/nse_cm-v1.csv"
        csv = (
            "pSymbol,pSymbolName,pTrdSymbol,pInstType,pLotSize,pTickSize\n"
            "11915,YES BANK,YESBANK-EQ,EQ,1,0.01\n"
            "1333,HDFC BANK,HDFCBANK-EQ,EQ,1,0.01\n"
        ).encode()

        with patch("app.universe.urllib.request.urlopen") as urlopen:
            response = type("R", (), {"read": lambda self: csv})()
            urlopen.return_value = response
            with patch.object(universe.websocket_manager, "subscribe_many") as subscribe:
                result = await universe.sync_nse_cash_metadata()

        self.assertTrue(result["ok"])
        self.assertEqual(result["synced"], 2)
        subscribe.assert_not_called()
        self.assertIsNotNone(self.db.get_instrument("nse_cm", "11915"))
        self.assertIsNotNone(self.db.get_instrument("nse_cm", "1333"))


if __name__ == "__main__":
    unittest.main()
