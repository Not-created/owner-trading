import math
import os
import pytest
from unittest.mock import patch

from tests.dbutil import fresh_db
from app import strategy_engine
from app import order_service
from app import broker_client
from app.state import BrokerState, current_state


def test_strategy_numeric_validation_rejects_nan_and_non_integer_position_controls():
    base = {
        "timeframe": "5m", "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "1"}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": "1"}]},
        "risk": {"stop_loss_pct": "NaN"},
        "position_sizing": {"quantity": 1},
        "universe": {"instrument_tokens": ["11915"]},
        "max_positions": 1.5,
        "execution": {"cooldown_bars": 1.5},
    }
    errors = strategy_engine.validate_strategy(base)
    assert any("risk.stop_loss_pct must be numeric" in e for e in errors)
    assert any("max_positions must be a positive integer" in e for e in errors)
    assert any("cooldown_bars must be a non-negative integer" in e for e in errors)


def test_strategy_duplicate_or_invalid_universe_tokens_are_rejected():
    base = {
        "timeframe": "5m", "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "risk": {"stop_loss_pct": 1}, "position_sizing": {"quantity": 1},
        "universe": {"instrument_tokens": ["11915", "11915", "bad"]},
    }
    errors = strategy_engine.validate_strategy(base)
    assert any("duplicate" in e for e in errors)
    assert any("positive integer token" in e for e in errors)


def test_size_position_never_rounds_requested_quantity_up_to_lot_size():
    definition = {"position_sizing": {"quantity": 1}}
    assert strategy_engine.size_position(definition, 100, lot_size=25) == 0


def test_pending_sell_entry_counts_toward_exposure_and_strategy_pressure():
    db = fresh_db()
    db.create_order(
        internal_order_id="pending-sell", mode="LIVE", status="SUBMITTING", client_tag="TAG1",
        trading_symbol="ABC-EQ", exchange_segment="nse_cm", transaction_type="S",
        order_type="MKT", product="MIS", validity="DAY", quantity=10, price=None,
        trigger_price=None, instrument_token="11915", signal_id=None, algo_position_id=None,
        order_role="MANUAL", parent_order_id=None,
    )
    with patch("app.order_service.fresh_ltp", return_value=100.0):
        total, by_strategy, by_instrument, counts, complete = order_service._pending_entry_risk()
    assert complete is True
    assert total == pytest.approx(1000.0)
    assert by_instrument[("nse_cm", "11915")] == pytest.approx(1000.0)


def test_final_entry_gate_rejects_malformed_persisted_scanner_ids():
    db = fresh_db()
    db.set_live_armed(True)
    db.record_funds_snapshot(available_margin=100000, used_margin=0, raw={}, realized_mtom=0, unrealized_mtom=0)
    rid = db.begin_reconciliation_run()
    db.finish_reconciliation_run(rid, status="COMPLETE", discrepancy_count=0, sections_ok=True, details={})
    current_state.transition(BrokerState.CONNECTED)
    strategy = db.create_strategy("malformed-scanner")
    definition = {
        "side": "BUY", "timeframe": "5m", "scanner_ids": ["oops"],
        "entry": {"conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "risk": {"stop_loss_pct": 1}, "position_sizing": {"quantity": 1},
    }
    version = db.save_strategy_version(strategy["id"], definition, "VALIDATED", [])
    with db._connection() as conn:
        conn.execute("UPDATE strategy_versions SET is_live_armed=1,status='LIVE_RUNNING' WHERE id=?", (version["id"],))
    signal = db.record_signal(strategy_version_id=version["id"], scanner_id=None,
                              exchange_segment="nse_cm", instrument_token="11915", trading_symbol="ABC-EQ",
                              timeframe="5m", side="BUY", signal_price=100, conditions={}, risk={},
                              candle_at="2026-10-05 10:00:00")
    db.create_order(internal_order_id="bad-scanner-entry", trading_symbol="ABC-EQ", exchange_segment="nse_cm",
                    transaction_type="B", order_type="MKT", product="MIS", validity="DAY", quantity=1,
                    price=None, trigger_price=None, mode="LIVE", status="SUBMITTING", client_tag="TAG2",
                    instrument_token="11915", signal_id=signal, order_role="ENTRY", parent_order_id=None)
    os.environ["BROKER_SERVICE_TOKEN"] = "x" * 32
    with patch("app.broker_client.sdk_conformance.check_vendor_integrity", return_value=type("R", (), {"ok": True, "errors": []})()), \
         patch("app.market_prices.fresh_ltp", return_value=100.0), \
         patch("app.websocket_manager.websocket_manager.status", return_value={"market": {"connected": True}, "orderFeed": {"connected": True}}):
        with pytest.raises(broker_client.LiveTradingBlockedError, match="scanner_ids"):
            broker_client.assert_live_trading_allowed(exclude_internal_order_id="bad-scanner-entry",
                                                       instrument_token="11915", trading_symbol="ABC-EQ", exchange_segment="nse_cm")
