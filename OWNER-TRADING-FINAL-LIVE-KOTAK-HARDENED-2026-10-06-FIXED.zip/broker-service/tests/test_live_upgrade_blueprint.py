
import asyncio
from types import SimpleNamespace

from app import strategy_engine
from app.exit_engine import derive_levels


def test_atr_stop_is_derived_for_live_position():
    definition = {"risk": {"stop_atr_multiple": 2}}
    assert derive_levels(definition, 100.0, "BUY", atr_value=3.0) == (94.0, None)
    assert derive_levels(definition, 100.0, "SELL", atr_value=3.0) == (106.0, None)


def test_atr_stop_does_not_invent_level_without_atr():
    definition = {"risk": {"stop_atr_multiple": 2}}
    assert derive_levels(definition, 100.0, "BUY", atr_value=None) == (None, None)


def test_scanner_ids_are_optional_but_validated_when_present():
    base = {
        "timeframe": "5m",
        "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "universe": {"instrument_tokens": ["1"]},
        "risk": {"stop_loss_pct": 1},
        "position_sizing": {"quantity": 1},
    }
    assert not any("scanner_ids" in e for e in strategy_engine.validate_strategy(base))
    invalid = dict(base, scanner_ids=["bad"])
    assert any("scanner_ids" in e for e in strategy_engine.validate_strategy(invalid))


def test_timeframe_support_includes_10m():
    assert "10m" in strategy_engine.TIMEFRAMES


def test_strategy_candidate_is_durable_and_scoped_to_strategy_and_scanner():
    from tests.dbutil import fresh_db
    db = fresh_db()
    scanner = db.create_scanner("Scoped Scanner", {
        "timeframe": "5m", "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
    })
    strategy = db.create_strategy("Candidate Strategy")
    version = db.save_strategy_version(strategy["id"], {
        "timeframe": "5m", "side": "BUY",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "universe": {"instrument_tokens": ["1"]},
        "scanner_ids": [scanner["id"]],
        "risk": {"stop_loss_pct": 1}, "position_sizing": {"quantity": 1},
    })
    candidate = db.upsert_strategy_candidate(
        strategy_version_id=version["id"], scanner_id=scanner["id"], exchange_segment="nse_cm",
        instrument_token="1", trading_symbol="TEST-EQ", timeframe="5m", matched_price=10,
        conditions={"matched": True}, expires_at="2999-01-01 00:00:00",
    )
    assert candidate["strategy_version_id"] == version["id"]
    assert db.has_active_candidate(strategy_version_id=version["id"], exchange_segment="nse_cm", instrument_token="1")
