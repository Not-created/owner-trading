import dataclasses
import os
import unittest
from unittest.mock import patch
from app import broker_client as bc
from app import live_readiness as lr
from app import sdk_adapter as a
from app.websocket_manager import websocket_manager
from app.state import BrokerState, current_state
from tests.dbutil import fresh_db
from tests.fakes import FakeNeoAPI
from tests.test_order_lifecycle import mk

def gate(res, gid):
    return next((g for g in res['gates'] if g['id'] == gid))

class ReadinessTests(unittest.TestCase):

    def setUp(self):
        self.db = fresh_db()
        os.environ.pop('BROKER_SERVICE_TOKEN', None)
        current_state.transition(BrokerState.DISCONNECTED)

    def tearDown(self):
        os.environ.pop('BROKER_SERVICE_TOKEN', None)

    def test_all_gates_can_pass_and_arming_is_separate(self):
        cfg = dataclasses.replace(lr.config, trading_mode='LIVE')
        os.environ['BROKER_SERVICE_TOKEN'] = 'x' * 32
        self.db.set_risk_settings({'max_order_quantity': 10, 'max_order_value': 5000, 'max_orders_per_day': 5, 'max_daily_loss': 1000})
        self.db.record_funds_snapshot(available_margin=1000, used_margin=0, raw={}, realized_mtom=0, unrealized_mtom=0)
        rid=self.db.begin_reconciliation_run(); self.db.finish_reconciliation_run(rid,status='COMPLETE',discrepancy_count=0,sections_ok=True,details={})
        ws = {'market': {'connected': True}, 'orderFeed': {'connected': True}}
        with patch.object(lr, 'config', cfg), patch.object(a, 'SDK_AVAILABLE', True), patch.object(a, 'SDK_VERSION', '3.0.7'), patch('app.sdk_conformance.check_runtime', return_value=lr.sdk_conformance.ConformanceResult(ok=True, checked=20)), patch('app.credential_manager.credential_manager.has_base_credentials', return_value=True), patch('app.websocket_manager.websocket_manager.status', return_value=ws):
            current_state.transition(BrokerState.CONNECTED)
            r = lr.evaluate()
            self.assertTrue(r['ready'], [g for g in r['gates'] if not g['ok']])
            self.assertFalse(r['live_orders_can_be_sent'])
            self.db.set_live_armed(True)
            self.assertTrue(lr.evaluate()['live_orders_can_be_sent'])

    def test_unknown_outcome_order_blocks_readiness(self):
        mk(self.db, status='PENDING_RECONCILE', broker_id=None)
        self.db.update_order(internal_order_id='o1', outcome_unknown=True)
        self.assertFalse(gate(lr.evaluate(), 'no_unknown_outcome_orders')['ok'])

    def test_emergency_stop_blocks(self):
        with patch.object(self.db, 'is_emergency_stop_active', return_value=True):
            self.assertFalse(gate(lr.evaluate(), 'emergency_stop_clear')['ok'])

    def test_missing_limits_named(self):
        self.db.set_risk_settings({'max_order_quantity': 10})
        g = gate(lr.evaluate(), 'risk_limits_configured')
        self.assertFalse(g['ok'])
        self.assertIn('max_daily_loss', g['detail'])

    def test_vendor_tamper_is_reported_non_blocking_warning(self):
        with patch('app.sdk_conformance.check_vendor_integrity', return_value=lr.sdk_conformance.ConformanceResult(ok=False, errors=['x modified'])):
            g = gate(lr.evaluate(), 'vendored_sdk_unmodified')
        self.assertFalse(g['ok'])
        self.assertTrue(g['blocking'])

    def test_evaluation_is_audited(self):
        lr.evaluate()
        with self.db._connection() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM live_readiness_checks').fetchone()[0], 1)
if __name__ == '__main__':
    unittest.main()

class StrategyScopedReadinessTests(unittest.TestCase):
    def test_strategy_scoped_subscriptions_ignore_unrelated_strategy_keys(self):
        armed = [
            {'id': 10, 'definition': {'scanner_ids': [], 'universe': {'instrument_tokens': ['10']}}},
            {'id': 20, 'definition': {'scanner_ids': [], 'universe': {'instrument_tokens': ['20']}}},
        ]
        with patch.object(lr._db, 'list_live_armed_strategy_versions', return_value=armed), \
             patch.object(lr._db, 'list_scanners', return_value=[]), \
             patch.object(lr._db, 'list_active_candidate_subscription_keys', return_value=[]), \
             patch.object(lr._db, 'get_strategy_version', return_value=armed[0]), \
             patch.object(lr._db, 'required_strategy_subscription_keys', return_value={('nse_cm','10'),('nse_cm','20')}), \
             patch.object(websocket_manager, '_subs', {('nse_cm','10'): None}), \
             patch.object(websocket_manager, 'status', return_value={'market': {'connected': True, 'stale': False}, 'orderFeed': {'connected': True}}), \
             patch.object(lr, 'sdk_ready', return_value=(False, 'test')):
            result = lr.evaluate(strategy_version_id=10, ignore_strategy_subscriptions=False)
        # The target's subscription is present; strategy 20's missing token must
        # not leak into the target-specific gate.
        self.assertTrue(gate(result, 'feed_subscriptions_healthy')['ok'])

    def test_unrelated_armed_strategy_scanner_does_not_block_target(self):
        armed = [
            {'id': 10, 'definition': {'scanner_ids': [1]}},
            {'id': 20, 'definition': {'scanner_ids': [2]}},
        ]
        scanners = [
            {'id': 1, 'is_active': True},
            {'id': 2, 'is_active': False},
        ]
        with patch.object(lr._db, 'list_live_armed_strategy_versions', return_value=armed), \
             patch.object(lr._db, 'list_scanners', return_value=scanners), \
             patch.object(lr._db, 'required_strategy_subscription_keys', return_value=set()), \
             patch.object(lr._db, 'list_active_candidate_subscription_keys', return_value=[]), \
             patch.object(lr._db, 'get_strategy_version', return_value=armed[0]), \
             patch.object(lr, 'sdk_ready', return_value=(False, 'test')):
            result = lr.evaluate(strategy_version_id=10, ignore_strategy_subscriptions=True)
        g = gate(result, 'strategy_scanners_healthy')
        self.assertTrue(g['ok'], g)
