import os
from unittest.mock import patch

import pytest

from tests.dbutil import fresh_db
from app.state import BrokerState, current_state
import app.broker_client as bc


def _base_runtime(db):
    db.set_live_armed(True)
    db.record_funds_snapshot(available_margin=100000, used_margin=0, raw={}, realized_mtom=0, unrealized_mtom=0)
    rid = db.begin_reconciliation_run()
    db.finish_reconciliation_run(rid, status="COMPLETE", discrepancy_count=0, sections_ok=True, details={})
    current_state.transition(BrokerState.CONNECTED)
    os.environ["BROKER_SERVICE_TOKEN"] = "x" * 32


def test_final_entry_gate_requires_strategy_candidate_and_strategy_arm():
    db = fresh_db()
    scanner = db.create_scanner("S", {
        "side": "BUY", "timeframe": "5m",
        "entry": {"conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"conditions": [{"left": "close", "operator": "<", "right": 1}]},
    })
    db.set_scanner_active(scanner["id"], True)
    strategy = db.create_strategy("strategy")
    definition = {
        "side": "BUY", "timeframe": "5m", "scanner_ids": [scanner["id"]],
        "entry": {"conditions": [{"left": "close", "operator": ">", "right": 1}]},
        "exit": {"conditions": [{"left": "close", "operator": "<", "right": 1}]},
        "risk": {"stop_loss_pct": 1}, "position_sizing": {"quantity": 1},
        "execution": {"product": "MIS"},
    }
    version = db.save_strategy_version(strategy["id"], definition, "VALIDATED", [])
    db.set_strategy_armed(version["id"], True)
    candidate = db.upsert_strategy_candidate(
        strategy_version_id=version["id"], scanner_id=scanner["id"], exchange_segment="nse_cm",
        instrument_token="11915", trading_symbol="YESBANK-EQ", timeframe="5m",
        matched_price=20.0, conditions={}, expires_at=None,
    )
    db.mark_strategy_candidate_subscribed(candidate["id"], True)
    signal = db.record_signal(strategy_version_id=version["id"], scanner_id=scanner["id"],
                              exchange_segment="nse_cm", instrument_token="11915", trading_symbol="YESBANK-EQ",
                              timeframe="5m", side="BUY", signal_price=20.0, conditions={}, risk={},
                              candle_at="2026-10-05 10:00:00")
    db.create_order(internal_order_id="entry-gate", trading_symbol="YESBANK-EQ", exchange_segment="nse_cm",
                    transaction_type="B", order_type="MKT", product="MIS", validity="DAY", quantity=1,
                    price=None, trigger_price=None, mode="LIVE", status="SUBMITTING", client_tag="TAGGATE",
                    instrument_token="11915", signal_id=signal, order_role="ENTRY")
    _base_runtime(db)
    with patch("app.websocket_manager.websocket_manager.status", return_value={
        "running": True, "market": {"connected": True, "stale": False, "subscriptions": 1},
        "orderFeed": {"connected": True},
    }), patch("app.broker_client.sdk_conformance.check_vendor_integrity", return_value=type("R", (), {"ok": True, "errors": [], "checked": 1})()), patch("app.market_prices.fresh_ltp", return_value=20.0):
        bc.assert_live_trading_allowed(exclude_internal_order_id="entry-gate", instrument_token="11915", trading_symbol="YESBANK-EQ", exchange_segment="nse_cm")
        db.set_strategy_armed(version["id"], False)
        with pytest.raises(bc.LiveTradingBlockedError, match="no longer LIVE armed"):
            bc.assert_live_trading_allowed(exclude_internal_order_id="entry-gate", instrument_token="11915", trading_symbol="YESBANK-EQ", exchange_segment="nse_cm")
