import asyncio

from app import db
from app import scanner_engine
from app import live_readiness


def test_strategy_daily_loss_halt_is_latched():
    db = __import__("tests.dbutil", fromlist=["fresh_db"]).fresh_db()
    st = db.create_strategy("risk-test")
    db.set_risk_settings({"max_strategy_daily_loss": 100.0})
    first = db.refresh_strategy_daily_loss_halt(strategy_version_id=st["id"], current_pnl=-150.0, limit=100.0)
    assert first["daily_loss_halted"] is True
    second = db.refresh_strategy_daily_loss_halt(strategy_version_id=st["id"], current_pnl=-10.0, limit=100.0)
    assert second["daily_loss_halted"] is True


def test_candidate_requires_subscription_for_execution():
    db = __import__("tests.dbutil", fromlist=["fresh_db"]).fresh_db()
    # This test is structural: the DB helper must distinguish active candidates
    # from candidates whose SFeed subscription failed.
    st = db.create_strategy("candidate-test")
    # Create a valid scanner row because candidates are foreign-key bound to both.
    sc = db.create_scanner("scanner-test", {"side":"BUY","timeframe":"5m","entry":{"conditions":[{"left":"close","operator":">","right":1}]},"exit":{"conditions":[{"left":"close","operator":"<","right":1}]}})
    db.set_risk_settings({})
    c = db.upsert_strategy_candidate(
        strategy_version_id=st["id"], scanner_id=sc["id"], exchange_segment="nse_cm",
        instrument_token="1", trading_symbol="TEST", timeframe="5m",
        matched_price=100.0, conditions={}, expires_at=None,
    )
    assert db.active_candidates_for_strategy_instrument(
        strategy_version_id=st["id"], exchange_segment="nse_cm", instrument_token="1", subscribed_only=True
    ) == []
    db.mark_strategy_candidate_subscribed(c["id"], True)
    assert db.active_candidates_for_strategy_instrument(
        strategy_version_id=st["id"], exchange_segment="nse_cm", instrument_token="1", subscribed_only=True
    )
