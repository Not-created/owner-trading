# Owner Trading — Phase 1–10 Complete / Final Hardening Audit

## Source
Current user package:
`owner-trading-PHASE-1-5-COMPLETE-FINAL.zip`

## Locked architecture preserved
React + Vite → Node/Express → SQLite → Python broker service → official Kotak Neo `kotakneoapi` 3.0.7 → Kotak, with systemd + Nginx.

No replacement architecture, Docker, Redis, PostgreSQL, Next.js, simulator/PAPER execution path, or second trading engine was introduced.

## Phase 1 — Production runtime / resilience
Retained the existing persistent SQLite web-session store, SQLite integrity checks, pre-deploy database backup/retention, fail-closed deployment and systemd protections.

Additional hardening:
- Candle runtime SQLite errors are logged instead of being silently swallowed.
- Forming-candle recovery now restores the cumulative-volume baseline before calculating the first post-restart tick delta.

## Phase 2 — Strategy / risk contract
Retained the existing canonical strategy DSL, sizing exclusivity, protective-stop LIVE gate, timeframe-aware exit handling and LIVE universe validation.

Additional hardening:
- Stop-loss modes are mutually exclusive: fixed price, percentage, or ATR multiple.
- Target modes are mutually exclusive: fixed price or percentage.
- `risk_per_trade` sizing now requires a stop-loss mode so sizing cannot silently fall back to quantity 1.
- `execution.cooldown_bars` is validated as a non-negative integer.

## Phase 3 — Backtest
Retained:
- Kotak historical interval/range chunking.
- IST timestamp normalization.
- Bulk candle caching.
- Entry/exit cost model.
- Portfolio-equity based Sharpe/Sortino.
- Equity curve, drawdown, data-quality and reproducibility metadata.

## Phase 4 — Market data / SFeed
Retained the official SDK v3 async SFeed architecture and 3000-token ceiling.

Additional hardening:
- Candle engine now builds only timeframes required by armed LIVE strategies/active scanners, with a short cache, instead of maintaining all seven timeframes for every subscribed instrument.
- Batched subscription registry now reflects successful batches correctly if a later batch fails.
- LIVE strategy arming uses batched SFeed subscription instead of one broker frame per token.
- Failed strategy arming rolls back newly-added subscriptions.
- Switching an armed strategy version cleans subscriptions no longer required by any remaining armed strategy.

## Phase 5 — Orders / execution
Retained:
- Durable local order before broker submission.
- Client-tag reconciliation.
- UNKNOWN outcome handling.
- Idempotency.
- Immutable strategy execution chain.
- No blind retry.

Additional hardening:
- Broker order cancellation remains available as a controlled exposure-reduction action during emergency stop / global LIVE disarm, while connected-session, SDK-integrity, reconciliation and freshness gates remain enforced.

## Phase 6 — Strategy Builder / scanner
Retained the existing no-code strategy builder and validated DSL.

Additional hardening:
- Scanner execution now validates the definition and timeframe before scanning.
- Scanner universe is capped at 3000.
- Scanner candle retrieval uses one bounded SQLite window query instead of opening a separate SQLite query/connection for every instrument.

## Phase 7 — LIVE strategy runtime
Retained:
- Completed-candle signal evaluation.
- Durable signal-before-order chain.
- Same-candle idempotency across restart.
- Strategy position limits.
- Scanner gating.
- Timeframe-aware strategy execution.

## Phase 8 — LIVE exit / position lifecycle
Retained:
- Tick-level protective stop/target/trailing evaluation.
- BUY/SELL-aware exits.
- Partial exits.
- Time exits.
- Broker-fill reconciliation.
- Broker-flat local position closure.
- Immutable ENTRY → EXIT parent chain.

## Phase 9 — Backtest/report/UI integration
Retained:
- Historical-only backtest boundary.
- Persisted backtest results/equity.
- Execution-chain inspection.
- Frontend → Express → Python route wiring.
- Existing Dark/Light theme.

## Phase 10 — Reconciliation hardening
Retained:
- Durable reconciliation-run ledger.
- Five authoritative sections: orders, trades, positions, holdings, funds.
- Clean reconciliation required for LIVE readiness.
- UNKNOWN/pending submission blocking.
- Strategy-position recovery bound to the immutable ENTRY chain.

The existing no-holdings/no-positions 424 handling is preserved so an empty broker portfolio is treated as empty data, not automatically as a discrepancy; unrelated 424/failure shapes remain blocking.

## Emergency-stop safety
Emergency stop now also clears the global LIVE arm in the same SQLite transaction. Clearing the emergency stop therefore does **not** silently resume live entries; a fresh explicit owner ARM action is required.

## Theme / SDK preservation
- Dark/Light theme implementation files: unchanged from the supplied ZIP.
- Vendored official `broker-service/vendor/kotakneoapi`: unchanged and byte-identical to the supplied ZIP.
- No legacy Kotak v2 SDK calls were introduced.

## Verification

- Broker-service pytest: **289 passed, 3 skipped, 0 failed**
- Backend Node tests: **25 passed, 6 skipped, 0 failed**
- Python compileall: PASS
- Backend Node syntax checks: PASS
- Shell syntax checks: PASS
- Static LIVE/PAPER/simulator scan: PASS
- Fresh SQLite migrations 001–011: PASS (existing package migrations retained)
- Vendor SDK integrity/conformance checks remain covered by the existing suite.

### Frontend build limitation
A fresh Vite production build was not claimed in this packaging environment because the frontend dependency tree is not installed here. The existing deployment script remains fail-closed and performs the real frontend dependency installation and `npm run build` on the target VPS.

### LIVE-money boundary
No Kotak credentials were used and no real-money order was placed during this packaging audit. Software verification does not constitute broker-side live-money verification.

## Official Kotak compatibility basis
The package retains the official Kotak Neo Python SDK 3.0.7. Kotak's current official documentation describes the v3 async SFeed `subscribe_scrips`/`unsubscribe_scrips` model and a 3000-token running subscription ceiling, and documents the historical-data intervals/range limits used by this project.
