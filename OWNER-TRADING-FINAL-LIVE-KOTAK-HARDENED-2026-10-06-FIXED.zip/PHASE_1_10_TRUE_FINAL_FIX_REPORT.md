# Owner Trading — Phase 1–10 True Final Fix Pass

This release is based on the supplied `owner-trading-PHASE-1-10-COMPLETE-FINAL.zip`.

## Production/deployment fixes
- Kotak scrip-master cache is explicitly relocated to `/var/lib/owner-trading/scrip_cache` through `NEO_SCRIP_CACHE_DIR` so it works with `ProtectHome=true`.
- Deployment creates, owns, permissions-checks and performs an actual write test against the cache path.
- Existing systemd services are quiesced before replacing the production runtime and before in-place DB migration.
- Deployment password handling is non-interactive: existing password is preserved; `OWNER_TRADING_PASSWORD` can explicitly replace it; a missing initial password is generated as an exact 8-character value and printed once.
- Existing Fernet credential key is preserved; invalid keys are not silently rotated when encrypted credentials exist.

## Broker/session safety
- Credentials alone no longer imply owner intent to reconnect on service restart.
- Startup auto-connect requires an explicit persisted owner CONNECT intent.
- Explicit Disconnect clears that intent.
- Broker session expiry is no longer based on an undocumented fixed 8-hour TTL; expiry is broker-signalled/state-driven.

## LIVE order safety
- EXIT orders bypass entry-only global limits so daily-loss/max-open-position/order-count gates cannot prevent flattening an existing position.
- Broker/session/reconciliation gates remain mandatory for controlled exits.
- EXIT quantity cannot exceed the open algo position's remaining quantity.
- EXIT instrument token must match the open algo position when supplied.
- Order quantities must be positive integers; non-finite numeric values are rejected.
- Unknown modify/cancel outcomes move the local order into `PENDING_RECONCILE` and trigger reconciliation instead of leaving an ambiguous active state.

## Market data / candles
- Candle engine receives every valid SFeed tick; SQLite market-tick persistence remains independently throttled.
- Candle timestamps use Kotak SFeed `last_trade_time`/`last_update_time` when available, with seconds/milliseconds normalization.
- 30m/1h intraday candle buckets are anchored to the NSE cash-session open at 09:15 IST instead of midnight flooring.
- Existing restart-persistent forming-candle state remains intact.

## Strategy/backtest correctness
- RSI and ATR use Wilder smoothing.
- ADX uses Wilder-style smoothing.
- VWAP is session/day scoped instead of spanning unrelated trading days.
- Invalid historical timestamps fail closed for NSE cash-session filtering.
- Fixed quantity sizing requires an integer quantity.
- Existing equity-curve/portfolio-return risk metric implementation is preserved.

## Preservation
- Dark/Light theme files were not modified in this pass.
- Vendored official Kotak Neo SDK files were not modified.
- React + Vite / Express + SQLite / Python broker architecture remains unchanged.

## Validation
- Python syntax/compile: PASS
- broker-service pytest: **289 passed, 3 skipped, 0 failed**
- Backend JavaScript syntax checks: PASS
- deploy.sh shell syntax: PASS
- No generated `__pycache__`, `.pyc` or `.pytest_cache` files are included in the release.

A fresh VPS deployment must still be executed through the hardened `deploy.sh`; this environment does not have the production VPS's systemd/nginx/Kotak network state, so a live broker connection was not fabricated as a local test result.
