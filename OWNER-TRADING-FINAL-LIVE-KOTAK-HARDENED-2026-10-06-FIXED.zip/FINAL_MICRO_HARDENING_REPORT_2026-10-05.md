# Owner Trading — Micro-Level Hardening Audit & Fix Report
Date: 2026-10-05
Release basis: OWNER-TRADING-FINAL-LIVE-SCANNER-RISK-HARDENED-KOTAK-DEEP-HARDENED-FINAL-2026-10-05.zip

## Scope
This pass started from the uploaded Deep-Hardened release and the uploaded official Kotak Neo Python SDK source. It focused on small cross-layer correctness failures that can survive normal happy-path tests and can affect LIVE safety, reconciliation, strategy arming, risk limits, or historical analysis.

## Fixed

1. **Pending SELL exposure bypass**
   - `order_service._pending_entry_risk()` previously considered only BUY (`B`) pending entries.
   - SELL (`S`) entries could therefore bypass total/strategy/instrument exposure pressure until the broker snapshot caught up.
   - Fixed to include both BUY and SELL entry directions while still excluding EXIT orders.

2. **Persisted malformed scanner IDs at the final LIVE gate**
   - Strategy ARM validation was strict, but a previously persisted/corrupted strategy definition could reach the final order gate.
   - The old list-comprehension silently dropped malformed scanner IDs.
   - Fixed: non-list, bool, non-numeric, zero, or negative scanner IDs now fail closed with an explicit LIVE block.

3. **Post-strategy-ARM subscription gate**
   - Scanner-linked strategy ARM previously used a blanket `ignore_strategy_subscriptions` setting during the post-arm check.
   - That could allow an already-active candidate with a failed subscription to coexist with an apparently successful ARM.
   - Fixed: post-arm readiness is now strict and scoped to the strategy. Zero active candidates is valid; existing active candidates must have valid subscriptions.

4. **Strategy definition numeric hardening**
   - Non-finite numeric values (`NaN`, `Infinity`) could pass weak numeric parsing in condition/risk validation.
   - `max_positions`, `cooldown_bars`, and `time_exit_bars` now require real integer representations rather than silently truncating values such as `1.5`.
   - Explicit universe tokens must be positive integer tokens and cannot contain duplicates.

5. **Strategy canonical persistence**
   - Valid strategy versions are now persisted with canonical scanner IDs and deduplicated string-form instrument tokens.
   - Runtime does not need to reinterpret mixed numeric/string representations.

6. **Lot-size quantity safety**
   - `size_position()` previously could round a requested quantity such as `1` up to a lot size such as `25`.
   - It now fails sizing (`0`) instead of increasing the owner's requested quantity.

7. **Backtest request validation**
   - Malformed `strategy_id` / `strategy_version_id`, exchange segment, instrument token, quantity, and empty trading symbol inputs now return explicit 400-level validation instead of falling into 500s or ambiguous downstream failures.

8. **Backtest interval UI alignment**
   - Added the supported `10m` interval to the Backtest UI so frontend choices match the backend/Kotak historical interval contract.

9. **Historical candle timestamp deduplication**
   - Timezone-aware timestamps representing the same instant (for example IST and UTC forms) are normalized to UTC before deduplication.
   - Prevents one candle from being counted twice when cache/API representations use different offsets.

10. **Condition operand finite-number validation**
    - Non-finite string operands are now rejected during strategy validation instead of becoming a runtime missing operand.

11. **Scanner sync/candidate route integer validation**
    - Malformed `limit` and `version_id` values now return explicit 400 responses instead of raising conversion exceptions.

## Intentionally NOT changed

- Official Kotak SDK source was not modified.
- Vendored SDK remains byte-identical to the uploaded official SDK 3.0.7 source.
- No LIVE readiness gate was bypassed.
- No reconciliation failure is converted into an unconditional success.
- 403/429/5xx/timeouts/invalid sessions remain blocking or UNKNOWN as appropriate.
- EXIT orders continue to bypass only new-exposure limits; broker/session/reconciliation protections remain.
- Scanner candidate architecture and reference-counted SFeed ownership remain intact.

## Verification

Broker service:
- `340 passed, 3 skipped`
- Python `compileall`: PASS
- Vendored SDK conformance/integrity: PASS
- Uploaded official SDK vs vendored SDK directory comparison: identical

Backend:
- `26 passed, 6 skipped`
- SQLite fresh migrations: PASS
- SQLite migration idempotency: PASS
- Node syntax checks: PASS

Deployment/static:
- `bash -n deploy.sh`: PASS
- Nginx timeout/static deployment contracts: PASS through existing test suite
- Final ZIP extraction/integrity: verified after packaging

Frontend build limitation:
- A fresh Vite build was not independently executed in this isolated environment because npm dependencies were not installed and registry installation was not completed. The deployment script still treats a failed `npm run build` as a hard deployment failure.

## LIVE safety result
The final executable path remains:

Strategy validation → explicit LIVE ARM → scanner/universe authorization → candidate/SFeed → fresh candle/tick → signal → risk gate → final readiness → fresh exact-instrument price → broker session/feed/reconciliation/funds/margin/idempotency → official Kotak order API.

A code path cannot use these micro-hardening changes to skip the final LIVE gates.
