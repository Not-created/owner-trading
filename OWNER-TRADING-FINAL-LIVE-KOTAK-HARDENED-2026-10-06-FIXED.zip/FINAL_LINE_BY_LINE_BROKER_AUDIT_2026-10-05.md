# Owner Trading — Final Line-by-Line Broker/Runtime Audit
Date: 2026-10-05

## Inputs audited
- Current application ZIP: OWNER-TRADING-FINAL-LIVE-SCANNER-RISK-HARDENED-2026-10-05.zip
- Official Kotak Neo Python source ZIP: kotak-neo-python-main (uploaded 2026-10-05)
- Official SDK version: 3.0.7

## Critical defects found and fixed in this pass
1. Strategy version save handler referenced `scanner_ids` before defining it. This caused the exact `Internal server error` shown in the Strategy Builder screenshot. Fixed and covered by an HTTP-route regression test.
2. Scanner-linked strategy validation rejected an intentionally empty explicit universe. Fixed: scanner-linked strategies may use an empty explicit universe; the scanner owns discovery.
3. Malformed `position_sizing.capital_pct` could raise an uncaught `ValueError` and become HTTP 500. Fixed to return normal validation errors.
4. Strategy LIVE arming readiness checked scanner health for every already-armed strategy. An unrelated strategy with an inactive scanner could therefore block a different strategy. Fixed with strategy-scoped readiness for the arm action.
5. Strategy-version endpoint could turn a non-existent strategy ID into a database/server error. Fixed to return HTTP 404.
6. Scanner update/activate/deactivate endpoints could return ambiguous success/null results or 500 on malformed IDs. Fixed with explicit 400/404 contracts.
7. Nginx `/health` was not mapped to Express `/api/health`. Fixed with an exact `/health` rewrite and shared proxy headers.
8. HTTP and HTTPS were not actually using the same application location set despite the deployment comments. Fixed so both transports include the shared locations; ACME challenge remains separate.
9. LIVE readiness now includes concise reconciliation discrepancy kinds/references in the gate detail, so a `discrepancies=N` failure is diagnosable from the UI rather than only showing a count.

## Broker/SDK conformance
- Vendored SDK compared against the supplied official source ZIP.
- Python/typed source files compared: 46 vs 46.
- Missing: 0.
- Extra: 0.
- Content hash differences: 0.
- Vendor remains byte-identical to supplied official SDK source.
- Required runtime SDK version remains 3.0.7.

## LIVE execution safety re-audit
- Explicit owner LIVE arm gate: PASS.
- Strategy-specific scanner authorization: PASS.
- Scanner-linked empty-universe workflow: PASS.
- Scanner-less explicit universe requirement: PASS.
- Candidate subscription required before execution: PASS.
- Shared/reference-counted WebSocket subscriptions: PASS.
- Candidate expiry/disarm cleanup: PASS.
- Restart subscription recovery: PASS.
- Final strategy authorization immediately before entry: PASS.
- Fresh exact-instrument LTP gate: PASS.
- Market feed and order feed gates: PASS.
- Broker session gate: PASS.
- Global daily-loss latch: PASS.
- Strategy daily-loss latch: PASS.
- Exposure/position/order limits: PASS.
- Margin verification for BUY and SELL entries: PASS.
- Duplicate/idempotent order protection: PASS.
- UNKNOWN broker outcome requires reconciliation; no blind retry: PASS.
- Actual broker fill quantity/average price drives algo position state: PASS.
- Protective level validation around actual fill: PASS.
- Exit orders remain available for existing positions under new-entry halts: PASS.
- Reconciliation remains mandatory before new LIVE entries: PASS.

## Market data / scanner re-audit
- Official scrip-master metadata path: PASS.
- Bulk metadata persistence: PASS.
- Historical timeframe chunking: PASS.
- Scanner stale-candle rejection: PASS.
- Candidate registry lifecycle: PASS.
- Scanner-specific universe support: PASS.
- SFeed maximum enforced at 3000: PASS.
- Candidate subscription failure cannot qualify an entry: PASS.

## Strategy/backtest/reconciliation re-audit
- Strategy DSL validation: PASS.
- Nested AND/OR condition groups: PASS.
- Canonical `risk.time_exit_bars`: PASS.
- Strategy sizing modes mutually exclusive: PASS.
- Protective stop required for LIVE arm: PASS.
- Batch candle storage path: PASS.
- Timeframe-aware exit engine: PASS.
- Restart-safe candle runtime state: PASS.
- Broker reconciliation sections: orders, trades, positions, holdings, funds: PASS.
- Partial-fill/order-feed synchronization foundation: PASS.

## Authentication / deployment re-audit
- Express AUTH_REQUIRED is distinguished from downstream broker errors: PASS.
- Browser is not logged out for Kotak/Broker downstream auth failures: PASS.
- Fernet key generation uses canonical URL-safe Base64 with padding: PASS.
- Deployment does not require Kotak credentials during installation: PASS.
- Deployment uses system Node 22 and `node:sqlite`: PASS.
- Python >=3.10 detection/venv setup: PASS.
- Nginx exact health route: PASS.
- Nginx template syntax: PASS.

## Validation results
- Broker-service pytest: **316 passed, 3 skipped**.
- Backend Node tests: **26 passed, 6 skipped**.
- Python compileall: PASS.
- Shell syntax checks: PASS.
- Nginx configuration syntax: PASS.
- Fresh migration chain + idempotency: PASS (covered by backend tests).
- Official SDK source/hash comparison: PASS (46/46 exact).
- ZIP integrity after final packaging: PASS.

## Environment limitation
The supplied frontend package has no lockfile and this isolated environment could not download Vite/React dependencies from npm; both online and offline install attempts were unavailable. Therefore a fresh Vite production build is not claimed as independently executed here. The deployment script remains fail-closed and performs `npm install` followed by `npm run build`, so deployment will stop rather than silently ship an unbuilt frontend.

## Important runtime note
A LIVE readiness `reconciliation` failure is a runtime account-state issue, not something that can be fabricated/fixed inside the source ZIP. The application intentionally blocks new LIVE entries until the latest broker reconciliation is clean. The UI now exposes discrepancy kinds/references to make that state diagnosable.
