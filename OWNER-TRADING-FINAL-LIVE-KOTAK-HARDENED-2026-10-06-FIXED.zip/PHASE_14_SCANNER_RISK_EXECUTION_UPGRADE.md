# Owner Trading — Phase 14 Scanner → Candidate → Risk → Execution Upgrade

## Production execution flow

`Strategy Create → Validate → LIVE ARM → strategy-specific scanner → continuous market-universe scan → scanner condition match → durable candidate → candidate LIVE-feed owner → completed candle/indicator evaluation → strategy entry condition → signal → strategy/global risk → final broker/feed readiness → Kotak order → broker acknowledgement/reconciliation → confirmed fill → algo position → tick-level protective exit / strategy exit / time exit → exit fill → reconciliation.`

## Scanner isolation

- A strategy definition may contain `scanner_ids`.
- Only scanners explicitly referenced by that strategy can create candidates for it.
- An unrelated active scanner cannot qualify or block another strategy.
- Scanner-linked strategies do not subscribe their entire universe at arm time; only matched candidates acquire strategy-owned LIVE-feed subscriptions.
- Scanner-less strategies continue to monitor their explicit instrument universe directly.
- Candidate state is durable in SQLite and survives broker-service restart.
- Candidate expiry releases only that strategy's logical subscription owner.
- Shared instruments use reference-counted logical owners so one strategy cannot unsubscribe a token still required by another strategy.

## Runtime recovery

- Armed scanner-linked candidates are restored on broker-service reconnect/restart.
- Scanner-less strategy universe owners are restored on reconnect/restart.
- The background scanner cycle runs continuously during the NSE cash session.
- Scanner candle timeframes are included only when the scanner is referenced by a LIVE strategy.

## Risk hardening

Existing global limits remain in place. Added:

- maximum total account exposure
- maximum strategy exposure
- maximum strategy positions
- maximum strategy daily loss
- maximum strategy capital allocation
- maximum instrument exposure
- latched global daily-loss halt for the current IST trading day
- final market SFeed/order-feed health gate
- exact-instrument fresh-price gate before LIVE entries

Daily-loss and exposure failures block **new entries**. Existing positions remain eligible for protective/strategy exits.

## Final entry boundary

The final broker boundary checks LIVE mode, owner arming, broker connection, clean reconciliation, unresolved-order state, global daily-loss halt, SDK integrity, SFeed health, order-feed health and exact-instrument price freshness before a LIVE entry reaches Kotak.

Unknown broker outcomes remain reconciliation-required and are never blindly retried.

## Validation

- Broker-service suite: **307 passed, 3 skipped, 0 failed**.
- Python `compileall`: PASS.
- Backend/deployment JavaScript syntax checks: PASS.
- Fresh SQLite migrations 001 → 012: PASS.
- Re-running all migrations: PASS/idempotent.
- Supplied official Kotak Neo source compared with the vendored `neo_api_client` package: **47/47 files identical, 0 mismatches**.
- No real Kotak credentials or real-money order were used during packaging validation.
- Frontend production build could not be executed in the packaging sandbox because npm dependency installation did not complete; the existing deploy script remains the production build gate on the VPS.
