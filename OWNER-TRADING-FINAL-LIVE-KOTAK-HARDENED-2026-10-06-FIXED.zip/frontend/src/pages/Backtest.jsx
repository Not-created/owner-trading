import {useState} from "react";
import usePolling from "../hooks/usePolling";
import {api} from "../api/client";
import EmptyState from "../components/common/EmptyState";

const LIMITS={ "1m":30, "3m":30, "5m":30, "10m":60, "15m":60, "30m":90, "1h":90, "1d":180 };
const DEFAULT_DEF={
  timeframe:"15m",side:"BUY",
  entry:{op:"AND",conditions:[{left:"ema20",operator:">",right:"ema50"}]},
  exit:{op:"OR",conditions:[{left:"rsi14",operator:"<",right:45}]},
  risk:{stop_loss_pct:1,target_pct:2,trailing_stop_pct:0.5,time_exit_bars:12},
  position_sizing:{quantity:1},
  execution:{product:"MIS"}
};

export default function Backtest(){
 const history=usePolling(()=>api.getBacktests(50),5000);
 const [form,setForm]=useState({
   exchange_segment:"nse_cm",instrument_token:"",trading_symbol:"",
   timeframe:"15m",quantity:"1",
   from_date:"",to_date:"",
   initial_capital:"100000",slippage:"0.0005",fees:"0"
 });
 const [def,setDef]=useState(JSON.stringify(DEFAULT_DEF,null,2));
 const [costModelJson,setCostModelJson]=useState(JSON.stringify({entry_brokerage:0,exit_brokerage:0,stt_sell_pct:0,exchange_txn_pct:0,sebi_pct:0,gst_pct:0,stamp_duty_buy_pct:0},null,2));
 const [result,setResult]=useState(null); const [msg,setMsg]=useState(""); const [busy,setBusy]=useState(false);

 function set(k,v){setForm(x=>({...x,[k]:v}));}
 function rangeHint(){
   const days=LIMITS[form.timeframe]||30;
   return `Kotak historical-data is fetched automatically in ${days}-day maximum chunks for ${form.timeframe}.`;
 }
 async function run(){
   setMsg("");setResult(null);
   if(!form.instrument_token.trim())return setMsg("Instrument token is required. Get it from Market Data search.");
   if(!form.from_date||!form.to_date)return setMsg("From date and To date are required.");
   if(form.from_date>form.to_date)return setMsg("From date cannot be after To date.");
   let definition, cost_model;
   try{definition=JSON.parse(def);}catch(e){return setMsg(`Strategy JSON is invalid: ${e.message}`);}
   const strategyTimeframe=String(definition?.timeframe||form.timeframe);
   if(strategyTimeframe!==String(form.timeframe)){
     return setMsg(`Backtest timeframe mismatch: strategy=${strategyTimeframe}, historical dataset=${form.timeframe}. Select the same timeframe before running.`);
   }
   try{cost_model=JSON.parse(costModelJson); if(!cost_model || typeof cost_model!=="object" || Array.isArray(cost_model)) throw new Error("cost_model must be a JSON object");}catch(e){return setMsg(`Cost model JSON is invalid: ${e.message}`);}
   setBusy(true);
   try{
     const r=await api.runBacktest({...form,cost_model,definition});
     if(r.ok){setResult(r.body.result);setMsg("");history.reload();}
     else setMsg(r.body?.validation_errors?.join("; ")||r.body?.error||"Backtest failed");
   }catch(e){setMsg(e.message||"Backtest failed");}
   finally{setBusy(false);}
 }
 return <div className="page">
  <div className="page__header"><h2 className="page__title">Backtest</h2><p className="page__subtitle">Historical analysis only. No broker order path is used. The backend automatically chunks long date ranges to Kotak's historical-data limits.</p></div>
  <div className="card">
   <div className="card__head"><h3 className="card__title">Historical Dataset</h3></div>
   <div className="order-form">
    <input value={form.exchange_segment} onChange={e=>set("exchange_segment",e.target.value)} placeholder="exchange segment"/>
    <input value={form.instrument_token} onChange={e=>set("instrument_token",e.target.value)} placeholder="instrument token (e.g. 11915)" required/>
    <input value={form.trading_symbol} onChange={e=>set("trading_symbol",e.target.value)} placeholder="trading symbol (e.g. YESBANK-EQ)"/>
    <select value={form.timeframe} onChange={e=>set("timeframe",e.target.value)}>{Object.keys(LIMITS).map(x=><option key={x}>{x}</option>)}</select>
    <input type="number" min="1" value={form.quantity} onChange={e=>set("quantity",e.target.value)} placeholder="quantity"/>
    <input type="date" value={form.from_date} onChange={e=>set("from_date",e.target.value)}/>
    <input type="date" value={form.to_date} onChange={e=>set("to_date",e.target.value)}/>
    <input type="number" min="1" step="any" value={form.initial_capital} onChange={e=>set("initial_capital",e.target.value)} placeholder="initial capital ₹"/>
    <input type="number" min="0" step="any" value={form.slippage} onChange={e=>set("slippage",e.target.value)} placeholder="slippage (fraction)"/>
    <input type="number" min="0" step="any" value={form.fees} onChange={e=>set("fees",e.target.value)} placeholder="legacy flat brokerage ₹ / side"/>
   </div>
   <p className="form-hint">Optional cost_model supports entry/exit brokerage plus STT, exchange transaction, SEBI, GST and stamp-duty percentages. Zero means disabled; rates remain configurable rather than hard-coded.</p>
   <p className="form-hint">{rangeHint()}</p>
   <textarea rows="18" style={{width:"100%",fontFamily:"monospace"}} value={def} onChange={e=>setDef(e.target.value)}/>
   <textarea rows="7" style={{width:"100%",fontFamily:"monospace",marginTop:10}} value={costModelJson} onChange={e=>setCostModelJson(e.target.value)} aria-label="Backtest cost model"/>
   <button onClick={run} disabled={busy}>{busy?"Running…":"Run Backtest"}</button>
   {msg&&<p className="form-error">{msg}</p>}
  </div>
  {result&&<div className="card">
   <div className="card__head"><h3 className="card__title">Backtest Results</h3></div>
   <div className="metrics-grid">
    {[
      ["Net P&L",result.net_pnl],["CAGR",result.cagr==null?"—":`${Number(result.cagr).toFixed(2)}%`],
      ["Win Rate",`${Number(result.win_rate).toFixed(2)}%`],["Profit Factor",result.profit_factor==null?"—":Number(result.profit_factor).toFixed(2)],
      ["Sharpe",result.sharpe==null?"—":Number(result.sharpe).toFixed(2)],["Sortino",result.sortino==null?"—":Number(result.sortino).toFixed(2)],
      ["Max Drawdown",result.max_drawdown],["Total Trades",result.total_trades]
    ].map(([k,v])=><div key={k}><strong>{k}</strong><h2>{typeof v==="number"?v.toFixed(2):v}</h2></div>)}
   </div>
   <p className="form-hint">Dataset: {result.data_window?.candles??"—"} candles · {result.data_window?.chunk_count??0} broker chunks · {result.data_window?.from_date} → {result.data_window?.to_date}</p>
   <pre style={{whiteSpace:"pre-wrap",overflowX:"auto"}}>{JSON.stringify(result.trades,null,2)}</pre>
  </div>}
  <div className="card"><h3>Run History</h3>{(history.body?.backtests||[]).map(x=><div key={x.id}><strong>#{x.id}</strong> · {x.status} · {x.created_at} · {x.result?.net_pnl??"—"}</div>)}</div>
 </div>;
}
