# Owner Trading — Kotak Neo Reconciliation / REST Diagnostic Fix
Date: 2026-10-05

## Scope
Current Owner Trading ZIP was audited against the user-supplied official Kotak Neo Python SDK ZIP (v3.0.7). The existing official SDK vendor tree was preserved; the project adapter/reconciliation layer was hardened without replacing the SDK.

## Root cause observed from VPS logs
Kotak returned a real HTTP/status 424 response for holdings:
- endpoint: `/portfolio/v1/holdings`
- HTTP status: 424
- Kotak stCode: 424
- errMsg: `No holdings found for this client ...`
- response shape: `stat=Not_Ok` + `error`/`errMsg`

This is an empty portfolio condition, not a login/session failure. The same class of exact `No <section> found/available/data/records` response is now normalized for read-only order/trade/position/holding collections. Unrelated 424 responses remain failures and still block LIVE.

## Fixes
1. Added stable broker REST diagnostics to every SDK adapter Outcome:
   - method
   - exact endpoint resolved from official SDK configuration
   - HTTP status
   - Kotak stCode/errorCode
   - Kotak errMsg/message
   - sanitized response body
   - session/auth indication
   - transport exception
2. SDK ApiException status/body/reason are extracted into the diagnostics envelope.
3. Sensitive response keys are redacted before diagnostics are persisted/returned.
4. `Outcome.as_dict()` now exposes the diagnostic envelope.
5. Reconciliation failure records now persist broker diagnostics instead of only `kind/message`.
6. LIVE readiness now shows HTTP, stCode, errMsg, endpoint, session indication and transport details for reconciliation failures.
7. Empty 424 responses are safely normalized for orders, trades, positions and holdings when the message explicitly indicates no records. This does NOT bypass real 424 failures.
8. Transport failures remain non-success and continue to block LIVE; their transport exception is explicitly surfaced.
9. Session/auth failures remain distinct and continue to transition the broker session to expired when appropriate.

## Broker compatibility
The vendored `neo_api_client` package source is byte-identical to the user-supplied SDK package source. No broker SDK source was rewritten.

## Validation
- Broker service pytest: 318 passed, 3 skipped
- Backend Node tests: 26 passed, 6 skipped
- Python compile: PASS
- Shell syntax: PASS
- SQLite migration tests: PASS
- Vendor/package source comparison: PASS (47 package files compared, 0 missing, 0 extra, 0 differences)
- Frontend Vite production build: not run in this environment because frontend node_modules are not installed and external npm installation was unavailable; deploy.sh remains fail-closed on frontend build failure.

## Safety behavior
The system must NOT convert an arbitrary 424, 401/403, timeout, 5xx, malformed response, or unknown response into a successful empty section. Only the exact empty-collection message family is normalized. A clean reconciliation remains mandatory before LIVE entry.
