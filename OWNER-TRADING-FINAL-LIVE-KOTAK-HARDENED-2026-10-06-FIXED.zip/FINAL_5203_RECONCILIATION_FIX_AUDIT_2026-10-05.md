# Owner Trading — Final 5203 No-Data Reconciliation Fix & Full Scan

Date: 2026-10-05

## 1. Scope

This release was re-audited from the uploaded ZIP after the earlier diagnosis that LIVE readiness was blocked by Kotak `stCode=5203 / errMsg=No Data` responses from order/trade/position reads.

The audit did **not** bypass LIVE safety gates. The fix is limited to the documented safe empty-read contract and the strategy ARM scanner-ID validation boundary.

## 2. Root cause confirmed

The previous `sdk_adapter._empty_read_response()` normalized only the narrow 424 empty-account responses. Kotak's documented 5203 No Data response therefore fell through to normal error classification and reconciliation recorded:

- `order_report_failed`
- `trade_report_failed`
- `positions_failed`

That made reconciliation `DISCREPANCY`, which correctly made LIVE readiness false and the global ARM control unavailable.

Official SDK documentation:
https://github.com/Kotak-Neo/kotak-neo-python/blob/main/docs/functions/README.md

The official response contract is:

```json
{
  "stCode": 5203,
  "errMsg": "No Data",
  "desc": "data not found",
  "stat": "Not_Ok"
}
```

## 3. Fix implemented

### `broker-service/app/sdk_adapter.py`

`_empty_read_response()` now recognizes Kotak 5203 only when the safe contract matches:

- `stCode == 5203`
- `errMsg == "No Data"` (case-insensitive, surrounding whitespace ignored)
- `stat == "Not_Ok"` / `NotOk`
- `desc`, when present, must be `data not found`
- an optional HTTP status must not itself be 4xx/5xx

Only these read-only collection methods use this normalization:

- `order_report()` -> `[]`
- `trade_report()` -> `[]`
- `positions()` -> `[]`
- `holdings()` -> `[]`

The adapter marks the diagnostic classification as `KOTAK_NO_DATA` and preserves the full redacted diagnostic envelope.

### Safety behavior retained

The following are **not** converted to empty data:

- 403 / invalid session
- 429 / rate limit
- 500/502/503/504
- timeout / transport failures
- malformed 5203 bodies
- 5203 with an HTTP failure status
- unrelated 424 broker errors
- other broker rejection responses

`classify()` itself still treats 5203 as a failure. This prevents the no-data interpretation from leaking into order submission or unrelated broker operations.

## 4. Reconciliation hardening

`broker-service/app/reconciliation.py` no longer performs a second, free-form message-based 424 classification for positions/holdings.

It now consumes the adapter's `Outcome.ok` result as the single response-classification boundary. This prevents reconciliation from inventing its own interpretation of broker errors.

Therefore:

`documented 5203 -> adapter [] -> Outcome.ok -> clean section -> COMPLETE`

while:

`real broker failure -> Outcome not ok -> discrepancy -> LIVE remains blocked`

## 5. Strategy ARM validation hardening

`broker-service/app/server.py` now uses one strict scanner-ID parser at the LIVE safety boundary.

Malformed/invalid scanner IDs are no longer silently discarded.

Examples now return HTTP 422:

- `scanner_ids: ["not-an-id"]`
- `scanner_ids: [0]`
- `scanner_ids: [-1]`
- `scanner_ids` not being a list

Valid positive integer IDs are deduplicated and then checked for existence/activity as before.

Malformed `version_id` input is also rejected with HTTP 400 instead of risking a server-side conversion exception.

## 6. Regression coverage added

New tests cover:

- 5203 No Data for orders
- 5203 No Data for trades
- 5203 No Data for positions
- 5203 No Data for holdings
- malformed 5203 remains rejected
- 5203 + HTTP 500 remains rejected
- `classify()` does not globally treat 5203 as success
- full reconciliation with all four empty 5203 sections is `COMPLETE`, zero discrepancies
- malformed 5203 blocks reconciliation
- malformed scanner IDs cannot be silently dropped during LIVE strategy arm
- non-positive scanner IDs are rejected

Existing 424 empty-account behavior remains covered.

## 7. Full project safety audit checks

The following previously identified hardening areas were rechecked:

- Express AUTH_REQUIRED is separated from downstream broker/Kotak 401 responses.
- Metadata sync uses batch SQLite UPSERT and reports failure stages.
- Scanner-linked strategies do not require a pre-existing candidate subscription to arm.
- Shared/reference-counted WebSocket ownership is retained.
- Strategy disarm releases only that strategy's logical owners and deactivates candidates.
- LIVE readiness checks the actual subscription registry rather than a nonexistent `subscribed` field.
- Exit engine uses the strategy timeframe through `TIMEFRAME_MINUTES`.
- Backtest historical candle storage uses bulk `upsert_candles()`.
- Candle runtime state is persisted and restored after restart.
- Global/strategy/instrument exposure and daily-loss gates remain in the order risk path.
- Controlled exits are not blocked by entry-only exposure limits.
- Broker UNKNOWN submission outcomes remain reconciliation-required and are not blindly retried.
- Protective levels are checked against actual broker average fill on recovery.
- Fernet generation in deployment uses canonical padded URL-safe Base64 and refuses unsafe silent key rotation when an encrypted credential store exists.
- Nginx `/health` handling remains explicit.
- Official vendored Kotak SDK integrity/conformance remains covered.

## 8. Validation results

Broker service:

`326 passed, 3 skipped`

Backend Node tests:

`26 passed, 6 skipped`

Backend migration/idempotency suite:

`26 passed, 6 skipped` (included in the backend Node test run)

Python compile:

PASS

Node syntax checks:

PASS

Shell syntax checks:

PASS

ZIP integrity:

PASS

Frontend production build:

**NOT CLAIMED AS PASS**. The packaging environment could not complete `npm install --no-audit --no-fund` before the execution timeout, and `vite` was therefore unavailable locally. The deployment script remains fail-closed and runs the real frontend dependency install plus `npm test` and `npm run build` on the target VPS.

Runtime SDK import:

The vendored SDK is version 3.0.7 and its integrity/conformance check passes, but this packaging sandbox does not have the complete production Python dependency installation. Therefore a live `neo_api_client` runtime import is not falsely claimed as locally verified.

## 9. Expected production behavior after deployment

If the Kotak account genuinely has no orders, trades, positions, or holdings:

- Orders -> PASS / 0
- Trades -> PASS / 0
- Positions -> PASS / 0
- Holdings -> PASS / 0
- Funds -> PASS
- `recent_reconciliation` -> PASS
- `reconciliation_sections_complete` -> PASS
- `Ready` -> YES
- `Armed` -> NO until owner explicitly arms
- `LIVE orders can be sent` -> NO until global LIVE arm succeeds

Typing the exact owner confirmation `ARM LIVE TRADING` can then arm global LIVE only if every other readiness gate is still passing.

No reconciliation gate is bypassed by this fix.
