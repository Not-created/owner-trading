# Owner Trading — Phase 1–5 Upgrade Report

Source package: `owner-trading-FINAL-BROKER-CONNECTION-FIXED-DARK-LIGHT-FINAL-v3.zip`

## Scope

This release completes the first five production upgrade areas together while preserving the locked architecture, current Dark/Light theme, and the vendored official Kotak Neo SDK tree.

### Phase 1 — Production safety / runtime resilience
- Added SQLite-backed Express sessions so the owner web session survives a backend process restart instead of relying on the default in-memory session store.
- Added migration `011_phase1_5_runtime_safety.sql` for persistent web sessions and crash-recoverable forming candle state.
- Added SQLite startup `PRAGMA integrity_check`; backend startup remains DEGRADED if migration/integrity validation fails.
- Added pre-deploy SQLite integrity verification and a consistent `VACUUM INTO` backup with 10-backup retention before migrations.
- Added a small systemd file-descriptor hardening limit without changing service paths, theme, or broker SDK.

### Phase 2 — Strategy engine / risk contract
- Strategy validation now rejects stop/target levels that are geometrically invalid for BUY/SELL direction.
- Strategy validation now rejects mixing fixed quantity, capital percentage and risk-per-trade sizing modes.
- LIVE arming now requires a protective stop configuration and a non-empty synced instrument universe.
- LIVE arming verifies every selected NSE instrument token exists in the authoritative metadata cache.
- Existing canonical `risk.time_exit_bars`, timeframe-aware exits, BUY/SELL logic and existing strategy DSL remain intact.

### Phase 3 — Backtest accuracy / portfolio metrics
- Backtest costs are split into explicit entry and exit legs, with brokerage, STT, exchange transaction, SEBI, GST and stamp-duty components.
- Entry costs are allocated per unit so partial exits carry the correct share of entry cost.
- Equity curve is now generated across the candle series rather than only at trade exits, providing a portfolio mark-to-market series for risk metrics.
- Sharpe/Sortino continue to use daily realized portfolio-equity returns on a 252-session annualization basis, not trade-level returns.
- Added deterministic historical data-quality metadata including malformed timestamp count and intraday gap detection.
- Historical chunking limits and timestamp normalization remain unchanged and compatible with Kotak's documented historical endpoint.

### Phase 4 — Market data / SFeed reliability
- Added crash-recoverable forming-candle persistence with cumulative-volume baseline recovery.
- Live universe subscription now uses batched SFeed subscribe/unsubscribe frames instead of one broker frame per token.
- The existing 3000-token SFeed cap, persisted LIVE subscription recovery and disarm cleanup remain enforced.
- No change was made to the official SDK vendor tree.

### Phase 5 — Orders / execution safety
- Modify requests now exclude their own known local order from the unresolved-submission safety scan, so an otherwise valid modification is not blocked by the very order being modified.
- The durable local-before-broker order record, client-tag reconciliation, UNKNOWN outcome handling, order-feed/REST synchronization, partial-fill handling, and immutable strategy ENTRY/EXIT chain remain in place.
- No blind retry was introduced for ambiguous broker submissions.

## Validation performed in this build

- Broker-service pytest: **285 passed, 3 skipped, 0 failed**.
- Python compileall: **PASS**.
- Shell syntax checks for `deploy.sh` and `deployment/verify-deployment.sh`: **PASS**.
- Node syntax checks for changed backend JavaScript: **PASS**.
- Fresh SQLite execution of migrations `001` through `011`: **PASS**; `PRAGMA integrity_check` returned `ok`.
- Strategy validation smoke test: **PASS**.
- Backtest smoke test: **PASS**, including candle-level equity curve generation.
- Dark/Light frontend files were not modified.
- Vendored `broker-service/vendor/kotakneoapi` files were not modified.

## Environment limitation

The packaging environment does not have the project's npm dependencies installed and cannot be used to claim a production Vite build or full Express runtime test. The release therefore does **not** falsely claim a frontend build PASS. `deploy.sh` remains responsible for installing dependencies and running the production frontend build on the VPS.

## Kotak SDK compatibility boundary

The release keeps the project's verified vendored `kotakneoapi` 3.0.7 tree unchanged. Current Kotak documentation confirms the modern async SFeed `subscribe_scrips`/`unsubscribe_scrips` model and a 3000-token subscription limit, and the historical endpoint's documented interval/range limits remain the basis of the existing chunker.

## LIVE-money boundary

No real Kotak credentials were used and no real-money order was submitted during packaging. The ZIP is a software upgrade; broker-side LIVE execution still requires the existing controlled VPS verification and readiness gates.
