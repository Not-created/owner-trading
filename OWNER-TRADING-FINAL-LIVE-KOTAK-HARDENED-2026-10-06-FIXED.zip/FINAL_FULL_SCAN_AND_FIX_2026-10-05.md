# Owner Trading — Full Scanner/Risk/LIVE Flow Audit & Fix

Date: 2026-10-05

## Target execution contract

Strategy Create -> Validation -> explicit LIVE arm -> strategy-specific scanner -> continuous fresh market scan -> scanner match -> durable candidate -> LIVE feed ownership -> fresh ticks -> candle -> strategy entry -> signal -> sizing -> risk -> final LIVE readiness -> Kotak order -> order-feed/reconciliation -> fill -> algo position -> protective/strategy exit -> reconciliation.

## Additional production bugs found and fixed

1. **Scanner-linked LIVE arming deadlock**
   - Scanner-linked strategies were required to have an explicit instrument universe even though the scanner was intended to own discovery.
   - Post-arm global readiness also required candidate subscriptions before the first scanner match, creating a circular dependency.
   - Fixed: scanner-linked strategies may use the scanner universe; arming no longer requires a candidate to exist before the strategy can wait for one.

2. **Frontend scanner-only strategy creation was blocked**
   - The Strategy Builder rejected an empty universe even when an active scanner was selected.
   - Fixed: a LIVE strategy now requires either an explicit universe or at least one active strategy-specific scanner.

3. **Candidate execution did not require successful subscription**
   - A candidate could remain ACTIVE even after its subscription failed, and the execution lookup treated it as eligible.
   - Fixed: execution requires an active, subscribed, error-free candidate.

4. **Final order gate did not enforce strategy-specific LIVE permission**
   - A stale strategy signal could reach the broker after the strategy was disarmed, or after its candidate/scanner was removed.
   - Fixed: final broker gate verifies the strategy version is still LIVE armed, the candidate is active/subscribed, and the linked scanner remains active.

5. **Margin verification was BUY-specific**
   - Entry margin verification previously ran only for BUY.
   - Fixed: all new LIVE ENTRY directions perform fresh reference-price + Kotak margin verification. The actual order remains MKT when requested.

6. **Strategy daily-loss limit was not latched**
   - A strategy could fall below its daily-loss threshold and later become eligible again if P&L recovered.
   - Fixed: per-strategy IST-date daily-loss halt state is persisted and latched. It blocks only that strategy's new entries; exits remain allowed.

7. **Risk settings API integration gap**
   - The Express risk route forwarded only the original five limits even though the UI exposed the new exposure limits.
   - Fixed: all production risk settings are now forwarded to the broker service.

8. **Scanner stale-data acceptance**
   - Scanner evaluation could consume an old candle from SQLite without verifying its age.
   - Fixed: intraday scanner candles must be fresh relative to their timeframe; daily candles have a bounded multi-day freshness window.

9. **Protective-level recovery validation**
   - Absolute stop/target levels were not explicitly checked against the actual broker average fill during position recovery.
   - Fixed: a recovered position is not resumed into LIVE exit management if BUY/SELL protective levels are on the wrong side of the actual entry.

10. **False `/health` HTTP 200 from SPA fallback**
    - `/health` could return frontend `index.html`, producing a misleading health result.
    - Fixed: Nginx now proxies exact `/health` to the backend health endpoint.

## Preserved architecture

- React + Vite frontend
- Express + Node.js backend
- SQLite
- Persistent Python broker service
- Official Kotak Neo Python SDK 3.0.7
- Existing candle engine
- Existing order lifecycle/idempotency/UNKNOWN reconciliation
- Existing authentication and encrypted credentials
- Existing protective exit engine
- Existing reconciliation
- HTTP + HTTPS support
- One-click deployment

No second broker architecture was introduced and no existing production secrets/database data are packaged.

## Official SDK verification

Uploaded official Kotak Neo SDK vs vendored `broker-service/vendor/kotakneoapi/neo_api_client`:

- Official Python source files checked: 46
- Vendored Python source files checked: 46
- Missing: 0
- Extra: 0
- Hash differences: 0
- SDK version: 3.0.7

## Validation actually executed

- Broker-service pytest: **310 passed, 3 skipped**
- Backend Node tests: **26 passed, 6 skipped**
- Python compile: PASS
- Node syntax: PASS
- Shell syntax: PASS
- Fresh SQLite migration chain through migration 013: PASS
- Migration idempotency: PASS
- Final ZIP extraction/integrity: PASS
- Official SDK source comparison: PASS

## Not verified in this packaging environment

Fresh frontend `npm install` timed out because external npm registry access did not complete within the execution window. Therefore a fresh Vite production build was not claimed as passed. The production `deploy.sh` remains fail-closed: it installs dependencies and runs `npm run build`; deployment stops if the frontend build fails.
