"""Continuous strategy-specific universe scanning and candidate management.

A scanner match is never an order signal by itself. It creates a durable
(strategy_version, instrument) candidate, acquires a logical LIVE-feed owner,
and lets the strategy engine perform the complete entry/risk/readiness chain.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import logging
import os
import re
import time
from zoneinfo import ZoneInfo
from . import db, strategy_engine
from .websocket_manager import websocket_manager

logger = logging.getLogger("owner_trading.scanner")
IST = ZoneInfo("Asia/Kolkata")
MAX_UNIVERSE = 3000
DEFAULT_CANDIDATE_TTL_BARS = 3


def _expiry_for(timeframe: str, definition: dict) -> str:
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 5))
    bars = int(definition.get("candidate_ttl_bars") or DEFAULT_CANDIDATE_TTL_BARS)
    bars = max(1, min(bars, 20))
    when = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=minutes * bars)
    return when.strftime("%Y-%m-%d %H:%M:%S")


def _scanner_universe(scanner: dict, fallback: list[dict]) -> list[dict]:
    definition=scanner.get("definition") or {}
    universe=definition.get("universe") if isinstance(definition,dict) else None
    tokens=[]
    if isinstance(universe,dict):
        tokens=[str(x).strip() for x in (universe.get("instrument_tokens") or []) if str(x).strip()]
    if not tokens:
        return fallback
    out=[]
    for tok in dict.fromkeys(tokens[:MAX_UNIVERSE]):
        inst=db.get_instrument("nse_cm",tok)
        if inst: out.append(inst)
    return out


def _candle_is_fresh(candle_at: str, timeframe: str) -> bool:
    try:
        raw=str(candle_at).replace("Z","+")
        stamp=dt.datetime.fromisoformat(raw)
        # Stored candle_at values are naive NSE (IST) wall-clock times, exactly as the candle
        # engine and historical loader write them -- NOT UTC. Reading them as UTC put every
        # candle 5.5h in the future and made the scanner treat all of them as stale.
        if stamp.tzinfo is None: stamp=stamp.replace(tzinfo=IST).astimezone(dt.timezone.utc)
        else: stamp=stamp.astimezone(dt.timezone.utc)
        minutes=int(strategy_engine.TIMEFRAMES.get(timeframe,5))
        age=(dt.datetime.now(dt.timezone.utc)-stamp).total_seconds()
        # Scanner works on completed candles. Intraday bars must be recent; a
        # daily bar may legitimately be the previous completed trading day.
        max_age=72*3600 if minutes>=1440 else max(3*minutes*60, 180)
        return 0 <= age <= max_age
    except (TypeError,ValueError,OverflowError):
        return False


MIN_BARS = 20
MAX_WARMUP_PER_CYCLE = 40
MAX_HISTORY_CHUNKS = 6      # broker chunks one instrument's warm-up may use (most definitions need one)
BARS_PER_TRADING_DAY = {"1m": 375, "3m": 125, "5m": 75, "10m": 38, "15m": 25, "30m": 13, "1h": 7, "1d": 1}


def history_calendar_days(timeframe: str, need_bars: int) -> int:
    """Smallest calendar window that covers `need_bars` completed bars (weekends/holidays included),
    kept inside ONE Kotak chunk so a single small request is made per instrument."""
    from . import backtest_service
    per_day = BARS_PER_TRADING_DAY.get(timeframe, 25)
    trading_days = -(-int(need_bars) // per_day) + 1
    days = -(-trading_days * 7 // 5) + 5
    # One small request when it fits in one broker chunk; a long window (1h/daily with ema200 ...) takes a few chunks.
    cap = (backtest_service.HISTORICAL_MAX_DAYS.get(timeframe, 30) - 1) * MAX_HISTORY_CHUNKS
    return max(3, min(days, cap))


def _definition_operands(definition: dict) -> set[str]:
    out: set[str] = set()

    def walk(group):
        if not isinstance(group, dict):
            return
        for c in group.get("conditions") or []:
            if isinstance(c, dict):
                for k in ("left", "right"):
                    if isinstance(c.get(k), str):
                        out.add(c[k].strip().lower())
        for child in group.get("groups") or []:
            walk(child)
    for part in ("entry", "exit"):
        walk(definition.get(part))
    return out


MAX_REQUIRED_BARS = strategy_engine.ANALYSIS_MAX_WINDOW


def required_bars(definition: dict) -> int:
    """Completed bars of history a definition needs: the ANALYSIS WINDOW, i.e. enough for every operand to be converged
    (ema20 -> 65, rsi14 -> 87, adx14 -> 115, macd -> 152, vwap -> a whole session ...), not merely defined. Scanner, live
    strategy and backtest all evaluate on exactly this many bars, which is what makes their results identical."""
    return min(max(MIN_BARS, strategy_engine.analysis_window(definition)), MAX_REQUIRED_BARS)


def _bar_is_complete(candle_at: str, timeframe: str, now_ist: dt.datetime) -> bool:
    """A bar is complete once its whole window has elapsed (history may include the forming bar)."""
    try:
        start = dt.datetime.strptime(db.canonical_candle_at(candle_at), "%Y-%m-%d %H:%M:%S").replace(tzinfo=IST)
    except ValueError:
        return False
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 5))
    # Session-aware: the 15:15 bar of a 30m/1h series completes at the 15:30 close (not 15:45/16:15), and a daily bar
    # completes at the close (not at the next midnight) -- otherwise the day's last bar was never scanned.
    from .market_session import bar_end
    return bar_end(start, minutes) <= now_ist


async def _candles_barrier() -> None:
    """Make sure every bar that has closed by the clock is in SQLite before candles are read for a scan."""
    import asyncio
    from .candle_engine import candle_engine
    from .tick_writer import tick_writer
    try:
        candle_engine.finalize_due(grace_seconds=0.0)
        await asyncio.to_thread(tick_writer.flush)
    except Exception as exc:  # noqa: BLE001 -- a failed barrier must not stop the scan; it falls back to what is stored
        logger.warning("Candle barrier before scan failed: %s", exc)


DEFAULT_MAX_CANDIDATES = 50
SCAN_FEED_BUDGET = 3000          # Kotak's documented simultaneous SFeed subscription limit
SCAN_FEED_RESERVE = 200          # always kept free for open positions, candidates, manual and order-time feeds
SCAN_UNIVERSE_CAP = SCAN_FEED_BUDGET - SCAN_FEED_RESERVE


def scan_options(definition: dict) -> dict:
    scan = definition.get("scan") if isinstance(definition, dict) else None
    scan = scan if isinstance(scan, dict) else {}
    try:
        cap = int(scan.get("max_candidates") or DEFAULT_MAX_CANDIDATES)
    except (TypeError, ValueError):
        cap = DEFAULT_MAX_CANDIDATES
    return {
        "series": [str(x).upper() for x in (scan.get("series") or ["EQ"])],
        "min_price": strategy_engine._num(scan.get("min_price")) if scan.get("min_price") is not None else None,
        "max_price": strategy_engine._num(scan.get("max_price")) if scan.get("max_price") is not None else None,
        "min_avg_volume": strategy_engine._num(scan.get("min_avg_volume")) if scan.get("min_avg_volume") is not None else None,
        "max_candidates": max(1, min(cap, 500)),
        "rank_by": str(scan.get("rank_by") or "volume"),
    }


def scan_universe(definition: dict, limit: int | None = None) -> list[dict]:
    """Stocks a scanner looks at: the instruments it names explicitly, otherwise every stock in its
    chosen series (EQ by default) -- no alphabetical cut-off, capped to the feed budget."""
    explicit = _scanner_universe({"definition": definition}, [])
    if explicit:
        return explicit
    cap = min(int(limit or SCAN_UNIVERSE_CAP), SCAN_UNIVERSE_CAP)
    return db.list_scan_universe(scan_options(definition)["series"], limit=cap)


def universe_coverage(definition: dict, universe: list[dict] | None = None) -> dict:
    """The real size of what a scanner is meant to cover versus what it actually scans.

    ``eligible_total`` is every stock of the chosen series; ``universe`` is what is scanned (the live-feed cap cuts
    it). Nothing here is a sample: these are counts from the instrument table, so the UI never has to guess."""
    explicit = bool(_scanner_universe({"definition": definition}, []))
    series = scan_options(definition)["series"]
    scanned = len(universe) if universe is not None else len(scan_universe(definition))
    eligible = scanned if explicit else db.count_scan_universe(series)
    truncated = max(0, eligible - scanned)
    out = {"series": series, "explicit": explicit, "eligible_total": eligible, "universe": scanned,
           "cap": SCAN_UNIVERSE_CAP, "truncated": truncated,
           "coverage_pct": round(100.0 * scanned / eligible, 1) if eligible else 100.0, "warning": None}
    if truncated:
        out["warning"] = (f"{truncated} of {eligible} stocks are beyond the {SCAN_UNIVERSE_CAP}-stock live-feed limit "
                          "and are NOT scanned. Narrow the stock filter (series, price, volume) or name the instruments.")
    return out


def _rank_value(rank_by: str, candles: list[dict]) -> float:
    last = candles[-1]
    close = float(last["close"]); vol = float(last.get("volume") or 0)
    if rank_by == "turnover":
        return close * vol
    if rank_by == "price":
        return close
    if rank_by == "change_pct":
        prev = float(candles[-2]["close"]) if len(candles) >= 2 else 0.0
        return (close / prev - 1) * 100 if prev else 0.0
    return vol


def _why(detail: dict) -> list[str]:
    out = []
    for item in (detail or {}).get("items", []):
        if "reason" in item and item.get("passed"):
            out.append(str(item["reason"]).replace(" => True", ""))
        elif "group_result" in item and item.get("passed"):
            out.extend(_why(item["group_result"]))
    return out


def _scan_with_stats(universe: list[dict], definition: dict, timeframe: str) -> tuple[list[dict], dict]:
    """Evaluate the entry conditions on COMPLETED bars; apply the stock filters; rank and cap the matches;
    and say exactly why instruments were skipped."""
    started = time.monotonic()
    opts = scan_options(definition)
    need = required_bars(definition)
    candle_map = db.recent_candles_for_instruments(universe, timeframe, min(need + 3, 600))
    now_ist = dt.datetime.now(IST)
    stats = {"universe": len(universe), "no_candles": 0, "insufficient_history": 0, "stale": 0, "filtered_out": 0,
             "evaluated": 0, "matched": 0, "matched_total": 0, "capped": 0, "required_bars": need, "latest_candle_at": None}
    matched = []
    for instrument in universe:
        candles = candle_map.get((instrument["exchange_segment"], str(instrument["instrument_token"])), [])
        while candles and not _bar_is_complete(candles[-1].get("candle_at"), timeframe, now_ist):
            candles = candles[:-1]
        if not candles:
            stats["no_candles"] += 1
            continue
        last_at = db.canonical_candle_at(candles[-1]["candle_at"])
        if stats["latest_candle_at"] is None or last_at > stats["latest_candle_at"]:
            stats["latest_candle_at"] = last_at
        if len(candles) < need:
            stats["insufficient_history"] += 1
            continue
        if not _candle_is_fresh(last_at, timeframe):
            stats["stale"] += 1
            continue
        price = float(candles[-1]["close"])
        if (opts["min_price"] is not None and price < opts["min_price"]) or (opts["max_price"] is not None and price > opts["max_price"]):
            stats["filtered_out"] += 1
            continue
        if opts["min_avg_volume"] is not None:
            vols = [float(c.get("volume") or 0) for c in candles[-20:]]
            if sum(vols) / len(vols) < opts["min_avg_volume"]:
                stats["filtered_out"] += 1
                continue
        stats["evaluated"] += 1
        passed, detail = strategy_engine.evaluate_entry(definition, candles)
        if passed:
            matched.append({"instrument": instrument, "price": candles[-1]["close"], "details": detail, "candle_at": last_at,
                            "rank": _rank_value(opts["rank_by"], candles), "why": _why(detail)})
    matched.sort(key=lambda m: m["rank"], reverse=True)
    stats["matched_total"] = len(matched)
    if len(matched) > opts["max_candidates"]:
        stats["capped"] = len(matched) - opts["max_candidates"]
        matched = matched[:opts["max_candidates"]]
    stats["matched"] = len(matched)
    stats["took_ms"] = int((time.monotonic() - started) * 1000)
    # Data readiness (real counts): ready = could be judged on completed bars; not_ready = could not be judged yet.
    stats["ready"] = stats["evaluated"] + stats["filtered_out"]
    stats["not_ready"] = stats["no_candles"] + stats["insufficient_history"] + stats["stale"]
    stats["readiness_pct"] = round(100.0 * stats["ready"] / stats["universe"], 1) if stats["universe"] else 0.0
    return matched, stats


def _scan(universe: list[dict], definition: dict, timeframe: str) -> list[dict]:
    return _scan_with_stats(universe, definition, timeframe)[0]


def explain_scan(stats: dict, *, market_open: bool) -> str:
    """One human sentence for the UI: why a scan produced what it produced."""
    if stats["universe"] == 0:
        return "No NSE instruments in the database. Sync Market Data (NSE cash scrip master) first."
    if stats["evaluated"] == 0:
        if stats["no_candles"] >= stats["universe"]:
            return ("No candle history exists for any instrument. Candles come from live ticks or Kotak historical data; "
                    "the scanner is loading history in batches -- run it again until 'remaining' reaches 0.")
        if stats["insufficient_history"] and not stats["stale"]:
            return (f"{stats['insufficient_history']} instruments have candles but fewer than the {stats['required_bars']} bars "
                    "this scanner's indicators need. Run again to keep loading history.")
        if stats["stale"]:
            return ("Candle history is stale (latest completed bar: %s). %s" % (
                stats["latest_candle_at"], "Wait for the next completed bar." if market_open else
                "The market is closed, so intraday scans only evaluate while it is open."))
    if stats["matched"] == 0:
        return f"Evaluated {stats['evaluated']} instruments on completed bars; none satisfy the entry conditions right now."
    extra = f" (top {stats['matched']} kept of {stats['matched_total']} matches)" if stats.get("capped") else ""
    return f"{stats['matched_total']} of {stats['evaluated']} evaluated instruments match{extra}."


def _with_coverage_warning(text: str, stats: dict) -> str:
    warning = (stats.get("coverage") or {}).get("warning")
    return f"{text} {warning}" if warning else text


def _warmup_targets(universe: list[dict], timeframe: str, definition: dict, need: int) -> list[dict]:
    """Instruments that cannot be evaluated yet (too few completed bars or a stale last bar)."""
    # Only the newest `need` completed bars matter (the scan reads the same window). 250 rows per stock made this
    # take ~11 s for 2,800 stocks, and a scanner needing more than 250 bars could never be satisfied.
    candle_map = db.recent_candles_for_instruments(universe, timeframe, min(need + 3, 600))
    now_ist = dt.datetime.now(IST)
    targets = []
    for inst in universe:
        complete = candle_map.get((inst["exchange_segment"], str(inst["instrument_token"])), [])
        while complete and not _bar_is_complete(complete[-1].get("candle_at"), timeframe, now_ist):
            complete = complete[:-1]                 # an unfinished bar can only be the last one
        ok = len(complete) >= need and complete and _candle_is_fresh(db.canonical_candle_at(complete[-1]["candle_at"]), timeframe)
        if not ok:
            targets.append(inst)
    return prioritize_targets(targets)


def prioritize_targets(targets: list[dict]) -> list[dict]:
    """Back-fill order: (1) instruments with an open position or an active candidate, (2) the busiest stocks (last known
    volume), (3) the rest in stable token order. When time runs out, what is missing is the least important data."""
    if len(targets) < 2:
        return targets
    try:
        important = db.priority_instrument_keys()
        volume = db.volume_rank_map()
    except Exception as exc:  # noqa: BLE001 -- ordering is an optimisation; keep the original order on any problem
        logger.info("Could not prioritise history back-fill: %s", exc)
        return targets
    def rank(inst):
        key = (inst["exchange_segment"], str(inst["instrument_token"]))
        return (0 if key in important else 1, -volume.get(key, 0))
    return sorted(targets, key=rank)       # sorted() is stable: ties keep the incoming (token) order


def history_concurrency() -> int:
    """Parallel historical_data requests (default 2). Raise with HISTORY_FETCH_CONCURRENCY (1-6) only if Kotak allows."""
    try:
        return max(1, min(6, int(os.environ.get("HISTORY_FETCH_CONCURRENCY", "2"))))
    except ValueError:
        return 2


async def warmup_history(universe: list[dict], timeframe: str, definition: dict, *,
                         time_budget: float = 6.0, max_instruments: int = 150, concurrency: int | None = None,
                         attempted: set | None = None, targets: list[dict] | None = None) -> dict:
    """Backfill completed-bar history from Kotak historical_data (docs/functions/market_data/historical_data.md).

    Only instruments that cannot yet be evaluated are fetched, time-boxed, with bounded concurrency, and
    stopped on the first broker auth/rate-limit/session/timeout failure instead of hammering the API.
    ``attempted`` (shared by the caller across batches) makes sure an instrument that was already fetched
    once -- e.g. a new listing that simply has too little history -- is never fetched again, so such stocks
    cannot starve the rest of the universe or cause a refetch loop. Read-only: no order path.
    """
    from . import backtest_service
    need = required_bars(definition)
    attempted = attempted if attempted is not None else set()
    # DB scan + indicator-window maths for up to 3000 instruments: keep it off the event loop.
    concurrency = history_concurrency() if concurrency is None else concurrency
    # ``targets`` lets a long back-fill compute the (database-heavy) list once instead of before every batch.
    all_targets = targets if targets is not None else await asyncio.to_thread(_warmup_targets, universe, timeframe, definition, need)
    key = lambda i: (i["exchange_segment"], str(i["instrument_token"]))
    targets = [t for t in all_targets if key(t) not in attempted]
    result = {"needed": len(targets), "fetched": 0, "failed": 0, "tried": 0, "remaining": len(targets), "stopped": None, "required_bars": need}
    if not targets or timeframe not in backtest_service.HISTORICAL_MAX_DAYS:
        return result
    batch = targets[:max(1, max_instruments)]
    days = history_calendar_days(timeframe, need)
    end = dt.datetime.now(IST).date()
    start = end - dt.timedelta(days=days)
    deadline = time.monotonic() + max(1.0, time_budget)
    sem = asyncio.Semaphore(max(1, concurrency))
    errors: list[str] = []
    stop = asyncio.Event()

    async def one(inst: dict):
        if stop.is_set() or time.monotonic() >= deadline:
            return
        async with sem:
            if stop.is_set() or time.monotonic() >= deadline:
                return
            try:
                rows, meta = await backtest_service._fetch_chunks(inst["exchange_segment"], str(inst["instrument_token"]), timeframe,
                                                                 start, end, inst.get("trading_symbol") or str(inst["instrument_token"]))
            except Exception as exc:  # noqa: BLE001 -- not connected / transport: stop, report
                errors.append(f"{type(exc).__name__}: {exc}"); stop.set(); result["stopped"] = errors[-1][:200]
                return
            attempted.add(key(inst)); result["tried"] += 1
            if rows is None:
                msg = str(meta.get("error") or "historical_data failed")
                result["failed"] += 1
                errors.append(msg)
                low = msg.lower()
                if any(k in low for k in ("429", "too many", "session", "auth", "login", "not connected", "403", "401", "timeout", "timed out")):
                    stop.set(); result["stopped"] = msg[:200]
                return
            result["fetched"] += 1

    await asyncio.gather(*(one(inst) for inst in batch))
    result["remaining"] = max(0, len(targets) - result["tried"])
    if errors and not result["stopped"] and result["fetched"] == 0:
        result["stopped"] = errors[0][:200]
    return result


SCAN_FEED_CUSHION = 50           # slots the scanner leaves free beyond what positions/candidates hold, so a new candidate rarely has to evict


async def ensure_scanner_market_universe(series=("EQ",), limit: int = SCAN_UNIVERSE_CAP) -> dict:
    """Keep the scanner's stock universe on the live feed, within Kotak's 3000-token limit.

    Only the chosen series are subscribed (EQ by default). The scanner gets what is LEFT after everything more important
    (open positions, candidates, strategy stocks, orders, manual): ``budget = limit - held_by_others - cushion``. When the
    universe is larger than that budget the busiest stocks (last known volume) keep their slot and the rest are reported,
    never silently dropped. The old fixed 200-slot reserve either wasted slots or, once candidates grew past it, made the
    whole scanner subscription fail."""
    cap = max(1, min(int(limit or SCAN_UNIVERSE_CAP), SCAN_UNIVERSE_CAP))
    full = db.list_scan_universe(series)
    universe = full[:cap]
    keys=[("nse_cm",str(x["instrument_token"])) for x in universe if str(x.get("instrument_token") or "").strip()]
    if not keys:
        return {"universe": 0, "subscribed": 0, "error": "No NSE instruments are available. Sync Market Data first."}
    truncated = max(0, len(full) - len(keys))
    try:
        held = websocket_manager.non_scanner_used()
        budget = max(0, min(cap, websocket_manager.max_subscriptions - held - SCAN_FEED_CUSHION))
        wanted = len(keys)
        budget_cut = 0
        if budget < len(keys):
            volume = db.volume_rank_map()
            keys.sort(key=lambda k: -volume.get(k, 0))        # busiest first; the sort is stable (ties keep token order)
            budget_cut = len(keys) - budget
            keys = keys[:budget]
        result = await websocket_manager.ensure_owner_subscriptions(keys, owner="scanner-universe") if keys else {"added": 0, "total": None}
        rejected = len(result.get("rejected") or [])
        out = {"universe": wanted, "subscribed": int(result.get("added") or 0), "total": result.get("total"), "truncated": truncated,
               "budget": budget, "held_by_others": held, "budget_cut": budget_cut, "rejected": rejected,
               "evicted": int(result.get("evicted") or 0)}
        short = budget_cut + rejected
        if short:
            out["warning"] = (f"{short} of {wanted} scanner stocks have no live-feed slot (positions, candidates and other owners "
                              f"hold {held} of {websocket_manager.max_subscriptions}); they are scanned on stored candles only.")
        return out
    except Exception as exc:
        return {"universe":len(keys),"subscribed":0,"truncated":truncated,"error":f"Scanner market-feed subscription failed: {type(exc).__name__}: {exc}"}


_WARMUP_JOBS: dict[str, dict] = {}
WARMUP_RESTART_AFTER_SECONDS = 30
WARMUP_MAX_SECONDS = 1200
_PUBLIC_JOB_FIELDS = ("status", "needed", "fetched", "failed", "remaining", "stopped", "required_bars", "started_at", "finished_at")


def _job_key(timeframe: str, definition: dict) -> str:
    return f"{timeframe}:{required_bars(definition)}"


def _public_job(job: dict | None) -> dict | None:
    return {k: job.get(k) for k in _PUBLIC_JOB_FIELDS} if job else None


async def _run_warmup_job(job: dict, universe: list[dict], timeframe: str, definition: dict) -> None:
    deadline = time.monotonic() + WARMUP_MAX_SECONDS
    attempted: set = set()
    try:
        for _ in range(200):
            if time.monotonic() >= deadline:
                job["stopped"] = job.get("stopped") or "time budget reached; press Run Now again to continue"
                break
            r = await warmup_history(universe, timeframe, definition, time_budget=25.0, max_instruments=300, attempted=attempted)
            if job["needed"] is None:
                job["needed"] = r.get("needed", 0)
            job["fetched"] += r.get("fetched", 0)
            job["failed"] += r.get("failed", 0)
            job["remaining"] = r.get("remaining", 0)
            job["required_bars"] = r.get("required_bars", job.get("required_bars"))
            if r.get("stopped"):
                job["stopped"] = r["stopped"]
                break
            if not r.get("remaining") or r.get("tried", 0) == 0:
                break
            await asyncio.sleep(0.5)
        job["status"] = "STOPPED" if job.get("stopped") else "DONE"
    except Exception as exc:  # noqa: BLE001 -- surfaced to the UI, never silent
        job["status"] = "ERROR"
        job["stopped"] = f"{type(exc).__name__}: {exc}"[:200]
        logger.warning("Scanner history job failed: %s", exc)
    finally:
        job["finished_at"] = dt.datetime.now(dt.timezone.utc).isoformat()


def start_warmup_job(universe: list[dict], timeframe: str, definition: dict) -> dict:
    """Single-flight background history load. Returns the (public) job state immediately; the HTTP
    request that asked for it never waits for Kotak. A failed job is not restarted for 30 s so a
    timeout/429 can never turn into a retry storm."""
    key = _job_key(timeframe, definition)
    job = _WARMUP_JOBS.get(key)
    if job:
        if job["status"] == "RUNNING":
            return job
        finished = job.get("finished_monotonic", 0.0)
        if job["status"] in ("STOPPED", "ERROR") and time.monotonic() - finished < WARMUP_RESTART_AFTER_SECONDS:
            return job
    job = {"status": "RUNNING", "needed": None, "fetched": 0, "failed": 0, "remaining": None, "stopped": None,
           "required_bars": required_bars(definition), "started_at": dt.datetime.now(dt.timezone.utc).isoformat(), "finished_at": None}
    _WARMUP_JOBS[key] = job
    task = asyncio.ensure_future(_run_warmup_job(job, universe, timeframe, definition))
    job["task"] = task
    task.add_done_callback(lambda _t, j=job: j.__setitem__("finished_monotonic", time.monotonic()))
    return job


async def run(payload: dict) -> dict:
    """Manual scanner run. Analysis-only: it never places an order.

    Loads missing history first (time-boxed), evaluates completed bars, returns matches with
    symbols plus a diagnostic breakdown, and -- when ``subscribe_matches`` is true -- subscribes
    the matched instruments to the live feed under one replaceable owner so they stay visible
    on Market Data."""
    from .market_session import session_state
    definition = payload.get("definition") or {}
    if not isinstance(definition, dict):
        return {"error": "definition must be an object", "results": [], "scanned": 0, "matched": 0}
    errors = strategy_engine.validate_scanner(definition)
    if errors:
        return {"error": "Invalid scanner definition", "validation_errors": errors, "results": [], "scanned": 0, "matched": 0}
    timeframe = str(payload.get("timeframe") or definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"error": "Unsupported scanner timeframe.", "results": [], "scanned": 0, "matched": 0}
    try:
        limit = max(1, min(int(payload.get("limit") or MAX_UNIVERSE), MAX_UNIVERSE))
    except (TypeError, ValueError):
        return {"error": "limit must be an integer.", "results": [], "scanned": 0, "matched": 0}
    await _candles_barrier()
    universe = scan_universe(definition, limit)
    # CPU-heavy indicator maths for up to 3000 instruments runs in a worker thread so the broker
    # service keeps processing ticks, exits and API calls while a scan is in progress.
    matched, stats = await asyncio.to_thread(_scan_with_stats, universe, definition, timeframe)
    stats["coverage"] = await asyncio.to_thread(universe_coverage, definition, universe)
    market_open = bool(session_state().get("open"))
    warmup = None
    if payload.get("warmup", True):
        needs_history = (stats["no_candles"] + stats["insufficient_history"]) > 0 or (market_open and stats["stale"] > 0)
        key = _job_key(timeframe, definition)
        if needs_history and not payload.get("poll"):
            warmup = _public_job(start_warmup_job(universe, timeframe, definition))
        else:
            warmup = _public_job(_WARMUP_JOBS.get(key))
    subscribed = None
    if payload.get("subscribe_matches"):
        subscribed = await _subscribe_manual_matches(matched)
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    scan_status = classify_scan_status(stats)
    stats["status"] = scan_status
    def feed_state(m):
        owners = websocket_manager.subscription_owners((m["instrument"]["exchange_segment"], str(m["instrument"]["instrument_token"])))
        return "SUBSCRIBED" if owners else "NOT_SUBSCRIBED"
    # Every match came from a fresh, completed bar (stale / short / missing instruments are never evaluated), so its
    # data status is FRESH; the feed status says whether it is receiving live ticks right now.
    rows = [{"trading_symbol": m["instrument"].get("trading_symbol"), "instrument_token": str(m["instrument"]["instrument_token"]),
             "exchange_segment": m["instrument"]["exchange_segment"], "price": m["price"], "candle_at": m.get("candle_at"),
             "last_completed_candle": m.get("candle_at"), "data_status": "FRESH", "subscription": feed_state(m),
             "rank": m.get("rank"), "why": m.get("why") or [], "details": m["details"]} for m in matched]
    try:
        db.record_scan_run(scanner_id=None, timeframe=timeframe, trigger="MANUAL", duration_ms=stats.get("took_ms"), universe=stats["universe"],
                           evaluated=stats["evaluated"], matched=stats["matched"], status=scan_status, stats=stats)
    except Exception as exc:  # noqa: BLE001 -- history is best effort
        logger.info("Could not record the manual scan run: %s", exc)
    return {"results": matched, "matches": rows, "scanned": len(universe), "matched": len(matched), "timeframe": timeframe,
            "diagnostics": stats, "coverage": stats["coverage"], "status": scan_status, "feed_status": websocket_manager.feed_status(),
            "explanation": _scan_explanation(stats, market_open, warmup), "market_open": market_open,
            "warmup": warmup, "subscribed_matches": subscribed}


def _scan_explanation(stats: dict, market_open: bool, warmup: dict | None) -> str:
    base = _with_coverage_warning(explain_scan(stats, market_open=market_open), stats)
    if warmup and warmup.get("status") == "RUNNING":
        done = warmup.get("fetched") or 0
        total = warmup.get("needed")
        progress = f"{done} of {total}" if total else f"{done}"
        return f"Loading candle history in the background ({progress} instruments). This page refreshes automatically; matches appear as history arrives. {base}"
    if warmup and warmup.get("status") in ("STOPPED", "ERROR") and warmup.get("stopped"):
        return f"History loading stopped: {warmup['stopped']}. {base}"
    return base


async def diagnostics() -> dict:
    """Read-only health check of everything a scan depends on, with the REAL numbers of this installation: how many
    stocks exist, what each active scanner covers, how much of it has usable candles, the live feed, the write-behind
    buffer and the candle engine. It reads SQLite and in-memory state only: it records nothing, subscribes nothing and
    places nothing, so it is safe to press on the live VPS at any time."""
    from .candle_engine import candle_engine
    from .market_session import session_state
    from .tick_writer import tick_writer
    started = time.monotonic()
    out: dict = {"scanners": [], "market_open": bool(session_state().get("open"))}
    try:
        out["instruments"] = await asyncio.to_thread(db.count_instruments_by_series)
    except Exception as exc:  # noqa: BLE001 -- partial diagnostics beat none
        out["instruments"] = {"error": f"{type(exc).__name__}: {exc}"}
    runs = await asyncio.to_thread(db.list_scan_runs, 60)
    for sc in [s for s in await asyncio.to_thread(db.list_scanners) if s.get("is_active")]:
        definition = sc.get("definition") or {}
        timeframe = str(definition.get("timeframe") or "5m")
        item: dict = {"id": sc["id"], "name": sc.get("name"), "timeframe": timeframe}
        try:
            universe = await asyncio.to_thread(scan_universe, definition)
            _matched, stats = await asyncio.to_thread(_scan_with_stats, universe, definition, timeframe)
            item["coverage"] = await asyncio.to_thread(universe_coverage, definition, universe)
            item["status"] = classify_scan_status(stats)
            item["data"] = {k: stats.get(k) for k in ("universe", "ready", "not_ready", "readiness_pct", "no_candles", "insufficient_history",
                                                       "stale", "required_bars", "latest_candle_at", "matched_total", "took_ms")}
        except Exception as exc:  # noqa: BLE001
            item["status"] = "FAILED"
            item["error"] = f"{type(exc).__name__}: {exc}"
        last = next((r for r in runs if r.get("scanner_id") == sc["id"]), None)
        item["last_run"] = {"status": last["status"], "bar_at": last.get("bar_at"), "attempt": (last.get("stats") or {}).get("attempt"),
                            "started_at": last.get("started_at"), "error": last.get("error")} if last else None
        out["scanners"].append(item)
    out["feed"] = websocket_manager.feed_status()
    out["tick_writer"] = {"running": tick_writer.running, "pending": tick_writer.pending(), **tick_writer.stats}
    out["candle_engine"] = {"forming_bars": len(candle_engine._state)}
    out["took_ms"] = int((time.monotonic() - started) * 1000)
    return out


MANUAL_MATCH_OWNER = "scanner-manual-matches"
MANUAL_MATCH_HOLD_SECONDS = 3600.0
_manual_release_handle = None
MAX_MANUAL_MATCH_SUBSCRIPTIONS = 200


async def _subscribe_manual_matches(matched: list[dict]) -> dict:
    """Replace (not accumulate) the manual-match feed owner so repeated runs cannot leak subscriptions."""
    keys = [(m["instrument"]["exchange_segment"], str(m["instrument"]["instrument_token"])) for m in matched][:MAX_MANUAL_MATCH_SUBSCRIPTIONS]
    try:
        await websocket_manager.release_owner(MANUAL_MATCH_OWNER)
        if not keys:
            return {"subscribed": 0, "skipped": len(matched)}
        r = await websocket_manager.subscribe_many(keys, owner=MANUAL_MATCH_OWNER)
        global _manual_release_handle
        if _manual_release_handle is not None:
            _manual_release_handle.cancel()
        # Manual matches are a temporary watchlist: free the feed after an hour so they do not pile up.
        _manual_release_handle = asyncio.get_running_loop().call_later(
            MANUAL_MATCH_HOLD_SECONDS, lambda: asyncio.ensure_future(websocket_manager.release_owner(MANUAL_MATCH_OWNER)))
        return {"subscribed": len(keys), "skipped": max(0, len(matched) - len(keys)), "total_feed": r.get("total") if isinstance(r, dict) else None}
    except Exception as exc:  # noqa: BLE001 -- surfaced to the UI, never silent
        return {"subscribed": 0, "error": f"{type(exc).__name__}: {exc}"}


async def run_for_strategy(strategy_version_id: int, scanner_id: int, scanner: dict, universe: list[dict] | None = None,
                           *, bar_at: str | None = None, trigger: str = "BAR_CLOSE") -> dict:
    """Run one scanner only for the strategy that explicitly references it."""
    definition=scanner.get("definition") or {}
    errors=strategy_engine.validate_scanner(definition)
    if errors:
        logger.warning("Skipping invalid scanner %s: %s", scanner_id, errors)
        try:
            db.record_scan_run(scanner_id=int(scanner_id),strategy_version_id=int(strategy_version_id),timeframe=str(definition.get("timeframe") or "?"),
                               bar_at=bar_at,trigger=trigger,status="INVALID",error="; ".join(errors)[:380])
        except Exception:  # noqa: BLE001
            pass
        return {"matched":0,"scanned":0,"errors":errors,"status":"INVALID"}
    timeframe=str(definition.get("timeframe") or "5m")
    if timeframe not in strategy_engine.TIMEFRAMES:
        return {"matched":0,"scanned":0,"errors":["unsupported scanner timeframe"]}
    await _candles_barrier()
    universe=scan_universe(definition) if universe is None else universe
    scan_universe_list=universe
    try:
        # Single-flight background job: the 30 s cycle never waits for Kotak, and a 3000-stock
        # universe is back-filled progressively while earlier-ready instruments already scan.
        start_warmup_job(scan_universe_list, timeframe, definition)
    except Exception as exc:  # noqa: BLE001 -- history loading must never stop the scan cycle
        logger.warning("Scanner history warm-up failed for scanner %s: %s", scanner_id, exc)
    matches,_stats=await asyncio.to_thread(_scan_with_stats,scan_universe_list,definition,timeframe)
    try:
        _stats["coverage"]=await asyncio.to_thread(universe_coverage,definition,scan_universe_list)
    except Exception as exc:  # noqa: BLE001 -- coverage is diagnostics; never stop the scan
        logger.info("Could not compute scan coverage: %s", exc)
    scan_status=classify_scan_status(_stats)
    try:
        _stats["attempt"]=(len(db.scan_attempts(int(strategy_version_id),int(scanner_id),bar_at))+1) if bar_at else 1
    except Exception:  # noqa: BLE001
        _stats["attempt"]=1
    _stats["status"]=scan_status
    logger.info("Scanner %s (strategy v%s) %s: %s", scanner_id, strategy_version_id, scan_status, _with_coverage_warning(explain_scan(_stats, market_open=True), _stats))
    try:
        db.record_scan_run(scanner_id=int(scanner_id),strategy_version_id=int(strategy_version_id),timeframe=timeframe,bar_at=bar_at,trigger=trigger,
                           duration_ms=_stats.get("took_ms"),universe=_stats["universe"],evaluated=_stats["evaluated"],matched=_stats["matched"],
                           status=scan_status,stats=_stats)
    except Exception as exc:  # noqa: BLE001 -- history is best effort
        logger.info("Could not record the scan run: %s", exc)
    ttl=_expiry_for(timeframe,definition)
    # The strategy may run on a different timeframe / need a longer history than the scanner:
    # give every matched candidate the history the strategy's own entry evaluation requires.
    try:
        sv=db.get_strategy_version(int(strategy_version_id)) or {}
        sdef=sv.get("definition") or {}
        stf=str(sdef.get("timeframe") or timeframe)
        if matches and stf in strategy_engine.TIMEFRAMES:
            await warmup_history([m["instrument"] for m in matches], stf, sdef, time_budget=4.0, max_instruments=MAX_WARMUP_PER_CYCLE)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Candidate history warm-up failed for strategy=%s: %s", strategy_version_id, exc)
    for item in matches:
        inst=item["instrument"]; tok=str(inst["instrument_token"]); seg=str(inst["exchange_segment"])
        candidate=db.upsert_strategy_candidate(
            strategy_version_id=strategy_version_id,scanner_id=int(scanner_id),exchange_segment=seg,
            instrument_token=tok,trading_symbol=inst.get("trading_symbol"),timeframe=timeframe,
            matched_price=float(item["price"]),conditions=dict(item["details"],why=item.get("why") or [],rank=item.get("rank")),expires_at=ttl,
        )
        owner=f"strategy:{strategy_version_id}:candidate:{seg}:{tok}"
        try:
            await websocket_manager.subscribe(seg,tok,owner=owner)
            db.mark_strategy_candidate_subscribed(candidate["id"],True)
        except Exception as exc:
            db.mark_strategy_candidate_subscribed(candidate["id"],False,error=f"{type(exc).__name__}: {exc}")
            logger.warning("Candidate subscription failed for strategy=%s token=%s: %s",strategy_version_id,tok,exc)
    # Evaluate the strategy's own entry rules NOW on the last completed bar of each fresh candidate.
    # Otherwise a candidate would sit idle until its next bar closes (up to a full timeframe later),
    # which looks like "the strategy does nothing". Safe: one evaluation per candle (_last_eval),
    # idempotent order key per candle, and every normal gate/risk check still applies.
    try:
        from .algo_engine import algo_engine
        sv=db.get_strategy_version(int(strategy_version_id)) or {}
        stf=str((sv.get("definition") or {}).get("timeframe") or timeframe)
        for item in matches[:30]:
            inst=item["instrument"]
            await algo_engine.on_tick(exchange_segment=str(inst["exchange_segment"]),instrument_token=str(inst["instrument_token"]),
                                      trading_symbol=inst.get("trading_symbol"),timeframe=stf)
    except Exception as exc:  # noqa: BLE001 -- never let an evaluation problem stop the scan cycle
        logger.warning("Immediate candidate evaluation failed for strategy=%s: %s",strategy_version_id,exc)
    return {"matched":len(matches),"scanned":len(scan_universe_list),"timeframe":timeframe,"stats":_stats,"status":scan_status}


async def cleanup_expired_candidates() -> int:
    """Expire candidate rows and release only the corresponding strategy owners."""
    before=db.list_strategy_candidates(active_only=True,limit=10000)
    db.expire_strategy_candidates()
    removed=0
    for c in before:
        if not db.has_active_candidate(strategy_version_id=c["strategy_version_id"], exchange_segment=c["exchange_segment"], instrument_token=c["instrument_token"]):
            owner=f"strategy:{c['strategy_version_id']}:candidate:{c['exchange_segment']}:{c['instrument_token']}"
            removed += await websocket_manager.release_owner(owner)
    return removed


async def run_continuous_cycle(only_scanner_ids: set | None = None, bar_keys: dict | None = None, trigger: str = "BAR_CLOSE",
                               only_pairs: set | None = None) -> dict:
    """Run only scanners referenced by currently LIVE-armed strategies (optionally just the ones whose bar closed)."""
    active=[]
    scanner_by_id={s["id"]:s for s in db.list_scanners() if s.get("is_active")}
    for item in db.list_live_armed_strategy_versions():
        for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
            try: sid=int(raw_id)
            except (TypeError,ValueError): continue
            scanner=scanner_by_id.get(sid)
            if scanner: active.append((int(item["id"]),sid,scanner))
    if not active:
        # No active scanner is currently allowed to drive any armed strategy.
        # Immediately stop existing candidate owners instead of waiting for TTL.
        for item in db.list_live_armed_strategy_versions():
            vid=int(item["id"])
            if (item.get("definition") or {}).get("scanner_ids"):
                for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
                db.deactivate_strategy_candidates(vid)
        await websocket_manager.release_owner("scanner-universe")
        return {"strategies":0,"scanners":0,"matched":0,"universe":0}
    # Deactivate candidates belonging to scanners that are no longer active or
    # no longer referenced by their owning strategy.
    active_by_strategy={}
    for vid,sid,_scanner in active:
        active_by_strategy.setdefault(vid,set()).add(sid)
    for item in db.list_live_armed_strategy_versions():
        vid=int(item["id"]); configured=[int(x) for x in (item.get("definition") or {}).get("scanner_ids") or [] if str(x).isdigit()]
        if configured:
            allowed=active_by_strategy.get(vid,set())
            for c in db.list_strategy_candidates(strategy_version_id=vid,active_only=True,limit=10000):
                if int(c["scanner_id"]) not in allowed:
                    await websocket_manager.release_owner(f"strategy:{vid}:candidate:{c['exchange_segment']}:{c['instrument_token']}")
            db.deactivate_strategy_candidates_for_scanners(vid,list(allowed))
    series=sorted({x for _v,_s,sc in active for x in scan_options(sc.get("definition") or {})["series"]}) or ["EQ"]
    market=await ensure_scanner_market_universe(series)
    universe=[]
    matched=0
    statuses: dict[tuple[int,int],dict]={}
    for vid,sid,scanner in active:
        if only_scanner_ids is not None and int(sid) not in only_scanner_ids:
            continue
        if only_pairs is not None and (int(vid),int(sid)) not in only_pairs:
            continue
        bar_at=(bar_keys or {}).get(int(sid))
        try:
            result=await run_for_strategy(vid,sid,scanner,None,bar_at=bar_at,trigger=trigger)
        except Exception as exc:  # noqa: BLE001 -- one failing scanner must not stop the others, and must leave a retryable record
            logger.warning("Scanner %s (strategy v%s) failed: %s", sid, vid, exc)
            try:
                db.record_scan_run(scanner_id=int(sid),strategy_version_id=int(vid),timeframe=str((scanner.get("definition") or {}).get("timeframe") or "?"),
                                   bar_at=bar_at,trigger=trigger,status="FAILED",error=f"{type(exc).__name__}: {exc}",stats={"status":"FAILED"})
            except Exception:  # noqa: BLE001
                pass
            result={"matched":0,"scanned":0,"status":"FAILED","error":f"{type(exc).__name__}: {exc}"}
        statuses[(int(vid),int(sid))]={"status":result.get("status") or "COMPLETE","ready":int((result.get("stats") or {}).get("ready") or 0)}
        universe=universe or [0]*int(result.get("scanned") or 0)
        matched += int(result.get("matched") or 0)
    removed=await cleanup_expired_candidates()
    await websocket_manager.remove_if_unneeded()
    db.set_algo_runtime(last_scan_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), universe_count=len(universe), status="RUNNING")
    return {"strategies":len({v for v,_,_ in active}),"scanners":len(active),"matched":matched,"universe":len(universe),"expired_unsubscribed":removed,"market":market,"pairs":statuses}


# ------------------------------------------------------------------ bar-close scheduling
SESSION_OPEN = dt.time(9, 15)
SESSION_CLOSE = dt.time(15, 30)
DAILY_SCAN_TIME = dt.time(15, 45)
BAR_CLOSE_DELAY_SECONDS = 3.0        # let the candle engine finish writing the bar that just closed

# ---- scan status and durable retry (Phase 4)
# COMPLETE          enough of the universe could be judged (>= SCAN_COMPLETE_MIN_READINESS %): "0 matches" is believable
# PARTIAL           some of it could be judged, some could not (missing/short/stale data): "0 matches" is NOT proof
# WAITING_FOR_DATA  nothing could be judged yet (history still loading / no candles)
# FAILED            the scan itself raised
# INVALID           the scanner definition is wrong (never retried)
SCAN_COMPLETE_MIN_READINESS = 95.0
SCAN_MAX_RETRIES = 3                                   # after the first try: at most 3 more for the same bar
SCAN_RETRY_BACKOFF_SECONDS = (30, 90, 180)             # wait before retry 1, 2, 3
SCAN_SETTLED_STATUSES = frozenset({"COMPLETE", "OK", "INVALID"})   # "OK" = rows written before v13
_LAST_RUN: dict[tuple[int, int, str], dict] = {}       # in-process memory of attempts (db.scan_attempts is the durable record)
_IN_FLIGHT: set[tuple[int, int, str]] = set()


def classify_scan_status(stats: dict) -> str:
    universe = int(stats.get("universe") or 0)
    ready = int(stats.get("ready") if stats.get("ready") is not None else (stats.get("evaluated", 0) + stats.get("filtered_out", 0)))
    if universe <= 0 or ready <= 0:
        return "WAITING_FOR_DATA"
    pct = 100.0 * ready / universe
    return "COMPLETE" if pct >= SCAN_COMPLETE_MIN_READINESS else "PARTIAL"


def _parse_utc(text: str | None) -> dt.datetime | None:
    try:
        return dt.datetime.strptime(str(text), "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return None


def _attempt_history(strategy_version_id: int, scanner_id: int, bar_key: str) -> list[dict]:
    """[{status, at (UTC), ready}] newest first: the database rows, or this process's memory when none were written."""
    out = []
    try:
        for row in db.scan_attempts(strategy_version_id, scanner_id, bar_key):
            out.append({"status": row["status"], "at": _parse_utc(row["started_at"]),
                        "ready": int((row["stats"] or {}).get("ready") or 0)})
    except Exception as exc:  # noqa: BLE001 -- fall back to memory
        logger.info("Could not read scan attempts: %s", exc)
    mem = _LAST_RUN.get((int(strategy_version_id), int(scanner_id), bar_key))
    if mem and len(out) < mem["n"]:
        out = [{"status": mem["status"], "at": mem["at"], "ready": mem.get("ready", 0)}] * (mem["n"] - len(out)) + out
    return out


def scan_due(strategy_version_id: int, scanner_id: int, bar_key: str, now_utc: dt.datetime | None = None) -> tuple[bool, str]:
    """Should this (strategy version, scanner) be scanned for this bar now?

    * never scanned for the bar                      -> yes
    * last attempt COMPLETE / INVALID                -> no (done; INVALID is a configuration error)
    * last attempt FAILED / WAITING_FOR_DATA         -> retry after a backoff, up to SCAN_MAX_RETRIES times
    * last attempt PARTIAL                           -> retry only while more data became ready since the previous try
    Before v13 a failed pass was never retried for its bar, so one transient error meant a silently missing scan."""
    now_utc = now_utc or dt.datetime.now(dt.timezone.utc)
    history = _attempt_history(strategy_version_id, scanner_id, bar_key)
    if not history:
        return True, "first"
    last = history[0]
    if last["status"] in SCAN_SETTLED_STATUSES:
        return False, "settled"
    attempts = len(history)
    if attempts > SCAN_MAX_RETRIES:
        return False, "retries exhausted"
    if last["status"] == "PARTIAL" and attempts >= 2 and last["ready"] <= history[1]["ready"]:
        return False, "no more data became ready"
    wait = SCAN_RETRY_BACKOFF_SECONDS[min(attempts - 1, len(SCAN_RETRY_BACKOFF_SECONDS) - 1)]
    if last["at"] is not None and (now_utc - last["at"]).total_seconds() < wait:
        return False, "backing off"
    return True, f"retry {attempts}"


def last_bar_boundary(timeframe: str, now: dt.datetime | None = None) -> str | None:
    """The newest bar-close instant (IST, 'YYYY-MM-DD HH:MM:SS') that is due to be scanned, else None.

    Intraday bars close at 09:15 + k x timeframe (the last, possibly partial, bar closes at 15:30).
    The daily timeframe is scanned once, at 15:45, after the day's bar exists. No scan on weekends/holidays."""
    from .market_session import holidays
    minutes = int(strategy_engine.TIMEFRAMES.get(timeframe, 0))
    if not minutes:
        return None
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    day = local.date()
    if day.weekday() >= 5 or day in holidays():
        return None
    delay = dt.timedelta(seconds=BAR_CLOSE_DELAY_SECONDS)
    if minutes >= 1440:
        boundary = dt.datetime.combine(day, DAILY_SCAN_TIME, IST)
        return boundary.strftime("%Y-%m-%d %H:%M:%S") if local >= boundary + delay else None
    open_dt = dt.datetime.combine(day, SESSION_OPEN, IST)
    close_dt = dt.datetime.combine(day, SESSION_CLOSE, IST)
    step = dt.timedelta(minutes=minutes)
    if local >= close_dt + delay:
        boundary = close_dt
    else:
        k = int((min(local, close_dt) - open_dt).total_seconds() // step.total_seconds())
        if k < 1:
            return None
        boundary = open_dt + k * step
        if local < boundary + delay:
            if k < 2:
                return None
            boundary -= step
    return boundary.strftime("%Y-%m-%d %H:%M:%S")


def _armed_scanners() -> list[tuple[int, int, dict]]:
    active = []
    scanner_by_id = {s["id"]: s for s in db.list_scanners() if s.get("is_active")}
    for item in db.list_live_armed_strategy_versions():
        for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
            try:
                sid = int(raw_id)
            except (TypeError, ValueError):
                continue
            if sid in scanner_by_id:
                active.append((int(item["id"]), sid, scanner_by_id[sid]))
    return active


async def run_due_cycles(now: dt.datetime | None = None) -> dict | None:
    """Called every few seconds: scan exactly the scanners whose bar has just closed (once per bar).

    A restart in the middle of the day catches up with one scan for the latest closed bar. Nothing runs
    for a bar that was already scanned, so a 5-minute scanner does 78 passes a day, not 720."""
    armed = _armed_scanners()
    if not armed:
        # Nothing armed uses a scanner any more: give the whole scanner universe back to the feed.
        if websocket_manager.has_owner("scanner-universe"):
            await websocket_manager.release_owner("scanner-universe")
        return None
    if not websocket_manager.has_owner("scanner-universe"):
        # Subscribe as soon as a scanner is armed (not only at the first bar close) so candles are already forming.
        series = sorted({x for _v, _s, sc in armed for x in scan_options(sc.get("definition") or {})["series"]}) or ["EQ"]
        await ensure_scanner_market_universe(series)
    now_utc = (now.astimezone(dt.timezone.utc) if now else dt.datetime.now(dt.timezone.utc))
    due_pairs: dict[tuple[int, int], str] = {}
    reasons: dict[tuple[int, int], str] = {}
    for vid, sid, scanner in armed:
        tf = str((scanner.get("definition") or {}).get("timeframe") or "5m")
        key = last_bar_boundary(tf, now)
        if not key or (int(vid), int(sid), key) in _IN_FLIGHT:
            continue
        is_due, why = scan_due(int(vid), int(sid), key, now_utc)
        if is_due:
            due_pairs[(int(vid), int(sid))] = key
            reasons[(int(vid), int(sid))] = why
    if not due_pairs:
        return None
    flights = {(v, s, k) for (v, s), k in due_pairs.items()}
    _IN_FLIGHT.update(flights)
    try:
        result = await run_continuous_cycle(only_scanner_ids={s for _v, s in due_pairs}, only_pairs=set(due_pairs),
                                            bar_keys={s: k for (_v, s), k in due_pairs.items()}, trigger="BAR_CLOSE")
    finally:
        _IN_FLIGHT.difference_update(flights)
    pairs_info = result.get("pairs")
    for (vid, sid), key in due_pairs.items():
        if pairs_info is None:                       # a cycle that reports no per-scanner results ran nothing to retry
            info = {"status": "COMPLETE", "ready": 0}
        else:
            info = pairs_info.get((vid, sid)) or {"status": "FAILED", "ready": 0}
        mem = _LAST_RUN.get((vid, sid, key)) or {"n": 0}
        _LAST_RUN[(vid, sid, key)] = {"n": mem["n"] + 1, "at": now_utc, "status": info["status"], "ready": info.get("ready", 0)}
    result["due"] = {s: k for (_v, s), k in due_pairs.items()}
    result["due_reason"] = {f"{v}:{s}": r for (v, s), r in reasons.items()}
    return result
