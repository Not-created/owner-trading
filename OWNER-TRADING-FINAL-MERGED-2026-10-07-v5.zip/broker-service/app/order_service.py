"""LIVE order placement / modification / cancellation.

Every executable order goes through the official Kotak Neo SDK. Backtest is
historical analysis only and is implemented outside this order service.

LIVE safety properties (each has a test):
  * a durable local row + unique client_tag exist BEFORE the broker call;
  * the client_tag is sent as the SDK `tag` and comes back as GuiOrdId, so an
    order whose placement outcome is UNKNOWN (timeout) is recovered by
    reconciliation -- it is never blindly retried and never marked rejected;
  * risk limits fail CLOSED when they cannot be evaluated;
  * idempotency_key replays return the existing order, never a second one.
"""
from __future__ import annotations

import asyncio
import logging
import math
import uuid
from decimal import Decimal

from . import db as _db
from .market_prices import fresh_ltp
from . import sdk_adapter
from .broker_client import LiveTradingBlockedError, NotConfiguredError, assert_live_trading_allowed, broker_client
from .config import config
from .sdk_adapter import AUTH, OK, REJECTED, UNKNOWN, OrderRequest, OrderRequestError

logger = logging.getLogger("owner_trading.order_service")

# One process-wide submission lock closes the TOCTOU window between risk checks,
# durable order creation, and the broker call. Owner Trading is intentionally
# single-user; serialising executable orders is safer than allowing concurrent
# entries to race through exposure/position limits.
_submission_lock = asyncio.Lock()


class OrderValidationError(ValueError):
    """Malformed request -> HTTP 400."""


class RiskLimitExceededError(ValueError):
    """Well-formed but blocked by risk policy -> HTTP 400."""


def _write_audit(*, action: str, **details) -> None:
    try:
        _db.write_audit_log(actor="owner", action=action, details=details)
    except Exception as exc:  # noqa: BLE001 -- audit failure must not block the order flow
        logger.warning("Failed to write audit log for %s: %s", action, exc)


def new_client_tag() -> str:
    """Alphanumeric, 18 chars. Broker-side tag length/charset limits are NOT
    documented in the SDK; this is deliberately short and conservative.
    (Verify with a 1-lot order on first LIVE use -- see LIVE_READINESS.md.)"""
    return "OT" + uuid.uuid4().hex[:16].upper()


# ------------------------------------------------------------------ validation
def _num(payload: dict, key: str) -> float | None:
    v = payload.get(key)
    if v is None or v == "":
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise OrderValidationError(f"{key} must be a number.")
    if not math.isfinite(f):
        raise OrderValidationError(f"{key} must be finite.")
    if f < 0:
        raise OrderValidationError(f"{key} cannot be negative.")
    return f


def _validate(payload: dict) -> dict:
    raw_qty = payload.get("quantity")
    try:
        if isinstance(raw_qty, bool) or int(raw_qty) != float(raw_qty):
            raise ValueError
        quantity = int(raw_qty)
    except (TypeError, ValueError):
        raise OrderValidationError("quantity must be a positive integer.")
    if quantity <= 0:
        raise OrderValidationError("quantity must be a positive integer.")
    order = {
        "trading_symbol": (payload.get("trading_symbol") or "").strip(),
        "exchange_segment": (payload.get("exchange_segment") or "").strip().lower(),
        "transaction_type": (payload.get("transaction_type") or "").strip().upper(),
        "order_type": (payload.get("order_type") or "").strip().upper(),
        "product": (payload.get("product") or "").strip().upper(),
        "validity": (payload.get("validity") or "DAY").strip().upper(),
        "quantity": quantity,
        "price": _num(payload, "price"),
        "trigger_price": _num(payload, "trigger_price"),
        "instrument_token": (str(payload["instrument_token"]).strip() if payload.get("instrument_token") not in (None, "") else None),
        "signal_id": None,
        "algo_position_id": None,
        "order_role": str(payload.get("order_role") or "MANUAL").upper(),
        "parent_order_id": (str(payload["parent_order_id"]).strip() if payload.get("parent_order_id") not in (None, "") else None),
    }
    for field in ("signal_id", "algo_position_id"):
        raw = payload.get(field)
        if raw in (None, ""):
            continue
        try:
            value = int(raw)
            if value <= 0:
                raise ValueError
        except (TypeError,ValueError):
            raise OrderValidationError(f"{field} must be a positive integer.")
        order[field] = value
    if not order["instrument_token"]:
        raise OrderValidationError("instrument_token is required for every LIVE order; use Market Data to select the exact instrument.")

    if order["order_type"] in ("MKT", "SL-M"):
        order["price"] = None if not order["price"] else order["price"]
    if order["order_role"] not in ("MANUAL", "ENTRY", "EXIT"):
        raise OrderValidationError("order_role must be MANUAL, ENTRY or EXIT.")
    if order["order_role"] == "ENTRY" and order["signal_id"] is None:
        raise OrderValidationError("ENTRY orders require signal_id.")
    if order["order_role"] == "EXIT" and order["algo_position_id"] is None:
        raise OrderValidationError("EXIT orders require algo_position_id.")
    if order["order_role"] == "EXIT" and not order["parent_order_id"]:
        raise OrderValidationError("EXIT orders require parent_order_id.")
    if order["order_role"] == "EXIT":
        pos = _db.get_open_algo_position(order["algo_position_id"])
        if not pos:
            raise OrderValidationError("EXIT order requires an OPEN algo position.")
        if quantity > int(pos.get("remaining_quantity") or 0):
            raise OrderValidationError(f"EXIT quantity {quantity} exceeds remaining position quantity {int(pos.get('remaining_quantity') or 0)}.")
        if order.get("instrument_token") and str(order["instrument_token"]) != str(pos.get("instrument_token")):
            raise OrderValidationError("EXIT instrument_token does not match the open algo position.")
    try:
        _to_request(order).validate()      # the SDK's own validation rules, applied to BOTH modes
    except OrderRequestError as exc:
        raise OrderValidationError(str(exc))
    _verify_instrument(order)
    return order


def _verify_instrument(order: dict) -> None:
    """Authoritative identity + lot/tick checks against the synced scrip master.

    exchange_segment + instrument_token + trading_symbol must be ONE row of the instruments
    table; a mismatched pair would otherwise send an order for a different security than the one
    the owner/strategy selected. Exposure-reducing EXIT orders are checked against the open
    position's recorded identity instead and are never blocked by lot/tick metadata.
    """
    seg, tok, sym = order["exchange_segment"], str(order["instrument_token"]), order["trading_symbol"]
    if order["order_role"] == "EXIT":
        pos = _db.get_open_algo_position(order["algo_position_id"]) or {}
        if pos.get("trading_symbol") and str(pos["trading_symbol"]).strip().upper() != sym.upper():
            raise OrderValidationError("EXIT trading_symbol does not match the open algo position.")
        if pos.get("exchange_segment") and str(pos["exchange_segment"]).lower() != seg:
            raise OrderValidationError("EXIT exchange_segment does not match the open algo position.")
        return
    inst = _db.get_instrument(seg, tok)
    if not inst:
        raise OrderValidationError(f"Instrument {seg}|{tok} is not in the synced scrip master; sync Market Data and select the instrument again.")
    if str(inst.get("trading_symbol") or "").strip().upper() != sym.upper():
        raise OrderValidationError(f"Instrument identity mismatch: token {tok} is {inst.get('trading_symbol')!r}, not {sym!r}.")
    lot = inst.get("lot_size")
    if lot is not None:
        try:
            lot = int(lot)
        except (TypeError, ValueError):
            lot = None
    if lot and lot > 1 and order["quantity"] % lot != 0:
        raise OrderValidationError(f"quantity {order['quantity']} is not a multiple of the lot size {lot}.")
    for field in ("price", "trigger_price"):
        value = order.get(field)
        if not value:
            continue
        tick = inst.get("tick_size")
        try:
            tick = float(tick) if tick is not None else None
        except (TypeError, ValueError):
            tick = None
        if not tick or tick <= 0:
            raise OrderValidationError(f"Tick size for {sym} is unknown (re-sync the scrip master); {field} cannot be validated, so a priced order is blocked. Use a MARKET order or re-sync.")
        steps = float(value) / tick
        if abs(steps - round(steps)) > 1e-6 * max(1.0, abs(steps)):
            raise OrderValidationError(f"{field} {value} is not a multiple of the tick size {tick:g} for {sym}.")


def _to_request(order: dict, tag: str | None = None) -> OrderRequest:
    return OrderRequest(
        exchange_segment=order["exchange_segment"], trading_symbol=order["trading_symbol"],
        transaction_type=order["transaction_type"], order_type=order["order_type"], product=order["product"],
        quantity=order["quantity"], validity=order["validity"], price=order["price"],
        trigger_price=order["trigger_price"], tag=tag,
    )


# ------------------------------------------------------------------ risk
def _reference_price(order: dict) -> float | None:
    if order.get("price"):
        return float(order["price"])
    if order.get("trigger_price"):
        return float(order["trigger_price"])
    px = fresh_ltp(order.get("instrument_token"), order["trading_symbol"], order["exchange_segment"])
    return px


def _daily_pnl_total() -> float | None:
    """LIVE: realised+unrealised from the latest funds snapshot (broker-reported)."""
    f = _db.latest_funds_snapshot()
    if not f or f.get("realized_mtom") is None or f.get("unrealized_mtom") is None:
        return None
    return float(f["realized_mtom"]) + float(f["unrealized_mtom"])


def _extract_margin_required(data) -> float | None:
    """Required margin from the OFFICIAL margin_required body, or None when it cannot be
    determined safely (nested error, RMS reject, insufficient funds, malformed). None => BLOCK."""
    try:
        return sdk_adapter.parse_margin_required(data)["required_margin"]
    except sdk_adapter.MarginUnavailableError:
        return None


def _strategy_version_for_order(order: dict) -> int | None:
    if order.get("signal_id"):
        ctx = _db.get_signal_strategy_context(int(order["signal_id"]))
        if ctx:
            return int(ctx["strategy_version_id"])
    return None


def _position_price(position: dict) -> float | None:
    token = position.get("instrument_token")
    symbol = position.get("trading_symbol") or ""
    return fresh_ltp(token, symbol, position.get("exchange_segment"))


def _pending_entry_risk() -> tuple[float, dict[int, float], dict[tuple[str,str], float], dict[int, int], bool]:
    """Estimate exposure/position pressure from accepted but not fully filled entries.

    Broker position snapshots can legitimately lag an OPEN/SUBMITTED order. Without
    this overlay, two fast entries could each pass exposure limits against the same
    stale snapshot. Missing price data fails closed when an exposure limit is active.
    """
    total = 0.0
    by_strategy: dict[int, float] = {}
    by_instrument: dict[tuple[str,str], float] = {}
    position_counts: dict[int, int] = {}
    complete = True
    for order in _db.list_unresolved_live_orders():
        if str(order.get("order_role") or "").upper() == "EXIT":
            continue
        # Both BUY and SELL entries increase exposure/position pressure.
        # A previous BUY-only filter let a pending short entry bypass total,
        # strategy and instrument exposure limits until the broker snapshot
        # caught up. Exit orders are already excluded above.
        if str(order.get("transaction_type") or "").upper() not in ("B", "S", "BUY", "SELL"):
            continue
        remaining = max(0, int(order.get("quantity") or 0) - int(order.get("filled_quantity") or 0))
        if remaining <= 0:
            continue
        ref = _reference_price(order)
        if ref is None or float(ref) <= 0:
            complete = False
            continue
        value = float(ref) * remaining
        total += value
        key = (str(order.get("exchange_segment") or ""), str(order.get("instrument_token") or ""))
        by_instrument[key] = by_instrument.get(key, 0.0) + value
        sid = _strategy_version_for_order(order)
        if sid is not None:
            by_strategy[sid] = by_strategy.get(sid, 0.0) + value
            if int(order.get("filled_quantity") or 0) == 0:
                position_counts[sid] = position_counts.get(sid, 0) + 1
    return total, by_strategy, by_instrument, position_counts, complete


def _broker_position_exposure() -> tuple[float, bool]:
    """Return (absolute market exposure, complete). Missing LTP never undercounts a configured cap."""
    total = 0.0
    complete = True
    for position in _db.latest_positions_snapshot():
        qty = abs(int(position.get("quantity") or 0))
        if qty == 0:
            continue
        px = _position_price(position)
        if px is None:
            complete = False
            continue
        total += qty * float(px)
    return total, complete


def _check_risk_limits(order: dict, mode: str, *, enforce_daily_order_count: bool = True) -> None:
    rs = _db.get_risk_settings()
    max_qty = min([v for v in (config.max_order_quantity or None, rs["max_order_quantity"]) if v] or [0]) or None
    max_orders = min([v for v in (config.max_orders_per_day or None, rs["max_orders_per_day"]) if v] or [0]) or None
    if max_qty and order["quantity"] > max_qty:
        raise RiskLimitExceededError(f"Order quantity {order['quantity']} exceeds the maximum order quantity ({max_qty}).")
    if max_orders and enforce_daily_order_count:
        placed = _db.count_orders_today(mode=mode)
        if placed >= max_orders:
            raise RiskLimitExceededError(f"Daily order limit reached ({placed}/{max_orders}).")
        # Rejected attempts do not use the allowance, but a runaway loop of rejections must still stop.
        rejected = _db.count_rejected_orders_today()
        rejected_cap = max(10, max_orders * 5)
        if rejected >= rejected_cap:
            raise RiskLimitExceededError(f"{rejected} orders were rejected today (cap {rejected_cap}); entries are paused. Fix the cause shown in the Order book, then raise or reset the limit.")

    ref = _reference_price(order)
    if ref is None and any(rs.get(k) for k in ("max_order_value", "max_total_exposure", "max_strategy_exposure", "max_strategy_capital", "max_instrument_exposure")):
        raise RiskLimitExceededError("Risk exposure cannot be evaluated because no fresh reference price is available.")
    order_value = (float(ref) * order["quantity"]) if ref is not None else 0.0
    if rs["max_order_value"] and order_value > float(rs["max_order_value"]):
        raise RiskLimitExceededError(f"Order value {order_value:.2f} exceeds max_order_value ({rs['max_order_value']}).")

    if mode != "LIVE":
        return

    # Global daily-loss is a latched halt for the current IST trading date.
    daily_pnl = _daily_pnl_total()
    if rs.get("max_daily_loss") and daily_pnl is None:
        raise RiskLimitExceededError("max_daily_loss is set but reconciled P&L is unavailable; LIVE entry is blocked.")
    halt = _db.refresh_daily_loss_halt(current_pnl=daily_pnl, limit=rs.get("max_daily_loss"))
    if halt["daily_loss_halted"]:
        raise RiskLimitExceededError(halt["halt_reason"] or "Global daily-loss halt is active.")

    if rs["max_open_positions"]:
        open_syms = {(p["exchange_segment"], p["trading_symbol"]) for p in _db.latest_positions_snapshot() if p.get("quantity")}
        if (order["exchange_segment"], order["trading_symbol"]) not in open_syms and len(open_syms) >= rs["max_open_positions"]:
            raise RiskLimitExceededError(f"Open position limit reached ({len(open_syms)}/{rs['max_open_positions']}).")

    # Strategy-scoped limits apply only to strategy ENTRY orders. EXITs bypass
    # all new-exposure limits so risk controls can never trap an open position.
    strategy_version_id = _strategy_version_for_order(order)
    if strategy_version_id is not None:
        strategy = _db.get_strategy_version(strategy_version_id)
        definition = (strategy or {}).get("definition") or {}
        strategy_open_positions = [p for p in _db.list_algo_positions() if int(p.get("strategy_version_id") or 0) == strategy_version_id]
        pending_total, pending_by_strategy, pending_by_instrument, pending_position_counts, pending_complete = _pending_entry_risk()
        max_strategy_positions = rs.get("max_strategy_positions") or definition.get("max_positions")
        strategy_position_count = len(strategy_open_positions) + pending_position_counts.get(strategy_version_id, 0)
        if max_strategy_positions and strategy_position_count >= int(max_strategy_positions):
            raise RiskLimitExceededError(f"Strategy position limit reached ({strategy_position_count}/{int(max_strategy_positions)}).")
        strategy_exposure = pending_by_strategy.get(strategy_version_id, 0.0)
        if rs.get("max_strategy_exposure") or rs.get("max_strategy_capital"):
            if not pending_complete:
                raise RiskLimitExceededError("Pending LIVE entry exposure cannot be evaluated because a fresh reference price is unavailable.")
            for position in strategy_open_positions:
                px = _position_price(position)
                if px is None:
                    raise RiskLimitExceededError("Strategy exposure cannot be evaluated because an existing strategy position has no fresh LTP.")
                strategy_exposure += abs(int(position.get("remaining_quantity") or 0)) * float(px)
        if rs.get("max_strategy_exposure") and strategy_exposure + order_value > float(rs["max_strategy_exposure"]):
            raise RiskLimitExceededError(f"Strategy exposure {strategy_exposure + order_value:.2f} exceeds max_strategy_exposure ({rs['max_strategy_exposure']}).")
        if rs.get("max_strategy_capital") and strategy_exposure + order_value > float(rs["max_strategy_capital"]):
            raise RiskLimitExceededError(f"Strategy capital allocation {strategy_exposure + order_value:.2f} exceeds max_strategy_capital ({rs['max_strategy_capital']}).")
        strategy_day_pnl = _db.strategy_realized_pnl_today(strategy_version_id)
        if rs.get("max_strategy_daily_loss"):
            for position in strategy_open_positions:
                px = _position_price(position)
                if px is None:
                    raise RiskLimitExceededError("Strategy daily P&L cannot be evaluated because an existing strategy position has no fresh LTP.")
                entry=float(position.get("average_entry") or px); qty=abs(int(position.get("remaining_quantity") or 0))
                side=str(position.get("entry_side") or definition.get("side") or "BUY").upper()
                strategy_day_pnl += ((float(px)-entry)*qty if side == "BUY" else (entry-float(px))*qty)
            halt = _db.refresh_strategy_daily_loss_halt(strategy_version_id=strategy_version_id, current_pnl=strategy_day_pnl, limit=rs.get("max_strategy_daily_loss"))
            if halt["daily_loss_halted"]:
                raise RiskLimitExceededError(halt["halt_reason"] or "Strategy daily-loss halt is active.")

    if rs.get("max_total_exposure") or rs.get("max_instrument_exposure"):
        current_exposure, complete = _broker_position_exposure()
        pending_total, _pending_by_strategy, pending_by_instrument, _pending_position_counts, pending_complete = _pending_entry_risk()
        if not complete or not pending_complete:
            raise RiskLimitExceededError("Existing or pending LIVE exposure cannot be evaluated because one or more positions/orders have no fresh LTP.")
        if rs.get("max_total_exposure") and current_exposure + pending_total + order_value > float(rs["max_total_exposure"]):
            raise RiskLimitExceededError(f"Total exposure {current_exposure + pending_total + order_value:.2f} exceeds max_total_exposure ({rs['max_total_exposure']}).")
        if rs.get("max_instrument_exposure"):
            same = pending_by_instrument.get((str(order["exchange_segment"]), str(order.get("instrument_token") or "")), 0.0)
            for position in _db.latest_positions_snapshot():
                if str(position.get("exchange_segment")) == str(order["exchange_segment"]) and str(position.get("instrument_token")) == str(order.get("instrument_token")):
                    qty = abs(int(position.get("quantity") or 0)); px = _position_price(position)
                    if qty and px is not None: same += qty * float(px)
            if same + order_value > float(rs["max_instrument_exposure"]):
                raise RiskLimitExceededError(f"Instrument exposure {same + order_value:.2f} exceeds max_instrument_exposure ({rs['max_instrument_exposure']}).")

    if order["transaction_type"] == "B" and ref is not None and order["product"] == "CNC":
        funds = _db.latest_funds_snapshot()
        if not funds or funds.get("available_margin") is None:
            raise RiskLimitExceededError("Available funds are unavailable; LIVE CNC BUY is blocked.")
        if order_value > float(funds["available_margin"]):
            raise RiskLimitExceededError(f"Order value {order_value:.2f} exceeds available funds {float(funds['available_margin']):.2f}.")


# ------------------------------------------------------------------ helpers
async def _in_executor(fn):
    return await asyncio.get_running_loop().run_in_executor(None, fn)


def _schedule_reconcile() -> None:
    try:
        from . import reconciliation
        asyncio.get_running_loop().create_task(reconciliation.run_full_reconciliation())
    except Exception:  # noqa: BLE001
        pass


def _finish(internal_order_id: str, outcome, action: str) -> dict:
    """Map a state-changing broker Outcome onto local state (place/modify/cancel)."""
    if outcome.kind == OK:
        return {"ok": True}
    if outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, outcome_unknown=True,
                         status_reason=f"{action}: outcome unknown ({outcome.message[:150]}); reconciling with broker.")
        _write_audit(action=f"order.{action}_unknown", internal_order_id=internal_order_id, reason=outcome.message)
        _schedule_reconcile()
        return {"ok": False, "unknown": True}
    return {"ok": False, "unknown": False}


# ------------------------------------------------------------------ place
async def _place_order_locked(payload: dict) -> dict:
    key = payload.get("idempotency_key")
    if key:
        key = str(key).strip()[:200]
        existing = _db.get_order(key)
        if existing is not None:
            logger.info("place_order idempotent replay for %s.", key)
            return existing
    order = _validate(payload)
    mode = "LIVE"
    # EXIT is exposure-reducing. Global entry limits (daily loss, max open
    # positions, new-order count/value) must never prevent an owner/algo from
    # flattening an already-open position. Broker/session/reconciliation gates
    # remain enforced by broker_client.assert_live_trading_allowed().
    if order["order_role"] != "EXIT":
        try:
            _check_risk_limits(order, mode)
        except RiskLimitExceededError as exc:
            _write_audit(action="order.risk_blocked", mode=mode, order=order, reason=str(exc))
            raise OrderValidationError(str(exc))

    internal_order_id = key or str(uuid.uuid4())
    tag = new_client_tag()
    _db.create_order(
        internal_order_id=internal_order_id, mode="LIVE",
        status="SUBMITTING", client_tag=tag, **order,
    )
    _write_audit(action="order.create", internal_order_id=internal_order_id, mode=mode, order=order, client_tag=tag)


    def reject(reason: str, action: str = "order.rejected") -> dict:
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason[:480])
        _write_audit(action=action, internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    try:
        req = _to_request(order, tag=tag)
        outcome = await _in_executor(lambda: broker_client.place_order(req, internal_order_id=internal_order_id, allow_controlled_exit=(order["order_role"] == "EXIT"), instrument_token=order.get("instrument_token")))
    except (LiveTradingBlockedError, NotConfiguredError) as exc:
        return reject(str(exc), "order.blocked")
    except OrderRequestError as exc:
        return reject(str(exc))
    except Exception as exc:  # noqa: BLE001 -- unexpected failure AFTER we may have sent: never assume rejection
        logger.exception("place_order raised unexpectedly")
        outcome = sdk_adapter.Outcome(UNKNOWN, message=f"{type(exc).__name__}", code="INTERNAL")

    if outcome.kind == OK:
        _db.update_order(internal_order_id=internal_order_id, status="SUBMITTED", broker_order_id=outcome.order_id)
        _db.record_order_event(event_source="place_order_response", broker_event_id=outcome.order_id,
                               raw_payload=outcome.raw if isinstance(outcome.raw, dict) else {"raw": str(outcome.raw)},
                               order_id=_db.get_order(internal_order_id)["id"], broker_order_id=outcome.order_id)
        _write_audit(action="order.submitted", internal_order_id=internal_order_id, mode=mode, broker_order_id=outcome.order_id)
    elif outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, status="PENDING_RECONCILE")
        _finish(internal_order_id, outcome, "place")
    elif outcome.kind == AUTH:
        # 401/403/session-invalid is a broker-session failure, not a business
        # order rejection. The broker client has already transitioned the
        # session to SESSION_EXPIRED; automatic re-authentication is handled
        # by the service supervisor. Never resend this order blindly because
        # the durable request must remain tied to this exact attempt.
        reason = "Kotak session/authentication rejected the request; order was not resent. " + _broker_reject_reason(outcome)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason[:480])
        _write_audit(action="order.auth_blocked", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)
    else:  # definitive broker/business rejection
        return reject(_broker_reject_reason(outcome))
    return _db.get_order(internal_order_id)


def _broker_reject_reason(outcome) -> str:
    """Exact, actionable broker rejection text for the Order book (code + Kotak message + hint)."""
    msg = (outcome.message or "Rejected by broker.").strip()
    diag = (getattr(outcome, "extra", None) or {}).get("broker_diagnostics") or {}
    bits = []
    if diag.get("http_status") is not None:
        bits.append(f"HTTP {diag['http_status']}")
    if diag.get("kotak_st_code") is not None:
        bits.append(f"stCode {diag['kotak_st_code']}")
    if outcome.kind == AUTH:
        bits.append("session")
    tail = f" [{', '.join(bits)}]" if bits else ""
    low = msg.lower()
    hint = ""
    if "unauthor" in low or "forbidden" in low or diag.get("http_status") in (401, 403):
        hint = (" Kotak refused ORDER placement as unauthorized although other calls work: the usual causes are "
                "(1) this server's outbound IP is not whitelisted for API orders (check System > What's my IP and register it in "
                "Kotak's API settings), (2) Trade API access is not enabled for this consumer key, (3) the trading session needs a fresh login.")
    return (msg + tail + hint)[:480]


FEED_WAIT_SECONDS = 4.0


async def _ensure_live_price_feed(payload: dict) -> None:
    """A manual/strategy ENTRY needs a FRESH tick for its exact instrument. If the instrument is not
    on the feed yet (the usual reason for 'market feed is stale or missing'), subscribe it under a
    dedicated owner and wait briefly for the first tick. Best effort only: the LIVE gate still
    blocks when no fresh tick arrives (market closed, feed down) -- nothing is ever bypassed."""
    try:
        if str(payload.get("order_role") or "MANUAL").upper() == "EXIT":
            return
        seg = str(payload.get("exchange_segment") or "").strip().lower()
        tok = str(payload.get("instrument_token") or "").strip()
        sym = str(payload.get("trading_symbol") or "").strip()
        if not seg or not tok:
            return
        from .market_prices import fresh_ltp
        if fresh_ltp(tok, sym, seg) is not None:
            return
        from .websocket_manager import websocket_manager
        await websocket_manager.subscribe(seg, tok, owner=f"order:{seg}:{tok}")
        loop = asyncio.get_running_loop()
        deadline = loop.time() + FEED_WAIT_SECONDS
        while loop.time() < deadline:
            await asyncio.sleep(0.25)
            if fresh_ltp(tok, sym, seg) is not None:
                return
    except Exception as exc:  # noqa: BLE001 -- the gate reports the real reason
        logger.info("Could not pre-subscribe %s for the order: %s", payload.get("trading_symbol"), exc)


async def place_order(payload: dict) -> dict:
    """Serialise LIVE order creation/submission so risk checks cannot race.

    The temporary ``order:<segment>:<token>`` SFeed owner exists only long
    enough to obtain a fresh entry price. It must be released after the attempt;
    otherwise repeated manual orders slowly consume the hard 3000-token SFeed
    capacity. Open positions are independently re-owned by ``position:<id>``
    during reconciliation.
    """
    await _ensure_live_price_feed(payload)
    try:
        async with _submission_lock:
            return await _place_order_locked(payload)
    finally:
        if str(payload.get("order_role") or "MANUAL").upper() != "EXIT":
            seg = str(payload.get("exchange_segment") or "").strip().lower()
            tok = str(payload.get("instrument_token") or "").strip()
            if seg and tok:
                try:
                    from .websocket_manager import websocket_manager
                    await websocket_manager.release_owner(f"order:{seg}:{tok}")
                    # If this exact execution token temporarily preempted one
                    # scanner-universe token at the 3000 limit, refill the
                    # scanner slot immediately instead of waiting for the next
                    # 30-second scanner cycle. Open positions remain protected
                    # by their own higher-priority owner.
                    await websocket_manager.restore_scanner_universe_after_preemption()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to release/restore temporary order feed owner %s|%s: %s", seg, tok, exc)


# ------------------------------------------------------------------ modify
async def modify_order(internal_order_id: str, payload: dict) -> dict:
    o = _db.get_order(internal_order_id)
    if o is None:
        raise OrderValidationError("Unknown order.")
    if o["status"] in _db.TERMINAL_STATUSES:
        raise OrderValidationError(f"Order is {o['status']} and cannot be modified.")
    try:
        raw_q = payload.get("quantity")
        new_qty = o["quantity"] if raw_q in (None, "") else int(raw_q)
        if isinstance(raw_q, bool) or (raw_q not in (None, "") and float(raw_q) != new_qty) or new_qty <= 0:
            raise ValueError
    except (TypeError, ValueError):
        raise OrderValidationError("quantity must be a positive integer.")
    price = _num(payload, "price") if "price" in payload else o["price"]
    trigger = _num(payload, "trigger_price") if "trigger_price" in payload else o["trigger_price"]
    order_type = (payload.get("order_type") or o["order_type"]).upper()
    validity = (payload.get("validity") or o["validity"]).upper()

    if not o["broker_order_id"]:
        raise OrderValidationError("Order has no broker order id yet (placement not confirmed); reconcile first.")
    if o.get("order_role") != "EXIT":
        # A modify must satisfy the same instrument lot/tick rules as the original order.
        _verify_instrument({**o, "quantity": new_qty, "price": price, "trigger_price": trigger,
                            "order_role": o.get("order_role") or "MANUAL"})
    # A modify can increase value/quantity, so it must pass the same risk policy
    # as the original entry. It is not a new order for max_orders_per_day.
    if o.get("order_role") != "EXIT":
        candidate = dict(o)
        candidate.update(quantity=new_qty, price=price, trigger_price=trigger)
        try:
            _check_risk_limits(candidate, "LIVE", enforce_daily_order_count=False)
        except RiskLimitExceededError as exc:
            raise OrderValidationError(str(exc))
    if o["filled_quantity"] and new_qty != o["quantity"]:
        # Kotak's modify-quantity semantics for partially filled orders are not documented in the SDK.
        raise OrderValidationError("Quantity of a partially filled order cannot be changed here; cancel the remainder instead.")
    try:
        outcome = await _in_executor(lambda: broker_client.modify_order(
            internal_order_id=internal_order_id, order_id=o["broker_order_id"], order_type=order_type, quantity=new_qty, validity=validity,
            price=price, trigger_price=trigger, instrument_token=o.get("instrument_token"),
            trading_symbol=o.get("trading_symbol"), exchange_segment=o.get("exchange_segment")))
    except (LiveTradingBlockedError, NotConfiguredError, OrderRequestError) as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        outcome = sdk_adapter.Outcome(UNKNOWN, message=type(exc).__name__)
    if outcome.kind == OK:
        # The broker may return a NEW order number for the modified order.
        _db.update_order(internal_order_id=internal_order_id, status="MODIFY_REQUESTED", broker_order_id=outcome.order_id)
        _db.update_order_fields(internal_order_id=internal_order_id, quantity=new_qty, price=price, trigger_price=trigger)
        _write_audit(action="order.modify", internal_order_id=internal_order_id, broker_order_id=outcome.order_id)
        _schedule_reconcile()
    elif outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, status="PENDING_RECONCILE", outcome_unknown=True,
                         status_reason=f"modify: outcome unknown ({outcome.message[:150]}); reconciling with broker.")
        _finish(internal_order_id, outcome, "modify")
    else:
        _write_audit(action="order.modify_rejected", internal_order_id=internal_order_id, reason=outcome.message)
        raise OrderValidationError(outcome.message or "Modify rejected by broker.")
    return _db.get_order(internal_order_id)


# ------------------------------------------------------------------ cancel
async def cancel_order(internal_order_id: str) -> dict:
    o = _db.get_order(internal_order_id)
    if o is None:
        raise OrderValidationError("Unknown order.")
    if o["status"] in _db.TERMINAL_STATUSES:
        raise OrderValidationError(f"Order is already {o['status']}.")
    if not o["broker_order_id"]:
        raise OrderValidationError("Order has no broker order id yet (placement not confirmed); reconcile first.")
    try:
        outcome = await _in_executor(lambda: broker_client.cancel_order(order_id=o["broker_order_id"]))
    except (LiveTradingBlockedError, NotConfiguredError, OrderRequestError) as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        outcome = sdk_adapter.Outcome(UNKNOWN, message=type(exc).__name__)
    if outcome.kind == OK:
        _db.update_order(internal_order_id=internal_order_id, status="CANCEL_REQUESTED")
        _write_audit(action="order.cancel", internal_order_id=internal_order_id, broker_order_id=o["broker_order_id"])
        _schedule_reconcile()
    elif outcome.kind == UNKNOWN:
        _db.update_order(internal_order_id=internal_order_id, status="PENDING_RECONCILE", outcome_unknown=True,
                         status_reason=f"cancel: outcome unknown ({outcome.message[:150]}); reconciling with broker.")
        _finish(internal_order_id, outcome, "cancel")
    else:
        _write_audit(action="order.cancel_rejected", internal_order_id=internal_order_id, reason=outcome.message)
        raise OrderValidationError(outcome.message or "Cancel rejected by broker.")
    return _db.get_order(internal_order_id)
