# Audit fixes — 2026-10-07

Root-cause fixes found by end-to-end tracing (each has regression tests under `broker-service/tests/` or `backend/test/`).

| # | Defect | Fix |
|---|--------|-----|
| 1 | `margin_required` parsed guessed keys (`margin`, `total`…); the official body (`ordMrgn`, `reqdMrgn`, `insufFund`, `rmsVldtd`) never matched, so real LIVE entries could not pass; nested errors under an OK envelope were not detected | `sdk_adapter.parse_margin_required()` follows `docs/functions/portfolio/margin_required.md`; blocks on nested error, RMS reject, `insufFund>0`, missing/invalid `ordMrgn`; a raising margin call now blocks (not UNKNOWN order) |
| 2 | HTTP 500/502/503/504 on place/modify/cancel classified REJECTED although the OMS outcome is unconfirmed | classified UNKNOWN → reconciliation, never auto-retried |
| 3 | A rejected/cancelled/blocked EXIT left `algo_exits` pending forever, disabling all later SL/target exits; retries replayed the rejected order via a shared idempotency key | exit requests released on REJECTED/CANCELLED/blocked; per-request keys `exit-<pos>-x<exit_id>`; 5 s retry cooldown; crash-orphaned requests adopted/released after 120 s; protective exits always close the full quantity (partial % only for TARGET/STRATEGY_EXIT) |
| 4 | DISARM / candidate expiry could unsubscribe instruments of OPEN positions (no ticks → no SL) | open positions own a `position:<id>` feed owner; last-owner release hands the subscription to the position; restored on restart |
| 5 | ARM/readiness evaluated during a running reconciliation (`state=RECONCILING` false failure); DISARM during ARM could be undone | `reconciliation.wait_until_idle()` before evaluation; disarm epoch + emergency-stop re-check immediately before the arm write |
| 6 | Express blocked order **cancel** during emergency stop (broker service allows it) | cancel gate allows emergency stop; mode + broker-connected gates kept |
| 7 | Malformed / out-of-order ticks: NaN/≤0 LTP reached exits/candles/LTP; late ticks closed the forming bar; same-day cumulative-volume glitch added a volume spike | validated in feed handler and candle engine |
| 8 | `strategy_engine.TIMEFRAMES` was a set but used with `.get()`/`[]` → scanner freshness/TTL and entry cooldown raised `AttributeError` | now a timeframe→minutes map |
| 9 | Scanner freshness and entry cooldown read naive IST candle times as UTC (5.5 h skew) | parsed as IST |
| 10 | No authoritative instrument identity, lot-size or tick-size validation on orders; scrip-master loader read non-official column names so lot/tick/strike were never stored | `_verify_instrument()` (exchange+token+symbol must be one scrip-master row; lot multiple; tick multiple for priced orders; unknown tick blocks priced orders only); loader uses `lLotSize`, `dTickSize`/`lPrecision`, `dStrikePrice;`; modify enforces the same rules |
| 11 | ARM blocked for an empty account: holdings returned `No holdings found for this client <id>` and was treated as a failed reconciliation section (the empty-read rule only accepted HTTP/stCode 424) | the exact endpoint-specific sentence is the contract (any non-5xx code / body shape); 5xx, auth errors, other sections and generic 424s remain failures |
| 12 | Scanner/strategy showed **0 matches every time**: no candle history was ever loaded (candles only came from live ticks, so e.g. ema50 on 15m needed ~13 h of ticks), broker history was stored in a different timestamp format than tick candles (`...T09:15:00+0530` vs `... 09:15:00`: same bar twice, wrong ordering), the forming bar could be evaluated, and the UI only showed raw `scanned/matched` | candles stored in ONE canonical IST format (+ idempotent startup repair of old rows); `scanner_engine.warmup_history()` back-fills Kotak `historical_data` for exactly the instruments that lack the bars the definition needs (time-boxed, bounded concurrency, stops on 429/session errors); only COMPLETED bars are evaluated; required bars derived from the indicators used; scan returns a full diagnostic breakdown + plain-language explanation; optional "subscribe matched stocks" with a replaceable feed owner; strategy ARM warms history (scanner-less) or kicks the first scanner cycle immediately; candidates get strategy-timeframe history |
| 13 | Manual/strategy ENTRY failed with "market feed is stale or missing" because the instrument was never subscribed | entry orders subscribe the exact instrument and wait up to 4 s for its first tick before the LIVE gate (gate itself unchanged; clearer reason text) |
| 14 | Orders page showed raw margin JSON | readable summary using the official fields (needs / available / shortfall / RMS) |

## Verification status
See the delivery message: Python tests (unittest + pytest-style files) and Node syntax/`node --test` were run;
the frontend build, Express test-suite and real-SDK dependency tests need `npm`/`pip` network access and were NOT run here.


## Additions in the merged FINAL build (v5)
| # | Defect | Fix |
|---|--------|-----|
| 15 | Rejected orders (no broker id) used up `max_orders_per_day`, locking the day after two failed attempts | they no longer count; a runaway cap (max(10, 5x limit) rejected entries/day) still pauses entries |
| 16 | Order book showed bare `unauthorized` | rejection text carries HTTP/stCode and an actionable hint (IP whitelist / Trade API / re-login) |
| 17 | Historical warm-up requests were oversized (e.g. 400/180 days for 1d) | window sized from the bars the indicators need (one small chunk), concurrency 3 |
| 18 | **Times were shown in UTC with no label, next to IST candle times** (an 11:00 IST tick showed 05:30) | one helper `frontend/src/lib/time.js`: server UTC stamps are converted and labelled IST on every page; candle/fill wall-clock stamps are only labelled IST (`backend/test/ist-time-format.test.js`) |
| 19 | Daily bars could exist twice per date | one canonical `YYYY-MM-DD 00:00:00` daily bar per date + startup repair |
| 20 | `request_timeout` on historical fetches was accepted but ignored | real application-level deadline |
