// Guards the UI rule: server UTC stamps are shown in IST, candle stamps are already IST.
const test = require("node:test");
const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");

const helper = path.resolve(__dirname, "../../frontend/src/lib/time.js");
const skip = !fs.existsSync(helper) && "frontend sources not present in this deployment";
const load = () => import(helper);

test("naive server stamps are UTC and render as IST", { skip }, async () => {
  const { formatUtc } = await load();
  assert.equal(formatUtc("2026-10-07 05:30:00"), "2026-10-07 11:00:00 IST");
  assert.equal(formatUtc("2026-10-07 07:35:20"), "2026-10-07 13:05:20 IST");
  assert.equal(formatUtc("2026-10-07 18:30:00"), "2026-10-08 00:00:00 IST");
});
test("explicit zones are honoured", { skip }, async () => {
  const { formatUtc } = await load();
  assert.equal(formatUtc("2026-10-07T05:30:00Z"), "2026-10-07 11:00:00 IST");
  assert.equal(formatUtc("2026-10-07T11:00:00+05:30"), "2026-10-07 11:00:00 IST");
});
test("candle wall-clock stamps are only labelled, never shifted", { skip }, async () => {
  const { formatIstWall } = await load();
  assert.equal(formatIstWall("2026-10-07 11:00:00"), "2026-10-07 11:00:00 IST");
  assert.equal(formatIstWall("2026-10-07T11:00:00"), "2026-10-07 11:00:00 IST");
});
test("empty and garbage values never throw", { skip }, async () => {
  const { formatUtc, formatIstWall } = await load();
  assert.equal(formatUtc(null), "—");
  assert.equal(formatUtc("garbage"), "garbage");
  assert.equal(formatIstWall(""), "—");
});
