# Owner Trading

Web-based automated trading platform (Kotak Neo integration planned).
Architecture: **Express + Node.js backend**, **React + Vite frontend**, **SQLite** database.

This is a **greenfield build**, developed feature-by-feature per
`OWNER_TRADING_MASTER_HANDOFF-3.md`. See `PROGRESS.md` for the current
checkpoint status.

## Project structure

```
owner-trading/
├── backend/            Express API + SQLite
│   ├── server.js       App entry point
│   ├── src/
│   │   ├── brokers/    Broker adapter interface + PAPER (real) + Kotak (stub)
│   │   ├── config/     Environment/config loading
│   │   ├── db/         SQLite connection + migrations
│   │   ├── middleware/ Auth guard + error handling
│   │   ├── routes/     API routes (health, auth, broker, trading,
│   │   │               strategies, orders, positions, risk, logs, market-data)
│   │   └── services/   Session/bootstrap/encryption/broker-credential
│   │                   storage/trading-state, plus the trading engine:
│   │                   strategyService, strategyExecutor, orderService,
│   │                   positionService, pnlService, riskService,
│   │                   reconciliationService, marketDataSimulator
│   ├── test/           node:test test files
│   └── data/           SQLite DB file lives here (gitignored)
├── frontend/           React + Vite app
│   └── src/
│       ├── api/        Backend API client (29 endpoint functions)
│       ├── context/     AuthContext
│       ├── routes/      ProtectedRoute guard
│       └── pages/        Login, ChangePassword, Dashboard, Settings,
│                          TradingControl, Strategies (+ Strategy Builder),
│                          MarketData, Orders, Positions, PnL, RiskControls,
│                          Logs
├── deploy/              deploy.sh + systemd/Nginx templates
├── .gitignore
├── DEPLOYMENT.md        Step-by-step VPS deployment guide
└── PROGRESS.md          Checkpoint log — source of truth for what's
                          actually built vs. not (read this first)
```

## Prerequisites

- Node.js 18 or later
- npm

## Setup (local development)

### Backend

```bash
cd backend
cp .env.example .env      # edit values as needed — see comments in the file
npm install
npm run dev                # starts on http://localhost:4000
```

On first run, an admin account is created automatically and its temporary
password is written to `backend/INITIAL_ADMIN_CREDENTIALS.txt`
(gitignored). Log in, complete the forced password change, then delete
that file.

### Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev                # starts on http://localhost:5173
```

Open http://localhost:5173, log in, and complete the forced password
change. From the dashboard you can reach **Trading controls**
(PAPER/LIVE mode, live-enable, emergency stop) and **Settings** (Kotak
credential storage — see the important note below).

## Testing

```bash
cd backend
npm test
```

## Production deployment

See **`DEPLOYMENT.md`** for the full VPS walkthrough, and
`deploy/deploy.sh` for the deployment script itself
(`./deploy/deploy.sh` with no arguments lists all commands).

## Security notes

- No secrets are committed to this repository. See `.gitignore`.
- `.env` files are local-only; only `.env.example` (no real values) is tracked.
- Kotak Neo credentials are entered by the admin through the running app's
  Settings page and stored server-side only, encrypted at rest — never in
  source control, and never sent to Claude/chat.
- This project has no runtime dependency on Claude, Claude Code, or any
  Claude-hosted service. It runs standalone with `node` + `npm` once
  installed, per the dependencies listed in `backend/package.json` and
  `frontend/package.json`.

## ⚠️ Kotak Neo LIVE trading status: NOT VERIFIED

The full trading engine — strategies, market data (simulated), risk
validation, order manager, PAPER broker, positions, P&L, reconciliation —
is built and genuinely tested (see `PROGRESS.md`). Credential **storage**
exists (encrypted at rest, masked in the UI). **The Kotak broker adapter
itself is an intentional, honest stub — no code in this project calls any
Kotak API endpoint.** Attempting a LIVE order will fail cleanly with
`NOT_IMPLEMENTED`, never a fabricated success. Do not treat this project
as ready for real trading until that adapter is implemented against
Kotak's verified current API and tested with a real account. See
`PROGRESS.md`'s "PROJECT STATUS SUMMARY" for the exact, current, honest
state, and `backend/src/brokers/kotakBrokerAdapter.js` for exactly what
remains unverified.

## Current status

See `PROGRESS.md` for the checkpoint-by-checkpoint build log, including
what is implemented, what is validated, and what is explicitly not yet done.
