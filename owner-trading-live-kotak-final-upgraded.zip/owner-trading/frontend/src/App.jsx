import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import ProtectedRoute from './routes/ProtectedRoute.jsx';
import LoginPage from './pages/LoginPage.jsx';
import ChangePasswordPage from './pages/ChangePasswordPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';
import SettingsPage from './pages/SettingsPage.jsx';
import TradingControlPage from './pages/TradingControlPage.jsx';
import StrategiesPage from './pages/StrategiesPage.jsx';
import MarketDataPage from './pages/MarketDataPage.jsx';
import OrdersPage from './pages/OrdersPage.jsx';
import PositionsPage from './pages/PositionsPage.jsx';
import PnLPage from './pages/PnLPage.jsx';
import RiskControlsPage from './pages/RiskControlsPage.jsx';
import LogsPage from './pages/LogsPage.jsx';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />

          <Route element={<ProtectedRoute />}>
            <Route path="/change-password" element={<ChangePasswordPage />} />
            <Route path="/" element={<DashboardPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/trading" element={<TradingControlPage />} />
            <Route path="/strategies" element={<StrategiesPage />} />
            <Route path="/market-data" element={<MarketDataPage />} />
            <Route path="/orders" element={<OrdersPage />} />
            <Route path="/positions" element={<PositionsPage />} />
            <Route path="/pnl" element={<PnLPage />} />
            <Route path="/risk" element={<RiskControlsPage />} />
            <Route path="/logs" element={<LogsPage />} />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
