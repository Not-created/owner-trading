import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

// Wraps routes that require an authenticated session. Nested via
// <Route element={<ProtectedRoute />}>...</Route> in App.jsx.
export default function ProtectedRoute() {
  const { user, mustChangePassword, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <p style={{ padding: '2rem', fontFamily: 'sans-serif' }}>Loading…</p>;
  }

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // Every protected route except /change-password itself redirects there
  // until the forced password change is complete.
  if (mustChangePassword && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }

  return <Outlet />;
}
