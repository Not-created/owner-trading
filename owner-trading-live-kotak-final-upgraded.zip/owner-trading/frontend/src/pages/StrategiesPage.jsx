import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  listStrategies,
  getStrategy,
  createStrategy,
  updateStrategy,
  deleteStrategy,
  startStrategy,
  stopStrategy,
  runStrategyOnce,
} from '../api/client.js';

const DEFAULT_CODE = `function strategy({ market, position, indicators }) {
  // market.price: latest price. market.history: array of past prices.
  // position.quantity: current position (0 = flat). indicators.sma/ema/rsi available.
  const avg = indicators.sma(market.history, 5);
  if (!avg) return "HOLD";
  if (market.price > avg * 1.001) return "BUY";
  if (market.price < avg * 0.999) return "SELL";
  return "HOLD";
}`;

const EMPTY_FORM = {
  name: '',
  symbol: '',
  code: DEFAULT_CODE,
  mode: 'PAPER',
  positionSizingType: 'FIXED_QTY',
  positionSizingValue: 1,
  stopLossPercent: '',
  targetPercent: '',
  exchangeSegment: 'nse_cm',
  product: 'MIS',
};

function toFormShape(strategy) {
  return {
    name: strategy.name,
    symbol: strategy.symbol,
    code: strategy.code,
    mode: strategy.mode,
    positionSizingType: strategy.position_sizing_type,
    positionSizingValue: strategy.position_sizing_value,
    stopLossPercent: strategy.stop_loss_percent ?? '',
    targetPercent: strategy.target_percent ?? '',
    exchangeSegment: strategy.exchange_segment,
    product: strategy.product,
  };
}

export default function StrategiesPage() {
  const [strategies, setStrategies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [editingId, setEditingId] = useState(null); // null = creating new
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  function load() {
    setLoading(true);
    return listStrategies()
      .then(setStrategies)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  function handleChange(field) {
    return (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));
  }

  function openNewStrategyForm() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setShowBuilder(true);
  }

  async function openEditForm(id) {
    setError(null);
    try {
      const full = await getStrategy(id); // fetches full row, including code
      setEditingId(id);
      setForm(toFormShape(full));
      setShowBuilder(true);
    } catch (err) {
      setError(err.message);
    }
  }

  function closeBuilder() {
    setShowBuilder(false);
    setEditingId(null);
    setForm(EMPTY_FORM);
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError(null);
    setSaving(true);
    const payload = {
      ...form,
      positionSizingValue: Number(form.positionSizingValue),
      stopLossPercent: form.stopLossPercent === '' ? null : Number(form.stopLossPercent),
      targetPercent: form.targetPercent === '' ? null : Number(form.targetPercent),
    };
    try {
      if (editingId) {
        await updateStrategy(editingId, payload);
      } else {
        await createStrategy(payload);
      }
      closeBuilder();
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(action, id) {
    setError(null);
    try {
      await action(id);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Delete this strategy? This cannot be undone.')) return;
    await handleAction(deleteStrategy, id);
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 640 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>Strategies</h1>
        <button onClick={showBuilder ? closeBuilder : openNewStrategyForm}>
          {showBuilder ? 'Cancel' : '+ New strategy'}
        </button>
      </div>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}

      {showBuilder && (
        <form onSubmit={handleSubmit} style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.1em', marginTop: 0 }}>
            {editingId ? `Edit strategy #${editingId}` : 'Strategy Builder'}
          </h2>
          <label style={{ display: 'block' }}>
            Name
            <input value={form.name} onChange={handleChange('name')} required style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Symbol
            <input value={form.symbol} onChange={handleChange('symbol')} required style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Mode
            <select value={form.mode} onChange={handleChange('mode')} style={{ display: 'block', width: '100%', marginTop: 4 }}>
              <option value="PAPER">PAPER</option>
              <option value="LIVE">LIVE</option>
            </select>
          </label>
          {form.mode === 'LIVE' && (
            <div style={{ display: 'flex', gap: 8, marginTop: '0.75rem' }}>
              <label style={{ flex: 1 }}>
                Exchange segment
                <select value={form.exchangeSegment} onChange={handleChange('exchangeSegment')} style={{ display: 'block', width: '100%', marginTop: 4 }}>
                  <option value="nse_cm">NSE Cash (nse_cm)</option>
                  <option value="bse_cm">BSE Cash (bse_cm)</option>
                  <option value="nse_fo">NSE F&amp;O (nse_fo)</option>
                  <option value="bse_fo">BSE F&amp;O (bse_fo)</option>
                  <option value="mcx_fo">MCX (mcx_fo)</option>
                </select>
              </label>
              <label style={{ flex: 1 }}>
                Product
                <select value={form.product} onChange={handleChange('product')} style={{ display: 'block', width: '100%', marginTop: 4 }}>
                  <option value="MIS">Intraday (MIS)</option>
                  <option value="CNC">Delivery (CNC)</option>
                  <option value="NRML">Carry-forward (NRML)</option>
                  <option value="MTF">Margin Trading (MTF)</option>
                </select>
              </label>
            </div>
          )}
          {form.mode === 'LIVE' && (
            <p style={{ fontSize: '0.8em', color: '#b00020' }}>
              Symbol must match Kotak's trading symbol format (for example "RELIANCE-EQ"). LIVE
              execution resolves the symbol through Kotak's official scrip-search service before quotes/orders.
            </p>
          )}
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Position sizing
            <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
              <select value={form.positionSizingType} onChange={handleChange('positionSizingType')}>
                <option value="FIXED_QTY">Fixed quantity</option>
                <option value="FIXED_VALUE">Fixed value (₹)</option>
              </select>
              <input type="number" min="0" step="any" value={form.positionSizingValue} onChange={handleChange('positionSizingValue')} required />
            </div>
          </label>
          <div style={{ display: 'flex', gap: 8, marginTop: '0.75rem' }}>
            <label style={{ flex: 1 }}>
              Stop-loss %
              <input type="number" step="any" value={form.stopLossPercent} onChange={handleChange('stopLossPercent')} placeholder="none" style={{ display: 'block', width: '100%', marginTop: 4 }} />
            </label>
            <label style={{ flex: 1 }}>
              Target %
              <input type="number" step="any" value={form.targetPercent} onChange={handleChange('targetPercent')} placeholder="none" style={{ display: 'block', width: '100%', marginTop: 4 }} />
            </label>
          </div>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Code — must define <code>function strategy({'{'} market, position, indicators {'}'})</code> returning
            "BUY" / "SELL" / "EXIT" / "HOLD". Available: <code>indicators.sma/ema/rsi(history, period)</code>.
            <textarea
              value={form.code}
              onChange={handleChange('code')}
              rows={12}
              spellCheck={false}
              style={{ display: 'block', width: '100%', marginTop: 4, fontFamily: 'monospace', fontSize: '0.85em' }}
            />
          </label>
          <p style={{ fontSize: '0.85em', color: '#555' }}>
            Runs in a worker thread with a hard timeout — this is hang/crash isolation, not a security
            sandbox. Do not paste untrusted code you would not run directly yourself.
          </p>
          <button type="submit" disabled={saving} style={{ marginTop: '0.5rem' }}>
            {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create strategy'}
          </button>
        </form>
      )}

      {loading && <p>Loading…</p>}

      {!loading && strategies.length === 0 && <p>No strategies yet.</p>}

      {!loading &&
        strategies.map((s) => (
          <div key={s.id} style={{ border: '1px solid #ddd', borderRadius: 6, padding: '1rem', marginBottom: '0.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button
                onClick={() => openEditForm(s.id)}
                style={{ background: 'none', border: 'none', padding: 0, font: 'inherit', cursor: 'pointer', textDecoration: 'underline' }}
                title="Click to edit"
              >
                <strong>{s.name}</strong>
              </button>
              <span>
                {s.symbol} · {s.mode} ·{' '}
                <span style={{ color: s.status === 'ERROR' ? '#b00020' : s.status === 'RUNNING' ? '#0a7d28' : '#555' }}>
                  {s.status}
                </span>
              </span>
            </div>
            {s.last_error && <p style={{ color: '#b00020', fontSize: '0.85em' }}>Last error: {s.last_error}</p>}
            {s.last_run_at && <p style={{ fontSize: '0.8em', color: '#777' }}>Last run: {s.last_run_at}</p>}
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              {s.status === 'RUNNING' ? (
                <button onClick={() => handleAction(stopStrategy, s.id)}>Stop</button>
              ) : (
                <button onClick={() => handleAction(startStrategy, s.id)}>Start</button>
              )}
              <button onClick={() => handleAction(runStrategyOnce, s.id)}>Run once</button>
              <button onClick={() => handleDelete(s.id)} style={{ color: '#b00020' }}>
                Delete
              </button>
            </div>
          </div>
        ))}
    </main>
  );
}
