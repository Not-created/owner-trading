import { useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function LoginPage() {
  const { user, mustChangePassword, loading, login } = useAuth();
  const location = useLocation();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  if (loading) {
    return <p style={{ padding: '2rem', fontFamily: 'sans-serif' }}>Loading…</p>;
  }

  // Already logged in — don't show the login form.
  if (user) {
    const redirectTo = mustChangePassword
      ? '/change-password'
      : location.state?.from?.pathname || '/';
    return <Navigate to={redirectTo} replace />;
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(username, password);
      // AuthContext state update triggers the redirect above on re-render.
    } catch (err) {
      setError(err.code === 'INVALID_CREDENTIALS' ? 'Invalid username or password.' : err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 360, margin: '0 auto' }}>
      <h1>Owner Trading</h1>
      <form onSubmit={handleSubmit}>
        <label style={{ display: 'block' }}>
          Username
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoFocus
            required
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>

        {error && <p style={{ color: '#b00020' }}>{error}</p>}

        <button type="submit" disabled={submitting} style={{ marginTop: '1rem' }}>
          {submitting ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </main>
  );
}
