import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { changePassword } from '../api/client.js';

export default function ChangePasswordPage() {
  const { user, mustChangePassword, loading, onPasswordChanged, logout } = useAuth();
  const navigate = useNavigate();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  if (loading) {
    return <p style={{ padding: '2rem', fontFamily: 'sans-serif' }}>Loading…</p>;
  }
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError(null);

    if (newPassword !== confirmPassword) {
      setError('New password and confirmation do not match.');
      return;
    }

    setSubmitting(true);
    try {
      await changePassword(currentPassword, newPassword);
      onPasswordChanged();
      setSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => navigate('/', { replace: true }), 700);
    } catch (err) {
      setError(
        err.code === 'INVALID_CURRENT_PASSWORD'
          ? 'Current password is incorrect.'
          : err.message
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 360, margin: '0 auto' }}>
      <h1>{mustChangePassword ? 'Set a new password' : 'Change password'}</h1>

      {mustChangePassword && (
        <p>You&rsquo;re using a temporary password. Set a new one before continuing.</p>
      )}

      <form onSubmit={handleSubmit}>
        <label style={{ display: 'block' }}>
          Current password
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            autoFocus
            required
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          New password
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            minLength={8}
            required
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Confirm new password
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            minLength={8}
            required
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>

        {error && <p style={{ color: '#b00020' }}>{error}</p>}
        {success && <p style={{ color: '#0a7d28' }}>Password updated.</p>}

        <button type="submit" disabled={submitting} style={{ marginTop: '1rem' }}>
          {submitting ? 'Saving…' : 'Save new password'}
        </button>
      </form>

      {!mustChangePassword && (
        <button onClick={logout} style={{ marginTop: '1rem' }}>
          Log out
        </button>
      )}
    </main>
  );
}
