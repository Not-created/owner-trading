import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getRiskLimits, updateRiskLimits } from '../api/client.js';

export default function RiskControlsPage() {
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getRiskLimits()
      .then((limits) =>
        setForm({
          maxOrderValue: limits.max_order_value,
          maxDailyLoss: limits.max_daily_loss,
          maxOpenPositions: limits.max_open_positions,
          maxOrdersPerMinute: limits.max_orders_per_minute,
        })
      )
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  function handleChange(field) {
    return (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));
  }

  async function handleSave(event) {
    event.preventDefault();
    setError(null);
    setSaved(false);
    setSaving(true);
    try {
      await updateRiskLimits(form);
      setSaved(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 480 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Risk controls</h1>
      <p style={{ fontSize: '0.85em', color: '#555' }}>
        Every order — PAPER and LIVE — passes through these checks before it can be submitted to a
        broker adapter. No order can bypass this.
      </p>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {loading && <p>Loading…</p>}

      {!loading && form && (
        <form onSubmit={handleSave}>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Max order value
            <input type="number" min="0" step="any" value={form.maxOrderValue} onChange={handleChange('maxOrderValue')} style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Max cumulative loss (standing cap — see note below)
            <input type="number" min="0" step="any" value={form.maxDailyLoss} onChange={handleChange('maxDailyLoss')} style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Max open positions
            <input type="number" min="0" step="1" value={form.maxOpenPositions} onChange={handleChange('maxOpenPositions')} style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>
          <label style={{ display: 'block', marginTop: '0.75rem' }}>
            Max orders per minute
            <input type="number" min="0" step="1" value={form.maxOrdersPerMinute} onChange={handleChange('maxOrdersPerMinute')} style={{ display: 'block', width: '100%', marginTop: 4 }} />
          </label>

          <p style={{ fontSize: '0.8em', color: '#777', marginTop: '0.75rem' }}>
            Note: the loss cap compares against all-time cumulative realized P&amp;L per mode, not a
            true midnight-reset daily figure — there is no date-partitioned P&amp;L ledger yet.
          </p>

          {saved && <p style={{ color: '#0a7d28' }}>Saved.</p>}
          <button type="submit" disabled={saving} style={{ marginTop: '0.5rem' }}>
            {saving ? 'Saving…' : 'Save risk limits'}
          </button>
        </form>
      )}
    </main>
  );
}
