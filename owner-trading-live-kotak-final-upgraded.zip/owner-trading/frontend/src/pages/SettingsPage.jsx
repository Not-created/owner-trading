import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getBrokerConfig, saveBrokerConfig, deleteBrokerConfig, testKotakConnection } from '../api/client.js';

const EMPTY_FORM = {
  consumerKey: '',
  ucc: '',
  mobileNumber: '',
  mpin: '',
  totpSecret: '',
  environment: 'prod',
};

const STATE_INFO = {
  CONNECTED: { label: 'CONNECTED', color: '#0a7d28' },
  VERIFYING: { label: 'AUTHENTICATING...', color: '#b8860b' },
  AUTH_FAILED: { label: 'AUTH FAILED', color: '#b00020' },
  SESSION_EXPIRED: { label: 'SESSION EXPIRED', color: '#b00020' },
  CONNECTION_ERROR: { label: 'CONNECTION ERROR', color: '#b00020' },
  DISCONNECTING: { label: 'DISCONNECTING...', color: '#b8860b' },
  DISCONNECTED: { label: 'DISCONNECTED', color: '#777' },
};

export default function SettingsPage() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState(null);
  const [authMessage, setAuthMessage] = useState(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  function loadStatus() {
    setLoading(true);
    return getBrokerConfig()
      .then((data) => setStatus(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    loadStatus();
  }, []);

  function handleChange(field) {
    return (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));
  }

  async function handleSaveAndConnect(event) {
    event.preventDefault();
    setError(null);
    setAuthMessage(null);
    setSaving(true);
    try {
      const result = await saveBrokerConfig(form);
      setForm(EMPTY_FORM);
      if (result.authResult.success) {
        setAuthMessage({ ok: true, text: 'Connected and verified.' });
      } else {
        setAuthMessage({
          ok: false,
          text: `Saved, but connection failed: ${result.authResult.errorCode}${result.authResult.errorMessage ? ' - ' + result.authResult.errorMessage : ''}`,
        });
      }
      await loadStatus();
    } catch (err) {
      if (err.code === 'MISSING_FIELDS') {
        setError(`Missing required fields: ${(err.missing || []).join(', ')}`);
      } else {
        setError(err.message);
      }
    } finally {
      setSaving(false);
    }
  }

  async function handleTestConnection() {
    setError(null);
    setAuthMessage(null);
    setTesting(true);
    try {
      const result = await testKotakConnection();
      setAuthMessage(
        result.authResult.success
          ? { ok: true, text: 'Connection verified.' }
          : { ok: false, text: `Test failed: ${result.authResult.errorCode}${result.authResult.errorMessage ? ' - ' + result.authResult.errorMessage : ''}` }
      );
      await loadStatus();
    } catch (err) {
      setError(err.message);
    } finally {
      setTesting(false);
    }
  }

  async function handleDisconnect() {
    setError(null);
    setAuthMessage(null);
    try {
      await deleteBrokerConfig();
      await loadStatus();
    } catch (err) {
      setError(err.message);
    }
  }

  const stateInfo = status ? STATE_INFO[status.connectionState] || STATE_INFO.DISCONNECTED : STATE_INFO.DISCONNECTED;

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 480 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Settings - Kotak Neo connection</h1>

      <p style={{ fontSize: '0.9em', color: '#555' }}>
        Credentials are encrypted at rest and never sent back to this page in full. Saving triggers a
        real authentication attempt against Kotak - a successful save does not by itself mean a working
        connection; check the status below.
      </p>

      {loading && <p>Loading current status...</p>}

      {!loading && status && (
        <div style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, marginBottom: '1.5rem' }}>
          <p style={{ margin: 0 }}>
            <strong>KOTAK NEO</strong> - <span style={{ color: stateInfo.color, fontWeight: 'bold' }}>{stateInfo.label}</span>
          </p>
          {status.configured && (
            <>
              <p style={{ margin: '0.5rem 0 0', fontSize: '0.9em' }}>
                Environment: {status.environment?.toUpperCase()} - UCC: {status.maskedFields?.ucc} - Mobile:{' '}
                {status.maskedFields?.mobileNumber}
              </p>
              {status.lastVerifiedAt && (
                <p style={{ margin: '0.25rem 0 0', fontSize: '0.85em', color: '#777' }}>
                  Last verified: {status.lastVerifiedAt}
                </p>
              )}
              {status.lastErrorMessage && (
                <p style={{ margin: '0.25rem 0 0', fontSize: '0.85em', color: '#b00020' }}>
                  Last error ({status.lastErrorCode}): {status.lastErrorMessage}
                </p>
              )}
              <div style={{ marginTop: '0.75rem', display: 'flex', gap: 8 }}>
                <button onClick={handleTestConnection} disabled={testing}>
                  {testing ? 'Testing...' : 'Test connection'}
                </button>
                <button onClick={handleDisconnect} style={{ color: '#b00020' }}>
                  Disconnect
                </button>
              </div>
            </>
          )}
          {!status.configured && <p style={{ margin: '0.5rem 0 0' }}>Not configured yet.</p>}
        </div>
      )}

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {authMessage && <p style={{ color: authMessage.ok ? '#0a7d28' : '#b00020' }}>{authMessage.text}</p>}

      <form onSubmit={handleSaveAndConnect}>
        <label style={{ display: 'block' }}>
          Consumer / API access token
          <input
            value={form.consumerKey}
            onChange={handleChange('consumerKey')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          UCC (Unique Client Code)
          <input
            value={form.ucc}
            onChange={handleChange('ucc')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Mobile number (with country code)
          <input
            value={form.mobileNumber}
            onChange={handleChange('mobileNumber')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          MPIN
          <input
            type="password"
            value={form.mpin}
            onChange={handleChange('mpin')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          TOTP seed (from authenticator setup - not the 6-digit code)
          <input
            type="password"
            value={form.totpSecret}
            onChange={handleChange('totpSecret')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Environment
          <select
            value={form.environment}
            onChange={handleChange('environment')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          >
            <option value="prod">Production</option>
            <option value="uat">UAT (test)</option>
          </select>
        </label>

        <button type="submit" disabled={saving} style={{ marginTop: '1rem' }}>
          {saving ? 'Connecting...' : 'Save & Connect'}
        </button>
      </form>
    </main>
  );
}
