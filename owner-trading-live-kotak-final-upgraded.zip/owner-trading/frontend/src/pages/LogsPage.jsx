import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listLogs, listStrategies } from '../api/client.js';

const LEVEL_COLORS = { ERROR: '#b00020', WARN: '#b8860b', INFO: '#333' };

export default function LogsPage() {
  const [logs, setLogs] = useState([]);
  const [strategies, setStrategies] = useState([]);
  const [strategyFilter, setStrategyFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    listStrategies().then(setStrategies).catch(() => {});
  }, []);

  function load(strategyId) {
    setLoading(true);
    return listLogs(strategyId || undefined)
      .then(setLogs)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load(strategyFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [strategyFilter]);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 700 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>Execution logs</h1>
        <select value={strategyFilter} onChange={(e) => setStrategyFilter(e.target.value)}>
          <option value="">All strategies</option>
          {strategies.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && logs.length === 0 && <p>No log entries yet.</p>}

      {!loading && logs.length > 0 && (
        <div style={{ fontFamily: 'monospace', fontSize: '0.85em' }}>
          {logs.map((l) => (
            <div key={l.id} style={{ borderBottom: '1px solid #eee', padding: '0.35rem 0' }}>
              <span style={{ color: '#999' }}>{l.created_at}</span>{' '}
              <span style={{ color: LEVEL_COLORS[l.level], fontWeight: 'bold' }}>[{l.level}]</span>{' '}
              {l.strategy_id && <span style={{ color: '#777' }}>(strategy #{l.strategy_id}) </span>}
              {l.message}
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
