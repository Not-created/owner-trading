import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMarketData } from '../api/client.js';

export default function MarketDataPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getMarketData()
      .then(setData)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 600 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Market data</h1>
      <p style={{ fontSize: '0.85em', color: '#555', background: '#fdecea', border: '1px solid #b00020', borderRadius: 6, padding: '0.75rem' }}>
        <strong>Synthetic data only.</strong> This project has no connection to a real market-data
        feed. These are randomly-generated prices used to drive PAPER strategy testing — never treat
        this as real price information.
      </p>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && data && data.symbols.length === 0 && <p>No symbols yet — create a strategy first.</p>}

      {!loading &&
        data &&
        data.symbols.map((s) => (
          <div key={s.symbol} style={{ border: '1px solid #ddd', borderRadius: 6, padding: '1rem', marginBottom: '0.75rem' }}>
            <strong>{s.symbol}</strong> — last: {s.price}
            <div style={{ fontSize: '0.8em', color: '#777', marginTop: 4, wordBreak: 'break-all' }}>
              recent: {s.history.slice(-15).join(', ')}
            </div>
          </div>
        ))}
    </main>
  );
}
