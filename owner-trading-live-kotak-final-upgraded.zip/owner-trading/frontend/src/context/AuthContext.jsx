import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { getMe, login as apiLogin, logout as apiLogout } from '../api/client.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [loading, setLoading] = useState(true); // true until the initial /me check resolves

  // Asks the backend "am I logged in?" via the session cookie. Called once
  // on mount, and can be called again after actions that might change auth
  // state elsewhere.
  const refresh = useCallback(async () => {
    try {
      const data = await getMe();
      setUser(data.user);
      setMustChangePassword(data.mustChangePassword);
    } catch {
      setUser(null);
      setMustChangePassword(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const login = useCallback(async (username, password) => {
    const data = await apiLogin(username, password);
    setUser(data.user);
    setMustChangePassword(data.mustChangePassword);
    return data;
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiLogout();
    } finally {
      setUser(null);
      setMustChangePassword(false);
    }
  }, []);

  // Called right after a successful change-password call so the UI updates
  // immediately, without waiting for a second round trip to /me.
  const onPasswordChanged = useCallback(() => {
    setMustChangePassword(false);
  }, []);

  const value = { user, mustChangePassword, loading, login, logout, refresh, onPasswordChanged };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
