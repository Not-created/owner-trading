#!/usr/bin/env python3
"""Internal Owner Trading -> official Kotak Neo Python SDK bridge.

All broker calls use the current kotakneoapi v3 API surface. This service is
localhost-only and never exposes credentials/tokens to the Node/frontend side.
"""
import asyncio, json, os, sys, time, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    from neo_api_client import NeoAPI
    from neo_api_client.websocket.feed import WsToken, SFeedScrip
except ImportError:
    NeoAPI = None
    WsToken = None
    SFeedScrip = None

SERVICE_SECRET = os.environ.get("KOTAK_SERVICE_SECRET", "")
PORT = int(os.environ.get("KOTAK_SERVICE_PORT", "5055"))
SESSION_TTL_SECONDS = int(os.environ.get("KOTAK_SESSION_TTL_SECONDS", str(6 * 60 * 60)))
_sessions = {}
_sessions_lock = threading.Lock()
_quote_cache = {}
_quote_lock = threading.Lock()
_feed_threads = {}

class BrokerResponseError(Exception):
    def __init__(self, code, message, status=502):
        super().__init__(message)
        self.code, self.status = code, status


def sanitize(text):
    text = str(text)
    lowered = text.lower()
    sensitive = ("consumer_key", "access_token", "mpin", "totp", "authorization", "session")
    if any(x in lowered for x in sensitive):
        return "Kotak SDK error (sensitive detail redacted)"
    return text[:400]


def normalize(result):
    """Turn SDK response into useful data; NEVER treat an SDK error dict as success."""
    if isinstance(result, dict):
        if result.get("stat") and str(result.get("stat")).lower() not in ("ok", "success"):
            msg = result.get("errMsg") or result.get("desc") or result.get("error") or result.get("message") or "Kotak request failed"
            raise BrokerResponseError("BROKER_REJECTED", sanitize(msg), 502)
        if "Error" in result or "error" in result:
            err = result.get("Error") or result.get("error")
            if isinstance(err, list):
                msg = "; ".join(str(x.get("message", x)) if isinstance(x, dict) else str(x) for x in err)
            else:
                msg = str(err)
            raise BrokerResponseError("BROKER_REJECTED", sanitize(msg), 502)
        if "status_code" in result and int(result.get("status_code") or 200) >= 400:
            raise BrokerResponseError("BROKER_REJECTED", sanitize(result.get("errMsg") or result), 502)
        if "data" in result and ("stat" in result or "stCode" in result):
            return result["data"]
    return result


def session(ucc):
    with _sessions_lock:
        item = _sessions.get(ucc)
        if not item:
            return None
        if time.time() - item["created_at"] > SESSION_TTL_SECONDS:
            _sessions.pop(ucc, None)
            return None
        return item["client"]


def store_session(ucc, client):
    with _sessions_lock:
        _sessions[ucc] = {"client": client, "created_at": time.time()}


def drop_session(ucc):
    with _sessions_lock:
        _sessions.pop(ucc, None)


def require_sdk():
    if NeoAPI is None:
        raise BrokerResponseError("SDK_NOT_INSTALLED", "kotakneoapi is not installed", 503)


def authenticate(body):
    require_sdk()
    required = [body.get(k) for k in ("consumerKey", "mobileNumber", "ucc", "totp", "mpin")]
    if not all(required):
        return 400, {"success": False, "errorCode": "MISSING_FIELDS"}
    try:
        client = NeoAPI(consumer_key=body["consumerKey"], environment=body.get("environment", "prod"))
        login = normalize(client.totp_login(mobile_number=body["mobileNumber"], ucc=body["ucc"], totp=body["totp"]))
        validate = normalize(client.totp_validate(mpin=body["mpin"]))
        # Current v3 limits() has NO parameters.
        normalize(client.limits())
        store_session(body["ucc"], client)
        return 200, {"success": True, "ucc": body["ucc"]}
    except BrokerResponseError as e:
        return e.status, {"success": False, "errorCode": e.code, "errorMessage": str(e)}
    except Exception as e:
        return 401, {"success": False, "errorCode": "AUTH_FAILED", "errorMessage": sanitize(e)}


def with_session(body, fn):
    ucc = body.get("ucc")
    client = session(ucc) if ucc else None
    if not client:
        return 401, {"success": False, "errorCode": "SESSION_EXPIRED"}
    try:
        return 200, {"success": True, "data": normalize(fn(client, body))}
    except BrokerResponseError as e:
        if e.code in ("SESSION_EXPIRED", "INVALID_SESSION"):
            drop_session(ucc)
        return e.status, {"success": False, "errorCode": e.code, "errorMessage": str(e)}
    except Exception as e:
        msg = sanitize(e)
        code = "SESSION_EXPIRED" if any(x in msg.lower() for x in ("invalid session", "session expired", "unauthorized", "forbidden")) else "BROKER_ERROR"
        if code == "SESSION_EXPIRED": drop_session(ucc)
        return 502, {"success": False, "errorCode": code, "errorMessage": msg}


def place_order(body):
    def fn(c, b):
        o = b["order"]
        return c.place_order(exchange_segment=o["exchangeSegment"], product=o["product"], price=str(o.get("price", "0")), order_type=o["orderType"], quantity=str(o["quantity"]), validity=o.get("validity", "DAY"), trading_symbol=o["tradingSymbol"], transaction_type=o["transactionType"], tag=o.get("tag"))
    return with_session(body, fn)


def modify_order(body):
    def fn(c, b):
        o = b["order"]
        return c.modify_order(order_id=o["orderId"], price=str(o.get("price", "0")), order_type=o["orderType"], quantity=str(o["quantity"]), validity=o.get("validity", "DAY"), trigger_price=str(o.get("triggerPrice", "0")), disclosed_quantity=str(o.get("disclosedQuantity", "0")), amo=o.get("amo", "NO"))
    return with_session(body, fn)


def cancel_order(body): return with_session(body, lambda c,b: c.cancel_order(order_id=b["orderId"]))
def order_report(body): return with_session(body, lambda c,b: c.order_report(order_id=b.get("orderId")) if b.get("orderId") else c.order_report())
def order_history(body): return with_session(body, lambda c,b: c.order_history(order_id=b["orderId"]))
def trade_report(body): return with_session(body, lambda c,b: c.trade_report())
def positions(body): return with_session(body, lambda c,b: c.positions())
def holdings(body): return with_session(body, lambda c,b: c.holdings())
def limits(body): return with_session(body, lambda c,b: c.limits())


def search_scrip(body):
    require_sdk()
    # Scrip search needs only the consumer key, but we reuse authenticated session when available.
    ucc = body.get("ucc")
    client = session(ucc) if ucc else None
    if not client:
        return 401, {"success": False, "errorCode": "SESSION_EXPIRED"}
    try:
        result = normalize(client.search_scrip(exchange_segment=body["exchangeSegment"], symbol=body.get("symbol", ""), expiry=body.get("expiry", ""), option_type=body.get("optionType", ""), strike_price=body.get("strikePrice", ""), ignore_50multiple=body.get("ignore50Multiple", True)))
        return 200, {"success": True, "data": result}
    except BrokerResponseError as e:
        return e.status, {"success": False, "errorCode": e.code, "errorMessage": str(e)}


def resolve_scrip(client, exchange_segment, symbol):
    key = (exchange_segment, symbol.upper())
    with _quote_lock:
        if key in _quote_cache: return _quote_cache[key]
    raw = symbol.strip()
    base = raw.split("-")[0]
    result = normalize(client.search_scrip(exchange_segment=exchange_segment, symbol=base, expiry="", option_type="", strike_price="", ignore_50multiple=True))
    if not isinstance(result, list) or not result:
        raise BrokerResponseError("SYMBOL_NOT_FOUND", f"Kotak symbol not found: {symbol}", 404)
    exact = next((x for x in result if str(x.get("pTrdSymbol", "")).upper() == raw.upper()), None)
    chosen = exact or result[0]
    meta = {"instrumentToken": str(chosen.get("pSymbol")), "exchangeSegment": chosen.get("pExchSeg", exchange_segment), "tradingSymbol": chosen.get("pTrdSymbol")}
    if not meta["instrumentToken"] or not meta["tradingSymbol"]: raise BrokerResponseError("SYMBOL_NOT_FOUND", f"Incomplete Kotak scrip metadata for {symbol}", 404)
    with _quote_lock: _quote_cache[key] = meta
    return meta


def quote(body):
    def fn(c,b):
        meta = resolve_scrip(c, b["exchangeSegment"], b["symbol"])
        return {"symbol": meta["tradingSymbol"], "meta": meta, "quote": c.quotes(instrument_tokens=[{"instrument_token": meta["instrumentToken"], "exchange_segment": meta["exchangeSegment"]}], quote_type=b.get("quoteType", "all"))}
    return with_session(body, fn)


def logout(body):
    ucc=body.get("ucc"); c=session(ucc)
    if c:
        try: normalize(c.logout())
        except Exception: pass
    drop_session(ucc)
    return 200, {"success": True}

ROUTES={"/authenticate":authenticate,"/place-order":place_order,"/modify-order":modify_order,"/cancel-order":cancel_order,"/order-report":order_report,"/order-history":order_history,"/trade-report":trade_report,"/positions":positions,"/holdings":holdings,"/limits":limits,"/search-scrip":search_scrip,"/quotes":quote,"/logout":logout}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt,*args): sys.stderr.write("[kotak_service] "+(fmt%args)+"\n")
    def send_json(self,status,payload):
        raw=json.dumps(payload,default=str).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path=="/health": self.send_json(200,{"status":"ok","sdk":"installed" if NeoAPI else "NOT_INSTALLED"}); return
        self.send_json(404,{"error":"NOT_FOUND"})
    def do_POST(self):
        if self.path=="/health": self.send_json(200,{"status":"ok"}); return
        if not SERVICE_SECRET or self.headers.get("X-Internal-Secret")!=SERVICE_SECRET: self.send_json(401,{"error":"UNAUTHORIZED"}); return
        fn=ROUTES.get(self.path)
        if not fn: self.send_json(404,{"error":"NOT_FOUND"}); return
        try:
            n=int(self.headers.get("Content-Length",0)); body=json.loads(self.rfile.read(n) or b"{}")
            status,payload=fn(body)
        except (ValueError,json.JSONDecodeError): status,payload=400,{"success":False,"errorCode":"INVALID_JSON"}
        except KeyError as e: status,payload=400,{"success":False,"errorCode":"MISSING_FIELDS","errorMessage":str(e)}
        self.send_json(status,payload)

def main():
    if not SERVICE_SECRET: sys.stderr.write("KOTAK_SERVICE_SECRET is required\n"); sys.exit(1)
    ThreadingHTTPServer(("127.0.0.1",PORT),Handler).serve_forever()
if __name__=="__main__": main()
