const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const config = require('../src/config/env');
const { getDb, closeDb } = require('../src/db/connection');
const { ensureAdminBootstrap } = require('../src/services/adminBootstrap');
const app = require('../server');

function extractCookie(setCookieHeaders, name) {
  if (!setCookieHeaders) return null;
  const match = setCookieHeaders.find((c) => c.startsWith(`${name}=`));
  if (!match) return null;
  return match.split(';')[0]; // "ot_session=<value>"
}

function resetDatabaseFile() {
  closeDb();
  for (const suffix of ['', '-wal', '-shm', '-journal']) {
    const p = config.databasePath + suffix;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

test('Authentication: bootstrap -> login -> forced password change -> session invalidation', async (t) => {
  resetDatabaseFile();
  const db = getDb(); // fresh DB: migrations run, zero users

  const bootstrap = ensureAdminBootstrap(db);
  assert.equal(bootstrap.created, true, 'expected admin to be freshly created on empty DB');
  const { username, password: tempPassword } = bootstrap;

  const server = app.listen(0);
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}/api`;

  await t.test('rejects wrong password', async () => {
    const res = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password: 'definitely-wrong' }),
    });
    assert.equal(res.status, 401);
  });

  let firstSessionCookie;

  await t.test('logs in with bootstrap credentials and reports mustChangePassword=true', async () => {
    const res = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password: tempPassword }),
    });
    const body = await res.json();

    assert.equal(res.status, 200);
    assert.equal(body.mustChangePassword, true);
    assert.equal(body.user.username, username);

    firstSessionCookie = extractCookie(res.headers.getSetCookie(), 'ot_session');
    assert.ok(firstSessionCookie, 'expected a session cookie to be set');
  });

  await t.test('/api/auth/me works with the session cookie while password change is pending', async () => {
    const res = await fetch(`${base}/auth/me`, {
      headers: { Cookie: firstSessionCookie },
    });
    const body = await res.json();

    assert.equal(res.status, 200);
    assert.equal(body.mustChangePassword, true);
  });

  await t.test('change-password rejects wrong current password', async () => {
    const res = await fetch(`${base}/auth/change-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: firstSessionCookie },
      body: JSON.stringify({ currentPassword: 'wrong', newPassword: 'a-new-strong-password' }),
    });
    assert.equal(res.status, 401);
  });

  let secondSessionCookie;
  const newPassword = 'a-new-strong-password-123';

  await t.test('change-password succeeds with correct current password', async () => {
    const res = await fetch(`${base}/auth/change-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: firstSessionCookie },
      body: JSON.stringify({ currentPassword: tempPassword, newPassword }),
    });
    const body = await res.json();

    assert.equal(res.status, 200);
    assert.equal(body.mustChangePassword, false);

    secondSessionCookie = extractCookie(res.headers.getSetCookie(), 'ot_session');
    assert.ok(secondSessionCookie, 'expected a fresh session cookie after password change');
    assert.notEqual(secondSessionCookie, firstSessionCookie, 'session must be rotated, not reused');
  });

  await t.test('old session cookie is invalidated after password change', async () => {
    const res = await fetch(`${base}/auth/me`, {
      headers: { Cookie: firstSessionCookie },
    });
    assert.equal(res.status, 401);
  });

  await t.test('new session cookie still works', async () => {
    const res = await fetch(`${base}/auth/me`, {
      headers: { Cookie: secondSessionCookie },
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.mustChangePassword, false);
  });

  await t.test('old temporary password no longer works', async () => {
    const res = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password: tempPassword }),
    });
    assert.equal(res.status, 401);
  });

  await t.test('new password logs in successfully with mustChangePassword=false', async () => {
    const res = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password: newPassword }),
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.mustChangePassword, false);
  });

  server.close();
  resetDatabaseFile();
});

test('Admin bootstrap is idempotent: does not run again once a user exists', () => {
  resetDatabaseFile();
  const db = getDb();

  const first = ensureAdminBootstrap(db);
  assert.equal(first.created, true);

  const second = ensureAdminBootstrap(db);
  assert.equal(second.created, false, 'must not create a second admin or reset the password');

  resetDatabaseFile();
});
