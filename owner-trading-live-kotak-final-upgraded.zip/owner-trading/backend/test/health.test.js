const test = require('node:test');
const assert = require('node:assert/strict');
const app = require('../server');
const { closeDb } = require('../src/db/connection');

test('GET /api/health returns ok status and confirms DB connection', async () => {
  const server = app.listen(0);
  const { port } = server.address();

  try {
    const res = await fetch(`http://127.0.0.1:${port}/api/health`);
    const body = await res.json();

    assert.equal(res.status, 200);
    assert.equal(body.status, 'ok');
    assert.equal(body.dbStatus, 'connected');
    assert.equal(typeof body.schemaVersion, 'number');
  } finally {
    server.close();
    closeDb();
  }
});

test('GET /unknown-route returns 404', async () => {
  const server = app.listen(0);
  const { port } = server.address();

  try {
    const res = await fetch(`http://127.0.0.1:${port}/unknown-route`);
    assert.equal(res.status, 404);
  } finally {
    server.close();
  }
});
