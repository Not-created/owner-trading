// Verified against RFC 6238 Appendix B's own published test vectors.
// The RFC's vectors use the raw ASCII secret "12345678901234567890" and
// publish 8-digit outputs; a 6-digit code is mathematically the last 6
// digits of the same computation (10^6 divides 10^8), so this test
// base32-encodes that same secret (the realistic real-world seed format)
// and checks against the last 6 digits of each published vector.

const test = require('node:test');
const assert = require('node:assert/strict');
const { generateTotp } = require('../src/services/totp');

function base32Encode(buf) {
  const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const byte of buf) bits += byte.toString(2).padStart(8, '0');
  let out = '';
  for (let i = 0; i + 5 <= bits.length; i += 5) out += ALPHABET[parseInt(bits.slice(i, i + 5), 2)];
  const rem = bits.length % 5;
  if (rem) out += ALPHABET[parseInt(bits.slice(-rem).padEnd(5, '0'), 2)];
  return out;
}

const RFC_SECRET_B32 = base32Encode(Buffer.from('12345678901234567890', 'ascii'));

const VECTORS = [
  { time: 59, expected8: '94287082' },
  { time: 1111111109, expected8: '07081804' },
  { time: 1111111111, expected8: '14050471' },
  { time: 1234567890, expected8: '89005924' },
  { time: 2000000000, expected8: '69279037' },
];

test('generateTotp matches every RFC 6238 Appendix B test vector', () => {
  for (const v of VECTORS) {
    const expected6 = v.expected8.slice(-6);
    const actual = generateTotp({ secret: RFC_SECRET_B32, timestamp: v.time * 1000, digits: 6 });
    assert.equal(actual, expected6, `mismatch at t=${v.time}`);
  }
});

test('generateTotp is stable within the same 30s window and changes across windows', () => {
  const a = generateTotp({ secret: RFC_SECRET_B32, timestamp: 1000 * 30 });
  const b = generateTotp({ secret: RFC_SECRET_B32, timestamp: 1000 * 30 + 5000 }); // same window
  const c = generateTotp({ secret: RFC_SECRET_B32, timestamp: 1000 * 61 }); // next window
  assert.equal(a, b);
  assert.notEqual(a, c);
});

test('generateTotp always returns a 6-digit zero-padded string', () => {
  for (let t = 0; t < 5; t += 1) {
    const code = generateTotp({ secret: RFC_SECRET_B32, timestamp: t * 30000 });
    assert.match(code, /^\d{6}$/);
  }
});
