// This exact suite was run standalone in this session before being
// committed here — see PROGRESS.md for that run's real output. It uses
// only Node built-ins (worker_threads, vm), so `npm test` will run it
// exactly as-is with no dependency installation required.

const test = require('node:test');
const assert = require('node:assert/strict');
const { runStrategy } = require('../src/services/strategyExecutor');

test('normal execution returns a normalized signal using an indicator', async () => {
  const result = await runStrategy({
    code: 'function strategy({ market, indicators }) { const avg = indicators.sma(market.history, 3); return market.price > avg ? "BUY" : "HOLD"; }',
    context: { market: { price: 105, history: [100, 101, 102] }, position: { quantity: 0, avgPrice: 0 } },
  });
  assert.deepEqual(result.signal, { action: 'BUY' });
  assert.equal(result.error, null);
});

test('an infinite loop is killed by the hard timeout, not left to hang', async () => {
  const start = Date.now();
  const result = await runStrategy({
    code: 'function strategy() { while(true) {} }',
    context: { market: { price: 1, history: [1] }, position: {} },
    timeoutMs: 500,
  });
  const elapsed = Date.now() - start;
  assert.equal(result.signal.reason, 'EXECUTION_TIMEOUT');
  assert.ok(elapsed < 2000, `expected termination well under 2s, took ${elapsed}ms`);
});

test('a thrown error inside strategy code is isolated, not propagated as a rejection', async () => {
  const result = await runStrategy({
    code: 'function strategy() { throw new Error("boom"); }',
    context: { market: {}, position: {} },
  });
  assert.equal(result.signal.action, 'HOLD');
  assert.equal(result.signal.reason, 'EXECUTION_ERROR');
  assert.equal(result.error, 'boom');
});

test('an unrecognized return value normalizes to HOLD rather than propagating garbage', async () => {
  const result = await runStrategy({
    code: 'function strategy() { return "NOT_A_REAL_ACTION"; }',
    context: { market: {}, position: {} },
  });
  assert.deepEqual(result.signal, { action: 'HOLD', reason: 'UNRECOGNIZED_RETURN_VALUE' });
});

test('the sandbox has no require/process access (hang/crash isolation, not a claimed security boundary)', async () => {
  const result = await runStrategy({
    code: 'function strategy() { return (typeof require === "undefined" && typeof process === "undefined") ? "EXIT" : "BUY"; }',
    context: { market: {}, position: {} },
  });
  assert.equal(result.signal.action, 'EXIT');
});
