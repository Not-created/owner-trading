process.env.CREDENTIAL_ENCRYPTION_KEY = require('node:crypto').randomBytes(32).toString('hex');

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const config = require('../src/config/env');
const { getDb, closeDb } = require('../src/db/connection');
const { ensureAdminBootstrap } = require('../src/services/adminBootstrap');
const tradingStateService = require('../src/services/tradingStateService');
const app = require('../server');

function extractCookie(setCookieHeaders, name) {
  if (!setCookieHeaders) return null;
  const match = setCookieHeaders.find((c) => c.startsWith(`${name}=`));
  return match ? match.split(';')[0] : null;
}

function resetDatabaseFile() {
  closeDb();
  for (const suffix of ['', '-wal', '-shm', '-journal']) {
    const p = config.databasePath + suffix;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

async function loginAndCompleteChange(base, username, tempPassword) {
  const loginRes = await fetch(`${base}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password: tempPassword }),
  });
  let cookie = extractCookie(loginRes.headers.getSetCookie(), 'ot_session');

  const changeRes = await fetch(`${base}/auth/change-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ currentPassword: tempPassword, newPassword: 'a-new-strong-password-123' }),
  });
  cookie = extractCookie(changeRes.headers.getSetCookie(), 'ot_session');
  return cookie;
}

test('Trading state: safe defaults, explicit live-enable rules, emergency stop', async (t) => {
  resetDatabaseFile();
  const db = getDb();
  const { username, password: tempPassword } = ensureAdminBootstrap(db);

  const server = app.listen(0);
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}/api`;
  const cookie = await loginAndCompleteChange(base, username, tempPassword);

  await t.test('default state is PAPER, live disabled, no emergency stop', async () => {
    const res = await fetch(`${base}/trading/state`, { headers: { Cookie: cookie } });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.tradingMode, 'PAPER');
    assert.equal(body.liveEnabled, false);
    assert.equal(body.emergencyStop, false);
  });

  await t.test('cannot enable live while still in PAPER mode', async () => {
    const res = await fetch(`${base}/trading/live-enable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ confirm: true }),
    });
    const body = await res.json();
    assert.equal(res.status, 409);
    assert.equal(body.error, 'MODE_NOT_LIVE');
  });

  await t.test('live-enable requires explicit confirm:true even in LIVE mode', async () => {
    await fetch(`${base}/trading/mode`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ mode: 'LIVE' }),
    });

    const res = await fetch(`${base}/trading/live-enable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({}), // no confirm
    });
    const body = await res.json();
    assert.equal(res.status, 400);
    assert.equal(body.error, 'CONFIRMATION_REQUIRED');
  });

  await t.test('live-enable succeeds with mode=LIVE and confirm:true', async () => {
    const res = await fetch(`${base}/trading/live-enable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ confirm: true }),
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.liveEnabled, true);
  });

  await t.test('emergency stop immediately forces live_enabled back to false', async () => {
    const res = await fetch(`${base}/trading/emergency-stop`, {
      method: 'POST',
      headers: { Cookie: cookie },
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.emergencyStop, true);
    assert.equal(body.liveEnabled, false);
  });

  await t.test('live-enable is refused while emergency stop is active', async () => {
    const res = await fetch(`${base}/trading/live-enable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ confirm: true }),
    });
    const body = await res.json();
    assert.equal(res.status, 409);
    assert.equal(body.error, 'EMERGENCY_STOP_ACTIVE');
  });

  await t.test('clearing emergency stop does NOT restore live_enabled by itself', async () => {
    const res = await fetch(`${base}/trading/emergency-stop/clear`, {
      method: 'POST',
      headers: { Cookie: cookie },
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.emergencyStop, false);
    assert.equal(body.liveEnabled, false, 'live must stay off until explicitly re-enabled');
  });

  await t.test('isLiveOrderAllowed() is false in every state except mode=LIVE + enabled + no stop', () => {
    assert.equal(tradingStateService.isLiveOrderAllowed(db), false);
    tradingStateService.enableLive(db, 1);
    assert.equal(tradingStateService.isLiveOrderAllowed(db), true);
    tradingStateService.triggerEmergencyStop(db, 1);
    assert.equal(tradingStateService.isLiveOrderAllowed(db), false);
  });

  server.close();
  resetDatabaseFile();
});

test('Startup safety: forceLiveDisabledOnStartup forces live off regardless of persisted state', () => {
  resetDatabaseFile();
  const db = getDb();
  ensureAdminBootstrap(db);

  tradingStateService.setMode(db, 'LIVE');
  tradingStateService.enableLive(db, 1);
  assert.equal(tradingStateService.getState(db).live_enabled, 1);

  const hadToReset = tradingStateService.forceLiveDisabledOnStartup(db);
  assert.equal(hadToReset, true);
  assert.equal(tradingStateService.getState(db).live_enabled, 0);

  // Calling it again when already off correctly reports no change was needed.
  const secondCall = tradingStateService.forceLiveDisabledOnStartup(db);
  assert.equal(secondCall, false);

  resetDatabaseFile();
});
