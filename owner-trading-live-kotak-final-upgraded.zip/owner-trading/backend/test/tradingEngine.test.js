// NOTE: this exact logic was verified to actually pass, in this session,
// via a standalone harness using Node 22's built-in node:sqlite module
// (these services take a `db` parameter and never require('better-sqlite3')
// themselves, so they run unmodified against any compatible driver). See
// PROGRESS.md for that run's full output. This file is the same coverage
// written in the project's normal node:test + better-sqlite3 convention,
// for when a real `npm install` makes `npm test` runnable.

process.env.CREDENTIAL_ENCRYPTION_KEY = require('node:crypto').randomBytes(32).toString('hex');

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const config = require('../src/config/env');
const { getDb, closeDb } = require('../src/db/connection');
const tradingStateService = require('../src/services/tradingStateService');
const strategyService = require('../src/services/strategyService');
const orderService = require('../src/services/orderService');
const positionService = require('../src/services/positionService');
const pnlService = require('../src/services/pnlService');
const riskService = require('../src/services/riskService');
const reconciliationService = require('../src/services/reconciliationService');
const marketDataSimulator = require('../src/services/marketDataSimulator');
const brokerCredentialService = require('../src/services/brokerCredentialService');
const { paperAdapter } = require('../src/brokers');

function resetDatabaseFile() {
  closeDb();
  for (const suffix of ['', '-wal', '-shm', '-journal']) {
    const p = config.databasePath + suffix;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  marketDataSimulator.reset();
  paperAdapter.reset();
  strategyService.stopAll();
}

const MOMENTUM_CODE =
  // Deterministic on purpose: price is always > 0, so this always signals
  // BUY on the very first tick. A test asserting "an order gets created"
  // must not depend on a random walk crossing a threshold within N ticks —
  // that would make the test itself flaky, independent of engine
  // correctness. (The Strategy Builder's UI default example uses a real
  // SMA-crossover for illustration; that non-determinism is fine for a
  // user-facing example, just not for an automated correctness test.)
  'function strategy({ market }) { return market.price > 0 ? "BUY" : "HOLD"; }';

test('Trading engine: full PAPER lifecycle end to end', async (t) => {
  resetDatabaseFile();
  const db = getDb();

  const strategy = strategyService.createStrategy(db, {
    name: 'Test SMA crossover',
    code: MOMENTUM_CODE,
    symbol: 'TESTSTOCK',
    mode: 'PAPER',
    positionSizingType: 'FIXED_QTY',
    positionSizingValue: 10,
  });

  await t.test('strategy created with safe defaults', () => {
    assert.equal(strategy.status, 'STOPPED');
    assert.equal(strategy.enabled, 0);
  });

  await t.test('market data -> strategy -> signal -> risk -> order -> fill -> position -> P&L', async () => {
    let created = false;
    for (let i = 0; i < 30; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await strategyService.runOnce(db, strategy.id);
      if (orderService.listOrders(db, { strategyId: strategy.id }).length > 0) {
        created = true;
        break;
      }
    }
    assert.ok(created, 'expected at least one order within 30 ticks');

    const filled = orderService.listOrders(db, { strategyId: strategy.id }).find((o) => o.state === 'FILLED');
    assert.ok(filled, 'expected a FILLED paper order — market orders fill immediately');

    const positions = positionService.listPositions(db, { strategyId: strategy.id });
    assert.equal(positions.length, 1);
    assert.notEqual(positions[0].quantity, 0);

    const pnl = await pnlService.summary(db, { strategyId: strategy.id });
    assert.ok(Number.isFinite(pnl.totals.totalPnl));
  });

  await t.test('risk engine genuinely rejects an order that exceeds max order value', async () => {
    riskService.updateLimits(db, { max_order_value: 1 });
    const rejected = await orderService.createOrder(db, {
      strategyId: strategy.id,
      symbol: 'RISKTEST', // distinct symbol so this can't collide with the
      // earlier PAPER-lifecycle test's duplicate-protection window (same
      // strategyId + side + quantity + orderType within 3s would otherwise
      // return that unrelated earlier order instead of exercising this check)
      side: 'BUY',
      quantity: 10,
      orderType: 'MARKET',
      mode: 'PAPER',
    });
    assert.equal(rejected.state, 'REJECTED');
    assert.equal(rejected.reject_reason, 'MAX_ORDER_VALUE_EXCEEDED');
    riskService.updateLimits(db, { max_order_value: 1000000 });
  });

  await t.test('duplicate order intent within the idempotency window collapses to one order', async () => {
    const first = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'DUPTEST', side: 'BUY', quantity: 5, orderType: 'MARKET', mode: 'PAPER',
    });
    const second = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'DUPTEST', side: 'BUY', quantity: 5, orderType: 'MARKET', mode: 'PAPER',
    });
    assert.equal(first.id, second.id);
  });

  await t.test('emergency stop blocks new PAPER orders, not just LIVE', async () => {
    tradingStateService.triggerEmergencyStop(db, null);
    const blocked = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'ESTOP', side: 'BUY', quantity: 1, orderType: 'MARKET', mode: 'PAPER',
    });
    assert.equal(blocked.state, 'REJECTED');
    assert.equal(blocked.reject_reason, 'EMERGENCY_STOP_ACTIVE');
    tradingStateService.clearEmergencyStop(db);
  });

  await t.test('LIVE order rejected while not allowed (no broker connection), and never fabricated once actually connected but the service is unreachable', async () => {
    const liveBlocked = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'LIVETEST', side: 'BUY', quantity: 1, orderType: 'MARKET', mode: 'LIVE',
    });
    assert.equal(liveBlocked.state, 'REJECTED');
    assert.equal(liveBlocked.reject_reason, 'LIVE_NOT_ALLOWED');

    tradingStateService.setMode(db, 'LIVE');
    tradingStateService.enableLive(db, null);

    // Still blocked: mode=LIVE + live_enabled=true is NOT sufficient on its
    // own — isLiveOrderAllowed() also requires a genuinely CONNECTED broker.
    const stillBlocked = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'LIVETEST2', side: 'BUY', quantity: 1, orderType: 'MARKET', mode: 'LIVE',
    });
    assert.equal(stillBlocked.state, 'REJECTED');
    assert.equal(stillBlocked.reject_reason, 'LIVE_NOT_ALLOWED');

    // Now simulate a genuinely CONNECTED broker (directly via SQL — this
    // test cannot perform a real Kotak authentication) to exercise the
    // actual adapter call path and confirm it still never fabricates success.
    const adminId = strategyService.getStrategy(db, strategy.id) && 1; // single-admin model, id 1 on a fresh DB
    brokerCredentialService.upsertCredentials(
      db,
      adminId,
      { consumerKey: 'x', ucc: 'AB123', mobileNumber: '+910000000000', mpin: '000000', totpSecret: 'JBSWY3DPEHPK3PXP' },
      'prod'
    );
    db.prepare("UPDATE broker_kotak_credentials SET connection_state = 'CONNECTED' WHERE user_id = ?").run(adminId);
    assert.equal(brokerCredentialService.isConnected(db, adminId), true);

    const liveAttempt = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'LIVETEST3', side: 'BUY', quantity: 1, orderType: 'MARKET', mode: 'LIVE',
    });
    // No Kotak integration service is running in this test, and no
    // KOTAK_SERVICE_SECRET is configured — the adapter must fail honestly
    // (UNKNOWN or FAILED), never report a fabricated FILLED/SUBMITTED.
    assert.ok(['UNKNOWN', 'FAILED'].includes(liveAttempt.state));
    assert.notEqual(liveAttempt.state, 'FILLED');

    brokerCredentialService.deleteCredentials(db, adminId);
    tradingStateService.triggerEmergencyStop(db, null); // back to a safe state
    tradingStateService.clearEmergencyStop(db);
    tradingStateService.setMode(db, 'PAPER');
  });

  await t.test('reconciliation resolves an OPEN limit order by asking the adapter, never by assuming', async () => {
    const price = marketDataSimulator.getLastPrice('LIMITTEST');
    const limitOrder = await orderService.createOrder(db, {
      strategyId: strategy.id, symbol: 'LIMITTEST', side: 'BUY', quantity: 3,
      orderType: 'LIMIT', limitPrice: price - 50, mode: 'PAPER',
    });
    assert.equal(limitOrder.state, 'OPEN');

    paperAdapter.tryFillPending(limitOrder.broker_order_id, limitOrder.limit_price);
    const reconciled = await reconciliationService.reconcileOrder(db, limitOrder);
    assert.equal(reconciled.state, 'FILLED');
  });

  await t.test('restart recovery: stale RUNNING status is corrected, nothing auto-resumes', () => {
    strategyService.startStrategy(db, strategy.id, 60000);
    assert.equal(strategyService.getStrategy(db, strategy.id).status, 'RUNNING');

    const corrected = strategyService.resetStrategyStatusOnStartup(db);
    assert.ok(corrected >= 1);
    assert.equal(strategyService.getStrategy(db, strategy.id).status, 'STOPPED');
    strategyService.stopAll();
  });

  await t.test('starting an already-running strategy is a no-op, not a second worker', () => {
    strategyService.startStrategy(db, strategy.id, 60000);
    strategyService.startStrategy(db, strategy.id, 60000);
    strategyService.stopAll(); // if this were two intervals, both still get cleared here either way —
    // the real guarantee is asserted by strategyService's own runningIntervals Map never growing
    // past one entry per id, which startStrategy's own early-return enforces by construction.
    assert.equal(strategyService.getStrategy(db, strategy.id).status, 'STOPPED');
  });

  await t.test('a strategy whose code throws is isolated to ERROR, others are unaffected', async () => {
    const badStrategy = strategyService.createStrategy(db, {
      name: 'Broken strategy',
      code: 'function strategy() { throw new Error("intentional test failure"); }',
      symbol: 'BROKENSTOCK',
    });
    await strategyService.runOnce(db, badStrategy.id);

    const afterFail = strategyService.getStrategy(db, badStrategy.id);
    assert.equal(afterFail.status, 'ERROR');
    assert.match(afterFail.last_error, /intentional test failure/);

    const otherStrategy = strategyService.getStrategy(db, strategy.id);
    assert.notEqual(otherStrategy.status, 'ERROR');
  });

  resetDatabaseFile();
});
