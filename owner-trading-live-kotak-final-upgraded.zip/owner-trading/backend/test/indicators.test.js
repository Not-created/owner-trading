const test = require('node:test');
const assert = require('node:assert/strict');
const { sma, ema, rsi } = require('../src/services/indicators');

test('sma() computes a simple moving average over the trailing period', () => {
  assert.equal(sma([1, 2, 3, 4, 5], 5), 3);
  assert.equal(sma([10, 20, 30], 2), 25);
  assert.equal(sma([1, 2], 5), null, 'insufficient history returns null, not garbage');
});

test('ema() weights recent values more heavily than sma()', () => {
  const history = [1, 1, 1, 1, 10]; // a late spike
  const smaVal = sma(history, 5);
  const emaVal = ema(history, 5);
  assert.ok(emaVal > smaVal, 'EMA should react more to the recent spike than SMA');
});

test('rsi() returns 100 for an all-gains series and null with insufficient history', () => {
  const allGains = Array.from({ length: 20 }, (_, i) => 100 + i);
  assert.equal(rsi(allGains, 14), 100);
  assert.equal(rsi([1, 2, 3], 14), null);
});
