// SQLite connection module.
//
// Design intent for this foundation checkpoint:
// - Single shared connection (better-sqlite3 is synchronous and safe to
//   share within one Node process for an app this size).
// - WAL mode for reasonable concurrent read/write behavior.
// - Idempotent schema application via schema.sql + schema_meta table, so
//   restarting the server never fails on "table already exists".
// - No feature-specific tables here — see schema.sql comment.

const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');
const config = require('../config/env');

const CURRENT_SCHEMA_VERSION = 1;

let db = null;

function ensureDataDirExists() {
  const dir = path.dirname(config.databasePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function applyFoundationSchema(connection) {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');
  connection.exec(schemaSql);

  const existing = connection
    .prepare('SELECT schema_version FROM schema_meta WHERE id = 1')
    .get();

  if (!existing) {
    connection
      .prepare('INSERT INTO schema_meta (id, schema_version) VALUES (1, ?)')
      .run(CURRENT_SCHEMA_VERSION);
  }
}

function getAppliedVersion(connection) {
  const row = connection.prepare('SELECT schema_version FROM schema_meta WHERE id = 1').get();
  return row ? row.schema_version : 0;
}

function setAppliedVersion(connection, version) {
  connection
    .prepare(
      "UPDATE schema_meta SET schema_version = ?, applied_at = datetime('now') WHERE id = 1"
    )
    .run(version);
}

// Applies backend/src/db/migrations/*.sql in numeric filename order
// (e.g. 002_add_auth_tables.sql), skipping any file whose leading number is
// <= the already-applied schema_version. Each migration runs in its own
// transaction so a mid-migration failure never leaves schema_meta pointing
// past a half-applied migration.
function applyMigrations(connection) {
  const migrationsDir = path.join(__dirname, 'migrations');
  if (!fs.existsSync(migrationsDir)) return;

  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  for (const file of files) {
    const match = file.match(/^(\d+)_/);
    if (!match) continue;

    const version = Number(match[1]);
    const currentVersion = getAppliedVersion(connection);
    if (version <= currentVersion) continue;

    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    const applyTx = connection.transaction(() => {
      connection.exec(sql);
      setAppliedVersion(connection, version);
    });
    applyTx();
  }
}

function getDb() {
  if (db) return db;

  ensureDataDirExists();
  db = new Database(config.databasePath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  applyFoundationSchema(db);
  applyMigrations(db);

  return db;
}

function closeDb() {
  if (db) {
    db.close();
    db = null;
  }
}

module.exports = { getDb, closeDb, CURRENT_SCHEMA_VERSION };
