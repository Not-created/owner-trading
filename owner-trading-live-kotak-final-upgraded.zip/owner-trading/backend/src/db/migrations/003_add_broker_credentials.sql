-- Migration 003: Kotak Neo broker credential storage.
--
-- Field set (consumerKey, ucc, mobileNumber, mpin, totpSecret) matches the
-- current officially-maintained `kotakneoapi` Python SDK's own login
-- sample (totp_login(mobile_number, ucc, totp) + totp_validate(mpin)) as
-- of the checkpoint that introduced this table. `totpSecret` here is the
-- 20-25 character TOTP *seed* issued once during TOTP registration — NOT
-- the rotating 6-digit code, which is generated on demand, not stored.
--
-- Storing this seed lets the backend generate valid TOTP codes for
-- unattended/automated login. This table only stores the credentials;
-- generating codes and calling Kotak's actual endpoints is explicitly
-- deferred to the Kotak API verification checkpoint — this migration does
-- not imply that integration has been verified.
--
-- One row per user (single-admin model today; user_id keeps this correct
-- if multi-user is ever added later). Secrets are encrypted at rest with
-- AES-256-GCM (see src/services/encryption.js) — this table never holds
-- plaintext.

CREATE TABLE IF NOT EXISTS broker_kotak_credentials (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  environment TEXT NOT NULL DEFAULT 'prod',
  encrypted_payload TEXT NOT NULL,
  iv TEXT NOT NULL,
  auth_tag TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
