-- Migration 008: replace obsolete Kotak v2 strategy choices with current v3 values.
-- Existing rows are preserved; only the CHECK constraints are rebuilt.
PRAGMA foreign_keys=OFF;
CREATE TABLE strategies_new (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  symbol TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'PAPER' CHECK (mode IN ('PAPER', 'LIVE')),
  enabled INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'STOPPED' CHECK (status IN ('STOPPED', 'RUNNING', 'ERROR')),
  position_sizing_type TEXT NOT NULL DEFAULT 'FIXED_QTY' CHECK (position_sizing_type IN ('FIXED_QTY', 'FIXED_VALUE')),
  position_sizing_value REAL NOT NULL DEFAULT 1,
  stop_loss_percent REAL,
  target_percent REAL,
  last_error TEXT,
  last_run_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  exchange_segment TEXT NOT NULL DEFAULT 'nse_cm' CHECK (exchange_segment IN ('nse_cm','bse_cm','nse_fo','bse_fo','mcx_fo')),
  product TEXT NOT NULL DEFAULT 'MIS' CHECK (product IN ('NRML','CNC','MIS','MTF'))
);
INSERT INTO strategies_new SELECT id,name,code,symbol,mode,enabled,status,position_sizing_type,position_sizing_value,stop_loss_percent,target_percent,last_error,last_run_at,created_at,updated_at,
  CASE WHEN exchange_segment='cde_fo' THEN 'nse_cm' ELSE exchange_segment END,
  CASE WHEN product IN ('CO','BO') THEN 'MIS' ELSE product END FROM strategies;
DROP TABLE strategies;
ALTER TABLE strategies_new RENAME TO strategies;
CREATE INDEX IF NOT EXISTS idx_strategies_status ON strategies(status);
PRAGMA foreign_keys=ON;
