-- Migration 007: exchange segment / product fields for current Kotak Neo v3 routing.
ALTER TABLE strategies ADD COLUMN exchange_segment TEXT NOT NULL DEFAULT 'nse_cm'
  CHECK (exchange_segment IN ('nse_cm','bse_cm','nse_fo','bse_fo','mcx_fo'));
ALTER TABLE strategies ADD COLUMN product TEXT NOT NULL DEFAULT 'MIS'
  CHECK (product IN ('NRML','CNC','MIS','MTF'));
