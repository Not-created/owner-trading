-- Migration 006: real broker connection lifecycle state.
--
-- Distinct from "configured" (credentials exist, encrypted at rest —
-- migration 003). This tracks whether those credentials have actually
-- been used to establish a verified, working Kotak session.
--
-- DISCONNECTED    - no active session (initial state, or after logout/restart)
-- VERIFYING       - an authenticate attempt is in flight
-- CONNECTED       - authenticated AND verified with a real read-only call
-- AUTH_FAILED      - the last authenticate attempt was rejected by Kotak
-- SESSION_EXPIRED  - a previously-working session stopped working
-- CONNECTION_ERROR - could not even reach the Kotak integration service
-- DISCONNECTING    - a disconnect/logout is in flight

ALTER TABLE broker_kotak_credentials ADD COLUMN connection_state TEXT NOT NULL DEFAULT 'DISCONNECTED'
  CHECK (connection_state IN (
    'DISCONNECTED', 'VERIFYING', 'CONNECTED', 'AUTH_FAILED',
    'SESSION_EXPIRED', 'CONNECTION_ERROR', 'DISCONNECTING'
  ));
ALTER TABLE broker_kotak_credentials ADD COLUMN last_verified_at TEXT;
ALTER TABLE broker_kotak_credentials ADD COLUMN last_error_code TEXT;
ALTER TABLE broker_kotak_credentials ADD COLUMN last_error_message TEXT;
