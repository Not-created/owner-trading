-- Migration 009: immutable broker fill ledger for real partial-fill reconciliation.
CREATE TABLE IF NOT EXISTS order_fills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  broker_fill_id TEXT NOT NULL,
  broker_order_id TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  price REAL NOT NULL CHECK(price >= 0),
  exchange_order_id TEXT,
  fill_time TEXT,
  created_at TEXT NOT NULL DEFAULT(datetime('now')),
  UNIQUE(order_id, broker_fill_id)
);
CREATE INDEX IF NOT EXISTS idx_order_fills_order ON order_fills(order_id);
