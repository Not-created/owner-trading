-- Migration 004: global trading state.
--
-- Single row (id=1) holding the app-wide trading mode and safety gates.
-- Deliberately separate from any per-strategy state (which doesn't exist
-- yet) because these are GLOBAL safety controls that must be able to
-- override every strategy at once (emergency stop) regardless of how many
-- strategies exist later.
--
-- trading_mode: which mode strategies currently target (PAPER or LIVE).
-- live_enabled: a SEPARATE explicit safety gate. Setting trading_mode to
--   LIVE does NOT by itself allow live orders — live_enabled must also be
--   true. This is enforced in application code
--   (tradingStateService.isLiveOrderAllowed), not just here.
-- emergency_stop: global kill switch. When true, live_enabled is forced
--   false and stays false until emergency_stop is explicitly cleared AND
--   live is explicitly re-enabled again (two separate actions).

CREATE TABLE IF NOT EXISTS trading_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  trading_mode TEXT NOT NULL DEFAULT 'PAPER' CHECK (trading_mode IN ('PAPER', 'LIVE')),
  live_enabled INTEGER NOT NULL DEFAULT 0,
  emergency_stop INTEGER NOT NULL DEFAULT 0,
  live_enabled_at TEXT,
  live_enabled_by INTEGER REFERENCES users(id),
  emergency_stop_at TEXT,
  emergency_stop_by INTEGER REFERENCES users(id),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO trading_state (id, trading_mode, live_enabled, emergency_stop)
SELECT 1, 'PAPER', 0, 0
WHERE NOT EXISTS (SELECT 1 FROM trading_state WHERE id = 1);
