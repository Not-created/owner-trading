-- Owner Trading — foundation schema.
-- This checkpoint intentionally creates only a schema_meta table to prove
-- that the SQLite connection, file creation, and migration pattern work
-- end-to-end. Feature-specific tables (users, strategies, orders, etc.)
-- are added in their own dedicated feature checkpoints, each with its own
-- migration file, so schema changes stay reviewable one feature at a time.

CREATE TABLE IF NOT EXISTS schema_meta (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  schema_version INTEGER NOT NULL,
  applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);
