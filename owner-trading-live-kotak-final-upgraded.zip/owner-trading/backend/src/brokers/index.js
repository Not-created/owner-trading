const { PaperBrokerAdapter } = require('./paperBrokerAdapter');
const { KotakBrokerAdapter } = require('./kotakBrokerAdapter');

const paperAdapter = new PaperBrokerAdapter();
const kotakAdapter = new KotakBrokerAdapter();

// mode here is the ORDER's mode (validated already), not the global
// trading_state mode — orderService is responsible for ensuring a LIVE
// order is only ever created when tradingStateService.isLiveOrderAllowed()
// is true. This function just routes to the right adapter.
function getAdapter(mode) {
  if (mode === 'LIVE') return kotakAdapter;
  return paperAdapter;
}

module.exports = { getAdapter, paperAdapter, kotakAdapter };
