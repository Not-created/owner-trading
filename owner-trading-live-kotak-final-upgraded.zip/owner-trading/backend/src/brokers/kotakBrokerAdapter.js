// Real Kotak Neo adapter via the official current kotakneoapi v3 Python SDK.
// Symbol resolution is performed by Kotak's official search_scrip() API; no
// instrument tokens are guessed or hard-coded.
const { BrokerAdapter } = require('./brokerAdapter');
const config = require('../config/env');
const { getDb } = require('../db/connection');
const brokerCredentialService = require('../services/brokerCredentialService');
const { generateTotp } = require('../services/totp');
const { getAdminUserId } = require('../services/adminBootstrap');

async function callService(path, body) {
  if (!config.kotakServiceSecret) { const e = new Error('KOTAK_SERVICE_SECRET is not configured'); e.code='KOTAK_SERVICE_UNAVAILABLE'; throw e; }
  let res;
  try { res = await fetch(`${config.kotakServiceUrl}${path}`, { method:'POST', headers:{'Content-Type':'application/json','X-Internal-Secret':config.kotakServiceSecret}, body:JSON.stringify(body), signal:AbortSignal.timeout(15000) }); }
  catch (err) { const e=new Error(`Could not reach Kotak integration service: ${err.message}`); e.code='KOTAK_SERVICE_UNAVAILABLE'; throw e; }
  let payload; try { payload=await res.json(); } catch { const e=new Error('Kotak integration service returned non-JSON'); e.code='KOTAK_SERVICE_UNAVAILABLE'; throw e; }
  if (!res.ok || payload.success === false) { const e=new Error(payload.errorMessage || `Kotak service error (${res.status})`); e.code=payload.errorCode || 'BROKER_ERROR'; throw e; }
  return payload.data !== undefined ? payload.data : payload;
}
function getStoredCredentials(db) {
  const userId=getAdminUserId(db); if (!userId) { const e=new Error('No admin account exists'); e.code='NOT_CONFIGURED'; throw e; }
  const raw=brokerCredentialService.getRawCredentials(db,userId); if (!raw) { const e=new Error('Kotak credentials are not configured'); e.code='NOT_CONFIGURED'; throw e; }
  return {userId,...raw};
}
function normalizeQuote(data, symbol) {
  const root = data && data.quote !== undefined ? data.quote : data;
  const item = Array.isArray(root) ? root[0] : (root && Array.isArray(root.data) ? root.data[0] : root);
  if (!item) throw Object.assign(new Error('Kotak quote returned no data'), {code:'QUOTE_UNAVAILABLE'});
  const n=(...keys)=>{for(const k of keys){if(item[k]!==undefined&&item[k]!==null&&item[k]!==''&&!Number.isNaN(Number(item[k])))return Number(item[k]);}return null;};
  const ltp=n('ltp','last_traded_price','lastTradedPrice','lastTradedPriceValue','l');
  if (!(ltp>0)) throw Object.assign(new Error('Kotak quote did not contain a valid LTP'),{code:'QUOTE_UNAVAILABLE'});
  return {symbol:data.symbol||symbol,ltp,bid:n('bid','best_bid','buyPrice','bp'),ask:n('ask','best_ask','sellPrice','sp'),volume:n('volume','vol','tradedVolume'),timestamp:new Date().toISOString(),exchange:data.meta?.exchangeSegment||null};
}
function normalizeOrderData(data) {
  const item=Array.isArray(data)?data[0]:data;
  if (!item) return null;
  return item;
}
function mapStatus(raw) {
  const s=String(raw||'').toLowerCase();
  if (['complete','completed','traded','filled'].includes(s)) return 'FILLED';
  if (['open','open pending','pending','trigger pending','validation pending'].includes(s)) return 'OPEN';
  if (s.includes('partial')) return 'PARTIALLY_FILLED';
  if (['rejected','reject'].includes(s)) return 'REJECTED';
  if (['cancelled','canceled','cancel'].includes(s)) return 'CANCELLED';
  return 'UNKNOWN';
}
class KotakBrokerAdapter extends BrokerAdapter {
  get name(){return 'kotak-neo';}
  async authenticateCandidate(fields, environment='prod') {
    try {
      const result=await callService('/authenticate',{consumerKey:fields.consumerKey,mobileNumber:fields.mobileNumber,ucc:fields.ucc,totp:generateTotp({secret:fields.totpSecret}),mpin:fields.mpin,environment});
      return {success:true,ucc:result.ucc};
    } catch(err) { return {success:false,errorCode:err.code,errorMessage:err.message}; }
  }
  async authenticate(){
    const db=getDb(); const {userId,fields,environment}=getStoredCredentials(db);
    brokerCredentialService.setConnectionState(db,userId,'VERIFYING');
    const result=await this.authenticateCandidate(fields,environment);
    if(result.success) brokerCredentialService.setConnectionState(db,userId,'CONNECTED');
    else brokerCredentialService.setConnectionState(db,userId,result.errorCode==='KOTAK_SERVICE_UNAVAILABLE'?'CONNECTION_ERROR':'AUTH_FAILED',{errorCode:result.errorCode,errorMessage:result.errorMessage});
    return result;
  }
  async logout(){const db=getDb();const {userId,fields}=getStoredCredentials(db);brokerCredentialService.setConnectionState(db,userId,'DISCONNECTING');try{await callService('/logout',{ucc:fields.ucc});}finally{brokerCredentialService.setConnectionState(db,userId,'DISCONNECTED');}}
  async placeOrder({clientOrderId,symbol,side,quantity,orderType,limitPrice,exchangeSegment,product}){
    const db=getDb();const {userId,fields}=getStoredCredentials(db);if(!brokerCredentialService.isConnected(db,userId)){const e=new Error('Kotak is not connected');e.code='NOT_CONNECTED';throw e;}
    try {
      const data=await callService('/place-order',{ucc:fields.ucc,order:{exchangeSegment:exchangeSegment||'nse_cm',product:product||'MIS',price:orderType==='LIMIT'?limitPrice:0,orderType:orderType==='LIMIT'?'L':'MKT',quantity,validity:'DAY',tradingSymbol:symbol,transactionType:side==='BUY'?'B':'S',tag:clientOrderId}});
      const item=normalizeOrderData(data); const brokerOrderId=item?.nOrdNo||item?.order_id||item?.orderId;
      if(!brokerOrderId){const e=new Error('Kotak accepted response did not contain a broker order ID');e.code='BROKER_RESPONSE_INVALID';throw e;}
      return {brokerOrderId:String(brokerOrderId),state:'SUBMITTED',filledQuantity:0,avgFillPrice:null};
    }catch(err){if(['SESSION_EXPIRED','INVALID_SESSION'].includes(err.code))brokerCredentialService.setConnectionState(db,userId,'SESSION_EXPIRED',{errorCode:err.code,errorMessage:err.message});throw err;}
  }
  async modifyOrder(brokerOrderId,updates={}){
    const db=getDb();const {userId,fields}=getStoredCredentials(db);if(!brokerCredentialService.isConnected(db,userId)){const e=new Error('Kotak is not connected');e.code='NOT_CONNECTED';throw e;}
    const data=await callService('/modify-order',{ucc:fields.ucc,order:{orderId:brokerOrderId,price:updates.limitPrice ?? 0,orderType:updates.orderType==='LIMIT'?'L':(updates.orderType||'MKT'),quantity:updates.quantity,validity:updates.validity||'DAY',triggerPrice:updates.triggerPrice||0,disclosedQuantity:updates.disclosedQuantity||0,amo:updates.amo||'NO'}});
    const item=normalizeOrderData(data); if(item && !item.nOrdNo && !item.order_id && item.stat && String(item.stat).toLowerCase()!=='ok'){const e=new Error('Kotak modify request was not accepted');e.code='ORDER_MODIFY_REJECTED';throw e;}
    return {state:'OPEN'};
  }
  async cancelOrder(brokerOrderId){const db=getDb();const {userId,fields}=getStoredCredentials(db);const data=await callService('/cancel-order',{ucc:fields.ucc,orderId:brokerOrderId});const item=normalizeOrderData(data)||{};return {state:String(item.stat||'').toLowerCase()==='ok'||item.nOrdNo?'CANCELLED':'UNKNOWN'};}
  async getOrderStatus(brokerOrderId){
    const db=getDb();const {fields}=getStoredCredentials(db);const data=await callService('/order-report',{ucc:fields.ucc,orderId:brokerOrderId});
    const item=normalizeOrderData(data);if(!item)return {state:'UNKNOWN',filledQuantity:0,avgFillPrice:null};
    return {state:mapStatus(item.ordSt||item.order_status),filledQuantity:Number(item.fldQty||item.filled_quantity||0),avgFillPrice:item.avgPrc!==undefined&&item.avgPrc!==''?Number(item.avgPrc):null};
  }
  async reconcileFills(brokerOrderId){const db=getDb();const {fields}=getStoredCredentials(db);const data=await callService('/trade-report',{ucc:fields.ucc});const rows=Array.isArray(data)?data:[];return rows.filter(x=>String(x.nOrdNo||x.order_id||'')===String(brokerOrderId));}
  async getPositions(){const db=getDb();const {fields}=getStoredCredentials(db);const data=await callService('/positions',{ucc:fields.ucc});return Array.isArray(data)?data:[];}
  async getHoldings(){const db=getDb();const {fields}=getStoredCredentials(db);const data=await callService('/holdings',{ucc:fields.ucc});return Array.isArray(data)?data:[];}
  async getLimits(){const db=getDb();const {fields}=getStoredCredentials(db);return callService('/limits',{ucc:fields.ucc});}
  async getQuote(symbol,exchangeSegment='nse_cm'){const db=getDb();const {fields}=getStoredCredentials(db);const data=await callService('/quotes',{ucc:fields.ucc,symbol,exchangeSegment,quoteType:'all'});return normalizeQuote(data,symbol);}
  async resolveSymbol(symbol,exchangeSegment='nse_cm'){const db=getDb();const {fields}=getStoredCredentials(db);return callService('/search-scrip',{ucc:fields.ucc,symbol,exchangeSegment});}
}
module.exports={KotakBrokerAdapter};
