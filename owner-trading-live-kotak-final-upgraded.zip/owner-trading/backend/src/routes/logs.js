const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const executionLogService = require('../services/executionLogService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

router.get('/', (req, res) => {
  const strategyId = req.query.strategyId ? Number(req.query.strategyId) : null;
  const limit = req.query.limit ? Number(req.query.limit) : 200;
  res.json(executionLogService.list(getDb(), { strategyId, limit }));
});

module.exports = router;
