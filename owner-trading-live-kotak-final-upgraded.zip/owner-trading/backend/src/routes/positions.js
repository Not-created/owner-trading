const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const positionService = require('../services/positionService');
const pnlService = require('../services/pnlService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

router.get('/', (req, res) => {
  const mode = req.query.mode || null;
  res.json(positionService.listPositions(getDb(), { mode }));
});

router.get('/pnl', async (req, res) => {
  const mode = req.query.mode || null;
  res.json(await pnlService.summary(getDb(), { mode }));
});

module.exports = router;
