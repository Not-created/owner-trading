const express = require('express');
const bcrypt = require('bcryptjs');

const config = require('../config/env');
const { getDb } = require('../db/connection');
const {
  COOKIE_NAME,
  createSession,
  destroySession,
  destroyAllSessionsForUser,
} = require('../services/sessionService');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const COOKIE_OPTIONS = {
  httpOnly: true,
  sameSite: 'lax',
  secure: config.nodeEnv === 'production' && process.env.COOKIE_SECURE !== 'false',
  path: '/',
};

function setSessionCookie(res, token, expiresAt) {
  res.cookie(COOKIE_NAME, token, { ...COOKIE_OPTIONS, expires: new Date(expiresAt) });
}

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: 'username and password are required' });
  }

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

  // Same error for "no such user" and "wrong password" — do not reveal
  // which one it was.
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'INVALID_CREDENTIALS' });
  }

  const { token, expiresAt } = createSession(db, user.id);
  setSessionCookie(res, token, expiresAt);

  res.json({
    user: { id: user.id, username: user.username },
    mustChangePassword: !!user.must_change_password,
  });
});

// POST /api/auth/logout
router.post('/logout', requireAuth, (req, res) => {
  const db = getDb();
  destroySession(db, req.cookies[COOKIE_NAME]);
  res.clearCookie(COOKIE_NAME, COOKIE_OPTIONS);
  res.json({ success: true });
});

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  res.json({
    user: { id: req.user.userId, username: req.user.username },
    mustChangePassword: req.user.mustChangePassword,
  });
});

// POST /api/auth/change-password
// Reachable even while mustChangePassword=true (that's the whole point of
// the forced-change flow) — only requireAuth guards this route, not
// requirePasswordChangeComplete.
router.post('/change-password', requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'currentPassword and newPassword are required' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'newPassword must be at least 8 characters' });
  }
  if (newPassword === currentPassword) {
    return res.status(400).json({ error: 'newPassword must differ from currentPassword' });
  }

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.userId);

  if (!bcrypt.compareSync(currentPassword, user.password_hash)) {
    return res.status(401).json({ error: 'INVALID_CURRENT_PASSWORD' });
  }

  const newHash = bcrypt.hashSync(newPassword, 10);
  db.prepare(
    "UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = datetime('now') WHERE id = ?"
  ).run(newHash, user.id);

  // Invalidate every existing session for this user (including the one
  // used to make this request) so the old password/session combination
  // cannot continue to be used anywhere, then issue one fresh session.
  destroyAllSessionsForUser(db, user.id);
  const { token, expiresAt } = createSession(db, user.id);
  setSessionCookie(res, token, expiresAt);

  res.json({ success: true, mustChangePassword: false });
});

module.exports = router;
