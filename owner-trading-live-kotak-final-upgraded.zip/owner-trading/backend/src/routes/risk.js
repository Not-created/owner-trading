const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const riskService = require('../services/riskService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

router.get('/', (req, res) => {
  res.json(riskService.getLimits(getDb()));
});

router.put('/', (req, res) => {
  const { maxOrderValue, maxDailyLoss, maxOpenPositions, maxOrdersPerMinute } = req.body || {};

  const updates = {};
  if (maxOrderValue !== undefined) updates.max_order_value = Number(maxOrderValue);
  if (maxDailyLoss !== undefined) updates.max_daily_loss = Number(maxDailyLoss);
  if (maxOpenPositions !== undefined) updates.max_open_positions = Number(maxOpenPositions);
  if (maxOrdersPerMinute !== undefined) updates.max_orders_per_minute = Number(maxOrdersPerMinute);

  const invalid = Object.values(updates).some((v) => !Number.isFinite(v) || v < 0);
  if (invalid) {
    return res.status(400).json({ error: 'INVALID_RISK_LIMIT_VALUE' });
  }

  res.json(riskService.updateLimits(getDb(), updates));
});

module.exports = router;
