const express = require('express');
const { getDb } = require('../db/connection');

const router = express.Router();

// GET /api/health
// Confirms: server is up, and SQLite connection + schema are reachable.
// Deliberately returns no sensitive data.
router.get('/health', (req, res) => {
  let dbStatus = 'unknown';
  let schemaVersion = null;

  try {
    const db = getDb();
    const row = db.prepare('SELECT schema_version FROM schema_meta WHERE id = 1').get();
    schemaVersion = row ? row.schema_version : null;
    dbStatus = 'connected';
  } catch (err) {
    dbStatus = 'error';
  }

  res.json({
    status: 'ok',
    service: 'owner-trading-backend',
    dbStatus,
    schemaVersion,
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
