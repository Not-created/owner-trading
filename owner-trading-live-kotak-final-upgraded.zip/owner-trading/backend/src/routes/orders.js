const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const orderService = require('../services/orderService');
const reconciliationService = require('../services/reconciliationService');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

router.get('/', (req, res) => {
  const strategyId = req.query.strategyId ? Number(req.query.strategyId) : null;
  res.json(orderService.listOrders(getDb(), { strategyId }));
});

router.post('/:id/modify', async (req, res) => {
  try {
    res.json(await orderService.modifyOrder(getDb(), Number(req.params.id), req.body || {}));
  } catch (err) {
    if (['ORDER_NOT_FOUND', 'ORDER_NOT_MODIFIABLE', 'INVALID_ORDER_TYPE', 'INVALID_PRICE', 'INVALID_QUANTITY'].includes(err.code)) {
      return res.status(err.code === 'ORDER_NOT_FOUND' ? 404 : 409).json({ error: err.code, message: err.message });
    }
    throw err;
  }
});

router.post('/:id/cancel', async (req, res) => {
  try {
    res.json(await orderService.cancelOrder(getDb(), Number(req.params.id)));
  } catch (err) {
    if (['ORDER_NOT_FOUND', 'ORDER_NOT_CANCELLABLE'].includes(err.code)) {
      const status = err.code === 'ORDER_NOT_FOUND' ? 404 : 409;
      return res.status(status).json({ error: err.code, message: err.message });
    }
    throw err;
  }
});

// Triggers reconciliation for every order currently in a non-terminal or
// uncertain state (see reconciliationService.NEEDS_RECONCILIATION_STATES).
router.post('/reconcile', async (req, res) => {
  const results = await reconciliationService.reconcileAll(getDb());
  res.json({ reconciled: results.length, orders: results });
});

module.exports = router;
