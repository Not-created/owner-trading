const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const {
  validateFields,
  isValidEnvironment,
  upsertCredentials,
  getMaskedStatus,
  deleteCredentials,
  setConnectionState,
} = require('../services/brokerCredentialService');
const { KotakBrokerAdapter } = require('../brokers/kotakBrokerAdapter');

const router = express.Router();
const kotakAdapter = new KotakBrokerAdapter();

router.use(requireAuth, requirePasswordChangeComplete);

// GET /api/broker/kotak-config — masked status, including real connection
// state (CONNECTED/AUTH_FAILED/etc — never "configured" used as a stand-in
// for "connected"; those are different things).
router.get('/kotak-config', (req, res) => {
  const db = getDb();
  res.json(getMaskedStatus(db, req.user.userId));
});

// PUT /api/broker/kotak-config — SAVE & CONNECT.
// Persists credentials, THEN actually attempts a real Kotak authentication
// (TOTP login -> MPIN validate -> a real read-only verification call) via
// the Kotak integration service. Only reports CONNECTED if that succeeds.
// A save with an authentication failure is not itself an HTTP error — the
// credentials saved correctly; the connection genuinely failed. Both facts
// are returned together so the UI can show exactly what happened.
router.put('/kotak-config', async (req, res) => {
  const { consumerKey, ucc, mobileNumber, mpin, totpSecret, environment } = req.body || {};
  const fields = { consumerKey, ucc, mobileNumber, mpin, totpSecret };

  const missing = validateFields(fields);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'MISSING_FIELDS', missing });
  }
  if (!isValidEnvironment(environment)) {
    return res.status(400).json({ error: 'INVALID_ENVIRONMENT' });
  }

  const db = getDb();
  // Authenticate the candidate first. Failed credentials are NEVER persisted.
  const authResult = await kotakAdapter.authenticateCandidate(fields, environment || 'prod');
  if (!authResult.success) {
    return res.status(401).json({ success: false, authResult, connectionState: authResult.errorCode === 'KOTAK_SERVICE_UNAVAILABLE' ? 'CONNECTION_ERROR' : 'AUTH_FAILED' });
  }
  upsertCredentials(db, req.user.userId, fields, environment);
  setConnectionState(db, req.user.userId, 'CONNECTED');
  res.json({ success: true, authResult, ...getMaskedStatus(db, req.user.userId) });
});

// POST /api/broker/kotak-config/test-connection — TEST CONNECTION.
// Uses whatever credentials are ALREADY stored (does not accept new ones
// in the body) and attempts a real authentication. Never places an order.
router.post('/kotak-config/test-connection', async (req, res) => {
  const db = getDb();
  const current = getMaskedStatus(db, req.user.userId);
  if (!current.configured) {
    return res.status(400).json({ error: 'NOT_CONFIGURED' });
  }

  const authResult = await kotakAdapter.authenticate();
  res.json({ authResult, ...getMaskedStatus(db, req.user.userId) });
});

// DELETE /api/broker/kotak-config — DISCONNECT.
// Best-effort real logout against Kotak if a session exists, then removes
// stored credentials entirely (which itself resets connection_state).
router.delete('/kotak-config', async (req, res) => {
  const db = getDb();
  const current = getMaskedStatus(db, req.user.userId);

  if (current.configured && current.connectionState === 'CONNECTED') {
    await kotakAdapter.logout(); // best-effort — proceeds to delete either way
  }

  deleteCredentials(db, req.user.userId);
  res.json({ success: true, configured: false, connectionState: 'DISCONNECTED' });
});

module.exports = router;
