// Market data routing — the ONLY place that decides "where does a price
// come from". PAPER routes to the synthetic simulator; LIVE routes to the
// real broker adapter's getQuote(). Order/risk code must call
// getReferencePrice() from here, never marketDataSimulator directly —
// that direct-import pattern was a real bug (LIVE risk/order pricing was
// silently using simulated prices) found and fixed during this project's
// audit.

const marketDataSimulator = require('./marketDataSimulator');
const { getAdapter } = require('../brokers');

// Returns a plain number (the price to use for risk sizing / fill logic).
// For LIVE, this makes a real call to the broker adapter — if that fails
// (adapter not implemented, broker unreachable, etc.), it throws rather
// than silently falling back to a simulated number. A LIVE order must
// never be priced or risk-checked against a fake value.
async function getReferencePrice(symbol, mode, exchangeSegment = 'nse_cm') {
  if (mode === 'LIVE') {
    const adapter = getAdapter('LIVE');
    const quote = await adapter.getQuote(symbol, exchangeSegment);
    return quote.ltp;
  }
  return marketDataSimulator.getLastPrice(symbol);
}

// Used by the strategy scheduler, which needs a full tick (advance +
// return) rather than a read-only lookup. LIVE strategies read the real
// quote on each cycle instead of "ticking" a synthetic series.
async function getMarketSnapshot(symbol, mode, exchangeSegment = 'nse_cm') {
  if (mode === 'LIVE') {
    const adapter = getAdapter('LIVE');
    const quote = await adapter.getQuote(symbol, exchangeSegment);
    // No real history buffer exists for LIVE yet (see PROGRESS.md) — a
    // single-point history is honest about that rather than fabricating
    // a trailing series that was never actually observed.
    return { price: quote.ltp, history: [quote.ltp] };
  }
  const price = marketDataSimulator.tick(symbol);
  return { price, history: marketDataSimulator.getHistory(symbol) };
}

module.exports = { getReferencePrice, getMarketSnapshot };
