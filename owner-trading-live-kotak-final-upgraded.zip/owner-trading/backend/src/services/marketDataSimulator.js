// Market data SIMULATOR — synthetic prices only.
//
// This is NOT a connection to any real market data feed. No such
// connection exists in this project (see PROGRESS.md). It exists solely
// so the strategy engine, order pipeline, and PAPER trading flow can be
// built and genuinely tested end-to-end without a live broker connection.
// A real market-data adapter (streaming quotes from Kotak) would replace
// the tick() source here; nothing else in the pipeline would need to
// change, since strategies/orders only ever see { price, history } shapes,
// never this module directly.

const MAX_HISTORY = 200;
const state = new Map(); // symbol -> { price, history: number[] }

function basePriceFor(symbol) {
  // Deterministic per-symbol starting price so repeated runs in tests are
  // stable-ish, without needing a persisted seed table for a simulator.
  let hash = 0;
  for (let i = 0; i < symbol.length; i += 1) {
    hash = (hash * 31 + symbol.charCodeAt(i)) % 100000;
  }
  return 100 + (hash % 900); // somewhere between 100 and 1000
}

function ensureSymbol(symbol) {
  if (!state.has(symbol)) {
    const price = basePriceFor(symbol);
    state.set(symbol, { price, history: [price] });
  }
  return state.get(symbol);
}

// Advances the symbol's synthetic price by one random step and returns the
// new price. Call this once per strategy-execution cycle for a symbol.
function tick(symbol) {
  const s = ensureSymbol(symbol);
  const pctMove = (Math.random() - 0.5) * 0.01; // +/-0.5% per tick
  const next = Math.max(0.05, s.price * (1 + pctMove));
  s.price = Math.round(next * 100) / 100;
  s.history.push(s.price);
  if (s.history.length > MAX_HISTORY) s.history.shift();
  return s.price;
}

function getLastPrice(symbol) {
  return ensureSymbol(symbol).price;
}

function getHistory(symbol) {
  return [...ensureSymbol(symbol).history];
}

// Test/ops utility — resets all synthetic state (in-memory only).
function reset() {
  state.clear();
}

module.exports = { tick, getLastPrice, getHistory, reset };
