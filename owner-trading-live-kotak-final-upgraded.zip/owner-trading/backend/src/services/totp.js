// RFC 6238 TOTP (Time-based One-Time Password) generator.
//
// This generates the CURRENT rotating 6-digit code from a stored TOTP
// seed — it is NOT the seed itself, and the seed is never derivable back
// from a generated code. Used to drive Kotak's `totp_login(totp=...)`
// without a human re-typing an authenticator app's code every session —
// this exact pattern (auto-generating from a stored seed for automated
// use) is acknowledged, if only for local iteration, in the official
// kotakneoapi SDK's own e2e smoke test documentation.
//
// Pure Node `crypto` (HMAC-SHA1) — RFC 6238 / RFC 4226 standard, not
// Kotak-specific. Verified against the official RFC 6238 Appendix B test
// vectors (see totp.test.js) before being wired into any login flow.

const crypto = require('node:crypto');

// Base32 alphabet per RFC 4648 — TOTP seeds are conventionally shared as
// base32 (what an authenticator app's QR code encodes).
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Decode(input) {
  const clean = input.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = '';
  for (const char of clean) {
    const val = BASE32_ALPHABET.indexOf(char);
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

// digits/period/algorithm default to the universal Google-Authenticator-
// compatible values (6 digits, 30s step, SHA1) that Kotak's authenticator-
// app-based TOTP registration uses.
function generateTotp({ secret, digits = 6, period = 30, algorithm = 'sha1', timestamp = Date.now() }) {
  const keyBuffer = /^[A-Z2-7]+=*$/i.test(secret) ? base32Decode(secret) : Buffer.from(secret, 'utf8');

  const counter = Math.floor(timestamp / 1000 / period);
  const counterBuffer = Buffer.alloc(8);
  counterBuffer.writeBigUInt64BE(BigInt(counter));

  const hmac = crypto.createHmac(algorithm, keyBuffer).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binCode =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);

  const code = (binCode % 10 ** digits).toString().padStart(digits, '0');
  return code;
}

module.exports = { generateTotp, base32Decode };
