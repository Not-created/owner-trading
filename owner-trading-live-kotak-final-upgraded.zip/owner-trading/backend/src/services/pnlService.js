// P&L summary. Realized P&L is already accumulated on the positions table
// by positionService as fills happen. Unrealized P&L is computed here, on
// demand, by marking each open position to the current reference price —
// routed through marketDataService so PAPER uses the simulator and LIVE
// attempts a real broker quote (never the simulator — see
// marketDataService.js header for the bug this fixed).

const positionService = require('./positionService');
const marketDataService = require('./marketDataService');

async function referencePriceFor(symbol, mode) {
  try {
    return await marketDataService.getReferencePrice(symbol, mode);
  } catch (err) {
    // Genuinely unavailable (e.g. LIVE adapter not implemented, or a real
    // broker call failed) — return null rather than fabricating a price.
    // Unrealized P&L for this position is correctly "unknown", not zero.
    return null;
  }
}

async function positionWithPnl(position) {
  const refPrice = await referencePriceFor(position.symbol, position.mode);
  const unrealizedPnl = refPrice === null ? null : (refPrice - position.avg_price) * position.quantity;

  return {
    ...position,
    referencePrice: refPrice,
    unrealizedPnl,
  };
}

async function summary(db, { mode = null, strategyId = null } = {}) {
  const rawPositions = positionService.listPositions(db, { mode, strategyId });
  const positions = await Promise.all(rawPositions.map(positionWithPnl));

  const totals = positions.reduce(
    (acc, p) => {
      acc.realizedPnl += p.realized_pnl;
      if (p.unrealizedPnl !== null) acc.unrealizedPnl += p.unrealizedPnl;
      return acc;
    },
    { realizedPnl: 0, unrealizedPnl: 0 }
  );

  return {
    positions,
    totals: {
      realizedPnl: totals.realizedPnl,
      unrealizedPnl: totals.unrealizedPnl,
      totalPnl: totals.realizedPnl + totals.unrealizedPnl,
    },
  };
}

module.exports = { summary, positionWithPnl };
