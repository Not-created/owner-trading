// Broker reconciliation. LIVE fill truth comes from Kotak order_report + trade_report.
const executionLogService = require('./executionLogService');
const positionService = require('./positionService');
const marketDataSimulator = require('./marketDataSimulator');
const { getAdapter, paperAdapter } = require('../brokers');
const NEEDS_RECONCILIATION_STATES=['SUBMITTED','OPEN','PARTIALLY_FILLED','UNKNOWN','RECONCILIATION_REQUIRED'];

function applyLiveFills(db, order, fills) {
  for (const fill of fills || []) {
    const fillId=String(fill.flId || fill.trade_id || fill.fill_id || `${fill.exOrdId||''}:${fill.flDt||''}:${fill.flTm||''}:${fill.fldQty||fill.qty||''}`);
    const qty=Number(fill.fldQty || fill.qty || 0); const price=Number(fill.avgPrc || fill.prc || 0);
    if (!(qty>0) || !(price>=0)) continue;
    const exists=db.prepare('SELECT id FROM order_fills WHERE order_id=? AND broker_fill_id=?').get(order.id,fillId);
    if (exists) continue;
    db.prepare(`INSERT INTO order_fills(order_id,broker_fill_id,broker_order_id,quantity,price,exchange_order_id,fill_time) VALUES(?,?,?,?,?,?,?)`)
      .run(order.id,fillId,String(order.broker_order_id),qty,price,fill.exOrdId||null,fill.flDt&&fill.flTm?`${fill.flDt} ${fill.flTm}`:null);
    positionService.applyFill(db,{strategyId:order.strategy_id,symbol:order.symbol,mode:order.mode,side:order.side,quantity:qty,price});
  }
}

async function reconcileOrder(db,order){
  if(!NEEDS_RECONCILIATION_STATES.includes(order.state)) return order;
  if(order.mode==='PAPER'&&order.state==='OPEN'&&order.broker_order_id){paperAdapter.tryFillPending(order.broker_order_id,marketDataSimulator.getLastPrice(order.symbol));}
  const adapter=getAdapter(order.mode);
  try{
    const status=await adapter.getOrderStatus(order.broker_order_id);
    if(order.mode==='LIVE' && typeof adapter.reconcileFills==='function'){
      const fills=await adapter.reconcileFills(order.broker_order_id);
      applyLiveFills(db,order,fills);
      const total=db.prepare('SELECT COALESCE(SUM(quantity),0) qty, CASE WHEN SUM(quantity)>0 THEN SUM(quantity*price)/SUM(quantity) END avg FROM order_fills WHERE order_id=?').get(order.id);
      status.filledQuantity=Number(total.qty||0); status.avgFillPrice=total.avg==null?null:Number(total.avg);
      if(status.filledQuantity>=order.quantity) status.state='FILLED'; else if(status.filledQuantity>0 && status.state!=='REJECTED'&&status.state!=='CANCELLED') status.state='PARTIALLY_FILLED';
    } else if(status.filledQuantity>order.filled_quantity && status.avgFillPrice!=null){
      const delta=status.filledQuantity-order.filled_quantity;
      positionService.applyFill(db,{strategyId:order.strategy_id,symbol:order.symbol,mode:order.mode,side:order.side,quantity:delta,price:status.avgFillPrice});
    }
    db.prepare(`UPDATE orders SET state=?,filled_quantity=?,avg_fill_price=?,updated_at=datetime('now') WHERE id=?`).run(status.state,status.filledQuantity,status.avgFillPrice,order.id);
    return db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
  }catch(err){
    db.prepare(`UPDATE orders SET state='RECONCILIATION_REQUIRED',reject_reason=?,updated_at=datetime('now') WHERE id=?`).run(err.message,order.id);
    executionLogService.error(db,order.strategy_id,`Order #${order.id} reconciliation failed: ${err.message}`);
    return db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
  }
}
async function reconcileAll(db){const pending=db.prepare(`SELECT * FROM orders WHERE state IN (${NEEDS_RECONCILIATION_STATES.map(()=>'?').join(',')})`).all(...NEEDS_RECONCILIATION_STATES);const out=[];for(const o of pending)out.push(await reconcileOrder(db,o));return out;}
module.exports={reconcileOrder,reconcileAll,NEEDS_RECONCILIATION_STATES};
