// Admin bootstrap.
//
// On first run (no users in the DB), creates exactly one admin account
// with a randomly generated temporary password and must_change_password=1.
// On every subsequent run, this is a no-op — it never resets or recreates
// an existing admin, so restarting the server can never wipe a real
// password. There is no public registration anywhere in this app; this is
// the only way a user row is ever created.

const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');

const BOOTSTRAP_USERNAME = 'admin';
const BCRYPT_SALT_ROUNDS = 10;

function generateTempPassword() {
  // 16 bytes -> ~22 url-safe base64 characters. Random, not a fixed default.
  return crypto.randomBytes(16).toString('base64url');
}

// Returns { created: false } if an admin already existed, or
// { created: true, username, password } if a new one was just created.
// `password` is the ONLY time the plaintext temporary password exists in
// memory — callers must not log it anywhere except the local credentials
// file (see server.js), and never send it anywhere over the network.
function ensureAdminBootstrap(db) {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM users').get();

  if (count > 0) {
    return { created: false };
  }

  const password = generateTempPassword();
  const passwordHash = bcrypt.hashSync(password, BCRYPT_SALT_ROUNDS);

  db.prepare(
    'INSERT INTO users (username, password_hash, must_change_password) VALUES (?, ?, 1)'
  ).run(BOOTSTRAP_USERNAME, passwordHash);

  return { created: true, username: BOOTSTRAP_USERNAME, password };
}

// Single-admin model: there is exactly one meaningful user row. Rather
// than hardcoding id=1 everywhere that needs "the admin", this looks it
// up — correct even in the edge case where row 1 was ever deleted/recreated.
function getAdminUserId(db) {
  const row = db.prepare('SELECT id FROM users ORDER BY id LIMIT 1').get();
  return row ? row.id : null;
}

module.exports = { ensureAdminBootstrap, BOOTSTRAP_USERNAME, getAdminUserId };
