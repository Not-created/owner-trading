// Strategy execution engine.
//
// IMPORTANT SECURITY NOTE (per project requirements — do not remove or
// soften this): running user JavaScript in a worker_thread + vm.Script
// gives HANG/CRASH isolation (a runaway loop or thrown exception in one
// strategy cannot freeze the main process or take down other strategies)
// and a HARD EXECUTION TIMEOUT. It is NOT a strong security sandbox.
// Node's own docs are explicit that `vm` is not a security mechanism, and
// a worker thread still shares the same Node binary, OS process tree, and
// (absent extra restriction) many built-in globals. A sufficiently
// determined malicious script could still attempt to misbehave.
// Consequences of this, reflected elsewhere in the codebase:
//   - Only PAPER execution is exercised by anything in this project.
//   - Strategy code NEVER receives a broker adapter, network access, or
//     filesystem access in its context — only plain data (price/position
//     numbers) and a few pure helper functions (indicators.js).
//   - If stronger isolation (e.g. a separate OS process per strategy with
//     seccomp/container-level restriction) is required before trusting
//     this with real money, that work has NOT been done — do not claim
//     otherwise.

const path = require('node:path');
const vm = require('node:vm');
const { Worker, isMainThread, parentPort, workerData } = require('node:worker_threads');

const DEFAULT_TIMEOUT_MS = 3000;
const VALID_ACTIONS = ['BUY', 'SELL', 'EXIT', 'HOLD'];

function normalizeSignal(raw) {
  if (typeof raw === 'string' && VALID_ACTIONS.includes(raw)) {
    return { action: raw };
  }
  if (raw && typeof raw === 'object' && VALID_ACTIONS.includes(raw.action)) {
    const signal = { action: raw.action };
    if (typeof raw.reason === 'string') signal.reason = raw.reason;
    if (Number.isFinite(raw.quantity) && raw.quantity > 0) signal.quantity = raw.quantity;
    return signal;
  }
  return { action: 'HOLD', reason: 'UNRECOGNIZED_RETURN_VALUE' };
}

// --- Worker-side execution (this branch runs INSIDE the spawned thread) --
if (!isMainThread) {
  const { code, context } = workerData;
  const logs = [];

  try {
    // indicators is required locally, not passed through workerData:
    // workerData goes through the structured clone algorithm, which
    // cannot serialize functions. Each worker just requires its own copy
    // of the (pure, stateless) indicators module instead.
    // eslint-disable-next-line global-require
    const indicators = require('./indicators');

    const sandbox = {
      market: context.market, // { price, history: number[] }
      position: context.position, // { quantity, avgPrice }
      indicators, // pure helper functions, see indicators.js
      console: {
        log: (...args) => logs.push(args.map(String).join(' ')),
      },
      Math,
      Date,
      JSON,
      __result__: undefined,
    };
    const vmContext = vm.createContext(sandbox);
    const script = new vm.Script(
      `${code}\n;__result__ = (typeof strategy === 'function') ? strategy({ market, position, indicators }) : undefined;`,
      { filename: 'strategy.js' }
    );
    // vm's own timeout is a second, defense-in-depth layer against a
    // synchronous infinite loop — the worker-level timeout below is the
    // primary guarantee since vm's timeout does not stop async code.
    script.runInContext(vmContext, { timeout: DEFAULT_TIMEOUT_MS });

    parentPort.postMessage({ type: 'result', signal: normalizeSignal(sandbox.__result__), logs });
  } catch (err) {
    parentPort.postMessage({ type: 'error', message: err.message, logs });
  }
}

// --- Main-thread API --------------------------------------------------
// Returns { signal, logs, error } — error is null on success. Never
// throws; a crash or timeout is reported in the result, not as a
// rejected promise, so callers (strategyService) can log and continue
// running other strategies without a try/catch at every call site.
function runStrategy({ code, context, timeoutMs = DEFAULT_TIMEOUT_MS }) {
  return new Promise((resolve) => {
    const worker = new Worker(path.resolve(__dirname, 'strategyExecutor.js'), {
      workerData: { code, context },
    });

    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      worker.terminate().catch(() => {});
      resolve(result);
    };

    const timer = setTimeout(() => {
      finish({
        signal: { action: 'HOLD', reason: 'EXECUTION_TIMEOUT' },
        logs: [],
        error: `Strategy execution exceeded ${timeoutMs}ms and was terminated`,
      });
    }, timeoutMs);

    worker.once('message', (msg) => {
      if (msg.type === 'result') {
        finish({ signal: msg.signal, logs: msg.logs, error: null });
      } else if (msg.type === 'error') {
        finish({
          signal: { action: 'HOLD', reason: 'EXECUTION_ERROR' },
          logs: msg.logs || [],
          error: msg.message,
        });
      }
    });

    worker.once('error', (err) => {
      finish({
        signal: { action: 'HOLD', reason: 'WORKER_CRASH' },
        logs: [],
        error: err.message,
      });
    });
  });
}

module.exports = { runStrategy, normalizeSignal, VALID_ACTIONS };
