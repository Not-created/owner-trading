// Encryption at rest for persisted secrets (currently: Kotak credentials).
//
// AES-256-GCM via Node's built-in crypto module — no external dependency.
// GCM's auth tag means tampered ciphertext fails to decrypt rather than
// silently returning garbage (validated standalone before this file was
// wired in — see PROGRESS.md for that validation run).

const crypto = require('node:crypto');
const config = require('../config/env');

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH_BYTES = 12; // recommended IV length for GCM

function getKeyBuffer() {
  const key = config.credentialEncryptionKey;
  if (!key || key.length !== 64) {
    throw new Error(
      'CREDENTIAL_ENCRYPTION_KEY must be set to a 64-character hex string (32 bytes). ' +
        'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }
  return Buffer.from(key, 'hex');
}

function encryptJson(obj) {
  const key = getKeyBuffer();
  const iv = crypto.randomBytes(IV_LENGTH_BYTES);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const plaintext = Buffer.from(JSON.stringify(obj), 'utf8');
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return {
    encryptedPayload: encrypted.toString('hex'),
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
  };
}

function decryptJson({ encryptedPayload, iv, authTag }) {
  const key = getKeyBuffer();
  const decipher = crypto.createDecipheriv(ALGORITHM, key, Buffer.from(iv, 'hex'));
  decipher.setAuthTag(Buffer.from(authTag, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encryptedPayload, 'hex')),
    decipher.final(),
  ]);
  return JSON.parse(decrypted.toString('utf8'));
}

module.exports = { encryptJson, decryptJson };
