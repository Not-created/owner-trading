// Server-side session handling.
//
// The cookie sent to the browser holds a random 256-bit token. Only the
// SHA-256 hash of that token is ever stored in the database, so reading
// the `sessions` table (e.g. via a DB backup or leak) is not enough by
// itself to forge a valid session — the raw token is never persisted.

const crypto = require('node:crypto');

const COOKIE_NAME = 'ot_session';
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function createSession(db, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const id = hashToken(token);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();

  db.prepare('INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)').run(
    id,
    userId,
    expiresAt
  );

  return { token, expiresAt };
}

// Returns { sessionId, userId, username, mustChangePassword } or null.
function getSessionUser(db, token) {
  if (!token) return null;

  const id = hashToken(token);
  const row = db
    .prepare(
      `SELECT sessions.id AS sessionId,
              sessions.expires_at AS expiresAt,
              users.id AS userId,
              users.username AS username,
              users.must_change_password AS mustChangePassword
       FROM sessions
       JOIN users ON users.id = sessions.user_id
       WHERE sessions.id = ?`
    )
    .get(id);

  if (!row) return null;

  if (new Date(row.expiresAt).getTime() < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
    return null;
  }

  return {
    sessionId: row.sessionId,
    userId: row.userId,
    username: row.username,
    mustChangePassword: !!row.mustChangePassword,
  };
}

function destroySession(db, token) {
  if (!token) return;
  db.prepare('DELETE FROM sessions WHERE id = ?').run(hashToken(token));
}

function destroyAllSessionsForUser(db, userId) {
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
}

module.exports = {
  COOKIE_NAME,
  createSession,
  getSessionUser,
  destroySession,
  destroyAllSessionsForUser,
};
