// Kotak credential storage: encrypt on write, mask on every read that a
// route can reach. Route handlers must only ever call getMaskedStatus() —
// getRawCredentials() exists only for kotakBrokerAdapter.js, never for an
// HTTP response.
//
// Also owns the connection-state lifecycle (migration 006) — distinct
// from "configured" (credentials exist) — see that migration's comment
// for the full state list. "configured" and "connected" are NEVER the
// same thing: saving credentials does not, by itself, mean they work.

const { encryptJson, decryptJson } = require('./encryption');

// See migrations/003_add_broker_credentials.sql for why these exact field
// names were chosen (sourced from the current official Kotak SDK sample).
const REQUIRED_FIELDS = ['consumerKey', 'ucc', 'mobileNumber', 'mpin', 'totpSecret'];
const ALLOWED_ENVIRONMENTS = ['prod', 'uat'];

function maskValue(value) {
  const str = value === undefined || value === null ? '' : String(value);
  if (str.length === 0) return '';
  if (str.length <= 4) return '*'.repeat(str.length);
  return `${str.slice(0, 2)}${'*'.repeat(str.length - 4)}${str.slice(-2)}`;
}

// Returns an array of missing required field names (empty array = valid).
function validateFields(fields) {
  return REQUIRED_FIELDS.filter((name) => !fields || !fields[name]);
}

function isValidEnvironment(env) {
  return !env || ALLOWED_ENVIRONMENTS.includes(env);
}

// Saving new/changed credentials always resets connection_state to
// DISCONNECTED — an old CONNECTED status must never be inherited by
// credentials that haven't themselves been verified yet.
function upsertCredentials(db, userId, fields, environment) {
  const { encryptedPayload, iv, authTag } = encryptJson(fields);

  db.prepare(
    `INSERT INTO broker_kotak_credentials
       (user_id, environment, encrypted_payload, iv, auth_tag, connection_state, updated_at)
     VALUES (?, ?, ?, ?, ?, 'DISCONNECTED', datetime('now'))
     ON CONFLICT(user_id) DO UPDATE SET
       environment = excluded.environment,
       encrypted_payload = excluded.encrypted_payload,
       iv = excluded.iv,
       auth_tag = excluded.auth_tag,
       connection_state = 'DISCONNECTED',
       last_verified_at = NULL,
       last_error_code = NULL,
       last_error_message = NULL,
       updated_at = datetime('now')`
  ).run(userId, environment || 'prod', encryptedPayload, iv, authTag);
}

// Decrypts and returns { environment, updatedAt, fields } with PLAINTEXT
// secrets, or null if nothing is stored. Not for route use — see header.
function getRawCredentials(db, userId) {
  const row = db.prepare('SELECT * FROM broker_kotak_credentials WHERE user_id = ?').get(userId);
  if (!row) return null;

  const fields = decryptJson({
    encryptedPayload: row.encrypted_payload,
    iv: row.iv,
    authTag: row.auth_tag,
  });

  return { environment: row.environment, updatedAt: row.updated_at, fields };
}

// Transitions to a new connection_state. Sanitized error info only —
// callers must never pass a raw exception object here (see
// kotakBrokerAdapter.js, which is the only caller).
function setConnectionState(db, userId, state, { errorCode = null, errorMessage = null } = {}) {
  const setVerified = state === 'CONNECTED';
  db.prepare(
    `UPDATE broker_kotak_credentials
     SET connection_state = ?,
         last_error_code = ?,
         last_error_message = ?,
         last_verified_at = CASE WHEN ? THEN datetime('now') ELSE last_verified_at END,
         updated_at = datetime('now')
     WHERE user_id = ?`
  ).run(state, errorCode, errorMessage, setVerified ? 1 : 0, userId);
}

function getConnectionRow(db, userId) {
  return db
    .prepare(
      'SELECT connection_state, last_verified_at, last_error_code, last_error_message FROM broker_kotak_credentials WHERE user_id = ?'
    )
    .get(userId);
}

// Used by tradingStateService as one of the LIVE-order safety gates — a
// LIVE order must never be attempted without a currently CONNECTED broker.
function isConnected(db, userId) {
  const row = getConnectionRow(db, userId);
  return !!row && row.connection_state === 'CONNECTED';
}

// The only read path routes should use: never returns a raw secret value.
function getMaskedStatus(db, userId) {
  const raw = getRawCredentials(db, userId);
  if (!raw) return { configured: false, connectionState: 'DISCONNECTED' };

  const maskedFields = {};
  for (const key of Object.keys(raw.fields)) {
    maskedFields[key] = maskValue(raw.fields[key]);
  }

  const connection = getConnectionRow(db, userId);

  return {
    configured: true,
    environment: raw.environment,
    updatedAt: raw.updatedAt,
    maskedFields,
    connectionState: connection ? connection.connection_state : 'DISCONNECTED',
    lastVerifiedAt: connection ? connection.last_verified_at : null,
    lastErrorCode: connection ? connection.last_error_code : null,
    lastErrorMessage: connection ? connection.last_error_message : null,
  };
}

function deleteCredentials(db, userId) {
  db.prepare('DELETE FROM broker_kotak_credentials WHERE user_id = ?').run(userId);
}

module.exports = {
  REQUIRED_FIELDS,
  validateFields,
  isValidEnvironment,
  upsertCredentials,
  getRawCredentials,
  getMaskedStatus,
  deleteCredentials,
  setConnectionState,
  getConnectionRow,
  isConnected,
};
