// Append-only execution log. Every strategy run, signal, risk rejection,
// order-state change, and error goes through here so the Logs UI has a
// single source of truth instead of scraping console output.

function log(db, { strategyId = null, level = 'INFO', message }) {
  db.prepare(
    'INSERT INTO execution_logs (strategy_id, level, message) VALUES (?, ?, ?)'
  ).run(strategyId, level, message);
}

function info(db, strategyId, message) {
  log(db, { strategyId, level: 'INFO', message });
}
function warn(db, strategyId, message) {
  log(db, { strategyId, level: 'WARN', message });
}
function error(db, strategyId, message) {
  log(db, { strategyId, level: 'ERROR', message });
}

function list(db, { strategyId = null, limit = 200 } = {}) {
  if (strategyId) {
    return db
      .prepare(
        'SELECT * FROM execution_logs WHERE strategy_id = ? ORDER BY id DESC LIMIT ?'
      )
      .all(strategyId, limit);
  }
  return db.prepare('SELECT * FROM execution_logs ORDER BY id DESC LIMIT ?').all(limit);
}

module.exports = { log, info, warn, error, list };
