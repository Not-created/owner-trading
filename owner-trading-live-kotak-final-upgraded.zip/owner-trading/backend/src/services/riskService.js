// Pre-order risk validation. Every order must pass through here before
// orderService ever calls a broker adapter. Fails CLOSED: if a limit is
// exceeded (or a check can't be computed), the order is rejected — it
// never falls through to "allow by default".
//
// KNOWN SIMPLIFICATION (documented, not hidden): max_daily_loss compares
// against all-time cumulative realized P&L across positions, not a
// true midnight-reset daily figure — there is no date-partitioned P&L
// ledger yet. Treat this as a standing loss cap, not a literal "today"
// figure, until a real daily ledger is built.

function getLimits(db) {
  return db.prepare('SELECT * FROM risk_limits WHERE id = 1').get();
}

function updateLimits(db, updates) {
  const current = getLimits(db);
  const next = { ...current, ...updates };
  db.prepare(
    `UPDATE risk_limits SET
       max_order_value = ?, max_daily_loss = ?, max_open_positions = ?,
       max_orders_per_minute = ?, updated_at = datetime('now')
     WHERE id = 1`
  ).run(next.max_order_value, next.max_daily_loss, next.max_open_positions, next.max_orders_per_minute);
  return getLimits(db);
}

function cumulativeRealizedLoss(db, mode) {
  const row = db
    .prepare('SELECT COALESCE(SUM(realized_pnl), 0) AS total FROM positions WHERE mode = ?')
    .get(mode);
  return row.total; // negative = net loss
}

function countOpenPositions(db, mode) {
  const row = db
    .prepare('SELECT COUNT(*) AS count FROM positions WHERE mode = ? AND quantity != 0')
    .get(mode);
  return row.count;
}

function hasOpenPosition(db, mode, symbol) {
  const row = db
    .prepare('SELECT 1 FROM positions WHERE mode = ? AND symbol = ? AND quantity != 0')
    .get(mode, symbol);
  return !!row;
}

function ordersInLastMinute(db) {
  const row = db
    .prepare("SELECT COUNT(*) AS count FROM orders WHERE created_at >= datetime('now', '-60 seconds')")
    .get();
  return row.count;
}

// Returns { allowed: boolean, reason?: string }.
function validateOrder(db, { symbol, mode, quantity, referencePrice }) {
  const limits = getLimits(db);

  const orderValue = quantity * referencePrice;
  if (orderValue > limits.max_order_value) {
    return { allowed: false, reason: 'MAX_ORDER_VALUE_EXCEEDED' };
  }

  const realizedLoss = cumulativeRealizedLoss(db, mode);
  if (realizedLoss <= -Math.abs(limits.max_daily_loss)) {
    return { allowed: false, reason: 'MAX_DAILY_LOSS_EXCEEDED' };
  }

  if (!hasOpenPosition(db, mode, symbol)) {
    const openCount = countOpenPositions(db, mode);
    if (openCount >= limits.max_open_positions) {
      return { allowed: false, reason: 'MAX_OPEN_POSITIONS_EXCEEDED' };
    }
  }

  if (ordersInLastMinute(db) >= limits.max_orders_per_minute) {
    return { allowed: false, reason: 'RATE_LIMIT_EXCEEDED' };
  }

  return { allowed: true };
}

module.exports = { getLimits, updateLimits, validateOrder };
