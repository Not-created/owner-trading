const fs = require('node:fs');
const path = require('node:path');

// Writes the one-time bootstrap admin credentials to a local file so the
// operator can retrieve them outside of chat/logs. This file is already
// excluded in .gitignore. It should be deleted after the first login.
function writeInitialAdminCredentialsFile(username, password) {
  const filePath = path.join(__dirname, '..', '..', 'INITIAL_ADMIN_CREDENTIALS.txt');
  const contents =
    `Owner Trading — initial admin credentials\n` +
    `Generated: ${new Date().toISOString()}\n\n` +
    `username: ${username}\n` +
    `password: ${password}\n\n` +
    `This file is created ONLY the first time the server runs with no users\n` +
    `in the database. Log in with these credentials, complete the forced\n` +
    `password change, then DELETE this file. It is excluded from git via\n` +
    `.gitignore and must never be committed.\n`;

  fs.writeFileSync(filePath, contents, { mode: 0o600 });
  return filePath;
}

module.exports = { writeInitialAdminCredentialsFile };
