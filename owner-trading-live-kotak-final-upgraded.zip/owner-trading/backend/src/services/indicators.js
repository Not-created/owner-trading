// Pure technical-indicator functions. Exposed to strategy code via the
// `indicators` object in strategyExecutor.js's sandbox — strategy authors
// call e.g. `indicators.sma(market.history, 20)` instead of hand-rolling
// math in every strategy. Deliberately a small, well-tested set rather
// than a large indicator library, to keep the sandboxed surface area
// small and fully understood.

function sma(history, period) {
  if (!Array.isArray(history) || history.length < period) return null;
  const slice = history.slice(-period);
  return slice.reduce((sum, v) => sum + v, 0) / period;
}

function ema(history, period) {
  if (!Array.isArray(history) || history.length < period) return null;
  const k = 2 / (period + 1);
  const slice = history.slice(-period);
  let value = slice[0];
  for (let i = 1; i < slice.length; i += 1) {
    value = slice[i] * k + value * (1 - k);
  }
  return value;
}

// Standard Wilder-style RSI over the trailing `period` changes.
function rsi(history, period = 14) {
  if (!Array.isArray(history) || history.length < period + 1) return null;

  const slice = history.slice(-(period + 1));
  let gains = 0;
  let losses = 0;
  for (let i = 1; i < slice.length; i += 1) {
    const change = slice[i] - slice[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;

  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

module.exports = { sma, ema, rsi };
