const config = require('../config/env');

// Centralized error handler. Kept deliberately simple at foundation stage:
// - Never leak stack traces or internal details to the client in production.
// - Never log request bodies wholesale (could contain secrets in later
//   features such as Kotak credential forms) — log only safe metadata.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || 500;

  console.error(`[error] ${req.method} ${req.path} -> ${status}: ${err.message}`);

  const body = { error: err.publicMessage || 'Internal server error' };
  if (config.nodeEnv !== 'production') {
    body.detail = err.message;
  }

  res.status(status).json(body);
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: 'Not found' });
}

module.exports = { errorHandler, notFoundHandler };
