const { getDb } = require('../db/connection');
const { COOKIE_NAME, getSessionUser } = require('../services/sessionService');

// Attaches req.user = { sessionId, userId, username, mustChangePassword }
// when the request has a valid session cookie. Otherwise responds 401.
// Intentionally does NOT check mustChangePassword itself — /api/auth/me
// and /api/auth/change-password must remain reachable for a user who is
// mid forced-password-change. Use requirePasswordChangeComplete after this
// on routes that should be blocked until the password change is done.
function requireAuth(req, res, next) {
  const token = req.cookies ? req.cookies[COOKIE_NAME] : null;
  const db = getDb();
  const user = getSessionUser(db, token);

  if (!user) {
    return res.status(401).json({ error: 'UNAUTHENTICATED' });
  }

  req.user = user;
  next();
}

// Apply AFTER requireAuth on any protected trading route (strategies,
// orders, broker config, etc. — added in later checkpoints) so a user who
// has not completed their forced password change cannot use them.
function requirePasswordChangeComplete(req, res, next) {
  if (req.user && req.user.mustChangePassword) {
    return res.status(403).json({ error: 'PASSWORD_CHANGE_REQUIRED' });
  }
  next();
}

module.exports = { requireAuth, requirePasswordChangeComplete };
