# Owner Trading — Progress / Checkpoint Log

This file is the persistent continuity record required by
`OWNER_TRADING_MASTER_HANDOFF-3.md`. Read this first in any new session,
then verify it against the actual code and (once connected) actual git
history before continuing.

---

## PROJECT STATUS SUMMARY (read this first)

**⚠️ A newer, more complete status document now exists:
`FINAL_IMPLEMENTATION_REPORT.md`** (project root), covering the full real
Kotak Neo LIVE integration pass (Python microservice wrapping the
official `kotakneoapi` SDK, real authentication/order/position/holdings/
limits calls, connection-state machine, LIVE safety gates requiring a
connected broker, and the simulator-leakage bug fix). Read that file
first for the current state; the summary immediately below predates it
and is kept for history.

**Overall status: NOT COMPLETE — but the full internal trading engine now
exists and is genuinely tested.** This section reflects the state after
the "Project 2: Final Trading Readiness" work. See the checkpoint entries
below for the earlier build (foundation/auth/broker-storage/deploy).

### Built and integrated (backend + frontend wired together)
- Foundation, authentication, Kotak credential storage (encrypted,
  storage-only), trading safety gates, deployment scripts — all as before.
- **Full trading engine, end to end**: strategy storage + execution
  (worker_threads + vm, hard timeout) → market data simulator → signal →
  risk engine → order manager (full state machine, idempotency/duplicate
  protection, emergency-stop + LIVE gating) → broker adapter interface →
  PAPER adapter (real simulated fills) / Kotak adapter (honest stub) →
  position accounting (weighted avg price, realized P&L, reversals) →
  P&L summary (realized + unrealized) → reconciliation (asks the adapter,
  never assumes) → execution logs.
- **Frontend**: Dashboard (live status indicators), Strategies (built-in
  Strategy Builder), Market Data, Orders, Positions, P&L, Risk Controls,
  Execution Logs, Trading Control, Settings — every backend endpoint has
  exactly one frontend caller (verified by cross-referencing every route
  against every `client.js` call — zero orphans either direction).

### Genuinely validated THIS session (not just written)
- **The entire PAPER trading lifecycle actually ran**, end to end, using
  Node 22's built-in `node:sqlite` module against the project's real
  migration SQL and real service code (unmodified) — because these
  services take a `db` parameter and never `require('better-sqlite3')`
  themselves, they run identically against any compatible driver. 15
  separate real assertions passed, including: a strategy actually
  producing an order through the full market-data→strategy→risk→order→
  fill→position→P&L pipeline; risk engine genuinely rejecting an
  over-limit order; duplicate order intents genuinely collapsing to one
  row; emergency stop genuinely blocking new PAPER orders; a LIVE order
  genuinely FAILING (not fabricating success) once the stub adapter is
  hit; reconciliation genuinely resolving an OPEN limit order to FILLED
  by asking the adapter; restart recovery genuinely correcting a stale
  RUNNING status; and a crashing strategy genuinely isolated to ERROR
  without affecting a healthy strategy running alongside it.
- **This process found and fixed one real bug**: the failure-isolation
  path was clobbering its own ERROR status by calling `stopStrategy()`
  (which unconditionally sets STOPPED) right after setting ERROR. Caught
  because the validation harness actually asserted on the final status,
  not because it was spotted by inspection.
- The strategy executor's worker_threads + vm sandbox was independently
  run and verified: normal execution, an infinite loop actually killed by
  the timeout (measured elapsed time), a thrown error isolated without
  crashing the process, a malformed return value normalized to HOLD, and
  confirmed `require`/`process` are not reachable from strategy code.
- `indicators.js` (sma/ema/rsi) and `strategyExecutor.js` tests were run
  with the **real `node --test` runner** (zero external dependencies) —
  8/8 pass.
- Full import-resolution audit (every relative `require()` in the backend
  resolves to a real file) and full route audit (every backend endpoint
  has exactly one matching frontend `client.js` call, both directions) —
  both actually executed via script, not eyeballed.
- `.gitignore` re-verified via a real local `git init`/`add` against every
  runtime artifact type produced across the whole project so far.

### Still NOT verified / NOT built (honest, explicit)
- **Kotak LIVE integration: NOT VERIFIED, NOT IMPLEMENTED.** The adapter
  is an honest stub (`kotakBrokerAdapter.js`) that throws `NOT_IMPLEMENTED`
  rather than fabricating a broker response. See that file's header for
  exactly what is and isn't verified about the current Kotak API contract,
  and exactly what would be needed (real docs access + a real account) to
  fill it in. This cannot change without real network access and a real
  broker account — neither exists in this sandbox, and credentials were
  correctly never requested in chat.
- **No real market data feed** — `marketDataSimulator.js` generates
  synthetic random-walk prices, clearly labeled everywhere it's used.
  Unrealized P&L for LIVE positions is `null` (never fabricated) because
  there is no real quote source to mark against.
- **Order modification** (amend price/qty) is not implemented — only
  create and cancel.
- **No automatic retry logic** for a failed/timed-out broker submission —
  reconciliation resolves uncertain state, but nothing automatically
  resubmits. A human (or future scheduled job) must act on
  `RECONCILIATION_REQUIRED`/`FAILED` orders.
- **No separate `fills`/`trades` ledger** — positions/P&L are computed
  from the `orders` table's aggregate fill data. Exactly correct for the
  paper adapter (always one all-at-once fill); a real broker reporting
  true multi-step partial fills would need a dedicated fills table for
  fully correct incremental accounting (documented in
  `reconciliationService.js`).
- **Risk limits are global, not per-strategy.** The spec asked for both;
  only the global tier was built, given time constraints — per-strategy
  limits would layer on top of the same `riskService.validateOrder()`
  choke point without changing its contract.
- **No trailing stop** — fixed stop-loss/target percentages only.
- **No `npm install`/`npm test`/`npm run build` has ever actually run** —
  this sandbox has no network access (reconfirmed via `403 Forbidden`
  from the npm registry every time it's been checked across this entire
  project). The nearest thing to "ran the tests for real" is the
  `node:sqlite`-based validation above, which exercises the identical
  service code but is not the same as `npm test` passing.

### Why this is still "NOT COMPLETE" rather than "LIVE READY"
Every piece that can be built and genuinely tested without a live broker
connection now exists and has been exercised for real. What remains is,
by construction, exactly the kind of external verification that requires
things this sandbox does not have: real network access to Kotak's
authoritative API reference, and a real account to test an actual
round-trip against. Marking this "LIVE READY" without that would be
fabrication — which the project's own instructions explicitly forbid.

---

## CHECKPOINT: Full trading engine (strategy, market data, risk, order manager, PAPER broker, positions, P&L, reconciliation) + frontend

FEATURE: Everything described in "Genuinely validated THIS session" above.

FILES ADDED:
```
backend/src/db/migrations/005_add_trading_engine.sql
backend/src/services/executionLogService.js
backend/src/services/marketDataSimulator.js
backend/src/services/indicators.js
backend/src/services/riskService.js
backend/src/services/strategyExecutor.js
backend/src/services/strategyService.js
backend/src/services/orderService.js
backend/src/services/positionService.js
backend/src/services/pnlService.js
backend/src/services/reconciliationService.js
backend/src/brokers/brokerAdapter.js       (interface)
backend/src/brokers/paperBrokerAdapter.js  (full implementation)
backend/src/brokers/kotakBrokerAdapter.js  (honest NOT_IMPLEMENTED stub)
backend/src/brokers/index.js               (adapter factory)
backend/src/routes/strategies.js
backend/src/routes/orders.js
backend/src/routes/positions.js
backend/src/routes/risk.js
backend/src/routes/logs.js
backend/src/routes/marketData.js
backend/test/tradingEngine.test.js
backend/test/strategyExecutor.test.js
backend/test/indicators.test.js
frontend/src/pages/StrategiesPage.jsx   (includes the Strategy Builder)
frontend/src/pages/MarketDataPage.jsx
frontend/src/pages/OrdersPage.jsx
frontend/src/pages/PositionsPage.jsx
frontend/src/pages/PnLPage.jsx
frontend/src/pages/RiskControlsPage.jsx
frontend/src/pages/LogsPage.jsx
```
FILES MODIFIED: `server.js` (mounted all new routes; startup now also
resets stale strategy RUNNING status and runs startup order reconciliation,
in addition to the existing LIVE-disable-on-restart safety from the
previous checkpoint), `frontend/src/api/client.js` (29 endpoint functions,
all now used), `frontend/src/App.jsx` (routes), `DashboardPage.jsx`
(rebuilt with real status indicators instead of a raw health-check dump).

VALIDATION ACTUALLY RUN: see "Genuinely validated THIS session" above —
not repeated here to avoid duplication. In short: 15/15 real end-to-end
engine assertions via `node:sqlite`, 8/8 real `node --test` passes
(strategyExecutor + indicators, zero dependencies), full import-resolution
audit, full route/client cross-reference audit, `.gitignore` re-proof.

VALIDATION NOT RUN: `npm test` for the full suite (needs better-sqlite3/
bcryptjs/cookie-parser, none installed — no network), `npm run build`,
any real HTTP round-trip through a running `node server.js` process,
opening this in an actual browser.

KOTAK LIVE STATUS: NOT VERIFIED, NOT IMPLEMENTED (intentional stub — see
`kotakBrokerAdapter.js`).

GITHUB: NOT DONE (no network, unchanged from every prior checkpoint).

---

## CHECKPOINT: Final re-audit and orphan-endpoint fix

During the mandated final re-audit, a route/client cross-check script
(count backend `router.<method>()` handlers vs. frontend `request()`
calls) found a genuine mismatch: 31 backend handlers vs. 30 frontend
calls. Root cause: `GET /api/strategies/:id` had no frontend caller at
all — a real orphaned endpoint, not a false positive.

FIX: added `getStrategy(id)` to `client.js`, and actually wired it into a
real feature rather than adding a dead import — `StrategiesPage.jsx` now
has a genuine Edit flow (click a strategy's name → fetches the full row
including its code via this endpoint → pre-fills the builder →
`updateStrategy()` on submit). This closed both the orphan and a real
functional gap (there was previously no way to edit a strategy's code
after creation). Re-ran the cross-check after the fix: 31/31, exact parity.

Also fixed during this pass: a test-design flaw (not an engine bug) where
the risk-rejection test reused the same strategy/symbol/side/quantity as
an earlier test within the 3-second duplicate-protection window, so it
was silently handed back the earlier FILLED order instead of exercising
the risk check — the engine's duplicate protection was working exactly as
designed; the test was wrong to expect otherwise. Fixed by using a
distinct symbol. Re-ran the full 15-check engine validation **15 times
across two sessions** after these fixes: 15/15 consistently.

GITHUB: NOT DONE (no network).

---

## CHECKPOINT: Foundation (project skeleton)

FEATURE: Clean project foundation — Express backend, React/Vite frontend,
SQLite wiring, config/env handling, error handling, health route, test
structure, .gitignore, README.

STATUS: PARTIALLY COMPLETE

Reasoning for PARTIALLY COMPLETE rather than COMPLETE: implementation and
static validation are done, but dependency installation and runtime
execution have NOT been verified in this environment (see below). Per the
handoff's Honest Status Rule, COMPLETE requires validation "to the extent
possible" — and in a network-connected environment, more validation is
possible than what has run here.

FILES CHANGED (all new):
```
.gitignore
README.md
PROGRESS.md
backend/package.json
backend/.env.example
backend/server.js
backend/src/config/env.js
backend/src/db/schema.sql
backend/src/db/connection.js
backend/src/routes/health.js
backend/src/middleware/errorHandler.js
backend/test/health.test.js
backend/data/.gitkeep
backend/logs/.gitkeep
frontend/package.json
frontend/vite.config.js
frontend/index.html
frontend/src/main.jsx
frontend/src/App.jsx
frontend/src/api/client.js
frontend/.env.example
```

INTEGRATION:
- Backend: `server.js` wires config → CORS → JSON body parsing → `/api`
  health route → 404 handler → error handler.
- `src/db/connection.js` opens the SQLite file (creating `backend/data/`
  if missing), applies `schema.sql` idempotently, and is called lazily by
  the health route — proving the DB path works without requiring a
  separate migration step yet.
- Frontend: `App.jsx` calls the backend's `/api/health` via
  `src/api/client.js` on mount and renders loading / error / success
  states, proving frontend→backend wiring end-to-end once both are
  running.
- Config is centralized in `backend/src/config/env.js` — no other backend
  file reads `process.env` directly, so later features have one place to
  extend.

DEPENDENCY JUSTIFICATION (per handoff's dependency rule):
| Package | Why | Type |
|---|---|---|
| express | Required by architecture spec | documented, standard |
| better-sqlite3 | Synchronous SQLite driver, widely used, no daemon/service needed, runs independently after `npm install` | documented, standard |
| cors | Standard Express CORS middleware | documented, standard |
| dotenv | Standard `.env` loader | documented, standard |
| react, react-dom | Required by architecture spec | documented, standard |
| vite, @vitejs/plugin-react | Required by architecture spec (Vite, not Next.js) | documented, standard |

No Claude-only, hidden, or undocumented dependency was introduced. No
package requires a running Claude session, Claude Code, or any
Claude-hosted service to function. All versions above are pinned exactly
(no `^`/`~` ranges) so a fresh `npm install` reproduces the same tree;
`package-lock.json` will be generated and committed the first time
`npm install` actually runs in a network-connected environment.

VALIDATION ACTUALLY RUN (in this sandbox, which has NO network access):
- `node --check` on every backend `.js` file — all passed (confirms
  syntax validity only, not runtime behavior).
- Confirmed `node` v22.22.2 and `npm` v10.9.7 are available.
- Confirmed this sandbox cannot reach the npm registry
  (`npm install --dry-run` → `403 Forbidden` on `registry.npmjs.org`),
  so dependency installation genuinely could not be attempted here.

VALIDATION NOT RUN (requires a network-connected environment, e.g. your
machine or Claude Code with network access):
- `npm install` in `backend/` and `frontend/` (untested — no registry access here)
- `npm test` (backend/test/health.test.js) — written, not executed
- `npm run dev` for backend or frontend — not started
- `npm run build` for frontend (Vite build) — not run
- End-to-end browser check of the health page — not performed
- No `package-lock.json` exists yet for either package — will be created
  by the first real `npm install`

KNOWN LIMITATIONS:
- SQLite schema currently contains only a `schema_meta` bookkeeping table.
  Feature tables (users, strategies, orders, etc.) are intentionally not
  created yet — they belong to their own future checkpoints.
- No authentication exists yet (Checkpoint: Authentication, next).
- No git repository has been initialized in this environment.

GITHUB COMMIT: NOT DONE — no git repository exists in this sandbox yet,
and this sandbox has no network access to reach GitHub even if one did.
GITHUB PUSH: NOT DONE, for the same reason.

NEXT FEATURE: Initialize git locally, do a full pre-commit secrets/.gitignore
audit against the file list above, and — once you're in a git+network
capable environment (your machine or Claude Code) — create the actual
initial commit and push the safe baseline to GitHub. After that: Checkpoint
2, Authentication (admin bootstrap + forced password change).

---

## CHECKPOINT: Authentication (admin bootstrap + forced password change)

FEATURE: Application login separate from Kotak login. Single admin
account, created automatically on first run only. Forced password change
on first login. Sessions server-side, tokens hashed at rest. No public
registration exists anywhere.

STATUS: PARTIALLY COMPLETE — same reason as the foundation checkpoint:
implementation + static validation done; real runtime execution
(`npm install`/`npm test`) still blocked by this sandbox having no network
access (re-confirmed below). The test suite is written and, by inspection,
exercises every acceptance criterion in the handoff's Authentication
section — but "written" is not "passed," so it is not marked COMPLETE.

FILES CHANGED:
```
backend/package.json                                  (added bcryptjs, cookie-parser)
backend/server.js                                      (wired cookie-parser, auth routes, startup bootstrap)
backend/src/db/connection.js                            (added migration runner)
backend/src/db/migrations/002_add_auth_tables.sql       (new: users, sessions tables)
backend/src/services/adminBootstrap.js                  (new)
backend/src/services/sessionService.js                  (new)
backend/src/services/writeInitialAdminCredentialsFile.js (new)
backend/src/middleware/auth.js                          (new)
backend/src/routes/auth.js                              (new)
backend/test/auth.test.js                               (new)
```

INTEGRATION:
- `server.js` startup (only when run directly, not on require by tests):
  opens DB → runs migrations → `ensureAdminBootstrap` → if a new admin was
  created, writes `INITIAL_ADMIN_CREDENTIALS.txt` (gitignored) and warns
  in the console → starts listening.
- `/api/auth/login`, `/logout`, `/me`, `/change-password` mounted at
  `/api/auth`, using `requireAuth` middleware backed by `sessionService`.
- `requirePasswordChangeComplete` middleware is implemented and exported
  now, ready to guard trading routes in later checkpoints — no trading
  routes exist yet, so it isn't attached anywhere yet (nothing invented
  ahead of its feature).
- Old password/session stops working immediately on password change:
  `change-password` calls `destroyAllSessionsForUser` (including the
  session used for that very request) before issuing one fresh session.

DEPENDENCY JUSTIFICATION (new packages only):
| Package | Why | Type |
|---|---|---|
| bcryptjs | Password hashing. Pure-JS (no native compilation step), widely used, actively maintained, works identically on any VPS after `npm install` | documented, standard |
| cookie-parser | Standard Express cookie middleware, used only to read the session cookie | documented, standard |

Both are pinned exact versions. Neither requires Claude, a Claude session,
or any hosted service — sessions and password hashing run entirely inside
the deployed Node process.

VALIDATION ACTUALLY RUN:
- `node --check` on all 12 backend `.js` files (foundation + auth) — all pass.
- Re-ran the `.gitignore` proof from the foundation checkpoint, this time
  simulating the actual artifacts THIS feature produces at runtime
  (`INITIAL_ADMIN_CREDENTIALS.txt`, `owner_trading.db` + its `-wal`/`-shm`
  files, `backend/node_modules/bcryptjs/`) — confirmed all excluded, only
  the 26 real source files would be staged.
- Re-confirmed this sandbox still has no network access
  (`npm install bcryptjs` → `403 Forbidden` from `registry.npmjs.org`).

VALIDATION NOT RUN (needs a network-connected environment):
- `npm install` (bcryptjs, cookie-parser are not yet actually installed
  anywhere — this sandbox never had network access to fetch them)
- `npm test` — `backend/test/auth.test.js` is written (login, wrong
  password, forced-change flow, session rotation, old-session/old-password
  rejection, bootstrap idempotency) but has never actually executed
- Manual end-to-end check of the login → change-password flow through the
  browser/frontend (no login UI exists yet — that's Frontend Audit /
  Login page, a later checkpoint per the handoff's own ordering)

KNOWN LIMITATIONS:
- No frontend login page yet — this checkpoint is backend-only, matching
  "one logical feature at a time." The frontend Login/AuthContext work is
  its own upcoming checkpoint.
- `requirePasswordChangeComplete` has no route to protect yet (no trading
  routes exist). It will be attached to Strategy/Order/Settings routes
  when those checkpoints are built — noting this now so a future session
  doesn't forget to wire it in.
- Encryption-at-rest for persisted secrets applies to Kotak credentials
  (checkpoint 3, not yet built) — password hashes here use bcrypt, which
  is the correct one-way hash for passwords, not "encryption at rest" in
  the reversible sense the handoff means for broker secrets.

GITHUB COMMIT: NOT DONE — no network in this sandbox.
GITHUB PUSH: NOT DONE — same reason.

NEXT FEATURE: Frontend Login page + AuthContext + forced-password-change
redirect, wired to these exact endpoints (matches handoff's own next step:
"Full Frontend Audit" starts with Login).

---

## CHECKPOINT: Frontend Login + AuthContext + forced-password-change redirect

FEATURE: React frontend authentication wiring — Login page, AuthContext,
ProtectedRoute guard, forced password-change redirect, Dashboard as the
protected landing page. Matches backend `/api/auth/*` from the previous
checkpoint exactly (no invented endpoints).

STATUS: PARTIALLY COMPLETE — implementation done and syntax-validated with
a real JSX parser (see below), but never actually run in a browser or
built with Vite, because this sandbox still has no network access to
install react-router-dom or any other dependency (re-confirmed below).

FILES CHANGED:
```
frontend/package.json                       (added react-router-dom)
frontend/src/api/client.js                  (rewritten: shared request() helper, credentials:'include', + login/logout/getMe/changePassword)
frontend/src/context/AuthContext.jsx        (new)
frontend/src/routes/ProtectedRoute.jsx      (new)
frontend/src/pages/LoginPage.jsx            (new)
frontend/src/pages/ChangePasswordPage.jsx   (new)
frontend/src/pages/DashboardPage.jsx        (new — the old App.jsx health-check UI moved here, not deleted)
frontend/src/App.jsx                        (rewritten: now the router shell only)
```

INTEGRATION:
- `App.jsx` → `BrowserRouter` → `AuthProvider` → `Routes`: `/login` public,
  `/` and `/change-password` behind `ProtectedRoute`.
- `AuthContext` calls `GET /api/auth/me` once on mount to establish auth
  state from the existing session cookie (so a page refresh doesn't lose
  login), and exposes `login`/`logout`/`onPasswordChanged`.
- `ProtectedRoute`: no session → redirect to `/login` (preserving the
  attempted location); session but `mustChangePassword` → redirect to
  `/change-password` from anywhere else.
- `ChangePasswordPage` calls the same `/api/auth/change-password` built
  last checkpoint, then calls `onPasswordChanged()` so the redirect clears
  without waiting on a second `/me` round trip.
- `DashboardPage` is the old foundation health-check page, relocated (not
  rewritten) behind the login wall, now also showing the signed-in
  username and a logout button.
- api client now sends `credentials: 'include'` on every request, which
  is required for the browser to send the `ot_session` cookie back to the
  Express backend's separate origin (`:5173` → `:4000`); backend CORS
  already had `credentials: true` configured in the foundation checkpoint,
  so no backend change was needed for this.

DEPENDENCY JUSTIFICATION (new package):
| Package | Why | Type |
|---|---|---|
| react-router-dom | Standard, most widely used React routing library; needed for the login/protected-route split. Pure JS, no native build step, runs independently after `npm install` | documented, standard |

Pinned exact version (`6.26.2`), no Claude/hosted-service runtime dependency.

VALIDATION ACTUALLY RUN:
- All 8 changed/new frontend files parsed with a **real JSX parser**
  (esbuild transform mode — a general-purpose tool already present in
  this sandbox for unrelated reasons, used here only to validate syntax;
  it is NOT a project dependency and is not referenced anywhere in
  `package.json`) — all 8 pass with zero syntax errors.
- Backend's existing 12 files re-checked with `node --check` — still all
  pass (confirms this feature didn't touch/break the backend).
- Re-ran the `.gitignore` staging proof, this time simulating
  `frontend/node_modules/react-router-dom/` and a `frontend/dist/` Vite
  build output — both correctly excluded; only the 29 real source files
  would be staged.
- Re-confirmed no network access (`npm install` on frontend → `403` from
  the registry).

VALIDATION NOT RUN (needs a network-connected environment):
- `npm install` in `frontend/` — react-router-dom has never actually been
  installed anywhere
- `npm run dev` / opening the app in an actual browser
- `npm run build` (Vite production build)
- Manual click-through of: login with temp password → forced redirect to
  `/change-password` → submit → redirect to `/` → refresh page stays
  logged in → logout → `/` redirects back to `/login`
- The backend's own `npm test` (auth.test.js) is also still unexecuted,
  carried over from the previous checkpoint — nothing in this checkpoint
  changed that status

KNOWN LIMITATIONS:
- No "forgot password" flow — not in scope for this checkpoint or the
  handoff's requirements for it.
- Styling is inline and intentionally minimal, per "keep UI minimal."
- Settings page, Strategy pages, Kotak connection UI do not exist yet —
  each is its own future checkpoint per the handoff's own ordering.

GITHUB COMMIT: NOT DONE — no network in this sandbox.
GITHUB PUSH: NOT DONE — same reason.

NEXT FEATURE: Backend Kotak Neo credential storage (Settings API) —
server-side only, encrypted at rest, masked in any response to the
frontend — per handoff section 3, before building the Settings UI that
calls it.

---

## CHECKPOINT: Kotak credential storage (backend)

FEATURE: Encrypted-at-rest storage for Kotak Neo credentials
(consumerKey, ucc, mobileNumber, mpin, totpSecret) with masked reads.
Storage only — no Kotak endpoint is called anywhere in this checkpoint.

STATUS: PARTIALLY COMPLETE (implemented + statically/logically validated;
never run with real dependencies installed — see below).

FILES: `backend/src/db/migrations/003_add_broker_credentials.sql`,
`backend/src/services/encryption.js`,
`backend/src/services/brokerCredentialService.js`,
`backend/src/routes/broker.js`, `backend/test/broker.test.js`; wired into
`server.js` at `/api/broker`.

FIELD NAMES — sourced, not guessed: consumerKey/ucc/mobileNumber/mpin
match the current officially-maintained `kotakneoapi` SDK's own login
sample (`totp_login(mobile_number, ucc, totp)`,
`totp_validate(mpin)`), confirmed via web search at the time this
checkpoint was built. `totpSecret` stores the TOTP *seed* (20-25 char,
issued once at TOTP setup) — not the rotating 6-digit code, which is
generated on demand and never stored. `consumer_secret`/`password` were
found to be legacy/unused in the current flow and were deliberately
excluded.

VALIDATION ACTUALLY RUN:
- `node --check` on all files — pass.
- **Standalone AES-256-GCM round-trip test using only Node's built-in
  `crypto`** (run directly via `node -e`, not through the app's own file,
  since that file transitively requires `dotenv`, which isn't installed):
  confirmed encrypt→decrypt returns the original object, and confirmed a
  tampered ciphertext is correctly rejected by GCM's auth tag rather than
  silently decrypting to garbage.
- `.gitignore` re-audit including this feature's actual runtime artifacts
  (`INITIAL_ADMIN_CREDENTIALS.txt`, DB + WAL/SHM files,
  `node_modules/bcryptjs/`) — all correctly excluded.
- Re-confirmed no network access.

VALIDATION NOT RUN: `npm install` (bcryptjs/cookie-parser/better-sqlite3
never actually installed), `npm test` (`broker.test.js` written —
password-change gate, masked reads, field validation, round-trip
integrity via `getRawCredentials`, delete — but never executed).

KNOWN LIMITATION: this is storage only. No code anywhere calls a Kotak
endpoint. That is intentional — see PROJECT STATUS SUMMARY above.

GITHUB: NOT DONE (no network).

---

## CHECKPOINT: Trading safety gates (PAPER/LIVE mode, emergency stop)

FEATURE: Global trading-state safety gates — separate from and gating
everything a future strategy/order system will do. `trading_mode`
(PAPER/LIVE), `live_enabled` (explicit confirmed switch, independent of
mode), `emergency_stop` (global kill switch). LIVE is forced OFF on every
server startup regardless of what was persisted, so it can never
auto-resume after a restart/crash.

STATUS: PARTIALLY COMPLETE (implemented + validated as far as this
sandbox allows; never run with real dependencies).

FILES: `backend/src/db/migrations/004_add_trading_state.sql`,
`backend/src/services/tradingStateService.js`,
`backend/src/routes/trading.js`, `backend/test/trading.test.js`; wired
into `server.js` at `/api/trading`, plus a startup call to
`forceLiveDisabledOnStartup()` before the server accepts any requests.

`isLiveOrderAllowed(db)` is exported as the single choke point any future
order-placement code must call. No order system exists yet to call it —
it's provided now specifically so that future code has no excuse to
reimplement (and possibly get wrong) this check.

VALIDATION ACTUALLY RUN: `node --check` on all files (19/19 backend files
pass); `.gitignore` re-audit; re-confirmed no network.

VALIDATION NOT RUN: `npm test` (`trading.test.js` covers: default state,
cannot enable live outside LIVE mode, confirmation required, emergency
stop force-disables live, live-enable refused during emergency stop,
clearing the stop does NOT restore live_enabled, `isLiveOrderAllowed()`
truth table, and the startup-reset function — all written, none executed).

GITHUB: NOT DONE (no network).

---

## CHECKPOINT: Settings + Trading Control frontend pages

FEATURE: Closed a real integration gap — the two checkpoints above had
zero frontend UI, violating "no backend feature left disconnected."
Added `SettingsPage.jsx` (Kotak credential form, masked-only display,
disconnect button) and `TradingControlPage.jsx` (mode switch, live-enable
with a confirmation dialog, emergency stop / clear), both linked from the
Dashboard nav and wired to the exact `/api/broker/*` and `/api/trading/*`
endpoints built above — no invented endpoints.

STATUS: PARTIALLY COMPLETE (implemented + real-JSX-parser validated;
never opened in an actual browser).

FILES: `frontend/src/pages/SettingsPage.jsx`,
`frontend/src/pages/TradingControlPage.jsx`; `frontend/src/api/client.js`
extended with the broker/trading functions; `App.jsx` routes added;
`DashboardPage.jsx` nav links added.

VALIDATION ACTUALLY RUN: all 10 frontend files parsed with the real
esbuild JSX parser (validation-only tool, not a project dependency) —
zero syntax errors. Cross-checked every backend route against every
frontend `client.js` call by grepping both and comparing — all 14
backend endpoints have exactly one matching frontend call, no orphans
either direction.

VALIDATION NOT RUN: opening this in an actual browser, clicking through
the Settings form or Trading Control buttons for real.

GITHUB: NOT DONE (no network).

---

## CHECKPOINT: Production deployment (deploy.sh, DEPLOYMENT.md, templates)

FEATURE: `deploy/deploy.sh` (install/build/setup-env/setup-systemd/
setup-nginx/start/stop/restart/status/logs/update/all),
`deploy/owner-trading.service.template` (systemd unit, hardened),
`deploy/nginx.conf.template` (reverse proxy + SPA fallback), and
`DEPLOYMENT.md` (exact VPS commands end to end, security checklist).

STATUS: PARTIALLY COMPLETE — the script's logic is real and largely
executable-in-principle, but only the parts that don't need root/network/
a real systemd or Nginx install could actually be run here.

VALIDATION ACTUALLY RUN:
- `bash -n deploy/deploy.sh` — syntax valid.
- **Actually executed `./deploy/deploy.sh setup-env`** in this sandbox:
  confirmed it creates `backend/.env` and `frontend/.env` from their
  `.env.example` files, confirmed re-running it is a no-op on an existing
  `.env` (genuine idempotency proof, not just read-and-assume), then
  deleted the test-generated files before packaging (they must never ship
  in the repo/zip).
- `.gitignore` re-audit including deploy-generated artifacts specifically
  (`backend/.env`, `frontend/.env`, `backend/data/backend.pid`,
  `backend/logs/backend.out.log`) — all correctly excluded.

VALIDATION NOT RUN (needs a real VPS): `install`, `build`, `start`,
`setup-systemd` (needs root + systemd), `setup-nginx` (needs root + nginx
+ a real domain), `update`. These were written carefully and reviewed,
but "written carefully" is not "executed successfully" — do not treat
this script as proven until it's actually been run on a real VPS.

GITHUB: NOT DONE (no network).

---

## How to actually get this onto GitHub

This chat environment cannot run `git push` (no network). To finish the
baseline checkpoint for real:

1. Download the project files from this chat.
2. On your machine (or in Claude Code), from the project root:
   ```bash
   git init
   git add .
   git status              # re-verify nothing secret is staged
   git commit -m "Foundation: Express + React/Vite + SQLite skeleton"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
3. Run the validation that couldn't run here:
   ```bash
   cd backend && npm install && npm test
   cd ../frontend && npm install && npm run build
   ```
4. Update this file's checkpoint to COMPLETE with the real commit hash and
   actual test/build results once that's done.
