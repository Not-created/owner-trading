# Deploying Owner Trading to a VPS

This covers a fresh Ubuntu/Debian-style VPS.

## 0. What you need before starting

- A VPS with SSH access and a sudo-capable user
- Node.js 18+ and Python 3.9+ (installed below if missing)
- A domain name pointed at the VPS (for HTTPS - optional if testing on
  the bare IP over HTTP only)

## 1. Install Node.js and Python (if not already present)

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs python3 python3-venv python3-pip
node -v && python3 --version
```

## 2. Get the code onto the VPS

```bash
git clone <your-repo-url> owner-trading
cd owner-trading
# or: unzip owner-trading-*.zip && cd owner-trading
```

## 3. One-command deploy

```bash
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

Running it with **no arguments** does everything: installs Node
dependencies for backend + frontend, creates a Python virtual environment
and installs the official `kotakneoapi` SDK into it, generates
`backend/.env`, `frontend/.env`, and `kotak_service/.env` with freshly
random **infrastructure** secrets (SESSION_SECRET, CREDENTIAL_ENCRYPTION_KEY,
KOTAK_SERVICE_SECRET) - never your Kotak broker credentials, which this
script never touches - builds the frontend, installs systemd services for
both the backend and the Kotak integration microservice, starts both, and
runs a health check against each. It asks for your sudo password once
(needed to install the systemd units) - that is the only interaction
required.

Re-running `./deploy/deploy.sh` at any time is safe: it never overwrites
an existing .env, database, or running service's data.

Every step is also its own command if you want to run one individually
for debugging: `./deploy/deploy.sh setup-python`, `./deploy/deploy.sh
build`, `./deploy/deploy.sh health-check`, etc. Run with no arguments to
see the full list in the script's own header.

## 4. What deploy.sh cannot do for you

- **Set a real domain**: edit FRONTEND_ORIGIN in backend/.env once you
  have one, then re-run `./deploy/deploy.sh build` (Vite bakes
  VITE_API_BASE_URL in at build time - set that in frontend/.env too).
- **HTTPS**: once you have a domain,
  ```bash
  sudo apt-get install -y nginx certbot python3-certbot-nginx
  DOMAIN=yourdomain.com sudo -E ./deploy/deploy.sh setup-nginx
  sudo certbot --nginx -d yourdomain.com
  ```
  After HTTPS is live, confirm NODE_ENV=production (already set by
  setup-env) and set FRONTEND_ORIGIN=https://yourdomain.com, then
  `./deploy/deploy.sh restart`.
- **Your Kotak broker credentials**: log in (see below), go to
  Settings, and enter your real consumer key, UCC, mobile number, MPIN,
  and TOTP seed there. This is deliberate - the deploy script must never
  see or touch real broker credentials.

## 5. First login

On first run, an admin account is created automatically. Find its
temporary password:

```bash
./deploy/deploy.sh logs
cat backend/INITIAL_ADMIN_CREDENTIALS.txt
```

Log in, complete the forced password change immediately, then:

```bash
rm backend/INITIAL_ADMIN_CREDENTIALS.txt
```

## 6. Connect your Kotak account

Go to Settings, enter your credentials, and click Save & Connect. This
performs a real authentication attempt (TOTP login -> MPIN validate -> a
read-only verification call) against Kotak through the internal Python
integration service. The connection status shown (CONNECTED / AUTH_FAILED
/ SESSION_EXPIRED / CONNECTION_ERROR) reflects the real outcome - a
successful save never implies a working connection by itself.

**Important limitation, stated plainly**: two Kotak capabilities -
modifyOrder and live quotes (getQuote) - require a Kotak
"instrument_token" from their scrip master, which this project does not
implement (no symbol/token lookup exists). Order placement, cancellation,
status, positions, and holdings do not need this and are implemented.
See backend/src/brokers/kotakBrokerAdapter.js for the exact detail.

## 7. Day-to-day operations

```bash
./deploy/deploy.sh status        # both services
./deploy/deploy.sh logs          # tail both services' logs
./deploy/deploy.sh restart       # restart both services
./deploy/deploy.sh health-check  # curl both /health endpoints
./deploy/deploy.sh update        # git pull + reinstall + rebuild + restart
```

## 8. Security checklist before going live

- [ ] backend/.env, kotak_service/.env have real generated secrets (done
      automatically by setup-env - verify they are not the .env.example
      placeholders)
- [ ] INITIAL_ADMIN_CREDENTIALS.txt deleted after first login
- [ ] NODE_ENV=production set (done automatically)
- [ ] HTTPS is active before entering real Kotak credentials
- [ ] Firewall allows only 80/443 (and SSH) from the public internet -
      neither the backend's port (4000) nor the Kotak service's port
      (5055, bound to 127.0.0.1 only regardless) should be reachable
      from outside; only Nginx should reach the backend, over 127.0.0.1
- [ ] Regular filesystem backups of backend/data/owner_trading.db (stop
      the service or use SQLite's backup API for a consistent copy)

## 9. What this deployment does NOT make LIVE-ready by itself

Deploying this project does not verify Kotak connectivity for you - that
requires your real credentials, entered through Settings, and depends on
your actual Kotak account being active and correctly configured for API
access. See PROGRESS.md and FINAL_IMPLEMENTATION_REPORT.md for the exact,
current, honest state of what has and has not been verified against a
real Kotak account.
