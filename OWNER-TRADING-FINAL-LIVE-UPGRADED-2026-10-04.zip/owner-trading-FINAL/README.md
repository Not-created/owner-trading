# Owner Trading

Owner Trading is a private, single-user, LIVE algorithmic trading platform for Kotak Neo.

## Runtime architecture

React/Vite → Node/Express → Python broker service → official Kotak Neo SDK 3.0.7 → Kotak.
SQLite stores orders, fills, positions, strategies, signals, risk and audit data.

Backtest is historical analysis only and never reaches the live order API. The production execution path is LIVE-only; there is no executable PAPER/simulator path.

## Latest release validation

The latest Phase A–D release audit is documented in `FINAL_PHASE_A_D_LIVE_FIX_REPORT.md`. The current broker-service regression suite passes 305 tests with 3 expected skips.

## Deployment

```bash
./deploy.sh
```

Deployment installs dependencies, configures systemd/Nginx, runs migrations/build/tests and performs health checks. It does not place orders or arm an algorithm.

After deployment, enter Kotak credentials in Settings, connect the account, configure risk limits, reconcile, create/validate a strategy and explicitly arm the selected strategy from the protected UI.

## Safety

Every live order is subject to broker/session/feed/reconciliation/risk/emergency-stop/idempotency gates. Unknown broker outcomes and pending submissions require reconciliation and are never blindly retried. Strategy execution is bound by the immutable Strategy Version → Signal → Internal Order → Broker Order → Trade → Position → Exit chain.
