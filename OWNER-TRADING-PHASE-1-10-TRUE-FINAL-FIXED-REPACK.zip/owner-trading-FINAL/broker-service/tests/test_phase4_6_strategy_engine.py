import unittest
from app.strategy_engine import validate_strategy, indicators, run_backtest

class Phase46StrategyTests(unittest.TestCase):
    def setUp(self):
        self.candles=[]
        for i in range(100):
            p=100+(i*0.35)
            self.candles.append({'candle_at':f'2026-01-01 09:{i%60:02d}:00','open':p,'high':p+1,'low':p-1,'close':p+0.4,'volume':100+i})
    def test_indicator_stack(self):
        x=indicators(self.candles)
        for k in ('macd','macd_signal','macd_hist','adx14','vwap','rsi14','atr14'):
            self.assertIn(k,x)
    def test_validation_rejects_invalid_definition(self):
        errors=validate_strategy({'side':'NOPE','entry':{'op':'X','conditions':[]},'exit':{'op':'OR','conditions':[]},'execution':{'product':'BO'}})
        self.assertGreaterEqual(len(errors),4)
    def test_validation_rejects_wrong_protective_levels_and_multiple_sizing_modes(self):
        d={'timeframe':'5m','side':'BUY','entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':1}]},'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':1}]},'risk':{'stop_loss':110,'target':105},'position_sizing':{'quantity':1,'capital_pct':10}}
        errors=validate_strategy(d)
        self.assertTrue(any('stop_loss below target' in x for x in errors))
        self.assertTrue(any('only one of quantity' in x for x in errors))
    def test_validation_rejects_conflicting_stop_modes_and_missing_risk_stop(self):
        base={'timeframe':'5m','side':'BUY','entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':1}]},'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':1}]}}
        errors=validate_strategy(base | {'risk':{'stop_loss_pct':1,'stop_atr_multiple':2},'position_sizing':{'quantity':1}})
        self.assertTrue(any('only one stop-loss mode' in x for x in errors))
        errors=validate_strategy(base | {'risk':{'target_pct':2},'position_sizing':{'risk_per_trade':500}})
        self.assertTrue(any('risk_per_trade sizing requires a stop-loss mode' in x for x in errors))

    def test_validation_rejects_negative_cooldown(self):
        d={'timeframe':'5m','side':'BUY','entry':{'op':'AND','conditions':[{'left':'close','operator':'>','right':1}]},'exit':{'op':'OR','conditions':[{'left':'close','operator':'<','right':1}]},'risk':{'stop_loss_pct':1},'position_sizing':{'quantity':1},'execution':{'product':'MIS','cooldown_bars':-1}}
        self.assertTrue(any('cooldown_bars' in x for x in validate_strategy(d)))

    def test_backtest_supports_sell_and_risk_exits(self):
        d={'timeframe':'5m','side':'SELL','entry':{'op':'AND','conditions':[{'left':'ema20','operator':'>','right':'ema50'}]},'exit':{'op':'OR','conditions':[{'left':'rsi14','operator':'<','right':45}]},'risk':{'stop_loss_pct':1,'target_pct':2,'trailing_stop_pct':0.5,'time_exit_bars':5},'position_sizing':{'quantity':2},'execution':{'product':'MIS'}}
        self.assertEqual(validate_strategy(d),[])
        result=run_backtest(self.candles,d,'TEST')
        self.assertEqual(result['side'],'SELL')
        self.assertTrue(result['total_trades']>=0)
        self.assertEqual(len(result['equity_curve']),len(self.candles))
        self.assertEqual(result['risk_metric_basis'],'daily_realized_portfolio_returns_annualized_252')

if __name__=='__main__':unittest.main()
