"""Instrument-universe synchronisation and explicit live-feed subscriptions.

The scrip master is metadata, not a live-feed universe.  Live SFeed
subscriptions are opt-in and are limited to instruments explicitly selected
by the owner/strategy.  This prevents an NSE cash metadata refresh from
silently subscribing thousands of instruments.
"""
from __future__ import annotations
import asyncio, csv, io, urllib.request, datetime as dt
from . import db
from .broker_client import broker_client
from .websocket_manager import websocket_manager

MAX_SFEED_SUBSCRIPTIONS = 3000

def _field(row, *names):
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return None

async def sync_nse_cash_and_subscribe(limit=0, instrument_tokens=None):
    """Download, validate and atomically import the official NSE cash scrip master.

    Metadata refresh never owns the web-session lifecycle and never subscribes
    the whole market. Explicit live tokens are subscribed only after the DB
    import succeeds.
    """
    try:
        out = await asyncio.get_running_loop().run_in_executor(
            None, lambda: broker_client.read("scrip_master", exchange_segment="nse_cm")
        )
    except Exception as exc:
        return {"ok": False, "stage": "scrip_master_request", "error": f"Kotak scrip_master request failed: {type(exc).__name__}: {exc}"}
    if not out.ok:
        return {"ok": False, "stage": "scrip_master_request", "error": out.message or "Kotak scrip_master request failed."}

    url = out.data if isinstance(out.data, str) else None
    if not url:
        return {"ok": False, "stage": "scrip_master_response", "error": "Kotak scrip_master did not return the NSE cash file URL."}

    try:
        raw = await asyncio.get_running_loop().run_in_executor(
            None, lambda: urllib.request.urlopen(url, timeout=45).read()
        )
    except Exception as exc:
        return {"ok": False, "stage": "csv_download", "error": f"NSE cash CSV download failed: {type(exc).__name__}: {exc}"}

    try:
        text = raw.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise ValueError("CSV has no header row")
        required = {"psymbol", "ptrdsymbol"}
        normalized = {str(x).strip().lower() for x in reader.fieldnames if x}
        if not required.issubset(normalized):
            raise ValueError("required columns pSymbol/pTrdSymbol are missing")
        rows = list(reader)
    except Exception as exc:
        return {"ok": False, "stage": "csv_parse", "error": f"NSE cash CSV parsing failed: {type(exc).__name__}: {exc}"}

    parsed = []
    by_token = {}
    rejected = 0
    for r in rows:
        tok = _field(r, "pSymbol", "instrument_token", "token", "symbol_token")
        sym = _field(r, "pTrdSymbol", "trading_symbol", "tradingsymbol", "symbol")
        if not tok or not sym:
            rejected += 1
            continue
        itype = (_field(r, "pInstType", "instrument_type", "instrument") or "").upper()
        if itype and itype not in ("EQ", "EQUITY", "CASH"):
            continue
        tok, sym = str(tok).strip(), str(sym).strip()
        name = _field(r, "pCompanyName", "company_name", "pSymbolName", "name")
        parsed.append({
            "trading_symbol": sym, "instrument_token": tok, "name": name,
            "instrument_type": itype or "EQ", "expiry": _field(r, "pExpiryDate", "expiry"),
            "strike": _field(r, "pStrikePrice", "strike"), "option_type": _field(r, "pOptionType", "option_type"),
            "lot_size": _field(r, "pLotSize", "lot_size"), "tick_size": _field(r, "pTickSize", "tick_size"),
        })
        by_token[tok] = sym

    try:
        imported = db.bulk_upsert_instruments(parsed)
    except Exception as exc:
        return {"ok": False, "stage": "sqlite_import", "error": f"NSE metadata SQLite import failed: {type(exc).__name__}: {exc}", "parsed": len(parsed), "rejected": rejected}

    requested_tokens = [str(x).strip() for x in (instrument_tokens or []) if str(x).strip()]
    requested_tokens = list(dict.fromkeys(requested_tokens))
    requested_limit = int(limit or 0)
    if not requested_tokens and requested_limit > 0:
        requested_tokens = list(by_token.keys())[:min(requested_limit, MAX_SFEED_SUBSCRIPTIONS)]
    if len(requested_tokens) > MAX_SFEED_SUBSCRIPTIONS:
        return {"ok": False, "stage": "subscription_validation", "error": f"Requested live universe has {len(requested_tokens)} instruments; SFeed allows at most {MAX_SFEED_SUBSCRIPTIONS}.", "synced": imported}
    invalid = [t for t in requested_tokens if t not in by_token]
    if invalid:
        return {"ok": False, "stage": "subscription_validation", "error": f"{len(invalid)} requested instrument token(s) were not found in the NSE cash scrip master.", "invalid_tokens": invalid[:20], "synced": imported}

    subscribed = rejected_subs = 0
    for tok in requested_tokens:
        try:
            await websocket_manager.subscribe("nse_cm", tok)
            subscribed += 1
        except Exception:
            rejected_subs += 1
    db.set_algo_runtime(universe_count=imported, status="RUNNING")
    return {
        "ok": rejected_subs == 0, "stage": "complete" if rejected_subs == 0 else "subscription",
        "synced": imported, "candidateCount": len(requested_tokens), "subscribed": subscribed,
        "rejected": rejected_subs, "rejected_metadata_rows": rejected,
        "subscriptionLimit": MAX_SFEED_SUBSCRIPTIONS, "metadataOnly": not bool(requested_tokens),
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    }

