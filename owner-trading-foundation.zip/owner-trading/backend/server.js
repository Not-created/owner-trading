require("dotenv").config();

const createApp = require("./src/app");
const config = require("./src/config");
const passwordStore = require("./src/services/passwordStore");

const app = createApp();

app.listen(config.port, () => {
  console.log(`[owner-trading] backend listening on port ${config.port} (env: ${config.env})`);
  if (!passwordStore.hasPasswordConfigured()) {
    console.warn(
      "[owner-trading] WARNING: no access password is configured yet. " +
        "Run the deployment setup (deployment/deploy.sh) or " +
        "`node deployment/set-password.js` before exposing this server."
    );
  }
});
