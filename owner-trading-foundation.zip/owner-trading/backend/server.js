require("dotenv").config();

const createApp = require("./src/app");
const config = require("./src/config");
const passwordStore = require("./src/services/passwordStore");
const { run: runMigrations } = require("./src/db/migrate");
const { markReady, markDegraded } = require("./src/services/readiness");

// Migrations are idempotent (see src/db/migrate.js) -- running them on
// every boot is safe and means a fresh deploy never needs a separate manual
// migration step.
try {
  runMigrations();
} catch (err) {
  console.error("[owner-trading] migration run failed at startup:", err.message);
  markDegraded();
}

const app = createApp();

app.listen(config.port, () => {
  console.log(`[owner-trading] backend listening on port ${config.port} (env: ${config.env})`);
  markReady();

  if (!passwordStore.hasPasswordConfigured()) {
    console.warn(
      "[owner-trading] WARNING: no access password is configured yet. " +
        "Run ./deploy.sh from the project root, or " +
        "`node deployment/set-password.js`, before exposing this server."
    );
  }
});

process.on("SIGTERM", () => {
  console.log("[owner-trading] received SIGTERM, shutting down gracefully");
  process.exit(0);
});
process.on("SIGINT", () => {
  console.log("[owner-trading] received SIGINT, shutting down gracefully");
  process.exit(0);
});
