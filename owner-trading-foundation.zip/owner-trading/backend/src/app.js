const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const cors = require("cors");

const config = require("./config");
const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");

function createApp() {
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", 1); // correct secure-cookie behavior behind a reverse proxy

  app.use(express.json());
  app.use(cookieParser());

  // In production the frontend is served by this same process (see below),
  // so CORS is same-origin and this is mostly a no-op. In local development
  // the frontend dev server runs on a different port, so it's allowlisted.
  if (config.env !== "production") {
    app.use(
      cors({
        origin: true,
        credentials: true,
      })
    );
  }

  app.use(
    session({
      name: "owner_trading_sid",
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: config.env === "production",
        maxAge: config.sessionMaxAgeMs,
      },
      // NOTE: this uses express-session's default in-memory store, which is
      // fine for a single-process foundation deployment but does not
      // survive a process restart or scale across multiple instances. If
      // the deployment target changes (multi-instance, serverless), swap in
      // a persistent store (e.g. Redis) here -- no other code needs to
      // change.
    })
  );

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", env: config.env });
  });

  app.use("/api/auth", authRoutes);
  app.use("/api/dashboard", dashboardRoutes);

  // Serve the built frontend (frontend/dist) as static assets, and fall back
  // to index.html for any non-API route so client-side routing (React
  // Router) works on a hard refresh/direct URL. This lets the whole app run
  // from a single process/port in production.
  if (fs.existsSync(config.frontendDistPath)) {
    app.use(express.static(config.frontendDistPath));
    app.get(/^(?!\/api).*/, (req, res) => {
      res.sendFile(path.join(config.frontendDistPath, "index.html"));
    });
  } else {
    app.get("/", (req, res) => {
      res.status(200).send(
        "Owner Trading backend is running, but no frontend build was found at " +
          config.frontendDistPath +
          ". Run the frontend build step (see deployment/deploy.sh) first."
      );
    });
  }

  // Central error handler -- never leak stack traces or internal details to
  // the client; log server-side only, and never log request bodies (which
  // could contain the password) at this layer.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error("[owner-trading] unhandled error:", err && err.message);
    res.status(500).json({ error: "Internal server error." });
  });

  return app;
}

module.exports = createApp;
