const { getDb } = require("../db/client");

// Exactly the states specified for this phase. CONNECTED must only ever be
// set by the broker service after a real, verified Kotak session -- never
// merely because credentials exist in config.
const BROKER_STATES = Object.freeze({
  DISCONNECTED: "DISCONNECTED",
  VERIFYING: "VERIFYING",
  CONNECTED: "CONNECTED",
  AUTH_FAILED: "AUTH_FAILED",
  SESSION_EXPIRED: "SESSION_EXPIRED",
  CONNECTION_ERROR: "CONNECTION_ERROR",
  NOT_CONFIGURED: "NOT_CONFIGURED",
});

function getBrokerConnectionState() {
  const db = getDb();
  const row = db.prepare("SELECT state, last_error, last_transition_at FROM broker_connection_state WHERE id = 1").get();
  return row || { state: BROKER_STATES.NOT_CONFIGURED, last_error: null, last_transition_at: null };
}

/**
 * Persists a broker connection state transition. This is the ONLY function
 * allowed to write broker_connection_state -- callers (the broker-status
 * poller in services/brokerClient.js) must pass one of BROKER_STATES.
 */
function setBrokerConnectionState(state, lastError = null) {
  if (!Object.values(BROKER_STATES).includes(state)) {
    throw new Error(`Invalid broker connection state: ${state}`);
  }
  const db = getDb();
  db.prepare(
    `UPDATE broker_connection_state
     SET state = ?, last_error = ?, last_transition_at = datetime('now'), updated_at = datetime('now')
     WHERE id = 1`
  ).run(state, lastError);
}

function isEmergencyStopActive() {
  const db = getDb();
  const row = db.prepare("SELECT is_active FROM emergency_stop_state WHERE id = 1").get();
  return !!(row && row.is_active === 1);
}

module.exports = {
  BROKER_STATES,
  getBrokerConnectionState,
  setBrokerConnectionState,
  isEmergencyStopActive,
};
