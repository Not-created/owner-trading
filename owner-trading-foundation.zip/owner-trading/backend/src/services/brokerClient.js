const config = require("../config");
const { BROKER_STATES, getBrokerConnectionState, setBrokerConnectionState } = require("./brokerState");

/**
 * Talks to the persistent Python broker service over local HTTP only.
 * Express never talks to Kotak directly and never handles Kotak
 * credentials -- it only asks the Python service "what's your status" and
 * mirrors the answer into SQLite for the dashboard to read cheaply.
 *
 * In THIS phase, no credentials are configured anywhere, so the Python
 * service is expected to report NOT_CONFIGURED (or be unreachable, which
 * this treats as CONNECTION_ERROR rather than crashing the API).
 */
async function fetchBrokerStatus() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.brokerServiceTimeoutMs);

  try {
    const res = await fetch(`${config.brokerServiceUrl}/status`, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) {
      setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, `broker service returned HTTP ${res.status}`);
      return getBrokerConnectionState();
    }

    const body = await res.json();
    const state = Object.values(BROKER_STATES).includes(body.state) ? body.state : BROKER_STATES.CONNECTION_ERROR;
    setBrokerConnectionState(state, body.last_error || null);
    return getBrokerConnectionState();
  } catch (err) {
    clearTimeout(timeout);
    // Broker service not running/unreachable -- this is the expected state
    // for this phase (nothing has started it yet), not a fatal API error.
    setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, "broker service unreachable: " + err.message);
    return getBrokerConnectionState();
  }
}

module.exports = { fetchBrokerStatus };
