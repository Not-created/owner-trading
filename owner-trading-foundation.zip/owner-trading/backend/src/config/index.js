const path = require("path");

/**
 * Central configuration for the backend.
 *
 * Nothing sensitive lives in this file itself -- values are read from
 * environment variables at runtime (populated by deployment/deploy.sh
 * during one-click setup, or from backend/.env in local development).
 */
const config = {
  env: process.env.NODE_ENV || "development",
  port: parseInt(process.env.PORT || "4000", 10),

  // Signs/encrypts the session cookie. Must be set in production; the
  // deploy script generates a random one if missing.
  sessionSecret: process.env.SESSION_SECRET || "dev-only-insecure-secret-change-me",

  // How long an authenticated session stays valid without re-entering the
  // password (in milliseconds). Default: 12 hours.
  sessionMaxAgeMs: parseInt(process.env.SESSION_MAX_AGE_MS || "43200000", 10),

  // Where the hashed website-access password is stored. Never committed --
  // backend/src/data/secure/ is gitignored except for a .gitkeep placeholder.
  passwordHashFile:
    process.env.PASSWORD_HASH_FILE ||
    path.join(__dirname, "..", "data", "secure", "password.hash.json"),

  // Absolute path to the built frontend (frontend/dist), served as static
  // assets in production so the whole app runs from a single process/port.
  frontendDistPath:
    process.env.FRONTEND_DIST_PATH || path.join(__dirname, "..", "..", "..", "frontend", "dist"),
};

module.exports = config;
