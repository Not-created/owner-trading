const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const { getBrokerConnectionState } = require("../services/brokerState");
const { fetchBrokerStatus } = require("../services/brokerClient");

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/broker/status
 * Refreshes from the Python broker service (best-effort, short timeout)
 * then returns the current state. Never fabricates CONNECTED -- if the
 * broker service is unreachable or hasn't been configured, this reports
 * exactly that, which is what the dashboard's "Kotak Neo: Not Connected"
 * badge reads from.
 */
router.get("/status", async (req, res) => {
  const state = await fetchBrokerStatus();
  res.json({
    state: state.state,
    lastError: state.last_error,
    lastTransitionAt: state.last_transition_at,
  });
});

/**
 * GET /api/broker/status/cached
 * Same shape, but reads only what's already in SQLite -- no outbound call
 * to the broker service. Useful for a fast dashboard poll that shouldn't
 * block on the broker service's response time.
 */
router.get("/status/cached", (req, res) => {
  const state = getBrokerConnectionState();
  res.json({
    state: state.state,
    lastError: state.last_error,
    lastTransitionAt: state.last_transition_at,
  });
});

module.exports = router;
