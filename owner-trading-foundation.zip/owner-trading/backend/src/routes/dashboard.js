const express = require("express");
const requireAuth = require("../middleware/requireAuth");

const router = express.Router();

// Every route below is a FOUNDATION-STAGE PLACEHOLDER: it exists so the
// frontend has a real, working, authenticated endpoint to call for each
// dashboard section, and so future broker/API integration has a clear,
// already-wired place to plug into. None of them contain trading logic,
// broker calls, or invented data -- each responds with an explicit "not yet
// implemented" shape. Do not add real data here until the broker
// integration stage begins.
function notYetImplemented(section) {
  return (req, res) => {
    res.json({
      section,
      data: null,
      message: "Not implemented yet. Broker/API integration is a future stage.",
    });
  };
}

// All routes require an authenticated session -- verified here, server-side,
// independent of whatever the frontend does or doesn't render.
router.use(requireAuth);

router.get("/summary", notYetImplemented("dashboard-summary"));
router.get("/orders", notYetImplemented("orders"));
router.get("/trade", notYetImplemented("trade"));
router.get("/positions", notYetImplemented("positions"));
router.get("/holdings", notYetImplemented("holdings"));
router.get("/history", notYetImplemented("history"));
router.get("/strategy", notYetImplemented("strategy"));
router.get("/reports", notYetImplemented("reports"));
router.get("/analytics", notYetImplemented("analytics"));
router.get("/market-data", notYetImplemented("market-data"));
router.get("/profile", notYetImplemented("profile"));

module.exports = router;
