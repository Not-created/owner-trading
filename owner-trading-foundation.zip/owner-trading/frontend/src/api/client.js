// Thin fetch wrapper. In production the frontend is served by the same
// origin as the backend, so relative "/api/..." paths work directly; in
// local dev, Vite's proxy (see vite.config.js) forwards them to :4000.
// `credentials: "include"` ensures the session cookie is sent/received.

async function request(path, options = {}) {
  const res = await fetch(path, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch {
    // Non-JSON response — leave body null, ok/status still tell the caller enough.
  }

  return { ok: res.ok, status: res.status, body };
}

export const api = {
  login: (password) =>
    request("/api/auth/login", { method: "POST", body: JSON.stringify({ password }) }),
  logout: () => request("/api/auth/logout", { method: "POST" }),
  getSession: () => request("/api/auth/session", { method: "GET" }),
  getDashboardSection: (section) => request(`/api/dashboard/${section}`, { method: "GET" }),
  getBrokerStatus: () => request("/api/broker/status", { method: "GET" }),
  getReadiness: () => request("/api/readiness", { method: "GET" }),
};
