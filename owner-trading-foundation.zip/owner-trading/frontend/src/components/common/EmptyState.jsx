/**
 * Standard "nothing here yet" state used by every foundation-stage page.
 * Deliberately generic -- no invented data, no fake numbers, no fake
 * status. `hint` is optional supporting text (e.g. "Coming soon").
 */
export default function EmptyState({ title = "No data available", hint }) {
  return (
    <div className="empty-state">
      <div className="empty-state__dash">—</div>
      <div className="empty-state__title">{title}</div>
      {hint && <div className="empty-state__hint">{hint}</div>}
    </div>
  );
}
