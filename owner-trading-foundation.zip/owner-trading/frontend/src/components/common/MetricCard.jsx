import Icon from "./Icon";

/**
 * A metric card with no invented value -- always renders the placeholder
 * dash until real data exists (broker integration stage).
 */
export default function MetricCard({ label, icon }) {
  return (
    <div className="metric-card">
      <div className="metric-card__icon">
        <Icon name={icon} size={18} />
      </div>
      <div className="metric-card__label">{label}</div>
      <div className="metric-card__value">--</div>
    </div>
  );
}
