import Icon from "./Icon";

/**
 * A metric card with no invented value -- always renders the placeholder
 * dash and an explicit "No data available" hint until real data exists
 * (broker integration stage).
 */
export default function MetricCard({ label, icon, hint = "No data available" }) {
  return (
    <div className="metric-card">
      <div className="metric-card__icon">
        <Icon name={icon} size={18} />
      </div>
      <div className="metric-card__label">{label}</div>
      <div className="metric-card__value">--</div>
      {hint && <div className="metric-card__hint">{hint}</div>}
    </div>
  );
}
