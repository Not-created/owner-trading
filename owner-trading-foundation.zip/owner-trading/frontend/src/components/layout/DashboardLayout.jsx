import { useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { NAV_SECTIONS } from "./navConfig";
import { useAuth } from "../../context/AuthContext";
import "./layout.css";

function currentTitle(pathname) {
  const match = NAV_SECTIONS.find((item) =>
    item.path === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(item.path)
  );
  return match ? match.label : "Dashboard";
}

export default function DashboardLayout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  async function handleLogout() {
    await logout();
    navigate("/", { replace: true });
  }

  return (
    <div className="app-shell">
      <Sidebar
        open={mobileNavOpen}
        onNavigate={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      {mobileNavOpen && (
        <div
          className="app-shell__overlay"
          onClick={() => setMobileNavOpen(false)}
          aria-hidden="true"
        />
      )}

      <div className="app-shell__main">
        <Header
          title={currentTitle(location.pathname)}
          onToggleSidebar={() => setMobileNavOpen((v) => !v)}
          onLogout={handleLogout}
        />
        <main className="app-shell__content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
