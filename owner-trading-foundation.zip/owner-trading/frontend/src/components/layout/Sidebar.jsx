import { NavLink } from "react-router-dom";
import Icon from "../common/Icon";
import { NAV_SECTIONS } from "./navConfig";

export default function Sidebar({ open, onNavigate, onLogout }) {
  return (
    <aside className={`sidebar ${open ? "sidebar--open" : ""}`}>
      <div className="sidebar__brand">
        <span className="sidebar__brand-owner">OWNER</span>{" "}
        <span className="sidebar__brand-trading">TRADING</span>
        <div className="sidebar__tagline">DISCIPLINE BUILDS WEALTH</div>
      </div>

      <nav className="sidebar__nav">
        {NAV_SECTIONS.map((item) => (
          <NavLink
            key={item.key}
            to={item.path}
            end={item.path === "/dashboard"}
            className={({ isActive }) => `sidebar__link ${isActive ? "sidebar__link--active" : ""}`}
            onClick={onNavigate}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}

        <button type="button" className="sidebar__link sidebar__logout" onClick={onLogout}>
          <Icon name="logout" />
          <span>Logout</span>
        </button>
      </nav>
    </aside>
  );
}
