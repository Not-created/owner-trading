import Icon from "../common/Icon";

export default function Header({ title, onToggleSidebar, onLogout }) {
  return (
    <header className="app-header">
      <button
        type="button"
        className="app-header__menu-btn"
        onClick={onToggleSidebar}
        aria-label="Toggle navigation menu"
      >
        <Icon name="menu" size={22} />
      </button>

      <h1 className="app-header__title">{title}</h1>

      <div className="app-header__right">
        <button type="button" className="app-header__icon-btn" aria-label="Notifications" disabled>
          <Icon name="bell" size={19} />
        </button>
        <div className="app-header__user">
          <span className="app-header__avatar">
            <Icon name="user" size={16} />
          </span>
          <span className="app-header__user-label">Owner</span>
        </div>
        <button type="button" className="app-header__logout" onClick={onLogout}>
          <Icon name="logout" size={16} />
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
