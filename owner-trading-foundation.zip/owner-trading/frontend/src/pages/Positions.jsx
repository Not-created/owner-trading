import FoundationPage from "../components/common/FoundationPage";

export default function Positions() {
  return <FoundationPage title="Positions" subtitle="View your open positions." />;
}
