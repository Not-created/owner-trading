import FoundationPage from "../components/common/FoundationPage";

export default function MarketData() {
  return <FoundationPage title="Market Data" subtitle="Live and historical market data." />;
}
