import FoundationPage from "../components/common/FoundationPage";

export default function Settings() {
  return <FoundationPage title="Settings" subtitle="Manage application settings." />;
}
