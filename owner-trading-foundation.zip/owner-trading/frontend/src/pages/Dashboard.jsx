import MetricCard from "../components/common/MetricCard";
import EmptyState from "../components/common/EmptyState";

export default function Dashboard() {
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Dashboard</h2>
        <p className="page__subtitle">Foundation overview — key metrics will appear here once broker data is connected.</p>
      </div>

      <div className="metrics-grid">
        <MetricCard label="Total Equity" icon="briefcase" />
        <MetricCard label="Today's P&L" icon="activity" />
        <MetricCard label="Open Positions" icon="layers" />
        <MetricCard label="Total Orders" icon="file-text" />
      </div>

      <div className="card">
        <h3 className="card__title">Portfolio Overview</h3>
        <EmptyState title="No data available" hint="Chart will populate once broker data is connected" />
      </div>

      <div className="dashboard-grid">
        <div className="card">
          <h3 className="card__title">Recent Orders</h3>
          <EmptyState title="No data available" />
        </div>
        <div className="card">
          <h3 className="card__title">Recent Trades</h3>
          <EmptyState title="No data available" />
        </div>
      </div>
    </div>
  );
}
