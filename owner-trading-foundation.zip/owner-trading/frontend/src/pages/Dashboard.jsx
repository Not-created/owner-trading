import { useState } from "react";
import { useNavigate } from "react-router-dom";
import MetricCard from "../components/common/MetricCard";
import EmptyState from "../components/common/EmptyState";
import SystemStatusCard from "../components/common/SystemStatusCard";

const RANGES = ["1D", "1W", "1M", "3M", "1Y"];

export default function Dashboard() {
  const [range, setRange] = useState("1D");
  const navigate = useNavigate();

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Dashboard</h2>
        <p className="page__subtitle">Welcome to Owner Trading</p>
      </div>

      <div className="metrics-grid">
        <MetricCard label="Total Equity" icon="briefcase" />
        <MetricCard label="Today's P&L" icon="activity" />
        <MetricCard label="Open Positions" icon="layers" />
        <MetricCard label="Total Orders" icon="file-text" />
      </div>

      <div className="dashboard-row dashboard-row--portfolio">
        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Portfolio Overview</h3>
            <div className="range-tabs">
              {RANGES.map((r) => (
                <button
                  key={r}
                  type="button"
                  className={`range-tabs__btn ${r === range ? "range-tabs__btn--active" : ""}`}
                  onClick={() => setRange(r)}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <EmptyState
            icon="bar-chart"
            title="No portfolio data available yet"
            hint="Your portfolio summary will appear here once connected"
          />
        </div>

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Recent Orders</h3>
            <button type="button" className="card__link" onClick={() => navigate("/dashboard/orders")}>
              View All
            </button>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Symbol</th>
                <th>Type</th>
                <th>Qty</th>
                <th>Status</th>
              </tr>
            </thead>
          </table>
          <EmptyState icon="file-text" title="No recent orders" hint="Your orders will appear here" />
        </div>
      </div>

      <div className="dashboard-row dashboard-row--split">
        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Recent Trades</h3>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Symbol</th>
                <th>Type</th>
                <th>Qty</th>
                <th>Price</th>
              </tr>
            </thead>
          </table>
          <EmptyState icon="activity" title="No recent trades" hint="Your trades will appear here" />
        </div>

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Market Data</h3>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Symbol</th>
                <th>LTP</th>
                <th>Change</th>
                <th>% Change</th>
              </tr>
            </thead>
          </table>
          <EmptyState
            icon="globe"
            title="No market data"
            hint="Market data will appear here once connected"
          />
        </div>
      </div>

      <div className="dashboard-row dashboard-row--split">
        <SystemStatusCard />

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Quick Stats</h3>
          </div>
          <EmptyState title="No data available" hint="Trading stats will appear here once connected" />
        </div>
      </div>

      <div className="card">
        <div className="card__head">
          <h3 className="card__title">News &amp; Updates</h3>
        </div>
        <EmptyState title="No updates available" hint="Market news and updates will appear here" />
      </div>
    </div>
  );
}
