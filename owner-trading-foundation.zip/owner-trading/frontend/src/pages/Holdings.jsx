import FoundationPage from "../components/common/FoundationPage";

export default function Holdings() {
  return <FoundationPage title="Holdings" subtitle="View your portfolio holdings." />;
}
