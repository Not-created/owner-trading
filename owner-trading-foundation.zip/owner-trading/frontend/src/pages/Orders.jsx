import FoundationPage from "../components/common/FoundationPage";

export default function Orders() {
  return <FoundationPage title="Orders" subtitle="Track and manage your trading orders." />;
}
