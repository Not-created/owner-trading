#!/usr/bin/env bash
#
# ==============================================================================
#  OWNER TRADING -- ROOT-LEVEL ONE-CLICK DEPLOYMENT
# ==============================================================================
#
# Intended usage on a fresh VPS:
#   git pull
#   chmod +x deploy.sh      # only needed once, if execute bit wasn't preserved
#   ./deploy.sh
#
# Flow:
#   1.  Detect/verify required runtime (Node.js/npm)
#   2.  Install backend dependencies
#   3.  Install frontend dependencies
#   4.  (No database in this foundation stage -- see NOTE below)
#   5.  Prepare required directories/configuration (session secret, etc.)
#   6.  Build the frontend for production
#   7.  Prompt for the 8-character website access password
#   8.  Validate (exactly 8 characters) -- re-prompt on invalid input
#   9.  Hash and store the password server-side
#   10. Start the backend (which also serves the built frontend)
#   11. Health-check the running server
#   12. Report success
#
# The ONLY interactive input in normal operation is the access password
# (step 7). Nothing else pauses for manual input.
#
# NOTE ON DATABASE: this foundation stage has no persistent data of its own
# (no orders/positions/trades are stored yet -- that begins in the broker
# integration stage). No database/migration step is required today. The
# project structure (backend/src/config, backend/src/services) already has a
# clear place to add one later without restructuring anything.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
DEPLOYMENT_DIR="$ROOT_DIR/deployment"
ENV_FILE="$BACKEND_DIR/.env"
PASSWORD_HASH_FILE="$BACKEND_DIR/src/data/secure/password.hash.json"
PORT="${PORT:-4000}"

info()  { printf '\n\033[1;36m==>\033[0m %s\n' "$1"; }
ok()    { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
fail()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

echo "=============================================="
echo "   OWNER TRADING -- One-Click Deployment"
echo "=============================================="

# ---------- 1. Detect/verify runtime ----------
info "Checking runtime prerequisites"
command -v node >/dev/null 2>&1 || fail "Node.js is required but was not found on this machine. Install Node.js 18+ and re-run ./deploy.sh."
command -v npm  >/dev/null 2>&1 || fail "npm is required but was not found on this machine."
NODE_VERSION="$(node --version)"
ok "Node.js ${NODE_VERSION}"
ok "npm $(npm --version)"

NODE_MAJOR="$(node -e "console.log(process.versions.node.split('.')[0])")"
if [ "$NODE_MAJOR" -lt 18 ]; then
  fail "Node.js 18+ is required (found ${NODE_VERSION}). Please upgrade Node.js and re-run ./deploy.sh."
fi

# ---------- 2. Backend dependencies ----------
info "Installing backend dependencies"
(cd "$BACKEND_DIR" && npm install --no-audit --no-fund) || fail "Backend dependency install failed."
ok "Backend dependencies installed"

# ---------- 3. Frontend dependencies ----------
info "Installing frontend dependencies"
(cd "$FRONTEND_DIR" && npm install --no-audit --no-fund) || fail "Frontend dependency install failed."
ok "Frontend dependencies installed"

# ---------- 4. Database ----------
info "Database/migrations"
ok "None required for this foundation stage (skipped by design -- see deploy.sh NOTE)"

# ---------- 5. Required directories/configuration ----------
info "Preparing configuration"
mkdir -p "$BACKEND_DIR/src/data/secure"
if [ -f "$ENV_FILE" ] && grep -q '^SESSION_SECRET=' "$ENV_FILE" 2>/dev/null; then
  ok "Session secret already configured"
else
  SESSION_SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")"
  {
    echo "NODE_ENV=production"
    echo "PORT=${PORT}"
    echo "SESSION_SECRET=${SESSION_SECRET}"
  } > "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  ok "Generated session secret -> backend/.env"
fi

# ---------- 6. Build frontend ----------
info "Building frontend for production"
(cd "$FRONTEND_DIR" && npm run build) || fail "Frontend build failed."
[ -f "$FRONTEND_DIR/dist/index.html" ] || fail "Frontend build did not produce dist/index.html."
ok "Frontend build complete (frontend/dist)"

# ---------- 7-9. Password setup (the one interactive step) ----------
info "Website access password setup"
if [ -f "$PASSWORD_HASH_FILE" ]; then
  echo "  An access password is already configured on this server."
  read -r -p "  Set a new one instead? [y/N]: " RESET_PW
  RESET_PW="${RESET_PW:-N}"
else
  RESET_PW="y"
fi

if [[ "$RESET_PW" =~ ^[Yy]$ ]]; then
  while true; do
    read -r -s -p "  Set the website access password (exactly 8 characters): " PW_1
    echo
    read -r -s -p "  Confirm password: " PW_2
    echo
    if [[ "$PW_1" != "$PW_2" ]]; then
      echo "  Passwords do not match. Please try again."
      continue
    fi
    if [[ "${#PW_1}" -ne 8 ]]; then
      echo "  Password must be exactly 8 characters (was ${#PW_1}). Please try again."
      continue
    fi
    if [[ ! "$PW_1" =~ ^[A-Za-z0-9!@#\$%^\&\*\(\)_\-+=\[\]\{\}\;:,.\?]{8}$ ]]; then
      echo "  Password contains an unsupported character. Use letters, numbers, or common symbols. Please try again."
      continue
    fi
    break
  done
  printf '%s' "$PW_1" | node "$DEPLOYMENT_DIR/set-password.js" || fail "Failed to store the password hash."
  unset PW_1 PW_2
  ok "Password stored securely (hashed, server-side only)"
else
  ok "Keeping existing password"
fi

# ---------- 10. Start the backend ----------
info "Starting the application"
cd "$BACKEND_DIR"

# Stop a previous run started by this same script, if any, so re-running
# ./deploy.sh on an already-deployed server restarts cleanly instead of
# failing on a port conflict.
PID_FILE="$ROOT_DIR/.owner-trading.pid"
if [ -f "$PID_FILE" ]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "  Stopping previous instance (pid $OLD_PID)..."
    kill "$OLD_PID" 2>/dev/null || true
    sleep 1
  fi
fi

nohup npm start > "$ROOT_DIR/owner-trading.log" 2>&1 &
NEW_PID=$!
echo "$NEW_PID" > "$PID_FILE"
ok "Server process started (pid $NEW_PID), logging to owner-trading.log"

# ---------- 11. Health check ----------
info "Health check"
HEALTHY=""
for i in $(seq 1 15); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    HEALTHY="1"
    break
  fi
  sleep 1
done

if [ -z "$HEALTHY" ]; then
  echo "  Server did not respond to a health check within 15 seconds."
  echo "  Check owner-trading.log for details:"
  tail -n 30 "$ROOT_DIR/owner-trading.log" || true
  fail "Deployment did not complete successfully -- server failed its health check."
fi
ok "Server is healthy and responding on port ${PORT}"

# ---------- 12. Done ----------
echo
echo "=============================================="
echo "   Deployment complete."
echo "   Owner Trading is running on port ${PORT}."
echo "   Opening the site shows the password screen immediately."
echo "   (Point your reverse proxy / domain at 127.0.0.1:${PORT}, or"
echo "   open http://<your-server-ip>:${PORT} directly.)"
echo "=============================================="
