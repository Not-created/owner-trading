# Owner Trading — Deployment + Broker Foundation

A password-protected trading dashboard with a complete production deployment
foundation and Kotak Neo broker infrastructure **installed but not
connected**. No Kotak account is authenticated, no credentials are
configured, and no order can be placed in this phase — see
[Broker status](#broker-status-this-phase) below.

## Architecture

```
React (Vite)  ->  Express API (Node)  ->  SQLite (node:sqlite, shared file)
                        |
                 Broker status proxy (local HTTP, short timeout)
                        |
        Python broker service (persistent, asyncio) -- owns --> kotakneoapi SDK --> Kotak Neo
```

- **Frontend**: React + Vite, served as static files by the Express backend in production (one process, one port).
- **Backend**: Node + Express. Owns the SQLite schema and migrations, session auth, and a thin HTTP client to the broker service (status only, in this phase).
- **Database**: SQLite via Node's built-in `node:sqlite` module -- zero native/compiled DB dependencies. **Requires Node 22.5+** (see [Node version note](#node-version-note)).
- **Broker service**: a *persistent* Python process (never spawned per-request) that is the only part of the system allowed to import `kotakneoapi`. Talks to Express over a minimal stdlib-only local HTTP interface (no aiohttp/FastAPI dependency). Reads/writes the *same* SQLite file as the backend (WAL mode) for idempotent order/trade/reconciliation records.
- **Process management**: systemd units for both services in production; `./deploy.sh` falls back to a background start when systemd isn't available (e.g. a container/sandbox).
- **Reverse proxy**: Nginx template forwarding everything to the backend.

## Node version note

The database layer intentionally uses Node's built-in `node:sqlite` instead
of a compiled dependency like `better-sqlite3`, to keep `npm install`
fast and dependency-free on a fresh VPS. That module requires **Node
22.5+**. `deploy.sh` checks this capability directly (not just the version
number) and fails with a clear upgrade message if it's missing.

## Broker status (this phase)

Nothing is connected. The dashboard's header badge reads the real
`/api/broker/status` endpoint, which proxies the Python broker service --
expect **"Kotak Neo: Not Connected"** (state `NOT_CONFIGURED`) until the
next phase configures real credentials. `CONNECTED` is never fabricated
anywhere in this codebase -- it is only ever set after a genuine, verified
Kotak session (which this phase deliberately does not attempt).

Connection states implemented: `DISCONNECTED`, `VERIFYING`, `CONNECTED`,
`AUTH_FAILED`, `SESSION_EXPIRED`, `CONNECTION_ERROR`, `NOT_CONFIGURED`.

## Project structure

```
owner-trading/
├── deploy.sh                       # ROOT-LEVEL one-click deployment
├── deployment/
│   ├── set-password.js             # Hashes & stores the access password
│   ├── systemd/                    # owner-trading-backend / -broker unit files
│   └── nginx/owner-trading.conf    # Reverse proxy template
├── backend/                        # Express API + serves the built frontend
│   └── src/
│       ├── db/                     # SQLite client (node:sqlite), migrations, migrate.js
│       ├── services/               # passwordStore, brokerState, brokerClient, readiness
│       ├── middleware/             # requireAuth, requireLiveTradingAllowed
│       └── routes/                 # auth, dashboard, broker, system
├── broker-service/                 # Persistent Python Kotak Neo service
│   ├── requirements.txt            # Pins kotakneoapi==3.0.6
│   ├── .env.example                # Documents credential vars (blank this phase)
│   ├── app/
│   │   ├── config.py               # Env-driven config, no hardcoded secrets
│   │   ├── state.py                # Broker connection state machine
│   │   ├── session.py              # Session TTL / expiry / re-auth architecture
│   │   ├── broker_client.py        # NeoAPI wrapper (current SDK signatures only)
│   │   ├── websocket_manager.py    # Subscription registry, reconnect/resubscribe
│   │   ├── reconciliation.py       # REST reconciliation foundation
│   │   ├── db.py                   # Idempotent shared-SQLite writes
│   │   ├── secure_store.py         # Secret-handling design + redact()
│   │   ├── server.py               # stdlib asyncio HTTP interface (/health, /status)
│   │   └── main.py                 # Entrypoint, graceful shutdown
│   └── tests/                      # 28 offline tests (see Validation below)
└── frontend/                       # React + Vite + React Router
    └── src/
        ├── components/common/BrokerStatusBadge.jsx  # Real status, never fabricated
        └── ... (dashboard shell, pages, auth -- see previous foundation docs)
```

## Deploying (fresh Ubuntu VPS)

```bash
git clone <this-repo>
cd owner-trading
chmod +x deploy.sh
./deploy.sh
```

`deploy.sh` (root-level, per requirement) will, in order: verify Ubuntu/Node
22.5+/Python 3.10+ -> install OS packages (python3-venv, build-essential,
curl) -> create the Python venv -> `pip install` the pinned `kotakneoapi` SDK
-> `npm install` backend and frontend -> run SQLite migrations (never drops
existing data; backs up the DB file first if one exists) -> generate
`backend/.env` and an empty broker credential template if missing (never
overwrites existing ones) -> build the frontend -> **prompt once for the
8-character access password** -> install/enable systemd units (or fall back
to a background start) -> install the Nginx config -> health-check both
services -> report final status.

Run as **root** for full systemd + Nginx automation; running as a non-root
user still completes the deployment via the background-process fallback,
with clear warnings about what was skipped and why.

## Local development

```bash
# Backend
cd backend && cp .env.example .env && npm install && npm run migrate && npm run dev

# Frontend
cd frontend && npm install && npm run dev

# Broker service
cd broker-service && python3 -m venv venv && ./venv/bin/pip install -r requirements.txt
./venv/bin/python -m app.main

# Set the access password once, from the project root:
printf '%s' 'Ab12@X9!' | node deployment/set-password.js
```

## Validation performed (see the assistant's final report for full detail)

- 28 offline unit/integration tests in `broker-service/tests/` -- including a
  real asyncio HTTP round-trip and real SQLite idempotency writes against
  the actual production schema. All pass.
- Live smoke test: started the real broker-service process, curled
  `/health` and `/status`, confirmed graceful `SIGTERM` shutdown.
- Live smoke test: called the Node backend's broker-client function
  directly (no Express needed) against the running broker-service, both up
  and down -- confirmed correct `CONNECTION_ERROR` reporting in both cases,
  never a fabricated `CONNECTED`.
- Full SQLite migration run against the real schema (idempotent -- reran
  clean).
- Syntax-checked every backend/frontend/Python/shell file.
- `systemd-analyze verify` on both unit files.
- Scanned for legacy Kotak v2 API usage, fake/mock trading data, and
  hardcoded secrets -- none found outside explanatory comments.
- **Not verified** (no network access in the build sandbox): a real
  `npm install`/frontend production build, `pip install kotakneoapi` against
  PyPI, `nginx -t` against a real Nginx binary, and any real Kotak Neo
  network behavior. Must be verified on your actual VPS.

## Security

- Access password: exactly 8 characters, any letters/numbers/symbols, bcrypt-hashed (12 rounds) server-side only.
- Kotak credentials (next phase): read from `/etc/owner-trading/broker.env` (root-owned, mode 600, outside the Git checkout) -- never committed, logged, or sent to the frontend.
- Session tokens from Kotak are kept **only in the broker service's process memory** -- never written to disk or SQLite.
- `requireLiveTradingAllowed` (Node) and `assert_live_trading_allowed()` (Python) independently gate any future LIVE order path on: `TRADING_MODE=LIVE` explicitly set, emergency stop inactive, and broker state genuinely `CONNECTED`.
- Nginx template never proxies to the secure credential/session directories.
