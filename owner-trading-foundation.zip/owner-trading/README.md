# Owner Trading — Foundation Stage

A password-protected trading dashboard shell. **This is the foundation stage only** —
no broker connectivity, orders, positions, or market data are implemented yet. All
dashboard sections currently show empty/placeholder states by design.

## What's included

- **Password gate**: the entire site is inaccessible until an 8-character access
  password is entered. The password is chosen by the administrator during
  deployment and stored server-side as a bcrypt hash — never in source, Git,
  logs, or the browser.
- **Dashboard shell**: header, responsive sidebar, and 13 section routes
  (Dashboard, Orders, Trade, Positions, Holdings, History, Strategy, Reports,
  Analytics, Market Data, Settings, Profile, Help), all real, routed, and
  navigable — each currently rendering a clean empty state.
- **Session handling**: server-side sessions via `express-session`; logout
  destroys the session and returns to the password screen.
- **One-click deployment**: `./deploy.sh` from the project root installs
  dependencies, builds the frontend, prompts once for the access password,
  and starts the app.

## Project structure

```
owner-trading/
├── deploy.sh                 # ROOT-LEVEL one-click deployment entry point
├── deployment/
│   └── set-password.js       # Helper: hashes & stores the password (called by deploy.sh)
├── backend/                  # Express API + serves the built frontend in production
│   ├── server.js
│   ├── .env.example
│   └── src/
│       ├── app.js            # Express app assembly (middleware, routes, static serving)
│       ├── config/           # Environment-driven configuration
│       ├── controllers/      # authController (login/logout/session)
│       ├── middleware/       # requireAuth (server-side route protection)
│       ├── routes/           # /api/auth/*, /api/dashboard/* (placeholder endpoints)
│       ├── services/         # passwordStore (bcrypt hash read/write)
│       └── data/secure/      # Gitignored — holds the hashed password file
└── frontend/                 # React + Vite + React Router
    ├── .env.example
    └── src/
        ├── App.jsx           # Route definitions
        ├── context/          # AuthContext (session state)
        ├── routes/           # ProtectedRoute
        ├── components/
        │   ├── PasswordGate/ # Password screen UI
        │   ├── layout/       # Sidebar, Header, DashboardLayout, nav config
        │   └── common/       # Icon, EmptyState, MetricCard, FoundationPage
        └── pages/             # One file per dashboard section
```

## Deploying (fresh server)

```bash
git clone <this-repo>
cd owner-trading
chmod +x deploy.sh          # only needed if the execute bit wasn't preserved
./deploy.sh
```

`deploy.sh` will:
1. Check for Node.js 18+ / npm.
2. Install backend and frontend dependencies.
3. Build the frontend for production.
4. Generate a session secret (first run only).
5. **Prompt you for the website access password — exactly 8 characters,
   any mix of letters/numbers/symbols** (this is the only interactive step).
6. Hash and store the password server-side.
7. Start the server and run a health check.

The site is then reachable on port `4000` (override with `PORT=8080 ./deploy.sh`).
Point a reverse proxy / domain at that port for a public URL + TLS.

Re-running `./deploy.sh` on an already-deployed server is safe — it offers to
keep the existing password and restarts the app cleanly.

## Local development

```bash
# Terminal 1
cd backend && cp .env.example .env && npm install && npm run dev

# Terminal 2
cd frontend && npm install && npm run dev
# open http://localhost:5173 (Vite dev server proxies /api to :4000)

# Set a password once, from the project root:
printf '%s' 'Ab12@X9!' | node deployment/set-password.js
```

## Security notes

- The access password is validated **server-side only** (exactly 8 characters,
  bcrypt-hashed with 12 salt rounds). No plaintext password is ever written to
  disk, logged, returned in an API response, or stored in the browser.
- `backend/src/data/secure/` (where the hash lives) is gitignored.
- Every `/api/dashboard/*` route is protected by `requireAuth` middleware —
  navigating directly to a dashboard URL without a valid session returns
  `401` from the API; the frontend correspondingly redirects to the password
  screen. This is enforced independently of the frontend.
- Login attempts are rate-limited (10 per 10 minutes per IP).
- Logout destroys the server-side session and clears the session cookie.

## What's intentionally NOT in this stage

No Kotak Neo / broker integration, no real orders/positions/holdings/market
data, no database (none is needed yet — see the comment in `deploy.sh`). These
begin in the next stage, per a separate instruction.
