"""Thin wrapper around the official `kotakneoapi` SDK's `NeoAPI` facade.

Method names and call shapes here are verified against the audited
Kotak-Neo/kotak-neo-python source (main branch, v3.0.6) kept read-only at
/home/claude/kotak-neo-sdk-reference in the assistant's workspace during
that audit -- NOT against the legacy v2 `kotak-neo-api-v2` client, and NOT
against invented/guessed method names.

IMPORTANT: nothing in this module makes a network call during this phase.
`NeoApiClient.connect()` (auth) and every trading/market-data/WebSocket
method below either raise `NotConfiguredError` or are simply never invoked,
because no route anywhere in this codebase calls them yet. This file exists
so the next phase only has to fill in the credential-driven call sites
below -- not design the integration from scratch.
"""
from __future__ import annotations

from .config import config
from .state import BrokerState, current_state

try:
    from neo_api_client import NeoAPI  # official SDK, package name "kotakneoapi"

    SDK_AVAILABLE = True
except ImportError:
    # Expected in this phase's offline validation (no network to `pip
    # install kotakneoapi`) -- the real VPS deploy installs it via
    # requirements.txt. The service must still start and report a clear
    # state rather than crash.
    NeoAPI = None
    SDK_AVAILABLE = False


class NotConfiguredError(RuntimeError):
    """Raised by any broker-calling method when credentials are missing or
    no session has been established. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """Raised when an order-placing method is reached while LIVE trading
    isn't genuinely allowed. Defense in depth: the Express backend's
    requireLiveTradingAllowed middleware is the primary gate; this is the
    same rule enforced independently on the Python side, so a bug in one
    layer can't silently let an order through.
    """


def assert_live_trading_allowed() -> None:
    from .state import BrokerState as _BrokerState  # local import avoids a cycle at module load
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("TRADING_MODE is not LIVE on this deployment.")
    if _db.is_emergency_stop_active():
        raise LiveTradingBlockedError("Emergency stop is active.")
    if current_state.state != _BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")


class BrokerClient:
    """Owns exactly one `NeoAPI` instance for the process lifetime -- the
    persistent Python service is not restarted per request, per the
    architecture requirement that a new process must not be spawned for
    every market-data request.
    """

    def __init__(self) -> None:
        self._neo: "NeoAPI | None" = None

    # ---------------------------------------------------------------- #
    # Authentication foundation (structure only -- not called this phase)
    # ---------------------------------------------------------------- #
    def is_ready_to_authenticate(self) -> bool:
        return SDK_AVAILABLE and config.is_fully_configured()

    async def connect(self) -> None:
        """Would perform: NeoAPI(consumer_key=...) -> totp_login(...) ->
        totp_validate(...), storing edit_token/edit_sid per the audited
        auth flow. NOT invoked in this phase -- no route calls this, and
        calling it here would violate "do not connect to Kotak yet".
        """
        raise NotConfiguredError(
            "Broker authentication is not enabled in this deployment phase."
        )

    # ---------------------------------------------------------------- #
    # Market data foundation (method names verified against audited SDK)
    # ---------------------------------------------------------------- #
    def quotes(self, *args, **kwargs):
        self._require_connected()
        return self._neo.quotes(*args, **kwargs)

    def scrip_master(self, *args, **kwargs):
        self._require_connected()
        return self._neo.scrip_master(*args, **kwargs)

    def search_scrip(self, *args, **kwargs):
        self._require_connected()
        return self._neo.search_scrip(*args, **kwargs)

    def expiries(self, *args, **kwargs):
        self._require_connected()
        return self._neo.expiries(*args, **kwargs)

    def option_chain(self, *args, **kwargs):
        self._require_connected()
        return self._neo.option_chain(*args, **kwargs)

    def historical_data(self, *args, **kwargs):
        self._require_connected()
        return self._neo.historical_data(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Order foundation
    # ---------------------------------------------------------------- #
    def place_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        # Deliberately not called anywhere yet -- no order route exists in
        # this phase, and both safety gates above (Express middleware +
        # this Python-side assertion) must pass before this line is ever
        # reached.
        return self._neo.place_order(*args, **kwargs)

    def modify_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.modify_order(*args, **kwargs)

    def cancel_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.cancel_order(*args, **kwargs)

    def order_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_report(*args, **kwargs)

    def order_history(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_history(*args, **kwargs)

    def trade_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.trade_report(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Portfolio foundation
    # ---------------------------------------------------------------- #
    def positions(self, *args, **kwargs):
        self._require_connected()
        return self._neo.positions(*args, **kwargs)

    def holdings(self, *args, **kwargs):
        self._require_connected()
        return self._neo.holdings(*args, **kwargs)

    def limits(self, *args, **kwargs):
        self._require_connected()
        return self._neo.limits(*args, **kwargs)

    def margin_required(self, *args, **kwargs):
        self._require_connected()
        return self._neo.margin_required(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # WebSocket foundation -- current SDK factory methods only.
    # Deliberately NOT using the legacy subscribe()/un_subscribe()/
    # subscribe_to_orderfeed() stubs identified as obsolete in the SDK audit.
    # ---------------------------------------------------------------- #
    def create_market_feed(self, **kwargs):
        """Would call self._neo.create_websocket(**kwargs) and return an
        SFeedWebSocket, then subscribe_scrips()/unsubscribe_scrips() per
        instrument -- see websocket_manager.py for the subscription
        registry this plugs into. Not invoked this phase.
        """
        self._require_connected()
        return self._neo.create_websocket(**kwargs)

    def create_order_feed(self, **kwargs):
        """Would call self._neo.create_order_feed(**kwargs). Not invoked
        this phase."""
        self._require_connected()
        return self._neo.create_order_feed(**kwargs)

    # ---------------------------------------------------------------- #
    def _require_connected(self) -> None:
        if current_state.state != BrokerState.CONNECTED or self._neo is None:
            raise NotConfiguredError(
                f"Broker is not connected (state: {current_state.state.value})."
            )


# Module-level singleton -- one broker client per persistent process.
broker_client = BrokerClient()
