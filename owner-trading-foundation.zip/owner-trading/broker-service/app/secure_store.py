"""Secure secret-handling architecture for Kotak credentials and session
artifacts.

THIS PHASE: no credentials are configured or handled anywhere, so nothing
here is exercised yet. This module documents and pre-wires WHERE secrets
will live so the next phase has one obvious, already-reviewed place to
write real credential handling into -- instead of inventing storage ad hoc.

Design (for the next phase):
  - Long-lived credentials (consumer_key/secret, UCC, TOTP secret, MPIN)
    are read from environment variables only (see config.py), populated by
    deployment/systemd/owner-trading-broker.service's EnvironmentFile
    directive pointing at a root-only-readable file
    (/etc/owner-trading/broker.env, mode 600) -- never committed to Git,
    never passed on the command line (avoids `ps` exposure), never logged.
  - Session artifacts (edit_token/edit_sid/data_center from totp_validate())
    are short-lived and process-local: kept ONLY in this process's memory
    (see state.py), never written to SQLite or disk. If the broker service
    restarts, the session is gone and a fresh TOTP+MPIN login is required --
    this is intentional; SQLite's broker_sessions table stores only opaque
    metadata (timestamps, a reference id), never the token itself.
  - The Express backend never receives, stores, or proxies Kotak credentials
    or tokens at any point -- it only ever sees the connection STATE
    (NOT_CONFIGURED / CONNECTED / etc.) via /status.

Nothing below performs I/O in this phase; the functions are typed
placeholders the next phase implements against the design above.
"""
from __future__ import annotations


def redact(value: str | None) -> str:
    """Used by any future logging call that might otherwise include a
    credential-shaped value -- never log config.consumer_key,
    config.mpin, etc. directly."""
    if not value:
        return "<empty>"
    return "*" * max(len(value) - 2, 0) + value[-2:] if len(value) > 2 else "**"
