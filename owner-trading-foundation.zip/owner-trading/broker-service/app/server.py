"""Minimal async HTTP server, stdlib-only (asyncio streams -- no aiohttp/
FastAPI dependency), so the broker service has zero extra pip packages
beyond the official SDK itself. It runs on the SAME event loop that will
host the WebSocket manager (next phase), rather than spinning up a second
process or a blocking thread per request -- satisfying "do not create a new
Python process for every market-data request" at the transport level too.

Only two endpoints exist in this phase:
  GET /health  -> liveness only ("is the process up")
  GET /status  -> broker connection state (never fabricated)
"""
from __future__ import annotations

import asyncio
import json
import logging

from .config import config
from .state import current_state

logger = logging.getLogger("owner_trading.server")


def _json_response(status_code: int, payload: dict) -> bytes:
    body = json.dumps(payload).encode("utf-8")
    status_text = {200: "OK", 404: "Not Found", 405: "Method Not Allowed"}.get(status_code, "Error")
    headers = (
        f"HTTP/1.1 {status_code} {status_text}\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    )
    return headers.encode("utf-8") + body


async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not request_line:
            writer.close()
            return
        # Drain remaining headers without needing them -- these endpoints
        # take no body and no query params.
        while True:
            line = await asyncio.wait_for(reader.readline(), timeout=5)
            if not line or line in (b"\r\n", b"\n"):
                break

        parts = request_line.decode("latin-1").strip().split(" ")
        method, path = (parts[0], parts[1]) if len(parts) >= 2 else ("", "")

        if method != "GET":
            writer.write(_json_response(405, {"error": "Method not allowed"}))
        elif path == "/health":
            writer.write(_json_response(200, {"status": "ok"}))
        elif path == "/status":
            writer.write(_json_response(200, current_state.as_dict()))
        else:
            writer.write(_json_response(404, {"error": "Not found"}))

        await writer.drain()
    except (asyncio.TimeoutError, ConnectionError) as exc:
        logger.debug("Client connection dropped: %s", exc)
    finally:
        writer.close()


async def run_server() -> None:
    server = await asyncio.start_server(_handle_client, config.host, config.port)
    addr = server.sockets[0].getsockname() if server.sockets else (config.host, config.port)
    logger.info("Broker service HTTP interface listening on %s:%s", *addr[:2])
    async with server:
        await server.serve_forever()
