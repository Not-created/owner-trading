"""REST-based reconciliation, run on startup and after any WebSocket
reconnect, so order/position/holding state never silently drifts from what
Kotak actually has.

Not invoked in this phase (nothing is connected yet). Every function is a
real, correctly-shaped stub the next phase fills in with actual persistence
calls against the SQLite tables the backend already migrated (orders,
order_events, trades, positions_snapshot, holdings_snapshot,
funds_snapshot, reconciliation_records).
"""
from __future__ import annotations

import logging

from .broker_client import broker_client, NotConfiguredError

logger = logging.getLogger("owner_trading.reconciliation")


async def reconcile_orders() -> None:
    """Would call broker_client.order_report() (full book) and diff against
    locally known open orders, recording any discrepancy into
    reconciliation_records rather than guessing/auto-correcting silently.
    """
    try:
        broker_client.order_report()
    except NotConfiguredError as exc:
        logger.info("Order reconciliation skipped: %s", exc)


async def reconcile_positions() -> None:
    try:
        broker_client.positions()
    except NotConfiguredError as exc:
        logger.info("Position reconciliation skipped: %s", exc)


async def reconcile_holdings() -> None:
    try:
        broker_client.holdings()
    except NotConfiguredError as exc:
        logger.info("Holdings reconciliation skipped: %s", exc)


async def reconcile_funds() -> None:
    try:
        broker_client.limits()
    except NotConfiguredError as exc:
        logger.info("Funds reconciliation skipped: %s", exc)


async def run_full_reconciliation() -> None:
    """Called on startup/restart, before LIVE trading may be considered
    available -- per the safety requirement that a restart must reconcile
    state before anything is trusted.
    """
    await reconcile_orders()
    await reconcile_positions()
    await reconcile_holdings()
    await reconcile_funds()
