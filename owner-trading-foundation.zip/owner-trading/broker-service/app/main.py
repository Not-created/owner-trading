"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express.
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")


def _determine_initial_state() -> None:
    """Sets the correct starting state WITHOUT attempting to connect.
    NOT_CONFIGURED unless every required credential is present -- and even
    then, this phase deliberately does not attempt authentication (that
    begins next phase). Presence of credentials is never treated as
    "connected".
    """
    if not broker_client_module.SDK_AVAILABLE:
        current_state.transition(
            BrokerState.CONNECTION_ERROR,
            "kotakneoapi SDK is not installed in this environment.",
        )
        logger.warning("kotakneoapi is not importable -- broker service running in degraded mode.")
        return

    if config.is_fully_configured():
        # Credentials exist, but this phase does not authenticate with them.
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials are present but authentication is disabled this phase.")
    else:
        current_state.transition(BrokerState.NOT_CONFIGURED)
        logger.info("Kotak credentials are not configured. Broker state: NOT_CONFIGURED.")


async def _main() -> None:
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())

    await stop_event.wait()
    server_task.cancel()
    try:
        await server_task
    except asyncio.CancelledError:
        pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
