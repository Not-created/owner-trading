"""Shared-database writer for the broker service.

The Node backend OWNS the SQLite schema (see
backend/src/db/migrations/001_init.sql) and runs all migrations -- this
module only ever INSERTs into tables that already exist, using the same
file (DB_PATH env var, matching backend/src/config/index.js's default of
backend/data/owner-trading.db). SQLite's WAL mode (enabled by the Node side
in db/client.js) safely supports this: one writer at a time, with SQLite
handling the locking -- both processes retry-on-busy rather than corrupt
data.

Every insert here is written to be idempotent against the UNIQUE
constraints already in the schema (order_events.(event_source,
broker_event_id), trades.broker_trade_id) using INSERT OR IGNORE, so a
duplicated WebSocket message or a retried REST reconciliation can never
double-record the same event -- this is the "duplicate-event protection /
idempotency" requirement implemented concretely, not just described.

Not called by anything live yet in this phase (no real events exist to
record) -- exercised directly by tests/test_idempotency.py.
"""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "data", "owner-trading.db"
)
DB_PATH = os.environ.get("DB_PATH", DEFAULT_DB_PATH)


@contextmanager
def _connection():
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def record_order_event(
    *,
    event_source: str,
    broker_event_id: str | None,
    raw_payload: dict,
    order_id: int | None = None,
    broker_order_id: str | None = None,
) -> bool:
    """Idempotent insert into order_events. Returns True if a new row was
    written, False if this exact (event_source, broker_event_id) was
    already recorded (duplicate, correctly ignored).
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO order_events
               (order_id, broker_order_id, event_source, broker_event_id, raw_payload)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, event_source, broker_event_id, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def record_trade(
    *,
    broker_trade_id: str,
    order_id: int | None,
    broker_order_id: str | None,
    fill_quantity: int,
    fill_price: float,
    fill_time: str | None,
    raw_payload: dict,
) -> bool:
    """Idempotent insert into trades, keyed on broker_trade_id -- handles
    partial/multiple fills correctly since each fill has its own unique
    broker_trade_id; re-delivery of the same fill event is a no-op.
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO trades
               (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, raw_payload)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def is_emergency_stop_active() -> bool:
    """Reads the shared emergency_stop_state singleton row (owned/migrated
    by the Node backend). Read-only from this side -- only the Express API
    is meant to toggle it (next phase: an explicit owner-triggered action).
    """
    with _connection() as conn:
        row = conn.execute("SELECT is_active FROM emergency_stop_state WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


def record_reconciliation(
    *, reconciliation_type: str, reference_id: str | None, discrepancy_found: bool, details: dict | None
) -> None:
    """Always inserts (not idempotent by design -- every reconciliation
    pass is its own audit record, even if the result matches the last one).
    """
    with _connection() as conn:
        conn.execute(
            """INSERT INTO reconciliation_records
               (reconciliation_type, reference_id, discrepancy_found, details)
               VALUES (?, ?, ?, ?)""",
            (reconciliation_type, reference_id, 1 if discrepancy_found else 0, json.dumps(details) if details else None),
        )
