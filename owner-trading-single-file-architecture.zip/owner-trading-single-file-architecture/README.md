# Owner Trading

Single-file-per-module architecture.

Each application module owns its complete UI, state handling and module-level
integration contract. Shared application concerns remain in the small core
files.

This archive is the clean architecture scaffold. Feature implementation will
be built into these final module boundaries; no unnecessary module explosion.
