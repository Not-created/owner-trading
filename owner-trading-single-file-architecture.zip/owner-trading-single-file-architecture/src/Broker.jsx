// Complete broker module: Kotak Neo connection, authentication, session, account, market data, orders, positions, holdings, funds, trade history
