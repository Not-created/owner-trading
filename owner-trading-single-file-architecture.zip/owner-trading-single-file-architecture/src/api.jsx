// Central API communication contract
