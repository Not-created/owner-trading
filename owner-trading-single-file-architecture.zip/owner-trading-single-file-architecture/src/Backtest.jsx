// Backtest configuration + execution + results + equity curve + statistics
