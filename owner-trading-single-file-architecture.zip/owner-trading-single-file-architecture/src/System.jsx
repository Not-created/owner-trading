// System health + service status + diagnostics
