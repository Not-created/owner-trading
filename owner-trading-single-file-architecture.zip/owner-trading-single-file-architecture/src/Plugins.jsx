// Plugin manager and lifecycle
