// Auth + Theme + global application state
