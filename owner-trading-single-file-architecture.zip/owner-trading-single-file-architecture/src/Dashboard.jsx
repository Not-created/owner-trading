// Portfolio + P&L + charts + live dashboard data
