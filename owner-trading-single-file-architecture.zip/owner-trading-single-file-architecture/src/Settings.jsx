// Theme + trading + notifications + security + preferences
