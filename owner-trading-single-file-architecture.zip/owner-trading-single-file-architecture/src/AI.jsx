// AI providers + chat + strategy assistant
