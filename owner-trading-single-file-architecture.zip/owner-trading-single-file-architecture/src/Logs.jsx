// System + trading + error/audit logs
