// Risk management + limits + kill switch + emergency controls
