// Strategy creation + editing + validation + run/stop/deploy
