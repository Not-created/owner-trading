// Master control + trading controls + system actions
