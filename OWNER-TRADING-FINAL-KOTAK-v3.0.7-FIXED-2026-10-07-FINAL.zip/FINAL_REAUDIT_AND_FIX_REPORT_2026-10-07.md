# Owner Trading — Final Re-audit & Fix Report — 2026-10-07

## Scope

This release was rebuilt from the supplied `OWNER-TRADING-FINAL-KOTAK-v3.0.7-FIXED-2026-10-07.zip` and audited as one interconnected system. The official vendored Kotak Neo Python SDK v3.0.7 was not modified or replaced.

Official Kotak references used as source of truth:
- SDK v3.0.7 is the production/stable SDK.
- `historical_data()` is consumer-key-only and has backend-enforced date limits: 30/30/30/60/60/90/90/180/180 days for the documented intervals.
- `scrip_master()`, `quotes()`, `option_chain()` and related market-data APIs documented for this SDK are consumer-key-only; authenticated Trade-session state must not be mutated by their failures.
- v3 order/WebSocket contracts use exact exchange/order/product/validity values and async SFeed/Order Feed APIs.

## Fixes applied one-by-one

### 1. Authentication classification hardening

Text-only `Unauthorized` is no longer sufficient to expire the trading session. Session expiry is classified from authoritative HTTP/broker error codes (401/403) or explicit session-invalid markers. A normal business/RMS rejection containing the word `unauthorized` is not automatically converted into `SESSION_EXPIRED`.

### 2. Consumer-key-only API isolation

The following APIs now use a dedicated consumer-key-only SDK instance and cannot transition the authenticated Trade session to `SESSION_EXPIRED`:

- scrip_master
- search_scrip
- quotes
- expiries
- option_chain
- historical_data

Authenticated order/portfolio/session APIs retain the existing Trade-session lifecycle.

### 3. Historical-data timeout

Historical requests now have a hard asynchronous request deadline at the application layer in addition to the SDK HTTP timeout. A timeout of one instrument does not automatically abort the entire scanner batch.

### 4. Scanner failure isolation

Only global auth/rate-limit failures pause the current historical warm-up batch. Ordinary timeout, transport, malformed/instrument-specific and other local failures are recorded for that instrument while other instruments continue.

### 5. Scanner starvation fix

The historical target batch rotates each cycle. A permanently failing/delisted instrument at the front of the universe can no longer starve the remaining stocks indefinitely. The rotation is time-derived so it does not depend on a new volatile in-memory-only checkpoint.

### 6. 3000-token SFeed capacity arbitration

The broker's hard 3000-token SFeed capacity is respected. Priority is:

`open position > execution > strategy candidate > strategy universe > manual > scanner universe`.

When capacity is full, only a lower-priority token can be temporarily preempted by a higher-priority execution/position/candidate request. Higher/equal-priority subscriptions are never evicted.

### 7. Temporary order-feed subscription leak fixed

The exact-instrument `order:<segment>:<token>` owner used to obtain a fresh entry tick is now released after the order attempt. This prevents repeated orders from consuming SFeed capacity permanently.

### 8. Scanner feed restoration

If an execution temporarily preempts a scanner-universe token, the scanner slot is restored immediately after the temporary order owner is released, rather than waiting for the next 30-second scanner cycle. Open-position ownership remains higher priority.

### 9. Exact-instrument LIVE safety gate retained

No feed safety gate was bypassed. A LIVE entry still requires a fresh exact-instrument tick, connected market/order feeds, clean reconciliation, risk gates and the existing idempotent/unknown-outcome protections.

## SDK integrity

- Required SDK: `3.0.7`
- Vendored manifest entries checked: `52`
- Manifest mismatches: `0`
- Vendored SDK source modified: `NO`

## Validation performed

- Broker-service pytest suite: **426 passed, 3 skipped, 0 failed**
- Python `compileall`: **PASS**
- Backend/deployment JavaScript syntax checks: **PASS**
- Deployment shell `bash -n`: **PASS**
- Vendored SDK SHA-256 manifest: **PASS (52/52)**
- Final ZIP extracted and validation suite rerun: **PASS**

## Known validation limitation

The audit container could not complete the frontend dependency installation: `npm install --no-audit --no-fund` timed out after 180 seconds. Therefore a Vite production build was **not** claimed as PASS. The deployment script itself performs the frontend dependency installation/build on the target VPS and will fail closed if that build fails.

## Live-broker limitation

No real LIVE Kotak order was submitted during offline validation. Real credentials, network connectivity, market session, broker-side permissions and the target VPS are required for the final controlled LIVE smoke test.
