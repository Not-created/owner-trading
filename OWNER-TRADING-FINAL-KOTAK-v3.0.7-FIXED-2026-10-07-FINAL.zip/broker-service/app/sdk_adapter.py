"""sdk_adapter -- the ONLY module in this service that imports the official
Kotak Neo SDK (`neo_api_client`, distribution `kotakneoapi`).

Everything here is written against the SDK source shipped with this project
(vendor/kotakneoapi, v3.0.7, byte-identical to the official ZIP -- see
vendor/VENDOR_MANIFEST.sha256). Exact call signatures used below
(NeoAPI.__init__, totp_login, totp_validate, place_order, modify_order,
cancel_order, order_report, order_history, trade_report, positions,
holdings, limits, margin_required, quotes, scrip_master, search_scrip,
create_websocket, create_order_feed, logout, whatsmyip) are re-checked
against the vendored source by tests/test_sdk_conformance.py using `ast`,
so a signature drift fails the test suite instead of failing a live order.

RESPONSE CONTRACT (read from the SDK source, not guessed):
  * NeoAPI trading methods NEVER raise for API problems. They return a dict.
    Error shapes seen in the source: {"Error": <exception object or str>},
    {"error": <ApiException | list of {"code","message"}>},
    {"Error Message": "Complete the 2fa process ..."} (no session), and
    backend rejections such as {"stCode": 1021, "errMsg": ..., "stat": ...,
    "status_code": 400}. HTTP >= 400 does NOT raise (raise_on_error is off),
    so a 4xx/5xx body is returned as parsed JSON.
  * Success bodies carry stat "Ok"/"ok" and stCode 200; order placement /
    modify / cancel carry the order id in `nOrdNo`.
  * Transport failures (timeout / connection error) surface as
    {"Error": ApiException(status=0, ...)} -- for order-changing calls the
    request MAY have reached the broker, so the outcome is UNKNOWN, never
    "rejected". Callers must reconcile by client tag (`GuiOrdId`).
This module turns those shapes into one JSON-safe `Outcome`.
"""
from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any, Callable

logger = logging.getLogger("owner_trading.sdk_adapter")

REQUIRED_SDK_VERSION = "3.0.7"

# The SDK writes a rotating log file relative to the CWD by default and, at
# INFO, logs call parameters. Pin conservative defaults BEFORE importing it
# (the SDK reads these env vars at import time). Operators may override.
os.environ.setdefault("NEO_LOG_LEVEL", "WARNING")
os.environ.setdefault("NEO_LOG_FILE_LEVEL", "WARNING")

SDK_IMPORT_ERROR: str | None = None
SDK_VERSION: str | None = None
try:  # pragma: no cover - exercised only where the real SDK + deps are installed
    import neo_api_client as _sdk_pkg
    from neo_api_client import NeoAPI  # noqa: F401
    SDK_VERSION = getattr(_sdk_pkg, "__version__", None)
    SDK_AVAILABLE = True
except Exception as _exc:  # ImportError, or a missing transitive dependency
    NeoAPI = None  # type: ignore[assignment]
    SDK_AVAILABLE = False
    SDK_IMPORT_ERROR = f"{type(_exc).__name__}: {_exc}"

# ------------------------------------------------------------------------ #
# Exact enums accepted by NeoAPI.place_order / modify_order / margin_required
# (neo_api_client/settings.py + req_data_validation.py, v3.0.7).
# Kept identical by tests/test_sdk_conformance.py.
# ------------------------------------------------------------------------ #
EXCHANGE_SEGMENTS = ("nse_cm", "bse_cm", "nse_fo", "bse_fo", "mcx_fo")
# expiries()/option_chain() only accept the three derivative segments (docs/functions/market_data).
DERIVATIVE_SEGMENTS = ("nse_fo", "bse_fo", "mcx_fo")
INSTRUMENT_TYPES = ("option", "fut")
HISTORICAL_INTERVALS = ("1min", "3min", "5min", "10min", "15min", "30min", "60min", "D", "W")
# historical_data() is documented as unsupported for these segments (backend-enforced, not SDK-validated).
HISTORICAL_UNSUPPORTED_SEGMENTS = ("mcx_fo", "nse_com")
PRODUCTS = ("CNC", "NRML", "MIS", "MTF")
ORDER_TYPES = ("L", "MKT", "SL", "SL-M")
TRANSACTION_TYPES = ("B", "S")
VALIDITY_BY_SEGMENT = {
    "nse_cm": ("DAY", "IOC"),
    "bse_cm": ("DAY", "IOC"),
    "nse_fo": ("DAY", "IOC"),
    "bse_fo": ("DAY", "IOC"),
    "mcx_fo": ("DAY",),
}
PRICE_REQUIRED_ORDER_TYPES = ("L", "SL")
TRIGGER_REQUIRED_ORDER_TYPES = ("SL", "SL-M")


# ------------------------------------------------------------------------ #
# Outcome
# ------------------------------------------------------------------------ #
OK = "OK"
REJECTED = "REJECTED"        # definitive: never sent (validation) or broker said no
AUTH = "AUTH"                # no session / session invalid -> re-login needed
UNKNOWN = "UNKNOWN"          # transport failure or unrecognised body: may or may not have happened


@dataclass
class Outcome:
    kind: str
    message: str = ""
    code: str | None = None
    order_id: str | None = None
    data: Any = None
    raw: Any = None
    extra: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.kind == OK

    def as_dict(self) -> dict:
        return {
            "kind": self.kind, "message": self.message, "code": self.code,
            "order_id": self.order_id, "data": self.data,
            "diagnostics": self.extra.get("broker_diagnostics") if self.extra else None,
        }


def jsonable(obj: Any, _depth: int = 0) -> Any:
    """Make an SDK response JSON-safe. SDK error dicts embed live exception
    objects ({"Error": ApiException(...)}); those become their str()."""
    if _depth > 8:
        return str(obj)
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {str(k): jsonable(v, _depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [jsonable(v, _depth + 1) for v in obj]
    if isinstance(obj, BaseException):
        return f"{type(obj).__name__}: {obj}"
    if hasattr(obj, "model_dump"):
        try:
            return jsonable(obj.model_dump(), _depth + 1)
        except Exception:  # noqa: BLE001
            return str(obj)
    return str(obj)


_SESSION_MARKERS = ("invalid session", "session expired", "session has expired", "re-login", "relogin", "invalid token", "token expired")
_AUTH_HTTP_CODES = (401, 403)
_NOT_AUTH_MARKER = "2fa process"


def _text_of(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts = []
        for item in value:
            if isinstance(item, dict):
                parts.append(str(item.get("message") or item.get("errMsg") or item))
            else:
                parts.append(str(item))
        return "; ".join(parts)
    return str(value)


def _status_of_exception(exc: Any) -> int | None:
    st = getattr(exc, "status", None)
    return st if isinstance(st, int) else None


def _int_or_none(v: Any) -> int | None:
    try:
        return int(str(v))
    except (TypeError, ValueError):
        return None


_ENDPOINT_KEYS = {
    "order_report": "order_book",
    "trade_report": "trade_report",
    "positions": "positions",
    "holdings": "holdings",
    "limits": "limits",
}


def _redact_sensitive(value: Any, _depth: int = 0) -> Any:
    """Keep broker error diagnostics useful without persisting auth material."""
    if _depth > 8:
        return "<truncated>"
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            lk = str(k).lower()
            if any(x in lk for x in ("token", "sid", "auth", "secret", "password", "consumer_key", "mpin", "totp")):
                out[str(k)] = "***REDACTED***"
            else:
                out[str(k)] = _redact_sensitive(v, _depth + 1)
        return out
    if isinstance(value, list):
        return [_redact_sensitive(v, _depth + 1) for v in value]
    return value


def _endpoint_for_sdk_method(neo: Any, method: str, *args) -> str | None:
    """Resolve the exact endpoint from the official SDK configuration."""
    try:
        cfg = getattr(neo, "configuration", None)
        key = _ENDPOINT_KEYS.get(method)
        if not cfg or not key:
            return None
        base = cfg.get_url_details(key)
        if method == "order_report" and args and args[0]:
            return f"{base.rstrip('/')}/{str(args[0]).strip()}"
        return base
    except Exception:
        return None


def _diagnostics(resp: Any, *, method: str | None = None, endpoint: str | None = None,
                 session_indication: str | None = None, transport_exception: str | None = None) -> dict:
    """Return a stable, UI-safe broker diagnostic envelope for every REST result."""
    safe = _redact_sensitive(jsonable(resp))
    http_status = None
    st_code = None
    err_msg = None
    if isinstance(resp, dict):
        http_status = _int_or_none(resp.get("status_code") or resp.get("StatusCode"))
        st_code = _int_or_none(resp.get("stCode") or resp.get("errorCode"))
        err_msg = _text_of(resp.get("errMsg") or resp.get("emsg") or resp.get("message")) or None
        if not err_msg and resp.get("error"):
            err_msg = _text_of(resp.get("error"))
        # ApiException from SDK 3.0.7 preserves HTTP status/body separately.
        # Surface those fields instead of forcing operators to decode the
        # stringified exception.
        for err_key in ("Error", "error"):
            err = resp.get(err_key)
            if isinstance(err, BaseException):
                http_status = http_status if http_status is not None else _status_of_exception(err)
                body = getattr(err, "body", None)
                if body is not None:
                    safe = _redact_sensitive(jsonable(body))
                reason = getattr(err, "reason", None)
                if reason and not err_msg:
                    err_msg = str(reason)
                break
    if transport_exception:
        transport_exception = str(transport_exception)[:500]
    return {
        "method": method,
        "endpoint": endpoint,
        "http_status": http_status,
        "kotak_st_code": st_code,
        "kotak_err_msg": err_msg,
        "response_body": safe,
        "session_auth_indication": session_indication or "UNKNOWN",
        "transport_exception": transport_exception,
    }


def _exception_body_as_response(exc: BaseException) -> Any:
    """Turn an SDK ApiException body into the same response shape as a normal SDK return.

    NeoAPI v3 can operate with ``raise_on_error=True``. In that mode the REST
    layer raises ``ApiException(status=..., body=<parsed JSON>)`` for HTTP >= 400,
    so the adapter's normal response classifier would otherwise never see the
    broker body.  This helper deliberately preserves the body and HTTP status so
    the endpoint-specific empty-read contract can be applied before generic
    error classification.
    """
    body = getattr(exc, "body", None)
    if isinstance(body, (bytes, bytearray)):
        try:
            body = body.decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            body = str(body)
    if isinstance(body, str):
        text = body.strip()
        if text:
            try:
                body = json.loads(text)
            except (TypeError, ValueError):
                body = None
    if isinstance(body, dict):
        out = dict(body)
        status = _status_of_exception(exc)
        if status is not None and not any(k in out for k in ("status_code", "StatusCode")):
            out["status_code"] = status
        return out
    if isinstance(body, list):
        return {"data": body, "status_code": _status_of_exception(exc)}
    return None


def _classify_read_exception(exc: BaseException, *, method: str, endpoint: str | None,
                             section: str) -> Outcome:
    """Classify a raised SDK REST exception without losing its broker body.

    Important: only the four read-only collection endpoints may convert their
    exact documented empty-account response into ``[]``. Every other raised
    exception remains a broker rejection/transport failure and therefore blocks
    reconciliation as appropriate.
    """
    body = _exception_body_as_response(exc)
    if isinstance(body, dict):
        diag = _diagnostics(body, method=method, endpoint=endpoint)
        empty = _empty_read_response(body, section, diag)
        if empty is not None:
            return empty
        # Classify the preserved broker response, not the exception string. This
        # keeps HTTP/stCode/errMsg/session diagnostics consistent with non-raised
        # SDK responses.
        return classify(body, method=method, endpoint=endpoint)

    # No structured broker body (e.g. timeout/connect failure). Preserve the
    # exception as an Error response so classify() applies its normal transport
    # and authentication rules.
    return classify(
        {"Error": exc, "status_code": _status_of_exception(exc)},
        method=method,
        endpoint=endpoint,
    )

def _empty_read_response(resp: Any, section: str, diagnostics: dict) -> Outcome | None:
    """Normalize only documented, safe empty read responses.

    Kotak Neo's current SDK documentation defines the response:
      stCode=5203, errMsg="No Data", desc="data not found", stat="Not_Ok"
    as its explicit *No Data Response*. For read-only collections this means
    the requested collection is empty, not that the broker/session failed.

    Some portfolio endpoints also return a 424 response with an endpoint-specific
    "No <section> found/available" message. That legacy empty-account shape is
    retained, but every other 424/5203 response remains a real broker failure.
    The 5203 rule is intentionally narrow and is applied only by the four
    read-only collection methods that call this helper.
    """
    if not isinstance(resp, dict):
        return None

    st_code = _int_or_none(resp.get("stCode"))
    http_status = _int_or_none(resp.get("status_code")) or _int_or_none(resp.get("StatusCode"))
    msg = _text_of(resp.get("errMsg") or resp.get("emsg") or resp.get("message") or resp.get("error"))
    stat = _text_of(resp.get("stat")).strip().lower()
    desc = _text_of(resp.get("desc")).strip().lower()

    # Official Kotak Neo 5203 No Data contract. If an optional/extra HTTP
    # status field is present, it must not itself indicate an HTTP failure.
    # The documented body fields are matched exactly (case-insensitive).
    if (st_code == 5203
            and msg.strip().casefold() == "no data"
            and stat in ("not_ok", "notok")
            and (not desc or desc == "data not found")
            and (http_status is None or http_status < 400)):
        diagnostics["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
        diagnostics["response_classification"] = "KOTAK_NO_DATA"
        return Outcome(OK, message=f"Kotak returned documented 5203 No Data for {section}; treating the section as empty.",
                       data=[], raw=jsonable(resp), extra={"broker_diagnostics": diagnostics})

    # Legacy/endpoint-specific empty-account response. Do not generalize 424
    # to all errors because unrelated 424 responses must still block LIVE.
    # Kotak reports this empty-account message under different HTTP/stCode values depending on the
    # gateway path (424, 4xx, or a body-only Not_Ok), so the EXACT endpoint-specific sentence --
    # not the numeric code -- is the contract. Server failures (5xx) and auth markers never qualify,
    # and any other message (including a generic 424) remains a real failure.
    code = http_status if http_status is not None else st_code
    if code is not None and code >= 500:
        return None
    candidates = [msg]
    for key in ("Error", "error", "message", "Message", "emsg"):
        v = resp.get(key)
        if isinstance(v, str):
            candidates.append(v)
        elif isinstance(v, dict):
            candidates.append(_text_of(v.get("errMsg") or v.get("message") or v.get("emsg")))
    low = ""
    for cand in candidates:
        norm = " ".join(str(cand or "").lower().split())
        if norm.startswith("no ") and " found for this client" in norm or norm.startswith(f"no {section} "):
            low = norm
            break
    if not low:
        return None
    # Kotak documents HTTP 424 as a dependency failure in general. We therefore
    # accept 424 as an empty collection only for the narrow endpoint-specific
    # "no <section> found for this client" family actually returned by the
    # portfolio/report endpoints. Generic 424 text is never treated as empty.
    exact_empty = re.compile(
        rf"^no {re.escape(section)} found for this client(?:\s+[a-z0-9_-]+)?[.!]?$"
    )
    alternate_empty = re.compile(
        rf"^no {re.escape(section)} (?:data|records|available)[.!]?$"
    )
    if exact_empty.fullmatch(low) or alternate_empty.fullmatch(low):
        diagnostics["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
        diagnostics["response_classification"] = "KOTAK_EMPTY_424"
        return Outcome(OK, message=f"Kotak returned 424 because there are no {section}; treating it as an empty section.",
                       data=[], raw=jsonable(resp), extra={"broker_diagnostics": diagnostics})
    return None


def classify(resp: Any, *, expect_order_id: bool = False, state_changing: bool = False,
             method: str | None = None, endpoint: str | None = None) -> Outcome:
    """Classify an SDK response and preserve actionable Kotak diagnostics."""
    safe = jsonable(resp)
    diag = _diagnostics(resp, method=method, endpoint=endpoint)

    if not isinstance(resp, dict):
        if isinstance(resp, list):
            diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
            return Outcome(OK, data=safe, raw=safe, extra={"broker_diagnostics": diag})
        if isinstance(resp, str) and resp.startswith("http"):
            diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
            return Outcome(OK, data=resp, raw=safe, extra={"broker_diagnostics": diag})
        return Outcome(UNKNOWN if state_changing else UNKNOWN, message="Unrecognised broker response type.", raw=safe,
                       extra={"broker_diagnostics": diag})

    em = resp.get("Error Message")
    if isinstance(em, str) and _NOT_AUTH_MARKER in em.lower():
        diag["session_auth_indication"] = "SESSION_MISSING_2FA"
        diag["kotak_err_msg"] = em
        return Outcome(AUTH, message="No trade session: complete login (totp_login + totp_validate) first.",
                       raw=safe, extra={"broker_diagnostics": diag})

    for key in ("Error", "error"):
        if key in resp and resp[key] not in (None, "", [], {}):
            err = resp[key]
            text = _text_of(err) or "Broker call failed."
            low = text.lower()
            diag["kotak_err_msg"] = diag.get("kotak_err_msg") or text[:1000]
            if any(m in low for m in _SESSION_MARKERS):
                st = _status_of_exception(err) if isinstance(err, BaseException) else None
                auth_code = str(st) if st in _AUTH_HTTP_CODES else None
                diag["session_auth_indication"] = "SESSION_INVALID"
                diag["response_classification"] = "AUTH_HTTP" if auth_code else "AUTH_MARKER"
                return Outcome(AUTH, message=text[:500], code=auth_code, raw=safe, extra={"broker_diagnostics": diag})
            if isinstance(err, BaseException):
                name = type(err).__name__
                st = _status_of_exception(err)
                if name in ("ApiValueError", "ApiTypeError", "ApiKeyError", "ApiAttributeError", "ValueError", "TypeError"):
                    diag["session_auth_indication"] = "NOT_AUTH_FAILURE"
                    return Outcome(REJECTED, message=text[:500], code="VALIDATION", raw=safe, extra={"broker_diagnostics": diag})
                if st in _AUTH_HTTP_CODES:
                    diag["http_status"] = st
                    diag["session_auth_indication"] = "SESSION_INVALID"
                    diag["response_classification"] = "AUTH_HTTP"
                    return Outcome(AUTH, message=text[:500], code=str(st), raw=safe, extra={"broker_diagnostics": diag})
                if st is not None and st >= 400:
                    diag["http_status"] = st
                    if state_changing and st >= 500:
                        # 500/502/503/504 on an order-changing call: the gateway could not
                        # confirm what the OMS did, so the order MAY exist. Never "rejected".
                        diag["session_auth_indication"] = "UNKNOWN_TRANSPORT"
                        diag["transport_exception"] = f"{name}: HTTP {st}: {text}"[:500]
                        return Outcome(UNKNOWN, message=text[:500], code=str(st), raw=safe, extra={"broker_diagnostics": diag})
                    diag["session_auth_indication"] = "NOT_AUTH_FAILURE"
                    return Outcome(REJECTED, message=text[:500], code=str(st), raw=safe, extra={"broker_diagnostics": diag})
                diag["session_auth_indication"] = "UNKNOWN_TRANSPORT"
                diag["transport_exception"] = f"{name}: {text}"[:500]
                return Outcome(UNKNOWN if state_changing else REJECTED, message=text[:500], code="TRANSPORT", raw=safe, extra={"broker_diagnostics": diag})
            if state_changing and ("exception has been occurred" in low or "connecting to api" in low):
                diag["session_auth_indication"] = "UNKNOWN_TRANSPORT"
                diag["transport_exception"] = text[:500]
                return Outcome(UNKNOWN, message=text[:500], code="TRANSPORT", raw=safe, extra={"broker_diagnostics": diag})
            diag["session_auth_indication"] = "NOT_AUTH_FAILURE"
            return Outcome(REJECTED, message=text[:500], code=_first_code(err), raw=safe, extra={"broker_diagnostics": diag})

    st_code_i = _int_or_none(resp.get("stCode"))
    http_status = _int_or_none(resp.get("status_code"))
    error_code_i = _int_or_none(resp.get("errorCode"))
    stat = str(resp.get("stat", "")).strip().lower()
    status_field = str(resp.get("status", "")).strip().lower()
    err_msg = _text_of(resp.get("errMsg") or resp.get("emsg") or resp.get("message"))
    failed = ((st_code_i is not None and st_code_i != 200) or (http_status is not None and http_status >= 400)
              or bool(resp.get("errMsg")) or stat in ("not_ok", "notok")
              or status_field in ("error", "failed", "failure")
              or (error_code_i is not None and error_code_i >= 400))
    if failed:
        text = err_msg or _text_of(resp.get("stat")) or _text_of(resp.get("error")) or "Broker rejected the request."
        low = text.lower()
        effective_code = resp.get("stCode") if resp.get("stCode") is not None else (http_status if http_status is not None else resp.get("errorCode"))
        if st_code_i in _AUTH_HTTP_CODES or http_status in _AUTH_HTTP_CODES or error_code_i in _AUTH_HTTP_CODES or any(m in low for m in _SESSION_MARKERS):
            auth_code = st_code_i if st_code_i in _AUTH_HTTP_CODES else (http_status if http_status in _AUTH_HTTP_CODES else (error_code_i if error_code_i in _AUTH_HTTP_CODES else 401))
            diag["session_auth_indication"] = "SESSION_INVALID"
            diag["response_classification"] = "AUTH_HTTP" if auth_code in _AUTH_HTTP_CODES else "AUTH_MARKER"
            return Outcome(AUTH, message=text[:500], code=str(auth_code), raw=safe, extra={"broker_diagnostics": diag})
        if error_code_i == 429 or http_status == 429 or "too many requests" in low or "rate limit" in low:
            diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
            return Outcome(REJECTED, message=text[:500], code="429", raw=safe, extra={"broker_diagnostics": diag})
        diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
        if state_changing and http_status is not None and http_status >= 500:
            # Documented 500/502/503/504 mean the trade API could not confirm the OMS outcome.
            diag["session_auth_indication"] = "UNKNOWN_TRANSPORT"
            diag["transport_exception"] = f"HTTP {http_status}: {text}"[:500]
            return Outcome(UNKNOWN, message=text[:500], code=str(http_status), raw=safe, extra={"broker_diagnostics": diag})
        return Outcome(REJECTED, message=text[:500], code=str(effective_code) if effective_code is not None else None, raw=safe,
                       extra={"broker_diagnostics": diag})

    diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
    if expect_order_id:
        oid = resp.get("nOrdNo")
        if oid:
            return Outcome(OK, order_id=str(oid), data=safe, raw=safe, extra={"broker_diagnostics": diag})
        return Outcome(UNKNOWN, message="Broker response carried no order number (nOrdNo).", raw=safe, extra={"broker_diagnostics": diag})
    return Outcome(OK, data=safe, raw=safe, extra={"broker_diagnostics": diag})

def _auth_stage_code(outcome: "Outcome", stage: str) -> str:
    """Maps a classify() outcome for one login sub-step to the exact
    authentication stage that failed, so the Settings UI and tests can
    distinguish a wrong TOTP from a wrong MPIN from a broker-side/
    transport problem instead of one generic "auth failed".

    Checked via classify()'s own `code` marker first, not just `kind`:
    totp_login/totp_validate are not "state_changing" calls, so a
    transport failure (status 0 -- timeout/connect error) classifies as
    REJECTED there, not UNKNOWN (see classify()'s docstring) -- `code`
    is what actually says "we don't know what happened", so it must be
    checked ahead of, and independently of, `kind`.
    """
    if outcome.code == "429":
        return "RATE_LIMITED"
    if outcome.code == "TRANSPORT" or outcome.kind == UNKNOWN:
        return "TRANSPORT_ERROR"
    if stage == "totp_login":
        return "TOTP_LOGIN_FAILED"
    if stage == "totp_validate":
        return "MPIN_VALIDATION_FAILED"
    return "BROKER_REJECTED"


def _first_code(err: Any) -> str | None:
    if isinstance(err, list) and err and isinstance(err[0], dict):
        c = err[0].get("code")
        return str(c) if c is not None else None
    return None


def _validate_collection_outcome(outcome: Outcome, section: str) -> Outcome:
    """Reject an apparently successful collection response that has no data container.

    The reconciliation layer treats an OK collection as authoritative. Therefore a
    malformed/HTML/partial JSON response must never silently become ``[]`` through
    rows_of(). Explicit 5203/424 empty responses are already normalized before this
    function is called.
    """
    if not outcome.ok:
        return outcome
    data = outcome.data
    valid = isinstance(data, list)
    if isinstance(data, dict):
        inner = data.get("data")
        valid = isinstance(inner, list) or (isinstance(inner, dict) and isinstance(inner.get("data"), list))
    if valid:
        return outcome
    diag = dict((outcome.extra or {}).get("broker_diagnostics") or {})
    diag["response_classification"] = "KOTAK_MALFORMED_READ_RESPONSE"
    diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
    return Outcome(UNKNOWN, message=f"Malformed {section} response: expected a data collection.",
                   code="MALFORMED_RESPONSE", data=None, raw=outcome.raw,
                   extra={"broker_diagnostics": diag})


def _validate_limits_outcome(outcome: Outcome) -> Outcome:
    """Require the documented flat limits fields before treating a limits read as OK."""
    if not outcome.ok:
        return outcome
    data = outcome.data
    if isinstance(data, dict) and ("Net" in data or "MarginUsed" in data or any(k in data for k in (
        "CashRlsMtomPrsnt", "CashUnRlsMtomPrsnt", "FoRlsMtomPrsnt", "FoUnRlsMtomPrsnt",
        "ComRlsMtomPrsnt", "ComUnRlsMtomPrsnt", "CurRlsMtomPrsnt", "CurUnRlsMtomPrsnt"))):
        return outcome
    diag = dict((outcome.extra or {}).get("broker_diagnostics") or {})
    diag["response_classification"] = "KOTAK_MALFORMED_LIMITS_RESPONSE"
    diag["session_auth_indication"] = "SESSION_PRESENT_BROKER_REPLIED"
    return Outcome(UNKNOWN, message="Malformed limits response: expected the documented flat limits fields.",
                   code="MALFORMED_RESPONSE", raw=outcome.raw,
                   extra={"broker_diagnostics": diag})


class MarginUnavailableError(ValueError):
    """The margin_required response cannot be turned into a trustworthy number."""


def _margin_amount(v: Any) -> Decimal | None:
    if v is None or isinstance(v, bool) or (isinstance(v, str) and not v.strip()):
        return None
    try:
        d = Decimal(str(v).strip().replace(",", ""))
    except (InvalidOperation, ValueError):
        return None
    return d if d.is_finite() and d >= 0 else None


def parse_margin_required(data: Any) -> dict:
    """Parse the OFFICIAL margin_required body (docs/functions/portfolio/margin_required.md):

        {"data": {"avlCash","totMrgnUsd","mrgnUsd","ordMrgn","rmsVldtd","reqdMrgn",
                  "avlMrgn","insufFund","stat","stCode"}}

    Returns {"required_margin", "order_margin", "reqd_margin", "insufficient_funds",
    "available_cash", "rms_validated"} (floats). Raises MarginUnavailableError when the
    body is nested-failed, malformed, RMS-rejected, reports insufficient funds, or has no
    parseable order margin -- callers must then BLOCK the entry.
    Required margin is the larger of ordMrgn / reqdMrgn (both are non-negative amounts), so
    an ambiguous field can never under-state the requirement.
    """
    body = data
    if isinstance(body, dict) and isinstance(body.get("data"), dict):
        body = body["data"]
    if not isinstance(body, dict):
        raise MarginUnavailableError("margin_required returned no data object.")
    stat = str(body.get("stat", "")).strip().lower()
    st_code = _int_or_none(body.get("stCode"))
    if stat in ("not_ok", "notok") or (st_code is not None and st_code != 200) or body.get("errMsg") or body.get("error") or body.get("Error"):
        raise MarginUnavailableError(f"margin_required failed: {_text_of(body.get('errMsg') or body.get('emsg') or body.get('error') or body.get('stat'))[:200] or 'broker error'}")
    rms = body.get("rmsVldtd")
    if rms is not None and str(rms).strip().upper() != "OK":
        raise MarginUnavailableError(f"Kotak RMS validation did not pass (rmsVldtd={str(rms)[:40]!r}).")
    order_margin = _margin_amount(body.get("ordMrgn"))
    reqd = _margin_amount(body.get("reqdMrgn"))
    if order_margin is None:
        raise MarginUnavailableError("margin_required response has no parseable ordMrgn.")
    if body.get("insufFund") is not None:
        insuf = _margin_amount(body.get("insufFund"))
        if insuf is None:
            raise MarginUnavailableError("margin_required insufFund is not a valid amount.")
    else:
        insuf = Decimal(0)
    if insuf > 0:
        raise MarginUnavailableError(f"Kotak reports insufficient funds (insufFund={insuf}).")
    required = max(order_margin, reqd) if reqd is not None else order_margin
    cash = _margin_amount(body.get("avlCash"))
    return {
        "required_margin": float(required), "order_margin": float(order_margin),
        "reqd_margin": float(reqd) if reqd is not None else None,
        "insufficient_funds": float(insuf), "available_cash": float(cash) if cash is not None else None,
        "rms_validated": rms is not None,
    }


def rows_of(outcome: Outcome) -> list[dict]:
    """Extract the list of row dicts from an OK outcome's `data`. Orders,
    trades, positions and holdings responses are {"data": [ {...}, ... ]};
    order_history is {"data": {"stat":..,"data":[...]}} (per the SDK docs)."""
    d = outcome.data
    if isinstance(d, list):
        return [r for r in d if isinstance(r, dict)]
    if isinstance(d, dict):
        inner = d.get("data")
        if isinstance(inner, list):
            return [r for r in inner if isinstance(r, dict)]
        if isinstance(inner, dict) and isinstance(inner.get("data"), list):
            return [r for r in inner["data"] if isinstance(r, dict)]
    return []


# ------------------------------------------------------------------------ #
# Order request -> exact SDK kwargs
# ------------------------------------------------------------------------ #
class OrderRequestError(ValueError):
    """The request violates the SDK's own validation rules; raised BEFORE any
    network call so it is always a clean, definitive rejection."""


def fmt_price(value: Any) -> str:
    """Decimal-exact price string, at least 2 decimals ("9.39", "100.00").
    Avoids float artefacts like 0.1+0.2. Never scientific notation."""
    try:
        d = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise OrderRequestError(f"Invalid price {value!r}.")
    if not d.is_finite() or d < 0:
        raise OrderRequestError("Price must be a finite, non-negative number.")
    d = d.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)   # kills float noise (0.1+0.2); NSE/BSE tick is <= 4 dp
    s = format(d.normalize(), "f")
    if "." not in s:
        s += ".00"
    elif len(s.split(".")[1]) < 2:
        s += "0" * (2 - len(s.split(".")[1]))
    return s


@dataclass
class OrderRequest:
    exchange_segment: str
    trading_symbol: str
    transaction_type: str
    order_type: str
    product: str
    quantity: int
    validity: str = "DAY"
    price: Any = None
    trigger_price: Any = None
    tag: str | None = None
    amo: str = "NO"
    disclosed_quantity: int = 0

    def validate(self) -> None:
        if self.exchange_segment not in EXCHANGE_SEGMENTS:
            raise OrderRequestError(f"exchange_segment must be one of {list(EXCHANGE_SEGMENTS)}.")
        if self.product not in PRODUCTS:
            raise OrderRequestError(f"product must be one of {list(PRODUCTS)}.")
        if self.order_type not in ORDER_TYPES:
            raise OrderRequestError(f"order_type must be one of {list(ORDER_TYPES)}.")
        if self.transaction_type not in TRANSACTION_TYPES:
            raise OrderRequestError("transaction_type must be 'B' or 'S'.")
        if self.validity not in VALIDITY_BY_SEGMENT[self.exchange_segment]:
            raise OrderRequestError(
                f"validity must be one of {list(VALIDITY_BY_SEGMENT[self.exchange_segment])} for {self.exchange_segment}."
            )
        if not str(self.trading_symbol or "").strip():
            raise OrderRequestError("trading_symbol is required (pTrdSymbol from the scrip master).")
        if not isinstance(self.quantity, int) or isinstance(self.quantity, bool) or self.quantity <= 0:
            raise OrderRequestError("quantity must be a positive integer.")
        if self.amo not in ("YES", "NO"):
            raise OrderRequestError("amo must be 'YES' or 'NO'.")
        if self.order_type in PRICE_REQUIRED_ORDER_TYPES and (self.price is None or Decimal(str(self.price)) <= 0):
            raise OrderRequestError(f"price must be > 0 for order_type={self.order_type}.")
        if self.order_type in TRIGGER_REQUIRED_ORDER_TYPES and (self.trigger_price is None or Decimal(str(self.trigger_price)) <= 0):
            raise OrderRequestError(f"trigger_price must be > 0 for order_type={self.order_type}.")
        if self.tag is not None and not str(self.tag).strip():
            raise OrderRequestError("tag must be non-blank when provided.")

    def to_sdk_kwargs(self) -> dict[str, str | None]:
        """The exact keyword arguments of NeoAPI.place_order (all strings)."""
        self.validate()
        price = fmt_price(self.price) if self.price is not None else "0"
        if self.order_type in ("MKT", "SL-M") and self.price is None:
            price = "0"
        trigger = fmt_price(self.trigger_price) if self.trigger_price is not None else "0"
        kwargs: dict[str, str | None] = {
            "exchange_segment": self.exchange_segment,
            "product": self.product,
            "price": price,
            "order_type": self.order_type,
            "quantity": str(int(self.quantity)),
            "validity": self.validity,
            "trading_symbol": self.trading_symbol.strip(),
            "transaction_type": self.transaction_type,
            "amo": self.amo,
            "disclosed_quantity": str(int(self.disclosed_quantity)),
            "trigger_price": trigger,
        }
        if self.tag:
            kwargs["tag"] = str(self.tag)
        return kwargs


# ------------------------------------------------------------------------ #
# The adapter
# ------------------------------------------------------------------------ #
class KotakSdk:
    """One authenticated NeoAPI session. All methods are SYNCHRONOUS (the SDK
    uses blocking httpx); callers run them in an executor."""

    def __init__(self, consumer_key: str, environment: str = "prod", *, neo_factory: Callable[..., Any] | None = None, timeout: float | None = None):
        factory = neo_factory or NeoAPI
        if factory is None:
            raise RuntimeError(f"Official SDK not importable: {SDK_IMPORT_ERROR}")
        # NeoAPI.__init__(consumer_key, environment, access_token, neo_fin_key, transport, limits, http2, timeout)
        kwargs = {"consumer_key": consumer_key, "environment": environment}
        if timeout is not None:
            kwargs["timeout"] = float(timeout)
        self._neo = factory(**kwargs)

    # -- authentication ---------------------------------------------------
    def login(self, *, mobile_number: str, ucc: str, totp: str, mpin: str) -> Outcome:
        """totp_login(mobile_number, ucc, totp) then totp_validate(mpin).
        Returns OK only when a TRADE session (edit_token + edit_sid) exists.

        Every non-OK return carries a `code` naming the exact stage that
        failed (TOTP_LOGIN_FAILED / MPIN_VALIDATION_FAILED /
        SESSION_VERIFICATION_FAILED / TRANSPORT_ERROR / RATE_LIMITED /
        BROKER_REJECTED) so callers -- and the Settings UI -- can tell a
        rejected TOTP apart from a rejected MPIN apart from a broker-side
        session-verification problem, instead of one flat "auth failed".
        The underlying broker message (already sanitised by classify(),
        never a secret) is preserved in `message`.
        """
        r1 = self._neo.totp_login(mobile_number=mobile_number, ucc=ucc, totp=totp)
        o1 = classify(r1)
        data1 = r1.get("data") if isinstance(r1, dict) else None
        if not o1.ok or not isinstance(data1, dict):
            code1 = _auth_stage_code(o1, "totp_login")
            outer1 = UNKNOWN if code1 in ("TRANSPORT_ERROR", "RATE_LIMITED") else REJECTED
            return Outcome(
                outer1,
                message=f"Kotak rejected the TOTP login step: {o1.message or 'no data in response'}",
                code=code1,
            )
        r2 = self._neo.totp_validate(mpin=mpin)
        o2 = classify(r2)
        data2 = r2.get("data") if isinstance(r2, dict) else None
        if not o2.ok or not isinstance(data2, dict):
            code2 = _auth_stage_code(o2, "totp_validate")
            outer2 = UNKNOWN if code2 in ("TRANSPORT_ERROR", "RATE_LIMITED") else REJECTED
            return Outcome(
                outer2,
                message=f"Kotak rejected the MPIN validation step: {o2.message or 'no data in response'}",
                code=code2,
            )
        ktype = data2.get("kType")
        if ktype not in (None, "Trade"):
            return Outcome(REJECTED, message=f"totp_validate returned kType={ktype!r}, not a Trade session.",
                           code="SESSION_VERIFICATION_FAILED")
        if not (self.has_trade_session()):
            return Outcome(REJECTED, message="totp_validate reported success but no usable trade session was established.",
                           code="SESSION_VERIFICATION_FAILED")
        return Outcome(OK, data={"data_center": self.data_center(), "ucc": data2.get("ucc") or data1.get("ucc")})

    def has_trade_session(self) -> bool:
        cfg = getattr(self._neo, "configuration", None)
        return bool(getattr(cfg, "edit_token", None) and getattr(cfg, "edit_sid", None))

    def data_center(self) -> str | None:
        return getattr(getattr(self._neo, "configuration", None), "data_center", None)

    def session_summary(self) -> dict:
        cfg = getattr(self._neo, "configuration", None)
        return {
            "trade_session": self.has_trade_session(),
            "data_center": getattr(cfg, "data_center", None),
            "base_url_present": bool(getattr(cfg, "base_url", None)),
            "ucc": getattr(cfg, "ucc", None),
        }

    def logout(self) -> Outcome:
        # SDK 3.0.7 logout() only clears local tokens (no network call).
        return classify(self._neo.logout())

    # -- orders -----------------------------------------------------------
    def place_order(self, req: OrderRequest) -> Outcome:
        kwargs = req.to_sdk_kwargs()  # raises OrderRequestError -> never sent
        return classify(self._neo.place_order(**kwargs), expect_order_id=True, state_changing=True)

    def modify_order(self, *, order_id: str, order_type: str, quantity: int, validity: str,
                     price: Any = None, trigger_price: Any = None, amo: str = "NO", disclosed_quantity: int = 0) -> Outcome:
        if not str(order_id or "").strip():
            raise OrderRequestError("order_id is required.")
        if order_type not in ORDER_TYPES:
            raise OrderRequestError(f"order_type must be one of {list(ORDER_TYPES)}.")
        if validity not in ("DAY", "IOC"):  # modify_order has no segment; SDK checks DAY/IOC
            raise OrderRequestError("validity must be DAY or IOC for modify.")
        if not isinstance(quantity, int) or quantity <= 0:
            raise OrderRequestError("quantity must be a positive integer.")
        if order_type in PRICE_REQUIRED_ORDER_TYPES and (price is None or Decimal(str(price)) <= 0):
            raise OrderRequestError(f"price must be > 0 for order_type={order_type}.")
        if order_type in TRIGGER_REQUIRED_ORDER_TYPES and (trigger_price is None or Decimal(str(trigger_price)) <= 0):
            raise OrderRequestError(f"trigger_price must be > 0 for order_type={order_type}.")
        return classify(
            self._neo.modify_order(
                order_id=str(order_id),
                price=fmt_price(price) if price is not None else "0",
                order_type=order_type,
                quantity=str(int(quantity)),
                validity=validity,
                trigger_price=fmt_price(trigger_price) if trigger_price is not None else "0",
                disclosed_quantity=str(int(disclosed_quantity)),
                amo=amo,
            ),
            expect_order_id=True, state_changing=True,
        )

    def cancel_order(self, *, order_id: str, amo: str = "NO") -> Outcome:
        if not str(order_id or "").strip():
            raise OrderRequestError("order_id is required.")
        return classify(self._neo.cancel_order(order_id=str(order_id), amo=amo), expect_order_id=True, state_changing=True)

    # -- read-only order/portfolio data -----------------------------------
    def order_report(self, order_id: str | None = None) -> Outcome:
        ep = _endpoint_for_sdk_method(self._neo, "order_report", order_id) if order_id else _endpoint_for_sdk_method(self._neo, "order_report")
        try:
            resp = self._neo.order_report(order_id=order_id) if order_id else self._neo.order_report()
            out = _empty_read_response(resp, "orders", _diagnostics(resp, method="order_report", endpoint=ep)) or classify(resp, method="order_report", endpoint=ep)
        except Exception as exc:  # noqa: BLE001 - adapter must classify SDK transport/API exceptions
            out = _classify_read_exception(exc, method="order_report", endpoint=ep, section="orders")
        return _validate_collection_outcome(out, "orders")

    def order_history(self, order_id: str) -> Outcome:
        return classify(self._neo.order_history(order_id=str(order_id)))

    def trade_report(self) -> Outcome:
        ep = _endpoint_for_sdk_method(self._neo, "trade_report")
        try:
            resp = self._neo.trade_report()
            out = _empty_read_response(resp, "trades", _diagnostics(resp, method="trade_report", endpoint=ep)) or classify(resp, method="trade_report", endpoint=ep)
        except Exception as exc:  # noqa: BLE001 - adapter must classify SDK transport/API exceptions
            out = _classify_read_exception(exc, method="trade_report", endpoint=ep, section="trades")
        return _validate_collection_outcome(out, "trades")

    def positions(self) -> Outcome:
        ep = _endpoint_for_sdk_method(self._neo, "positions")
        try:
            resp = self._neo.positions()
            diag = _diagnostics(resp, method="positions", endpoint=ep)
            out = _empty_read_response(resp, "positions", diag) or classify(resp, method="positions", endpoint=ep)
        except Exception as exc:  # noqa: BLE001 - adapter must classify SDK transport/API exceptions
            out = _classify_read_exception(exc, method="positions", endpoint=ep, section="positions")
        return _validate_collection_outcome(out, "positions")

    def holdings(self) -> Outcome:
        ep = _endpoint_for_sdk_method(self._neo, "holdings")
        try:
            resp = self._neo.holdings()
            diag = _diagnostics(resp, method="holdings", endpoint=ep)
            out = _empty_read_response(resp, "holdings", diag) or classify(resp, method="holdings", endpoint=ep)
        except Exception as exc:  # noqa: BLE001 - adapter must classify SDK transport/API exceptions
            out = _classify_read_exception(exc, method="holdings", endpoint=ep, section="holdings")
        return _validate_collection_outcome(out, "holdings")

    def limits(self) -> Outcome:
        out = classify(self._neo.limits(), method="limits", endpoint=_endpoint_for_sdk_method(self._neo, "limits"))
        return _validate_limits_outcome(out)

    def margin_required(self, *, exchange_segment: str, price: Any, order_type: str, product: str,
                        quantity: int, instrument_token: str, transaction_type: str, trigger_price: Any = None) -> Outcome:
        return classify(self._neo.margin_required(
            exchange_segment=exchange_segment, price=fmt_price(price if price is not None else 0),
            order_type=order_type, product=product, quantity=str(int(quantity)),
            instrument_token=str(instrument_token), transaction_type=transaction_type,
            trigger_price=fmt_price(trigger_price) if trigger_price is not None else None,
        ))

    def whatsmyip(self) -> Outcome:
        return classify(self._neo.whatsmyip())

    # -- derivatives market data (expiries / option_chain / historical_data) --
    # These three accept only consumer_key per the official docs (no totp_validate
    # required), but this adapter still requires a live KotakSdk instance, which
    # broker_client only creates after a successful /connect -- consistent with
    # how quotes()/scrip_master() are already gated in this project.
    def expiries(self, *, exchange: str, underlying: str, instrument_type: str | None = None) -> Outcome:
        if exchange not in DERIVATIVE_SEGMENTS:
            raise OrderRequestError(f"exchange must be one of {list(DERIVATIVE_SEGMENTS)}.")
        if not str(underlying or "").strip():
            raise OrderRequestError("underlying is required.")
        if instrument_type is not None and instrument_type not in INSTRUMENT_TYPES:
            raise OrderRequestError(f"instrument_type must be one of {list(INSTRUMENT_TYPES)}.")
        return classify(self._neo.expiries(exchange=exchange, underlying=underlying.strip(), instrument_type=instrument_type))

    def option_chain(self, *, exchange: str, underlying: str, expiry: str | None = None,
                     instrument_type: str | None = None, count: int | None = None) -> Outcome:
        if exchange not in DERIVATIVE_SEGMENTS:
            raise OrderRequestError(f"exchange must be one of {list(DERIVATIVE_SEGMENTS)}.")
        if not str(underlying or "").strip():
            raise OrderRequestError("underlying is required.")
        if instrument_type is not None and instrument_type not in INSTRUMENT_TYPES:
            raise OrderRequestError(f"instrument_type must be one of {list(INSTRUMENT_TYPES)}.")
        if count is not None and (not isinstance(count, int) or isinstance(count, bool) or count <= 0):
            raise OrderRequestError("count must be a positive integer.")
        return classify(self._neo.option_chain(exchange=exchange, underlying=underlying.strip(), expiry=expiry,
                                               instrument_type=instrument_type, count=count))

    def historical_data(self, *, neosymbol: str, interval: str, from_date: str, to_date: str) -> Outcome:
        if not str(neosymbol or "").strip() or "|" not in str(neosymbol):
            raise OrderRequestError('neosymbol must be "{exchange_segment}|{instrument_token}", e.g. "nse_cm|1333".')
        seg = str(neosymbol).split("|", 1)[0]
        if seg in HISTORICAL_UNSUPPORTED_SEGMENTS:
            raise OrderRequestError(f"historical_data is not available for {seg}.")
        if interval not in HISTORICAL_INTERVALS:
            raise OrderRequestError(f"interval must be one of {list(HISTORICAL_INTERVALS)}.")
        if not str(from_date or "").strip() or not str(to_date or "").strip():
            raise OrderRequestError("from_date and to_date are required (YYYY-MM-DD).")
        return classify(self._neo.historical_data(neosymbol=str(neosymbol), interval=interval,
                                                  from_date=str(from_date), to_date=str(to_date)))

    # -- market data (REST) -----------------------------------------------
    def quotes(self, tokens: list[tuple[str, str]], quote_type: str | None = None) -> Outcome:
        """tokens: [(exchange_segment, instrument_token), ...] (max 50 per call, backend-enforced)."""
        if not tokens:
            raise OrderRequestError("At least one instrument is required.")
        payload = [{"instrument_token": str(t), "exchange_segment": s} for s, t in tokens]
        return classify(self._neo.quotes(instrument_tokens=payload, quote_type=quote_type))

    def scrip_master(self, exchange_segment: str | None = None) -> Outcome:
        return classify(self._neo.scrip_master(exchange_segment=exchange_segment))

    def search_scrip(self, *, exchange_segment: str, symbol: str = "", expiry: str | None = None,
                     option_type: str | None = None, strike_price: str | None = None) -> Outcome:
        return classify(self._neo.search_scrip(
            exchange_segment=exchange_segment, symbol=symbol, expiry=expiry,
            option_type=option_type, strike_price=strike_price,
        ))

    # -- websockets (async SFeed / order feed; legacy subscribe() is NOT used) --
    def create_market_feed(self, **kwargs):
        return self._neo.create_websocket(**kwargs)

    def create_order_feed(self, **kwargs):
        return self._neo.create_order_feed(**kwargs)


def make_ws_token(exchange_segment: str, instrument_token: str):
    """neo_api_client.websocket.feed.WsToken(exchange_segment, instrument_token)."""
    from neo_api_client.websocket.feed import WsToken  # local: keeps import cost/failure contained
    return WsToken(exchange_segment, str(instrument_token))
