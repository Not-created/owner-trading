import unittest

from app import order_service as osv
from app import universe
from tests.dbutil import fresh_db


def payload(**kw):
    p = dict(trading_symbol="ABC-EQ", exchange_segment="nse_cm", transaction_type="B", order_type="L", product="CNC",
             validity="DAY", quantity=10, price=100.05, instrument_token="500", order_role="MANUAL")
    p.update(kw)
    return p


class IdentityLotTick(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments([
            {"trading_symbol": "ABC-EQ", "instrument_token": "500", "lot_size": 1, "tick_size": 0.05},
            {"trading_symbol": "LOT-EQ", "instrument_token": "501", "lot_size": 25, "tick_size": 0.05},
            {"trading_symbol": "NOTICK-EQ", "instrument_token": "502", "lot_size": 1, "tick_size": None},
        ])

    def test_valid_order_passes(self):
        self.assertEqual(osv._validate(payload())["instrument_token"], "500")

    def test_unknown_instrument_is_blocked(self):
        with self.assertRaisesRegex(osv.OrderValidationError, "not in the synced scrip master"):
            osv._validate(payload(instrument_token="999"))

    def test_symbol_token_mismatch_is_blocked(self):
        with self.assertRaisesRegex(osv.OrderValidationError, "identity mismatch"):
            osv._validate(payload(trading_symbol="LOT-EQ"))        # token 500 is ABC-EQ
        with self.assertRaisesRegex(osv.OrderValidationError, "not in the synced scrip master"):
            osv._validate(payload(exchange_segment="bse_cm"))      # same token, other segment

    def test_symbol_match_is_case_insensitive_not_substring(self):
        self.assertTrue(osv._validate(payload(trading_symbol="abc-eq")))
        with self.assertRaises(osv.OrderValidationError):
            osv._validate(payload(trading_symbol="ABC"))

    def test_lot_size_multiple_enforced(self):
        with self.assertRaisesRegex(osv.OrderValidationError, "lot size 25"):
            osv._validate(payload(trading_symbol="LOT-EQ", instrument_token="501", quantity=30, price=100))
        self.assertTrue(osv._validate(payload(trading_symbol="LOT-EQ", instrument_token="501", quantity=50, price=100)))

    def test_tick_size_enforced_on_price_and_trigger(self):
        with self.assertRaisesRegex(osv.OrderValidationError, "tick size"):
            osv._validate(payload(price=100.03))
        with self.assertRaisesRegex(osv.OrderValidationError, "tick size"):
            osv._validate(payload(order_type="SL", price=100.05, trigger_price=99.97))
        self.assertTrue(osv._validate(payload(order_type="SL", price=100.05, trigger_price=100.0)))

    def test_float_noise_does_not_false_block(self):
        self.assertTrue(osv._validate(payload(price=0.1 + 0.2 + 100)))   # 100.30000000000001

    def test_unknown_tick_blocks_priced_orders_but_not_market(self):
        with self.assertRaisesRegex(osv.OrderValidationError, "Tick size .* unknown"):
            osv._validate(payload(trading_symbol="NOTICK-EQ", instrument_token="502"))
        self.assertTrue(osv._validate(payload(trading_symbol="NOTICK-EQ", instrument_token="502", order_type="MKT", price=None)))


class ScripMasterColumns(unittest.TestCase):
    def test_official_columns_are_parsed(self):
        row = {"pSymbol": "11915", "pTrdSymbol": "YESBANK-EQ", "dTickSize": "5", "lPrecision": "2", "lLotSize": "1", "dStrikePrice;": "-1"}
        self.assertEqual(universe._tick_size(row), 0.05)
        self.assertEqual(universe._lot_size(row), 1)
        self.assertIsNone(universe._strike(row))

    def test_precision_defaults_and_legacy_columns(self):
        self.assertEqual(universe._tick_size({"dTickSize": "1"}), 0.01)
        self.assertEqual(universe._tick_size({"pTickSize": "0.05"}), 0.05)
        self.assertIsNone(universe._tick_size({}))
        self.assertIsNone(universe._tick_size({"dTickSize": "0"}))
        self.assertIsNone(universe._lot_size({"lLotSize": "abc"}))
        self.assertEqual(universe._strike({"dStrikePrice": "1500"}), 1500.0)


if __name__ == "__main__":
    unittest.main()


class ModifyValidation(unittest.IsolatedAsyncioTestCase):
    async def test_modify_enforces_tick_and_rejects_bad_quantity(self):
        db = fresh_db()
        db.bulk_upsert_instruments([{"trading_symbol": "ABC-EQ", "instrument_token": "500", "lot_size": 1, "tick_size": 0.05}])
        db.create_order(internal_order_id="M1", trading_symbol="ABC-EQ", exchange_segment="nse_cm", transaction_type="B",
                        order_type="L", product="CNC", validity="DAY", quantity=10, price=100.0, trigger_price=None,
                        mode="LIVE", status="OPEN", client_tag="TAGM1", instrument_token="500", order_role="MANUAL")
        db.update_order(internal_order_id="M1", broker_order_id="B1")
        with self.assertRaisesRegex(osv.OrderValidationError, "tick size"):
            await osv.modify_order("M1", {"price": 100.03})
        for bad in ("abc", 0, -5, 2.5, True):
            with self.assertRaisesRegex(osv.OrderValidationError, "positive integer"):
                await osv.modify_order("M1", {"quantity": bad})


class OrderFeedPreSubscribe(unittest.IsolatedAsyncioTestCase):
    async def test_entry_subscribes_instrument_and_waits_for_first_tick(self):
        from unittest.mock import patch, AsyncMock
        calls = {"n": 0}

        def fresh(tok, sym, seg):
            calls["n"] += 1
            return None if calls["n"] < 3 else 101.0
        sub = AsyncMock()
        with patch("app.market_prices.fresh_ltp", fresh), patch("app.websocket_manager.websocket_manager.subscribe", sub):
            await osv._ensure_live_price_feed(payload())
        sub.assert_awaited_once()
        self.assertEqual(sub.await_args.kwargs["owner"], "order:nse_cm:500")

    async def test_exit_and_already_fresh_do_not_subscribe(self):
        from unittest.mock import patch, AsyncMock
        sub = AsyncMock()
        with patch("app.market_prices.fresh_ltp", return_value=100.0), patch("app.websocket_manager.websocket_manager.subscribe", sub):
            await osv._ensure_live_price_feed(payload())
            await osv._ensure_live_price_feed(payload(order_role="EXIT"))
        sub.assert_not_awaited()

    async def test_subscription_failure_is_swallowed_so_gate_reports_real_reason(self):
        from unittest.mock import patch, AsyncMock
        with patch("app.market_prices.fresh_ltp", return_value=None), \
             patch("app.websocket_manager.websocket_manager.subscribe", AsyncMock(side_effect=RuntimeError("feed down"))):
            await osv._ensure_live_price_feed(payload())            # must not raise
