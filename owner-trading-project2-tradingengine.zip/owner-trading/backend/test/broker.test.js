// Set before any module that reads it is required, so config.js caches a
// usable key for this test file's process (node:test isolates each test
// file into its own process by default, so this doesn't leak elsewhere).
process.env.CREDENTIAL_ENCRYPTION_KEY = require('node:crypto').randomBytes(32).toString('hex');

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const config = require('../src/config/env');
const { getDb, closeDb } = require('../src/db/connection');
const { ensureAdminBootstrap } = require('../src/services/adminBootstrap');
const { getRawCredentials } = require('../src/services/brokerCredentialService');
const app = require('../server');

function extractCookie(setCookieHeaders, name) {
  if (!setCookieHeaders) return null;
  const match = setCookieHeaders.find((c) => c.startsWith(`${name}=`));
  return match ? match.split(';')[0] : null;
}

function resetDatabaseFile() {
  closeDb();
  for (const suffix of ['', '-wal', '-shm', '-journal']) {
    const p = config.databasePath + suffix;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

test('Kotak credential storage: gated by password-change, masked, encrypted, deletable', async (t) => {
  resetDatabaseFile();
  const db = getDb();
  const { username, password: tempPassword } = ensureAdminBootstrap(db);

  const server = app.listen(0);
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}/api`;

  const loginRes = await fetch(`${base}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password: tempPassword }),
  });
  let cookie = extractCookie(loginRes.headers.getSetCookie(), 'ot_session');

  await t.test('blocks broker routes until forced password change is complete', async () => {
    const res = await fetch(`${base}/broker/kotak-config`, { headers: { Cookie: cookie } });
    const body = await res.json();
    assert.equal(res.status, 403);
    assert.equal(body.error, 'PASSWORD_CHANGE_REQUIRED');
  });

  await t.test('completing password change unlocks broker routes', async () => {
    const res = await fetch(`${base}/auth/change-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ currentPassword: tempPassword, newPassword: 'a-new-strong-password-123' }),
    });
    assert.equal(res.status, 200);
    cookie = extractCookie(res.headers.getSetCookie(), 'ot_session');
    assert.ok(cookie);
  });

  await t.test('GET kotak-config reports not configured initially', async () => {
    const res = await fetch(`${base}/broker/kotak-config`, { headers: { Cookie: cookie } });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.configured, false);
  });

  await t.test('PUT kotak-config rejects missing required fields', async () => {
    const res = await fetch(`${base}/broker/kotak-config`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ consumerKey: 'partial-only' }),
    });
    const body = await res.json();
    assert.equal(res.status, 400);
    assert.equal(body.error, 'MISSING_FIELDS');
    assert.ok(body.missing.includes('mpin'));
    assert.ok(body.missing.includes('totpSecret'));
  });

  const sampleCreds = {
    consumerKey: 'sample-consumer-key-token',
    ucc: 'AB123',
    mobileNumber: '+919876543210',
    mpin: '123456',
    totpSecret: 'JBSWY3DPEHPK3PXP', // example-format seed, not a real credential
  };

  await t.test('PUT kotak-config stores credentials and response contains no raw secret', async () => {
    const res = await fetch(`${base}/broker/kotak-config`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify(sampleCreds),
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.configured, true);

    const raw = JSON.stringify(body);
    assert.ok(!raw.includes(sampleCreds.mpin), 'response must not leak mpin');
    assert.ok(!raw.includes(sampleCreds.totpSecret), 'response must not leak totpSecret');
    assert.ok(!raw.includes(sampleCreds.consumerKey), 'response must not leak full consumerKey');
    assert.notEqual(body.maskedFields.mpin, sampleCreds.mpin);
  });

  await t.test('stored value round-trips correctly through encryption (server-side only check)', () => {
    const raw = getRawCredentials(db, 1); // single admin, always user id 1 on a fresh DB
    assert.deepEqual(raw.fields, sampleCreds);
  });

  await t.test('DELETE kotak-config removes stored credentials', async () => {
    const res = await fetch(`${base}/broker/kotak-config`, {
      method: 'DELETE',
      headers: { Cookie: cookie },
    });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.configured, false);

    const check = await fetch(`${base}/broker/kotak-config`, { headers: { Cookie: cookie } });
    const checkBody = await check.json();
    assert.equal(checkBody.configured, false);
  });

  server.close();
  resetDatabaseFile();
});
