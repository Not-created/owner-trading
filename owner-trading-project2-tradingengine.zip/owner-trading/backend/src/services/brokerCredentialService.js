// Kotak credential storage: encrypt on write, mask on every read that a
// route can reach. Route handlers must only ever call getMaskedStatus() —
// getRawCredentials() exists for a future server-side Kotak adapter
// (the verification checkpoint), never for an HTTP response.

const { encryptJson, decryptJson } = require('./encryption');

// See migrations/003_add_broker_credentials.sql for why these exact field
// names were chosen (sourced from the current official Kotak SDK sample).
const REQUIRED_FIELDS = ['consumerKey', 'ucc', 'mobileNumber', 'mpin', 'totpSecret'];
const ALLOWED_ENVIRONMENTS = ['prod', 'uat'];

function maskValue(value) {
  const str = value === undefined || value === null ? '' : String(value);
  if (str.length === 0) return '';
  if (str.length <= 4) return '*'.repeat(str.length);
  return `${str.slice(0, 2)}${'*'.repeat(str.length - 4)}${str.slice(-2)}`;
}

// Returns an array of missing required field names (empty array = valid).
function validateFields(fields) {
  return REQUIRED_FIELDS.filter((name) => !fields || !fields[name]);
}

function isValidEnvironment(env) {
  return !env || ALLOWED_ENVIRONMENTS.includes(env);
}

function upsertCredentials(db, userId, fields, environment) {
  const { encryptedPayload, iv, authTag } = encryptJson(fields);

  db.prepare(
    `INSERT INTO broker_kotak_credentials (user_id, environment, encrypted_payload, iv, auth_tag, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'))
     ON CONFLICT(user_id) DO UPDATE SET
       environment = excluded.environment,
       encrypted_payload = excluded.encrypted_payload,
       iv = excluded.iv,
       auth_tag = excluded.auth_tag,
       updated_at = datetime('now')`
  ).run(userId, environment || 'prod', encryptedPayload, iv, authTag);
}

// Decrypts and returns { environment, updatedAt, fields } with PLAINTEXT
// secrets, or null if nothing is stored. Not for route use — see header.
function getRawCredentials(db, userId) {
  const row = db
    .prepare('SELECT * FROM broker_kotak_credentials WHERE user_id = ?')
    .get(userId);
  if (!row) return null;

  const fields = decryptJson({
    encryptedPayload: row.encrypted_payload,
    iv: row.iv,
    authTag: row.auth_tag,
  });

  return { environment: row.environment, updatedAt: row.updated_at, fields };
}

// The only read path routes should use: never returns a raw secret value.
function getMaskedStatus(db, userId) {
  const raw = getRawCredentials(db, userId);
  if (!raw) return { configured: false };

  const maskedFields = {};
  for (const key of Object.keys(raw.fields)) {
    maskedFields[key] = maskValue(raw.fields[key]);
  }

  return {
    configured: true,
    environment: raw.environment,
    updatedAt: raw.updatedAt,
    maskedFields,
  };
}

function deleteCredentials(db, userId) {
  db.prepare('DELETE FROM broker_kotak_credentials WHERE user_id = ?').run(userId);
}

module.exports = {
  REQUIRED_FIELDS,
  validateFields,
  isValidEnvironment,
  upsertCredentials,
  getRawCredentials,
  getMaskedStatus,
  deleteCredentials,
};
