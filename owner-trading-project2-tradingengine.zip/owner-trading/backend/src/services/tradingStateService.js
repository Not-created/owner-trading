// Global trading-state safety gates.
//
// Three independent controls, deliberately not collapsed into one flag:
//   trading_mode   — which mode strategies currently target (PAPER/LIVE)
//   live_enabled   — explicit "yes, really place live orders" switch.
//                    Setting trading_mode=LIVE alone does NOT flip this.
//   emergency_stop — global kill switch, overrides both of the above.
//
// isLiveOrderAllowed() is the single choke point any future order-placement
// code must call before submitting a real order. No order system exists
// yet — this is provided now specifically so that future code has no
// excuse to reimplement (and possibly get wrong) this check.

function getState(db) {
  return db.prepare('SELECT * FROM trading_state WHERE id = 1').get();
}

function toApiShape(row) {
  return {
    tradingMode: row.trading_mode,
    liveEnabled: !!row.live_enabled,
    emergencyStop: !!row.emergency_stop,
    liveEnabledAt: row.live_enabled_at,
    emergencyStopAt: row.emergency_stop_at,
    updatedAt: row.updated_at,
  };
}

function setMode(db, mode) {
  if (mode !== 'PAPER' && mode !== 'LIVE') {
    throw Object.assign(new Error('Invalid trading mode'), { code: 'INVALID_MODE' });
  }
  db.prepare("UPDATE trading_state SET trading_mode = ?, updated_at = datetime('now') WHERE id = 1").run(
    mode
  );
  return getState(db);
}

// Explicit, confirmed action required to actually allow live orders.
// Refuses unless mode is already LIVE and no emergency stop is active.
function enableLive(db, userId) {
  const state = getState(db);

  if (state.trading_mode !== 'LIVE') {
    throw Object.assign(new Error('Trading mode must be LIVE first'), { code: 'MODE_NOT_LIVE' });
  }
  if (state.emergency_stop) {
    throw Object.assign(new Error('Emergency stop is active'), { code: 'EMERGENCY_STOP_ACTIVE' });
  }

  db.prepare(
    `UPDATE trading_state
     SET live_enabled = 1, live_enabled_at = datetime('now'), live_enabled_by = ?, updated_at = datetime('now')
     WHERE id = 1`
  ).run(userId);

  return getState(db);
}

function disableLive(db) {
  db.prepare(
    "UPDATE trading_state SET live_enabled = 0, updated_at = datetime('now') WHERE id = 1"
  ).run();
  return getState(db);
}

function triggerEmergencyStop(db, userId) {
  db.prepare(
    `UPDATE trading_state
     SET emergency_stop = 1, emergency_stop_at = datetime('now'), emergency_stop_by = ?,
         live_enabled = 0, updated_at = datetime('now')
     WHERE id = 1`
  ).run(userId);
  return getState(db);
}

// Clearing the stop does NOT restore live_enabled — that must be a
// separate, explicit action. Fail-safe on the side of requiring a human.
function clearEmergencyStop(db) {
  db.prepare(
    "UPDATE trading_state SET emergency_stop = 0, updated_at = datetime('now') WHERE id = 1"
  ).run();
  return getState(db);
}

// Called once at process startup, before the server accepts requests.
// LIVE must never auto-enable after a restart — this forces it off
// regardless of whatever was last persisted, and reports whether it had
// to actually change anything (so the caller can log it loudly).
function forceLiveDisabledOnStartup(db) {
  const state = getState(db);
  if (state && state.live_enabled) {
    db.prepare(
      "UPDATE trading_state SET live_enabled = 0, updated_at = datetime('now') WHERE id = 1"
    ).run();
    return true;
  }
  return false;
}

// The single choke point for "is it OK to place a live order right now".
function isLiveOrderAllowed(db) {
  const state = getState(db);
  return state.trading_mode === 'LIVE' && !!state.live_enabled && !state.emergency_stop;
}

module.exports = {
  getState,
  toApiShape,
  setMode,
  enableLive,
  disableLive,
  triggerEmergencyStop,
  clearEmergencyStop,
  forceLiveDisabledOnStartup,
  isLiveOrderAllowed,
};
