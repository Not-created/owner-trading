// P&L summary. Realized P&L is already accumulated on the positions table
// by positionService as fills happen. Unrealized P&L is computed here,
// on demand, by marking each open position to the current reference
// price — for PAPER that's the market data simulator; a LIVE adapter's
// live quote would plug in here the same way (see marketDataSimulator.js
// header comment for why that swap doesn't touch anything else).

const marketDataSimulator = require('./marketDataSimulator');
const positionService = require('./positionService');

function referencePriceFor(symbol, mode) {
  if (mode === 'LIVE') {
    // No live quote source exists yet (see PROGRESS.md) — never fabricate
    // a live price. Unrealized P&L for LIVE positions is unavailable
    // until a real market-data adapter exists.
    return null;
  }
  return marketDataSimulator.getLastPrice(symbol);
}

function positionWithPnl(position) {
  const refPrice = referencePriceFor(position.symbol, position.mode);
  const unrealizedPnl =
    refPrice === null ? null : (refPrice - position.avg_price) * position.quantity;

  return {
    ...position,
    referencePrice: refPrice,
    unrealizedPnl,
  };
}

function summary(db, { mode = null, strategyId = null } = {}) {
  const positions = positionService.listPositions(db, { mode, strategyId }).map(positionWithPnl);

  const totals = positions.reduce(
    (acc, p) => {
      acc.realizedPnl += p.realized_pnl;
      if (p.unrealizedPnl !== null) acc.unrealizedPnl += p.unrealizedPnl;
      return acc;
    },
    { realizedPnl: 0, unrealizedPnl: 0 }
  );

  return {
    positions,
    totals: {
      realizedPnl: totals.realizedPnl,
      unrealizedPnl: totals.unrealizedPnl,
      totalPnl: totals.realizedPnl + totals.unrealizedPnl,
    },
  };
}

module.exports = { summary, positionWithPnl };
