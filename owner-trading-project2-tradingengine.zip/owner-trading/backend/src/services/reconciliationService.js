// Reconciliation — resolves orders whose true state isn't certain yet, by
// actually asking the broker adapter (never by assuming).
//
// KNOWN LIMITATION (documented): fill deltas are applied to positions
// using the order's aggregate avg_fill_price rather than a separate
// per-fill ledger. This is exact for the paper adapter (which only ever
// produces a single all-at-once fill) but would need a dedicated `fills`
// table for fully correct incremental accounting against a real broker
// that reports true partial fills across multiple updates. Not built —
// see PROGRESS.md.

const executionLogService = require('./executionLogService');
const positionService = require('./positionService');
const marketDataSimulator = require('./marketDataSimulator');
const { getAdapter, paperAdapter } = require('../brokers');

const NEEDS_RECONCILIATION_STATES = [
  'SUBMITTED',
  'OPEN',
  'PARTIALLY_FILLED',
  'UNKNOWN',
  'RECONCILIATION_REQUIRED',
];

function applyFillDelta(db, order, newFilledQuantity, avgFillPrice) {
  const delta = newFilledQuantity - order.filled_quantity;
  if (delta > 0 && avgFillPrice !== null && avgFillPrice !== undefined) {
    positionService.applyFill(db, {
      strategyId: order.strategy_id,
      symbol: order.symbol,
      mode: order.mode,
      side: order.side,
      quantity: delta,
      price: avgFillPrice,
    });
  }
}

async function reconcileOrder(db, order) {
  if (!NEEDS_RECONCILIATION_STATES.includes(order.state)) {
    return order; // already terminal, nothing to reconcile
  }

  // Paper-specific: give a pending OPEN limit order a chance to fill
  // against the latest simulated price. Real brokers don't need this —
  // they already know their own order's state; this is purely a paper
  // simulator affordance for testing the OPEN -> FILLED transition.
  if (order.mode === 'PAPER' && order.state === 'OPEN' && order.broker_order_id) {
    const latestPrice = marketDataSimulator.getLastPrice(order.symbol);
    paperAdapter.tryFillPending(order.broker_order_id, latestPrice);
  }

  const adapter = getAdapter(order.mode);

  try {
    const status = await adapter.getOrderStatus(order.broker_order_id);
    applyFillDelta(db, order, status.filledQuantity, status.avgFillPrice);

    db.prepare(
      `UPDATE orders SET state = ?, filled_quantity = ?, avg_fill_price = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(status.state, status.filledQuantity, status.avgFillPrice, order.id);

    if (status.state !== order.state) {
      executionLogService.info(
        db,
        order.strategy_id,
        `Order #${order.id} reconciled: ${order.state} -> ${status.state}`
      );
    }
  } catch (err) {
    // Could not determine the real state — mark it for a human/retry
    // pass rather than guessing. Never downgrade an already-terminal
    // state (checked above) and never invent FILLED/REJECTED here.
    db.prepare(
      `UPDATE orders SET state = 'RECONCILIATION_REQUIRED', reject_reason = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(err.message, order.id);
    executionLogService.error(
      db,
      order.strategy_id,
      `Order #${order.id} reconciliation failed: ${err.message} — marked RECONCILIATION_REQUIRED`
    );
  }

  return db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);
}

async function reconcileAll(db) {
  const pending = db
    .prepare(`SELECT * FROM orders WHERE state IN (${NEEDS_RECONCILIATION_STATES.map(() => '?').join(',')})`)
    .all(...NEEDS_RECONCILIATION_STATES);

  const results = [];
  for (const order of pending) {
    // Sequential on purpose: this touches shared position rows per
    // symbol/strategy, and better-sqlite3 is synchronous/single-connection
    // anyway — no benefit to parallelizing and it avoids any interleaving
    // risk on the positions table.
    // eslint-disable-next-line no-await-in-loop
    results.push(await reconcileOrder(db, order));
  }
  return results;
}

module.exports = { reconcileOrder, reconcileAll, NEEDS_RECONCILIATION_STATES };
