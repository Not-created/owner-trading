// Broker adapter interface.
//
// The trading engine (orderService.js) only ever talks to whatever object
// implements THIS shape — it never knows or cares whether that's the
// paper simulator or a real broker. This is what "broker-independent
// trading engine" means in practice: swapping brokers means writing a new
// file that implements these five methods, and nothing else in the
// codebase changes.
//
// Every method is async and must resolve/reject — never throw
// synchronously — so orderService can uniformly await + try/catch every
// call regardless of adapter.
//
// Contract:
//
//   name: string — for logging ("paper", "kotak-neo", ...)
//
//   async placeOrder({ clientOrderId, symbol, side, quantity, orderType,
//                       limitPrice, referencePrice })
//     -> { brokerOrderId, state, filledQuantity, avgFillPrice }
//     `state` must be one of the order states in migration 005.
//     MUST NOT fabricate a success state if the outcome is genuinely
//     unknown (e.g. a network timeout after sending the request) — return
//     state: 'UNKNOWN' in that case, never guess FILLED or REJECTED.
//
//   async getOrderStatus(brokerOrderId)
//     -> { state, filledQuantity, avgFillPrice }
//     Used by reconciliation to resolve UNKNOWN/RECONCILIATION_REQUIRED
//     orders against the broker's own record — never guess, always ask.
//
//   async cancelOrder(brokerOrderId) -> { state }
//
//   async getPositions() -> [{ symbol, quantity, avgPrice }]
//     Broker's own view of positions, for reconciliation against this
//     app's locally computed positions table.

class BrokerAdapter {
  // eslint-disable-next-line class-methods-use-this
  get name() {
    throw new Error('BrokerAdapter subclasses must implement get name()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async placeOrder(_orderIntent) {
    throw new Error('BrokerAdapter subclasses must implement placeOrder()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async getOrderStatus(_brokerOrderId) {
    throw new Error('BrokerAdapter subclasses must implement getOrderStatus()');
  }

  // eslint-disable-next-line no-unused-vars, class-methods-use-this
  async cancelOrder(_brokerOrderId) {
    throw new Error('BrokerAdapter subclasses must implement cancelOrder()');
  }

  // eslint-disable-next-line class-methods-use-this
  async getPositions() {
    throw new Error('BrokerAdapter subclasses must implement getPositions()');
  }
}

module.exports = { BrokerAdapter };
