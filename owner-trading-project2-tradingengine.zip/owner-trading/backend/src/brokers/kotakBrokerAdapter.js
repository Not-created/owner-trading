// Kotak Neo broker adapter — INTENTIONALLY NOT IMPLEMENTED.
//
// This file exists to satisfy "keep broker integration behind a clean
// adapter/interface" — it conforms to the same BrokerAdapter contract as
// the paper adapter — but every method throws NOT_IMPLEMENTED. This is a
// deliberate, honest choice, not an oversight. Here's exactly why:
//
// What IS verified (via the officially-referenced Python SDK's own PyPI
// page, as of the session that wrote this file):
//   - Auth is two-step: totp_login(mobile_number, ucc, totp) then
//     totp_validate(mpin) — matches the fields already stored by
//     brokerCredentialService.js (consumerKey, ucc, mobileNumber, mpin,
//     a TOTP *seed* rather than a live 6-digit code).
//   - place_order() takes: exchange_segment, product, price, order_type,
//     quantity, validity, trading_symbol, transaction_type.
//   - quotes() takes: instrument_tokens, quote_type.
//
// What is NOT verified, and must not be guessed:
//   - The actual raw REST endpoint paths, request/response JSON envelope,
//     auth header format, and error-code semantics. Kotak publishes a
//     separate REST API reference alongside the Python SDK, and the SDK's
//     own release notes confirm endpoints were restructured in the v2
//     migration — meaning any endpoint path found outside that primary
//     reference (e.g. older blog posts) cannot be trusted as current.
//   - There is no officially-maintained Node.js SDK; a real Node
//     integration means either (a) calling the verified REST endpoints
//     directly once genuinely confirmed from Kotak's own current
//     reference docs, or (b) shelling out to the official Python SDK
//     (kotakneoapi) from Node as a subprocess, which needs Python +
//     `pip install kotakneoapi` on the deployment target.
//   - Rate limits, order-rejection error shapes, partial-fill reporting
//     format, and reconciliation/order-history endpoint behavior.
//   - None of the above could be confirmed or tested in the sandbox that
//     built this file: no network access to fetch Kotak's authoritative
//     REST reference, and correctly no real account/credentials to test
//     an actual round trip against.
//
// DO NOT fill in these methods by guessing. Fill them in only after:
//   1. Reading Kotak's own current REST API reference (not a mirror/blog)
//      or installing the official kotakneoapi Python package and wrapping
//      it, and
//   2. Testing a real authenticate() + a real UAT/sandbox order round trip
//      (if Kotak's environment="uat" mode supports order placement) with
//      real credentials, entered only through this app's Settings UI —
//      never in chat.
//
// Until then, isLiveOrderAllowed() staying false (see
// tradingStateService.js) is necessary but NOT sufficient on its own —
// this file is the actual last line of defense: even if every safety gate
// were somehow bypassed, LIVE orders still cannot succeed, because this
// throws instead of fabricating a broker response.

const { BrokerAdapter } = require('./brokerAdapter');

class NotImplementedError extends Error {
  constructor(method) {
    super(
      `Kotak Neo adapter: ${method}() is not implemented. This is an ` +
        'intentional stub — see the header comment in kotakBrokerAdapter.js ' +
        'for exactly what remains unverified before this can be filled in.'
    );
    this.code = 'NOT_IMPLEMENTED';
  }
}

class KotakBrokerAdapter extends BrokerAdapter {
  // eslint-disable-next-line class-methods-use-this
  get name() {
    return 'kotak-neo';
  }

  // eslint-disable-next-line class-methods-use-this
  async placeOrder() {
    throw new NotImplementedError('placeOrder');
  }

  // eslint-disable-next-line class-methods-use-this
  async getOrderStatus() {
    throw new NotImplementedError('getOrderStatus');
  }

  // eslint-disable-next-line class-methods-use-this
  async cancelOrder() {
    throw new NotImplementedError('cancelOrder');
  }

  // eslint-disable-next-line class-methods-use-this
  async getPositions() {
    throw new NotImplementedError('getPositions');
  }
}

module.exports = { KotakBrokerAdapter, NotImplementedError };
