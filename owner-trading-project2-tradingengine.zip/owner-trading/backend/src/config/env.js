// Centralized environment/config loader.
// Every other module should read config from here instead of process.env
// directly, so there is one place that knows what variables exist and
// what their safe defaults are.

const path = require('node:path');
require('dotenv').config();

function requireInProduction(name, value) {
  if (process.env.NODE_ENV === 'production' && !value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 4000,
  frontendOrigin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  databasePath: path.resolve(
    __dirname,
    '..',
    '..',
    process.env.DATABASE_PATH || './data/owner_trading.db'
  ),
  // NOTE: not currently read by any route — server.js/sessionService.js
  // implement sessions via a hashed random token, not this secret. Kept
  // for forward compatibility (e.g. CSRF or signed-cookie use) and fixed
  // here so it actually fails fast in production instead of silently
  // falling back to a guessable value.
  sessionSecret:
    process.env.NODE_ENV === 'production'
      ? requireInProduction('SESSION_SECRET', process.env.SESSION_SECRET)
      : process.env.SESSION_SECRET || 'dev_only_insecure_secret_change_me',
  // Used by src/services/encryption.js to encrypt Kotak credentials at
  // rest. Must be a 64-char hex string (32 bytes) — see .env.example for
  // how to generate one. Intentionally has NO insecure default: routes
  // that need it will fail loudly (see encryption.js) rather than silently
  // encrypting secrets with a guessable key.
  credentialEncryptionKey: requireInProduction(
    'CREDENTIAL_ENCRYPTION_KEY',
    process.env.CREDENTIAL_ENCRYPTION_KEY || ''
  ),
  kotakIntegrationEnabled: process.env.KOTAK_INTEGRATION_ENABLED === 'true',
};

module.exports = config;
