const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const marketDataSimulator = require('../services/marketDataSimulator');

const router = express.Router();
router.use(requireAuth, requirePasswordChangeComplete);

// GET /api/market-data — current simulated price + short history for
// every distinct symbol currently configured on any strategy. This is a
// SIMULATOR (see marketDataSimulator.js header) — there is no real market
// data feed in this project.
router.get('/', (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT DISTINCT symbol FROM strategies').all();

  const data = rows.map(({ symbol }) => ({
    symbol,
    price: marketDataSimulator.getLastPrice(symbol),
    history: marketDataSimulator.getHistory(symbol),
  }));

  res.json({ simulated: true, symbols: data });
});

module.exports = router;
