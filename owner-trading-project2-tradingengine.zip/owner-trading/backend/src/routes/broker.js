const express = require('express');
const { getDb } = require('../db/connection');
const { requireAuth, requirePasswordChangeComplete } = require('../middleware/auth');
const {
  validateFields,
  isValidEnvironment,
  upsertCredentials,
  getMaskedStatus,
  deleteCredentials,
} = require('../services/brokerCredentialService');

const router = express.Router();

// Every route here requires a completed forced password change — this is
// the first feature checkpoint where that gate actually protects something.
router.use(requireAuth, requirePasswordChangeComplete);

// GET /api/broker/kotak-config — masked status only. Never returns a raw
// secret value under any circumstance.
router.get('/kotak-config', (req, res) => {
  const db = getDb();
  res.json(getMaskedStatus(db, req.user.userId));
});

// PUT /api/broker/kotak-config — store/replace credentials for this user.
// This ONLY persists credentials; it does not attempt to contact Kotak or
// validate them against a live endpoint (that belongs to the separate
// Kotak API verification checkpoint).
router.put('/kotak-config', (req, res) => {
  const { consumerKey, ucc, mobileNumber, mpin, totpSecret, environment } = req.body || {};
  const fields = { consumerKey, ucc, mobileNumber, mpin, totpSecret };

  const missing = validateFields(fields);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'MISSING_FIELDS', missing });
  }
  if (!isValidEnvironment(environment)) {
    return res.status(400).json({ error: 'INVALID_ENVIRONMENT' });
  }

  const db = getDb();
  upsertCredentials(db, req.user.userId, fields, environment);
  res.json({ success: true, ...getMaskedStatus(db, req.user.userId) });
});

// DELETE /api/broker/kotak-config — disconnect / remove stored credentials.
router.delete('/kotak-config', (req, res) => {
  const db = getDb();
  deleteCredentials(db, req.user.userId);
  res.json({ success: true, configured: false });
});

module.exports = router;
