# Deploying Owner Trading to a VPS

This covers a fresh Ubuntu/Debian-style VPS. Adjust package-manager
commands if you're on a different distro — everything after Node.js is
installed is distro-agnostic.

## 0. What you need before starting

- A VPS with SSH access and a non-root sudo user
- A domain name pointed at the VPS's IP (for HTTPS; skip if testing on the
  bare IP over HTTP only)
- Node.js 18+ (installation covered below)

## 1. Install Node.js (if not already present)

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # confirm v18 or later
```

## 2. Get the code onto the VPS

Either clone your GitHub repo (once you've pushed the checkpointed code
there from your own machine — this project was built without network
access to GitHub, see PROGRESS.md) or upload/unzip the project archive:

```bash
git clone <your-repo-url> owner-trading
cd owner-trading
# or: unzip owner-trading-*.zip && cd owner-trading
```

## 3. Install dependencies and build the frontend

```bash
chmod +x deploy/deploy.sh
./deploy/deploy.sh install
./deploy/deploy.sh setup-env
```

`setup-env` creates `backend/.env` and `frontend/.env` from their
`.env.example` files **if they don't already exist** — it never overwrites
a real one. It will NOT fill in real secret values; you must edit them:

```bash
nano backend/.env
```

Set at minimum:
- `SESSION_SECRET` and `CREDENTIAL_ENCRYPTION_KEY` — generate each with:
  ```bash
  node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
  ```
- `FRONTEND_ORIGIN` — your real site URL, e.g. `https://yourdomain.com`
- `NODE_ENV=production`

And `frontend/.env`:
- `VITE_API_BASE_URL` — e.g. `https://yourdomain.com/api`

Then build the frontend (must be re-run any time `frontend/.env` changes,
since Vite bakes `VITE_*` values in at build time):

```bash
./deploy/deploy.sh build
```

## 4. Run the backend as a systemd service (recommended)

```bash
sudo ./deploy/deploy.sh setup-systemd
sudo systemctl start owner-trading
./deploy/deploy.sh status
```

This installs `deploy/owner-trading.service.template` to
`/etc/systemd/system/owner-trading.service` with your actual project path
and user filled in, enables it to start on boot, and runs it with some
basic systemd hardening (`NoNewPrivileges`, `ProtectSystem=full`, etc. —
see the template file for exactly what's applied).

If your VPS has no systemd, `./deploy/deploy.sh start` falls back to a
plain background `node` process with a PID file (`start`/`stop`/`status`/
`logs` all work the same way either way).

On first run, the server prints the auto-generated admin username and
password location to the log — check:

```bash
./deploy/deploy.sh logs
cat backend/INITIAL_ADMIN_CREDENTIALS.txt
```

Log in, complete the forced password change immediately, then:

```bash
rm backend/INITIAL_ADMIN_CREDENTIALS.txt
```

## 5. Reverse proxy with Nginx + HTTPS

```bash
sudo apt-get install -y nginx certbot python3-certbot-nginx
DOMAIN=yourdomain.com sudo -E ./deploy/deploy.sh setup-nginx
sudo certbot --nginx -d yourdomain.com
```

`setup-nginx` installs `deploy/nginx.conf.template` to
`/etc/nginx/sites-available/owner-trading` with your domain, project path,
and backend port filled in, serving the built frontend as static files and
proxying `/api/` to the Express backend. `certbot --nginx` then obtains a
real certificate and automatically adds the HTTPS server block + HTTP→HTTPS
redirect.

**After enabling HTTPS**, update `backend/.env`:
```
FRONTEND_ORIGIN=https://yourdomain.com
NODE_ENV=production
```
`NODE_ENV=production` makes the session cookie `Secure` (HTTPS-only) — see
`backend/src/routes/auth.js`. Restart after changing this:
```bash
./deploy/deploy.sh restart
```

## 6. Day-to-day operations

```bash
./deploy/deploy.sh status     # is it running?
./deploy/deploy.sh logs       # tail logs (journalctl if systemd, else a log file)
./deploy/deploy.sh restart    # restart the backend
./deploy/deploy.sh update     # git pull (if a git checkout) + reinstall + rebuild + restart
```

## 7. Security checklist before going live

- [ ] `backend/.env` has real, unique `SESSION_SECRET` and
      `CREDENTIAL_ENCRYPTION_KEY` values (not the placeholders)
- [ ] `INITIAL_ADMIN_CREDENTIALS.txt` deleted after first login
- [ ] `NODE_ENV=production` set
- [ ] HTTPS is active (`FRONTEND_ORIGIN` uses `https://`)
- [ ] `backend/.env`, `backend/data/*.db*`, and logs are NOT inside your web
      server's document root (they aren't, by default, in this layout —
      only `frontend/dist` is served as static files)
- [ ] Firewall allows only 80/443 (and SSH) from the public internet;
      the backend's own port (default 4000) should NOT be publicly exposed
      — only Nginx should reach it, over `127.0.0.1`
- [ ] Regular filesystem backups of `backend/data/owner_trading.db`
      (stop the service or use SQLite's backup API for a consistent copy —
      don't just `cp` a live WAL-mode database file)

## 8. What this deployment does NOT yet cover

Kotak Neo LIVE trading requires a separately verified integration step
before it is safe to use — see `PROGRESS.md` for exactly what has and has
not been verified. Deploying this project does not by itself make LIVE
trading safe or functional; the trading-mode/emergency-stop safety gates
exist specifically so LIVE stays blocked until that verification is done.
