#!/usr/bin/env bash
#
# Owner Trading — production deployment script for a fresh (or existing) VPS.
#
# Usage: ./deploy.sh <command>
#   install        Check prerequisites, install backend+frontend dependencies
#   build          Build the frontend for production (frontend/dist)
#   setup-env      Create backend/.env from .env.example if missing (does NOT
#                  fill in real values — you must edit it yourself)
#   setup-systemd  Install a systemd service for the backend (requires sudo)
#   setup-nginx    Install an Nginx reverse-proxy config (requires sudo)
#   start          Start the backend (systemd if installed, else a plain
#                  background process with a PID file)
#   stop           Stop the backend
#   restart        Restart the backend
#   status         Show whether the backend is running
#   logs           Tail backend logs
#   update         git pull (if this is a git checkout) + install + build + restart
#   all            install + setup-env + build + setup-systemd + start
#                  (does NOT run setup-nginx — that needs your domain name)
#
# Design notes:
# - No secrets are hardcoded anywhere in this script. All real configuration
#   lives in backend/.env, which YOU create/edit — this script never writes
#   credential values into it.
# - Idempotent: re-running install/build/setup-* is safe and will not
#   destroy an existing .env, database, or logs.
# - Fails loudly and stops (`set -euo pipefail`) rather than continuing
#   past a broken step.

set -euo pipefail

# --- Locate the project root (parent of this script's directory) ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"

SERVICE_NAME="owner-trading"
PID_FILE="$BACKEND_DIR/data/backend.pid"
FALLBACK_LOG="$BACKEND_DIR/logs/backend.out.log"

log()  { echo "[deploy] $*"; }
err()  { echo "[deploy][ERROR] $*" >&2; }
die()  { err "$*"; exit 1; }

# --- Prerequisite checks -----------------------------------------------
check_prereqs() {
  command -v node >/dev/null 2>&1 || die "Node.js is not installed. Install Node.js 18+ first."
  command -v npm  >/dev/null 2>&1 || die "npm is not installed."

  local node_major
  node_major="$(node -e 'console.log(process.versions.node.split(".")[0])')"
  if [ "$node_major" -lt 18 ]; then
    die "Node.js 18+ is required (found v$(node -v)). Upgrade Node.js and re-run."
  fi

  log "Prerequisites OK: node $(node -v), npm $(npm -v)"
}

# --- install: dependencies for backend + frontend ------------------------
cmd_install() {
  check_prereqs

  log "Installing backend dependencies..."
  (cd "$BACKEND_DIR" && npm install --omit=dev)

  log "Installing frontend dependencies..."
  (cd "$FRONTEND_DIR" && npm install)

  mkdir -p "$BACKEND_DIR/data" "$BACKEND_DIR/logs"
  log "install complete."
}

# --- build: production frontend build ------------------------------------
cmd_build() {
  check_prereqs
  log "Building frontend for production..."
  (cd "$FRONTEND_DIR" && npm run build)
  [ -d "$FRONTEND_DIR/dist" ] || die "Build finished but frontend/dist was not created — check the build output above."
  log "build complete: $FRONTEND_DIR/dist"
}

# --- setup-env: create backend/.env if missing (idempotent) --------------
cmd_setup_env() {
  if [ -f "$BACKEND_DIR/.env" ]; then
    log "backend/.env already exists — leaving it untouched."
  else
    cp "$BACKEND_DIR/.env.example" "$BACKEND_DIR/.env"
    log "Created backend/.env from .env.example."
    err "ACTION REQUIRED: edit $BACKEND_DIR/.env and set real values before starting:"
    err "  - SESSION_SECRET / CREDENTIAL_ENCRYPTION_KEY: generate with"
    err "      node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\""
    err "  - FRONTEND_ORIGIN: your real site URL (e.g. https://yourdomain.com)"
  fi

  if [ -f "$FRONTEND_DIR/.env" ]; then
    log "frontend/.env already exists — leaving it untouched."
  else
    cp "$FRONTEND_DIR/.env.example" "$FRONTEND_DIR/.env"
    log "Created frontend/.env from .env.example — set VITE_API_BASE_URL to your real API URL, then re-run 'build'."
  fi
}

# --- setup-systemd: install the unit file (requires sudo) ----------------
cmd_setup_systemd() {
  command -v systemctl >/dev/null 2>&1 || die "systemctl not found — this VPS does not appear to use systemd."
  [ "$(id -u)" -eq 0 ] || die "setup-systemd must be run with sudo/root (it writes to /etc/systemd/system)."

  local service_user="${SUDO_USER:-$(whoami)}"
  local unit_path="/etc/systemd/system/${SERVICE_NAME}.service"

  sed \
    -e "s#__PROJECT_ROOT__#${PROJECT_ROOT}#g" \
    -e "s#__SERVICE_USER__#${service_user}#g" \
    "$SCRIPT_DIR/owner-trading.service.template" > "$unit_path"

  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME"
  log "systemd service installed and enabled as '${SERVICE_NAME}' (runs as user: ${service_user})."
  log "Start it with: sudo systemctl start ${SERVICE_NAME}   (or: ./deploy.sh start)"
}

# --- setup-nginx: install reverse-proxy config (requires sudo) -----------
cmd_setup_nginx() {
  command -v nginx >/dev/null 2>&1 || die "nginx is not installed."
  [ "$(id -u)" -eq 0 ] || die "setup-nginx must be run with sudo/root."
  [ -n "${DOMAIN:-}" ] || die "Set DOMAIN first, e.g.: DOMAIN=yourdomain.com sudo -E ./deploy.sh setup-nginx"

  local backend_port="${PORT:-4000}"
  local conf_path="/etc/nginx/sites-available/${SERVICE_NAME}"

  sed \
    -e "s#__DOMAIN__#${DOMAIN}#g" \
    -e "s#__PROJECT_ROOT__#${PROJECT_ROOT}#g" \
    -e "s#__BACKEND_PORT__#${backend_port}#g" \
    "$SCRIPT_DIR/nginx.conf.template" > "$conf_path"

  ln -sf "$conf_path" "/etc/nginx/sites-enabled/${SERVICE_NAME}"
  nginx -t
  systemctl reload nginx
  log "Nginx config installed for ${DOMAIN}. Next: obtain HTTPS with certbot (see DEPLOYMENT.md)."
}

# --- start / stop / restart / status / logs -------------------------------
using_systemd() {
  command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q "^${SERVICE_NAME}.service"
}

cmd_start() {
  if using_systemd; then
    sudo systemctl start "$SERVICE_NAME"
    log "Started via systemd. Check: ./deploy.sh status"
    return
  fi

  [ -f "$BACKEND_DIR/.env" ] || die "backend/.env not found. Run: ./deploy.sh setup-env"
  if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "Already running (pid $(cat "$PID_FILE"))."
    return
  fi

  mkdir -p "$BACKEND_DIR/logs"
  (cd "$BACKEND_DIR" && NODE_ENV=production nohup node server.js >> "$FALLBACK_LOG" 2>&1 &
   echo $! > "$PID_FILE")
  sleep 1
  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "Started (pid $(cat "$PID_FILE")). Logs: $FALLBACK_LOG"
  else
    die "Backend failed to start — check $FALLBACK_LOG"
  fi
}

cmd_stop() {
  if using_systemd; then
    sudo systemctl stop "$SERVICE_NAME"
    log "Stopped via systemd."
    return
  fi

  if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    kill "$(cat "$PID_FILE")"
    rm -f "$PID_FILE"
    log "Stopped."
  else
    log "Not running (no active PID file)."
  fi
}

cmd_restart() {
  if using_systemd; then
    sudo systemctl restart "$SERVICE_NAME"
    log "Restarted via systemd."
    return
  fi
  cmd_stop || true
  cmd_start
}

cmd_status() {
  if using_systemd; then
    systemctl status "$SERVICE_NAME" --no-pager || true
    return
  fi

  if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "Running (pid $(cat "$PID_FILE"))."
  else
    log "Not running."
  fi
}

cmd_logs() {
  if using_systemd; then
    journalctl -u "$SERVICE_NAME" -f
    return
  fi
  [ -f "$FALLBACK_LOG" ] || die "No log file yet at $FALLBACK_LOG — has the backend been started?"
  tail -f "$FALLBACK_LOG"
}

# --- update: pull latest code (if a git checkout) + reinstall + rebuild --
cmd_update() {
  if [ -d "$PROJECT_ROOT/.git" ]; then
    log "Git checkout detected — pulling latest..."
    (cd "$PROJECT_ROOT" && git pull --ff-only)
  else
    log "Not a git checkout — skipping git pull. Replace files manually before running update."
  fi

  cmd_install
  cmd_build
  cmd_restart
  log "update complete."
}

cmd_all() {
  cmd_install
  cmd_setup_env
  cmd_build
  if command -v systemctl >/dev/null 2>&1; then
    log "systemd detected — run 'sudo ./deploy.sh setup-systemd' then './deploy.sh start' once backend/.env is filled in."
  else
    log "No systemd detected — after filling in backend/.env, run './deploy.sh start' for the fallback process runner."
  fi
}

# --- dispatch --------------------------------------------------------------
case "${1:-}" in
  install)        cmd_install ;;
  build)           cmd_build ;;
  setup-env)       cmd_setup_env ;;
  setup-systemd)   cmd_setup_systemd ;;
  setup-nginx)     cmd_setup_nginx ;;
  start)           cmd_start ;;
  stop)            cmd_stop ;;
  restart)         cmd_restart ;;
  status)          cmd_status ;;
  logs)            cmd_logs ;;
  update)          cmd_update ;;
  all)             cmd_all ;;
  *)
    echo "Usage: $0 {install|build|setup-env|setup-systemd|setup-nginx|start|stop|restart|status|logs|update|all}"
    exit 1
    ;;
esac
