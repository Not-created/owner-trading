// Central API client. Every backend call goes through request() so cookie
// handling, JSON parsing, and error shape stay consistent in one place —
// components should never call fetch() directly.

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000/api';

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    credentials: 'include', // send/receive the ot_session cookie
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const error = new Error((body && body.error) || `Request failed with status ${res.status}`);
    error.status = res.status;
    error.code = body && body.error;
    throw error;
  }

  return body;
}

export function getHealth() {
  return request('/health', { method: 'GET' });
}

export function login(username, password) {
  return request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
}

export function logout() {
  return request('/auth/logout', { method: 'POST' });
}

export function getMe() {
  return request('/auth/me', { method: 'GET' });
}

export function changePassword(currentPassword, newPassword) {
  return request('/auth/change-password', {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newPassword }),
  });
}

// --- Broker (Kotak) credential storage ---
// GET returns only masked previews — the backend never sends raw secrets.

export function getBrokerConfig() {
  return request('/broker/kotak-config', { method: 'GET' });
}

export function saveBrokerConfig(fields) {
  return request('/broker/kotak-config', {
    method: 'PUT',
    body: JSON.stringify(fields),
  });
}

export function deleteBrokerConfig() {
  return request('/broker/kotak-config', { method: 'DELETE' });
}

// --- Trading state (mode / live-enable / emergency stop) ---

export function getTradingState() {
  return request('/trading/state', { method: 'GET' });
}

export function setTradingMode(mode) {
  return request('/trading/mode', { method: 'PUT', body: JSON.stringify({ mode }) });
}

export function enableLiveTrading() {
  return request('/trading/live-enable', {
    method: 'POST',
    body: JSON.stringify({ confirm: true }),
  });
}

export function disableLiveTrading() {
  return request('/trading/live-disable', { method: 'POST' });
}

export function triggerEmergencyStop() {
  return request('/trading/emergency-stop', { method: 'POST' });
}

export function clearEmergencyStop() {
  return request('/trading/emergency-stop/clear', { method: 'POST' });
}

// --- Strategies ---

export function listStrategies() {
  return request('/strategies', { method: 'GET' });
}
export function getStrategy(id) {
  return request(`/strategies/${id}`, { method: 'GET' });
}
export function createStrategy(input) {
  return request('/strategies', { method: 'POST', body: JSON.stringify(input) });
}
export function updateStrategy(id, input) {
  return request(`/strategies/${id}`, { method: 'PUT', body: JSON.stringify(input) });
}
export function deleteStrategy(id) {
  return request(`/strategies/${id}`, { method: 'DELETE' });
}
export function startStrategy(id) {
  return request(`/strategies/${id}/start`, { method: 'POST' });
}
export function stopStrategy(id) {
  return request(`/strategies/${id}/stop`, { method: 'POST' });
}
export function runStrategyOnce(id) {
  return request(`/strategies/${id}/run-once`, { method: 'POST' });
}

// --- Orders ---

export function listOrders(strategyId) {
  const qs = strategyId ? `?strategyId=${strategyId}` : '';
  return request(`/orders${qs}`, { method: 'GET' });
}
export function cancelOrder(id) {
  return request(`/orders/${id}/cancel`, { method: 'POST' });
}
export function reconcileOrders() {
  return request('/orders/reconcile', { method: 'POST' });
}

// --- Positions & P&L ---

export function listPositions(mode) {
  const qs = mode ? `?mode=${mode}` : '';
  return request(`/positions${qs}`, { method: 'GET' });
}
export function getPnlSummary(mode) {
  const qs = mode ? `?mode=${mode}` : '';
  return request(`/positions/pnl${qs}`, { method: 'GET' });
}

// --- Risk limits ---

export function getRiskLimits() {
  return request('/risk', { method: 'GET' });
}
export function updateRiskLimits(limits) {
  return request('/risk', { method: 'PUT', body: JSON.stringify(limits) });
}

// --- Execution logs ---

export function listLogs(strategyId) {
  const qs = strategyId ? `?strategyId=${strategyId}` : '';
  return request(`/logs${qs}`, { method: 'GET' });
}

// --- Market data (simulator — see backend for details) ---

export function getMarketData() {
  return request('/market-data', { method: 'GET' });
}
