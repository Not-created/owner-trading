import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  getTradingState,
  setTradingMode,
  enableLiveTrading,
  disableLiveTrading,
  triggerEmergencyStop,
  clearEmergencyStop,
} from '../api/client.js';

export default function TradingControlPage() {
  const [state, setState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  function load() {
    setLoading(true);
    return getTradingState()
      .then(setState)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function runAction(action) {
    setError(null);
    setBusy(true);
    try {
      const result = await action();
      setState(result);
    } catch (err) {
      setError(err.code || err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleModeChange(nextMode) {
    if (nextMode === state.tradingMode) return;
    await runAction(() => setTradingMode(nextMode));
  }

  async function handleEnableLive() {
    const confirmed = window.confirm(
      'This will allow REAL orders to be placed once a strategy runs in LIVE mode. Continue?'
    );
    if (!confirmed) return;
    await runAction(() => enableLiveTrading());
  }

  if (loading) {
    return <p style={{ padding: '2rem', fontFamily: 'sans-serif' }}>Loading…</p>;
  }

  const liveOrdersAllowed = state.tradingMode === 'LIVE' && state.liveEnabled && !state.emergencyStop;

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 480 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Trading controls</h1>

      <div
        style={{
          background: liveOrdersAllowed ? '#fdecea' : '#f4f4f4',
          border: liveOrdersAllowed ? '1px solid #b00020' : '1px solid #ddd',
          padding: '1rem',
          borderRadius: 6,
          marginBottom: '1.5rem',
        }}
      >
        <p style={{ margin: 0 }}>
          <strong>Live orders: {liveOrdersAllowed ? 'ALLOWED' : 'BLOCKED'}</strong>
        </p>
        <p style={{ margin: '0.5rem 0 0', fontSize: '0.9em' }}>
          Mode: {state.tradingMode} · Live enabled: {String(state.liveEnabled)} · Emergency stop:{' '}
          {String(state.emergencyStop)}
        </p>
      </div>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}

      <section style={{ marginTop: '1.5rem' }}>
        <h2 style={{ fontSize: '1.1em' }}>Trading mode</h2>
        <button
          disabled={busy || state.tradingMode === 'PAPER'}
          onClick={() => handleModeChange('PAPER')}
        >
          Switch to PAPER
        </button>{' '}
        <button
          disabled={busy || state.tradingMode === 'LIVE'}
          onClick={() => handleModeChange('LIVE')}
        >
          Switch to LIVE
        </button>
        <p style={{ fontSize: '0.85em', color: '#555' }}>
          Switching to LIVE mode alone does not place real orders — Live trading must also be
          explicitly enabled below.
        </p>
      </section>

      <section style={{ marginTop: '1.5rem' }}>
        <h2 style={{ fontSize: '1.1em' }}>Live trading</h2>
        {state.liveEnabled ? (
          <button disabled={busy} onClick={() => runAction(disableLiveTrading)}>
            Disable live trading
          </button>
        ) : (
          <button
            disabled={busy || state.tradingMode !== 'LIVE' || state.emergencyStop}
            onClick={handleEnableLive}
          >
            Enable live trading
          </button>
        )}
        {state.tradingMode !== 'LIVE' && (
          <p style={{ fontSize: '0.85em', color: '#555' }}>Switch to LIVE mode first.</p>
        )}
      </section>

      <section style={{ marginTop: '1.5rem' }}>
        <h2 style={{ fontSize: '1.1em' }}>Emergency stop</h2>
        {state.emergencyStop ? (
          <>
            <p style={{ color: '#b00020' }}>Emergency stop is ACTIVE.</p>
            <button disabled={busy} onClick={() => runAction(clearEmergencyStop)}>
              Clear emergency stop
            </button>
            <p style={{ fontSize: '0.85em', color: '#555' }}>
              Clearing this does not re-enable live trading — that is a separate, explicit step.
            </p>
          </>
        ) : (
          <button
            disabled={busy}
            onClick={() => runAction(triggerEmergencyStop)}
            style={{ background: '#b00020', color: 'white', border: 'none', padding: '0.5rem 1rem' }}
          >
            Emergency stop
          </button>
        )}
      </section>
    </main>
  );
}
