import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listOrders, cancelOrder, reconcileOrders } from '../api/client.js';

const STATE_COLORS = {
  FILLED: '#0a7d28',
  REJECTED: '#b00020',
  FAILED: '#b00020',
  CANCELLED: '#777',
  UNKNOWN: '#b8860b',
  RECONCILIATION_REQUIRED: '#b8860b',
};

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reconciling, setReconciling] = useState(false);

  function load() {
    setLoading(true);
    return listOrders()
      .then(setOrders)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCancel(id) {
    setError(null);
    try {
      await cancelOrder(id);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleReconcile() {
    setError(null);
    setReconciling(true);
    try {
      await reconcileOrders();
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setReconciling(false);
    }
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 800 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>Orders</h1>
        <button onClick={handleReconcile} disabled={reconciling}>
          {reconciling ? 'Reconciling…' : 'Reconcile now'}
        </button>
      </div>

      {error && <p style={{ color: '#b00020' }}>{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && orders.length === 0 && <p>No orders yet.</p>}

      {!loading && orders.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9em' }}>
          <thead>
            <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
              <th>#</th>
              <th>Symbol</th>
              <th>Side</th>
              <th>Qty</th>
              <th>Type</th>
              <th>Mode</th>
              <th>State</th>
              <th>Fill price</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} style={{ borderBottom: '1px solid #eee' }}>
                <td>{o.id}</td>
                <td>{o.symbol}</td>
                <td>{o.side}</td>
                <td>
                  {o.filled_quantity}/{o.quantity}
                </td>
                <td>{o.order_type}</td>
                <td>{o.mode}</td>
                <td style={{ color: STATE_COLORS[o.state] || '#333', fontWeight: 'bold' }}>
                  {o.state}
                  {o.reject_reason && <div style={{ fontWeight: 'normal', fontSize: '0.85em' }}>{o.reject_reason}</div>}
                </td>
                <td>{o.avg_fill_price ?? '—'}</td>
                <td>
                  {['OPEN', 'PARTIALLY_FILLED', 'SUBMITTED'].includes(o.state) && (
                    <button onClick={() => handleCancel(o.id)}>Cancel</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
