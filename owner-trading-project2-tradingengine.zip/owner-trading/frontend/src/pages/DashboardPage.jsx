import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { getBrokerConfig, getTradingState, listStrategies } from '../api/client.js';

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const [broker, setBroker] = useState(null);
  const [trading, setTrading] = useState(null);
  const [strategies, setStrategies] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    Promise.all([getBrokerConfig(), getTradingState(), listStrategies()])
      .then(([brokerData, tradingData, strategyData]) => {
        if (cancelled) return;
        setBroker(brokerData);
        setTrading(tradingData);
        setStrategies(strategyData);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const runningCount = strategies.filter((s) => s.status === 'RUNNING').length;
  const errorCount = strategies.filter((s) => s.status === 'ERROR').length;
  const liveOrdersAllowed = trading && trading.tradingMode === 'LIVE' && trading.liveEnabled && !trading.emergencyStop;

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 640 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h1>Owner Trading</h1>
        <button onClick={logout}>Log out</button>
      </div>

      <p>
        Signed in as <strong>{user?.username}</strong>.
      </p>

      {error && (
        <p style={{ color: '#b00020' }}>Could not reach backend: {error}.</p>
      )}
      {loading && <p>Loading status…</p>}

      {!loading && !error && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', margin: '1rem 0' }}>
          <StatusCard
            label="Broker (Kotak) connection"
            value={broker?.configured ? 'Configured' : 'Not configured'}
            tone={broker?.configured ? 'ok' : 'neutral'}
          />
          <StatusCard
            label="Trading mode"
            value={trading?.tradingMode || '—'}
            tone={trading?.tradingMode === 'LIVE' ? 'warn' : 'ok'}
          />
          <StatusCard
            label="Live orders"
            value={liveOrdersAllowed ? 'ALLOWED' : 'BLOCKED'}
            tone={liveOrdersAllowed ? 'danger' : 'ok'}
          />
          <StatusCard
            label="Emergency stop"
            value={trading?.emergencyStop ? 'ACTIVE' : 'clear'}
            tone={trading?.emergencyStop ? 'danger' : 'ok'}
          />
          <StatusCard label="Strategies running" value={String(runningCount)} tone={runningCount > 0 ? 'ok' : 'neutral'} />
          <StatusCard label="Strategies in error" value={String(errorCount)} tone={errorCount > 0 ? 'danger' : 'neutral'} />
        </div>
      )}

      <nav style={{ margin: '1.5rem 0', display: 'flex', flexWrap: 'wrap', gap: '0.75rem 1.25rem' }}>
        <Link to="/strategies">Strategies</Link>
        <Link to="/market-data">Market data</Link>
        <Link to="/orders">Orders</Link>
        <Link to="/positions">Positions</Link>
        <Link to="/pnl">P&amp;L</Link>
        <Link to="/risk">Risk controls</Link>
        <Link to="/logs">Execution logs</Link>
        <Link to="/trading">Trading controls</Link>
        <Link to="/settings">Settings (Kotak connection)</Link>
      </nav>
    </main>
  );
}

const TONE_COLORS = {
  ok: '#0a7d28',
  warn: '#b8860b',
  danger: '#b00020',
  neutral: '#555',
};

function StatusCard({ label, value, tone }) {
  return (
    <div style={{ background: '#f4f4f4', padding: '0.75rem 1rem', borderRadius: 6 }}>
      <div style={{ fontSize: '0.75em', color: '#777' }}>{label}</div>
      <div style={{ fontSize: '1.1em', fontWeight: 'bold', color: TONE_COLORS[tone] || '#333' }}>{value}</div>
    </div>
  );
}
