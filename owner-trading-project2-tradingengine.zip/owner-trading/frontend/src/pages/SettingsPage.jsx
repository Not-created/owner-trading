import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getBrokerConfig, saveBrokerConfig, deleteBrokerConfig } from '../api/client.js';

const EMPTY_FORM = {
  consumerKey: '',
  ucc: '',
  mobileNumber: '',
  mpin: '',
  totpSecret: '',
  environment: 'prod',
};

export default function SettingsPage() {
  const [status, setStatus] = useState(null); // masked status from backend
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [savedMessage, setSavedMessage] = useState(null);

  function loadStatus() {
    setLoading(true);
    return getBrokerConfig()
      .then((data) => setStatus(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    loadStatus();
  }, []);

  function handleChange(field) {
    return (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));
  }

  async function handleSave(event) {
    event.preventDefault();
    setError(null);
    setSavedMessage(null);
    setSaving(true);
    try {
      await saveBrokerConfig(form);
      setForm(EMPTY_FORM); // never keep raw secrets in memory longer than needed
      setSavedMessage('Kotak credentials saved.');
      await loadStatus();
    } catch (err) {
      if (err.code === 'MISSING_FIELDS') {
        setError(`Missing required fields: ${(err.missing || []).join(', ')}`);
      } else {
        setError(err.message);
      }
    } finally {
      setSaving(false);
    }
  }

  async function handleDisconnect() {
    setError(null);
    setSavedMessage(null);
    try {
      await deleteBrokerConfig();
      await loadStatus();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: 480 }}>
      <p>
        <Link to="/">&larr; Back to dashboard</Link>
      </p>
      <h1>Settings — Kotak Neo connection</h1>

      <p style={{ fontSize: '0.9em', color: '#555' }}>
        Credentials are encrypted at rest and are never sent back to this page in full — only a
        masked preview is shown after saving. This form only stores credentials; it does not yet
        connect to Kotak (that requires a separate, explicitly verified integration step).
      </p>

      {loading && <p>Loading current status…</p>}

      {!loading && status && (
        <div style={{ background: '#f4f4f4', padding: '1rem', borderRadius: 6, marginBottom: '1.5rem' }}>
          {status.configured ? (
            <>
              <p>
                <strong>Configured</strong> — environment: {status.environment}, last updated:{' '}
                {status.updatedAt}
              </p>
              <ul>
                {Object.entries(status.maskedFields || {}).map(([key, value]) => (
                  <li key={key}>
                    {key}: <code>{value}</code>
                  </li>
                ))}
              </ul>
              <button onClick={handleDisconnect} style={{ color: '#b00020' }}>
                Disconnect (delete stored credentials)
              </button>
            </>
          ) : (
            <p>Not configured yet.</p>
          )}
        </div>
      )}

      <form onSubmit={handleSave}>
        <label style={{ display: 'block' }}>
          Consumer key
          <input
            value={form.consumerKey}
            onChange={handleChange('consumerKey')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          UCC (Unique Client Code)
          <input
            value={form.ucc}
            onChange={handleChange('ucc')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Mobile number (with country code)
          <input
            value={form.mobileNumber}
            onChange={handleChange('mobileNumber')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          MPIN
          <input
            type="password"
            value={form.mpin}
            onChange={handleChange('mpin')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          TOTP seed (from authenticator setup — not the 6-digit code)
          <input
            type="password"
            value={form.totpSecret}
            onChange={handleChange('totpSecret')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: '0.75rem' }}>
          Environment
          <select
            value={form.environment}
            onChange={handleChange('environment')}
            style={{ display: 'block', width: '100%', marginTop: 4 }}
          >
            <option value="prod">Production</option>
            <option value="uat">UAT (test)</option>
          </select>
        </label>

        {error && <p style={{ color: '#b00020' }}>{error}</p>}
        {savedMessage && <p style={{ color: '#0a7d28' }}>{savedMessage}</p>}

        <button type="submit" disabled={saving} style={{ marginTop: '1rem' }}>
          {saving ? 'Saving…' : 'Save credentials'}
        </button>
      </form>
    </main>
  );
}
