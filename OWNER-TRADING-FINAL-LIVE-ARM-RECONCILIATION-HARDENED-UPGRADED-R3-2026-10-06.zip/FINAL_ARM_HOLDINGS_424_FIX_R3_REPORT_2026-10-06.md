# FINAL R3 — ARM / Holdings reconciliation hardening

## Root cause addressed
The R2 code correctly normalized the official Kotak Neo SDK 3.0.7 nested `{"Error": ApiException(...)}` response for the documented/narrow empty holdings case. The deployed screenshot still showed `holdings_failed` for the exact message `No holdings found for this client V883E`, which means the live runtime was either not running the R2 broker code or an intermediate SDK/OpenAPI wrapper had stringified the nested exception and discarded its HTTP status.

R3 therefore adds one additional defensive path without weakening safety:

- Official structured `ApiException` body: exact empty holdings response -> empty collection.
- Stringified `ApiException: No holdings found for this client <id>` with no status: exact holdings-only empty response -> empty collection.
- Generic `ApiException: ...` string: remains blocked.
- Generic HTTP 424: remains blocked.
- 401/403/session errors: remain authentication blockers.
- 429/5xx/transport/malformed responses: remain blockers/unknown as appropriate.

No blanket 424 bypass was introduced.

## Runtime identity
`broker-service/app/release.py` now reports:

`OWNER-TRADING-ARM-HOLDINGS-424-HARDENED-2026-10-06-R3`

Use `GET /status` on the broker service after deployment to verify the actual running release. This prevents accidentally testing an older deployed copy.

## Validation
- Broker Python suite: **362 passed, 3 skipped**
- Includes structured nested SDK error tests, raised exception tests, 5203 No Data tests, generic 424 blocking tests, and stringified nested exception tests.
- Python compile: PASS
- deploy.sh shell syntax: PASS
- Official SDK vendor/conformance checks remain part of the suite.
