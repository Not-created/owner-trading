"""Immutable application release identity for production diagnostics."""
RELEASE_ID = "OWNER-TRADING-ARM-HOLDINGS-424-HARDENED-2026-10-06-R3"
