from __future__ import annotations

import datetime as dt
import logging
import math
from zoneinfo import ZoneInfo

from . import db
from .market_session import bar_end, in_session
from .tick_writer import tick_writer

logger = logging.getLogger("owner_trading.candle")

IST = ZoneInfo("Asia/Kolkata")
FINALIZE_GRACE_SECONDS = 1.0     # a bar is closed this long after its end, so ticks stamped inside it still in flight are counted
TIMEFRAMES = {"1m": 1, "3m": 3, "5m": 5, "10m": 10, "15m": 15, "30m": 30, "1h": 60, "1d": 1440}


class CandleEngine:
    """Builds completed bars from SFeed ticks.

    SFeed volume is cumulative day volume, so persisted candle volume is the
    delta from the previous tick/day baseline, never the cumulative value.
    Strategy evaluation is emitted only when a bar is completed.
    """
    def __init__(self):
        self._state = {}
        self._last_cum_volume: dict[tuple[str, str], int] = {}
        self._last_persist: dict[tuple[str, str, str], float] = {}
        self._last_tick_at: dict[tuple[str, str], dt.datetime] = {}
        self._persist_interval_seconds = 5.0
        self._timeframe_cache: set[str] | None = None
        self._timeframe_cache_at = 0.0
        self._timeframe_cache_ttl = 5.0
        # Forming-bar checkpoints loaded once at feed start (None = not loaded: fall back to per-key reads).
        self._preloaded: dict | None = None
        self._seeds: dict = {}
        self._completed_pending: list[tuple] = []     # (segment, token, symbol, timeframe) bars closed, awaiting strategy evaluation
        self._dispatch_task = None

    def preload_runtime_state(self) -> int:
        """Load every persisted forming-bar checkpoint with ONE query, so the first tick of each instrument after a
        restart does not need its own SQLite read on the event loop. Call from a worker thread."""
        loaded = db.load_candle_runtime_states()
        now = dt.datetime.now(IST)
        # A checkpoint whose bar has already ended belongs to a bar that never got closed (crash / kill / restart that
        # took longer than the bar). Write it as a candle (never over a stored one) and drop the checkpoint.
        stale_rows, stale_keys = [], []
        for key, row in loaded.items():
            minutes = TIMEFRAMES.get(key[2])
            try:
                start = dt.datetime.strptime(str(row["candle_at"]), "%Y-%m-%d %H:%M:%S").replace(tzinfo=IST)
            except ValueError:
                continue
            if minutes and now >= bar_end(start, minutes) + dt.timedelta(seconds=FINALIZE_GRACE_SECONDS):
                stale_keys.append(key)
                stale_rows.append({"exchange_segment": key[0], "instrument_token": key[1], "timeframe": key[2],
                                   "trading_symbol": row.get("trading_symbol"), "candle_at": row["candle_at"],
                                   "open": row["open"], "high": row["high"], "low": row["low"], "close": row["close"],
                                   "volume": row.get("volume") or 0})
        if stale_keys:
            recovered = db.insert_candles_if_missing(stale_rows)
            db.delete_candle_runtime_states_bulk(stale_keys)
            for key in stale_keys:
                loaded.pop(key, None)
            logger.info("Recovered %d unfinished bar(s) from before the restart (%d checkpoint(s) cleared).", recovered, len(stale_keys))
        seeds: dict = {}
        for tf in self._required_timeframes():
            bucket = self._bucket(now, TIMEFRAMES[tf]).strftime("%Y-%m-%d %H:%M:%S")
            for (seg, tok), row in db.load_candles_at(tf, bucket).items():
                seeds[(seg, tok, tf, bucket)] = row
        self._seeds = seeds
        self._preloaded = loaded
        return len(loaded)

    def _seed(self, exchange_segment, instrument_token, timeframe, bucket_text):
        """The bar already stored for this bucket (e.g. history loaded mid-bar), without a per-tick SQLite read."""
        if self._preloaded is not None:
            return self._seeds.get((exchange_segment, str(instrument_token), timeframe, bucket_text))
        return db.get_candle(exchange_segment, instrument_token, timeframe, bucket_text)

    def _runtime(self, exchange_segment, instrument_token, timeframe):
        if self._preloaded is not None:
            return self._preloaded.get((exchange_segment, str(instrument_token), timeframe))
        return db.get_candle_runtime_state(exchange_segment, instrument_token, timeframe)

    @staticmethod
    def _bucket(now: dt.datetime, minutes: int) -> dt.datetime:
        if minutes >= 1440:
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        # NSE cash intraday bars are anchored at the 09:15 IST session open.
        # Midnight-flooring misaligned 30m/1h bars to 09:00/10:00.
        session_start = 9 * 60 + 15
        total = now.hour * 60 + now.minute
        if total < session_start:
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        bucket_minute = session_start + ((total - session_start) // minutes) * minutes
        return now.replace(hour=bucket_minute // 60, minute=bucket_minute % 60, second=0, microsecond=0)

    def flush(self):
        """Persist all forming bars so a graceful service restart can resume them."""
        rows = []
        for key, st in list(self._state.items()):
            exchange_segment, instrument_token, timeframe = key
            rows.append({"exchange_segment": exchange_segment, "instrument_token": instrument_token,
                         "trading_symbol": st.get("trading_symbol") or str(instrument_token), "timeframe": timeframe,
                         "candle_at": st["at"].strftime("%Y-%m-%d %H:%M:%S"), "open": st["open"],
                         "high": st["high"], "low": st["low"], "close": st["close"], "volume": st["volume"]})
        db.upsert_candles(rows)

    def _required_timeframes(self) -> set[str]:
        """Return only timeframes actually needed by armed LIVE strategies/scanners.

        Building every timeframe for every subscribed instrument is unnecessarily
        expensive on the 1-OCPU production target. The result is cached briefly
        so a large tick stream does not repeatedly query the strategy tables.
        """
        now = dt.datetime.now(dt.timezone.utc).timestamp()
        if self._timeframe_cache is not None and now - self._timeframe_cache_at < self._timeframe_cache_ttl:
            return set(self._timeframe_cache)
        required: set[str] = set()
        try:
            for item in db.list_live_armed_strategy_versions():
                definition = item.get("definition") or {}
                tf = str(definition.get("timeframe") or "5m")
                if tf in TIMEFRAMES:
                    required.add(tf)
            # Only scanner definitions referenced by LIVE strategies are part
            # of the production candle workload. An unrelated active scanner
            # must not increase candle CPU/storage or alter another strategy.
            active_scanner_ids=set()
            for item in db.list_live_armed_strategy_versions():
                for raw_id in (item.get("definition") or {}).get("scanner_ids") or []:
                    try: active_scanner_ids.add(int(raw_id))
                    except (TypeError,ValueError): pass
            for scanner in db.list_scanners():
                if scanner.get("is_active") and int(scanner.get("id") or 0) in active_scanner_ids:
                    definition = scanner.get("definition") or {}
                    tf = str(definition.get("timeframe") or "5m")
                    if tf in TIMEFRAMES:
                        required.add(tf)
        except Exception as exc:  # noqa: BLE001 -- feed processing must continue
            logger.warning("Could not determine required candle timeframes: %s", exc)
        self._timeframe_cache = required or {"5m"}
        self._timeframe_cache_at = now
        return set(self._timeframe_cache)

    def on_tick(self, *, exchange_segment, instrument_token, trading_symbol, price, volume=None, timestamp=None):
        now = timestamp.astimezone(IST) if timestamp else dt.datetime.now(IST)
        try:
            price = float(price)
        except (TypeError, ValueError):
            return
        if not math.isfinite(price) or price <= 0:
            return
        key_base = (exchange_segment or "", str(instrument_token))
        # Out-of-order / replayed tick: an older tick must never close the forming bar early,
        # open a bar in the past, or rewind the cumulative-volume baseline.
        last_seen = self._last_tick_at.get(key_base)
        if last_seen is not None and now < last_seen:
            return
        self._last_tick_at[key_base] = now
        cumulative = int(volume or 0)
        completed = []
        required_timeframes = self._required_timeframes()
        # Restore the cumulative-volume baseline before calculating this tick's
        # delta. Without this ordering, the first tick after a restart loses its
        # volume contribution because the persisted baseline is loaded too late.
        previous_cumulative = self._last_cum_volume.get(key_base)
        if previous_cumulative is None:
            try:
                for restore_tf in sorted(required_timeframes):
                    runtime = self._runtime(exchange_segment, instrument_token, restore_tf)
                    if runtime and runtime.get("cumulative_volume") is not None:
                        previous_cumulative = int(runtime["cumulative_volume"])
                        break
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not restore cumulative volume baseline: %s", exc)
        if previous_cumulative is None:
            delta_volume = 0
        elif cumulative < previous_cumulative:
            # A genuine day roll-over restarts the counter; a lower value on the SAME session
            # date is a glitch -- contribute nothing and keep the higher baseline.
            if last_seen is not None and last_seen.date() == now.date():
                delta_volume = 0
                cumulative = previous_cumulative
            else:
                delta_volume = cumulative
        else:
            delta_volume = cumulative - previous_cumulative
        self._last_cum_volume[key_base] = cumulative

        # Pre-open (before 09:15) and post-close ticks are not part of any bar. They used to be bucketed to 00:00 /
        # 15:30 and produced a fake first bar in every indicator window. The volume baseline above is still kept
        # current, so the opening auction's volume lands in the 09:15 bar.
        if not in_session(now):
            return

        for tf, minutes in ((tf, TIMEFRAMES[tf]) for tf in required_timeframes):
            bucket = self._bucket(now, minutes)
            key = (*key_base, tf)
            st = self._state.get(key)
            if st is None:
                persisted = self._runtime(exchange_segment, instrument_token, tf)
                if persisted and str(persisted.get("candle_at")) == bucket.strftime("%Y-%m-%d %H:%M:%S"):
                    st = {"at": bucket, "open": float(persisted["open"]), "high": float(persisted["high"]),
                          "low": float(persisted["low"]), "close": float(persisted["close"]),
                          "volume": int(persisted.get("volume") or 0), "trading_symbol": persisted.get("trading_symbol") or trading_symbol}
                    self._state[key] = st
                    if persisted.get("cumulative_volume") is not None:
                        self._last_cum_volume[key_base] = int(persisted["cumulative_volume"])
                if st is None:
                    persisted = self._seed(exchange_segment, instrument_token, tf, bucket.strftime("%Y-%m-%d %H:%M:%S"))
                    if persisted:
                        st = {"at": bucket, "open": float(persisted["open"]), "high": float(persisted["high"]),
                              "low": float(persisted["low"]), "close": float(persisted["close"]),
                              "volume": int(persisted.get("volume") or 0), "trading_symbol": persisted.get("trading_symbol") or trading_symbol}
                        self._state[key] = st
            if not st or st["at"] != bucket:
                if st and not st.get("final"):
                    tick_writer.put_candle(self._candle_row(key, st))
                    tick_writer.delete_runtime_state(exchange_segment, instrument_token, tf)
                    completed.append(tf)
                st = {"at": bucket, "open": price, "high": price, "low": price,
                      "close": price, "volume": int(delta_volume), "trading_symbol": trading_symbol}
                self._state[key] = st
                tick_writer.put_runtime_state(exchange_segment=exchange_segment, instrument_token=instrument_token, timeframe=tf,
                                               candle_at=st["at"].strftime("%Y-%m-%d %H:%M:%S"), open_=st["open"], high=st["high"],
                                               low=st["low"], close=st["close"], volume=st["volume"],
                                               trading_symbol=trading_symbol, cumulative_volume=cumulative)
            else:
                st["high"] = max(st["high"], price)
                st["low"] = min(st["low"], price)
                st["close"] = price
                st["volume"] += int(delta_volume)
                st["trading_symbol"] = trading_symbol or st.get("trading_symbol")
                if st.get("final"):
                    # a tick stamped inside a bar the clock already closed (late delivery): re-write the bar with it
                    tick_writer.put_candle(self._candle_row(key, st))

            now_ts = dt.datetime.now(dt.timezone.utc).timestamp()
            if not st.get("final") and now_ts - self._last_persist.get(key, 0.0) >= self._persist_interval_seconds:
                tick_writer.put_runtime_state(exchange_segment=exchange_segment, instrument_token=instrument_token, timeframe=tf,
                                               candle_at=st["at"].strftime("%Y-%m-%d %H:%M:%S"), open_=st["open"], high=st["high"],
                                               low=st["low"], close=st["close"], volume=st["volume"],
                                               trading_symbol=st.get("trading_symbol"), cumulative_volume=cumulative)
                self._last_persist[key] = now_ts

        # Automated strategy evaluation is emitted only for completed bars.
        # Protective exits are separate and receive the raw tick path from the
        # WebSocket supervisor, so a stop/target never waits for a 5m close.
        if completed:
            self._emit_completed([(exchange_segment, str(instrument_token), trading_symbol, tf) for tf in completed])

    @staticmethod
    def _candle_row(key, st) -> dict:
        exchange_segment, instrument_token, timeframe = key
        return {"exchange_segment": exchange_segment, "instrument_token": instrument_token,
                "trading_symbol": st.get("trading_symbol") or str(instrument_token), "timeframe": timeframe,
                "candle_at": st["at"].strftime("%Y-%m-%d %H:%M:%S"), "open": st["open"],
                "high": st["high"], "low": st["low"], "close": st["close"], "volume": st["volume"]}

    def finalize_due(self, now: dt.datetime | None = None, grace_seconds: float = FINALIZE_GRACE_SECONDS) -> int:
        """Close every forming bar whose window has ended, BY THE CLOCK.

        Before this, a bar reached the candles table only when that same instrument's next tick arrived -- a stock
        that did not trade again for ten minutes (or never again that day) left its last bar unwritten, and a scan
        at bar-close time silently read the bar before. No I/O here: rows go to the write-behind buffer."""
        local = (now or dt.datetime.now(IST)).astimezone(IST)
        due = []
        for key, st in list(self._state.items()):
            if st.get("final"):
                continue
            minutes = TIMEFRAMES.get(key[2])
            if not minutes:
                continue
            if local >= bar_end(st["at"], minutes) + dt.timedelta(seconds=grace_seconds):
                due.append((key, st))
        completed = []
        for key, st in due:
            exchange_segment, instrument_token, tf = key
            tick_writer.put_candle(self._candle_row(key, st))
            tick_writer.delete_runtime_state(exchange_segment, instrument_token, tf)
            st["final"] = True
            completed.append((exchange_segment, instrument_token, st.get("trading_symbol") or str(instrument_token), tf))
        self._emit_completed(completed)
        return len(completed)

    def _emit_completed(self, items: list[tuple]) -> None:
        """Queue closed bars for strategy evaluation. Without a running event loop (tests, scripts) nothing is queued,
        exactly like before."""
        if not items:
            return
        try:
            import asyncio
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._completed_pending.extend(items)
        if self._dispatch_task is None or self._dispatch_task.done():
            self._dispatch_task = loop.create_task(self._dispatch_completed())

    async def _dispatch_completed(self) -> None:
        import asyncio
        while self._completed_pending:
            batch, self._completed_pending = self._completed_pending, []
            # Strategy evaluation reads the closed bar from SQLite. With write-behind buffering the bar may still be
            # in memory, so it is made durable first -- otherwise every evaluation would see the PREVIOUS bar.
            try:
                await asyncio.to_thread(tick_writer.flush)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not flush closed bars before strategy evaluation: %s", exc)
            from .algo_engine import algo_engine
            try:
                batch = await asyncio.to_thread(relevant_completed, batch)
            except Exception as exc:  # noqa: BLE001 -- on any doubt evaluate everything (the old behaviour)
                logger.warning("Could not narrow closed bars to relevant instruments: %s", exc)
            for exchange_segment, token, symbol, tf in batch:
                try:
                    await algo_engine.on_tick(exchange_segment=exchange_segment, instrument_token=token,
                                              trading_symbol=symbol, timeframe=tf)
                except Exception as exc:  # noqa: BLE001 -- one instrument must not stop the rest
                    logger.warning("Strategy evaluation failed for %s %s: %s", symbol, tf, exc)
                await asyncio.sleep(0)          # let ticks, exits and the order feed run between instruments


def relevant_completed(batch: list[tuple]) -> list[tuple]:
    """Keep only the closed bars a LIVE-armed strategy could act on (runs in a worker thread: it reads SQLite).

    Closing 2,800 bars at the same second used to call the strategy engine 2,800 times, each time re-reading every
    strategy from the database, although almost none of them can ever produce a signal. This applies the same
    rules the strategy engine applies first, once per batch:
      * no armed strategy                      -> nothing to evaluate (the runtime counter is still refreshed)
      * strategy linked to scanners            -> only its active candidates
      * strategy bound to explicit instruments -> only those
      * strategy with no scanner and no binding -> every instrument (nothing can be skipped)
    and only for the timeframe of that strategy."""
    db.refresh_algo_runtime()
    versions = db.list_live_armed_strategy_versions()
    if not versions:
        return []
    wild_all: set[str] = set()                 # timeframes where every instrument is relevant ("*" = every timeframe)
    allowed: dict[str, set[tuple[str, str]]] = {}
    allowed_tokens: dict[str, set[str]] = {}
    for v in versions:
        d = v.get("definition") or {}
        tf = str(d.get("timeframe") or "*")
        scanner_ids = [x for x in (d.get("scanner_ids") or []) if str(x).isdigit()]
        universe = d.get("universe") if isinstance(d.get("universe"), dict) else {}
        bound = universe.get("instrument_tokens") or []
        if scanner_ids:
            rows = db.list_strategy_candidates(strategy_version_id=int(v["id"]), active_only=True, limit=10000)
            allowed.setdefault(tf, set()).update((str(r["exchange_segment"]), str(r["instrument_token"])) for r in rows)
        elif bound:
            allowed_tokens.setdefault(tf, set()).update(str(x) for x in bound)
        else:
            wild_all.add(tf)
    out = []
    for item in batch:
        seg, tok, _sym, tf = item
        tfs = (tf, "*")
        if any(t in wild_all for t in tfs) or any((seg, tok) in allowed.get(t, ()) or tok in allowed_tokens.get(t, ()) for t in tfs):
            out.append(item)
    return out


candle_engine = CandleEngine()
