# v13 - Phase 3: universe and history

## Problems fixed (each has a test in tests/test_phase3_universe_history.py)
1. **Two different universes.** The scanner scans the EQ series (token order, capped to the feed budget) but daily prep warmed
   `db.list_instruments(3000)` = the first 3,000 instruments of ALL series in alphabetical order, so history was loaded for the
   wrong stocks. Daily prep now uses `scanner_engine.scan_universe()` - the same function the scanner uses.
2. **No coverage numbers.** `scanner_engine.universe_coverage()` returns the real figures: eligible stocks in the chosen series,
   stocks actually scanned, cap, truncated count, coverage %, and a plain warning ("147 of 2947 stocks are beyond the 2800-stock
   live-feed limit and are NOT scanned"). It is stored in every scan run's stats, returned by the manual scan (`coverage`) and
   appended to the scan explanation text. `/algo/universe-preview` now also returns `truncated` and counts instead of loading rows.
3. **No readiness numbers.** Scan stats now include `ready`, `not_ready` and `readiness_pct` next to the existing
   `no_candles / insufficient_history / stale` breakdown.
4. **History back-fill order.** Missing history is now loaded in this order: instruments with an open position or an active
   candidate, then the busiest stocks (last known volume), then the rest. If time runs out, the least important data is missing.
5. **Back-fill recomputed what is missing before every batch of 300** (a database-heavy pass). Daily prep computes it once and
   passes it on (`warmup_history(targets=...)`).
6. **Every 5-minute retry re-downloaded the scrip master and re-pruned candles.** A retry now repeats only what failed.
7. **`count` of the scrip master was always null** (wrong key); it now reports the number synced.
8. **Daily prep entries** report `missing_at_start`, `ready_at_start`, `remaining`, `fetched` and `coverage` per job, and use the
   `remaining` figure the fetcher reports.
9. **History fetch concurrency** is configurable (`HISTORY_FETCH_CONCURRENCY`, 1-6, default 2; raise only if Kotak allows it).

## Performance (measured here: 2,800 stocks x 750 five-minute bars = 2.1 million candle rows)
| | before | after |
|---|---|---|
| `recent_candles_for_instruments` (23 bars) | 6.13 s | 0.18 s |
| `_warmup_targets` (what is missing) | 10.93 s | 0.22 s |
| full `_scan_with_stats` | ~6.5 s + evaluation | 0.37 s + evaluation |
The old candle query ranked every candle row of the timeframe for all wanted stocks (it grew with the history kept: ~18 s for 30
days). It is now one index seek per stock on one connection, verified to return exactly what the old query returned.
`_warmup_targets` also read 250 bars per stock and tested every one; it now reads only the newest `need` bars (a scanner
needing more than 250 bars could never be satisfied before).

## Not done here (on purpose)
* Stocks beyond the 2,800 feed cap are reported, not yet rotated through in batches: that needs the dynamic feed manager (Phase 4).
* "No trade in last bar" vs "data missing" still shares the `stale` counter; Phase 4's per-instrument status separates them.
* Not measured: real Kotak historical_data throughput / rate limits and the real VPS. Daily prep's 10-minute budget may still
  not finish 2,800 stocks in one attempt on a slow API; it now resumes cheaply (only missing stocks) on each retry.
