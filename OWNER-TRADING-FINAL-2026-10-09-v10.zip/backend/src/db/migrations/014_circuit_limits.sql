-- Latest exchange circuit (price band) limits per instrument, captured from the SFeed tick.
-- Used to reject an out-of-band LIMIT/SL price locally with a clear reason instead of waiting
-- for Kotak RMS to refuse it. Existing rows are preserved; the columns start NULL.
ALTER TABLE market_data_state ADD COLUMN upper_circuit REAL;
ALTER TABLE market_data_state ADD COLUMN lower_circuit REAL;
