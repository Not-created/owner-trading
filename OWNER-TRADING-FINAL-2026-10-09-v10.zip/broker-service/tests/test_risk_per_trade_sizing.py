import unittest
from app import strategy_engine as se


def d(side="BUY", **risk):
    return {"side": side, "position_sizing": {"risk_per_trade": 200}, "risk": risk}


class RiskPerTradeSizing(unittest.TestCase):
    def test_percentage_stop_sets_the_quantity(self):
        # Rs 200 risk, 1% stop on Rs 840 => Rs 8.40 per share => 23 shares
        self.assertEqual(se.size_position(d(stop_loss_pct=1), 840.0), 23)
        self.assertEqual(se.size_position(d("SELL", stop_loss_pct=1), 840.0), 23)

    def test_atr_and_price_stops_unchanged(self):
        self.assertEqual(se.size_position(d(stop_atr_multiple=2), 100.0, atr_value=5.0), 20)
        self.assertEqual(se.size_position(d(stop_loss=95.0), 100.0), 40)

    def test_lot_and_cap_still_apply(self):
        self.assertEqual(se.size_position(d(stop_loss_pct=1), 840.0, lot_size=10), 20)
        self.assertEqual(se.size_position(d(stop_loss_pct=1), 840.0, max_quantity=5), 5)

    def test_validator_requires_a_stop_for_risk_sizing(self):
        base = {"side": "BUY", "timeframe": "15m", "entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"}]},
                "exit": {"op": "OR", "conditions": [{"left": "ema20", "operator": "cross_below", "right": "ema50"}]},
                "position_sizing": {"risk_per_trade": 200}, "risk": {"target_pct": 2}}
        self.assertTrue(any("requires a stop-loss" in e for e in se.validate_strategy(base)))
        base["risk"]["stop_loss_pct"] = 1
        self.assertEqual(se.validate_strategy(base), [])


if __name__ == "__main__":
    unittest.main()
