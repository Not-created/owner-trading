import asyncio
import datetime as dt
import unittest
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")
DEF = {"side": "BUY", "timeframe": "5m",
       "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
       "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
       "execution": {"product": "MIS"}, "risk": {"stop_loss_pct": 1, "target_pct": 2}, "position_sizing": {"quantity": 1}}


def last_complete_bar(minutes=5):
    now = dt.datetime.now(IST).replace(second=0, microsecond=0)
    now -= dt.timedelta(minutes=now.minute % minutes)
    return now - dt.timedelta(minutes=minutes)


def rows(token, n=30, end=None, fmt="%Y-%m-%d %H:%M:%S", rising=True):
    end = end or last_complete_bar()
    out = []
    for i in range(n):
        ts = end - dt.timedelta(minutes=5 * (n - 1 - i))
        px = 100 + (i if rising else -i * 0.1)
        out.append({"exchange_segment": "nse_cm", "instrument_token": token, "trading_symbol": f"S{token}", "timeframe": "5m",
                    "candle_at": ts.strftime(fmt), "open": px, "high": px + 1, "low": px - 1, "close": px, "volume": 1000})
    return out


class CanonicalTimestamps(unittest.TestCase):
    def test_all_broker_spellings_collapse_to_one_ist_format(self):
        db = fresh_db()
        for raw in ("2026-10-07T09:15:00+0530", "2026-10-07T09:15:00+05:30", "2026-10-07 09:15:00",
                    "2026-10-07T03:45:00Z", "2026-10-07T09:15:00"):
            self.assertEqual(db.canonical_candle_at(raw), "2026-10-07 09:15:00", raw)
        with self.assertRaises(ValueError):
            db.canonical_candle_at("garbage")

    def test_same_bar_in_two_spellings_is_one_row(self):
        db = fresh_db()
        a = rows("9", 1)[0]; b = dict(a); b["candle_at"] = dt.datetime.strptime(a["candle_at"], "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%dT%H:%M:%S+0530")
        db.upsert_candles([a]); db.upsert_candles([b])
        got = db.recent_candles_for_instruments([{"exchange_segment": "nse_cm", "instrument_token": "9"}], "5m", 10)
        self.assertEqual(len(got[("nse_cm", "9")]), 1)

    def test_startup_repair_merges_legacy_rows(self):
        db = fresh_db()
        with db._connection() as c:
            for at in ("2026-10-07T09:15:00+0530", "2026-10-07 09:15:00", "2026-10-07T09:20:00+0530"):
                c.execute("INSERT INTO candles(exchange_segment,instrument_token,trading_symbol,timeframe,candle_at,open,high,low,close,volume) VALUES('nse_cm','5','X','5m',?,1,1,1,1,1)", (at,))
        r = db.normalize_stored_candles()
        self.assertEqual((r["normalized"], r["duplicates_or_invalid_removed"]), (1, 1))
        with db._connection() as c:
            self.assertEqual([x[0] for x in c.execute("SELECT candle_at FROM candles ORDER BY candle_at")],
                             ["2026-10-07 09:15:00", "2026-10-07 09:20:00"])
        self.assertEqual(db.normalize_stored_candles(), {"normalized": 0, "duplicates_or_invalid_removed": 0})   # idempotent


class ScanDiagnostics(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app import scanner_engine as se
        self.se = se

    def test_required_bars_follow_the_indicators_used(self):
        d = {"entry": {"conditions": [{"left": "ema20", "operator": ">", "right": "ema50"}]}, "exit": {"conditions": []}}
        self.assertEqual(self.se.required_bars(d), 52)
        self.assertEqual(self.se.required_bars({"entry": {"conditions": [{"left": "close", "operator": ">", "right": "sma200"}]}}), 202)
        self.assertEqual(self.se.required_bars(DEF), 20)

    def test_counts_explain_every_skipped_instrument(self):
        u = [{"exchange_segment": "nse_cm", "instrument_token": t, "trading_symbol": f"S{t}"} for t in ("1", "2", "3", "4")]
        self.db.upsert_candles(rows("1"))                                         # matches
        self.db.upsert_candles(rows("2", rising=False))                           # evaluated, no match
        self.db.upsert_candles(rows("3", n=5))                                    # too few bars
        # token 4: no candles at all
        matched, st = self.se._scan_with_stats(u, DEF, "5m")
        self.assertEqual([m["instrument"]["instrument_token"] for m in matched], ["1"])
        self.assertEqual((st["evaluated"], st["insufficient_history"], st["no_candles"], st["stale"], st["matched"]), (2, 1, 1, 0, 1))

    def test_stale_history_is_reported_stale(self):
        u = [{"exchange_segment": "nse_cm", "instrument_token": "7", "trading_symbol": "S7"}]
        self.db.upsert_candles(rows("7", end=last_complete_bar() - dt.timedelta(days=2)))
        matched, st = self.se._scan_with_stats(u, DEF, "5m")
        self.assertEqual((len(matched), st["stale"]), (0, 1))
        self.assertIn("stale", self.se.explain_scan(st, market_open=False))

    def test_forming_bar_is_never_evaluated(self):
        u = [{"exchange_segment": "nse_cm", "instrument_token": "8", "trading_symbol": "S8"}]
        forming = dt.datetime.now(IST).replace(second=0, microsecond=0)
        forming -= dt.timedelta(minutes=forming.minute % 5)                       # bar that started but has not finished
        data = rows("8", end=forming)
        self.db.upsert_candles(data)
        _m, st = self.se._scan_with_stats(u, DEF, "5m")
        self.assertEqual(st["latest_candle_at"], (forming - dt.timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S"))

    def test_history_in_broker_format_is_usable_by_the_scanner(self):
        u = [{"exchange_segment": "nse_cm", "instrument_token": "6", "trading_symbol": "S6"}]
        self.db.upsert_candles(rows("6", fmt="%Y-%m-%dT%H:%M:%S+0530"))
        matched, st = self.se._scan_with_stats(u, DEF, "5m")
        self.assertEqual((len(matched), st["evaluated"]), (1, 1))


class ScannerRunAndWarmup(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments([{"trading_symbol": "AAA-EQ", "instrument_token": "11", "lot_size": 1, "tick_size": 0.05},
                                         {"trading_symbol": "BBB-EQ", "instrument_token": "12", "lot_size": 1, "tick_size": 0.05}])
        from app import scanner_engine as se
        self.se = se
        se._WARMUP_JOBS.clear()

    async def test_warmup_fetches_only_instruments_that_need_history(self):
        self.db.upsert_candles(rows("11"))                                         # 11 is ready
        calls = []

        async def fake(seg, tok, tf, a, b, sym):
            calls.append(tok)
            self.db.upsert_candles(rows(tok)); return [1], {}
        with patch("app.backtest_service._fetch_chunks", fake):
            u = self.db.list_instruments(10)
            r = await self.se.warmup_history(u, "5m", DEF)
        self.assertEqual((calls, r["fetched"], r["remaining"]), (["12"], 1, 0))

    async def test_warmup_stops_on_rate_limit_and_reports_it(self):
        n = {"c": 0}

        async def fake(seg, tok, tf, a, b, sym):
            n["c"] += 1
            return None, {"error": "HTTP 429 Too many requests"}
        with patch("app.backtest_service._fetch_chunks", fake):
            r = await self.se.warmup_history(self.db.list_instruments(10), "5m", DEF, concurrency=1)
        self.assertIn("429", r["stopped"])
        self.assertEqual(n["c"], 1)                                                 # did not hammer the API

    async def _finish_job(self, tf="5m"):
        job = self.se._WARMUP_JOBS[self.se._job_key(tf, DEF)]
        await asyncio.wait_for(job["task"], 10)
        await asyncio.sleep(0)
        return job

    async def test_run_returns_immediately_then_matches_appear_as_history_loads(self):
        async def fake(seg, tok, tf, a, b, sym):
            self.db.upsert_candles(rows(tok)); return [1], {}
        sub = AsyncMock(return_value={"total": 2}); rel = AsyncMock(return_value=0)
        with patch("app.backtest_service._fetch_chunks", fake), \
             patch.object(self.se.websocket_manager, "subscribe_many", sub), patch.object(self.se.websocket_manager, "release_owner", rel):
            first = await self.se.run({"definition": DEF, "timeframe": "5m", "subscribe_matches": True})
            self.assertEqual(first["matched"], 0)                               # nothing cached yet: answered at once
            self.assertEqual(first["warmup"]["status"], "RUNNING")
            self.assertIn("background", first["explanation"])
            job = await self._finish_job()
            self.assertEqual((job["status"], job["fetched"]), ("DONE", 2))
            out = await self.se.run({"definition": DEF, "timeframe": "5m", "subscribe_matches": True, "poll": True})
        self.assertEqual(out["matched"], 2)
        self.assertEqual({m["trading_symbol"] for m in out["matches"]}, {"AAA-EQ", "BBB-EQ"})
        self.assertEqual(out["diagnostics"]["evaluated"], 2)
        self.assertEqual(out["warmup"]["status"], "DONE")
        self.assertEqual(out["subscribed_matches"]["subscribed"], 2)
        rel.assert_awaited_with("scanner-manual-matches")
        self.assertEqual(sub.await_args.kwargs["owner"], "scanner-manual-matches")

    async def test_poll_requests_never_start_a_job_and_running_job_is_single_flight(self):
        gate = asyncio.Event()
        calls = {"n": 0}

        async def slow(seg, tok, tf, a, b, sym):
            calls["n"] += 1
            await gate.wait(); self.db.upsert_candles(rows(tok)); return [1], {}
        with patch("app.backtest_service._fetch_chunks", slow):
            poll = await self.se.run({"definition": DEF, "poll": True})
            self.assertIsNone(poll["warmup"])                                     # poll alone does not load anything
            a = await self.se.run({"definition": DEF})
            b = await self.se.run({"definition": DEF})                            # second click while running
            self.assertEqual((a["warmup"]["status"], b["warmup"]["status"]), ("RUNNING", "RUNNING"))
            await asyncio.sleep(0.1)
            self.assertLessEqual(calls["n"], 2)                                    # one job, concurrency 2: no duplicate fetches
            gate.set(); await self._finish_job()

    async def test_failed_job_is_not_restarted_within_30_seconds(self):
        n = {"c": 0}

        async def fail(seg, tok, tf, a, b, sym):
            n["c"] += 1
            return None, {"error": "Request timeout after 30 seconds"}
        with patch("app.backtest_service._fetch_chunks", fail):
            await self.se.run({"definition": DEF})
            job = await self._finish_job()
            self.assertEqual(job["status"], "STOPPED")
            self.assertIn("timeout", job["stopped"])
            calls_after_first = n["c"]
            again = await self.se.run({"definition": DEF})                         # immediate re-click
            self.assertEqual(again["warmup"]["status"], "STOPPED")
            self.assertIn("History loading stopped", again["explanation"])
            await asyncio.sleep(0.1)
            self.assertEqual(n["c"], calls_after_first)                            # no retry storm

    async def test_run_never_subscribes_unless_asked(self):
        sub = AsyncMock()
        with patch("app.backtest_service._fetch_chunks", AsyncMock(return_value=(None, {"error": "x"}))), \
             patch.object(self.se.websocket_manager, "subscribe_many", sub):
            await self.se.run({"definition": DEF})
            await self._finish_job()
        sub.assert_not_awaited()

    async def test_scan_runs_off_the_event_loop(self):
        import threading
        seen = {}
        orig = self.se._scan_with_stats

        def spy(*a, **k):
            seen["thread"] = threading.current_thread().name
            return orig(*a, **k)
        with patch.object(self.se, "_scan_with_stats", spy), \
             patch("app.backtest_service._fetch_chunks", AsyncMock(return_value=(None, {"error": "x"}))):
            await self.se.run({"definition": DEF, "warmup": False})
        self.assertNotEqual(seen["thread"], threading.main_thread().name)


if __name__ == "__main__":
    unittest.main()
