"""Scanner-linked strategy: armed -> scan cycle -> candidate -> entry evaluated -> ENTRY order."""
import datetime as dt
import unittest
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")
SCAN = {"side": "BUY", "timeframe": "5m",
        "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]},
        "exit": {"op": "OR", "conditions": [{"left": "rsi14", "operator": ">", "right": 99}]},
        "execution": {"product": "MIS"}, "risk": {"stop_loss_pct": 1, "target_pct": 2}, "position_sizing": {"quantity": 1}}


def bars(token, n=40, rising=True):
    now = dt.datetime.now(IST).replace(second=0, microsecond=0)
    end = now - dt.timedelta(minutes=now.minute % 5 + 5)
    out = []
    for i in range(n):
        ts = end - dt.timedelta(minutes=5 * (n - 1 - i))
        px = 100 + (i if rising else -i * 0.1)
        out.append({"exchange_segment": "nse_cm", "instrument_token": token, "trading_symbol": f"S{token}", "timeframe": "5m",
                    "candle_at": ts.strftime("%Y-%m-%d %H:%M:%S"), "open": px, "high": px + 1, "low": px - 1, "close": px, "volume": 1000})
    return out


class EndToEnd(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments([{"trading_symbol": "S1", "instrument_token": "1", "lot_size": 1, "tick_size": 0.05},
                                         {"trading_symbol": "S2", "instrument_token": "2", "lot_size": 1, "tick_size": 0.05}])
        self.db.upsert_candles(bars("1") + bars("2", rising=False))
        sc = self.db.create_scanner("m", SCAN)
        self.db.activate_scanner(sc["id"]) if hasattr(self.db, "activate_scanner") else self.db.set_scanner_active(sc["id"], True)
        strat = self.db.create_strategy("s")
        d = dict(SCAN, scanner_ids=[sc["id"]], universe={"instrument_tokens": []}, max_positions=2)
        v = self.db.save_strategy_version(strat["id"], d)
        self.db.set_strategy_armed(v["id"], True)
        self.vid = v["id"]
        from app import scanner_engine, algo_engine
        self.se, self.ae = scanner_engine, algo_engine
        scanner_engine._WARMUP_JOBS.clear()
        algo_engine.algo_engine._last_eval.clear()

    async def test_cycle_creates_candidate_and_places_an_entry_order_once(self):
        from app.state import BrokerState
        placed = []

        async def fake_place(payload):
            placed.append(payload)
            return {"internal_order_id": "OID1", "status": "SUBMITTED"}
        ready = {"ready": True, "armed": True, "live_orders_can_be_sent": True}
        with patch("app.backtest_service._fetch_chunks", AsyncMock(return_value=(None, {"error": "no network in test"}))), \
             patch.object(self.se.websocket_manager, "subscribe", AsyncMock()), \
             patch.object(self.se.websocket_manager, "release_owner", AsyncMock(return_value=0)), \
             patch.object(self.se.websocket_manager, "ensure_owner_subscriptions", AsyncMock(return_value={})), \
             patch("app.algo_engine.session_state", return_value={"open": True}), \
             patch("app.algo_engine.mis_entries_allowed", return_value=(True, "ok")), \
             patch("app.algo_engine.current_state", type("S", (), {"state": BrokerState.CONNECTED})()), \
             patch("app.algo_engine.live_readiness.evaluate", return_value=ready), \
             patch("app.algo_engine.order_service.place_order", fake_place):
            r = await self.se.run_continuous_cycle()
            cands = self.db.list_strategy_candidates(strategy_version_id=self.vid, active_only=True, limit=50)
            self.assertEqual([c["trading_symbol"] for c in cands], ["S1"])        # S2 (falling) does not match
            self.assertEqual(len(placed), 1)
            self.assertEqual((placed[0]["order_role"], placed[0]["instrument_token"], placed[0]["transaction_type"]), ("ENTRY", "1", "B"))
            await self.se.run_continuous_cycle()                                   # next 30 s cycle: same bar
            self.assertEqual(len(placed), 1)                                       # never a second order for the same candle


if __name__ == "__main__":
    unittest.main()
