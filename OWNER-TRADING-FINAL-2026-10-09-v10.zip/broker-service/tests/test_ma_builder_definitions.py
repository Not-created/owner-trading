"""Every definition the frontend MA-crossover builder can emit must pass the REAL engine validator."""
import json
import os
import unittest

from app import strategy_engine as se

FIXTURE = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "test", "fixtures", "ma-definitions.json")


@unittest.skipUnless(os.path.exists(FIXTURE), "frontend fixture not present")
class BuilderDefinitions(unittest.TestCase):
    def setUp(self):
        with open(FIXTURE, encoding="utf-8") as fh:
            self.cases = json.load(fh)

    def test_there_are_cases(self):
        self.assertGreaterEqual(len(self.cases), 6)

    def test_every_builder_output_is_valid_for_the_engine(self):
        for name, definition in self.cases.items():
            self.assertEqual(se.validate_strategy(definition), [], name)

    def test_crossover_semantics_are_evaluated_by_the_engine(self):
        d = self.cases["buy_default"]
        up = [{"open": 1, "high": 1, "low": 1, "close": c, "volume": 1000, "candle_at": f"2026-10-0{1 + i % 8} 10:00:00"} for i, c in enumerate([100] * 60)]
        # flat prices: fast == slow -> no cross -> no entry
        passed, _ = se.evaluate_entry(d, [dict(c, candle_at=f"2026-09-{(i % 28) + 1:02d} 10:00:00") for i, c in enumerate(up)])
        self.assertFalse(passed)
        # a rally after a long flat period: fast EMA crosses above slow EMA on exactly the bars after the turn
        series = [100.0] * 80 + [100 + 2.0 * k for k in range(1, 15)]
        bars = [{"open": c, "high": c, "low": c, "close": c, "volume": 1000, "candle_at": f"2026-09-{(i // 20) + 1:02d} {10 + (i % 20) // 4:02d}:{(i % 4) * 15:02d}:00"} for i, c in enumerate(series)]
        hits = [i for i in range(60, len(bars)) if se.evaluate_entry(d, bars[: i + 1])[0]]
        self.assertTrue(hits, "the crossover must trigger during the rally")
        self.assertGreaterEqual(min(hits), 80)

    def test_percent_stop_with_risk_sizing_gives_a_real_quantity(self):
        d = self.cases["pct_stop_risk_sizing"]
        self.assertEqual(se.size_position(d, 840.0), 23)


if __name__ == "__main__":
    unittest.main()
