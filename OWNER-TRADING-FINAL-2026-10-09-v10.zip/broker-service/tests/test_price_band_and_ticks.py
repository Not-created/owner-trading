import unittest
from unittest.mock import patch

from app import order_service as osv
from app import websocket_manager as wsm
from tests.dbutil import fresh_db


def order(**kw):
    o = dict(trading_symbol="YESBANK-EQ", exchange_segment="nse_cm", instrument_token="11915", price=20.5, trigger_price=None,
             order_role="MANUAL", quantity=1)
    o.update(kw)
    return o


class PriceBand(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()

    def test_price_far_from_ltp_is_rejected_with_a_clear_message(self):
        with patch("app.market_prices.fresh_ltp", return_value=3000.0):
            with self.assertRaisesRegex(osv.OrderValidationError, r"price 1\.00 is outside .*live price is 3000\.00"):
                osv._check_price_band(order(price=1.0))

    def test_exchange_circuit_limits_are_used_when_known(self):
        self.db.record_market_tick(instrument_token="11915", exchange_segment="nse_cm", last_traded_price=20.51,
                                   upper_circuit=22.49, lower_circuit=18.41)
        with patch("app.market_prices.fresh_ltp", return_value=20.51):
            with self.assertRaisesRegex(osv.OrderValidationError, r"allowed range 18\.41 - 22\.49"):
                osv._check_price_band(order(price=1.0))
            with self.assertRaises(osv.OrderValidationError):
                osv._check_price_band(order(price=22.60))
            osv._check_price_band(order(price=22.49))                       # on the band edge is allowed
            osv._check_price_band(order(price=20.5))

    def test_percentage_fallback_without_circuit_data(self):
        with patch("app.market_prices.fresh_ltp", return_value=100.0):
            osv._check_price_band(order(price=119.9))
            with self.assertRaises(osv.OrderValidationError):
                osv._check_price_band(order(price=121.0))

    def test_trigger_price_is_checked_too(self):
        with patch("app.market_prices.fresh_ltp", return_value=100.0):
            with self.assertRaisesRegex(osv.OrderValidationError, "trigger_price"):
                osv._check_price_band(order(price=100.0, trigger_price=5.0))

    def test_exit_market_and_no_ltp_are_never_blocked_here(self):
        with patch("app.market_prices.fresh_ltp", return_value=100.0):
            osv._check_price_band(order(price=1.0, order_role="EXIT"))
            osv._check_price_band(order(price=None))
        with patch("app.market_prices.fresh_ltp", return_value=None):
            osv._check_price_band(order(price=1.0))                          # the LIVE gate blocks "no fresh tick"


class CircuitCapture(unittest.TestCase):
    def test_sanity_filter_for_circuit_values(self):
        self.assertEqual(wsm._sane_circuit(22.49, 20.5, upper=True), 22.49)
        self.assertEqual(wsm._sane_circuit(18.41, 20.5, upper=False), 18.41)
        for bad in (None, "x", 0, -1, float("nan"), 2250, 1.0):                # unscaled / sentinel / wrong side
            self.assertIsNone(wsm._sane_circuit(bad, 20.5, upper=True), bad)
        self.assertIsNone(wsm._sane_circuit(25.0, 20.5, upper=False))

    def test_circuit_columns_persist_and_are_not_erased_by_a_tick_without_them(self):
        db = fresh_db()
        db.record_market_tick(instrument_token="1", exchange_segment="nse_cm", last_traded_price=10.0, upper_circuit=11.0, lower_circuit=9.0)
        db.record_market_tick(instrument_token="1", exchange_segment="nse_cm", last_traded_price=10.1)
        self.assertEqual(db.get_circuit_limits("nse_cm", "1"), (9.0, 11.0))


if __name__ == "__main__":
    unittest.main()


class StaleFeedMessage(unittest.TestCase):
    def test_message_names_the_closed_market_session(self):
        import datetime as dt
        from zoneinfo import ZoneInfo
        from app import market_session as ms
        st = ms.session_state(dt.datetime(2026, 10, 9, 9, 14, 21, tzinfo=ZoneInfo("Asia/Kolkata")))   # pre-open, like 03:44 UTC
        self.assertFalse(st["open"]); self.assertEqual(st["reason"], "OUTSIDE_SESSION")
