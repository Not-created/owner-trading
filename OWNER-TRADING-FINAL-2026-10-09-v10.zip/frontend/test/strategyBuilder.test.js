import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  defaultMaState, buildMaDefinition, validateMaState, describeMaState, samplePrices,
  movingAverage, findCrossovers, tradeDiagram, exampleQuantity, fastOperand, slowOperand,
} from "../src/lib/strategyBuilder.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const FIXTURE = path.join(here, "fixtures", "ma-definitions.json");

function state(over = {}) {
  return { ...defaultMaState(), name: "MA", tokens: ["11915"], ...over };
}

// The same cases are serialised to a fixture that the Python test-suite validates with the
// REAL strategy_engine.validate_strategy, so the builder can never drift from the engine.
export function fixtureCases() {
  return {
    buy_default: buildMaDefinition(state()),
    sell_sma: buildMaDefinition(state({ side: "SELL", fastType: "SMA", fastPeriod: 9, slowType: "SMA", slowPeriod: 100 })),
    all_filters_and_exits: buildMaDefinition(state({ filters: { rsi: true, volume: true, adx: true }, exitOnRsi: true, rsiExitLevel: 75,
      partialExitPct: 50, timeExitBars: 12, trailingPct: 0.5, targetPct: 3 })),
    atr_stop_capital_sizing: buildMaDefinition(state({ stopMode: "atr", stopValue: 1.5, sizingMode: "capital", capitalPct: 20 })),
    pct_stop_risk_sizing: buildMaDefinition(state({ sizingMode: "risk", riskPerTrade: 200, scannerIds: [1], tokens: [] })),
    no_target_no_trailing: buildMaDefinition(state({ targetPct: null, trailingPct: null, exitOnOpposite: false, exitOnRsi: true })),
  };
}

test("operands use the periods the engine computes", () => {
  assert.equal(fastOperand(defaultMaState()), "ema20");
  assert.equal(slowOperand({ ...defaultMaState(), slowType: "SMA", slowPeriod: 200 }), "sma200");
});

test("BUY crossover builds cross_above entry and cross_below exit", () => {
  const d = buildMaDefinition(state());
  assert.deepEqual(d.entry.conditions, [{ left: "ema20", operator: "cross_above", right: "ema50" }]);
  assert.deepEqual(d.exit.conditions, [{ left: "ema20", operator: "cross_below", right: "ema50" }]);
  assert.equal(d.side, "BUY");
});

test("SELL mirrors the crossover and the RSI filter", () => {
  const d = buildMaDefinition(state({ side: "SELL", filters: { rsi: true, volume: false, adx: false }, exitOnRsi: true, rsiExitLevel: 25 }));
  assert.equal(d.entry.conditions[0].operator, "cross_below");
  assert.deepEqual(d.entry.conditions[1], { left: "rsi14", operator: "<", right: 50 });
  assert.deepEqual(d.exit.conditions[1], { left: "rsi14", operator: "<", right: 25 });
});

test("risk block carries exactly one stop mode and only enabled extras", () => {
  const pct = buildMaDefinition(state());
  assert.deepEqual(pct.risk, { stop_loss_pct: 1, target_pct: 2, trailing_stop_pct: 0.5 });
  const atr = buildMaDefinition(state({ stopMode: "atr", stopValue: 2, targetPct: null, trailingPct: null }));
  assert.deepEqual(atr.risk, { stop_atr_multiple: 2 });
  const full = buildMaDefinition(state({ partialExitPct: 50, timeExitBars: 8 }));
  assert.equal(full.risk.partial_exit_pct, 50);
  assert.equal(full.risk.time_exit_bars, 8);
  assert.equal(buildMaDefinition(state({ partialExitPct: 100 })).risk.partial_exit_pct, undefined);
});

test("exactly one sizing mode is emitted", () => {
  assert.deepEqual(buildMaDefinition(state()).position_sizing, { quantity: 1 });
  assert.deepEqual(buildMaDefinition(state({ sizingMode: "capital", capitalPct: 15 })).position_sizing, { capital_pct: 15 });
  assert.deepEqual(buildMaDefinition(state({ sizingMode: "risk", riskPerTrade: 300 })).position_sizing, { risk_per_trade: 300 });
});

test("universe, scanners and execution are mapped", () => {
  const d = buildMaDefinition(state({ tokens: ["11915", 1333], scannerIds: ["2", 3], product: "CNC", cooldownBars: 3, maxPositions: 4 }));
  assert.deepEqual(d.universe.instrument_tokens, ["11915", "1333"]);
  assert.deepEqual(d.scanner_ids, [2, 3]);
  assert.deepEqual(d.execution, { product: "CNC", cooldown_bars: 3 });
  assert.equal(d.max_positions, 4);
});

test("validation catches every user mistake", () => {
  assert.deepEqual(validateMaState(state()), []);
  const has = (over, text) => assert.ok(validateMaState(state(over)).some((e) => e.includes(text)), `${text} <- ${JSON.stringify(over)}`);
  has({ name: " " }, "name");
  has({ fastPeriod: 50, slowPeriod: 50 }, "smaller period");
  has({ fastPeriod: 50, slowPeriod: 20 }, "smaller period");
  has({ fastPeriod: 13 }, "periods must be one of");
  has({ exitOnOpposite: false, exitOnRsi: false }, "exit rule");
  has({ stopValue: 0 }, "stop-loss is required");
  has({ stopValue: "" }, "stop-loss is required");
  has({ targetPct: -1 }, "Target");
  has({ trailingPct: 0 }, "Trailing");
  has({ partialExitPct: 0 }, "Partial");
  has({ partialExitPct: 101 }, "Partial");
  has({ timeExitBars: 1.5 }, "Time exit");
  has({ quantity: 0 }, "Quantity");
  has({ sizingMode: "capital", capitalPct: 120 }, "Capital per trade");
  has({ sizingMode: "risk", riskPerTrade: 0 }, "Risk per trade");
  has({ maxPositions: 0 }, "Max open positions");
  has({ cooldownBars: -1 }, "Cooldown");
  has({ tokens: [], scannerIds: [] }, "where it trades");
  has({ exitOnRsi: true, rsiExitLevel: 100 }, "RSI exit level");
});

test("description reads as one clear sentence", () => {
  const text = describeMaState(state({ filters: { rsi: true, volume: false, adx: false }, partialExitPct: 50 }));
  assert.match(text, /^Buy when EMA 20 crosses above EMA 50 on the 15m chart, only if RSI above 50\. Exit on the opposite crossover, a 2% target \(50% of the position\), a 1% stop-loss, a 0\.5% trailing stop\.$/);
});

test("moving averages and crossovers are computed correctly", () => {
  assert.deepEqual(movingAverage([1, 2, 3, 4, 5], "SMA", 3), [null, null, 2, 3, 4]);
  const ema = movingAverage([10, 10, 10, 10], "EMA", 3);
  assert.equal(ema[3], 10);
  const prices = samplePrices();
  const { up, down } = findCrossovers(prices, defaultMaState());
  assert.ok(up.length > 0 && down.length > 0);
  for (const i of up) {
    const { fast, slow } = findCrossovers(prices, defaultMaState());
    assert.ok(fast[i - 1] <= slow[i - 1] && fast[i] > slow[i]);
  }
  // a faster pair crosses at least as often as a slower pair on the same prices
  const quick = findCrossovers(prices, { ...defaultMaState(), fastPeriod: 5, slowPeriod: 20 });
  const slowPair = findCrossovers(prices, { ...defaultMaState(), fastPeriod: 50, slowPeriod: 200, fastType: "SMA", slowType: "SMA" });
  assert.ok(quick.up.length + quick.down.length >= slowPair.up.length + slowPair.down.length);
});

test("trade diagram: target, trailing stop and stop-loss outcomes", () => {
  const hitTarget = tradeDiagram(state({ targetPct: 2 }));
  assert.equal(hitTarget.reason, "Target");
  assert.ok(Math.abs(hitTarget.returnPct - 2) < 1e-9);
  const trailed = tradeDiagram(state({ targetPct: 10, trailingPct: 0.5 }));
  assert.equal(trailed.reason, "Trailing stop");
  assert.ok(trailed.returnPct > 2);
  const stopped = tradeDiagram(state({ targetPct: 10, trailingPct: null, stopValue: 0.25 }), [100, 99.9, 99.7, 99.5]);
  assert.equal(stopped.reason, "Stop-loss");
  assert.ok(stopped.returnPct < 0);
  assert.equal(tradeDiagram(state({ targetPct: 4, stopValue: 1 })).riskReward, 4);
  assert.equal(tradeDiagram(state({ targetPct: null })).riskReward, null);
});

test("example quantity matches the engine's sizing rule", () => {
  assert.equal(exampleQuantity(state({ sizingMode: "quantity", quantity: 7 })), 7);
  assert.equal(exampleQuantity(state({ sizingMode: "capital", capitalPct: 20 }), { price: 840, capital: 25000 }), 5);
  assert.equal(exampleQuantity(state({ sizingMode: "risk", riskPerTrade: 200, stopValue: 1 }), { price: 840 }), 23);
  assert.equal(exampleQuantity(state({ sizingMode: "risk", stopMode: "atr" })), null);
});

test("fixture of builder output matches the checked-in file", () => {
  const generated = JSON.stringify(fixtureCases(), null, 2) + "\n";
  if (process.env.UPDATE_FIXTURE === "1") {
    fs.mkdirSync(path.dirname(FIXTURE), { recursive: true });
    fs.writeFileSync(FIXTURE, generated);
  }
  assert.equal(fs.readFileSync(FIXTURE, "utf8"), generated, "run UPDATE_FIXTURE=1 node --test test/strategyBuilder.test.js");
});
