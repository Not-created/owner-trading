import { useMemo, useState } from "react";
import { api } from "../../api/client";
import {
  MA_PERIODS, MA_TYPES, TIMEFRAMES, PRODUCTS, defaultMaState, validateMaState, buildMaDefinition, describeMaState,
  samplePrices, findCrossovers, tradeDiagram, exampleQuantity,
} from "../../lib/strategyBuilder";
import "./maBuilder.css";

const STEPS = ["Entry signal", "Exit and risk", "Size, test, arm"];
const ZERO_COSTS = { entry_brokerage: 0, exit_brokerage: 0, stt_sell_pct: 0, exchange_txn_pct: 0, sebi_pct: 0, gst_pct: 0, stamp_duty_buy_pct: 0 };

function Chips({ options, value, onChange, label }) {
  return (
    <div className="sb__chips" role="group" aria-label={label}>
      {options.map((o) => {
        const v = typeof o === "object" ? o.value : o;
        const t = typeof o === "object" ? o.label : String(o);
        return (
          <button key={String(v)} type="button" className={`sb__chip ${value === v ? "sb__chip--on" : ""}`} aria-pressed={value === v} onClick={() => onChange(v)}>{t}</button>
        );
      })}
    </div>
  );
}

function Switch({ checked, onChange, label }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className="sb__switch" onClick={() => onChange(!checked)} />;
}

function Stepper({ value, onChange, step = 1, min = 0, max = 100, unit = "", decimals = 0, label }) {
  const bump = (d) => {
    const next = Math.round((Number(value) + d * step) * 1000) / 1000;
    onChange(Math.max(min, Math.min(max, next)));
  };
  return (
    <div className="sb__stepper">
      <button type="button" aria-label={`Decrease ${label}`} onClick={() => bump(-1)}>−</button>
      <output aria-label={label}>{Number(value).toFixed(decimals)}{unit}</output>
      <button type="button" aria-label={`Increase ${label}`} onClick={() => bump(1)}>+</button>
    </div>
  );
}

function OptionalStepper({ value, onChange, defaultOn, ...rest }) {
  const on = value !== null && value !== "" && value !== undefined;
  return (
    <div className="sb__stepper">
      {on ? <Stepper value={value} onChange={onChange} {...rest} /> : <span className="sb__note" style={{ margin: 0 }}>Off</span>}
      <Switch checked={on} onChange={(v) => onChange(v ? defaultOn : null)} label={`${rest.label} on or off`} />
    </div>
  );
}

function PreviewChart({ state }) {
  const prices = useMemo(() => samplePrices(), []);
  const { fast, slow, up, down } = useMemo(() => findCrossovers(prices, state), [prices, state.fastType, state.fastPeriod, state.slowType, state.slowPeriod]);
  const W = 340, H = 190, pad = 8;
  const lo = Math.min(...prices) - 1, hi = Math.max(...prices) + 1;
  const x = (i) => pad + (i * (W - 2 * pad)) / (prices.length - 1);
  const y = (v) => pad + ((hi - v) / (hi - lo)) * (H - 2 * pad);
  const line = (arr) => arr.map((v, i) => (v == null ? "" : `${arr.slice(0, i).some((q) => q != null) ? "L" : "M"}${x(i).toFixed(1)} ${y(v).toFixed(1)}`)).join(" ");
  const buy = state.side === "BUY";
  const entries = buy ? up : down;
  const exits = buy ? down : up;
  return (
    <div>
      <svg className="sb__chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Illustrative price chart with the fast and slow averages and every crossover marked">
        <path d={line(prices)} fill="none" stroke="var(--sb-price)" strokeWidth="1" opacity=".8" />
        <path d={line(slow)} fill="none" stroke="var(--sb-slow)" strokeWidth="1.8" strokeLinejoin="round" />
        <path d={line(fast)} fill="none" stroke="var(--sb-fast)" strokeWidth="1.8" strokeLinejoin="round" />
        {entries.map((i) => <path key={`e${i}`} d={`M${x(i)} ${y(fast[i]) + (buy ? 3 : -3)} l-5 ${buy ? 9 : -9} h10 Z`} fill="var(--sb-good)" />)}
        {exits.map((i) => <path key={`x${i}`} d={`M${x(i)} ${y(fast[i]) + (buy ? -3 : 3)} l-5 ${buy ? -9 : 9} h10 Z`} fill="var(--sb-bad)" />)}
      </svg>
      <div className="sb__legend">
        <span><i style={{ background: "var(--sb-fast)" }} />{state.fastType} {state.fastPeriod}</span>
        <span><i style={{ background: "var(--sb-slow)" }} />{state.slowType} {state.slowPeriod}</span>
        <span><i style={{ background: "var(--sb-good)" }} />Entry ({entries.length})</span>
        <span><i style={{ background: "var(--sb-bad)" }} />Exit signal ({exits.length})</span>
      </div>
      <p className="sb__note">Illustrative sample prices, not live data. The count shows how often this pair would have crossed.</p>
    </div>
  );
}

function TradeDiagram({ state }) {
  const d = useMemo(() => tradeDiagram(state), [state.stopMode, state.stopValue, state.targetPct, state.trailingPct]);
  const W = 340, H = 170, plR = 46, pad = 8;
  const hi = Math.max(d.target ?? 0, 104.4, ...d.path) + 0.2;
  const lo = Math.min(d.stop, 98.8) - 0.2;
  const x = (i) => pad + (i * (W - pad - plR)) / (d.path.length - 1);
  const y = (v) => pad + ((hi - v) / (hi - lo)) * (H - 2 * pad);
  const last = d.exitIndex ?? d.path.length - 1;
  const seg = (arr) => arr.slice(0, last + 1).map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(" ");
  return (
    <div>
      <svg className="sb__chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Sample trade with entry, target, stop-loss and trailing stop">
        {d.target !== null && <><line x1={pad} x2={W - plR} y1={y(d.target)} y2={y(d.target)} stroke="var(--sb-good)" strokeDasharray="4 3" /><text x={W - plR + 3} y={y(d.target) + 4} fontSize="11" fill="var(--sb-good)">Target</text></>}
        <line x1={pad} x2={W - plR} y1={y(d.stop)} y2={y(d.stop)} stroke="var(--sb-bad)" strokeDasharray="4 3" />
        <text x={W - plR + 3} y={y(d.stop) + 4} fontSize="11" fill="var(--sb-bad)">Stop</text>
        <line x1={pad} x2={W - plR} y1={y(d.entry)} y2={y(d.entry)} stroke="var(--sb-price)" strokeDasharray="2 3" />
        <text x={W - plR + 3} y={y(d.entry) + 4} fontSize="11" fill="var(--sb-price)">Entry</text>
        <path d={seg(d.trail)} fill="none" stroke="var(--sb-slow)" strokeWidth="1.5" />
        <path d={seg(d.path)} fill="none" stroke="var(--sb-fast)" strokeWidth="2" strokeLinejoin="round" />
        <circle cx={x(0)} cy={y(d.entry)} r="4" fill="var(--sb-good)" />
        {d.exitIndex !== null && <>
          <circle cx={x(d.exitIndex)} cy={y(d.exitPrice)} r="5" fill="var(--sb-bad)" />
          <text x={Math.min(x(d.exitIndex) + 8, W - plR - 70)} y={y(d.exitPrice) - 8} fontSize="11" fill="currentColor">{d.reason} {d.returnPct >= 0 ? "+" : ""}{d.returnPct.toFixed(2)}%</text>
        </>}
      </svg>
      <p className="sb__note">{d.riskReward !== null ? `Risk 1 : Reward ${d.riskReward.toFixed(1)}. ` : ""}Illustrative path: the orange line is the stop, rising behind the price when a trailing stop is on.</p>
    </div>
  );
}

function UniversePicker({ scanners, scannerIds, setScannerIds, stocks, setStocks }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const active = (scanners || []).filter((s) => s.is_active);
  async function search(e) {
    e.preventDefault();
    const q = query.trim();
    if (!q) { setResults([]); return; }
    setBusy(true); setMsg("");
    const r = await api.searchScrip({ exchange_segment: "nse_cm", symbol: q });
    setBusy(false);
    if (!r.ok) { setMsg(r.body?.error || "Stock search failed."); return; }
    setResults((Array.isArray(r.body?.data) ? r.body.data : []).slice(0, 30));
  }
  function add(row) {
    const token = String(row.pSymbol || "").trim();
    if (!token) return;
    const symbol = String(row.pTrdSymbol || row.pSymbolName || token).trim();
    setStocks((prev) => (prev.some((x) => x.token === token) ? prev : [...prev, { token, symbol }]));
    setResults((prev) => prev.filter((x) => String(x.pSymbol || "") !== token));
  }
  return (
    <div>
      <span className="sb__lab">Scanners this strategy may use</span>
      {active.length ? active.map((sc) => (
        <label key={sc.id} className="sb__line" style={{ cursor: "pointer" }}>
          <span><b>{sc.name}</b> <span className="sb__note">{sc.definition?.timeframe || ""}</span></span>
          <input type="checkbox" checked={scannerIds.includes(Number(sc.id))}
            onChange={(e) => setScannerIds((ids) => (e.target.checked ? [...new Set([...ids, Number(sc.id)])] : ids.filter((x) => x !== Number(sc.id))))} />
        </label>
      )) : <p className="sb__note">No active scanner. Pick stocks below, or create and activate one on the Scanner page.</p>}
      <span className="sb__lab">Stocks to trade (and to backtest on)</span>
      <form onSubmit={search} style={{ display: "flex", gap: 8 }}>
        <input aria-label="Search NSE stock" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search, e.g. RELIANCE" style={{ flex: 1, minHeight: 44 }} />
        <button type="submit" disabled={busy} style={{ minHeight: 44 }}>{busy ? "Searching…" : "Search"}</button>
      </form>
      {msg && <p className="sb__msg sb__msg--bad">{msg}</p>}
      {results.map((row) => (
        <div key={String(row.pSymbol)} className="sb__line">
          <span><b>{row.pTrdSymbol}</b> <span className="sb__note">{row.pSymbolName || "NSE equity"}</span></span>
          <button type="button" onClick={() => add(row)}>Add</button>
        </div>
      ))}
      <div className="sb__stocks">
        {stocks.map((s) => (
          <span className="sb__tag" key={s.token}>{s.symbol}<button type="button" aria-label={`Remove ${s.symbol}`} onClick={() => setStocks((p) => p.filter((x) => x.token !== s.token))}>×</button></span>
        ))}
      </div>
    </div>
  );
}

function isoDay(offsetDays) {
  const d = new Date(Date.now() + offsetDays * 86400000);
  return d.toISOString().slice(0, 10);
}

function BacktestPanel({ state, stocks, errors, definition }) {
  const [from, setFrom] = useState(isoDay(-180));
  const [to, setTo] = useState(isoDay(0));
  const [pick, setPick] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [result, setResult] = useState(null);
  const chosen = stocks.find((s) => s.token === pick) || stocks[0];
  const blocking = errors.filter((e) => !/name|where it trades/i.test(e));

  async function run() {
    if (busy) return;
    setMsg(""); setResult(null);
    if (!chosen) return setMsg("Add at least one stock above to backtest on.");
    if (blocking.length) return setMsg(blocking[0]);
    if (from > to) return setMsg("From date cannot be after To date.");
    setBusy(true);
    try {
      const r = await api.runBacktest({
        exchange_segment: "nse_cm", instrument_token: chosen.token, trading_symbol: chosen.symbol, timeframe: state.timeframe,
        quantity: String(state.sizingMode === "quantity" ? state.quantity : (exampleQuantity(state) || 1)),
        from_date: from, to_date: to, initial_capital: "100000", slippage: "0.0005", fees: "0", cost_model: ZERO_COSTS, definition,
      });
      if (r.ok) setResult(r.body.result);
      else setMsg(r.body?.validation_errors?.join("; ") || r.body?.error || (r.status ? `Backtest failed (HTTP ${r.status}).` : "Backtest failed: no response."));
    } catch (e) {
      setMsg(e.message || "Backtest failed");
    } finally { setBusy(false); }
  }

  const curve = Array.isArray(result?.equity_curve) ? result.equity_curve.map((p) => Number(p.equity)).filter(Number.isFinite) : [];
  const W = 340, H = 90;
  const cl = Math.min(...curve), ch = Math.max(...curve);
  const cx = (i) => (i * W) / Math.max(1, curve.length - 1);
  const cy = (v) => 6 + ((ch - v) / Math.max(1e-9, ch - cl)) * (H - 12);
  const fmt = (v, d = 2, suffix = "") => (v === null || v === undefined || Number.isNaN(Number(v)) ? "—" : `${Number(v).toFixed(d)}${suffix}`);
  return (
    <div>
      <div className="sb__grid2">
        <div><span className="sb__lab">Stock</span>
          <select aria-label="Backtest stock" value={chosen?.token || ""} onChange={(e) => setPick(e.target.value)} style={{ width: "100%", minHeight: 44 }}>
            {stocks.length ? stocks.map((s) => <option key={s.token} value={s.token}>{s.symbol}</option>) : <option value="">Add a stock first</option>}
          </select></div>
        <div><span className="sb__lab">Period</span>
          <div style={{ display: "flex", gap: 6 }}>
            <input type="date" aria-label="From date" value={from} onChange={(e) => setFrom(e.target.value)} style={{ flex: 1, minHeight: 44 }} />
            <input type="date" aria-label="To date" value={to} onChange={(e) => setTo(e.target.value)} style={{ flex: 1, minHeight: 44 }} />
          </div></div>
      </div>
      <div className="sb__actions"><button type="button" onClick={run} disabled={busy}>{busy ? "Running backtest…" : "Run backtest"}</button></div>
      {msg && <p className="sb__msg sb__msg--bad">{msg}</p>}
      {result && (
        <div>
          <div className="sb__metrics">
            <div className="sb__metric"><span>Trades</span><b>{result.total_trades ?? "—"}</b></div>
            <div className="sb__metric"><span>Win rate</span><b>{fmt(result.win_rate, 1, "%")}</b></div>
            <div className="sb__metric"><span>Profit factor</span><b>{fmt(result.profit_factor)}</b></div>
            <div className="sb__metric"><span>Net P&amp;L</span><b>{fmt(result.net_pnl)}</b></div>
            <div className="sb__metric"><span>Max drawdown</span><b>{fmt(result.max_drawdown)}</b></div>
            <div className="sb__metric"><span>Sharpe</span><b>{fmt(result.sharpe)}</b></div>
          </div>
          {curve.length > 1 && (
            <svg className="sb__chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Backtest equity curve">
              <path d={curve.map((v, i) => `${i ? "L" : "M"}${cx(i).toFixed(1)} ${cy(v).toFixed(1)}`).join(" ")} fill="none" stroke="var(--sb-good)" strokeWidth="2" strokeLinejoin="round" />
            </svg>
          )}
          <p className="sb__note">Real backtest on {chosen?.symbol}, {result.data_window?.from_date} to {result.data_window?.to_date}. Past results do not promise future profit; one stock is not the whole strategy.</p>
        </div>
      )}
    </div>
  );
}

export default function MaCrossoverBuilder({ scanners, onSaved }) {
  const [step, setStep] = useState(0);
  const [state, setState] = useState(defaultMaState());
  const [stocks, setStocks] = useState([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState({ text: "", ok: false });
  const set = (patch) => setState((s) => ({ ...s, ...patch }));
  const setScannerIds = (fn) => setState((s) => ({ ...s, scannerIds: typeof fn === "function" ? fn(s.scannerIds) : fn }));

  const full = useMemo(() => ({ ...state, tokens: stocks.map((s) => s.token) }), [state, stocks]);
  const errors = useMemo(() => validateMaState(full), [full]);
  const definition = useMemo(() => buildMaDefinition(full), [full]);
  const qty = exampleQuantity(full);

  async function save() {
    if (saving) return;
    setMsg({ text: "", ok: false });
    if (errors.length) return setMsg({ text: errors[0], ok: false });
    setSaving(true);
    try {
      const vld = await api.validateAlgoStrategy(definition);
      if (!vld.ok || !vld.body?.valid) return setMsg({ text: vld.body?.errors?.join("; ") || "The engine rejected this definition.", ok: false });
      const created = await api.createAlgoStrategy({ name: state.name.trim() });
      if (!created.ok) return setMsg({ text: created.body?.error || "Create failed", ok: false });
      const v = await api.saveAlgoStrategyVersion(created.body.strategy.id, { definition, status: "VALIDATED" });
      if (!v.ok) return setMsg({ text: v.body?.error || "Save failed.", ok: false });
      setMsg({ text: "Validated and saved. It appears below; arming LIVE is a separate step you do there.", ok: true });
      setState(defaultMaState()); setStocks([]); setStep(0);
      onSaved?.();
    } finally { setSaving(false); }
  }

  const buy = state.side === "BUY";
  return (
    <div className="card sb">
      <div className="card__head"><h3 className="card__title">Moving average crossover builder</h3></div>
      <div className="sb__steps" role="tablist" aria-label="Builder steps">
        {STEPS.map((label, i) => (
          <button key={label} type="button" role="tab" aria-selected={step === i} className={`sb__step ${step === i ? "sb__step--on" : ""}`} onClick={() => setStep(i)}>
            <b>{i + 1}</b>{label}
          </button>
        ))}
      </div>

      {step === 0 && (
        <>
          <div className="sb__panel">
            <h4>Strategy</h4>
            <input aria-label="Strategy name" value={state.name} onChange={(e) => set({ name: e.target.value })} placeholder="Name, e.g. EMA 20/50 intraday" style={{ width: "100%", minHeight: 44 }} />
            <span className="sb__lab">Trade direction</span>
            <Chips label="Direction" value={state.side} onChange={(v) => set({ side: v })} options={[{ value: "BUY", label: "Buy when fast crosses above" }, { value: "SELL", label: "Sell when fast crosses below" }]} />
            <span className="sb__lab">Timeframe</span>
            <Chips label="Timeframe" value={state.timeframe} onChange={(v) => set({ timeframe: v })} options={TIMEFRAMES} />
          </div>
          <div className="sb__panel">
            <div className="sb__grid2">
              <div>
                <span className="sb__lab" style={{ color: "var(--sb-fast)" }}>Fast average</span>
                <Chips label="Fast type" value={state.fastType} onChange={(v) => set({ fastType: v })} options={MA_TYPES} />
                <div style={{ height: 6 }} />
                <Chips label="Fast period" value={state.fastPeriod} onChange={(v) => set({ fastPeriod: v })} options={MA_PERIODS} />
              </div>
              <div>
                <span className="sb__lab" style={{ color: "var(--sb-slow)" }}>Slow average</span>
                <Chips label="Slow type" value={state.slowType} onChange={(v) => set({ slowType: v })} options={MA_TYPES} />
                <div style={{ height: 6 }} />
                <Chips label="Slow period" value={state.slowPeriod} onChange={(v) => set({ slowPeriod: v })} options={MA_PERIODS} />
              </div>
            </div>
            {Number(state.fastPeriod) >= Number(state.slowPeriod) && <p className="sb__msg sb__msg--bad">The fast average needs a smaller period than the slow one.</p>}
            <p className="sb__note">Periods are the ones the engine computes: {MA_PERIODS.join(", ")}.</p>
          </div>
          <div className="sb__panel"><h4>Preview</h4><PreviewChart state={full} /></div>
          <div className="sb__panel">
            <h4>Entry filters <span className="sb__note">(optional; all selected must pass)</span></h4>
            <div className="sb__line"><span>RSI {buy ? "above" : "below"} 50</span><Switch label="RSI filter" checked={state.filters.rsi} onChange={(v) => set({ filters: { ...state.filters, rsi: v } })} /></div>
            <div className="sb__line"><span>Volume above its 20-bar average</span><Switch label="Volume filter" checked={state.filters.volume} onChange={(v) => set({ filters: { ...state.filters, volume: v } })} /></div>
            <div className="sb__line"><span>ADX above 20 (trend strength)</span><Switch label="ADX filter" checked={state.filters.adx} onChange={(v) => set({ filters: { ...state.filters, adx: v } })} /></div>
          </div>
        </>
      )}

      {step === 1 && (
        <>
          <div className="sb__panel"><h4>How one trade plays out</h4><TradeDiagram state={full} /></div>
          <div className="sb__panel">
            <h4>Exit rules</h4>
            <div className="sb__line"><span>Exit on the opposite crossover</span><Switch label="Exit on opposite crossover" checked={state.exitOnOpposite} onChange={(v) => set({ exitOnOpposite: v })} /></div>
            <div className="sb__line"><span>Exit when RSI {buy ? "rises above" : "falls below"}</span>
              <div className="sb__stepper">
                {state.exitOnRsi && <Stepper label="RSI exit level" value={state.rsiExitLevel} onChange={(v) => set({ rsiExitLevel: v })} step={5} min={5} max={95} />}
                <Switch label="RSI exit" checked={state.exitOnRsi} onChange={(v) => set({ exitOnRsi: v })} />
              </div></div>
            <div className="sb__line"><span>Target</span><OptionalStepper label="Target" value={state.targetPct} onChange={(v) => set({ targetPct: v })} defaultOn={2} step={0.5} min={0.5} max={50} unit="%" decimals={2} /></div>
            <div className="sb__line"><span>Close only part at the target</span><OptionalStepper label="Partial exit" value={state.partialExitPct === 100 ? null : state.partialExitPct} onChange={(v) => set({ partialExitPct: v === null ? 100 : v })} defaultOn={50} step={10} min={10} max={90} unit="%" /></div>
            <div className="sb__line"><span>Time exit after</span><OptionalStepper label="Time exit bars" value={state.timeExitBars} onChange={(v) => set({ timeExitBars: v })} defaultOn={12} step={1} min={1} max={500} unit=" bars" /></div>
            <div className="sb__line"><span>MIS positions close automatically</span><span className="sb__note" style={{ margin: 0 }}>15:15 IST</span></div>
          </div>
          <div className="sb__panel">
            <h4>Protection</h4>
            <Chips label="Stop mode" value={state.stopMode} onChange={(v) => set({ stopMode: v, stopValue: v === "atr" ? 1.5 : 1 })} options={[{ value: "pct", label: "Stop in %" }, { value: "atr", label: "ATR multiple" }]} />
            <div className="sb__line"><span>Stop-loss {state.stopMode === "atr" ? "(× ATR)" : "(% from entry)"}</span>
              <Stepper label="Stop-loss" value={state.stopValue} onChange={(v) => set({ stopValue: v })} step={state.stopMode === "atr" ? 0.5 : 0.25} min={state.stopMode === "atr" ? 0.5 : 0.25} max={state.stopMode === "atr" ? 10 : 20} unit={state.stopMode === "atr" ? "×" : "%"} decimals={2} /></div>
            <div className="sb__line"><span>Trailing stop</span><OptionalStepper label="Trailing stop" value={state.trailingPct} onChange={(v) => set({ trailingPct: v })} defaultOn={0.5} step={0.25} min={0.25} max={20} unit="%" decimals={2} /></div>
            <p className="sb__note">A stop-loss is required before a strategy can go live.</p>
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <div className="sb__panel">
            <h4>Position size</h4>
            <Chips label="Sizing" value={state.sizingMode} onChange={(v) => set({ sizingMode: v })} options={[{ value: "quantity", label: "Fixed quantity" }, { value: "capital", label: "% of capital" }, { value: "risk", label: "₹ risk per trade" }]} />
            <div className="sb__line">
              <span>{state.sizingMode === "quantity" ? "Shares per trade" : state.sizingMode === "capital" ? "Capital per trade" : "Money at risk per trade"}</span>
              {state.sizingMode === "quantity" && <Stepper label="Quantity" value={state.quantity} onChange={(v) => set({ quantity: v })} step={1} min={1} max={100000} />}
              {state.sizingMode === "capital" && <Stepper label="Capital percent" value={state.capitalPct} onChange={(v) => set({ capitalPct: v })} step={5} min={5} max={100} unit="%" />}
              {state.sizingMode === "risk" && <Stepper label="Risk per trade" value={state.riskPerTrade} onChange={(v) => set({ riskPerTrade: v })} step={50} min={50} max={1000000} unit="₹" />}
            </div>
            <p className="sb__note">
              {state.sizingMode === "risk" && state.stopMode === "atr" ? "Quantity is calculated from the ATR at entry time." : `Example at ₹840 with ₹25,000 capital: ${qty ?? "—"} shares.`}
            </p>
            <div className="sb__line"><span>Product</span><Chips label="Product" value={state.product} onChange={(v) => set({ product: v })} options={PRODUCTS} /></div>
            <div className="sb__line"><span>Max open positions</span><Stepper label="Max positions" value={state.maxPositions} onChange={(v) => set({ maxPositions: v })} step={1} min={1} max={50} /></div>
            <div className="sb__line"><span>Cooldown after a trade (bars)</span><Stepper label="Cooldown bars" value={state.cooldownBars} onChange={(v) => set({ cooldownBars: v })} step={1} min={0} max={100} /></div>
          </div>
          <div className="sb__panel"><h4>Where it trades</h4>
            <UniversePicker scanners={scanners} scannerIds={state.scannerIds} setScannerIds={setScannerIds} stocks={stocks} setStocks={setStocks} />
          </div>
          <div className="sb__panel"><h4>Backtest</h4>
            <BacktestPanel state={full} stocks={stocks} errors={errors} definition={definition} />
          </div>
          <div className="sb__panel">
            <h4>Review</h4>
            <p className="sb__summary">{describeMaState(full)}</p>
            {errors.length > 0 && <ul className="sb__errors">{errors.map((e) => <li key={e}>{e}</li>)}</ul>}
            <div className="sb__actions">
              <button type="button" onClick={save} disabled={saving || errors.length > 0}>{saving ? "Saving…" : "Validate & save version"}</button>
            </div>
            <p className="sb__note">Saving never trades. Arming LIVE is a separate action on the saved version, and the usual safety checks still apply.</p>
          </div>
        </>
      )}

      {msg.text && <p className={`sb__msg ${msg.ok ? "sb__msg--ok" : "sb__msg--bad"}`} role="status">{msg.text}</p>}
      <div className="sb__nav">
        <button type="button" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>Back</button>
        {step < 2 && <button type="button" onClick={() => setStep((s) => Math.min(2, s + 1))}>Next: {STEPS[step + 1]}</button>}
      </div>
    </div>
  );
}
