"""Thin wrapper around the official `kotakneoapi` SDK's `NeoAPI` facade.

Method names and call shapes here are verified against the audited
Kotak-Neo/kotak-neo-python source (main branch, v3.0.6) kept read-only at
/home/claude/kotak-neo-sdk-reference in the assistant's workspace during
that audit -- NOT against the legacy v2 `kotak-neo-api-v2` client, and NOT
against invented/guessed method names.

IMPORTANT: authentication (connect/test_connection) now makes REAL calls to
the official SDK's totp_login/totp_validate -- but ONLY when explicitly
invoked via the Express -> broker-service /connect or /test routes, which
in turn only fire when the owner submits credentials through the Settings
UI and clicks Connect/Test. Nothing here runs automatically on startup, and
no route anywhere calls these implicitly.
"""
from __future__ import annotations

import asyncio

from .config import config
from .state import BrokerState, current_state


def _sanitize_sdk_response(resp, *, context: str) -> str:
    """Turns a raw Kotak SDK response into a message safe to store in
    state.last_error and return over HTTP to the frontend.

    BUGFIX (final audit): connect()/test_connection() used to embed the
    raw SDK response dict verbatim (f"totp_login rejected: {login_resp}")
    into last_error, which flows straight through Express to the Settings
    UI (brokerKotak.js returns result.body.last_error as-is). A raw Kotak
    error payload can carry diagnostic/echoed fields (request ids, partial
    account identifiers, internal error codes) that have no business
    reaching a browser response -- only a short, human-readable reason
    should. This extracts a plausible message field if the SDK provided
    one (several Kotak error shapes use "message" or "errCode" +
    "errMsg" -- neither confirmed against a live account in this audit,
    so both are tried defensively) and otherwise falls back to a generic,
    non-leaking message.
    """
    if isinstance(resp, dict):
        for key in ("message", "errMsg", "error", "error_description"):
            val = resp.get(key)
            if isinstance(val, str) and val.strip():
                return f"{context}: {val.strip()[:300]}"
        code = resp.get("errCode") or resp.get("code")
        if code:
            return f"{context}: broker rejected the request (code {code})."
    return f"{context}: broker rejected the request."

try:
    from neo_api_client import NeoAPI  # official SDK, package name "kotakneoapi"

    SDK_AVAILABLE = True
except ImportError:
    # Expected in this phase's offline validation (no network to `pip
    # install kotakneoapi`) -- the real VPS deploy installs it via
    # requirements.txt. The service must still start and report a clear
    # state rather than crash.
    NeoAPI = None
    SDK_AVAILABLE = False


class NotConfiguredError(RuntimeError):
    """Raised by any broker-calling method when credentials are missing or
    no session has been established. Never silently returns fake data."""


class LiveTradingBlockedError(RuntimeError):
    """Raised when an order-placing method is reached while LIVE trading
    isn't genuinely allowed. Defense in depth: the Express backend's
    requireLiveTradingAllowed middleware is the primary gate; this is the
    same rule enforced independently on the Python side, so a bug in one
    layer can't silently let an order through.
    """


def assert_live_trading_allowed() -> None:
    from .state import BrokerState as _BrokerState  # local import avoids a cycle at module load
    from . import db as _db

    if config.trading_mode != "LIVE":
        raise LiveTradingBlockedError("TRADING_MODE is not LIVE on this deployment.")
    if _db.is_emergency_stop_active():
        raise LiveTradingBlockedError("Emergency stop is active.")
    if current_state.state != _BrokerState.CONNECTED:
        raise LiveTradingBlockedError(f"Broker is not CONNECTED (state: {current_state.state.value}).")


class BrokerClient:
    """Owns exactly one `NeoAPI` instance for the process lifetime -- the
    persistent Python service is not restarted per request, per the
    architecture requirement that a new process must not be spawned for
    every market-data request.
    """

    def __init__(self) -> None:
        self._neo: "NeoAPI | None" = None
        # BUGFIX (final audit): connect()/test_connection()/disconnect()/
        # reconnect() had no concurrency protection -- two near-simultaneous
        # requests (e.g. a double-click on Connect, or Connect firing while
        # a background reconnect is already running) could both reach the
        # real totp_login/totp_validate calls at once, racing on
        # self._neo and on the shared state machine. A single lock around
        # every state-changing action serializes them: a second caller
        # waits for the first to finish rather than interleaving.
        self._lock = asyncio.Lock()

    # ---------------------------------------------------------------- #
    # Authentication -- REAL implementation, gated on this being explicitly
    # invoked via /connect (never on startup, never implicitly).
    #
    # Call shape verified against the audited Kotak-Neo/kotak-neo-python
    # source (main, v3.0.6): NeoAPI(consumer_key=..., environment=...) ->
    # totp_login(mobile_number=..., ucc=..., totp=...) ->
    # totp_validate(mpin=...). Success/failure detection matches the
    # audited behavior of neo_api.py: a successful call returns a dict
    # containing a truthy "data" key; the SDK itself stores
    # edit_token/edit_sid/data_center onto NeoAPI.configuration (a
    # NeoUtility instance) once totp_validate succeeds -- checking those
    # attributes directly (not just the response dict) is how the audited
    # SDK's own trading methods decide whether a session is usable, so
    # that's the same bar used here for "verified and usable" per this
    # phase's requirement.
    # ---------------------------------------------------------------- #
    def is_ready_to_authenticate(self) -> bool:
        return SDK_AVAILABLE and config.is_fully_configured()

    async def connect(self) -> dict:
        """Public entrypoint -- serializes against any other in-flight
        connect/test/disconnect/reconnect via self._lock (see __init__)."""
        async with self._lock:
            return await self._connect_locked()

    async def _connect_locked(self) -> dict:
        """Performs the real two-step Kotak auth flow and, on success,
        keeps the resulting NeoAPI instance alive on self._neo for
        subsequent market-data/order calls. Transitions the shared state
        machine; never marks CONNECTED unless edit_token/edit_sid are
        genuinely present on the SDK's own configuration object afterward.
        """
        from . import credential_manager as credential_manager_module
        from .credential_manager import credential_manager
        from . import db as _db

        if not SDK_AVAILABLE:
            current_state.transition(
                BrokerState.CONNECTION_ERROR, "kotakneoapi SDK is not installed in this environment."
            )
            return current_state.as_dict()

        creds = credential_manager.get()
        if not credential_manager.has_base_credentials():
            current_state.transition(BrokerState.NOT_CONFIGURED, "Credentials have not been saved yet.")
            return current_state.as_dict()

        totp = credential_manager.current_totp_code()
        if not totp:
            reason = (
                "pyotp is not installed in this environment (transitive kotakneoapi dependency)."
                if not credential_manager_module.PYOTP_AVAILABLE
                else "No TOTP secret is saved."
            )
            current_state.transition(BrokerState.AUTH_FAILED, f"Could not generate a TOTP code: {reason}")
            return current_state.as_dict()

        current_state.transition(BrokerState.VERIFYING)
        loop = asyncio.get_running_loop()
        try:
            neo = NeoAPI(consumer_key=creds.consumer_key, environment=config.environment)
            # totp_login/totp_validate are SYNCHRONOUS in the audited SDK
            # (blocking httpx calls) -- run them off the event loop so a
            # slow/hanging Kotak response can't stall the whole persistent
            # service (including any concurrent WebSocket handling).
            login_resp = await loop.run_in_executor(
                None, lambda: neo.totp_login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp)
            )
        except Exception as exc:  # noqa: BLE001 -- any transport/SDK-level failure here is a connection error, not an auth rejection
            current_state.transition(BrokerState.CONNECTION_ERROR, f"totp_login request failed: {exc}")
            return current_state.as_dict()

        if not isinstance(login_resp, dict) or not login_resp.get("data"):
            current_state.transition(BrokerState.AUTH_FAILED, _sanitize_sdk_response(login_resp, context="totp_login rejected"))
            return current_state.as_dict()

        try:
            validate_resp = await loop.run_in_executor(None, lambda: neo.totp_validate(mpin=creds.mpin))
        except Exception as exc:  # noqa: BLE001
            current_state.transition(BrokerState.CONNECTION_ERROR, f"totp_validate request failed: {exc}")
            return current_state.as_dict()

        if not isinstance(validate_resp, dict) or not validate_resp.get("data"):
            current_state.transition(BrokerState.AUTH_FAILED, _sanitize_sdk_response(validate_resp, context="totp_validate rejected"))
            return current_state.as_dict()

        cfg = getattr(neo, "configuration", None)
        edit_token = getattr(cfg, "edit_token", None) if cfg else None
        edit_sid = getattr(cfg, "edit_sid", None) if cfg else None
        if not (edit_token and edit_sid):
            # The SDK reported success but didn't leave a usable session --
            # per this phase's rule, that is NOT "CONNECTED".
            current_state.transition(
                BrokerState.AUTH_FAILED,
                "totp_validate reported success but no usable session (edit_token/edit_sid) was established.",
            )
            return current_state.as_dict()

        self._neo = neo
        data_center = getattr(cfg, "data_center", None)

        # "Read-only broker verification" step, required BEFORE CONNECTED is
        # ever reported (per this phase's own definition: "CONNECTED means:
        # real authentication succeeded, usable session exists, required
        # session/token state is valid, safe read-only verification
        # succeeds"). edit_token/edit_sid being present only proves the SDK
        # *stored* something -- it does not prove Kotak's backend actually
        # accepts that session for real calls. One real, side-effect-free
        # call (limits() -- funds/margin, never places or touches an order)
        # is made here, synchronously, before transitioning to CONNECTED.
        # A failure here means AUTH_FAILED, not CONNECTED, even though
        # totp_validate itself reported success.
        try:
            verify_resp = await loop.run_in_executor(None, neo.limits)
        except Exception as exc:  # noqa: BLE001
            self._neo = None
            current_state.transition(BrokerState.CONNECTION_ERROR, f"Read-only verification call (limits) failed: {exc}")
            return current_state.as_dict()

        if isinstance(verify_resp, dict) and any(k in verify_resp for k in ("error", "errMsg", "errCode")):
            self._neo = None
            current_state.transition(
                BrokerState.AUTH_FAILED,
                _sanitize_sdk_response(verify_resp, context="Session established but read-only verification (limits) was rejected"),
            )
            return current_state.as_dict()

        from . import session as _session

        _session.mark_session_established(data_center)
        _db.record_reconciliation(
            reconciliation_type="connect", reference_id=creds.ucc, discrepancy_found=False,
            details={"data_center": data_center, "verification_call": "limits"},
        )

        # Per the "reconciliation before LIVE readiness" requirement: a
        # fresh CONNECTED session's local view of orders/positions/
        # holdings/funds must be reconciled against the broker immediately,
        # not left stale until the next scheduled pass (main.py runs the
        # scheduled pass every RECONCILIATION_INTERVAL_SECONDS, but that
        # could be minutes away from the moment of connecting). Best-effort:
        # a reconciliation failure must not undo an otherwise-successful
        # connect, so it's logged, not raised.
        try:
            from . import reconciliation as _reconciliation

            await _reconciliation.run_full_reconciliation()
        except Exception as exc:  # noqa: BLE001
            import logging

            logging.getLogger("owner_trading.broker_client").warning(
                "Post-connect reconciliation failed (state remains CONNECTED): %s", exc
            )

        # Same best-effort policy as reconciliation above: WebSocket
        # streaming is a real-time convenience layer on top of the REST
        # foundation this connect already established -- if it can't
        # start (SDK shape mismatch, callback registration failure, etc.,
        # see websocket_manager.py's module docstring), the connection
        # itself is still genuinely CONNECTED and usable via REST; this
        # never downgrades a successful auth+session+verification into a
        # failure just because real-time streaming couldn't come up.
        try:
            from . import websocket_manager as _websocket_manager

            await _websocket_manager.websocket_manager.start()
        except Exception as exc:  # noqa: BLE001
            import logging

            logging.getLogger("owner_trading.broker_client").warning(
                "WebSocket start failed after connect (state remains CONNECTED, REST-only): %s", exc
            )

        return current_state.as_dict()

    async def test_connection(self) -> dict:
        """Public entrypoint -- serializes against connect/disconnect/
        reconnect via self._lock (see __init__), so a Test click can't race
        a concurrent Connect click against the same NeoAPI/session state."""
        async with self._lock:
            return await self._test_connection_locked()

    async def _test_connection_locked(self) -> dict:
        """Performs the same real two-step flow to genuinely verify the
        saved credentials, then immediately logs the test session back out
        (SDK's own logout() -- audited as LogoutAPI.logging_out) rather
        than keeping it. Deliberately does NOT transition the persisted
        broker_connection_state -- test and connect are kept separate per
        this phase's requirement, so a test never makes the dashboard show
        CONNECTED.
        """
        from . import credential_manager as credential_manager_module
        from .credential_manager import credential_manager

        if not SDK_AVAILABLE:
            return {"success": False, "error": "kotakneoapi SDK is not installed in this environment."}

        creds = credential_manager.get()
        if not credential_manager.has_base_credentials():
            return {"success": False, "error": "Credentials have not been saved yet."}

        totp = credential_manager.current_totp_code()
        if not totp:
            reason = (
                "pyotp is not installed in this environment."
                if not credential_manager_module.PYOTP_AVAILABLE
                else "No TOTP secret is saved."
            )
            return {"success": False, "error": f"Could not generate a TOTP code: {reason}"}

        loop = asyncio.get_running_loop()
        try:
            neo = NeoAPI(consumer_key=creds.consumer_key, environment=config.environment)
            login_resp = await loop.run_in_executor(
                None, lambda: neo.totp_login(mobile_number=creds.mobile_number, ucc=creds.ucc, totp=totp)
            )
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "error": f"totp_login request failed: {exc}"}

        if not isinstance(login_resp, dict) or not login_resp.get("data"):
            return {"success": False, "error": _sanitize_sdk_response(login_resp, context="totp_login rejected")}

        try:
            validate_resp = await loop.run_in_executor(None, lambda: neo.totp_validate(mpin=creds.mpin))
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "error": f"totp_validate request failed: {exc}"}

        if not isinstance(validate_resp, dict) or not validate_resp.get("data"):
            return {"success": False, "error": _sanitize_sdk_response(validate_resp, context="totp_validate rejected")}

        cfg = getattr(neo, "configuration", None)
        edit_token = getattr(cfg, "edit_token", None) if cfg else None
        edit_sid = getattr(cfg, "edit_sid", None) if cfg else None
        if not (edit_token and edit_sid):
            return {
                "success": False,
                "error": "totp_validate reported success but no usable session (edit_token/edit_sid) was established.",
            }

        # Same read-only verification standard as connect() (final audit
        # fix -- these two paths had drifted: connect() gained a real
        # read-only check while test_connection() still declared success
        # right after totp_validate). One real, side-effect-free call
        # (limits()) must also succeed here before Test Connection reports
        # success, so "Test Connection" and "Connect" can never disagree
        # about whether the same credentials are actually usable.
        try:
            verify_resp = await loop.run_in_executor(None, neo.limits)
        except Exception as exc:  # noqa: BLE001
            try:
                await loop.run_in_executor(None, neo.logout)
            except Exception:  # noqa: BLE001
                pass
            return {"success": False, "error": f"Read-only verification call (limits) failed: {exc}"}

        if isinstance(verify_resp, dict) and any(k in verify_resp for k in ("error", "errMsg", "errCode")):
            try:
                await loop.run_in_executor(None, neo.logout)
            except Exception:  # noqa: BLE001
                pass
            return {
                "success": False,
                "error": _sanitize_sdk_response(verify_resp, context="Session established but read-only verification (limits) was rejected"),
            }

        try:
            await loop.run_in_executor(None, neo.logout)
        except Exception:  # noqa: BLE001 -- best-effort cleanup, test result already known
            pass

        return {"success": True}

    async def disconnect(self) -> dict:
        """Public entrypoint -- serializes via self._lock (see __init__)."""
        async with self._lock:
            return await self._disconnect_locked()

    async def _disconnect_locked(self) -> dict:
        """Deliberate disconnect action (distinct from an involuntary
        SESSION_EXPIRED). Best-effort calls the SDK's own logout(), then
        always drops the local session regardless of whether that call
        succeeded -- a failed logout call must never leave the app still
        believing it holds a usable session.
        """
        try:
            from . import websocket_manager as _websocket_manager

            await _websocket_manager.websocket_manager.stop()
        except Exception:  # noqa: BLE001 -- disconnect must proceed even if the feed was never started
            pass

        if self._neo is not None:
            try:
                await asyncio.get_running_loop().run_in_executor(None, self._neo.logout)
            except Exception:  # noqa: BLE001
                pass
        self._neo = None

        from . import session as _session
        from . import db as _db

        _session.current_session.established_at = None
        try:
            _db.record_session_ended()
        except Exception:  # noqa: BLE001
            pass
        current_state.transition(BrokerState.DISCONNECTED)
        return current_state.as_dict()

    async def reconnect(self) -> dict:
        """Public entrypoint -- takes the lock ONCE for the whole
        disconnect-then-connect sequence (via the *_locked internals, never
        the public connect()/disconnect()) so a concurrent Test/Connect/
        Disconnect request can't interleave with a reconnect in progress --
        asyncio.Lock is not reentrant, so calling the public connect()/
        disconnect() here (which each try to acquire the same lock) would
        deadlock.
        """
        async with self._lock:
            await self._disconnect_locked()
            return await self._connect_locked()

    # ---------------------------------------------------------------- #
    # Market data foundation (method names verified against audited SDK)
    # ---------------------------------------------------------------- #
    def quotes(self, *args, **kwargs):
        self._require_connected()
        return self._neo.quotes(*args, **kwargs)

    def scrip_master(self, *args, **kwargs):
        self._require_connected()
        return self._neo.scrip_master(*args, **kwargs)

    def search_scrip(self, *args, **kwargs):
        self._require_connected()
        return self._neo.search_scrip(*args, **kwargs)

    def expiries(self, *args, **kwargs):
        self._require_connected()
        return self._neo.expiries(*args, **kwargs)

    def option_chain(self, *args, **kwargs):
        self._require_connected()
        return self._neo.option_chain(*args, **kwargs)

    def historical_data(self, *args, **kwargs):
        self._require_connected()
        return self._neo.historical_data(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Order foundation
    # ---------------------------------------------------------------- #
    def place_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        # Deliberately not called anywhere yet -- no order route exists in
        # this phase, and both safety gates above (Express middleware +
        # this Python-side assertion) must pass before this line is ever
        # reached.
        return self._neo.place_order(*args, **kwargs)

    def modify_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.modify_order(*args, **kwargs)

    def cancel_order(self, *args, **kwargs):
        assert_live_trading_allowed()
        self._require_connected()
        return self._neo.cancel_order(*args, **kwargs)

    def order_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_report(*args, **kwargs)

    def order_history(self, *args, **kwargs):
        self._require_connected()
        return self._neo.order_history(*args, **kwargs)

    def trade_report(self, *args, **kwargs):
        self._require_connected()
        return self._neo.trade_report(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # Portfolio foundation
    # ---------------------------------------------------------------- #
    def positions(self, *args, **kwargs):
        self._require_connected()
        return self._neo.positions(*args, **kwargs)

    def holdings(self, *args, **kwargs):
        self._require_connected()
        return self._neo.holdings(*args, **kwargs)

    def limits(self, *args, **kwargs):
        self._require_connected()
        return self._neo.limits(*args, **kwargs)

    def margin_required(self, *args, **kwargs):
        self._require_connected()
        return self._neo.margin_required(*args, **kwargs)

    # ---------------------------------------------------------------- #
    # WebSocket -- both known SDK generations' methods are wrapped here as
    # thin passthroughs (current: create_websocket/subscribe_scrips/
    # unsubscribe_scrips/create_order_feed; legacy:
    # subscribe/un_subscribe/subscribe_to_orderfeed). Neither is assumed
    # correct for a given deployment -- websocket_manager.py calls
    # sdk_conformance.detect_websocket_api_shape() at runtime against
    # whatever SDK is actually installed and only ever invokes the shape
    # that's genuinely present, so this class exposes both without
    # guessing which one any particular installation will use.
    # ---------------------------------------------------------------- #
    def create_market_feed(self, **kwargs):
        """Current-shape factory: self._neo.create_websocket(**kwargs)."""
        self._require_connected()
        return self._neo.create_websocket(**kwargs)

    def create_order_feed(self, **kwargs):
        """Current-shape factory: self._neo.create_order_feed(**kwargs)."""
        self._require_connected()
        return self._neo.create_order_feed(**kwargs)

    def subscribe_scrips(self, *args, **kwargs):
        self._require_connected()
        return self._neo.subscribe_scrips(*args, **kwargs)

    def unsubscribe_scrips(self, *args, **kwargs):
        self._require_connected()
        return self._neo.unsubscribe_scrips(*args, **kwargs)

    def legacy_subscribe(self, *args, **kwargs):
        """Legacy-shape: self._neo.subscribe(*args, **kwargs)."""
        self._require_connected()
        return self._neo.subscribe(*args, **kwargs)

    def legacy_unsubscribe(self, *args, **kwargs):
        self._require_connected()
        return self._neo.un_subscribe(*args, **kwargs)

    def legacy_subscribe_to_orderfeed(self, *args, **kwargs):
        self._require_connected()
        return self._neo.subscribe_to_orderfeed(*args, **kwargs)

    # ---------------------------------------------------------------- #
    def _require_connected(self) -> None:
        if current_state.state != BrokerState.CONNECTED or self._neo is None:
            raise NotConfiguredError(
                f"Broker is not connected (state: {current_state.state.value})."
            )


# Module-level singleton -- one broker client per persistent process.
broker_client = BrokerClient()
