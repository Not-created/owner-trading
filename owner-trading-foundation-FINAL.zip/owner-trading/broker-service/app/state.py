"""Broker connection state machine.

Mirrors the states defined on the Express side
(backend/src/services/brokerState.js) exactly -- the two must never drift,
since the Express /api/broker/status route passes this service's state
straight through to the dashboard.
"""
from enum import Enum
from dataclasses import dataclass, field
import time


class BrokerState(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    VERIFYING = "VERIFYING"
    CONNECTED = "CONNECTED"
    AUTH_FAILED = "AUTH_FAILED"
    SESSION_EXPIRED = "SESSION_EXPIRED"
    CONNECTION_ERROR = "CONNECTION_ERROR"
    NOT_CONFIGURED = "NOT_CONFIGURED"


@dataclass
class StateHolder:
    """In-memory, single-process state holder. The broker service is a
    single persistent process (never spawned per-request), so in-memory
    state is safe here -- Express polls /status rather than sharing memory.
    """

    state: BrokerState = BrokerState.NOT_CONFIGURED
    last_error: str | None = None
    last_transition_at: float = field(default_factory=time.time)

    def transition(self, new_state: BrokerState, error: str | None = None) -> None:
        self.state = new_state
        self.last_error = error
        self.last_transition_at = time.time()

    def as_dict(self) -> dict:
        return {
            "state": self.state.value,
            "last_error": self.last_error,
            "last_transition_at": self.last_transition_at,
        }


# Module-level singleton -- one broker service process, one state.
current_state = StateHolder()
