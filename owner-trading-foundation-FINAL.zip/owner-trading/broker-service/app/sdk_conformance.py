"""Runtime conformance check for the installed Kotak SDK.

WHY THIS EXISTS (final audit): this project's SDK version/source could NOT
be conclusively verified from outside a real deployment. During this audit:

  - The repo the project's own spec named, github.com/Kotak-Neo/kotak-neo-python,
    returned a 404 on direct fetch (tried twice, independently).
  - PyPI's project page for "kotakneoapi" (the package requirements.txt
    pins) shows a real-looking, cryptographically attested 3.0.6 release
    (GitHub OIDC Trusted Publishing + Sigstore transparency-log entries)
    naming that same repo as its source -- evidence that is hard to fully
    fabricate, but does not by itself prove the repo is public and
    unchanged right now.
  - Kotak Securities' own official bulletin (kotaksecurities.com /
    kotakneo.com, fetched directly) names a THIRD, different repo --
    github.com/Kotak-Neo/kotak-neo-api -- as "our official Python SDK",
    using a materially different (older, password+OTP) login flow.
  - A fourth repo, Kotak-Neo/Kotak-neo-api-v2 (API version 2.0.0, latest
    tag v2.0.2), fetches successfully and independently confirms the
    totp_login/totp_validate flow and the order/portfolio method names
    this codebase calls -- but its WebSocket API is the older
    subscribe()/un_subscribe()/subscribe_to_orderfeed() shape, not the
    create_websocket()/subscribe_scrips()/create_order_feed() shape this
    codebase (and the kotakneoapi 3.0.6 PyPI page) describe.

None of this is resolved with certainty. Per this phase's explicit rule --
"Do NOT assume. Do NOT invent." -- the responsible response is not to pick
one source and hope, but to make the running system check itself: at
startup, introspect whatever package is ACTUALLY installed in THIS
deployment (via `pip install -r requirements.txt`, which the operator
controls and can point at whichever source they've independently verified)
and refuse to report a healthy/connectable state if it doesn't expose the
exact symbols broker_client.py and websocket_manager.py call.

This turns "we can't verify the docs" into "the code verifies itself
against whatever is really installed, every time it starts" -- a stronger
guarantee than trusting any single external source, and it fails LOUD
(CONNECTION_ERROR, not a crash, not a silent skip) rather than discovering
a signature mismatch for the first time when an owner's LIVE order fails.
"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field


@dataclass
class ConformanceResult:
    ok: bool
    checked: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.ok:
            return f"SDK conformance OK ({len(self.checked)} symbols verified present)."
        return (
            f"SDK conformance FAILED -- installed package is missing: {', '.join(self.missing)}. "
            f"This deployment's installed 'kotakneoapi'/'neo_api_client' package does not match "
            f"what this codebase calls. Do not trust CONNECTED state until this is resolved -- "
            f"see app/sdk_conformance.py for how to re-run this check and what it verifies."
        )


# Every method broker_client.py actually calls on a NeoAPI instance. This
# list is the ground truth for "does this deployment's installed SDK match
# what our code calls" -- not a claim about which repo/version is
# officially canonical (see module docstring: that's unresolved).
_REQUIRED_NEOAPI_METHODS = [
    "totp_login",
    "totp_validate",
    "logout",
    "quotes",
    "scrip_master",
    "search_scrip",
    "expiries",
    "option_chain",
    "historical_data",
    "place_order",
    "modify_order",
    "cancel_order",
    "order_report",
    "order_history",
    "trade_report",
    "positions",
    "holdings",
    "limits",
    "margin_required",
]

# WebSocket factory methods -- only checked as a WARNING, not a hard
# failure, since websocket_manager.py's start() is not invoked yet in this
# phase (see websocket_manager.py: "not called this phase"). If these are
# missing, real-time market/order data simply cannot be enabled yet, but
# REST-only operation (auth, orders, portfolio, reconciliation) is
# unaffected.
_OPTIONAL_WEBSOCKET_METHODS = ["create_websocket", "create_order_feed"]


def check_sdk_conformance() -> ConformanceResult:
    """Introspects whatever is actually importable as `neo_api_client.NeoAPI`
    right now, in this environment. Returns ok=False (never raises) if the
    SDK isn't installed at all or is missing anything this codebase calls.
    """
    try:
        from neo_api_client import NeoAPI  # the exact import broker_client.py uses
    except ImportError as exc:
        return ConformanceResult(ok=False, missing=[f"<import failed: {exc}>"])

    checked: list[str] = []
    missing: list[str] = []
    for name in _REQUIRED_NEOAPI_METHODS:
        attr = getattr(NeoAPI, name, None)
        if attr is None or not callable(attr):
            missing.append(name)
        else:
            checked.append(name)

    warnings: list[str] = []
    for name in _OPTIONAL_WEBSOCKET_METHODS:
        attr = getattr(NeoAPI, name, None)
        if attr is None or not callable(attr):
            warnings.append(
                f"NeoAPI.{name} not found on the installed SDK -- real-time WebSocket "
                f"streaming cannot be enabled until this is resolved (REST-only calls, "
                f"including order placement, are unaffected)."
            )
        else:
            checked.append(name)

    # Sanity-check the constructor accepts the keyword args we call it with,
    # so a signature drift (e.g. consumer_key renamed) is caught here rather
    # than surfacing as an opaque TypeError inside connect().
    try:
        sig = inspect.signature(NeoAPI.__init__)
        params = set(sig.parameters.keys())
        for required_kw in ("consumer_key", "environment"):
            if required_kw not in params and "kwargs" not in str(sig):
                missing.append(f"NeoAPI.__init__(..., {required_kw}=...)")
    except (TypeError, ValueError):
        warnings.append("Could not introspect NeoAPI.__init__ signature.")

    return ConformanceResult(ok=(len(missing) == 0), checked=checked, missing=missing, warnings=warnings)
