"""Runtime conformance check for the installed Kotak SDK.

UPDATED: this project's official SDK source (github.com/Kotak-Neo/
kotak-neo-python, kotakneoapi 3.0.7) was directly inspected file-by-file
-- not fetched indirectly, not guessed from search snippets. Confirmed
directly from neo_api_client/neo_api.py:

  - Every method this codebase calls (totp_login, totp_validate,
    place_order, modify_order, cancel_order, order_report, order_history,
    trade_report, positions, holdings, limits, quotes, search_scrip,
    scrip_master, expiries, option_chain, historical_data,
    create_websocket, create_order_feed) exists with a confirmed exact
    signature.
  - NeoAPI.subscribe()/un_subscribe()/subscribe_to_orderfeed() exist as
    methods but their bodies unconditionally `raise NotImplementedError`
    ("Removed in 2.2.0. Use create_websocket() (SFeed WebSocket)
    instead.") -- there is no working "legacy shape" to fall back to.
    This module previously carried a dual-shape detector (current vs.
    legacy) written under genuine uncertainty about which shape a real
    installation would expose; that uncertainty is now resolved, and the
    legacy branch has been removed rather than kept as dead weight.

Despite having the real source for THIS version, the check below still
does NOT assume any future/different installed version matches it
exactly -- it introspects whatever `neo_api_client.NeoAPI` is ACTUALLY
importable in this deployment (via `pip install -r requirements.txt`,
which the operator controls) and refuses to report a healthy/connectable
state if it doesn't expose every symbol this codebase calls. A pip
install of a different version than 3.0.7 is exactly the scenario this
check exists to catch -- it fails LOUD (CONNECTION_ERROR, not a crash,
not a silent skip) rather than discovering a signature mismatch for the
first time when an owner's LIVE order fails.
"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field


@dataclass
class ConformanceResult:
    ok: bool
    checked: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.ok:
            return f"SDK conformance OK ({len(self.checked)} symbols verified present)."
        return (
            f"SDK conformance FAILED -- installed package is missing: {', '.join(self.missing)}. "
            f"This deployment's installed 'kotakneoapi'/'neo_api_client' package does not match "
            f"what this codebase calls (verified against kotakneoapi 3.0.7's real source -- see "
            f"this module's docstring). Do not trust CONNECTED state until this is resolved."
        )


# Every method broker_client.py actually calls on a NeoAPI instance --
# confirmed present, with these exact names, in kotakneoapi 3.0.7's real
# source (neo_api_client/neo_api.py).
_REQUIRED_NEOAPI_METHODS = [
    "totp_login",
    "totp_validate",
    "logout",
    "quotes",
    "scrip_master",
    "search_scrip",
    "expiries",
    "option_chain",
    "historical_data",
    "place_order",
    "modify_order",
    "cancel_order",
    "order_report",
    "order_history",
    "trade_report",
    "positions",
    "holdings",
    "limits",
    "margin_required",
    "create_websocket",
    "create_order_feed",
]

# The Pydantic message/token types websocket_manager.py imports directly
# from neo_api_client.websocket.feed / .orderfeed -- confirmed present in
# kotakneoapi 3.0.7's real source. Checked separately from
# _REQUIRED_NEOAPI_METHODS since these aren't NeoAPI attributes.
_REQUIRED_FEED_TYPES = ("WsToken", "SFeedScrip", "SFeedScripLite", "SFeedIndex", "SFeedMarketStatus")
_REQUIRED_ORDERFEED_TYPES = ("OrderUpdate", "OrderData", "PositionUpdate", "PositionData")


def check_sdk_conformance() -> ConformanceResult:
    """Introspects whatever is actually importable as `neo_api_client`
    right now, in this environment. Returns ok=False (never raises) if the
    SDK isn't installed at all or is missing anything this codebase calls
    -- on either the main NeoAPI class or the WebSocket message/token
    types, both of which are hard requirements now that this codebase
    calls the real WebSocket API directly (no more shape-detection
    fallback -- see module docstring).
    """
    try:
        from neo_api_client import NeoAPI  # the exact import broker_client.py uses
    except ImportError as exc:
        return ConformanceResult(ok=False, missing=[f"<import failed: {exc}>"])

    checked: list[str] = []
    missing: list[str] = []
    for name in _REQUIRED_NEOAPI_METHODS:
        attr = getattr(NeoAPI, name, None)
        if attr is None or not callable(attr):
            missing.append(f"NeoAPI.{name}")
        else:
            checked.append(f"NeoAPI.{name}")

    try:
        from neo_api_client.websocket.feed import (  # noqa: F401
            SFeedIndex,
            SFeedMarketStatus,
            SFeedScrip,
            SFeedScripLite,
            WsToken,
        )

        for name in _REQUIRED_FEED_TYPES:
            checked.append(f"websocket.feed.{name}")
    except ImportError as exc:
        missing.append(f"neo_api_client.websocket.feed ({', '.join(_REQUIRED_FEED_TYPES)}): {exc}")

    try:
        from neo_api_client.websocket.orderfeed import (  # noqa: F401
            OrderData,
            OrderUpdate,
            PositionData,
            PositionUpdate,
        )

        for name in _REQUIRED_ORDERFEED_TYPES:
            checked.append(f"websocket.orderfeed.{name}")
    except ImportError as exc:
        missing.append(f"neo_api_client.websocket.orderfeed ({', '.join(_REQUIRED_ORDERFEED_TYPES)}): {exc}")

    warnings: list[str] = []
    # Sanity-check the constructor accepts the keyword args we call it with,
    # so a signature drift (e.g. consumer_key renamed) is caught here rather
    # than surfacing as an opaque TypeError inside connect().
    try:
        sig = inspect.signature(NeoAPI.__init__)
        params = set(sig.parameters.keys())
        for required_kw in ("consumer_key", "environment"):
            if required_kw not in params and "kwargs" not in str(sig):
                missing.append(f"NeoAPI.__init__(..., {required_kw}=...)")
    except (TypeError, ValueError):
        warnings.append("Could not introspect NeoAPI.__init__ signature.")

    return ConformanceResult(ok=(len(missing) == 0), checked=checked, missing=missing, warnings=warnings)
