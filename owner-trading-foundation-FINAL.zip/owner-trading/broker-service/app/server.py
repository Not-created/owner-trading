"""Minimal async HTTP server, stdlib-only (asyncio streams -- no aiohttp/
FastAPI dependency), so the broker service has zero extra pip packages
beyond the official SDK itself. It runs on the SAME event loop that will
host the WebSocket manager (next phase), rather than spinning up a second
process or a blocking thread per request -- satisfying "do not create a new
Python process for every market-data request" at the transport level too.

Bound to config.host (127.0.0.1 by default) -- never exposed publicly (see
deployment/nginx, which never proxies to this port). No auth of its own:
this interface is trusted only because it is unreachable from outside the
host; the real user-facing auth boundary is the Express session layer.

Endpoints:
  GET  /health       -> liveness only
  GET  /status        -> broker connection state (never fabricated)
  POST /credentials   -> save Kotak credentials (in-memory only, see credential_manager.py)
  POST /test           -> test_connection(): real auth attempt, immediately logged back out, state machine untouched
  POST /connect        -> connect(): real auth attempt, persists session + state on success
  POST /disconnect     -> disconnect(): drops the active session
  POST /reconnect      -> disconnect() then connect()
  GET  /funds          -> real-time reconcile + return latest funds snapshot
  GET  /positions      -> real-time reconcile + return latest positions snapshot
  GET  /holdings       -> real-time reconcile + return latest holdings snapshot
  GET  /orders         -> local orders table (PAPER + LIVE, our own source of truth)
  POST /orders         -> place an order (PAPER simulated locally / LIVE via real SDK call -- see order_service.py)
  POST /orders/cancel  -> cancel an order (body: {internal_order_id, amo?}) -- calls the
                          real, source-verified cancel_order(order_id, amo, isVerify) directly
  POST /orders/modify  -> modify an order (body: {internal_order_id, quantity?, price?, trigger_price?})
                          -- calls the real modify_order(order_id, price, order_type, quantity,
                          validity, trigger_price) directly, filling in order_type/validity from
                          the order's own stored values (both are mandatory on the real signature)
  GET  /order-history  -> broker_client.order_history(), sanitized
  GET  /trades         -> broker_client.trade_report(), sanitized, live (local `trades` table is
                           only populated once a real order-feed/fill source exists -- not yet)
  POST /quotes         -> broker_client.quotes(**body) -- exact kwargs are the caller's
                           responsibility (see order_service.py's module docstring for why this
                           codebase won't guess Kotak's exact parameter names)
  POST /scrip-search   -> broker_client.search_scrip(**body), same passthrough policy
  GET  /audit-logs     -> local audit_logs table

Request/response bodies are JSON. Credential values are never logged --
see the explicit avoidance of logging `body` anywhere below.
"""
from __future__ import annotations

import asyncio
import json
import logging
from urllib.parse import urlsplit, parse_qs

from .config import config
from .state import current_state, BrokerState

logger = logging.getLogger("owner_trading.server")

MAX_BODY_BYTES = 8192  # credential payloads are tiny; reject anything larger


def _json_response(status_code: int, payload: dict) -> bytes:
    body = json.dumps(payload).encode("utf-8")
    status_text = {
        200: "OK", 400: "Bad Request", 404: "Not Found",
        405: "Method Not Allowed", 500: "Internal Server Error",
    }.get(status_code, "Error")
    headers = (
        f"HTTP/1.1 {status_code} {status_text}\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    )
    return headers.encode("utf-8") + body


async def _read_headers(reader: asyncio.StreamReader) -> dict:
    headers = {}
    while True:
        line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not line or line in (b"\r\n", b"\n"):
            break
        if b":" in line:
            name, _, value = line.partition(b":")
            headers[name.decode("latin-1").strip().lower()] = value.decode("latin-1").strip()
    return headers


async def _read_json_body(reader: asyncio.StreamReader, headers: dict) -> dict:
    length = int(headers.get("content-length", "0") or "0")
    if length <= 0:
        return {}
    if length > MAX_BODY_BYTES:
        raise ValueError("Request body too large.")
    raw = await asyncio.wait_for(reader.readexactly(length), timeout=10)
    if not raw:
        return {}
    parsed = json.loads(raw.decode("utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("Request body must be a JSON object.")
    return parsed


def _require_fields(body: dict, fields: list[str]) -> str | None:
    for f in fields:
        if not body.get(f):
            return f"Missing required field: {f}"
    return None


async def _handle_portfolio_read(which: str) -> bytes:
    """Shared handler for /funds, /positions, /holdings -- reuses
    reconciliation.py's fetch+normalize+persist logic (rather than
    duplicating the same best-effort field-name extraction here) and then
    returns the freshly-persisted snapshot. This means every read through
    this endpoint doubles as a reconciliation pass -- consistent with "do
    not fetch broker data and discard it".
    """
    from . import reconciliation as _reconciliation
    from . import db as _db
    from .broker_client import NotConfiguredError

    reconcile_fn = {
        "funds": _reconciliation.reconcile_funds,
        "positions": _reconciliation.reconcile_positions,
        "holdings": _reconciliation.reconcile_holdings,
    }[which]
    snapshot_fn = {
        "funds": _db.latest_funds_snapshot,
        "positions": _db.latest_positions_snapshot,
        "holdings": _db.latest_holdings_snapshot,
    }[which]

    if current_state.state != BrokerState.CONNECTED:
        return _json_response(409, {"error": f"Broker is not connected (state: {current_state.state.value})."})

    try:
        await reconcile_fn()
    except NotConfiguredError as exc:
        return _json_response(409, {"error": str(exc)})
    except Exception as exc:  # noqa: BLE001
        return _json_response(502, {"error": f"{which} fetch failed: {exc}"})

    return _json_response(200, {which: snapshot_fn()})


async def _handle_broker_passthrough(reader: asyncio.StreamReader, headers: dict, method_name: str) -> bytes:
    """Shared handler for /quotes and /scrip-search. Per this codebase's
    consistent honesty policy (see order_service.py's module docstring):
    Kotak's exact parameter names for quotes()/search_scrip() were not
    independently verified either, so the request body is forwarded
    as-is (**body) rather than mapped through a guessed schema -- the
    caller (frontend/owner) supplies the exact field names their real
    Kotak account's SDK expects.
    """
    from .broker_client import NotConfiguredError, _sanitize_sdk_response, response_is_error

    try:
        body = await _read_json_body(reader, headers)
    except (ValueError, json.JSONDecodeError) as exc:
        return _json_response(400, {"error": str(exc)})

    if current_state.state != BrokerState.CONNECTED:
        return _json_response(409, {"error": f"Broker is not connected (state: {current_state.state.value})."})

    from .broker_client import broker_client as _broker_client

    method = getattr(_broker_client, method_name)
    try:
        resp = await asyncio.get_running_loop().run_in_executor(None, lambda: method(**body))
    except NotConfiguredError as exc:
        return _json_response(409, {"error": str(exc)})
    except TypeError as exc:
        # Wrong/unexpected kwargs -- report this plainly rather than
        # letting it look like a broker rejection.
        return _json_response(400, {"error": f"Invalid parameters for {method_name}: {exc}"})
    except Exception as exc:  # noqa: BLE001
        return _json_response(502, {"error": f"{method_name} call failed: {exc}"})

    if isinstance(resp, dict) and response_is_error(resp):
        return _json_response(502, {"error": _sanitize_sdk_response(resp, context=f"{method_name} rejected")})
    return _json_response(200, {"data": resp})


async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    from .broker_client import broker_client  # local import avoids a cycle at module load

    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=5)
        if not request_line:
            writer.close()
            return

        parts = request_line.decode("latin-1").strip().split(" ")
        method, raw_path = (parts[0], parts[1]) if len(parts) >= 2 else ("", "")
        split = urlsplit(raw_path)
        path = split.path
        query = parse_qs(split.query)
        headers = await _read_headers(reader)

        if method == "GET" and path == "/health":
            writer.write(_json_response(200, {"status": "ok"}))

        elif method == "GET" and path == "/status":
            writer.write(_json_response(200, current_state.as_dict()))

        elif method == "GET" and path == "/credentials/status":
            from .credential_manager import credential_manager

            writer.write(_json_response(200, credential_manager.masked_summary()))

        elif method == "POST" and path == "/credentials":
            try:
                body = await _read_json_body(reader, headers)
            except (ValueError, json.JSONDecodeError) as exc:
                writer.write(_json_response(400, {"error": str(exc)}))
                await writer.drain()
                return
            missing = _require_fields(body, ["consumerKey", "mobileNumber", "ucc", "mpin", "totpSecret"])
            if missing:
                writer.write(_json_response(400, {"error": missing}))
            else:
                from .credential_manager import credential_manager, CredentialFormatError

                try:
                    credential_manager.set(
                        consumer_key=body["consumerKey"],
                        mobile_number=body["mobileNumber"],
                        ucc=body["ucc"],
                        mpin=body["mpin"],
                        totp_secret=body["totpSecret"],
                    )
                except CredentialFormatError as exc:
                    writer.write(_json_response(400, {"error": str(exc)}))
                    await writer.drain()
                    return
                # Credentials were just saved but no connection has been
                # attempted yet -- move off NOT_CONFIGURED to DISCONNECTED
                # (credentials exist, but that is explicitly NOT the same
                # as CONNECTED); leave any other existing state untouched.
                if current_state.state == BrokerState.NOT_CONFIGURED:
                    current_state.transition(BrokerState.DISCONNECTED)
                writer.write(_json_response(200, {"success": True}))

        elif method == "POST" and path == "/test":
            result = await broker_client.test_connection()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/connect":
            result = await broker_client.connect()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/disconnect":
            result = await broker_client.disconnect()
            writer.write(_json_response(200, result))

        elif method == "POST" and path == "/reconnect":
            result = await broker_client.reconnect()
            writer.write(_json_response(200, result))

        elif method == "GET" and path == "/funds":
            writer.write(await _handle_portfolio_read("funds"))

        elif method == "GET" and path == "/positions":
            writer.write(await _handle_portfolio_read("positions"))

        elif method == "GET" and path == "/holdings":
            writer.write(await _handle_portfolio_read("holdings"))

        elif method == "GET" and path == "/orders":
            from . import db as _db

            limit = int(query.get("limit", ["200"])[0])
            writer.write(_json_response(200, {"orders": _db.list_orders(limit=limit)}))

        elif method == "POST" and path == "/orders":
            from . import order_service

            try:
                body = await _read_json_body(reader, headers)
            except (ValueError, json.JSONDecodeError) as exc:
                writer.write(_json_response(400, {"error": str(exc)}))
                await writer.drain()
                return
            try:
                result = await order_service.place_order(body)
                writer.write(_json_response(200, result))
            except order_service.OrderValidationError as exc:
                writer.write(_json_response(400, {"error": str(exc)}))

        elif method == "POST" and path == "/orders/cancel":
            from . import order_service

            try:
                body = await _read_json_body(reader, headers)
            except (ValueError, json.JSONDecodeError) as exc:
                writer.write(_json_response(400, {"error": str(exc)}))
                await writer.drain()
                return
            missing = _require_fields(body, ["internal_order_id"])
            if missing:
                writer.write(_json_response(400, {"error": missing}))
            else:
                try:
                    result = await order_service.cancel_order(
                        body["internal_order_id"], amo=body.get("amo", "NO")
                    )
                    writer.write(_json_response(200, result))
                except order_service.OrderValidationError as exc:
                    writer.write(_json_response(400, {"error": str(exc)}))

        elif method == "POST" and path == "/orders/modify":
            from . import order_service

            try:
                body = await _read_json_body(reader, headers)
            except (ValueError, json.JSONDecodeError) as exc:
                writer.write(_json_response(400, {"error": str(exc)}))
                await writer.drain()
                return
            missing = _require_fields(body, ["internal_order_id"])
            if missing:
                writer.write(_json_response(400, {"error": missing}))
            else:
                try:
                    result = await order_service.modify_order(body["internal_order_id"], body)
                    writer.write(_json_response(200, result))
                except order_service.OrderValidationError as exc:
                    writer.write(_json_response(400, {"error": str(exc)}))

        elif method == "GET" and path == "/order-history":
            from .broker_client import NotConfiguredError, _sanitize_sdk_response, response_is_error

            try:
                resp = await asyncio.get_running_loop().run_in_executor(None, broker_client.order_history)
            except NotConfiguredError as exc:
                writer.write(_json_response(409, {"error": str(exc)}))
                await writer.drain()
                return
            except Exception as exc:  # noqa: BLE001
                writer.write(_json_response(502, {"error": f"order_history call failed: {exc}"}))
                await writer.drain()
                return
            if isinstance(resp, dict) and response_is_error(resp):
                writer.write(_json_response(502, {"error": _sanitize_sdk_response(resp, context="order_history rejected")}))
            else:
                writer.write(_json_response(200, {"history": resp}))

        elif method == "GET" and path == "/trades":
            from .broker_client import NotConfiguredError, _sanitize_sdk_response, response_is_error

            try:
                resp = await asyncio.get_running_loop().run_in_executor(None, broker_client.trade_report)
            except NotConfiguredError as exc:
                writer.write(_json_response(409, {"error": str(exc)}))
                await writer.drain()
                return
            except Exception as exc:  # noqa: BLE001
                writer.write(_json_response(502, {"error": f"trade_report call failed: {exc}"}))
                await writer.drain()
                return
            if isinstance(resp, dict) and response_is_error(resp):
                writer.write(_json_response(502, {"error": _sanitize_sdk_response(resp, context="trade_report rejected")}))
            else:
                writer.write(_json_response(200, {"trades": resp}))

        elif method == "POST" and path == "/quotes":
            writer.write(await _handle_broker_passthrough(reader, headers, "quotes"))

        elif method == "POST" and path == "/scrip-search":
            writer.write(await _handle_broker_passthrough(reader, headers, "search_scrip"))

        elif method == "GET" and path == "/market-ticks":
            from . import db as _db

            limit = int(query.get("limit", ["200"])[0])
            writer.write(_json_response(200, {"ticks": _db.latest_market_ticks(limit=limit)}))

        elif method == "GET" and path == "/audit-logs":
            from . import db as _db

            limit = int(query.get("limit", ["200"])[0])
            writer.write(_json_response(200, {"logs": _db.list_audit_logs(limit=limit)}))

        elif method not in ("GET", "POST"):
            writer.write(_json_response(405, {"error": "Method not allowed"}))
        else:
            writer.write(_json_response(404, {"error": "Not found"}))

        await writer.drain()
    except (asyncio.TimeoutError, ConnectionError) as exc:
        logger.debug("Client connection dropped: %s", exc)
    except Exception as exc:  # noqa: BLE001 -- never crash the server loop on a bad request
        logger.warning("Unhandled error serving request: %s", exc)
        try:
            writer.write(_json_response(500, {"error": "Internal server error."}))
            await writer.drain()
        except Exception:  # noqa: BLE001
            pass
    finally:
        writer.close()


async def run_server() -> None:
    server = await asyncio.start_server(_handle_client, config.host, config.port)
    addr = server.sockets[0].getsockname() if server.sockets else (config.host, config.port)
    logger.info("Broker service HTTP interface listening on %s:%s", *addr[:2])
    async with server:
        await server.serve_forever()
