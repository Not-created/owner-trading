"""Entrypoint for the persistent Kotak broker service.

Run as: python -m app.main  (from broker-service/, inside its venv)
In production this is what deployment/systemd/owner-trading-broker.service
invokes.

This process is intended to run continuously (systemd Restart=on-failure),
never spawned per-request -- the whole point of a persistent service is
that WebSocket connections and the scrip-master cache stay warm across
requests from Express.
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import config
from .state import BrokerState, current_state
from .server import run_server
from . import broker_client as broker_client_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("owner_trading.main")

# BUGFIX (final audit): session.check_and_handle_expiry() and
# reconciliation.run_full_reconciliation() were both fully implemented but
# never invoked from anywhere -- dead code. Session expiry would never be
# detected until the next broker call happened to fail, and reconciliation
# never ran on any schedule (only once, right after a successful connect,
# per the fix in broker_client.py). This loop is what actually makes both
# real: it polls every SESSION_CHECK_INTERVAL_SECONDS while the service is
# up, regardless of connection state (check_and_handle_expiry() itself is a
# no-op unless state is CONNECTED), and re-reconciles on the slower
# RECONCILIATION_INTERVAL_SECONDS cadence whenever still CONNECTED.
SESSION_CHECK_INTERVAL_SECONDS = 60
RECONCILIATION_INTERVAL_SECONDS = 15 * 60


def _determine_initial_state() -> None:
    """Sets the correct starting state WITHOUT attempting to connect --
    startup never authenticates automatically, only GET /connect does (and
    only Express calling it on the owner's explicit action triggers that).

    If env-provided credentials are fully present (the persistent
    /etc/owner-trading/broker.env path), they're loaded into the same
    CredentialManager the Settings UI writes to -- otherwise a
    fully-configured broker.env would be silently unusable for /connect,
    since credential_manager (not config.py) is what connect() actually
    reads from.
    """
    from .credential_manager import credential_manager

    if not broker_client_module.SDK_AVAILABLE:
        current_state.transition(
            BrokerState.CONNECTION_ERROR,
            "kotakneoapi SDK is not installed in this environment.",
        )
        logger.warning("kotakneoapi is not importable -- broker service running in degraded mode.")
        return

    # BUGFIX (final audit): the SDK's exact version/source could not be
    # conclusively verified against external docs (see
    # sdk_conformance.py's module docstring for the full finding). Rather
    # than trust any single external source, verify the package actually
    # installed in THIS environment exposes every symbol this codebase
    # calls, every time the service starts. A mismatch here means
    # deployment must fail loud, not silently report NOT_CONFIGURED/
    # DISCONNECTED and let an owner discover the real problem only when a
    # LIVE order call throws AttributeError.
    from .sdk_conformance import check_sdk_conformance

    conformance = check_sdk_conformance()
    for warning in conformance.warnings:
        logger.warning("SDK conformance: %s", warning)
    if not conformance.ok:
        current_state.transition(BrokerState.CONNECTION_ERROR, conformance.summary())
        logger.error(conformance.summary())
        return
    logger.info(conformance.summary())

    if config.is_fully_configured():
        credential_manager.set(
            consumer_key=config.consumer_key,
            mobile_number=config.mobile_number,
            ucc=config.ucc,
            mpin=config.mpin,
            totp_secret=config.totp_secret,
        )
        current_state.transition(BrokerState.DISCONNECTED)
        logger.info("Kotak credentials loaded from environment. Broker state: DISCONNECTED (call /connect to authenticate).")
    else:
        current_state.transition(BrokerState.NOT_CONFIGURED)
        logger.info("Kotak credentials are not configured. Broker state: NOT_CONFIGURED.")


async def _background_maintenance_loop(stop_event: asyncio.Event) -> None:
    """Runs for the life of the process: periodic session-expiry detection
    (every SESSION_CHECK_INTERVAL_SECONDS) and periodic reconciliation
    (every RECONCILIATION_INTERVAL_SECONDS while CONNECTED). Never raises
    out of the loop -- a single failed check must not kill the whole
    service; it's logged and the loop continues on the next tick.
    """
    from . import session as _session
    from . import reconciliation as _reconciliation
    from . import websocket_manager as _websocket_manager

    elapsed_since_reconciliation = 0
    while not stop_event.is_set():
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=SESSION_CHECK_INTERVAL_SECONDS)
            break  # stop_event was set during the wait
        except asyncio.TimeoutError:
            pass  # normal tick

        try:
            was_expired = _session.check_and_handle_expiry()
            if was_expired:
                logger.warning("Broker session expired (TTL exceeded); state transitioned to SESSION_EXPIRED.")
                # A session expiry mid-stream means the WebSocket
                # connection (authenticated under that now-dead session)
                # is no longer trustworthy either -- stop it explicitly
                # rather than leaving it running against a session the
                # broker itself no longer considers valid.
                try:
                    await _websocket_manager.websocket_manager.stop()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to stop WebSocket after session expiry: %s", exc)
        except Exception as exc:  # noqa: BLE001 -- one bad tick must not stop future ticks
            logger.warning("Session-expiry check failed: %s", exc)

        # WebSocket staleness/health check -- independent of the
        # reconciliation cadence below, checked every tick since a stale
        # feed is worth reacting to quickly, not once every 15 minutes.
        #
        # NOTE: the SDK's own SFeedWebSocket/OrderFeedWebSocket already
        # reconnect+resubscribe internally on a detected disconnect (see
        # websocket_manager.py's module docstring, point 2) -- staleness
        # here means messages have stopped arriving WITHOUT the async
        # iterator raising anything (a degraded connection the SDK's own
        # logic hasn't noticed yet), so the reaction is a full outer
        # restart (stop -> start) of this manager, not a soft retry.
        if current_state.state == BrokerState.CONNECTED:
            try:
                if _websocket_manager.websocket_manager.is_stale():
                    logger.warning(
                        "WebSocket feed appears stale (no message in %ds) -- forcing a full restart.",
                        _websocket_manager.STALE_AFTER_SECONDS,
                    )

                    async def _restart():
                        await _websocket_manager.websocket_manager.stop()
                        await _websocket_manager.websocket_manager.start()
                        from . import reconciliation as _reconciliation

                        await _reconciliation.run_full_reconciliation()

                    asyncio.create_task(_restart())
            except Exception as exc:  # noqa: BLE001
                logger.warning("WebSocket staleness check failed: %s", exc)

        elapsed_since_reconciliation += SESSION_CHECK_INTERVAL_SECONDS
        if elapsed_since_reconciliation >= RECONCILIATION_INTERVAL_SECONDS:
            elapsed_since_reconciliation = 0
            if current_state.state == BrokerState.CONNECTED:
                try:
                    await _reconciliation.run_full_reconciliation()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Scheduled reconciliation failed: %s", exc)


async def _main() -> None:
    _determine_initial_state()

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_signal(sig_name: str) -> None:
        logger.info("Received %s, shutting down gracefully.", sig_name)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _handle_signal, sig.name)

    server_task = asyncio.create_task(run_server())
    maintenance_task = asyncio.create_task(_background_maintenance_loop(stop_event))

    await stop_event.wait()
    server_task.cancel()
    maintenance_task.cancel()
    for task in (server_task, maintenance_task):
        try:
            await task
        except asyncio.CancelledError:
            pass
    logger.info("Broker service stopped.")


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
