"""Order placement orchestration -- the layer between the HTTP route
(server.py) and BrokerClient.place_order()/cancel_order().

WHY THIS EXISTS AS ITS OWN MODULE: BrokerClient (broker_client.py) is
deliberately just a thin, generic wrapper around the real Kotak SDK calls
-- it has no PAPER-vs-LIVE branching logic. Per this phase's explicit
safety requirement ("PAPER must NEVER call real Kotak order APIs"), that
branching needs to happen BEFORE any broker call is even attempted, not
be trusted to a flag the broker client checks internally. This module is
that branch point, and it is the only place in the codebase that decides
whether an order request becomes a local-only simulation or a real
network call to Kotak.

HONEST LIMITATION, stated up front rather than hidden: place_order()'s
exact Kotak-side parameter names (is it trading_symbol or tradingsymbol?
transaction_type or a numeric code? quantity or qty?) could not be
independently verified against the official Kotak Neo repository during
this project's audits (see broker-service/requirements.txt's version-
history note and app/sdk_conformance.py's docstring for the full finding
-- the canonical source repo returns 404 on direct fetch). Rather than
guess a plausible-looking parameter mapping, this module requires the
caller to supply the exact broker-side parameter dict explicitly
(`broker_params` in the request body) for any LIVE order -- see
place_order()'s docstring below. PAPER orders need no such mapping since
they never reach the SDK at all.
"""
from __future__ import annotations

import logging
import uuid

from . import db as _db
from .broker_client import broker_client, LiveTradingBlockedError, NotConfiguredError
from .config import config

logger = logging.getLogger("owner_trading.order_service")

VALID_TRANSACTION_TYPES = {"B", "S"}
VALID_ORDER_TYPES = {"L", "MKT", "SL", "SL-M"}
VALID_PRODUCTS = {"CNC", "NRML", "MIS", "MTF"}
VALID_VALIDITY = {"DAY", "IOC"}


class OrderValidationError(ValueError):
    """A malformed order request -- caught by server.py and reported as a
    400, never silently coerced into something 'close enough'."""


def _validate(payload: dict) -> dict:
    trading_symbol = (payload.get("trading_symbol") or "").strip()
    if not trading_symbol:
        raise OrderValidationError("trading_symbol is required.")

    transaction_type = (payload.get("transaction_type") or "").strip().upper()
    if transaction_type not in VALID_TRANSACTION_TYPES:
        raise OrderValidationError(f"transaction_type must be one of {sorted(VALID_TRANSACTION_TYPES)}.")

    order_type = (payload.get("order_type") or "").strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise OrderValidationError(f"order_type must be one of {sorted(VALID_ORDER_TYPES)}.")

    product = (payload.get("product") or "").strip().upper()
    if product not in VALID_PRODUCTS:
        raise OrderValidationError(f"product must be one of {sorted(VALID_PRODUCTS)}.")

    validity = (payload.get("validity") or "DAY").strip().upper()
    if validity not in VALID_VALIDITY:
        raise OrderValidationError(f"validity must be one of {sorted(VALID_VALIDITY)}.")

    try:
        quantity = int(payload.get("quantity"))
    except (TypeError, ValueError):
        raise OrderValidationError("quantity must be a positive integer.")
    if quantity <= 0:
        raise OrderValidationError("quantity must be a positive integer.")

    price = payload.get("price")
    if order_type in ("L", "SL") and (price is None or float(price) <= 0):
        raise OrderValidationError(f"price is required and must be > 0 for order_type={order_type}.")
    price = float(price) if price is not None else None

    trigger_price = payload.get("trigger_price")
    if order_type in ("SL", "SL-M") and (trigger_price is None or float(trigger_price) <= 0):
        raise OrderValidationError(f"trigger_price is required and must be > 0 for order_type={order_type}.")
    trigger_price = float(trigger_price) if trigger_price is not None else None

    return {
        "trading_symbol": trading_symbol,
        "exchange_segment": (payload.get("exchange_segment") or "").strip() or None,
        "transaction_type": transaction_type,
        "order_type": order_type,
        "product": product,
        "validity": validity,
        "quantity": quantity,
        "price": price,
        "trigger_price": trigger_price,
    }


async def place_order(payload: dict) -> dict:
    """Validates, persists locally, and either simulates (PAPER) or places
    a real order (LIVE) -- in that order, so every request has a durable
    local record before anything irreversible (a real broker call) is
    attempted.
    """
    order = _validate(payload)
    internal_order_id = str(uuid.uuid4())
    mode = config.trading_mode  # "PAPER" or "LIVE" -- read once, used consistently for this whole request

    if mode == "LIVE":
        initial_status = "SUBMITTING"
    else:
        initial_status = "PAPER_ACCEPTED"

    _db.create_order(
        internal_order_id=internal_order_id,
        mode=mode,
        status=initial_status,
        **order,
    )
    _write_audit(action="order.create", internal_order_id=internal_order_id, mode=mode, order=order)

    if mode != "LIVE":
        # PAPER: per this phase's explicit safety rule, this branch NEVER
        # calls broker_client / NeoAPI, not even read-only. It also does
        # NOT simulate a matching engine or a fill price -- inventing an
        # execution price would be fabricated broker data. The order is
        # simply recorded as accepted; a fills/matching simulator is
        # future work, tracked honestly as not implemented, not faked.
        return _db.get_order(internal_order_id)

    # ---- LIVE from here on ---- #
    broker_params = payload.get("broker_params")
    if not isinstance(broker_params, dict) or not broker_params:
        # See module docstring: place_order()'s exact Kotak-side parameter
        # names could not be independently verified, so this module
        # refuses to guess a mapping. The order row above already exists
        # (status SUBMITTING) as an audit trail of the attempt.
        reason = (
            "LIVE order requires an explicit 'broker_params' object in the request body with the exact "
            "parameter names the installed Kotak SDK's place_order() expects -- this codebase could not "
            "independently verify that signature against the official repository (see "
            "broker-service/requirements.txt's version-history note) and will not guess it for a real order."
        )
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.rejected", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    try:
        import asyncio

        resp = await asyncio.get_running_loop().run_in_executor(
            None, lambda: broker_client.place_order(**broker_params)
        )
    except LiveTradingBlockedError as exc:
        reason = str(exc)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.blocked", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)
    except NotConfiguredError as exc:
        reason = str(exc)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.rejected", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)
    except Exception as exc:  # noqa: BLE001 -- any transport/SDK failure is a rejection, not a crash
        reason = f"place_order call failed: {exc}"
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.error", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    broker_order_id = None
    if isinstance(resp, dict):
        # BEST-EFFORT, UNVERIFIED extraction: place_order()'s real response
        # shape/field name for the broker's order id could not be
        # independently confirmed either (same limitation as the request
        # parameters -- see module docstring). Every plausible key seen
        # across various Kotak SDK generations is tried; if none matches,
        # broker_order_id stays None (this order can still be found later
        # via reconciliation.py's order_report() diff, which is the
        # authoritative source regardless of what this extraction finds).
        for key in ("nOrdNo", "order_id", "orderId", "orderNo", "nOrdNoId"):
            if resp.get(key):
                broker_order_id = str(resp[key])
                break
        if broker_order_id is None:
            logger.warning(
                "place_order response did not match any known broker-order-id field name -- "
                "order %s was likely submitted but its broker_order_id could not be extracted. "
                "It will still surface via the next order_report() reconciliation pass.",
                internal_order_id,
            )

    if isinstance(resp, dict) and any(k in resp for k in ("error", "errMsg", "errCode")) and not broker_order_id:
        reason = _sanitize(resp)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.rejected", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    _db.update_order(internal_order_id=internal_order_id, status="SUBMITTED", broker_order_id=broker_order_id)
    _db.record_order_event(
        event_source="place_order_response",
        broker_event_id=broker_order_id,
        raw_payload=resp if isinstance(resp, dict) else {"raw": str(resp)},
        broker_order_id=broker_order_id,
    )
    _write_audit(action="order.submitted", internal_order_id=internal_order_id, mode=mode, broker_order_id=broker_order_id)
    return _db.get_order(internal_order_id)


def _sanitize(resp: dict) -> str:
    for key in ("message", "errMsg", "error", "error_description"):
        val = resp.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()[:300]
    code = resp.get("errCode") or resp.get("code")
    return f"broker rejected the request (code {code})." if code else "broker rejected the request."


def _write_audit(*, action: str, **details) -> None:
    try:
        _db.write_audit_log(actor="owner", action=action, details=details)
    except Exception as exc:  # noqa: BLE001 -- an audit-log write failure must never block the order flow itself
        logger.warning("Failed to write audit log for %s: %s", action, exc)


async def cancel_order(internal_order_id: str, broker_params: dict | None = None) -> dict:
    """Cancels a local order. PAPER: local-only, no broker call. LIVE:
    requires the order to have a broker_order_id (i.e. it was actually
    submitted) and goes through the same safety gate as placement.

    Same honest limitation as place_order() (see module docstring):
    cancel_order()'s exact Kotak-side parameter name/shape could not be
    independently verified either. If the caller supplies `broker_params`,
    it's forwarded as-is (**broker_params). Otherwise this falls back to a
    single positional call with just the broker order id -- a reasonable
    default for a cancel operation, but still NOT independently confirmed
    against the official SDK signature, and callers who know the real
    signature should pass broker_params explicitly.
    """
    order = _db.get_order(internal_order_id)
    if order is None:
        raise OrderValidationError(f"No order found with internal_order_id={internal_order_id}.")

    if order["mode"] != "LIVE":
        _db.update_order(internal_order_id=internal_order_id, status="CANCELLED", status_reason="Cancelled by owner (PAPER).")
        _write_audit(action="order.cancelled", internal_order_id=internal_order_id, mode=order["mode"])
        return _db.get_order(internal_order_id)

    if not order.get("broker_order_id"):
        raise OrderValidationError("This LIVE order was never accepted by the broker (no broker_order_id) -- nothing to cancel there.")

    try:
        import asyncio

        if broker_params:
            resp = await asyncio.get_running_loop().run_in_executor(
                None, lambda: broker_client.cancel_order(**broker_params)
            )
        else:
            resp = await asyncio.get_running_loop().run_in_executor(
                None, lambda: broker_client.cancel_order(order["broker_order_id"])
            )
    except LiveTradingBlockedError as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        raise OrderValidationError(f"cancel_order call failed: {exc}")

    if isinstance(resp, dict) and any(k in resp for k in ("error", "errMsg", "errCode")):
        reason = _sanitize(resp)
        _write_audit(action="order.cancel_rejected", internal_order_id=internal_order_id, reason=reason)
        raise OrderValidationError(reason)

    _db.update_order(internal_order_id=internal_order_id, status="CANCEL_REQUESTED")
    _write_audit(action="order.cancel_requested", internal_order_id=internal_order_id)
    return _db.get_order(internal_order_id)
