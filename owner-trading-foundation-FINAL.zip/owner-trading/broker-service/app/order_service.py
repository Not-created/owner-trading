"""Order placement orchestration -- the layer between the HTTP route
(server.py) and BrokerClient.place_order()/cancel_order().

WHY THIS EXISTS AS ITS OWN MODULE: BrokerClient (broker_client.py) is
deliberately just a thin, generic wrapper around the real Kotak SDK calls
-- it has no PAPER-vs-LIVE branching logic. Per this phase's explicit
safety requirement ("PAPER must NEVER call real Kotak order APIs"), that
branching needs to happen BEFORE any broker call is even attempted, not
be trusted to a flag the broker client checks internally. This module is
that branch point, and it is the only place in the codebase that decides
whether an order request becomes a local-only simulation or a real
network call to Kotak.

UPDATED: place_order()/modify_order()/cancel_order() now call the real,
source-verified kotakneoapi 3.0.7 signatures directly (confirmed by
reading neo_api_client/neo_api.py from the official SDK source directly --
see requirements.txt for the full provenance note). There is no more
caller-supplied "broker_params" workaround for these three calls -- the
exact parameter names, types (price/quantity/trigger_price are STRINGS),
and defaults are built from the order's own validated fields. The one
place a caller-supplied parameter dict is still used is quotes()/
search_scrip() (see server.py's /quotes and /scrip-search routes), which
remain a direct kwargs passthrough since their parameters vary by use case
(which instruments, which fields) rather than a single order-shaped call.
"""
from __future__ import annotations

import logging
import uuid

from . import db as _db
from .broker_client import broker_client, LiveTradingBlockedError, NotConfiguredError, response_is_error
from .config import config

logger = logging.getLogger("owner_trading.order_service")

# Confirmed directly against kotakneoapi 3.0.7's real source
# (neo_api_client/settings.py + req_data_validation.py) -- these are the
# EXACT canonical values place_order()/modify_order() accept; aliases
# (e.g. "NSE", "Limit", "Market", "Normal") are rejected by the SDK
# itself, not resolved, so this module validates against the same
# canonical set rather than a looser guess.
VALID_TRANSACTION_TYPES = {"B", "S"}
VALID_ORDER_TYPES = {"L", "MKT", "SL", "SL-M"}
VALID_PRODUCTS = {"CNC", "NRML", "MIS", "MTF"}
VALID_VALIDITY = {"DAY", "IOC"}
VALID_EXCHANGE_SEGMENTS = {"nse_cm", "bse_cm", "nse_fo", "bse_fo", "mcx_fo"}


class OrderValidationError(ValueError):
    """A malformed order request -- caught by server.py and reported as a
    400, never silently coerced into something 'close enough'."""


class RiskLimitExceededError(ValueError):
    """A well-formed order that violates a configured pre-trade risk limit
    -- distinct from OrderValidationError so callers/tests can tell 'bad
    request shape' from 'rejected by risk policy', though both currently
    surface as 400s at the HTTP layer."""


def _check_risk_limits(order: dict, mode: str) -> None:
    """Pre-trade risk checks (Phase: risk management, requirements #65-68).

    HONEST SCOPE: these are global limits only -- max quantity per order
    and max orders per day, both operator-configured via MAX_ORDER_QUANTITY
    / MAX_ORDERS_PER_DAY (0/unset = no limit), plus a funds/margin check
    for LIVE limit orders where a price is known. There is no per-strategy
    exposure/risk engine here -- building one honestly needs a strategy
    risk-limit schema and a position-exposure model that do not exist yet
    in this codebase, so it is not faked with a check that looks
    comprehensive but isn't. Applied identically to PAPER and LIVE (a
    PAPER order that would blow through your real risk limits is still
    worth catching before it becomes a habit).
    """
    if config.max_order_quantity and order["quantity"] > config.max_order_quantity:
        raise RiskLimitExceededError(
            f"Order quantity {order['quantity']} exceeds the configured MAX_ORDER_QUANTITY ({config.max_order_quantity})."
        )

    if config.max_orders_per_day:
        placed_today = _db.count_orders_today()
        if placed_today >= config.max_orders_per_day:
            raise RiskLimitExceededError(
                f"Daily order limit reached ({placed_today}/{config.max_orders_per_day} orders already placed today)."
            )

    if mode == "LIVE" and order.get("price"):
        funds = _db.latest_funds_snapshot()
        if funds and funds.get("available_margin") is not None:
            order_value = order["price"] * order["quantity"]
            if order_value > funds["available_margin"]:
                raise RiskLimitExceededError(
                    f"Order value {order_value:.2f} exceeds available margin {funds['available_margin']:.2f} "
                    f"(as of the last funds snapshot -- {funds.get('snapshot_at', 'unknown time')})."
                )
        # No funds snapshot yet (never connected/reconciled) -- deliberately
        # does NOT block the order on missing data; assert_live_trading_allowed()
        # (broker_client.py) already requires CONNECTED, and a connect always
        # runs one reconciliation pass first (see broker_client.connect()), so
        # a LIVE order reaching this point should already have a snapshot in
        # all real operating conditions. Silently passing here only matters
        # for the theoretical edge case, not the normal path.


def _validate(payload: dict) -> dict:
    trading_symbol = (payload.get("trading_symbol") or "").strip()
    if not trading_symbol:
        raise OrderValidationError("trading_symbol is required.")

    # exchange_segment is MANDATORY per the real place_order() signature
    # (confirmed: neo_api.py's place_order_validation() rejects a blank
    # value before any network call) -- an earlier version of this
    # module treated it as optional, which would have made every real
    # order attempt fail validation on the SDK side.
    exchange_segment = (payload.get("exchange_segment") or "").strip().lower()
    if exchange_segment not in VALID_EXCHANGE_SEGMENTS:
        raise OrderValidationError(f"exchange_segment is required and must be one of {sorted(VALID_EXCHANGE_SEGMENTS)}.")

    transaction_type = (payload.get("transaction_type") or "").strip().upper()
    if transaction_type not in VALID_TRANSACTION_TYPES:
        raise OrderValidationError(f"transaction_type must be one of {sorted(VALID_TRANSACTION_TYPES)}.")

    order_type = (payload.get("order_type") or "").strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise OrderValidationError(f"order_type must be one of {sorted(VALID_ORDER_TYPES)}.")

    product = (payload.get("product") or "").strip().upper()
    if product not in VALID_PRODUCTS:
        raise OrderValidationError(f"product must be one of {sorted(VALID_PRODUCTS)}.")

    # Allowed validity values are per-exchange-segment on the real SDK
    # (mcx_fo only accepts "DAY"; every other segment accepts "DAY"/"IOC")
    # -- confirmed from settings.py's validity_allowed_by_segment.
    validity = (payload.get("validity") or "DAY").strip().upper()
    segment_validity = {"mcx_fo": {"DAY"}}.get(exchange_segment, VALID_VALIDITY)
    if validity not in segment_validity:
        raise OrderValidationError(f"validity must be one of {sorted(segment_validity)} for exchange_segment={exchange_segment}.")

    try:
        quantity = int(payload.get("quantity"))
    except (TypeError, ValueError):
        raise OrderValidationError("quantity must be a positive integer.")
    if quantity <= 0:
        raise OrderValidationError("quantity must be a positive integer.")

    # price=0 is valid for MKT/SL-M (executes at market); L/SL need a real
    # positive limit price -- confirmed from
    # req_data_validation.py's price_required_order_types = ["L", "SL"].
    price = payload.get("price")
    if order_type in ("L", "SL") and (price is None or float(price) <= 0):
        raise OrderValidationError(f"price is required and must be > 0 for order_type={order_type}.")
    price = float(price) if price is not None else 0.0

    trigger_price = payload.get("trigger_price")
    if order_type in ("SL", "SL-M") and (trigger_price is None or float(trigger_price) <= 0):
        raise OrderValidationError(f"trigger_price is required and must be > 0 for order_type={order_type}.")
    trigger_price = float(trigger_price) if trigger_price is not None else 0.0

    return {
        "trading_symbol": trading_symbol,
        "exchange_segment": exchange_segment,
        "transaction_type": transaction_type,
        "order_type": order_type,
        "product": product,
        "validity": validity,
        "quantity": quantity,
        "price": price,
        "trigger_price": trigger_price,
    }


async def place_order(payload: dict) -> dict:
    """Validates, persists locally, and either simulates (PAPER) or places
    a real order (LIVE) -- in that order, so every request has a durable
    local record before anything irreversible (a real broker call) is
    attempted.

    IDEMPOTENCY (requirement #55): if the caller supplies `idempotency_key`
    (any string the client generates once per logical order attempt -- a
    good default is a UUID generated client-side before the first network
    call), a replayed request with the SAME key returns the ALREADY-
    EXISTING order instead of creating a second one. This is what protects
    against the real failure mode: a frontend request that times out
    client-side after the server already accepted it, and the user (or an
    auto-retry) submits again. Without a key, every call creates a new
    order, unchanged from before -- this is opt-in, not a behavior change
    for existing callers.
    """
    idempotency_key = payload.get("idempotency_key")
    if idempotency_key:
        idempotency_key = str(idempotency_key).strip()[:200]
        existing = _db.get_order(idempotency_key)
        if existing is not None:
            logger.info("place_order idempotent replay for %s -- returning the existing order, not creating a new one.", idempotency_key)
            return existing

    order = _validate(payload)
    mode = config.trading_mode  # "PAPER" or "LIVE" -- read once, used consistently for this whole request

    try:
        _check_risk_limits(order, mode)
    except RiskLimitExceededError as exc:
        _write_audit(action="order.risk_blocked", mode=mode, order=order, reason=str(exc))
        raise OrderValidationError(str(exc))

    internal_order_id = idempotency_key or str(uuid.uuid4())

    if mode == "LIVE":
        initial_status = "SUBMITTING"
    else:
        initial_status = "PAPER_ACCEPTED"

    _db.create_order(
        internal_order_id=internal_order_id,
        mode=mode,
        status=initial_status,
        **order,
    )
    _write_audit(action="order.create", internal_order_id=internal_order_id, mode=mode, order=order)

    if mode != "LIVE":
        # PAPER: per this phase's explicit safety rule, this branch NEVER
        # calls broker_client / NeoAPI, not even read-only. It also does
        # NOT simulate a matching engine or a fill price -- inventing an
        # execution price would be fabricated broker data. The order is
        # simply recorded as accepted; a fills/matching simulator is
        # future work, tracked honestly as not implemented, not faked.
        return _db.get_order(internal_order_id)

    # ---- LIVE from here on ----
    # Real, source-verified call (kotakneoapi 3.0.7's neo_api.py,
    # read directly) -- no more "supply broker_params yourself" workaround.
    # Two things confirmed from source and applied here:
    #   - price/quantity/trigger_price must be STRINGS, not numbers.
    #   - tag is an optional caller-defined marker echoed back as "GuiOrdId"
    #     in order_report()/trade_report() -- our own internal_order_id is
    #     passed here (truncated defensively; the real max length wasn't
    #     specified in the source) so a later order_report() row can be
    #     traced back to this local order even before broker_order_id is
    #     known.
    try:
        import asyncio

        resp = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: broker_client.place_order(
                exchange_segment=order["exchange_segment"],
                product=order["product"],
                price=str(order["price"]),
                order_type=order["order_type"],
                quantity=str(order["quantity"]),
                validity=order["validity"],
                trading_symbol=order["trading_symbol"],
                transaction_type=order["transaction_type"],
                trigger_price=str(order["trigger_price"]),
                tag=internal_order_id[:20],
            ),
        )
    except LiveTradingBlockedError as exc:
        reason = str(exc)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.blocked", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)
    except NotConfiguredError as exc:
        reason = str(exc)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.rejected", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)
    except Exception as exc:  # noqa: BLE001 -- any transport/SDK failure is a rejection, not a crash
        reason = f"place_order call failed: {exc}"
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.error", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    broker_order_id = None
    if isinstance(resp, dict):
        # BEST-EFFORT extraction, but no longer a blind guess: source
        # inspection of kotakneoapi 3.0.7 confirms OrderAPI.order_placing()
        # returns the raw backend JSON response as-is (no SDK-level
        # Pydantic model for it), so its exact success-response field name
        # for the order id is genuinely not defined by the SDK itself --
        # HOWEVER, the order-FEED's OrderData model (also confirmed from
        # source) aliases order_id to exactly "nOrdNo", which is Kotak's
        # own backend field-naming convention showing through -- a
        # well-motivated primary guess, not an arbitrary one, with the
        # remaining keys kept as defensive fallbacks. If none match,
        # broker_order_id stays None (this order can still be found later
        # via reconciliation.py's order_report() diff, which is the
        # authoritative source regardless of what this extraction finds).
        for key in ("nOrdNo", "order_id", "orderId", "orderNo", "nOrdNoId"):
            if resp.get(key):
                broker_order_id = str(resp[key])
                break
        if broker_order_id is None:
            logger.warning(
                "place_order response did not match any known broker-order-id field name -- "
                "order %s was likely submitted but its broker_order_id could not be extracted. "
                "It will still surface via the next order_report() reconciliation pass.",
                internal_order_id,
            )

    if isinstance(resp, dict) and response_is_error(resp) and not broker_order_id:
        reason = _sanitize(resp)
        _db.update_order(internal_order_id=internal_order_id, status="REJECTED", status_reason=reason)
        _write_audit(action="order.rejected", internal_order_id=internal_order_id, mode=mode, reason=reason)
        return _db.get_order(internal_order_id)

    _db.update_order(internal_order_id=internal_order_id, status="SUBMITTED", broker_order_id=broker_order_id)
    _db.record_order_event(
        event_source="place_order_response",
        broker_event_id=broker_order_id,
        raw_payload=resp if isinstance(resp, dict) else {"raw": str(resp)},
        broker_order_id=broker_order_id,
    )
    _write_audit(action="order.submitted", internal_order_id=internal_order_id, mode=mode, broker_order_id=broker_order_id)
    return _db.get_order(internal_order_id)


def _sanitize(resp: dict) -> str:
    """Delegates to broker_client's shared, source-verified error-message
    extraction (see response_is_error()'s docstring for the two real
    error shapes) rather than keeping a second, separately-guessed
    extraction here."""
    from .broker_client import _sanitize_sdk_response

    full = _sanitize_sdk_response(resp, context="_order_service")
    return full.split(": ", 1)[1] if ": " in full else full


def _write_audit(*, action: str, **details) -> None:
    try:
        _db.write_audit_log(actor="owner", action=action, details=details)
    except Exception as exc:  # noqa: BLE001 -- an audit-log write failure must never block the order flow itself
        logger.warning("Failed to write audit log for %s: %s", action, exc)


async def modify_order(internal_order_id: str, payload: dict) -> dict:
    """Modifies a local order's quantity/price/trigger_price.

    PAPER: pure local update -- never calls broker_client, same guarantee
    as place_order()/cancel_order().

    LIVE: requires the order to have a broker_order_id (i.e. was actually
    submitted), goes through the same LIVE safety gate as placement
    (assert_live_trading_allowed(), enforced inside broker_client.py), and
    calls the real, source-verified modify_order(order_id, price,
    order_type, quantity, validity, trigger_price, ...) directly.
    order_type/validity are NOT optional on the real signature -- when the
    caller's payload doesn't change them, this fills them in from the
    order's own current stored values rather than requiring the caller to
    repeat everything on every modify.
    """
    order = _db.get_order(internal_order_id)
    if order is None:
        raise OrderValidationError(f"No order found with internal_order_id={internal_order_id}.")
    if order["status"] in ("CANCELLED", "REJECTED", "COMPLETE"):
        raise OrderValidationError(f"Order {internal_order_id} is already {order['status']} and cannot be modified.")

    new_quantity = payload.get("quantity")
    new_price = payload.get("price")
    new_trigger_price = payload.get("trigger_price")
    if new_quantity is not None:
        try:
            new_quantity = int(new_quantity)
        except (TypeError, ValueError):
            raise OrderValidationError("quantity must be an integer.")
        if new_quantity <= 0:
            raise OrderValidationError("quantity must be a positive integer.")
    if new_price is not None:
        new_price = float(new_price)
    if new_trigger_price is not None:
        new_trigger_price = float(new_trigger_price)

    if order["mode"] != "LIVE":
        _db.update_order(
            internal_order_id=internal_order_id, status="MODIFIED",
            status_reason="Modified by owner (PAPER).",
        )
        if new_quantity is not None or new_price is not None or new_trigger_price is not None:
            _db.update_order_fields(
                internal_order_id=internal_order_id,
                quantity=new_quantity, price=new_price, trigger_price=new_trigger_price,
            )
        _write_audit(
            action="order.modified", internal_order_id=internal_order_id, mode=order["mode"],
            quantity=new_quantity, price=new_price, trigger_price=new_trigger_price,
        )
        return _db.get_order(internal_order_id)

    if not order.get("broker_order_id"):
        raise OrderValidationError("This LIVE order was never accepted by the broker (no broker_order_id) -- nothing to modify there.")

    # modify_order()'s real signature requires order_type/validity/price/
    # quantity/trigger_price ALL on every call (confirmed from source) --
    # not just the fields actually changing. Anything the caller's payload
    # didn't touch is filled in from the order's own current stored values.
    effective_quantity = new_quantity if new_quantity is not None else order["quantity"]
    effective_price = new_price if new_price is not None else order["price"]
    effective_trigger_price = new_trigger_price if new_trigger_price is not None else order["trigger_price"]

    try:
        import asyncio

        resp = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: broker_client.modify_order(
                order_id=order["broker_order_id"],
                price=str(effective_price or 0),
                order_type=order["order_type"],
                quantity=str(effective_quantity),
                validity=order["validity"],
                trigger_price=str(effective_trigger_price or 0),
            ),
        )
    except LiveTradingBlockedError as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        raise OrderValidationError(f"modify_order call failed: {exc}")

    if isinstance(resp, dict) and response_is_error(resp):
        reason = _sanitize(resp)
        _write_audit(action="order.modify_rejected", internal_order_id=internal_order_id, reason=reason)
        raise OrderValidationError(reason)

    _db.update_order(internal_order_id=internal_order_id, status="MODIFY_REQUESTED")
    if new_quantity is not None or new_price is not None or new_trigger_price is not None:
        _db.update_order_fields(
            internal_order_id=internal_order_id,
            quantity=new_quantity, price=new_price, trigger_price=new_trigger_price,
        )
    _db.record_order_event(
        event_source="modify_order_response", broker_event_id=order["broker_order_id"],
        raw_payload=resp if isinstance(resp, dict) else {"raw": str(resp)},
        broker_order_id=order["broker_order_id"],
    )
    _write_audit(action="order.modify_requested", internal_order_id=internal_order_id)
    return _db.get_order(internal_order_id)


async def cancel_order(internal_order_id: str, amo: str = "NO") -> dict:
    """Cancels a local order. PAPER: local-only, no broker call. LIVE:
    requires the order to have a broker_order_id (i.e. it was actually
    submitted) and goes through the same safety gate as placement.

    Calls the real, source-verified cancel_order(order_id, amo, isVerify)
    directly -- `amo` defaults to "NO" (regular order); pass "YES" only
    when cancelling an after-market order. `isVerify` is not exposed here
    since the real SDK documents it as having no effect (kept for
    backward compatibility on Kotak's side).
    """
    order = _db.get_order(internal_order_id)
    if order is None:
        raise OrderValidationError(f"No order found with internal_order_id={internal_order_id}.")

    if order["mode"] != "LIVE":
        _db.update_order(internal_order_id=internal_order_id, status="CANCELLED", status_reason="Cancelled by owner (PAPER).")
        _write_audit(action="order.cancelled", internal_order_id=internal_order_id, mode=order["mode"])
        return _db.get_order(internal_order_id)

    if not order.get("broker_order_id"):
        raise OrderValidationError("This LIVE order was never accepted by the broker (no broker_order_id) -- nothing to cancel there.")

    try:
        import asyncio

        resp = await asyncio.get_running_loop().run_in_executor(
            None, lambda: broker_client.cancel_order(order_id=order["broker_order_id"], amo=amo)
        )
    except LiveTradingBlockedError as exc:
        raise OrderValidationError(str(exc))
    except Exception as exc:  # noqa: BLE001
        raise OrderValidationError(f"cancel_order call failed: {exc}")

    if isinstance(resp, dict) and response_is_error(resp):
        reason = _sanitize(resp)
        _write_audit(action="order.cancel_rejected", internal_order_id=internal_order_id, reason=reason)
        raise OrderValidationError(reason)

    _db.update_order(internal_order_id=internal_order_id, status="CANCEL_REQUESTED")
    _write_audit(action="order.cancel_requested", internal_order_id=internal_order_id)
    return _db.get_order(internal_order_id)
