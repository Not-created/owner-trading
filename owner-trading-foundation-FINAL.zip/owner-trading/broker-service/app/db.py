"""Shared-database writer for the broker service.

The Node backend OWNS the SQLite schema (see
backend/src/db/migrations/001_init.sql) and runs all migrations -- this
module only ever INSERTs into tables that already exist, using the same
file (DB_PATH env var, matching backend/src/config/index.js's default of
backend/data/owner-trading.db). SQLite's WAL mode (enabled by the Node side
in db/client.js) safely supports this: one writer at a time, with SQLite
handling the locking -- both processes retry-on-busy rather than corrupt
data.

Every insert here is written to be idempotent against the UNIQUE
constraints already in the schema (order_events.(event_source,
broker_event_id), trades.broker_trade_id) using INSERT OR IGNORE, so a
duplicated WebSocket message or a retried REST reconciliation can never
double-record the same event -- this is the "duplicate-event protection /
idempotency" requirement implemented concretely, not just described.

Order/position/holding/funds persistence and audit logging (Phase 1C) are
called from order_service.py, reconciliation.py, and server.py's new
routes -- see those modules for how each function here is actually used.
"""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "data", "owner-trading.db"
)
DB_PATH = os.environ.get("DB_PATH", DEFAULT_DB_PATH)


@contextmanager
def _connection():
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def record_order_event(
    *,
    event_source: str,
    broker_event_id: str | None,
    raw_payload: dict,
    order_id: int | None = None,
    broker_order_id: str | None = None,
) -> bool:
    """Idempotent insert into order_events. Returns True if a new row was
    written, False if this exact (event_source, broker_event_id) was
    already recorded (duplicate, correctly ignored).
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO order_events
               (order_id, broker_order_id, event_source, broker_event_id, raw_payload)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, event_source, broker_event_id, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def record_trade(
    *,
    broker_trade_id: str,
    order_id: int | None,
    broker_order_id: str | None,
    fill_quantity: int,
    fill_price: float,
    fill_time: str | None,
    raw_payload: dict,
) -> bool:
    """Idempotent insert into trades, keyed on broker_trade_id -- handles
    partial/multiple fills correctly since each fill has its own unique
    broker_trade_id; re-delivery of the same fill event is a no-op.
    """
    with _connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO trades
               (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, raw_payload)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (order_id, broker_order_id, broker_trade_id, fill_quantity, fill_price, fill_time, json.dumps(raw_payload)),
        )
        return cur.rowcount == 1


def is_emergency_stop_active() -> bool:
    """Reads the shared emergency_stop_state singleton row (owned/migrated
    by the Node backend). Read-only from this side -- only the Express API
    is meant to toggle it (next phase: an explicit owner-triggered action).
    """
    with _connection() as conn:
        row = conn.execute("SELECT is_active FROM emergency_stop_state WHERE id = 1").fetchone()
        return bool(row and row[0] == 1)


# BUGFIX (final audit): broker_sessions (001_init.sql) was defined in the
# schema but never referenced by any code anywhere -- pure dead schema.
# Rather than delete a table that's a genuinely useful audit trail (when
# was each session established/revoked, from which data center), this
# wires it up: session.py calls these two functions on every
# established/ended transition, so broker_sessions becomes a real,
# queryable history instead of an always-empty table.
def record_session_started(*, data_center: str | None, expires_at_iso: str | None) -> None:
    with _connection() as conn:
        account = conn.execute("SELECT id FROM broker_accounts ORDER BY id ASC LIMIT 1").fetchone()
        if account is None:
            # No account row exists yet (Settings UI hasn't saved account
            # metadata) -- session history has nowhere to attach; skip
            # rather than violate the NOT NULL broker_account_id FK.
            return
        conn.execute(
            """INSERT INTO broker_sessions (broker_account_id, session_ref, data_center, established_at, expires_at)
               VALUES (?, ?, ?, datetime('now'), ?)""",
            (account[0], None, data_center, expires_at_iso),
        )


def record_session_ended() -> None:
    """Marks the most recent still-open (revoked_at IS NULL) session row as
    revoked now. Idempotent: a second call with nothing open is a no-op."""
    with _connection() as conn:
        conn.execute(
            """UPDATE broker_sessions SET revoked_at = datetime('now')
               WHERE id = (SELECT id FROM broker_sessions WHERE revoked_at IS NULL ORDER BY id DESC LIMIT 1)"""
        )


def record_reconciliation(
    *, reconciliation_type: str, reference_id: str | None, discrepancy_found: bool, details: dict | None
) -> None:
    """Always inserts (not idempotent by design -- every reconciliation
    pass is its own audit record, even if the result matches the last one).
    """
    with _connection() as conn:
        conn.execute(
            """INSERT INTO reconciliation_records
               (reconciliation_type, reference_id, discrepancy_found, details)
               VALUES (?, ?, ?, ?)""",
            (reconciliation_type, reference_id, 1 if discrepancy_found else 0, json.dumps(details) if details else None),
        )


# ==================================================================== #
# Phase 1C: order/position/holding/funds persistence + audit logging.
# Everything below writes into tables the Node backend already migrated
# (001_init.sql) -- see that file for column definitions. Nothing here
# invents a schema; it only starts actually using what was already there.
# ==================================================================== #


def write_audit_log(*, actor: str, action: str, details: dict | None = None) -> None:
    """Appends to audit_logs. Never raises into the caller's control flow
    for anything except a genuinely broken DB -- an audit-log write failing
    must not itself block a real order/connection action, but every
    call site should still know a total DB outage is a serious problem,
    so this deliberately does NOT swallow exceptions; callers that must
    not fail on audit-log trouble wrap this themselves (see order_service.py).
    """
    with _connection() as conn:
        conn.execute(
            "INSERT INTO audit_logs (actor, action, details) VALUES (?, ?, ?)",
            (actor, action, json.dumps(details) if details is not None else None),
        )


def list_audit_logs(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            "SELECT id, actor, action, details, created_at FROM audit_logs ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {
                "id": r[0],
                "actor": r[1],
                "action": r[2],
                "details": json.loads(r[3]) if r[3] else None,
                "created_at": r[4],
            }
            for r in rows
        ]


def create_order(
    *,
    internal_order_id: str,
    trading_symbol: str,
    exchange_segment: str | None,
    transaction_type: str,
    order_type: str,
    product: str,
    validity: str,
    quantity: int,
    price: float | None,
    trigger_price: float | None,
    mode: str,
    status: str,
    status_reason: str | None = None,
    broker_order_id: str | None = None,
) -> int:
    """Inserts a new local order row (our own idempotency key is
    internal_order_id, generated by order_service.py BEFORE any broker
    call is attempted -- so a request can always be traced/retried safely
    even if the broker call itself times out ambiguously)."""
    with _connection() as conn:
        cur = conn.execute(
            """INSERT INTO orders
               (internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason, submitted_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))""",
            (
                internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                transaction_type, order_type, product, validity, quantity, price,
                trigger_price, mode, status, status_reason,
            ),
        )
        return cur.lastrowid


def update_order(
    *, internal_order_id: str, status: str | None = None, status_reason: str | None = None,
    broker_order_id: str | None = None,
) -> None:
    """Partial update by internal_order_id -- only columns explicitly
    passed are changed; None means "leave alone" for status_reason/
    broker_order_id specifically (an order moving PENDING -> OPEN has no
    new reason to record), but status is only ever written when the
    caller passes one."""
    with _connection() as conn:
        sets = ["updated_at = datetime('now')"]
        params: list = []
        if status is not None:
            sets.append("status = ?")
            params.append(status)
        if status_reason is not None:
            sets.append("status_reason = ?")
            params.append(status_reason)
        if broker_order_id is not None:
            sets.append("broker_order_id = ?")
            params.append(broker_order_id)
        params.append(internal_order_id)
        conn.execute(f"UPDATE orders SET {', '.join(sets)} WHERE internal_order_id = ?", params)


def get_order(internal_order_id: str) -> dict | None:
    with _connection() as conn:
        row = conn.execute(
            """SELECT internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                      transaction_type, order_type, product, validity, quantity, price,
                      trigger_price, mode, status, status_reason, submitted_at, updated_at, created_at
               FROM orders WHERE internal_order_id = ?""",
            (internal_order_id,),
        ).fetchone()
        return _order_row_to_dict(row) if row else None


def list_orders(*, limit: int = 200) -> list[dict]:
    limit = max(1, min(limit, 1000))
    with _connection() as conn:
        rows = conn.execute(
            """SELECT internal_order_id, broker_order_id, trading_symbol, exchange_segment,
                      transaction_type, order_type, product, validity, quantity, price,
                      trigger_price, mode, status, status_reason, submitted_at, updated_at, created_at
               FROM orders ORDER BY id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        return [_order_row_to_dict(r) for r in rows]


def _order_row_to_dict(row) -> dict:
    keys = [
        "internal_order_id", "broker_order_id", "trading_symbol", "exchange_segment",
        "transaction_type", "order_type", "product", "validity", "quantity", "price",
        "trigger_price", "mode", "status", "status_reason", "submitted_at", "updated_at", "created_at",
    ]
    return dict(zip(keys, row))


def record_positions_snapshot(rows: list[dict]) -> None:
    """Replaces the positions_snapshot table's content with the latest
    fetch (delete-then-insert in one transaction) -- a snapshot table
    holds "what does the broker say right now", not a growing history, so
    stale rows from a closed/changed position must not linger."""
    with _connection() as conn:
        conn.execute("DELETE FROM positions_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO positions_snapshot
                   (trading_symbol, exchange_segment, product, quantity, average_price, raw_payload)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"), r.get("product"),
                    r.get("quantity"), r.get("average_price"), json.dumps(r.get("raw", r)),
                ),
            )


def record_holdings_snapshot(rows: list[dict]) -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM holdings_snapshot")
        for r in rows:
            conn.execute(
                """INSERT INTO holdings_snapshot
                   (trading_symbol, exchange_segment, quantity, average_price, raw_payload)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    r.get("trading_symbol"), r.get("exchange_segment"),
                    r.get("quantity"), r.get("average_price"), json.dumps(r.get("raw", r)),
                ),
            )


def record_funds_snapshot(*, available_margin: float | None, used_margin: float | None, raw: dict) -> None:
    with _connection() as conn:
        conn.execute(
            "INSERT INTO funds_snapshot (available_margin, used_margin, raw_payload) VALUES (?, ?, ?)",
            (available_margin, used_margin, json.dumps(raw)),
        )


def latest_positions_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, product, quantity, average_price, raw_payload, snapshot_at FROM positions_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1], "product": r[2],
                "quantity": r[3], "average_price": r[4], "raw": json.loads(r[5]) if r[5] else None,
                "snapshot_at": r[6],
            }
            for r in rows
        ]


def latest_holdings_snapshot() -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT trading_symbol, exchange_segment, quantity, average_price, raw_payload, snapshot_at FROM holdings_snapshot ORDER BY id ASC"
        ).fetchall()
        return [
            {
                "trading_symbol": r[0], "exchange_segment": r[1],
                "quantity": r[2], "average_price": r[3], "raw": json.loads(r[4]) if r[4] else None,
                "snapshot_at": r[5],
            }
            for r in rows
        ]


def latest_funds_snapshot() -> dict | None:
    with _connection() as conn:
        row = conn.execute(
            "SELECT available_margin, used_margin, raw_payload, snapshot_at FROM funds_snapshot ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        return {
            "available_margin": row[0], "used_margin": row[1],
            "raw": json.loads(row[2]) if row[2] else None, "snapshot_at": row[3],
        }
