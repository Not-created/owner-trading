"""WebSocket lifecycle foundation for the Kotak SFeed (market data) and
order feed. Uses only the current async factory API confirmed by the SDK
audit -- create_websocket()/subscribe_scrips()/unsubscribe_scrips() and
create_order_feed() -- never the obsolete subscribe()/un_subscribe()/
subscribe_to_orderfeed() stubs.

Nothing here opens a real connection during this phase. `start()` is not
called by main.py yet -- it is wired up and ready for the next phase to
invoke once real credentials exist.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from .broker_client import broker_client
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket_manager")


@dataclass
class SubscriptionRegistry:
    """Tracks which instruments the dashboard currently wants ticks for, so
    a reconnect can resubscribe everything without the caller re-asking.
    """

    scrip_subscriptions: set[str] = field(default_factory=set)

    def add(self, instrument_token: str) -> None:
        self.scrip_subscriptions.add(instrument_token)

    def remove(self, instrument_token: str) -> None:
        self.scrip_subscriptions.discard(instrument_token)

    def all(self) -> list[str]:
        return sorted(self.scrip_subscriptions)


class WebSocketManager:
    """Owns the market-data and order-feed WebSocket lifecycle: connect,
    subscribe, reconnect with backoff, resubscribe after reconnect, and a
    heartbeat/health check the /status endpoint can report on.

    Foundation-stage behavior: every method below is implemented but never
    called with real credentials in this phase. `main.py` does not invoke
    `start()` yet.
    """

    def __init__(self) -> None:
        self.registry = SubscriptionRegistry()
        self._market_feed = None
        self._order_feed = None
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 10
        self._running = False

    async def start(self) -> None:
        """Would: broker_client.create_market_feed() and
        broker_client.create_order_feed(), then resubscribe every
        instrument in self.registry, then launch the heartbeat loop. Only
        valid once current_state.state == CONNECTED. Not called this phase.
        """
        if current_state.state != BrokerState.CONNECTED:
            logger.info("WebSocketManager.start() skipped -- broker not connected yet.")
            return
        self._running = True
        # Real implementation (next phase):
        #   self._market_feed = broker_client.create_market_feed()
        #   async with self._market_feed as feed:
        #       await feed.subscribe_scrips(self.registry.all())
        #       async for message in feed:
        #           await self._handle_market_message(message)
        raise NotImplementedError("WebSocket connection is not enabled in this deployment phase.")

    async def stop(self) -> None:
        """Graceful shutdown: close both feeds cleanly rather than dropping
        the connection, so the broker sees an intentional disconnect.
        """
        self._running = False
        if self._market_feed is not None:
            await self._safe_close(self._market_feed)
        if self._order_feed is not None:
            await self._safe_close(self._order_feed)

    async def _safe_close(self, feed) -> None:
        try:
            await feed.close()
        except Exception as exc:  # noqa: BLE001 -- shutdown must not raise
            logger.warning("Error while closing feed during shutdown: %s", exc)

    async def _reconnect_with_backoff(self) -> None:
        """Exponential backoff up to _max_reconnect_attempts, then gives up
        and transitions the broker state to CONNECTION_ERROR so the
        dashboard reflects reality instead of silently going stale.
        """
        while self._running and self._reconnect_attempts < self._max_reconnect_attempts:
            delay = min(2**self._reconnect_attempts, 30)
            await asyncio.sleep(delay)
            self._reconnect_attempts += 1
            try:
                await self.start()
                await self.resubscribe_all()
                self._reconnect_attempts = 0
                return
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconnect attempt %s failed: %s", self._reconnect_attempts, exc)
        current_state.transition(BrokerState.CONNECTION_ERROR, "WebSocket reconnect attempts exhausted")

    async def resubscribe_all(self) -> None:
        """After a reconnect, re-issue subscribe_scrips() for everything in
        the registry -- and REST-reconcile order/position state, since
        events may have been missed while disconnected (see
        reconciliation.py)."""
        if self._market_feed is None:
            return
        # Real implementation: await self._market_feed.subscribe_scrips(self.registry.all())


# Module-level singleton -- one manager per persistent process.
websocket_manager = WebSocketManager()
