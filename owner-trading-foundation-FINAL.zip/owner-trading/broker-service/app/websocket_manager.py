"""WebSocket lifecycle for the Kotak market-data (SFeed) and order feeds.

REWRITTEN against the real, directly-inspected kotakneoapi 3.0.7 source
(github.com/Kotak-Neo/kotak-neo-python, provided directly -- not fetched
indirectly, not guessed). Everything below reflects what was actually
read in neo_api_client/websocket/feed/client.py and
neo_api_client/websocket/orderfeed/client.py:

1. THE REAL USAGE PATTERN is an async context manager + async iterator,
   NOT callback registration (an earlier version of this module tried
   on_message attribute/method patterns that don't apply to this SDK):

       async with broker_client.create_market_feed() as ws:
           await ws.subscribe_scrips([WsToken(exchange_segment, token)])
           async for message in ws:
               ...  # message is a typed Pydantic model

2. THE SDK HAS ITS OWN BUILT-IN RECONNECT + RESUBSCRIBE. Both
   SFeedWebSocket and OrderFeedWebSocket accept reconnect_delay/
   max_reconnect_attempts and internally call _handle_disconnect(), which
   reconnects AND resubscribes everything the caller previously
   subscribed to -- confirmed by reading _handle_disconnect() directly.
   This module's own outer retry loop therefore only matters for the case
   where the SDK's OWN reconnect attempts are exhausted (the `async with`
   block exits) or the initial connect() fails outright (e.g. an
   auth/session problem) -- it is a second, outer safety net, not a
   duplicate of what the SDK already does well.

3. THE LEGACY WEBSOCKET METHODS ARE CONFIRMED DEAD. NeoAPI.subscribe()/
   un_subscribe()/subscribe_to_orderfeed() exist as methods but their
   bodies unconditionally `raise NotImplementedError` ("Removed in
   2.2.0"). There is no dual-shape ambiguity anymore -- this module calls
   create_websocket()/create_order_feed() unconditionally, the only real
   path (see sdk_conformance.py for the runtime check that still guards
   against an installed version that doesn't match this).

4. MESSAGE FIELDS ARE FULLY TYPED, CONFIRMED FROM SOURCE -- not best-
   effort dict-key guessing anymore:
   - Market feed: SFeedScrip/SFeedScripLite/SFeedIndex all share
     .exchange_segment/.instrument_token/.trading_symbol/.last_traded_price
     (inherited from/matching SFeedInstrumentMessage).
   - Order feed: OrderUpdate.data is an OrderData with confirmed fields
     order_id, order_status, average_price, quantity, filled_quantity,
     trading_symbol, exchange_segment, transaction_type, price_type.
     PositionUpdate.data is a PositionData with confirmed fields
     account_id, symbol, filled_buy_quantity, filled_sell_quantity, etc.
   No field-name guessing remains in this module's message handlers.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum

from .broker_client import broker_client, NotConfiguredError
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket_manager")

# No message for this long while supposedly running is treated as stale --
# worth flagging even before the SDK's own reconnect logic notices a drop.
STALE_AFTER_SECONDS = 90

# Outer retry loop (this module's own safety net -- see module docstring,
# point 2): backoff between attempts to reopen a feed after the SDK's own
# internal reconnect has been exhausted or the initial connect failed.
_OUTER_MAX_ATTEMPTS = 10


class FeedState(str, Enum):
    STOPPED = "STOPPED"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    RECONNECTING = "RECONNECTING"
    FAILED = "FAILED"


@dataclass
class SubscriptionRegistry:
    """Tracks (exchange_segment, instrument_token) pairs the dashboard
    currently wants ticks for, so a fresh feed (after this module's own
    outer reconnect, not the SDK's internal one) can resubscribe
    everything without the caller re-asking."""

    tokens: set[tuple[str, str]] = field(default_factory=set)

    def add(self, exchange_segment: str, instrument_token: str) -> None:
        self.tokens.add((exchange_segment, instrument_token))

    def remove(self, exchange_segment: str, instrument_token: str) -> None:
        self.tokens.discard((exchange_segment, instrument_token))

    def all(self) -> list[tuple[str, str]]:
        return sorted(self.tokens)


class WebSocketManager:
    """Owns the market-data and order-feed WebSocket lifecycle. Runs both
    feeds as independent background asyncio tasks (each with its own
    outer retry loop around the SDK's own async-context-manager /
    async-iterator usage), and exposes staleness/state for /status and
    main.py's background loop.
    """

    def __init__(self) -> None:
        self.registry = SubscriptionRegistry()
        self.state = FeedState.STOPPED
        self._running = False
        self._market_task: asyncio.Task | None = None
        self._order_task: asyncio.Task | None = None
        self._market_ws = None  # the currently-open SFeedWebSocket, if any -- for live subscribe()/unsubscribe()
        self._last_message_at: float | None = None
        self.last_error: str | None = None

    # ------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------ #
    async def start(self) -> None:
        """Launches both feeds as background tasks. Each task manages its
        own connect/subscribe/iterate/reconnect cycle independently --
        this method returns once the tasks are scheduled, it does not
        wait for a successful connection (that happens asynchronously;
        check self.state or is_stale() to observe it)."""
        if current_state.state != BrokerState.CONNECTED:
            logger.info("WebSocketManager.start() skipped -- broker not connected yet (state: %s).", current_state.state.value)
            return
        if self._running:
            logger.info("WebSocketManager.start() called while already running -- ignoring.")
            return

        self._running = True
        self.state = FeedState.CONNECTING
        self._market_task = asyncio.create_task(self._run_market_feed())
        self._order_task = asyncio.create_task(self._run_order_feed())
        logger.info("WebSocketManager started (%d instrument(s) queued for subscription).", len(self.registry.all()))

    async def stop(self) -> None:
        """Graceful shutdown: cancels both background tasks and lets each
        one's `async with` block close its feed cleanly via __aexit__."""
        self._running = False
        self.state = FeedState.STOPPED
        for task in (self._market_task, self._order_task):
            if task is not None and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._market_task = None
        self._order_task = None
        self._market_ws = None

    # ------------------------------------------------------------ #
    # Market feed -- outer retry loop around the SDK's own reconnect
    # ------------------------------------------------------------ #
    async def _run_market_feed(self) -> None:
        from .sdk_conformance import check_sdk_conformance

        attempts = 0
        while self._running and attempts < _OUTER_MAX_ATTEMPTS:
            try:
                conformance = check_sdk_conformance()
                if not conformance.ok:
                    raise RuntimeError(conformance.summary())

                async with broker_client.create_market_feed() as ws:
                    self._market_ws = ws
                    self.state = FeedState.CONNECTED
                    attempts = 0  # a real connection succeeded -- reset the outer backoff counter
                    from neo_api_client.websocket.feed import WsToken

                    tokens = self.registry.all()
                    if tokens:
                        await ws.subscribe_scrips([WsToken(seg, tok) for seg, tok in tokens])
                    async for message in ws:
                        self._last_message_at = time.time()
                        self._on_market_message(message)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 -- one failed attempt must not kill the outer loop
                attempts += 1
                self.last_error = f"Market feed error (outer attempt {attempts}/{_OUTER_MAX_ATTEMPTS}): {exc}"
                logger.warning(self.last_error)
                self._market_ws = None
                if not self._running:
                    break
                self.state = FeedState.RECONNECTING
                delay = min(2**attempts, 30)
                await asyncio.sleep(delay)
                try:
                    from . import reconciliation as _reconciliation

                    await _reconciliation.run_full_reconciliation()
                except Exception as recon_exc:  # noqa: BLE001
                    logger.warning("Post-reconnect reconciliation failed: %s", recon_exc)

        if self._running and attempts >= _OUTER_MAX_ATTEMPTS:
            self.state = FeedState.FAILED
            current_state.transition(BrokerState.CONNECTION_ERROR, "Market feed reconnect attempts exhausted")

    async def _run_order_feed(self) -> None:
        attempts = 0
        while self._running and attempts < _OUTER_MAX_ATTEMPTS:
            try:
                async with broker_client.create_order_feed() as feed:
                    attempts = 0
                    async for message in feed:
                        self._last_message_at = time.time()
                        self._on_order_message(message)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                attempts += 1
                logger.warning("Order feed error (outer attempt %d/%d): %s", attempts, _OUTER_MAX_ATTEMPTS, exc)
                if not self._running:
                    break
                delay = min(2**attempts, 30)
                await asyncio.sleep(delay)

    # ------------------------------------------------------------ #
    # Subscriptions -- live-subscribe on the currently-open feed when one
    # exists; always update the registry so a future (re)connect picks it
    # up regardless.
    # ------------------------------------------------------------ #
    async def subscribe(self, exchange_segment: str, instrument_token: str) -> None:
        self.registry.add(exchange_segment, instrument_token)
        if self._market_ws is not None:
            from neo_api_client.websocket.feed import WsToken

            await self._market_ws.subscribe_scrips([WsToken(exchange_segment, instrument_token)])

    async def unsubscribe(self, exchange_segment: str, instrument_token: str) -> None:
        self.registry.remove(exchange_segment, instrument_token)
        if self._market_ws is not None:
            from neo_api_client.websocket.feed import WsToken

            await self._market_ws.unsubscribe_scrips([WsToken(exchange_segment, instrument_token)])

    # ------------------------------------------------------------ #
    # Staleness
    # ------------------------------------------------------------ #
    def is_stale(self) -> bool:
        if self.state != FeedState.CONNECTED or self._last_message_at is None:
            return False
        return (time.time() - self._last_message_at) > STALE_AFTER_SECONDS

    # ------------------------------------------------------------ #
    # Message handling -- confirmed field names, no guessing (see module
    # docstring, point 4).
    # ------------------------------------------------------------ #
    def _on_market_message(self, message) -> None:
        try:
            from . import db as _db
            from neo_api_client.websocket.feed import SFeedIndex, SFeedScrip, SFeedScripLite

            if isinstance(message, (SFeedScrip, SFeedScripLite, SFeedIndex)):
                _db.record_market_tick(
                    instrument_token=message.instrument_token,
                    exchange_segment=message.exchange_segment,
                    last_traded_price=message.last_traded_price,
                )
            else:
                # SFeedMarketStatus / SFeedCasChange -- status/corporate-
                # action notifications, not tick data; not persisted to
                # market_data_state (which models "current price"), just
                # logged for visibility.
                logger.info("Market feed status/CAS message: %s", type(message).__name__)
        except Exception as exc:  # noqa: BLE001 -- a callback must never raise back into the SDK's async iterator
            logger.error("Error handling market message: %s", exc)

    def _on_order_message(self, message) -> None:
        try:
            from . import db as _db
            from neo_api_client.websocket.orderfeed import OrderUpdate, PositionUpdate

            if isinstance(message, PositionUpdate):
                logger.info("Position update received (symbol=%s) -- positions are read via REST reconciliation, not persisted from this event.", message.data.symbol)
                return
            if not isinstance(message, OrderUpdate):
                logger.info("Unrecognized order-feed message type: %s", type(message).__name__)
                return

            data = message.data
            payload = data.model_dump(by_alias=True)
            _db.record_order_event(
                event_source="order_feed_ws", broker_event_id=data.order_id,
                raw_payload=payload, broker_order_id=data.order_id,
            )

            if not data.order_id:
                logger.warning("Order-feed message has no order_id -- raw payload still recorded to order_events.")
                return

            local_order = _db.get_order_by_broker_order_id(data.order_id)
            if local_order is None:
                logger.info("Order-feed message for broker_order_id=%s has no matching local order (placed outside this app?).", data.order_id)
                return

            # PARTIAL-FILL PERSISTENCE: OrderData carries the order's
            # CURRENT CUMULATIVE state (filled_quantity out of quantity),
            # not a discrete per-fill event with its own trade id -- there
            # is no trade-level id in this model (confirmed from source).
            # Status is derived from the real filled_quantity/quantity
            # ratio, never from order_status's raw string value alone
            # (its exact vocabulary wasn't enumerated in the source beyond
            # OrderStatus's constants -- see that class for what's
            # confirmed). Individual per-fill trade records (with their
            # own broker_trade_id, for the `trades` table) come from
            # trade_report() via reconciliation.reconcile_trades(), which
            # IS a real per-trade REST endpoint -- not this feed.
            if data.filled_quantity is not None and data.quantity:
                new_status = "COMPLETE" if data.filled_quantity >= data.quantity else (
                    "PARTIALLY_FILLED" if data.filled_quantity > 0 else local_order["status"]
                )
                _db.update_order(
                    internal_order_id=local_order["internal_order_id"],
                    status=new_status,
                    status_reason=f"Broker order_status: {data.order_status}" if data.order_status else None,
                )
        except Exception as exc:  # noqa: BLE001
            logger.error("Error handling order-feed message: %s", exc)


# Module-level singleton -- one manager per persistent process.
websocket_manager = WebSocketManager()
