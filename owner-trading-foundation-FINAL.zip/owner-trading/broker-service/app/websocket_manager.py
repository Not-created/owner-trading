"""WebSocket lifecycle for the Kotak market-data (SFeed) and order feeds.

WHAT IS AND ISN'T VERIFIED HERE, STATED PLAINLY:

1. WHICH METHODS EXIST -- verified at runtime, every time this starts.
   sdk_conformance.detect_websocket_api_shape() introspects whatever
   `neo_api_client.NeoAPI` is ACTUALLY installed in this deployment and
   returns "current" (create_websocket/subscribe_scrips/
   unsubscribe_scrips/create_order_feed), "legacy" (subscribe/
   un_subscribe/subscribe_to_orderfeed), or None. This code only ever
   calls the shape that's genuinely present -- it does not guess which
   generation of the SDK is "correct" for this account, because that
   question could not be resolved against the official repository during
   this project's audits (github.com/Kotak-Neo/kotak-neo-python has
   returned 404 on every direct-fetch check performed across this
   project's sessions).

2. HOW A MESSAGE CALLBACK IS REGISTERED -- NOT independently verified,
   best-effort. Different WebSocket client designs register a message
   handler differently (an `on_message` attribute assignment, an
   `on_message(callback)` method call, a `.on("message", callback)`
   event-emitter pattern, or an async iterator you loop over). This
   module tries the most common patterns via introspection, in order, and
   raises a clear, specific error if none work -- it does NOT silently
   fall back to "looks connected" without a real, working callback path.

3. THE SHAPE OF AN INCOMING MESSAGE -- NOT independently verified,
   best-effort, same policy as broker_client.py's response-field
   extraction and order_service.py's broker-order-id extraction: a list
   of plausible field names is tried, the raw payload is ALWAYS persisted
   verbatim (via db.record_order_event) regardless of whether extraction
   succeeds, and a failed extraction is logged, never silently dropped.

4. THE RECONNECT/BACKOFF/RESUBSCRIBE/MISSED-EVENT-RECONCILIATION
   ORCHESTRATION -- this part IS fully deterministic engineering, not
   dependent on unverified Kotak specifics: track what's subscribed,
   detect disconnection/staleness, back off and retry, resubscribe
   everything on reconnect, and always run a REST reconciliation pass
   after reconnecting (since some events may have been missed while
   disconnected -- the WebSocket feed is a low-latency convenience layer,
   REST reconciliation is the authoritative source of truth this project
   has relied on throughout).
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum

from .broker_client import broker_client, NotConfiguredError
from .sdk_conformance import detect_websocket_api_shape
from .state import BrokerState, current_state

logger = logging.getLogger("owner_trading.websocket_manager")

# No message for this long while supposedly CONNECTED is treated as stale
# -- worth flagging even before the underlying transport notices a drop.
STALE_AFTER_SECONDS = 90


class FeedState(str, Enum):
    STOPPED = "STOPPED"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    RECONNECTING = "RECONNECTING"
    FAILED = "FAILED"


@dataclass
class SubscriptionRegistry:
    """Tracks which instruments the dashboard currently wants ticks for, so
    a reconnect can resubscribe everything without the caller re-asking.
    """

    scrip_subscriptions: set[str] = field(default_factory=set)

    def add(self, instrument_token: str) -> None:
        self.scrip_subscriptions.add(instrument_token)

    def remove(self, instrument_token: str) -> None:
        self.scrip_subscriptions.discard(instrument_token)

    def all(self) -> list[str]:
        return sorted(self.scrip_subscriptions)


def _try_register_callback(feed, handler) -> bool:
    """Best-effort, documented-as-unverified (see module docstring, point
    2): tries the common ways a WebSocket client object exposes a message
    callback. Returns True if one of them was applied without raising --
    NOT proof the callback actually fires for a real message, only that
    the registration call itself didn't error.
    """
    if hasattr(feed, "on_message") and callable(getattr(feed, "on_message", None)):
        try:
            feed.on_message(handler)
            return True
        except TypeError:
            pass  # on_message might be a plain attribute slot, not a registration method -- fall through
    if hasattr(feed, "on_message"):
        try:
            feed.on_message = handler
            return True
        except Exception:  # noqa: BLE001
            pass
    if hasattr(feed, "on") and callable(getattr(feed, "on", None)):
        try:
            feed.on("message", handler)
            return True
        except Exception:  # noqa: BLE001
            pass
    return False


class WebSocketManager:
    """Owns the market-data and order-feed WebSocket lifecycle: connect,
    subscribe, reconnect with backoff, resubscribe after reconnect, missed-
    event REST reconciliation, and a staleness check the /status endpoint
    (and main.py's background loop) can use.
    """

    def __init__(self) -> None:
        self.registry = SubscriptionRegistry()
        self._market_feed = None
        self._order_feed = None
        self._shape: str | None = None
        self.state = FeedState.STOPPED
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 10
        self._running = False
        self._last_message_at: float | None = None
        self.last_error: str | None = None

    # ------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------ #
    async def start(self) -> None:
        """Detects the real installed SDK's websocket shape, opens both
        feeds, wires callbacks, and resubscribes everything currently in
        the registry. Raises RuntimeError with a specific reason on any
        failure -- callers (main.py) catch this and log it; it never
        leaves self.state silently claiming CONNECTED when it isn't.
        """
        if current_state.state != BrokerState.CONNECTED:
            logger.info("WebSocketManager.start() skipped -- broker not connected yet.")
            return

        self._shape = detect_websocket_api_shape()
        if self._shape is None:
            self.state = FeedState.FAILED
            self.last_error = (
                "Installed Kotak SDK exposes neither the current "
                "(create_websocket/subscribe_scrips/create_order_feed) nor legacy "
                "(subscribe/un_subscribe/subscribe_to_orderfeed) WebSocket method set -- "
                "real-time market/order data cannot be enabled with this installed package."
            )
            logger.error(self.last_error)
            raise RuntimeError(self.last_error)

        self.state = FeedState.CONNECTING
        self._running = True
        loop = asyncio.get_running_loop()

        try:
            if self._shape == "current":
                self._market_feed = await loop.run_in_executor(None, broker_client.create_market_feed)
                self._order_feed = await loop.run_in_executor(None, broker_client.create_order_feed)
            else:
                # Legacy shape: subscribe()/un_subscribe() are called
                # directly on the NeoAPI instance itself (no separate feed
                # object in this generation) -- broker_client is the "feed"
                # for callback-registration purposes here.
                self._market_feed = broker_client
                self._order_feed = broker_client
        except NotConfiguredError:
            raise
        except Exception as exc:  # noqa: BLE001
            self.state = FeedState.FAILED
            self.last_error = f"Failed to open WebSocket feed(s) ({self._shape} shape): {exc}"
            logger.error(self.last_error)
            raise RuntimeError(self.last_error) from exc

        if not _try_register_callback(self._market_feed, self._on_market_message):
            self.state = FeedState.FAILED
            self.last_error = (
                f"Opened the market feed ({self._shape} shape) but could not register a message callback "
                f"via any known pattern (on_message method/attribute, .on('message', ...)) -- see "
                f"websocket_manager.py's module docstring, point 2."
            )
            logger.error(self.last_error)
            raise RuntimeError(self.last_error)
        _try_register_callback(self._order_feed, self._on_order_message)  # best-effort; market feed is the hard requirement

        await self._subscribe_all()
        self.state = FeedState.CONNECTED
        self._last_message_at = time.time()
        self._reconnect_attempts = 0
        logger.info("WebSocketManager started (shape=%s, %d instrument(s) subscribed).", self._shape, len(self.registry.all()))

    async def stop(self) -> None:
        """Graceful shutdown: close both feeds cleanly rather than dropping
        the connection, so the broker sees an intentional disconnect.
        """
        self._running = False
        self.state = FeedState.STOPPED
        if self._market_feed is not None:
            await self._safe_close(self._market_feed)
        if self._order_feed is not None and self._order_feed is not self._market_feed:
            await self._safe_close(self._order_feed)
        self._market_feed = None
        self._order_feed = None

    async def _safe_close(self, feed) -> None:
        close = getattr(feed, "close", None)
        if not callable(close):
            return
        try:
            result = close()
            if asyncio.iscoroutine(result):
                await result
        except Exception as exc:  # noqa: BLE001 -- shutdown must not raise
            logger.warning("Error while closing feed during shutdown: %s", exc)

    # ------------------------------------------------------------ #
    # Subscriptions
    # ------------------------------------------------------------ #
    async def subscribe(self, instrument_token: str) -> None:
        self.registry.add(instrument_token)
        if self.state == FeedState.CONNECTED:
            await self._call_subscribe([instrument_token])

    async def unsubscribe(self, instrument_token: str) -> None:
        self.registry.remove(instrument_token)
        if self.state == FeedState.CONNECTED:
            await self._call_unsubscribe([instrument_token])

    async def _subscribe_all(self) -> None:
        tokens = self.registry.all()
        if tokens:
            await self._call_subscribe(tokens)

    async def _call_subscribe(self, tokens: list[str]) -> None:
        loop = asyncio.get_running_loop()
        if self._shape == "current":
            await loop.run_in_executor(None, lambda: broker_client.subscribe_scrips(tokens))
        else:
            await loop.run_in_executor(None, lambda: broker_client.legacy_subscribe(tokens))

    async def _call_unsubscribe(self, tokens: list[str]) -> None:
        loop = asyncio.get_running_loop()
        if self._shape == "current":
            await loop.run_in_executor(None, lambda: broker_client.unsubscribe_scrips(tokens))
        else:
            await loop.run_in_executor(None, lambda: broker_client.legacy_unsubscribe(tokens))

    # ------------------------------------------------------------ #
    # Reconnect / staleness
    # ------------------------------------------------------------ #
    def is_stale(self) -> bool:
        """True if we believe we're connected but haven't heard a message
        in STALE_AFTER_SECONDS -- a live feed with no ticks for that long
        (during market hours) is a strong signal something's wrong even
        before the transport itself notices a drop."""
        if self.state != FeedState.CONNECTED or self._last_message_at is None:
            return False
        return (time.time() - self._last_message_at) > STALE_AFTER_SECONDS

    async def reconnect_with_backoff(self) -> None:
        """Exponential backoff up to _max_reconnect_attempts, then gives up
        and transitions the broker state to CONNECTION_ERROR so the
        dashboard reflects reality instead of silently going stale. On a
        successful reconnect, ALWAYS triggers a full REST reconciliation
        pass (missed-event recovery -- see module docstring, point 4)
        before declaring itself healthy again.
        """
        self.state = FeedState.RECONNECTING
        while self._running and self._reconnect_attempts < self._max_reconnect_attempts:
            delay = min(2**self._reconnect_attempts, 30)
            await asyncio.sleep(delay)
            self._reconnect_attempts += 1
            try:
                await self.start()
                from . import reconciliation as _reconciliation

                await _reconciliation.run_full_reconciliation()
                logger.info("WebSocket reconnected after %d attempt(s); missed-event reconciliation complete.", self._reconnect_attempts)
                return
            except Exception as exc:  # noqa: BLE001
                logger.warning("Reconnect attempt %s failed: %s", self._reconnect_attempts, exc)
        self.state = FeedState.FAILED
        current_state.transition(BrokerState.CONNECTION_ERROR, "WebSocket reconnect attempts exhausted")

    # ------------------------------------------------------------ #
    # Message handling -- best-effort extraction (module docstring, 3);
    # raw payload always persisted regardless of extraction success.
    # ------------------------------------------------------------ #
    def _on_market_message(self, message) -> None:
        self._last_message_at = time.time()
        try:
            from . import db as _db

            payload = message if isinstance(message, dict) else {"raw": str(message)}
            token = None
            price = None
            exchange_segment = None
            if isinstance(message, dict):
                for key in ("tk", "token", "instrument_token", "symbol"):
                    if message.get(key):
                        token = str(message[key])
                        break
                for key in ("ltp", "last_traded_price", "lastTradedPrice", "close"):
                    if message.get(key) is not None:
                        try:
                            price = float(message[key])
                        except (TypeError, ValueError):
                            pass
                        break
                for key in ("e", "exchange_segment", "exchangeSegment"):
                    if message.get(key):
                        exchange_segment = str(message[key])
                        break
            if token:
                _db.record_market_tick(instrument_token=token, exchange_segment=exchange_segment, last_traded_price=price)
            else:
                logger.warning("Market message did not match any known instrument-token field -- payload not persisted to market_data_state (raw: %s).", payload)
        except Exception as exc:  # noqa: BLE001 -- a callback must never raise back into the SDK's dispatch loop
            logger.error("Error handling market message: %s", exc)

    def _on_order_message(self, message) -> None:
        self._last_message_at = time.time()
        try:
            from . import db as _db

            payload = message if isinstance(message, dict) else {"raw": str(message)}
            broker_order_id = None
            broker_event_id = None
            status = None
            fill_qty = None
            fill_price = None
            broker_trade_id = None
            if isinstance(message, dict):
                for key in ("nOrdNo", "order_id", "orderId", "orderNo"):
                    if message.get(key):
                        broker_order_id = str(message[key])
                        break
                for key in ("evntId", "event_id", "reportType"):
                    if message.get(key):
                        broker_event_id = str(message[key])
                        break
                for key in ("status", "ordSt", "order_status"):
                    if message.get(key):
                        status = str(message[key])
                        break
                for key in ("fldQty", "filled_quantity", "flQty"):
                    if message.get(key) is not None:
                        try:
                            fill_qty = int(message[key])
                        except (TypeError, ValueError):
                            pass
                        break
                for key in ("avgPrc", "fill_price", "avgPrice"):
                    if message.get(key) is not None:
                        try:
                            fill_price = float(message[key])
                        except (TypeError, ValueError):
                            pass
                        break
                for key in ("flDtTm", "trade_id", "fillId"):
                    if message.get(key):
                        broker_trade_id = str(message[key])
                        break

            # Raw payload is ALWAYS recorded (idempotent on
            # (event_source, broker_event_id)), regardless of whether the
            # best-effort field extraction above found anything -- this is
            # the durable, replayable audit trail even when the shape
            # doesn't match what was guessed.
            _db.record_order_event(
                event_source="order_feed_ws", broker_event_id=broker_event_id or broker_order_id,
                raw_payload=payload, broker_order_id=broker_order_id,
            )

            if not broker_order_id:
                logger.warning("Order-feed message did not match any known broker-order-id field -- raw payload still recorded to order_events.")
                return

            local_order = _db.get_order_by_broker_order_id(broker_order_id)
            if local_order is None:
                logger.info("Order-feed message for broker_order_id=%s has no matching local order (placed outside this app?).", broker_order_id)
                return

            # PARTIAL-FILL PERSISTENCE: every fill event with a distinct
            # broker_trade_id is recorded (idempotent -- re-delivery of the
            # same fill is a no-op), then the order's status is derived
            # from the REAL SUM of recorded fills vs. the order's own
            # quantity -- never from a single message's claimed status
            # string alone, since a status VALUE's exact vocabulary
            # ("open"/"complete"/"rejected" vs. numeric codes) is exactly
            # the kind of Kotak-specific detail this project could not
            # verify (see reconciliation.py's docstring for the same
            # reasoning applied to order presence).
            if fill_qty and fill_price and broker_trade_id:
                inserted = _db.record_trade(
                    broker_trade_id=broker_trade_id, order_id=local_order["id"], broker_order_id=broker_order_id,
                    fill_quantity=fill_qty, fill_price=fill_price, fill_time=None, raw_payload=payload,
                )
                if inserted:
                    total_filled = _db.sum_filled_quantity(local_order["id"])
                    new_status = "COMPLETE" if total_filled >= local_order["quantity"] else "PARTIALLY_FILLED"
                    _db.update_order(internal_order_id=local_order["internal_order_id"], status=new_status)
                    logger.info(
                        "Fill recorded for order %s: %d/%d filled -> %s",
                        local_order["internal_order_id"], total_filled, local_order["quantity"], new_status,
                    )
            elif status:
                # No fill data in this message, but a status string was
                # present -- recorded as status_reason context rather than
                # overwriting `status` itself with an unverified value.
                _db.update_order(
                    internal_order_id=local_order["internal_order_id"],
                    status_reason=f"Broker reported status: {status}",
                )
        except Exception as exc:  # noqa: BLE001
            logger.error("Error handling order-feed message: %s", exc)


# Module-level singleton -- one manager per persistent process.
websocket_manager = WebSocketManager()
