"""REST-based reconciliation, run right after every successful connect
(see broker_client.py) and on a periodic schedule while CONNECTED (see
main.py's _background_maintenance_loop).

Phase 1C: orders/positions/holdings/funds are now actually persisted
locally (db.py's create_order/record_*_snapshot, populated by
order_service.py and the routes in server.py), so reconcile_orders() now
does a REAL presence diff between the broker's order book and this
service's own `orders` table -- not just "fetched successfully" like
before.

HONEST SCOPE NOTE, still true: Kotak's exact field names for order
id/status inside order_report()'s response could not be independently
verified against the official repository (see
broker-service/requirements.txt and app/sdk_conformance.py for the full
finding). So this diff is deliberately shallow and defensible without
guessing: it compares by broker_order_id PRESENCE only (does every
locally-known submitted LIVE order id appear somewhere in the broker's
order book, and vice versa) -- it does NOT attempt to map or compare
Kotak's specific status string values, since those field/value names are
equally unverified and a wrong mapping would be worse than no mapping.
"""
from __future__ import annotations

import logging

from .broker_client import broker_client, NotConfiguredError, response_is_error

logger = logging.getLogger("owner_trading.reconciliation")

# Same best-effort, documented-as-unverified key list used in
# order_service.py's place_order() response parsing -- kept in sync so an
# order id extracted at submission time and one extracted during
# reconciliation use the same (best-guess) shape.
_ORDER_ID_KEYS = ("nOrdNo", "order_id", "orderId", "orderNo", "nOrdNoId")


def _looks_like_broker_error(payload) -> bool:
    """Thin alias kept so every call site below reads the same as before
    -- the real check is now response_is_error() (broker_client.py),
    verified against kotakneoapi 3.0.7's actual error shapes rather than
    guessed key names."""
    return response_is_error(payload)


def _extract_list(result) -> list:
    if isinstance(result, list):
        return result
    if isinstance(result, dict) and isinstance(result.get("data"), list):
        return result["data"]
    return []


def _extract_order_ids(rows: list) -> set[str]:
    ids: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        for key in _ORDER_ID_KEYS:
            if row.get(key):
                ids.add(str(row[key]))
                break
    return ids


async def _fetch(fetch):
    import asyncio

    # broker_client's methods are synchronous, blocking SDK calls (see
    # broker_client.py) -- run off the event loop so a slow reconciliation
    # fetch can't stall the HTTP server or WebSocket handling.
    return await asyncio.get_running_loop().run_in_executor(None, fetch)


async def reconcile_orders() -> None:
    """Real presence diff: every LIVE order this service submitted (has a
    broker_order_id) should appear in the broker's own order_report(), and
    every order_report() row should be traceable to a local order --
    anything on only one side is recorded as a discrepancy for a human to
    look at (never auto-corrected silently)."""
    from . import db as _db

    try:
        result = await _fetch(broker_client.order_report)
    except NotConfiguredError as exc:
        logger.info("orders reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="orders", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        logger.warning("orders reconciliation call failed: %s", exc)
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(
            reconciliation_type="orders", reference_id=None, discrepancy_found=True,
            details={"broker_response": result},
        )
        return

    broker_rows = _extract_list(result)
    broker_order_ids = _extract_order_ids(broker_rows)

    local_orders = _db.list_orders(limit=1000)
    local_live_submitted = [o for o in local_orders if o["mode"] == "LIVE" and o.get("broker_order_id")]
    local_order_ids = {o["broker_order_id"] for o in local_live_submitted}

    missing_from_broker = sorted(local_order_ids - broker_order_ids)  # we think we submitted these, broker doesn't show them
    missing_locally = sorted(broker_order_ids - local_order_ids)      # broker has these, we have no local record

    discrepancy_found = bool(missing_from_broker or missing_locally)
    _db.record_reconciliation(
        reconciliation_type="orders",
        reference_id=None,
        discrepancy_found=discrepancy_found,
        details={
            "broker_order_count": len(broker_rows),
            "local_live_submitted_count": len(local_live_submitted),
            "missing_from_broker": missing_from_broker,
            "missing_locally": missing_locally,
            "note": "presence-only diff -- see reconciliation.py docstring for why status values aren't compared",
        },
    )
    if discrepancy_found:
        logger.warning(
            "Order reconciliation discrepancy: %d order(s) we submitted are missing from the broker's book, "
            "%d broker order(s) have no local record.",
            len(missing_from_broker), len(missing_locally),
        )


async def reconcile_positions() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.positions)
    except NotConfiguredError as exc:
        logger.info("positions reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="positions", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="positions", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    rows = _extract_list(result)
    # Best-effort field extraction (unverified exact key names -- see
    # module docstring): the full raw row is always kept in `raw` for the
    # snapshot regardless of whether these specific keys matched.
    normalized = [
        {
            "trading_symbol": r.get("trdSym") or r.get("tradingSymbol") or r.get("trading_symbol"),
            "exchange_segment": r.get("exSeg") or r.get("exchangeSegment") or r.get("exchange_segment"),
            "product": r.get("prod") or r.get("product"),
            "quantity": r.get("flBuyQty") or r.get("netQty") or r.get("quantity"),
            "average_price": r.get("buyAvgPrc") or r.get("avgPrice") or r.get("average_price"),
            "raw": r,
        }
        for r in rows if isinstance(r, dict)
    ]
    _db.record_positions_snapshot(normalized)
    _db.record_reconciliation(
        reconciliation_type="positions", reference_id=None, discrepancy_found=False,
        details={"fetched_count": len(rows)},
    )


async def reconcile_holdings() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.holdings)
    except NotConfiguredError as exc:
        logger.info("holdings reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="holdings", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="holdings", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    rows = _extract_list(result)
    normalized = [
        {
            "trading_symbol": r.get("trdSym") or r.get("tradingSymbol") or r.get("trading_symbol"),
            "exchange_segment": r.get("exSeg") or r.get("exchangeSegment") or r.get("exchange_segment"),
            "quantity": r.get("qty") or r.get("quantity"),
            "average_price": r.get("avgPrc") or r.get("avgPrice") or r.get("average_price"),
            "raw": r,
        }
        for r in rows if isinstance(r, dict)
    ]
    _db.record_holdings_snapshot(normalized)
    _db.record_reconciliation(
        reconciliation_type="holdings", reference_id=None, discrepancy_found=False,
        details={"fetched_count": len(rows)},
    )


async def reconcile_funds() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.limits)
    except NotConfiguredError as exc:
        logger.info("funds reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    data = result.get("data") if isinstance(result, dict) else None
    row = data[0] if isinstance(data, list) and data else (data if isinstance(data, dict) else {})
    available = row.get("Net") or row.get("availableMargin") or row.get("available_margin") if isinstance(row, dict) else None
    used = row.get("MarginUsed") or row.get("usedMargin") or row.get("used_margin") if isinstance(row, dict) else None
    try:
        available = float(available) if available is not None else None
    except (TypeError, ValueError):
        available = None
    try:
        used = float(used) if used is not None else None
    except (TypeError, ValueError):
        used = None
    _db.record_funds_snapshot(available_margin=available, used_margin=used, raw=result if isinstance(result, dict) else {"raw": str(result)})
    _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=False, details={})


async def reconcile_trades() -> None:
    """Fetches trade_report() and persists individual fill/trade records
    into the `trades` table -- confirmed from source (services/
    trade_report.py) to be the real per-trade REST endpoint, distinct
    from the order feed's OrderData (which only carries an order's
    CUMULATIVE filled_quantity, not individual trade ids -- see
    websocket_manager.py's module docstring for that finding). This is
    therefore the authoritative source for individual trade records with
    their own broker_trade_id, used to populate the idempotent `trades`
    table this codebase has carried since Phase 1.

    HONEST SCOPE NOTE: trade_report()'s SUCCESS response is raw backend
    JSON with no SDK-level schema (confirmed from source: TradeReportAPI.
    trading_report() returns `.json()` directly) -- so the exact field
    names for trade id/order id/quantity/price below are best-effort, same
    documented status as limits()'s field extraction just above. Its ERROR
    shape ({"Error": e}) IS confirmed and handled via response_is_error().
    """
    from . import db as _db

    try:
        result = await _fetch(broker_client.trade_report)
    except NotConfiguredError as exc:
        logger.info("trades reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="trades", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="trades", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    rows = _extract_list(result)
    recorded = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        broker_order_id = None
        for key in _ORDER_ID_KEYS:
            if row.get(key):
                broker_order_id = str(row[key])
                break
        broker_trade_id = None
        for key in ("flDtTm", "trade_id", "tradeId", "exchTrdId", "nTrdNo"):
            if row.get(key):
                broker_trade_id = str(row[key])
                break
        fill_qty = None
        for key in ("fldQty", "filled_quantity", "flQty", "qty"):
            if row.get(key) is not None:
                try:
                    fill_qty = int(row[key])
                except (TypeError, ValueError):
                    pass
                break
        fill_price = None
        for key in ("avgPrc", "fill_price", "avgPrice", "prc"):
            if row.get(key) is not None:
                try:
                    fill_price = float(row[key])
                except (TypeError, ValueError):
                    pass
                break

        if not broker_trade_id or not broker_order_id:
            continue

        local_order = _db.get_order_by_broker_order_id(broker_order_id)
        order_id = local_order["id"] if local_order else None
        inserted = _db.record_trade(
            broker_trade_id=broker_trade_id, order_id=order_id, broker_order_id=broker_order_id,
            fill_quantity=fill_qty, fill_price=fill_price, fill_time=None, raw_payload=row,
        )
        if inserted:
            recorded += 1
            if local_order and fill_qty:
                total_filled = _db.sum_filled_quantity(order_id)
                new_status = "COMPLETE" if total_filled >= local_order["quantity"] else "PARTIALLY_FILLED"
                _db.update_order(internal_order_id=local_order["internal_order_id"], status=new_status)

    _db.record_reconciliation(
        reconciliation_type="trades", reference_id=None, discrepancy_found=False,
        details={"fetched_count": len(rows), "newly_recorded": recorded},
    )


async def run_full_reconciliation() -> None:
    """Called right after a successful connect() (broker_client.py) and on
    a periodic schedule while CONNECTED (main.py) -- per the safety
    requirement that a restart/reconnect must reconcile state before
    anything is trusted, and that state must not silently drift afterward.

    Surfaces RECONCILING on /status for the duration -- ONLY when the
    state was CONNECTED beforehand (never overwrites DISCONNECTED,
    SESSION_EXPIRED, an auth failure, etc. with a misleading "reconciling"
    label), and ONLY reverts back to CONNECTED afterward if nothing else
    changed the state while this ran (e.g. a session expiring mid-pass
    must keep SESSION_EXPIRED, not be silently overwritten back to
    CONNECTED just because reconciliation happened to finish after it).
    """
    from .state import BrokerState, current_state

    was_connected = current_state.state == BrokerState.CONNECTED
    if was_connected:
        current_state.transition(BrokerState.RECONCILING)
    try:
        await reconcile_orders()
        await reconcile_trades()
        await reconcile_positions()
        await reconcile_holdings()
        await reconcile_funds()
    finally:
        if was_connected and current_state.state == BrokerState.RECONCILING:
            current_state.transition(BrokerState.CONNECTED)
