"""REST-based reconciliation, run right after every successful connect
(see broker_client.py) and on a periodic schedule while CONNECTED (see
main.py's _background_maintenance_loop).

Phase 1C: orders/positions/holdings/funds are now actually persisted
locally (db.py's create_order/record_*_snapshot, populated by
order_service.py and the routes in server.py), so reconcile_orders() now
does a REAL presence diff between the broker's order book and this
service's own `orders` table -- not just "fetched successfully" like
before.

HONEST SCOPE NOTE, still true: Kotak's exact field names for order
id/status inside order_report()'s response could not be independently
verified against the official repository (see
broker-service/requirements.txt and app/sdk_conformance.py for the full
finding). So this diff is deliberately shallow and defensible without
guessing: it compares by broker_order_id PRESENCE only (does every
locally-known submitted LIVE order id appear somewhere in the broker's
order book, and vice versa) -- it does NOT attempt to map or compare
Kotak's specific status string values, since those field/value names are
equally unverified and a wrong mapping would be worse than no mapping.
"""
from __future__ import annotations

import logging

from .broker_client import broker_client, NotConfiguredError

logger = logging.getLogger("owner_trading.reconciliation")

# Same best-effort, documented-as-unverified key list used in
# order_service.py's place_order() response parsing -- kept in sync so an
# order id extracted at submission time and one extracted during
# reconciliation use the same (best-guess) shape.
_ORDER_ID_KEYS = ("nOrdNo", "order_id", "orderId", "orderNo", "nOrdNoId")


def _looks_like_broker_error(payload) -> bool:
    """Best-effort, non-authoritative check for whether a broker response
    shape looks like an error rather than data -- used only to decide
    discrepancy_found for the audit record, never to hide/suppress the
    raw payload (which is stored in full in `details`)."""
    return isinstance(payload, dict) and any(k in payload for k in ("error", "errMsg", "errCode"))


def _extract_list(result) -> list:
    if isinstance(result, list):
        return result
    if isinstance(result, dict) and isinstance(result.get("data"), list):
        return result["data"]
    return []


def _extract_order_ids(rows: list) -> set[str]:
    ids: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        for key in _ORDER_ID_KEYS:
            if row.get(key):
                ids.add(str(row[key]))
                break
    return ids


async def _fetch(fetch):
    import asyncio

    # broker_client's methods are synchronous, blocking SDK calls (see
    # broker_client.py) -- run off the event loop so a slow reconciliation
    # fetch can't stall the HTTP server or WebSocket handling.
    return await asyncio.get_running_loop().run_in_executor(None, fetch)


async def reconcile_orders() -> None:
    """Real presence diff: every LIVE order this service submitted (has a
    broker_order_id) should appear in the broker's own order_report(), and
    every order_report() row should be traceable to a local order --
    anything on only one side is recorded as a discrepancy for a human to
    look at (never auto-corrected silently)."""
    from . import db as _db

    try:
        result = await _fetch(broker_client.order_report)
    except NotConfiguredError as exc:
        logger.info("orders reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="orders", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        logger.warning("orders reconciliation call failed: %s", exc)
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(
            reconciliation_type="orders", reference_id=None, discrepancy_found=True,
            details={"broker_response": result},
        )
        return

    broker_rows = _extract_list(result)
    broker_order_ids = _extract_order_ids(broker_rows)

    local_orders = _db.list_orders(limit=1000)
    local_live_submitted = [o for o in local_orders if o["mode"] == "LIVE" and o.get("broker_order_id")]
    local_order_ids = {o["broker_order_id"] for o in local_live_submitted}

    missing_from_broker = sorted(local_order_ids - broker_order_ids)  # we think we submitted these, broker doesn't show them
    missing_locally = sorted(broker_order_ids - local_order_ids)      # broker has these, we have no local record

    discrepancy_found = bool(missing_from_broker or missing_locally)
    _db.record_reconciliation(
        reconciliation_type="orders",
        reference_id=None,
        discrepancy_found=discrepancy_found,
        details={
            "broker_order_count": len(broker_rows),
            "local_live_submitted_count": len(local_live_submitted),
            "missing_from_broker": missing_from_broker,
            "missing_locally": missing_locally,
            "note": "presence-only diff -- see reconciliation.py docstring for why status values aren't compared",
        },
    )
    if discrepancy_found:
        logger.warning(
            "Order reconciliation discrepancy: %d order(s) we submitted are missing from the broker's book, "
            "%d broker order(s) have no local record.",
            len(missing_from_broker), len(missing_locally),
        )


async def reconcile_positions() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.positions)
    except NotConfiguredError as exc:
        logger.info("positions reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="positions", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="positions", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    rows = _extract_list(result)
    # Best-effort field extraction (unverified exact key names -- see
    # module docstring): the full raw row is always kept in `raw` for the
    # snapshot regardless of whether these specific keys matched.
    normalized = [
        {
            "trading_symbol": r.get("trdSym") or r.get("tradingSymbol") or r.get("trading_symbol"),
            "exchange_segment": r.get("exSeg") or r.get("exchangeSegment") or r.get("exchange_segment"),
            "product": r.get("prod") or r.get("product"),
            "quantity": r.get("flBuyQty") or r.get("netQty") or r.get("quantity"),
            "average_price": r.get("buyAvgPrc") or r.get("avgPrice") or r.get("average_price"),
            "raw": r,
        }
        for r in rows if isinstance(r, dict)
    ]
    _db.record_positions_snapshot(normalized)
    _db.record_reconciliation(
        reconciliation_type="positions", reference_id=None, discrepancy_found=False,
        details={"fetched_count": len(rows)},
    )


async def reconcile_holdings() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.holdings)
    except NotConfiguredError as exc:
        logger.info("holdings reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="holdings", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="holdings", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    rows = _extract_list(result)
    normalized = [
        {
            "trading_symbol": r.get("trdSym") or r.get("tradingSymbol") or r.get("trading_symbol"),
            "exchange_segment": r.get("exSeg") or r.get("exchangeSegment") or r.get("exchange_segment"),
            "quantity": r.get("qty") or r.get("quantity"),
            "average_price": r.get("avgPrc") or r.get("avgPrice") or r.get("average_price"),
            "raw": r,
        }
        for r in rows if isinstance(r, dict)
    ]
    _db.record_holdings_snapshot(normalized)
    _db.record_reconciliation(
        reconciliation_type="holdings", reference_id=None, discrepancy_found=False,
        details={"fetched_count": len(rows)},
    )


async def reconcile_funds() -> None:
    from . import db as _db

    try:
        result = await _fetch(broker_client.limits)
    except NotConfiguredError as exc:
        logger.info("funds reconciliation skipped: %s", exc)
        return
    except Exception as exc:  # noqa: BLE001
        _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=True, details={"error": str(exc)[:500]})
        return

    if _looks_like_broker_error(result):
        _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=True, details={"broker_response": result})
        return

    data = result.get("data") if isinstance(result, dict) else None
    row = data[0] if isinstance(data, list) and data else (data if isinstance(data, dict) else {})
    available = row.get("Net") or row.get("availableMargin") or row.get("available_margin") if isinstance(row, dict) else None
    used = row.get("MarginUsed") or row.get("usedMargin") or row.get("used_margin") if isinstance(row, dict) else None
    try:
        available = float(available) if available is not None else None
    except (TypeError, ValueError):
        available = None
    try:
        used = float(used) if used is not None else None
    except (TypeError, ValueError):
        used = None
    _db.record_funds_snapshot(available_margin=available, used_margin=used, raw=result if isinstance(result, dict) else {"raw": str(result)})
    _db.record_reconciliation(reconciliation_type="funds", reference_id=None, discrepancy_found=False, details={})


async def run_full_reconciliation() -> None:
    """Called right after a successful connect() (broker_client.py) and on
    a periodic schedule while CONNECTED (main.py) -- per the safety
    requirement that a restart/reconnect must reconcile state before
    anything is trusted, and that state must not silently drift afterward.
    """
    await reconcile_orders()
    await reconcile_positions()
    await reconcile_holdings()
    await reconcile_funds()
