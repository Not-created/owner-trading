"""Tests for app/order_service.py -- the PAPER/LIVE order branch point.

Uses a real temporary migrated SQLite DB (same pattern as
test_idempotency.py) so order persistence is exercised for real, not
mocked -- and mocks ONLY the NeoAPI boundary for the LIVE path, same
convention as test_kotak_auth.py.

UPDATED: place_order()/modify_order()/cancel_order() now call the real,
source-verified kotakneoapi 3.0.7 signatures directly (see order_service.py's
module docstring and the "broker_params" workaround this replaced) -- tests
below assert the exact keyword arguments passed to broker_client, not a
passthrough dict.
"""
from __future__ import annotations

import asyncio
import dataclasses
import importlib
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock, patch

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro):
    return asyncio.run(coro)


class OrderServiceTestsBase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)

        from app import order_service as order_service_module

        importlib.reload(order_service_module)
        self.order_service = order_service_module
        self.db = db_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _live_cfg(self, **overrides):
        return dataclasses.replace(self.order_service.config, trading_mode="LIVE", **overrides)

    def _paper_cfg(self, **overrides):
        return dataclasses.replace(self.order_service.config, trading_mode="PAPER", **overrides)

    def _valid_payload(self, **overrides):
        payload = {
            "trading_symbol": "RELIANCE-EQ",
            "exchange_segment": "nse_cm",
            "transaction_type": "B",
            "order_type": "MKT",
            "product": "CNC",
            "quantity": 1,
        }
        payload.update(overrides)
        return payload


class ValidationTests(OrderServiceTestsBase):
    def test_rejects_missing_trading_symbol(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(trading_symbol="")))

    def test_rejects_invalid_transaction_type(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(transaction_type="X")))

    def test_rejects_limit_order_without_price(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(order_type="L", price=None)))

    def test_rejects_zero_quantity(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(quantity=0)))

    def test_rejects_missing_exchange_segment(self):
        """exchange_segment is MANDATORY on the real place_order() signature
        -- confirmed from kotakneoapi 3.0.7's source (an earlier version of
        this module treated it as optional)."""
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(exchange_segment="")))

    def test_rejects_invalid_exchange_segment(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(exchange_segment="NYSE")))

    def test_accepts_every_real_canonical_exchange_segment(self):
        for seg in ("nse_cm", "bse_cm", "nse_fo", "bse_fo"):
            with patch.object(self.order_service, "config", self._paper_cfg()):
                result = _run(self.order_service.place_order(self._valid_payload(exchange_segment=seg)))
            self.assertEqual(result["status"], "PAPER_ACCEPTED", msg=seg)

    def test_mcx_fo_rejects_ioc_validity(self):
        """settings.py's validity_allowed_by_segment restricts mcx_fo to
        DAY only -- confirmed from source."""
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(exchange_segment="mcx_fo", validity="IOC")))


class PaperModeTests(OrderServiceTestsBase):
    def test_paper_order_never_touches_broker_client(self):
        """The core safety guarantee: PAPER must never call Kotak."""
        with patch.object(self.order_service, "config", self._paper_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            result = _run(self.order_service.place_order(self._valid_payload()))

        fake_broker_client.place_order.assert_not_called()
        self.assertEqual(result["mode"], "PAPER")
        self.assertEqual(result["status"], "PAPER_ACCEPTED")
        self.assertIsNone(result["broker_order_id"])

    def test_paper_order_is_persisted_and_listable(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            _run(self.order_service.place_order(self._valid_payload()))
        orders = self.db.list_orders()
        self.assertEqual(len(orders), 1)
        self.assertEqual(orders[0]["trading_symbol"], "RELIANCE-EQ")

    def test_paper_order_writes_audit_log(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            _run(self.order_service.place_order(self._valid_payload()))
        logs = self.db.list_audit_logs()
        self.assertTrue(any(l["action"] == "order.create" for l in logs))

    def test_paper_cancel_never_touches_broker_client(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            order = _run(self.order_service.place_order(self._valid_payload()))
        with patch.object(self.order_service, "broker_client") as fake_broker_client:
            result = _run(self.order_service.cancel_order(order["internal_order_id"]))
        fake_broker_client.cancel_order.assert_not_called()
        self.assertEqual(result["status"], "CANCELLED")


class IdempotencyTests(OrderServiceTestsBase):
    """Requirement #55: prevent duplicate orders on request retry."""

    def test_replayed_idempotency_key_returns_same_order_not_a_new_one(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            first = _run(self.order_service.place_order(self._valid_payload(idempotency_key="retry-key-1")))
            second = _run(self.order_service.place_order(self._valid_payload(idempotency_key="retry-key-1")))

        self.assertEqual(first["internal_order_id"], second["internal_order_id"])
        self.assertEqual(len(self.db.list_orders()), 1)

    def test_different_idempotency_keys_create_separate_orders(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            _run(self.order_service.place_order(self._valid_payload(idempotency_key="key-a")))
            _run(self.order_service.place_order(self._valid_payload(idempotency_key="key-b")))
        self.assertEqual(len(self.db.list_orders()), 2)

    def test_no_idempotency_key_behaves_as_before(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            _run(self.order_service.place_order(self._valid_payload()))
            _run(self.order_service.place_order(self._valid_payload()))
        self.assertEqual(len(self.db.list_orders()), 2)


class RiskLimitTests(OrderServiceTestsBase):
    """Requirements #65-68: pre-trade risk limits."""

    def test_quantity_over_configured_max_is_rejected(self):
        cfg = self._paper_cfg(max_order_quantity=10)
        with patch.object(self.order_service, "config", cfg):
            with self.assertRaises(self.order_service.OrderValidationError):
                _run(self.order_service.place_order(self._valid_payload(quantity=11)))
        self.assertEqual(len(self.db.list_orders()), 0)

    def test_quantity_at_configured_max_is_allowed(self):
        cfg = self._paper_cfg(max_order_quantity=10)
        with patch.object(self.order_service, "config", cfg):
            result = _run(self.order_service.place_order(self._valid_payload(quantity=10)))
        self.assertEqual(result["status"], "PAPER_ACCEPTED")

    def test_zero_max_quantity_means_unlimited(self):
        cfg = self._paper_cfg(max_order_quantity=0)
        with patch.object(self.order_service, "config", cfg):
            result = _run(self.order_service.place_order(self._valid_payload(quantity=100000)))
        self.assertEqual(result["status"], "PAPER_ACCEPTED")

    def test_daily_order_count_limit_is_enforced(self):
        cfg = self._paper_cfg(max_orders_per_day=2)
        with patch.object(self.order_service, "config", cfg):
            _run(self.order_service.place_order(self._valid_payload()))
            _run(self.order_service.place_order(self._valid_payload()))
            with self.assertRaises(self.order_service.OrderValidationError):
                _run(self.order_service.place_order(self._valid_payload()))
        self.assertEqual(len(self.db.list_orders()), 2)

    def test_live_order_value_over_available_margin_is_rejected(self):
        self.db.record_funds_snapshot(available_margin=1000.0, used_margin=0.0, raw={})
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            with self.assertRaises(self.order_service.OrderValidationError):
                _run(self.order_service.place_order(self._valid_payload(order_type="L", price=500, quantity=10)))
        fake_broker_client.place_order.assert_not_called()

    def test_live_order_value_within_margin_proceeds_to_broker(self):
        self.db.record_funds_snapshot(available_margin=10000.0, used_margin=0.0, raw={})
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "1"}
            result = _run(self.order_service.place_order(self._valid_payload(order_type="L", price=500, quantity=10)))
        self.assertEqual(result["status"], "SUBMITTED")


class ModifyOrderTests(OrderServiceTestsBase):
    def test_paper_modify_updates_quantity_locally_without_broker_call(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            order = _run(self.order_service.place_order(self._valid_payload(quantity=5)))
            with patch.object(self.order_service, "broker_client") as fake_broker_client:
                result = _run(self.order_service.modify_order(order["internal_order_id"], {"quantity": 8}))
        fake_broker_client.modify_order.assert_not_called()
        self.assertEqual(result["quantity"], 8)
        self.assertEqual(result["status"], "MODIFIED")

    def test_modify_unknown_order_raises(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.modify_order("does-not-exist", {"quantity": 1}))

    def test_live_modify_calls_real_signature_with_current_values_filled_in(self):
        """order_type/validity are mandatory on the real modify_order()
        signature even when only quantity is changing -- confirmed from
        source. This module fills them in from the order's own stored
        values rather than requiring the caller to repeat everything."""
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "BROKER-1"}
            order = _run(self.order_service.place_order(self._valid_payload(order_type="L", price=100)))
            fake_broker_client.modify_order.return_value = {"stat": "Ok"}
            result = _run(self.order_service.modify_order(order["internal_order_id"], {"quantity": 2}))

        fake_broker_client.modify_order.assert_called_once_with(
            order_id="BROKER-1", price="100.0", order_type="L", quantity="2", validity="DAY", trigger_price="0",
        )
        self.assertEqual(result["status"], "MODIFY_REQUESTED")
        self.assertEqual(result["quantity"], 2)

    def test_live_modify_rejected_by_broker_is_recorded(self):
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "BROKER-1"}
            order = _run(self.order_service.place_order(self._valid_payload()))
            fake_broker_client.modify_order.return_value = {"Error Message": "Complete the 2fa process"}
            with self.assertRaises(self.order_service.OrderValidationError) as ctx:
                _run(self.order_service.modify_order(order["internal_order_id"], {"quantity": 2}))
        self.assertIn("2fa", str(ctx.exception))

    def test_modify_already_complete_order_raises(self):
        with patch.object(self.order_service, "config", self._paper_cfg()):
            order = _run(self.order_service.place_order(self._valid_payload()))
        self.db.update_order(internal_order_id=order["internal_order_id"], status="COMPLETE")
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.modify_order(order["internal_order_id"], {"quantity": 2}))


class LiveModeTests(OrderServiceTestsBase):
    """place_order() now calls the real, source-verified kotakneoapi 3.0.7
    signature directly: exchange_segment, product, price (str), order_type,
    quantity (str), validity, trading_symbol, transaction_type,
    trigger_price (str), tag -- no more caller-supplied broker_params
    workaround."""

    def test_live_order_calls_real_signature_with_string_price_and_quantity(self):
        """Confirmed from source: price/quantity/trigger_price must be
        STRINGS, not numbers -- an earlier version of this module would
        have sent the wrong types to a real account."""
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "230918000123456"}
            result = _run(self.order_service.place_order(
                self._valid_payload(order_type="L", price=101.5, quantity=7)
            ))

        fake_broker_client.place_order.assert_called_once()
        _, kwargs = fake_broker_client.place_order.call_args
        self.assertEqual(kwargs["exchange_segment"], "nse_cm")
        self.assertEqual(kwargs["price"], "101.5")
        self.assertEqual(kwargs["quantity"], "7")
        self.assertEqual(kwargs["trading_symbol"], "RELIANCE-EQ")
        self.assertEqual(kwargs["transaction_type"], "B")
        self.assertIsInstance(kwargs["price"], str)
        self.assertIsInstance(kwargs["quantity"], str)
        self.assertEqual(result["status"], "SUBMITTED")
        self.assertEqual(result["broker_order_id"], "230918000123456")

    def test_live_order_rejected_by_broker_capital_error_shape_is_recorded(self):
        """Confirmed from source: place_order()'s own exception handler
        returns {"Error": e} (capital E) -- not "errMsg"/"errCode", which
        an earlier, unverified version of this codebase checked for."""
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"Error": "insufficient margin"}
            result = _run(self.order_service.place_order(self._valid_payload()))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("insufficient margin", result["status_reason"])

    def test_live_order_rejected_by_broker_error_message_shape_is_recorded(self):
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"Error Message": "Complete the 2fa process before accessing this application"}
            result = _run(self.order_service.place_order(self._valid_payload()))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("2fa", result["status_reason"])

    def test_live_order_rejected_by_broker_lowercase_error_list_shape_is_recorded(self):
        """Confirmed from source: totp_login/totp_validate/quotes/
        search_scrip-style validation failures use {"error": [...]}
        (lowercase, a list) -- order.py's own internal exception handler
        uses {"error": ex} (lowercase, single object) -- both are
        recognized."""
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"error": [{"code": "900901", "message": "Invalid session"}]}
            result = _run(self.order_service.place_order(self._valid_payload()))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("Invalid session", result["status_reason"])

    def test_live_order_blocked_when_not_connected(self):
        """assert_live_trading_allowed() (broker_client.py) raising
        LiveTradingBlockedError must surface as a clean REJECTED order,
        not an unhandled exception."""
        from app.broker_client import LiveTradingBlockedError

        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.side_effect = LiveTradingBlockedError("Broker is not CONNECTED.")
            result = _run(self.order_service.place_order(self._valid_payload()))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("not CONNECTED", result["status_reason"])

    def test_live_cancel_calls_real_signature(self):
        with patch.object(self.order_service, "config", self._live_cfg()), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "BROKER-1"}
            order = _run(self.order_service.place_order(self._valid_payload()))
            fake_broker_client.cancel_order.return_value = {"stat": "Ok"}
            _run(self.order_service.cancel_order(order["internal_order_id"]))
        fake_broker_client.cancel_order.assert_called_once_with(order_id="BROKER-1", amo="NO")


if __name__ == "__main__":
    unittest.main()
