"""Tests for app/order_service.py -- the PAPER/LIVE order branch point.

Uses a real temporary migrated SQLite DB (same pattern as
test_idempotency.py) so order persistence is exercised for real, not
mocked -- and mocks ONLY the NeoAPI boundary for the LIVE path, same
convention as test_kotak_auth.py.
"""
from __future__ import annotations

import asyncio
import dataclasses
import importlib
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock, patch

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro):
    return asyncio.run(coro)


class OrderServiceTestsBase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)

        from app import order_service as order_service_module

        importlib.reload(order_service_module)
        self.order_service = order_service_module
        self.db = db_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _valid_payload(self, **overrides):
        payload = {
            "trading_symbol": "RELIANCE-EQ",
            "transaction_type": "B",
            "order_type": "MKT",
            "product": "CNC",
            "quantity": 1,
        }
        payload.update(overrides)
        return payload


class ValidationTests(OrderServiceTestsBase):
    def test_rejects_missing_trading_symbol(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(trading_symbol="")))

    def test_rejects_invalid_transaction_type(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(transaction_type="X")))

    def test_rejects_limit_order_without_price(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(order_type="L", price=None)))

    def test_rejects_zero_quantity(self):
        with self.assertRaises(self.order_service.OrderValidationError):
            _run(self.order_service.place_order(self._valid_payload(quantity=0)))


class PaperModeTests(OrderServiceTestsBase):
    def test_paper_order_never_touches_broker_client(self):
        """The core safety guarantee: PAPER must never call Kotak."""
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="PAPER")), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            result = _run(self.order_service.place_order(self._valid_payload()))

        fake_broker_client.place_order.assert_not_called()
        self.assertEqual(result["mode"], "PAPER")
        self.assertEqual(result["status"], "PAPER_ACCEPTED")
        self.assertIsNone(result["broker_order_id"])

    def test_paper_order_is_persisted_and_listable(self):
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="PAPER")):
            _run(self.order_service.place_order(self._valid_payload()))
        orders = self.db.list_orders()
        self.assertEqual(len(orders), 1)
        self.assertEqual(orders[0]["trading_symbol"], "RELIANCE-EQ")

    def test_paper_order_writes_audit_log(self):
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="PAPER")):
            _run(self.order_service.place_order(self._valid_payload()))
        logs = self.db.list_audit_logs()
        self.assertTrue(any(l["action"] == "order.create" for l in logs))

    def test_paper_cancel_never_touches_broker_client(self):
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="PAPER")):
            order = _run(self.order_service.place_order(self._valid_payload()))
        with patch.object(self.order_service, "broker_client") as fake_broker_client:
            result = _run(self.order_service.cancel_order(order["internal_order_id"]))
        fake_broker_client.cancel_order.assert_not_called()
        self.assertEqual(result["status"], "CANCELLED")


class LiveModeTests(OrderServiceTestsBase):
    def test_live_order_without_broker_params_is_rejected_not_guessed(self):
        """Core honesty guarantee: this module refuses to invent Kotak's
        place_order() parameter names -- see module docstring."""
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="LIVE")), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            result = _run(self.order_service.place_order(self._valid_payload()))

        fake_broker_client.place_order.assert_not_called()
        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("broker_params", result["status_reason"])

    def test_live_order_with_broker_params_calls_broker_and_records_id(self):
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="LIVE")), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"nOrdNo": "230918000123456"}
            payload = self._valid_payload(broker_params={"trading_symbol": "RELIANCE-EQ", "qty": 1})
            result = _run(self.order_service.place_order(payload))

        fake_broker_client.place_order.assert_called_once_with(trading_symbol="RELIANCE-EQ", qty=1)
        self.assertEqual(result["status"], "SUBMITTED")
        self.assertEqual(result["broker_order_id"], "230918000123456")

    def test_live_order_rejected_by_broker_is_recorded(self):
        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="LIVE")), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.return_value = {"errMsg": "insufficient margin"}
            payload = self._valid_payload(broker_params={"x": 1})
            result = _run(self.order_service.place_order(payload))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("insufficient margin", result["status_reason"])

    def test_live_order_blocked_when_not_connected(self):
        """assert_live_trading_allowed() (broker_client.py) raising
        LiveTradingBlockedError must surface as a clean REJECTED order,
        not an unhandled exception."""
        from app.broker_client import LiveTradingBlockedError

        with patch.object(self.order_service, "config", dataclasses.replace(self.order_service.config, trading_mode="LIVE")), \
             patch.object(self.order_service, "broker_client") as fake_broker_client:
            fake_broker_client.place_order.side_effect = LiveTradingBlockedError("Broker is not CONNECTED.")
            payload = self._valid_payload(broker_params={"x": 1})
            result = _run(self.order_service.place_order(payload))

        self.assertEqual(result["status"], "REJECTED")
        self.assertIn("not CONNECTED", result["status_reason"])


if __name__ == "__main__":
    unittest.main()
