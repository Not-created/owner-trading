"""Offline test suite for the broker service foundation. Uses only the
standard library (unittest, asyncio) so it runs without `pip install`ing
anything -- including without the `kotakneoapi` SDK itself installed, since
app/broker_client.py is required to degrade gracefully rather than crash
when the SDK is absent (see SDK_AVAILABLE).

Run from broker-service/:  python -m unittest discover -v
"""
import asyncio
import json
import unittest

from app.config import Config
from app.state import BrokerState, StateHolder
from app import broker_client as broker_client_module
from app.broker_client import BrokerClient, NotConfiguredError
from app.websocket_manager import SubscriptionRegistry
from app.secure_store import redact


class ConfigTests(unittest.TestCase):
    def test_not_configured_when_credentials_missing(self):
        cfg = Config(
            consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None
        )
        self.assertFalse(cfg.is_fully_configured())

    def test_configured_when_all_present(self):
        cfg = Config(
            consumer_key="x", mobile_number="y", ucc="z", totp_secret="t", mpin="m"
        )
        self.assertTrue(cfg.is_fully_configured())

    def test_partial_credentials_not_configured(self):
        cfg = Config(consumer_key="x", mobile_number="y", ucc=None, totp_secret=None, mpin=None)
        self.assertFalse(cfg.is_fully_configured())


class StateMachineTests(unittest.TestCase):
    def test_default_state_is_not_configured(self):
        holder = StateHolder()
        self.assertEqual(holder.state, BrokerState.NOT_CONFIGURED)

    def test_transition_updates_state_and_error(self):
        holder = StateHolder()
        holder.transition(BrokerState.CONNECTION_ERROR, "unreachable")
        self.assertEqual(holder.state, BrokerState.CONNECTION_ERROR)
        self.assertEqual(holder.last_error, "unreachable")

    def test_as_dict_is_json_serializable(self):
        holder = StateHolder()
        holder.transition(BrokerState.VERIFYING)
        json.dumps(holder.as_dict())  # raises if not serializable

    def test_all_seven_required_states_exist(self):
        expected = {
            "DISCONNECTED", "VERIFYING", "CONNECTED", "AUTH_FAILED",
            "SESSION_EXPIRED", "CONNECTION_ERROR", "NOT_CONFIGURED",
        }
        actual = {s.value for s in BrokerState}
        self.assertEqual(expected, actual)


class BrokerClientTests(unittest.TestCase):
    def test_market_data_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("quotes", "scrip_master", "search_scrip", "expiries", "option_chain", "historical_data"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_order_placing_methods_blocked_by_live_gate_in_paper_mode(self):
        # TRADING_MODE defaults to PAPER, so the LIVE safety gate fires
        # before the "not connected" check even applies.
        client = BrokerClient()
        for method_name in ("place_order", "modify_order", "cancel_order"):
            with self.assertRaises(broker_client_module.LiveTradingBlockedError, msg=method_name):
                getattr(client, method_name)()

    def test_order_reporting_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("order_report", "order_history", "trade_report"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_portfolio_methods_raise_when_not_connected(self):
        client = BrokerClient()
        for method_name in ("positions", "holdings", "limits", "margin_required"):
            with self.assertRaises(NotConfiguredError, msg=method_name):
                getattr(client, method_name)()

    def test_websocket_factories_raise_when_not_connected(self):
        client = BrokerClient()
        with self.assertRaises(NotConfiguredError):
            client.create_market_feed()
        with self.assertRaises(NotConfiguredError):
            client.create_order_feed()

    def test_connect_without_credentials_reports_not_configured(self):
        """connect() no longer raises for this phase -- it performs a real
        attempt and returns the resulting state. With nothing saved, that
        must be NOT_CONFIGURED (or CONNECTION_ERROR if the SDK itself isn't
        importable in this environment) -- never CONNECTED.
        """
        client = BrokerClient()

        async def run():
            result = await client.connect()
            self.assertIn(result["state"], ["NOT_CONFIGURED", "CONNECTION_ERROR"])
            self.assertNotEqual(result["state"], "CONNECTED")

        asyncio.run(run())

    def test_sdk_availability_flag_is_boolean(self):
        # Whatever the actual import outcome in this environment, the flag
        # must exist and be a bool -- broker_client.py must not crash the
        # whole module on ImportError.
        self.assertIsInstance(broker_client_module.SDK_AVAILABLE, bool)


class SubscriptionRegistryTests(unittest.TestCase):
    def test_add_remove_and_list(self):
        reg = SubscriptionRegistry()
        reg.add("TOKEN_A")
        reg.add("TOKEN_B")
        self.assertEqual(reg.all(), ["TOKEN_A", "TOKEN_B"])
        reg.remove("TOKEN_A")
        self.assertEqual(reg.all(), ["TOKEN_B"])

    def test_duplicate_add_is_idempotent(self):
        reg = SubscriptionRegistry()
        reg.add("TOKEN_A")
        reg.add("TOKEN_A")
        self.assertEqual(reg.all(), ["TOKEN_A"])


class SecureStoreTests(unittest.TestCase):
    def test_redact_empty(self):
        self.assertEqual(redact(None), "<empty>")
        self.assertEqual(redact(""), "<empty>")

    def test_redact_masks_all_but_last_two_chars(self):
        self.assertEqual(redact("ABCDEFGH"), "******GH")

    def test_redact_never_returns_the_original_for_a_real_looking_secret(self):
        secret = "super-secret-value-123"
        self.assertNotEqual(redact(secret), secret)


class ServerIntegrationTests(unittest.IsolatedAsyncioTestCase):
    """Actually starts the real asyncio server on an ephemeral local port
    and talks to it with a raw socket -- no mocking, no extra dependency.
    """

    async def asyncSetUp(self):
        from app.server import _handle_client  # noqa: PLC0415

        self.server = await asyncio.start_server(_handle_client, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]
        self._serve_task = asyncio.create_task(self.server.serve_forever())

    async def asyncTearDown(self):
        self._serve_task.cancel()
        self.server.close()
        await self.server.wait_closed()

    async def _get(self, path: str) -> tuple[int, dict]:
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        writer.write(f"GET {path} HTTP/1.1\r\nHost: localhost\r\n\r\n".encode())
        await writer.drain()
        raw = await asyncio.wait_for(reader.read(), timeout=5)
        writer.close()
        status_line, _, rest = raw.partition(b"\r\n")
        status_code = int(status_line.decode().split(" ")[1])
        _, _, body = rest.partition(b"\r\n\r\n")
        return status_code, json.loads(body.decode())

    async def test_health_endpoint(self):
        status, body = await self._get("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "ok"})

    async def test_status_endpoint_reflects_current_state(self):
        status, body = await self._get("/status")
        self.assertEqual(status, 200)
        self.assertIn("state", body)
        self.assertIn(body["state"], [s.value for s in BrokerState])

    async def test_unknown_path_is_404(self):
        status, _ = await self._get("/nope")
        self.assertEqual(status, 404)


class ServerNewRoutesTests(unittest.IsolatedAsyncioTestCase):
    """Phase 1C: HTTP-level tests for /funds, /positions, /holdings,
    /orders, /orders/cancel, /trades, /quotes, /scrip-search, /audit-logs.
    Same real-socket, no-mocking-the-transport approach as
    ServerIntegrationTests above, but with a real temporary migrated DB
    (same pattern as test_idempotency.py) since these routes actually
    read/write orders and audit logs.
    """

    async def asyncSetUp(self):
        import os
        import sqlite3
        import tempfile
        import importlib

        schema_path = os.path.join(
            os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
        )
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(schema_path, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        from app import order_service as order_service_module

        importlib.reload(order_service_module)

        from app.server import _handle_client  # noqa: PLC0415

        self.server = await asyncio.start_server(_handle_client, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]
        self._serve_task = asyncio.create_task(self.server.serve_forever())

    async def asyncTearDown(self):
        self._serve_task.cancel()
        self.server.close()
        await self.server.wait_closed()
        import os

        os.environ.pop("DB_PATH", None)

    async def _get(self, path: str) -> tuple[int, dict]:
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        writer.write(f"GET {path} HTTP/1.1\r\nHost: localhost\r\n\r\n".encode())
        await writer.drain()
        raw = await asyncio.wait_for(reader.read(), timeout=5)
        writer.close()
        status_line, _, rest = raw.partition(b"\r\n")
        status_code = int(status_line.decode().split(" ")[1])
        _, _, body = rest.partition(b"\r\n\r\n")
        return status_code, json.loads(body.decode())

    async def _post(self, path: str, payload: dict) -> tuple[int, dict]:
        body = json.dumps(payload).encode("utf-8")
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        request = (
            f"POST {path} HTTP/1.1\r\nHost: localhost\r\n"
            f"Content-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n"
        ).encode("utf-8") + body
        writer.write(request)
        await writer.drain()
        raw = await asyncio.wait_for(reader.read(), timeout=5)
        writer.close()
        status_line, _, rest = raw.partition(b"\r\n")
        status_code = int(status_line.decode().split(" ")[1])
        _, _, resp_body = rest.partition(b"\r\n\r\n")
        return status_code, json.loads(resp_body.decode())

    async def test_orders_list_starts_empty(self):
        status, body = await self._get("/orders")
        self.assertEqual(status, 200)
        self.assertEqual(body["orders"], [])

    async def test_place_paper_order_end_to_end_over_http(self):
        status, body = await self._post(
            "/orders",
            {
                "trading_symbol": "RELIANCE-EQ",
                "transaction_type": "B",
                "order_type": "MKT",
                "product": "CNC",
                "quantity": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["mode"], "PAPER")
        self.assertEqual(body["status"], "PAPER_ACCEPTED")

        # Confirm it's now visible through GET /orders too.
        status2, body2 = await self._get("/orders")
        self.assertEqual(status2, 200)
        self.assertEqual(len(body2["orders"]), 1)

    async def test_place_order_with_invalid_payload_is_400(self):
        status, body = await self._post("/orders", {"trading_symbol": ""})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    async def test_cancel_unknown_order_is_400(self):
        status, body = await self._post("/orders/cancel", {"internal_order_id": "does-not-exist"})
        self.assertEqual(status, 400)

    async def test_cancel_paper_order_over_http(self):
        _, placed = await self._post(
            "/orders",
            {
                "trading_symbol": "RELIANCE-EQ", "transaction_type": "B", "order_type": "MKT",
                "product": "CNC", "quantity": 1,
            },
        )
        status, body = await self._post("/orders/cancel", {"internal_order_id": placed["internal_order_id"]})
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "CANCELLED")

    async def test_funds_returns_409_when_not_connected(self):
        status, body = await self._get("/funds")
        self.assertEqual(status, 409)
        self.assertIn("error", body)

    async def test_positions_returns_409_when_not_connected(self):
        status, _ = await self._get("/positions")
        self.assertEqual(status, 409)

    async def test_holdings_returns_409_when_not_connected(self):
        status, _ = await self._get("/holdings")
        self.assertEqual(status, 409)

    async def test_trades_returns_409_when_not_connected(self):
        status, _ = await self._get("/trades")
        self.assertEqual(status, 409)

    async def test_audit_logs_reflects_order_actions(self):
        await self._post(
            "/orders",
            {
                "trading_symbol": "RELIANCE-EQ", "transaction_type": "B", "order_type": "MKT",
                "product": "CNC", "quantity": 1,
            },
        )
        status, body = await self._get("/audit-logs")
        self.assertEqual(status, 200)
        self.assertTrue(any(l["action"] == "order.create" for l in body["logs"]))

    async def test_modify_paper_order_over_http(self):
        _, placed = await self._post(
            "/orders",
            {
                "trading_symbol": "RELIANCE-EQ", "transaction_type": "B", "order_type": "MKT",
                "product": "CNC", "quantity": 1,
            },
        )
        status, body = await self._post(
            "/orders/modify", {"internal_order_id": placed["internal_order_id"], "quantity": 5}
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["quantity"], 5)
        self.assertEqual(body["status"], "MODIFIED")

    async def test_modify_unknown_order_is_400(self):
        status, body = await self._post("/orders/modify", {"internal_order_id": "nope", "quantity": 1})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    async def test_order_history_returns_409_when_not_connected(self):
        status, _ = await self._get("/order-history")
        self.assertEqual(status, 409)

    async def test_placing_order_twice_with_same_idempotency_key_over_http_is_a_no_op(self):
        payload = {
            "trading_symbol": "RELIANCE-EQ", "transaction_type": "B", "order_type": "MKT",
            "product": "CNC", "quantity": 1, "idempotency_key": "http-retry-key",
        }
        status1, body1 = await self._post("/orders", payload)
        status2, body2 = await self._post("/orders", payload)
        self.assertEqual(status1, 200)
        self.assertEqual(status2, 200)
        self.assertEqual(body1["internal_order_id"], body2["internal_order_id"])
        _, listing = await self._get("/orders")
        self.assertEqual(len(listing["orders"]), 1)


if __name__ == "__main__":
    unittest.main()
