"""Tests for app/websocket_manager.py -- rewritten against the real
kotakneoapi 3.0.7 async-context-manager / async-iterator WebSocket API
(see that module's docstring for what was confirmed directly from source).

Fakes the neo_api_client.websocket.feed/.orderfeed Pydantic message types
with lightweight duck-typed stand-ins carrying the exact confirmed
attribute names, registered under the real import paths so
websocket_manager.py's `isinstance()` checks and imports work unmodified
against real code, not a parallel test-only code path.
"""
from __future__ import annotations

import asyncio
import importlib
import os
import sqlite3
import sys
import tempfile
import types
import unittest
from unittest.mock import AsyncMock, patch

from app.sdk_conformance import ConformanceResult

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro, timeout=2):
    return asyncio.run(asyncio.wait_for(coro, timeout=timeout))


def _install_fake_feed_types():
    """Registers real-shaped fake classes under the exact module paths
    websocket_manager.py imports from, so isinstance() checks against
    "the real types" work in tests without the actual pydantic package
    installed (no network access to pip install it in this sandbox)."""

    class WsToken:
        def __init__(self, exchange_segment, instrument_token):
            self.exchange_segment = exchange_segment
            self.instrument_token = instrument_token

    class SFeedScrip:
        def __init__(self, exchange_segment, instrument_token, last_traded_price, trading_symbol=None):
            self.exchange_segment = exchange_segment
            self.instrument_token = instrument_token
            self.last_traded_price = last_traded_price
            self.trading_symbol = trading_symbol

    class SFeedScripLite(SFeedScrip):
        pass

    class SFeedIndex(SFeedScrip):
        pass

    class SFeedMarketStatus:
        pass

    feed_pkg = types.ModuleType("neo_api_client.websocket.feed")
    feed_pkg.WsToken = WsToken
    feed_pkg.SFeedScrip = SFeedScrip
    feed_pkg.SFeedScripLite = SFeedScripLite
    feed_pkg.SFeedIndex = SFeedIndex
    feed_pkg.SFeedMarketStatus = SFeedMarketStatus
    sys.modules["neo_api_client.websocket"] = types.ModuleType("neo_api_client.websocket")
    sys.modules["neo_api_client.websocket.feed"] = feed_pkg

    class OrderData:
        def __init__(self, order_id=None, order_status=None, average_price=None, quantity=None,
                     filled_quantity=None, symbol=None, exchange_segment=None):
            self.order_id = order_id
            self.order_status = order_status
            self.average_price = average_price
            self.quantity = quantity
            self.filled_quantity = filled_quantity
            self.symbol = symbol
            self.exchange_segment = exchange_segment

        def model_dump(self, by_alias=True):
            return {
                "nOrdNo": self.order_id, "ordSt": self.order_status, "avgPrc": self.average_price,
                "qty": self.quantity, "fldQty": self.filled_quantity,
            }

    class OrderUpdate:
        def __init__(self, data: OrderData):
            self.type = "order"
            self.data = data

    class PositionData:
        def __init__(self, symbol=None):
            self.symbol = symbol

    class PositionUpdate:
        def __init__(self, data: PositionData):
            self.type = "position"
            self.data = data

    orderfeed_pkg = types.ModuleType("neo_api_client.websocket.orderfeed")
    orderfeed_pkg.OrderData = OrderData
    orderfeed_pkg.OrderUpdate = OrderUpdate
    orderfeed_pkg.PositionData = PositionData
    orderfeed_pkg.PositionUpdate = PositionUpdate
    sys.modules["neo_api_client.websocket.orderfeed"] = orderfeed_pkg

    return types.SimpleNamespace(
        WsToken=WsToken, SFeedScrip=SFeedScrip, SFeedScripLite=SFeedScripLite, SFeedIndex=SFeedIndex,
        OrderData=OrderData, OrderUpdate=OrderUpdate, PositionData=PositionData, PositionUpdate=PositionUpdate,
    )


class FakeAsyncFeed:
    """A minimal async-context-manager + async-iterator stand-in for
    SFeedWebSocket/OrderFeedWebSocket -- the real usage pattern confirmed
    from source (see websocket_manager.py's module docstring)."""

    def __init__(self, messages=None, raise_on_enter=None):
        self._messages = list(messages or [])
        self.raise_on_enter = raise_on_enter
        self.subscribe_scrips = AsyncMock()
        self.unsubscribe_scrips = AsyncMock()
        self.entered = False

    async def __aenter__(self):
        if self.raise_on_enter:
            raise self.raise_on_enter
        self.entered = True
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.entered = False
        return False

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._messages:
            return self._messages.pop(0)
        # Block forever once messages are exhausted (mirrors a real idle
        # connection) -- tests that need this to end cancel the task
        # instead of waiting for a StopAsyncIteration that wouldn't be
        # realistic.
        await asyncio.sleep(3600)


class WebSocketManagerTestsBase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        self.db = db_module

        self.types = _install_fake_feed_types()

        from app import websocket_manager as ws_module
        from app.state import current_state, BrokerState

        importlib.reload(ws_module)
        self.ws_module = ws_module
        self.manager = ws_module.WebSocketManager()
        current_state.transition(BrokerState.CONNECTED)

    def tearDown(self):
        os.environ.pop("DB_PATH", None)
        for mod in ("neo_api_client.websocket", "neo_api_client.websocket.feed", "neo_api_client.websocket.orderfeed"):
            sys.modules.pop(mod, None)
        from app.state import current_state, BrokerState

        current_state.transition(BrokerState.DISCONNECTED)


class SubscriptionRegistryTests(unittest.TestCase):
    def test_add_and_all(self):
        from app.websocket_manager import SubscriptionRegistry

        reg = SubscriptionRegistry()
        reg.add("nse_cm", "11536")
        reg.add("bse_cm", "500325")
        self.assertEqual(reg.all(), [("bse_cm", "500325"), ("nse_cm", "11536")])

    def test_remove(self):
        from app.websocket_manager import SubscriptionRegistry

        reg = SubscriptionRegistry()
        reg.add("nse_cm", "11536")
        reg.remove("nse_cm", "11536")
        self.assertEqual(reg.all(), [])

    def test_duplicate_add_is_a_no_op(self):
        from app.websocket_manager import SubscriptionRegistry

        reg = SubscriptionRegistry()
        reg.add("nse_cm", "11536")
        reg.add("nse_cm", "11536")
        self.assertEqual(reg.all(), [("nse_cm", "11536")])


class StartStopLifecycleTests(WebSocketManagerTestsBase):
    def setUp(self):
        super().setUp()
        self._conformance_patch = patch("app.sdk_conformance.check_sdk_conformance", return_value=ConformanceResult(ok=True))
        self._conformance_patch.start()

    def tearDown(self):
        self._conformance_patch.stop()
        super().tearDown()

    def test_start_skipped_when_not_connected(self):
        from app.state import current_state, BrokerState

        current_state.transition(BrokerState.DISCONNECTED)
        _run(self.manager.start())
        self.assertEqual(self.manager.state, self.ws_module.FeedState.STOPPED)
        self.assertIsNone(self.manager._market_task)

    def test_start_launches_background_tasks_when_connected(self):
        fake_market = FakeAsyncFeed()
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                self.assertIsNotNone(self.manager._market_task)
                self.assertIsNotNone(self.manager._order_task)
                await self.manager.stop()

        _run(scenario())

    def test_stop_cancels_running_tasks(self):
        fake_market = FakeAsyncFeed()
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                await self.manager.stop()

        _run(scenario())
        self.assertEqual(self.manager.state, self.ws_module.FeedState.STOPPED)
        self.assertIsNone(self.manager._market_task)

    def test_double_start_is_a_no_op(self):
        fake_market = FakeAsyncFeed()
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                first_task = self.manager._market_task
                await self.manager.start()
                self.assertIs(self.manager._market_task, first_task)
                await self.manager.stop()

        _run(scenario())


class MarketFeedRunLoopTests(WebSocketManagerTestsBase):
    def setUp(self):
        super().setUp()
        self._conformance_patch = patch("app.sdk_conformance.check_sdk_conformance", return_value=ConformanceResult(ok=True))
        self._conformance_patch.start()

    def tearDown(self):
        self._conformance_patch.stop()
        super().tearDown()

    def test_subscribes_registry_tokens_on_connect(self):
        self.manager.registry.add("nse_cm", "11536")
        fake_market = FakeAsyncFeed()
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                await asyncio.sleep(0.05)
                await self.manager.stop()

        _run(scenario())
        fake_market.subscribe_scrips.assert_called_once()
        (tokens_arg,), _ = fake_market.subscribe_scrips.call_args
        self.assertEqual(len(tokens_arg), 1)
        self.assertEqual(tokens_arg[0].exchange_segment, "nse_cm")
        self.assertEqual(tokens_arg[0].instrument_token, "11536")

    def test_market_message_is_persisted_via_run_loop(self):
        tick = self.types.SFeedScrip(exchange_segment="nse_cm", instrument_token="11536", last_traded_price=101.5)
        fake_market = FakeAsyncFeed(messages=[tick])
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                await asyncio.sleep(0.05)
                await self.manager.stop()

        _run(scenario())
        ticks = self.db.latest_market_ticks()
        self.assertEqual(len(ticks), 1)
        self.assertEqual(ticks[0]["last_traded_price"], 101.5)

    def test_connect_failure_is_caught_and_retried_not_left_to_crash(self):
        """A failed __aenter__ (e.g. a dropped connection) must not crash
        the background task -- it's caught, logged to last_error, and the
        outer loop backs off and retries (real backoff -- checked while
        still mid-sleep, well under the >=2s first delay) rather than
        dying silently."""
        fake_market = FakeAsyncFeed(raise_on_enter=ConnectionError("dropped"))
        fake_order = FakeAsyncFeed()

        async def scenario():
            with patch.object(self.ws_module, "broker_client") as fake_bc:
                fake_bc.create_market_feed.return_value = fake_market
                fake_bc.create_order_feed.return_value = fake_order
                await self.manager.start()
                await asyncio.sleep(0.05)
                self.assertIsNotNone(self.manager._market_task)
                self.assertFalse(self.manager._market_task.done())
                self.assertIn("dropped", self.manager.last_error or "")
                await self.manager.stop()

        _run(scenario())


class StalenessTests(WebSocketManagerTestsBase):
    def test_not_stale_when_not_connected(self):
        self.assertFalse(self.manager.is_stale())

    def test_not_stale_right_after_a_message(self):
        self.manager.state = self.ws_module.FeedState.CONNECTED
        import time

        self.manager._last_message_at = time.time()
        self.assertFalse(self.manager.is_stale())

    def test_stale_after_threshold_exceeded(self):
        self.manager.state = self.ws_module.FeedState.CONNECTED
        self.manager._last_message_at = 0  # epoch -- long, long ago
        self.assertTrue(self.manager.is_stale())


class MarketMessageHandlingTests(WebSocketManagerTestsBase):
    def test_scrip_message_is_persisted(self):
        tick = self.types.SFeedScrip(exchange_segment="nse_cm", instrument_token="11536", last_traded_price=101.5)
        self.manager._on_market_message(tick)
        ticks = self.db.latest_market_ticks()
        self.assertEqual(len(ticks), 1)
        self.assertEqual(ticks[0]["instrument_token"], "11536")
        self.assertEqual(ticks[0]["last_traded_price"], 101.5)

    def test_scrip_lite_message_is_also_persisted(self):
        tick = self.types.SFeedScripLite(exchange_segment="nse_cm", instrument_token="1", last_traded_price=50.0)
        self.manager._on_market_message(tick)
        self.assertEqual(len(self.db.latest_market_ticks()), 1)

    def test_index_message_is_also_persisted(self):
        tick = self.types.SFeedIndex(exchange_segment="nse_cm", instrument_token="NIFTY", last_traded_price=22000.0)
        self.manager._on_market_message(tick)
        self.assertEqual(len(self.db.latest_market_ticks()), 1)

    def test_repeated_tick_updates_same_row_not_duplicates(self):
        self.manager._on_market_message(self.types.SFeedScrip("nse_cm", "1", 100.0))
        self.manager._on_market_message(self.types.SFeedScrip("nse_cm", "1", 105.0))
        ticks = self.db.latest_market_ticks()
        self.assertEqual(len(ticks), 1)
        self.assertEqual(ticks[0]["last_traded_price"], 105.0)

    def test_unrecognized_message_type_does_not_raise(self):
        self.manager._on_market_message(object())  # must not raise
        self.assertEqual(self.db.latest_market_ticks(), [])


class OrderMessageHandlingTests(WebSocketManagerTestsBase):
    def _place_live_order(self, quantity=10) -> dict:
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment="nse_cm",
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=quantity, price=0.0, trigger_price=0.0, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-1",
        )
        return self.db.get_order("int-1")

    def test_raw_payload_always_recorded(self):
        self._place_live_order()
        order_data = self.types.OrderData(order_id="BROKER-1", filled_quantity=0, quantity=10)
        self.manager._on_order_message(self.types.OrderUpdate(order_data))
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM order_events").fetchone()[0]
        self.assertEqual(count, 1)

    def test_full_fill_marks_order_complete(self):
        self._place_live_order(quantity=10)
        order_data = self.types.OrderData(order_id="BROKER-1", filled_quantity=10, quantity=10, order_status="complete")
        self.manager._on_order_message(self.types.OrderUpdate(order_data))
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "COMPLETE")

    def test_partial_fill_marks_order_partially_filled(self):
        self._place_live_order(quantity=10)
        order_data = self.types.OrderData(order_id="BROKER-1", filled_quantity=4, quantity=10)
        self.manager._on_order_message(self.types.OrderUpdate(order_data))
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "PARTIALLY_FILLED")

    def test_zero_fill_does_not_change_status(self):
        self._place_live_order(quantity=10)
        order_data = self.types.OrderData(order_id="BROKER-1", filled_quantity=0, quantity=10, order_status="open")
        self.manager._on_order_message(self.types.OrderUpdate(order_data))
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "SUBMITTED")  # unchanged
        self.assertIn("open", order["status_reason"])

    def test_message_for_unknown_broker_order_id_does_not_raise(self):
        order_data = self.types.OrderData(order_id="NEVER-PLACED", filled_quantity=1, quantity=1)
        self.manager._on_order_message(self.types.OrderUpdate(order_data))  # must not raise

    def test_position_update_does_not_raise_and_is_not_persisted_as_order(self):
        position_data = self.types.PositionData(symbol="RELIANCE-EQ")
        self.manager._on_order_message(self.types.PositionUpdate(position_data))  # must not raise
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM order_events").fetchone()[0]
        self.assertEqual(count, 0)

    def test_unrecognized_message_type_does_not_raise(self):
        self.manager._on_order_message(object())


if __name__ == "__main__":
    unittest.main()
