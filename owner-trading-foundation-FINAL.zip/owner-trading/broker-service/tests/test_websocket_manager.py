"""Tests for app/websocket_manager.py and the websocket-shape detection in
app/sdk_conformance.py.

Uses a real temporary migrated SQLite DB (same pattern as
test_idempotency.py / test_order_service.py) since message handling
actually persists to market_data_state/order_events/trades/orders.
"""
from __future__ import annotations

import asyncio
import importlib
import os
import sqlite3
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro):
    return asyncio.run(coro)


def _install_fake_neo_api_client(methods: list[str]) -> None:
    fake_module = types.ModuleType("neo_api_client")

    class FakeNeoAPI:
        def __init__(self, consumer_key=None, environment=None, **kwargs):
            pass

    for name in methods:
        setattr(FakeNeoAPI, name, lambda self, *a, **k: None)
    fake_module.NeoAPI = FakeNeoAPI
    sys.modules["neo_api_client"] = fake_module


class ShapeDetectionTests(unittest.TestCase):
    def tearDown(self):
        sys.modules.pop("neo_api_client", None)

    def test_current_shape_detected(self):
        from app.sdk_conformance import detect_websocket_api_shape, _CURRENT_SHAPE_METHODS

        _install_fake_neo_api_client(list(_CURRENT_SHAPE_METHODS))
        self.assertEqual(detect_websocket_api_shape(), "current")

    def test_legacy_shape_detected(self):
        from app.sdk_conformance import detect_websocket_api_shape, _LEGACY_SHAPE_METHODS

        _install_fake_neo_api_client(list(_LEGACY_SHAPE_METHODS))
        self.assertEqual(detect_websocket_api_shape(), "legacy")

    def test_neither_shape_returns_none(self):
        from app.sdk_conformance import detect_websocket_api_shape

        _install_fake_neo_api_client(["totp_login"])  # unrelated methods only
        self.assertIsNone(detect_websocket_api_shape())

    def test_missing_module_returns_none(self):
        from app.sdk_conformance import detect_websocket_api_shape

        sys.modules.pop("neo_api_client", None)
        self.assertIsNone(detect_websocket_api_shape())

    def test_current_shape_preferred_when_both_present(self):
        from app.sdk_conformance import detect_websocket_api_shape, _CURRENT_SHAPE_METHODS, _LEGACY_SHAPE_METHODS

        _install_fake_neo_api_client(list(_CURRENT_SHAPE_METHODS) + list(_LEGACY_SHAPE_METHODS))
        self.assertEqual(detect_websocket_api_shape(), "current")


class WebSocketManagerTestsBase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        self.db = db_module

        from app import websocket_manager as ws_module
        from app.state import current_state, BrokerState

        importlib.reload(ws_module)
        self.ws_module = ws_module
        self.manager = ws_module.WebSocketManager()
        current_state.transition(BrokerState.CONNECTED)

    def tearDown(self):
        os.environ.pop("DB_PATH", None)
        sys.modules.pop("neo_api_client", None)
        from app.state import current_state, BrokerState

        current_state.transition(BrokerState.DISCONNECTED)


class StartLifecycleTests(WebSocketManagerTestsBase):
    def test_start_fails_clearly_when_no_shape_detected(self):
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value=None):
            with self.assertRaises(RuntimeError) as ctx:
                _run(self.manager.start())
        self.assertIn("neither the current", str(ctx.exception))
        self.assertEqual(self.manager.state, self.ws_module.FeedState.FAILED)

    def test_start_current_shape_opens_both_feeds_and_connects(self):
        fake_market_feed = MagicMock()
        fake_order_feed = MagicMock()
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="current"), \
             patch.object(self.ws_module, "broker_client") as fake_bc:
            fake_bc.create_market_feed.return_value = fake_market_feed
            fake_bc.create_order_feed.return_value = fake_order_feed
            _run(self.manager.start())

        self.assertEqual(self.manager.state, self.ws_module.FeedState.CONNECTED)
        fake_market_feed.on_message.assert_called_once()

    def test_start_legacy_shape_uses_broker_client_as_feed(self):
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="legacy"), \
             patch.object(self.ws_module, "broker_client") as fake_bc:
            _run(self.manager.start())
        self.assertEqual(self.manager.state, self.ws_module.FeedState.CONNECTED)
        self.assertIs(self.manager._market_feed, fake_bc)

    def test_start_fails_when_callback_registration_impossible(self):
        class NoCallbackFeed:
            pass  # no on_message, no on()

        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="current"), \
             patch.object(self.ws_module, "broker_client") as fake_bc:
            fake_bc.create_market_feed.return_value = NoCallbackFeed()
            fake_bc.create_order_feed.return_value = NoCallbackFeed()
            with self.assertRaises(RuntimeError) as ctx:
                _run(self.manager.start())
        self.assertIn("could not register a message callback", str(ctx.exception))

    def test_start_skipped_when_not_connected(self):
        from app.state import current_state, BrokerState

        current_state.transition(BrokerState.DISCONNECTED)
        _run(self.manager.start())  # no exception -- just a no-op
        self.assertEqual(self.manager.state, self.ws_module.FeedState.STOPPED)

    def test_start_resubscribes_existing_registry(self):
        self.manager.registry.add("TOKEN-1")
        self.manager.registry.add("TOKEN-2")
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="current"), \
             patch.object(self.ws_module, "broker_client") as fake_bc:
            fake_bc.create_market_feed.return_value = MagicMock()
            fake_bc.create_order_feed.return_value = MagicMock()
            _run(self.manager.start())
        fake_bc.subscribe_scrips.assert_called_once_with(["TOKEN-1", "TOKEN-2"])


class ReconnectTests(WebSocketManagerTestsBase):
    def test_reconnect_gives_up_after_max_attempts_and_sets_connection_error(self):
        from app.state import current_state, BrokerState

        self.manager._max_reconnect_attempts = 2
        self.manager._running = True
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value=None), \
             patch("asyncio.sleep", return_value=None):
            _run(self.manager.reconnect_with_backoff())
        self.assertEqual(self.manager.state, self.ws_module.FeedState.FAILED)
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)

    def test_successful_reconnect_triggers_reconciliation(self):
        self.manager._running = True
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="current"), \
             patch.object(self.ws_module, "broker_client") as fake_bc, \
             patch("asyncio.sleep", return_value=None):
            fake_bc.create_market_feed.return_value = MagicMock()
            fake_bc.create_order_feed.return_value = MagicMock()
            with patch("app.reconciliation.run_full_reconciliation") as fake_reconcile:
                fake_reconcile.return_value = _make_awaitable(None)
                _run(self.manager.reconnect_with_backoff())
                fake_reconcile.assert_called_once()
        self.assertEqual(self.manager.state, self.ws_module.FeedState.CONNECTED)

    def test_reconnect_resubscribes_everything_in_registry(self):
        self.manager.registry.add("TOKEN-A")
        self.manager._running = True
        with patch.object(self.ws_module, "detect_websocket_api_shape", return_value="current"), \
             patch.object(self.ws_module, "broker_client") as fake_bc, \
             patch("asyncio.sleep", return_value=None), \
             patch("app.reconciliation.run_full_reconciliation", return_value=_make_awaitable(None)):
            fake_bc.create_market_feed.return_value = MagicMock()
            fake_bc.create_order_feed.return_value = MagicMock()
            _run(self.manager.reconnect_with_backoff())
        fake_bc.subscribe_scrips.assert_called_with(["TOKEN-A"])


def _make_awaitable(result):
    async def _coro():
        return result

    return _coro()


class StalenessTests(WebSocketManagerTestsBase):
    def test_not_stale_when_not_connected(self):
        self.assertFalse(self.manager.is_stale())

    def test_not_stale_right_after_a_message(self):
        self.manager.state = self.ws_module.FeedState.CONNECTED
        import time

        self.manager._last_message_at = time.time()
        self.assertFalse(self.manager.is_stale())

    def test_stale_after_threshold_exceeded(self):
        self.manager.state = self.ws_module.FeedState.CONNECTED
        self.manager._last_message_at = 0  # epoch -- long, long ago
        self.assertTrue(self.manager.is_stale())


class MarketMessageHandlingTests(WebSocketManagerTestsBase):
    def test_tick_with_recognized_fields_is_persisted(self):
        self.manager._on_market_message({"tk": "12345", "ltp": 101.5, "e": "nse_cm"})
        ticks = self.db.latest_market_ticks()
        self.assertEqual(len(ticks), 1)
        self.assertEqual(ticks[0]["instrument_token"], "12345")
        self.assertEqual(ticks[0]["last_traded_price"], 101.5)

    def test_tick_updates_last_message_at(self):
        self.assertIsNone(self.manager._last_message_at)
        self.manager._on_market_message({"tk": "1", "ltp": 1})
        self.assertIsNotNone(self.manager._last_message_at)

    def test_unrecognized_tick_shape_does_not_raise(self):
        self.manager._on_market_message({"nonsense": True})  # must not raise
        self.assertEqual(self.db.latest_market_ticks(), [])

    def test_repeated_tick_updates_same_row_not_duplicates(self):
        self.manager._on_market_message({"tk": "1", "ltp": 100, "e": "nse_cm"})
        self.manager._on_market_message({"tk": "1", "ltp": 105, "e": "nse_cm"})
        ticks = self.db.latest_market_ticks()
        self.assertEqual(len(ticks), 1)
        self.assertEqual(ticks[0]["last_traded_price"], 105)


class OrderMessageHandlingTests(WebSocketManagerTestsBase):
    def _place_live_order(self) -> dict:
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=10, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-1",
        )
        return self.db.get_order("int-1")

    def test_raw_payload_always_recorded_even_without_recognized_fields(self):
        self.manager._on_order_message({"weird": "shape"})
        logs = self.db.list_audit_logs()  # not the check -- verifying via order_events count instead
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM order_events").fetchone()[0]
        self.assertEqual(count, 1)

    def test_full_fill_marks_order_complete(self):
        self._place_live_order()
        self.manager._on_order_message({
            "nOrdNo": "BROKER-1", "fldQty": 10, "avgPrc": 250.5, "flDtTm": "trade-1",
        })
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "COMPLETE")

    def test_partial_fill_marks_order_partially_filled(self):
        self._place_live_order()
        self.manager._on_order_message({
            "nOrdNo": "BROKER-1", "fldQty": 4, "avgPrc": 250.5, "flDtTm": "trade-1",
        })
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "PARTIALLY_FILLED")

    def test_two_partial_fills_sum_to_complete(self):
        self._place_live_order()
        self.manager._on_order_message({"nOrdNo": "BROKER-1", "fldQty": 4, "avgPrc": 250, "flDtTm": "trade-1"})
        self.manager._on_order_message({"nOrdNo": "BROKER-1", "fldQty": 6, "avgPrc": 251, "flDtTm": "trade-2"})
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "COMPLETE")
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        self.assertEqual(count, 2)

    def test_duplicate_fill_event_is_idempotent(self):
        self._place_live_order()
        msg = {"nOrdNo": "BROKER-1", "fldQty": 10, "avgPrc": 250, "flDtTm": "trade-1"}
        self.manager._on_order_message(msg)
        self.manager._on_order_message(dict(msg))  # exact same fill re-delivered
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        self.assertEqual(count, 1)

    def test_message_for_unknown_broker_order_id_does_not_raise(self):
        self.manager._on_order_message({"nOrdNo": "NEVER-PLACED", "fldQty": 1, "avgPrc": 1, "flDtTm": "t"})
        # must not raise; nothing to assert on the (nonexistent) local order

    def test_status_only_message_updates_reason_not_status(self):
        self._place_live_order()
        self.manager._on_order_message({"nOrdNo": "BROKER-1", "status": "open"})
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "SUBMITTED")  # unchanged
        self.assertIn("open", order["status_reason"])


if __name__ == "__main__":
    unittest.main()
