"""Tests app/db.py's idempotent writes against a REAL temporary SQLite
database, migrated with the actual schema
(backend/src/db/migrations/001_init.sql) -- not a mock. This is the
concrete verification for "duplicate-event protection / idempotency".
"""
import os
import sqlite3
import tempfile
import unittest

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


class IdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            schema_sql = f.read()
        conn = sqlite3.connect(self.db_path)
        conn.executescript(schema_sql)
        conn.commit()
        conn.close()

        # Point app.db at this temp file for the duration of the test,
        # then restore the module's DB_PATH afterwards.
        os.environ["DB_PATH"] = self.db_path
        global db
        from app import db as db_module

        import importlib

        importlib.reload(db_module)
        self.db = db_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_duplicate_order_event_is_ignored(self):
        payload = {"stCode": 200, "ordSt": "open"}
        first = self.db.record_order_event(
            event_source="order_feed_ws", broker_event_id="evt-1", raw_payload=payload
        )
        second = self.db.record_order_event(
            event_source="order_feed_ws", broker_event_id="evt-1", raw_payload=payload
        )
        self.assertTrue(first)
        self.assertFalse(second)  # duplicate correctly ignored, not double-inserted

        conn = sqlite3.connect(self.db_path)
        count = conn.execute("SELECT COUNT(*) FROM order_events").fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)

    def test_different_event_sources_are_independent(self):
        payload = {"x": 1}
        a = self.db.record_order_event(event_source="order_feed_ws", broker_event_id="evt-1", raw_payload=payload)
        b = self.db.record_order_event(event_source="order_report_rest", broker_event_id="evt-1", raw_payload=payload)
        self.assertTrue(a)
        self.assertTrue(b)  # same broker_event_id but different source -- not a duplicate

    def test_partial_fills_each_recorded_once(self):
        fill_1 = self.db.record_trade(
            broker_trade_id="trade-1", order_id=None, broker_order_id="B1",
            fill_quantity=5, fill_price=100.0, fill_time=None, raw_payload={},
        )
        fill_2 = self.db.record_trade(
            broker_trade_id="trade-2", order_id=None, broker_order_id="B1",
            fill_quantity=5, fill_price=101.0, fill_time=None, raw_payload={},
        )
        duplicate_of_fill_1 = self.db.record_trade(
            broker_trade_id="trade-1", order_id=None, broker_order_id="B1",
            fill_quantity=5, fill_price=100.0, fill_time=None, raw_payload={},
        )
        self.assertTrue(fill_1)
        self.assertTrue(fill_2)
        self.assertFalse(duplicate_of_fill_1)

        conn = sqlite3.connect(self.db_path)
        count = conn.execute("SELECT COUNT(*) FROM trades WHERE broker_order_id = 'B1'").fetchone()[0]
        conn.close()
        self.assertEqual(count, 2)  # two distinct partial fills, duplicate not double-counted

    def test_emergency_stop_defaults_inactive(self):
        self.assertFalse(self.db.is_emergency_stop_active())

    def test_emergency_stop_read_reflects_db_state(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("UPDATE emergency_stop_state SET is_active = 1 WHERE id = 1")
        conn.commit()
        conn.close()
        self.assertTrue(self.db.is_emergency_stop_active())

    def test_reconciliation_record_written(self):
        self.db.record_reconciliation(
            reconciliation_type="order_status", reference_id="B1", discrepancy_found=True, details={"note": "mismatch"}
        )
        conn = sqlite3.connect(self.db_path)
        count = conn.execute("SELECT COUNT(*) FROM reconciliation_records").fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)


if __name__ == "__main__":
    unittest.main()
