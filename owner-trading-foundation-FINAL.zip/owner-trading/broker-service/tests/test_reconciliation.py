"""Tests for app/reconciliation.py's real presence-diff logic (Phase 1C)."""
from __future__ import annotations

import asyncio
import importlib
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro):
    return asyncio.run(coro)


class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        self.db = db_module

        from app import reconciliation as reconciliation_module

        importlib.reload(reconciliation_module)
        self.reconciliation = reconciliation_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_matching_orders_report_no_discrepancy(self):
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-123",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": [{"nOrdNo": "BROKER-123", "status": "open"}]}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertFalse(records["discrepancy_found"])
        self.assertEqual(records["details"]["missing_from_broker"], [])
        self.assertEqual(records["details"]["missing_locally"], [])

    def test_order_missing_from_broker_is_flagged(self):
        """We think we submitted it (have a broker_order_id locally), but
        it doesn't show up in the broker's own order book -- a real
        discrepancy worth surfacing, not silently ignored."""
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-999",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": []}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertTrue(records["discrepancy_found"])
        self.assertIn("BROKER-999", records["details"]["missing_from_broker"])

    def test_order_missing_locally_is_flagged(self):
        """The broker has an order we have no local record of -- e.g.
        manually placed outside this app -- also a real discrepancy."""
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": [{"nOrdNo": "MYSTERY-1"}]}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertTrue(records["discrepancy_found"])
        self.assertIn("MYSTERY-1", records["details"]["missing_locally"])

    def test_paper_orders_never_counted_in_diff(self):
        """A PAPER order has no broker_order_id and must never be treated
        as something that should appear in the broker's real order book."""
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="PAPER", status="PAPER_ACCEPTED",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": []}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertFalse(records["discrepancy_found"])
        self.assertEqual(records["details"]["local_live_submitted_count"], 0)

    def _latest_reconciliation(self, reconciliation_type: str) -> dict:
        import sqlite3

        conn = sqlite3.connect(self.db_path)
        row = conn.execute(
            "SELECT discrepancy_found, details FROM reconciliation_records WHERE reconciliation_type = ? ORDER BY id DESC LIMIT 1",
            (reconciliation_type,),
        ).fetchone()
        conn.close()
        import json

        return {"discrepancy_found": bool(row[0]), "details": json.loads(row[1])}


class RunFullReconciliationStateTests(unittest.TestCase):
    """Requirement (final production pass): /status should show RECONCILING
    while a reconciliation pass runs, and correctly revert to CONNECTED
    afterward -- but never invent a RECONCILING label for a broker that
    wasn't CONNECTED to begin with, and never clobber a state change that
    happened during the pass (e.g. a session expiring mid-reconciliation).
    """

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)

        from app import reconciliation as reconciliation_module

        importlib.reload(reconciliation_module)
        self.reconciliation = reconciliation_module

        from app.state import current_state, BrokerState

        self.current_state = current_state
        self.BrokerState = BrokerState

    def tearDown(self):
        os.environ.pop("DB_PATH", None)
        self.current_state.transition(self.BrokerState.NOT_CONFIGURED)

    def test_reconciling_shown_while_running_and_reverts_to_connected(self):
        self.current_state.transition(self.BrokerState.CONNECTED)
        seen_state_during_run = {}

        async def fake_reconcile_orders():
            seen_state_during_run["state"] = self.current_state.state

        with patch.object(self.reconciliation, "reconcile_orders", fake_reconcile_orders), \
             patch.object(self.reconciliation, "reconcile_positions", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_holdings", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_funds", return_value=_noop()):
            _run(self.reconciliation.run_full_reconciliation())

        self.assertEqual(seen_state_during_run["state"], self.BrokerState.RECONCILING)
        self.assertEqual(self.current_state.state, self.BrokerState.CONNECTED)

    def test_never_shows_reconciling_when_not_connected(self):
        self.current_state.transition(self.BrokerState.DISCONNECTED)
        with patch.object(self.reconciliation, "reconcile_orders", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_positions", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_holdings", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_funds", return_value=_noop()):
            _run(self.reconciliation.run_full_reconciliation())
        self.assertEqual(self.current_state.state, self.BrokerState.DISCONNECTED)

    def test_does_not_clobber_a_state_change_that_happened_during_the_pass(self):
        self.current_state.transition(self.BrokerState.CONNECTED)

        async def reconcile_that_expires_the_session():
            self.current_state.transition(self.BrokerState.SESSION_EXPIRED)

        with patch.object(self.reconciliation, "reconcile_orders", reconcile_that_expires_the_session), \
             patch.object(self.reconciliation, "reconcile_positions", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_holdings", return_value=_noop()), \
             patch.object(self.reconciliation, "reconcile_funds", return_value=_noop()):
            _run(self.reconciliation.run_full_reconciliation())

        self.assertEqual(self.current_state.state, self.BrokerState.SESSION_EXPIRED)


async def _noop():
    return None


class ReconcileTradesTests(unittest.TestCase):
    """reconcile_trades() -- the real per-trade source (trade_report()),
    distinct from the order feed's cumulative-only OrderData (see
    websocket_manager.py's module docstring)."""

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        self.db = db_module

        from app import reconciliation as reconciliation_module

        importlib.reload(reconciliation_module)
        self.reconciliation = reconciliation_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _place_live_order(self, quantity=10) -> dict:
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment="nse_cm",
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=quantity, price=0.0, trigger_price=0.0, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-1",
        )

    def test_trade_is_persisted_and_linked_to_local_order(self):
        self._place_live_order(quantity=10)
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.trade_report.return_value = {
                "data": [{"nOrdNo": "BROKER-1", "nTrdNo": "TRADE-1", "fldQty": "10", "avgPrc": "250.5"}]
            }
            _run(self.reconciliation.reconcile_trades())

        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute("SELECT broker_trade_id, fill_quantity, fill_price FROM trades").fetchone()
        self.assertEqual(row, ("TRADE-1", 10, 250.5))
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "COMPLETE")

    def test_duplicate_trade_id_is_idempotent(self):
        self._place_live_order(quantity=10)
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.trade_report.return_value = {
                "data": [{"nOrdNo": "BROKER-1", "nTrdNo": "TRADE-1", "fldQty": "10", "avgPrc": "250.5"}]
            }
            _run(self.reconciliation.reconcile_trades())
            _run(self.reconciliation.reconcile_trades())  # same trade re-fetched on next pass
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        self.assertEqual(count, 1)

    def test_partial_fill_trade_marks_order_partially_filled(self):
        self._place_live_order(quantity=10)
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.trade_report.return_value = {
                "data": [{"nOrdNo": "BROKER-1", "nTrdNo": "TRADE-1", "fldQty": "4", "avgPrc": "250"}]
            }
            _run(self.reconciliation.reconcile_trades())
        order = self.db.get_order("int-1")
        self.assertEqual(order["status"], "PARTIALLY_FILLED")

    def test_trade_error_response_is_recorded_as_discrepancy(self):
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.trade_report.return_value = {"Error": "session expired"}
            _run(self.reconciliation.reconcile_trades())
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT discrepancy_found FROM reconciliation_records WHERE reconciliation_type = 'trades' ORDER BY id DESC LIMIT 1"
            ).fetchone()
        self.assertEqual(row[0], 1)

    def test_trade_with_no_matching_local_order_is_skipped_gracefully(self):
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.trade_report.return_value = {
                "data": [{"nOrdNo": "UNKNOWN-ORDER", "nTrdNo": "TRADE-1", "fldQty": "1", "avgPrc": "1"}]
            }
            _run(self.reconciliation.reconcile_trades())  # must not raise
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        self.assertEqual(count, 1)  # trade still recorded, just with order_id=NULL


if __name__ == "__main__":
    unittest.main()
