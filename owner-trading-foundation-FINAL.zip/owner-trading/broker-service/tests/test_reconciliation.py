"""Tests for app/reconciliation.py's real presence-diff logic (Phase 1C)."""
from __future__ import annotations

import asyncio
import importlib
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

SCHEMA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "backend", "src", "db", "migrations", "001_init.sql"
)


def _run(coro):
    return asyncio.run(coro)


class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp_dir, "test.db")
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(self.db_path)
            conn.executescript(f.read())
            conn.commit()
            conn.close()
        os.environ["DB_PATH"] = self.db_path

        from app import db as db_module

        importlib.reload(db_module)
        self.db = db_module

        from app import reconciliation as reconciliation_module

        importlib.reload(reconciliation_module)
        self.reconciliation = reconciliation_module

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_matching_orders_report_no_discrepancy(self):
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-123",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": [{"nOrdNo": "BROKER-123", "status": "open"}]}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertFalse(records["discrepancy_found"])
        self.assertEqual(records["details"]["missing_from_broker"], [])
        self.assertEqual(records["details"]["missing_locally"], [])

    def test_order_missing_from_broker_is_flagged(self):
        """We think we submitted it (have a broker_order_id locally), but
        it doesn't show up in the broker's own order book -- a real
        discrepancy worth surfacing, not silently ignored."""
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED",
            broker_order_id="BROKER-999",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": []}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertTrue(records["discrepancy_found"])
        self.assertIn("BROKER-999", records["details"]["missing_from_broker"])

    def test_order_missing_locally_is_flagged(self):
        """The broker has an order we have no local record of -- e.g.
        manually placed outside this app -- also a real discrepancy."""
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": [{"nOrdNo": "MYSTERY-1"}]}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertTrue(records["discrepancy_found"])
        self.assertIn("MYSTERY-1", records["details"]["missing_locally"])

    def test_paper_orders_never_counted_in_diff(self):
        """A PAPER order has no broker_order_id and must never be treated
        as something that should appear in the broker's real order book."""
        self.db.create_order(
            internal_order_id="int-1", trading_symbol="RELIANCE-EQ", exchange_segment=None,
            transaction_type="B", order_type="MKT", product="CNC", validity="DAY",
            quantity=1, price=None, trigger_price=None, mode="PAPER", status="PAPER_ACCEPTED",
        )
        with patch.object(self.reconciliation, "broker_client") as fake_bc:
            fake_bc.order_report.return_value = {"data": []}
            _run(self.reconciliation.reconcile_orders())

        records = self._latest_reconciliation("orders")
        self.assertFalse(records["discrepancy_found"])
        self.assertEqual(records["details"]["local_live_submitted_count"], 0)

    def _latest_reconciliation(self, reconciliation_type: str) -> dict:
        import sqlite3

        conn = sqlite3.connect(self.db_path)
        row = conn.execute(
            "SELECT discrepancy_found, details FROM reconciliation_records WHERE reconciliation_type = ? ORDER BY id DESC LIMIT 1",
            (reconciliation_type,),
        ).fetchone()
        conn.close()
        import json

        return {"discrepancy_found": bool(row[0]), "details": json.loads(row[1])}


if __name__ == "__main__":
    unittest.main()
