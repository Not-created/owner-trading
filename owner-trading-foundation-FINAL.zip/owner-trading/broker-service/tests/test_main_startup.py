"""Tests for app/main.py's startup state-determination logic, in
particular the env-var -> credential_manager bridge added in Phase 1.
Mocks only the SDK-availability boundary (same pattern as
test_kotak_auth.py) so the actual bridging logic is exercised for real.
"""
from __future__ import annotations

import unittest
from unittest.mock import patch

from app import main as main_module
from app import broker_client as bc_module
from app import credential_manager as cm_module
from app.config import Config
from app.state import BrokerState, current_state
from app.sdk_conformance import ConformanceResult

# These tests exercise the env-var -> credential_manager bridge, not SDK
# conformance (that has its own tests -- see test_sdk_conformance.py) --
# and this sandbox has no real network access to `pip install kotakneoapi`,
# so neo_api_client genuinely isn't importable here. Patch the conformance
# check itself to a passing result wherever SDK_AVAILABLE=True is also
# patched, so these tests reflect the credential-bridging logic regardless
# of what happens to be pip-installed in whatever environment runs them.
_PASSING_CONFORMANCE = ConformanceResult(ok=True, checked=["totp_login"], missing=[], warnings=[])


class InitialStateTests(unittest.TestCase):
    def setUp(self):
        current_state.transition(BrokerState.NOT_CONFIGURED)
        cm_module.credential_manager.clear()

    def test_sdk_unavailable_short_circuits_to_connection_error(self):
        with patch.object(bc_module, "SDK_AVAILABLE", False):
            main_module._determine_initial_state()
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)
        self.assertFalse(cm_module.credential_manager.has_base_credentials())

    def test_no_env_credentials_reports_not_configured(self):
        empty_config = Config(
            consumer_key=None, mobile_number=None, ucc=None, totp_secret=None, mpin=None
        )
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(main_module, "config", empty_config), \
             patch("app.sdk_conformance.check_sdk_conformance", return_value=_PASSING_CONFORMANCE):
            main_module._determine_initial_state()
        self.assertEqual(current_state.state, BrokerState.NOT_CONFIGURED)

    def test_full_env_credentials_load_into_credential_manager_but_stay_disconnected(self):
        """The core bridge this test guards: a fully-configured
        broker.env must end up usable by connect() (i.e. present in
        credential_manager) -- but startup must NEVER itself claim
        CONNECTED just because credentials exist.
        """
        full_config = Config(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", totp_secret="SECRET", mpin="1234"
        )
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(main_module, "config", full_config), \
             patch("app.sdk_conformance.check_sdk_conformance", return_value=_PASSING_CONFORMANCE):
            main_module._determine_initial_state()

        self.assertEqual(current_state.state, BrokerState.DISCONNECTED)
        self.assertTrue(cm_module.credential_manager.has_base_credentials())
        loaded = cm_module.credential_manager.get()
        self.assertEqual(loaded.consumer_key, "ck")
        self.assertEqual(loaded.ucc, "ABC123")

    def test_sdk_conformance_failure_short_circuits_to_connection_error(self):
        """New behavior (final audit): SDK_AVAILABLE=True is not enough --
        if the installed package is missing methods this codebase calls,
        startup must land in CONNECTION_ERROR, not silently proceed as if
        the SDK were usable."""
        full_config = Config(
            consumer_key="ck", mobile_number="9999999999", ucc="ABC123", totp_secret="SECRET", mpin="1234"
        )
        failing = ConformanceResult(ok=False, checked=[], missing=["place_order"], warnings=[])
        with patch.object(bc_module, "SDK_AVAILABLE", True), patch.object(main_module, "config", full_config), \
             patch("app.sdk_conformance.check_sdk_conformance", return_value=failing):
            main_module._determine_initial_state()
        self.assertEqual(current_state.state, BrokerState.CONNECTION_ERROR)


if __name__ == "__main__":
    unittest.main()
