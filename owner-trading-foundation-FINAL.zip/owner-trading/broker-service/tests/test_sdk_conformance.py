"""Tests for app/sdk_conformance.py -- the runtime introspection check that
verifies whatever kotakneoapi package is ACTUALLY installed in this
deployment against every symbol this codebase calls (both NeoAPI methods
and the WebSocket feed/orderfeed Pydantic types) -- confirmed against the
real kotakneoapi 3.0.7 source, not guessed (see that module's docstring).
"""
from __future__ import annotations

import sys
import types
import unittest

from app.sdk_conformance import check_sdk_conformance, _REQUIRED_NEOAPI_METHODS


def _install_fake_neo_api_client(methods: list[str], *, with_feed_types: bool = True, with_orderfeed_types: bool = True) -> None:
    fake_module = types.ModuleType("neo_api_client")

    class FakeNeoAPI:
        def __init__(self, consumer_key=None, environment=None, **kwargs):
            pass

    for name in methods:
        setattr(FakeNeoAPI, name, lambda self, *a, **k: None)

    fake_module.NeoAPI = FakeNeoAPI
    sys.modules["neo_api_client"] = fake_module

    # Real kotakneoapi 3.0.7 exposes these as subpackages
    # (neo_api_client.websocket.feed / .orderfeed) -- faked the same way
    # here so check_sdk_conformance()'s import of them can be controlled
    # per test.
    websocket_pkg = types.ModuleType("neo_api_client.websocket")
    sys.modules["neo_api_client.websocket"] = websocket_pkg

    if with_feed_types:
        feed_pkg = types.ModuleType("neo_api_client.websocket.feed")
        for name in ("WsToken", "SFeedScrip", "SFeedScripLite", "SFeedIndex", "SFeedMarketStatus"):
            setattr(feed_pkg, name, type(name, (), {}))
        sys.modules["neo_api_client.websocket.feed"] = feed_pkg
    else:
        sys.modules.pop("neo_api_client.websocket.feed", None)

    if with_orderfeed_types:
        orderfeed_pkg = types.ModuleType("neo_api_client.websocket.orderfeed")
        for name in ("OrderUpdate", "OrderData", "PositionUpdate", "PositionData"):
            setattr(orderfeed_pkg, name, type(name, (), {}))
        sys.modules["neo_api_client.websocket.orderfeed"] = orderfeed_pkg
    else:
        sys.modules.pop("neo_api_client.websocket.orderfeed", None)


class SdkConformanceTests(unittest.TestCase):
    def tearDown(self):
        for mod in ("neo_api_client", "neo_api_client.websocket", "neo_api_client.websocket.feed", "neo_api_client.websocket.orderfeed"):
            sys.modules.pop(mod, None)

    def test_missing_module_fails_cleanly(self):
        sys.modules.pop("neo_api_client", None)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("import failed" in m for m in result.missing))

    def test_fully_matching_sdk_passes(self):
        _install_fake_neo_api_client(_REQUIRED_NEOAPI_METHODS)
        result = check_sdk_conformance()
        self.assertTrue(result.ok, msg=result.summary())
        self.assertEqual(result.missing, [])

    def test_missing_required_neoapi_method_fails(self):
        methods = [m for m in _REQUIRED_NEOAPI_METHODS if m != "place_order"]
        _install_fake_neo_api_client(methods)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("place_order" in m for m in result.missing))

    def test_missing_create_websocket_fails(self):
        """UPDATED: create_websocket/create_order_feed are now REQUIRED,
        not a soft warning -- confirmed from kotakneoapi 3.0.7's real
        source that these are the only working WebSocket path (the
        legacy subscribe()/un_subscribe() methods always raise
        NotImplementedError), so a deployment missing them cannot do
        real-time streaming at all and conformance must fail, not warn."""
        methods = [m for m in _REQUIRED_NEOAPI_METHODS if m != "create_websocket"]
        _install_fake_neo_api_client(methods)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("create_websocket" in m for m in result.missing))

    def test_missing_feed_types_fails(self):
        _install_fake_neo_api_client(_REQUIRED_NEOAPI_METHODS, with_feed_types=False)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("websocket.feed" in m for m in result.missing))

    def test_missing_orderfeed_types_fails(self):
        _install_fake_neo_api_client(_REQUIRED_NEOAPI_METHODS, with_orderfeed_types=False)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("websocket.orderfeed" in m for m in result.missing))


if __name__ == "__main__":
    unittest.main()
