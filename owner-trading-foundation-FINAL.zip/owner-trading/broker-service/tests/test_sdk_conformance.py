"""Tests for app/sdk_conformance.py -- the runtime introspection check
added in the final audit (see that module's docstring for why it exists:
the real SDK source could not be conclusively verified from outside a
real deployment, so the running system verifies itself against whatever
is actually installed instead of trusting any single external doc).
"""
from __future__ import annotations

import sys
import types
import unittest

from app.sdk_conformance import check_sdk_conformance, _REQUIRED_NEOAPI_METHODS


def _install_fake_neo_api_client(methods: list[str]) -> None:
    fake_module = types.ModuleType("neo_api_client")

    class FakeNeoAPI:
        def __init__(self, consumer_key=None, environment=None, **kwargs):
            pass

    for name in methods:
        setattr(FakeNeoAPI, name, lambda self, *a, **k: None)

    fake_module.NeoAPI = FakeNeoAPI
    sys.modules["neo_api_client"] = fake_module


class SdkConformanceTests(unittest.TestCase):
    def tearDown(self):
        sys.modules.pop("neo_api_client", None)

    def test_missing_module_fails_cleanly(self):
        sys.modules.pop("neo_api_client", None)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertTrue(any("import failed" in m for m in result.missing))

    def test_fully_matching_sdk_passes(self):
        _install_fake_neo_api_client(_REQUIRED_NEOAPI_METHODS + ["create_websocket", "create_order_feed"])
        result = check_sdk_conformance()
        self.assertTrue(result.ok, msg=result.summary())
        self.assertEqual(result.missing, [])

    def test_missing_required_method_fails(self):
        methods = [m for m in _REQUIRED_NEOAPI_METHODS if m != "place_order"]
        _install_fake_neo_api_client(methods)
        result = check_sdk_conformance()
        self.assertFalse(result.ok)
        self.assertIn("place_order", result.missing)

    def test_missing_websocket_methods_is_only_a_warning(self):
        """WebSocket streaming isn't activated yet this phase (see
        websocket_manager.py) -- its absence must not block REST-only
        operation (auth, orders, portfolio, reconciliation)."""
        _install_fake_neo_api_client(_REQUIRED_NEOAPI_METHODS)  # no create_websocket/create_order_feed
        result = check_sdk_conformance()
        self.assertTrue(result.ok, msg=result.summary())
        self.assertTrue(any("create_websocket" in w for w in result.warnings))


if __name__ == "__main__":
    unittest.main()
