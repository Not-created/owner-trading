const config = require("../config");
const { BROKER_STATES, getBrokerConnectionState, setBrokerConnectionState } = require("./brokerState");

/**
 * Talks to the persistent Python broker service over local HTTP only.
 * Express never talks to Kotak directly.
 *
 * Phase 1: Express DOES receive Kotak credentials from the Settings UI (an
 * authenticated session is required -- see routes/brokerKotak.js) and
 * forwards them to the broker service over the loopback HTTP call below.
 * Express itself never stores, logs, or returns them -- every function
 * here that carries a `credentials` argument passes it straight through
 * in the request body and nowhere else; nothing in this file or its
 * caller writes that argument to a log, a database column, or an HTTP
 * response.
 */

async function _postToBroker(path, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.brokerServiceTimeoutMs);
  try {
    const res = await fetch(`${config.brokerServiceUrl}${path}`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    clearTimeout(timeout);
    let parsed = null;
    try {
      parsed = await res.json();
    } catch {
      // non-JSON body -- parsed stays null, ok/status still tell the caller enough
    }
    return { ok: res.ok, status: res.status, body: parsed };
  } catch (err) {
    clearTimeout(timeout);
    return { ok: false, status: 0, body: null, networkError: err.message };
  }
}

/**
 * GET /status equivalent -- refreshes from the broker service, mirrors
 * into SQLite, and returns the resulting state. Never fabricates
 * CONNECTED -- if the broker service is unreachable, this reports exactly
 * that.
 */
async function fetchBrokerStatus() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.brokerServiceTimeoutMs);

  try {
    const res = await fetch(`${config.brokerServiceUrl}/status`, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) {
      setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, `broker service returned HTTP ${res.status}`);
      return getBrokerConnectionState();
    }

    const body = await res.json();
    const state = Object.values(BROKER_STATES).includes(body.state) ? body.state : BROKER_STATES.CONNECTION_ERROR;
    setBrokerConnectionState(state, body.last_error || null);
    return getBrokerConnectionState();
  } catch (err) {
    clearTimeout(timeout);
    setBrokerConnectionState(BROKER_STATES.CONNECTION_ERROR, "broker service unreachable: " + err.message);
    return getBrokerConnectionState();
  }
}

/**
 * Forwards credentials to the broker service (which holds them in-memory
 * only -- see broker-service/app/credential_manager.py). Returns whether
 * the broker service accepted them; does not itself attempt a connection.
 */
async function saveCredentials({ consumerKey, mobileNumber, ucc, mpin, totpSecret }) {
  const result = await _postToBroker("/credentials", {
    consumerKey,
    mobileNumber,
    ucc,
    mpin,
    totpSecret,
  });
  if (!result.ok) {
    setBrokerConnectionState(
      BROKER_STATES.CONNECTION_ERROR,
      result.networkError ? `broker service unreachable: ${result.networkError}` : "broker service rejected credentials"
    );
  }
  return result;
}

async function credentialsStatus() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.brokerServiceTimeoutMs);
  try {
    const res = await fetch(`${config.brokerServiceUrl}/credentials/status`, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return { ok: false, status: res.status, body: null };
    return { ok: true, status: res.status, body: await res.json() };
  } catch (err) {
    clearTimeout(timeout);
    return { ok: false, status: 0, body: null, networkError: err.message };
  }
}

/** Real auth attempt that does NOT persist a session -- see broker_client.py's test_connection(). */
async function testConnection() {
  return _postToBroker("/test", null);
}

/** Real auth attempt that DOES persist a session on success and updates the shared state machine. */
async function connect() {
  const result = await _postToBroker("/connect", null);
  if (result.ok && result.body) {
    const state = Object.values(BROKER_STATES).includes(result.body.state)
      ? result.body.state
      : BROKER_STATES.CONNECTION_ERROR;
    setBrokerConnectionState(state, result.body.last_error || null);
  } else {
    setBrokerConnectionState(
      BROKER_STATES.CONNECTION_ERROR,
      result.networkError ? `broker service unreachable: ${result.networkError}` : "connect request failed"
    );
  }
  return result;
}

async function disconnect() {
  const result = await _postToBroker("/disconnect", null);
  if (result.ok && result.body) {
    const state = Object.values(BROKER_STATES).includes(result.body.state)
      ? result.body.state
      : BROKER_STATES.DISCONNECTED;
    setBrokerConnectionState(state, result.body.last_error || null);
  }
  return result;
}

async function reconnect() {
  const result = await _postToBroker("/reconnect", null);
  if (result.ok && result.body) {
    const state = Object.values(BROKER_STATES).includes(result.body.state)
      ? result.body.state
      : BROKER_STATES.CONNECTION_ERROR;
    setBrokerConnectionState(state, result.body.last_error || null);
  } else {
    setBrokerConnectionState(
      BROKER_STATES.CONNECTION_ERROR,
      result.networkError ? `broker service unreachable: ${result.networkError}` : "reconnect request failed"
    );
  }
  return result;
}

async function _getFromBroker(path) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.brokerServiceTimeoutMs);
  try {
    const res = await fetch(`${config.brokerServiceUrl}${path}`, { signal: controller.signal });
    clearTimeout(timeout);
    let parsed = null;
    try {
      parsed = await res.json();
    } catch {
      // non-JSON body
    }
    return { ok: res.ok, status: res.status, body: parsed };
  } catch (err) {
    clearTimeout(timeout);
    return { ok: false, status: 0, body: null, networkError: err.message };
  }
}

module.exports = {
  fetchBrokerStatus, saveCredentials, credentialsStatus, testConnection, connect, disconnect, reconnect,
  // Phase 1C -- real portfolio/order/market-data proxying. Every function
  // here is a thin, honest pass-through to the Python broker service (see
  // broker-service/app/server.py for what each path actually does); none
  // of them compute, aggregate, or fabricate anything Express-side.
  getFunds: () => _getFromBroker("/funds"),
  getPositions: () => _getFromBroker("/positions"),
  getHoldings: () => _getFromBroker("/holdings"),
  getOrders: (limit) => _getFromBroker(`/orders${limit ? `?limit=${encodeURIComponent(limit)}` : ""}`),
  placeOrder: (payload) => _postToBroker("/orders", payload),
  modifyOrder: (internalOrderId, payload) => _postToBroker("/orders/modify", { ...payload, internal_order_id: internalOrderId }),
  cancelOrder: (internalOrderId, amo) =>
    _postToBroker("/orders/cancel", { internal_order_id: internalOrderId, amo: amo || "NO" }),
  getTrades: () => _getFromBroker("/trades"),
  getOrderHistory: () => _getFromBroker("/order-history"),
  getQuotes: (payload) => _postToBroker("/quotes", payload),
  searchScrip: (payload) => _postToBroker("/scrip-search", payload),
  getAuditLogs: (limit) => _getFromBroker(`/audit-logs${limit ? `?limit=${encodeURIComponent(limit)}` : ""}`),
  getMarketTicks: () => _getFromBroker("/market-ticks"),
};
