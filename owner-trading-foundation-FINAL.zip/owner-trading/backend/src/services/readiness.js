const { getBrokerConnectionState, BROKER_STATES } = require("./brokerState");

// Application-level readiness, distinct from broker connection state.
// "READY" only ever means "the app itself is up and its own dependencies
// (DB, sessions) are fine" -- it does NOT mean broker/live trading is
// ready. The dashboard must combine this with broker state before
// suggesting anything is available for trading.
const READINESS_STATES = Object.freeze({
  INSTALLING: "INSTALLING",
  STARTING: "STARTING",
  READY: "READY",
  DEGRADED: "DEGRADED",
  EMERGENCY_STOP: "EMERGENCY_STOP",
});

let appReadiness = READINESS_STATES.STARTING;

function markReady() {
  appReadiness = READINESS_STATES.READY;
}

function markDegraded() {
  appReadiness = READINESS_STATES.DEGRADED;
}

function getReadinessSnapshot() {
  const broker = getBrokerConnectionState();
  return {
    application: appReadiness,
    broker: broker.state,
    // Convenience flag for the frontend: true only when the application is
    // up AND the broker is genuinely authenticated -- never true just
    // because the server started.
    liveTradingPossible: appReadiness === READINESS_STATES.READY && broker.state === BROKER_STATES.CONNECTED,
  };
}

module.exports = { READINESS_STATES, markReady, markDegraded, getReadinessSnapshot };
