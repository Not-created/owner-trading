const fs = require("fs");
const bcrypt = require("bcryptjs");
const config = require("../config");

const SALT_ROUNDS = 12;

/**
 * Server-side storage for the single Owner Trading access password.
 *
 * The plaintext password is NEVER written to disk, logged, or returned by
 * any function here -- only its bcrypt hash is persisted, to a gitignored
 * JSON file (see config.passwordHashFile). This module is the only place
 * in the backend allowed to touch that file.
 */

// Exactly 8 characters, any mix of letters / numbers / the listed symbols.
// (No digit-only restriction -- see project instructions: any secure
// 8-character password is allowed, e.g. "Ab12@X9!".)
const PASSWORD_PATTERN = /^[A-Za-z0-9!@#$%^&*()_\-+=[\]{};:,.?]{8}$/;

function isValidPasswordFormat(password) {
  return typeof password === "string" && PASSWORD_PATTERN.test(password);
}

function hasPasswordConfigured() {
  return fs.existsSync(config.passwordHashFile);
}

/**
 * Hash and persist a new 8-character access password. Used only by the
 * deployment-time setup script (deployment/set-password.js), never by any
 * HTTP route -- there is no API endpoint that lets a caller set the
 * password over the network.
 */
async function setPassword(plainPassword) {
  if (!isValidPasswordFormat(plainPassword)) {
    throw new Error("Password must be exactly 8 characters (letters/numbers/symbols).");
  }
  const hash = await bcrypt.hash(plainPassword, SALT_ROUNDS);
  const payload = {
    hash,
    algorithm: "bcrypt",
    updatedAt: new Date().toISOString(),
  };
  fs.mkdirSync(require("path").dirname(config.passwordHashFile), { recursive: true });
  fs.writeFileSync(config.passwordHashFile, JSON.stringify(payload, null, 2), {
    mode: 0o600,
  });
}

/**
 * Verify a submitted password against the stored hash. Returns false (never
 * throws for a wrong password) so callers can't distinguish "wrong
 * password" from other failures via exception type/message.
 */
async function verifyPassword(submittedPassword) {
  if (!isValidPasswordFormat(submittedPassword)) return false;
  if (!hasPasswordConfigured()) return false;

  try {
    const raw = fs.readFileSync(config.passwordHashFile, "utf-8");
    const { hash } = JSON.parse(raw);
    if (!hash) return false;
    return await bcrypt.compare(submittedPassword, hash);
  } catch {
    return false;
  }
}

module.exports = {
  isValidPasswordFormat,
  hasPasswordConfigured,
  setPassword,
  verifyPassword,
};
