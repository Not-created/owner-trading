const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const config = require("../config");
const { requireLiveTradingAllowed } = require("../middleware/requireLiveTradingAllowed");
const brokerClient = require("../services/brokerClient");

const router = express.Router();
router.use(requireAuth);

/**
 * Applies requireLiveTradingAllowed ONLY when this deployment's TRADING_MODE
 * is LIVE. A PAPER-mode deployment never reaches that gate at all -- per
 * requireLiveTradingAllowed.js's own docstring: "PAPER-mode requests should
 * never call this middleware in the first place". The Python broker service
 * independently re-checks its OWN TRADING_MODE env var before ever calling
 * a real Kotak order API (see order_service.py) -- this is defense in depth,
 * not the only gate; a mismatch between the two processes' TRADING_MODE
 * values (e.g. Express set to PAPER, broker-service set to LIVE, or vice
 * versa) is a deployment misconfiguration to avoid, not something this
 * layer alone can fully protect against, which is exactly why both layers
 * check independently rather than one trusting the other's opinion.
 */
function gateIfLive(req, res, next) {
  if (config.tradingMode === "LIVE") {
    return requireLiveTradingAllowed(req, res, next);
  }
  return next();
}

router.get("/", async (req, res) => {
  const result = await brokerClient.getOrders(req.query.limit);
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.post("/", gateIfLive, async (req, res) => {
  const result = await brokerClient.placeOrder(req.body || {});
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.post("/cancel", gateIfLive, async (req, res) => {
  const { internalOrderId, brokerParams } = req.body || {};
  if (!internalOrderId) {
    return res.status(400).json({ error: "internalOrderId is required." });
  }
  const result = await brokerClient.cancelOrder(internalOrderId, brokerParams);
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.post("/modify", gateIfLive, async (req, res) => {
  const { internalOrderId, ...rest } = req.body || {};
  if (!internalOrderId) {
    return res.status(400).json({ error: "internalOrderId is required." });
  }
  const result = await brokerClient.modifyOrder(internalOrderId, rest);
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.get("/trades", async (req, res) => {
  const result = await brokerClient.getTrades();
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.get("/history", async (req, res) => {
  const result = await brokerClient.getOrderHistory();
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

module.exports = router;
