const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const result = await brokerClient.getFunds();
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

module.exports = router;
