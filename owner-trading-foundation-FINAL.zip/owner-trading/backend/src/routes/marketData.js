const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");

const router = express.Router();
router.use(requireAuth);

/**
 * Both routes below are honest pass-throughs to the Python broker
 * service's /quotes and /scrip-search endpoints (see
 * broker-service/app/server.py and order_service.py's module docstring
 * for why): Kotak's exact quotes()/search_scrip() parameter names could
 * not be independently verified against the official repository during
 * this project's audits, so this layer does not attempt to build or
 * guess a request shape -- the caller (frontend) supplies the exact
 * field names their real Kotak account's SDK expects, and this just
 * forwards the body as-is.
 */
router.post("/quotes", async (req, res) => {
  const result = await brokerClient.getQuotes(req.body || {});
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

router.post("/scrip-search", async (req, res) => {
  const result = await brokerClient.searchScrip(req.body || {});
  if (result.networkError) {
    return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
  }
  return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
});

module.exports = router;
