const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");

const router = express.Router();

// BUGFIX (Phase 1C): positions/holdings/orders/market-data used to be
// "not yet implemented" placeholders (see the git history of this file).
// summary/trade/history/strategy/reports/analytics/profile remain
// placeholders in THIS phase -- they either need real logic this codebase
// cannot honestly compute yet (e.g. a P&L figure requires live LTP
// integration, not built this phase) or a verified Kotak "profile" API
// this project could not independently confirm exists. Each of those is
// left explicit about what it is, rather than quietly faked.
function notYetImplemented(section) {
  return (req, res) => {
    res.json({
      section,
      data: null,
      message: "Not implemented yet. Broker/API integration is a future stage.",
    });
  };
}

// Forwards a broker-service GET call straight through. 409/502/etc. from
// the broker service (not connected, SDK call failed) are passed through
// with their real status code -- never silently turned into a 200 with
// empty/fake data.
function proxyGet(brokerFn) {
  return async (req, res) => {
    const result = await brokerFn(req.query.limit);
    if (result.networkError) {
      return res.status(502).json({ error: `broker service unreachable: ${result.networkError}` });
    }
    return res.status(result.status || 502).json(result.body || { error: "Empty response from broker service." });
  };
}

// All routes require an authenticated session -- verified here, server-side,
// independent of whatever the frontend does or doesn't render.
router.use(requireAuth);

router.get("/summary", notYetImplemented("dashboard-summary"));
router.get("/orders", proxyGet(brokerClient.getOrders));
router.get("/trade", notYetImplemented("trade"));
router.get("/positions", proxyGet(brokerClient.getPositions));
router.get("/holdings", proxyGet(brokerClient.getHoldings));
router.get("/history", notYetImplemented("history"));
router.get("/strategy", notYetImplemented("strategy"));
router.get("/reports", notYetImplemented("reports"));
router.get("/analytics", notYetImplemented("analytics"));
router.get("/market-data", notYetImplemented("market-data")); // see routes/marketData.js for the real quotes/search endpoints
router.get("/profile", notYetImplemented("profile")); // no verified Kotak "profile" API found during audit -- see final report

module.exports = router;
