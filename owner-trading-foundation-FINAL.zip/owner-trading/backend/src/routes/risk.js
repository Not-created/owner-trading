const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const config = require("../config");
const { getDb } = require("../db/client");
const {
  getBrokerConnectionState, getEmergencyStopState, setEmergencyStop,
} = require("../services/brokerState");

const router = express.Router();
router.use(requireAuth);

function writeAuditLog(action, details) {
  const db = getDb();
  db.prepare("INSERT INTO audit_logs (actor, action, details) VALUES (?, ?, ?)").run(
    "owner", action, details ? JSON.stringify(details) : null
  );
}

/**
 * Real status, not a placeholder: trading mode and emergency-stop state
 * are read straight from config/DB, and broker connection state comes
 * from the same shared state the rest of the app uses -- this is exactly
 * what requireLiveTradingAllowed.js checks before allowing a LIVE order,
 * surfaced here for the owner to see and act on directly.
 */
router.get("/", (req, res) => {
  res.json({
    tradingMode: config.tradingMode,
    emergencyStop: getEmergencyStopState(),
    brokerConnection: getBrokerConnectionState(),
  });
});

router.post("/emergency-stop/activate", (req, res) => {
  const reason = (req.body && req.body.reason) || "Activated by owner.";
  setEmergencyStop(true, reason);
  writeAuditLog("risk.emergency_stop.activated", { reason });
  res.json({ emergencyStop: getEmergencyStopState() });
});

router.post("/emergency-stop/clear", (req, res) => {
  setEmergencyStop(false);
  writeAuditLog("risk.emergency_stop.cleared", {});
  res.json({ emergencyStop: getEmergencyStopState() });
});

module.exports = router;
