import FoundationPage from "../components/common/FoundationPage";

export default function Strategy() {
  return <FoundationPage title="Strategy" subtitle="Build and manage trading strategies." />;
}
