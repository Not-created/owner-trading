import { useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function MarketData() {
  const [paramsText, setParamsText] = useState('{\n  \n}');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function runQuotes(e) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    let payload;
    try {
      payload = JSON.parse(paramsText);
    } catch {
      setError("Parameters must be valid JSON.");
      setLoading(false);
      return;
    }
    const { ok, body, status } = await api.getQuotes(payload);
    setLoading(false);
    if (ok) {
      setResult(body.data);
    } else {
      setError((body && body.error) || `Request failed (HTTP ${status}).`);
    }
  }

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Market Data</h2>
        <p className="page__subtitle">Real-time quotes from your connected Kotak account.</p>
      </div>
      <div className="card">
        <div className="card__head">
          <h3 className="card__title">Quotes lookup</h3>
        </div>
        <form onSubmit={runQuotes} className="order-form">
          <textarea rows={5} value={paramsText} onChange={(e) => setParamsText(e.target.value)} />
          <p className="form-hint">
            This app could not independently verify Kotak's exact quotes() parameter names against the official
            repository, so the exact JSON your Kotak SDK expects is required here rather than guessed.
          </p>
          <button type="submit" disabled={loading}>{loading ? "Loading…" : "Get quotes"}</button>
        </form>
      </div>
      <div className="card">
        {error && <EmptyState title="Quotes unavailable" hint={error} icon="globe" />}
        {!error && !result && <EmptyState title="No lookup yet" hint="Run a quotes lookup above." icon="globe" />}
        {result && <pre className="raw-json">{JSON.stringify(result, null, 2)}</pre>}
      </div>
    </div>
  );
}
