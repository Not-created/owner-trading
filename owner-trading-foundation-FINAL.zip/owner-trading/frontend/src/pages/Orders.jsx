import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

const EXCHANGE_SEGMENTS = ["nse_cm", "bse_cm", "nse_fo", "bse_fo", "mcx_fo"];

const EMPTY_FORM = {
  trading_symbol: "",
  exchange_segment: "nse_cm",
  transaction_type: "B",
  order_type: "MKT",
  product: "CNC",
  validity: "DAY",
  quantity: "",
  price: "",
  trigger_price: "",
};

export default function Orders() {
  const [orders, setOrders] = useState(null);
  const [loading, setLoading] = useState(true);
  const [listError, setListError] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  function load() {
    setLoading(true);
    api.getOrders().then(({ ok, status, body }) => {
      if (ok) {
        setOrders(body.orders || []);
        setListError(null);
      } else {
        setListError((body && body.error) || `Request failed (HTTP ${status}).`);
      }
      setLoading(false);
    });
  }

  useEffect(load, []);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function submit(e) {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);

    const payload = {
      trading_symbol: form.trading_symbol,
      exchange_segment: form.exchange_segment,
      transaction_type: form.transaction_type,
      order_type: form.order_type,
      product: form.product,
      validity: form.validity,
      quantity: Number(form.quantity),
      price: form.price ? Number(form.price) : undefined,
      trigger_price: form.trigger_price ? Number(form.trigger_price) : undefined,
      // Prevents a double-click or a client-side network retry from
      // placing the same order twice -- see order_service.py's
      // place_order() docstring for how the backend honors this.
      idempotency_key: crypto.randomUUID(),
    };

    const { ok, body, status } = await api.placeOrder(payload);
    setSubmitting(false);
    if (!ok) {
      setSubmitError((body && body.error) || `Order failed (HTTP ${status}).`);
      return;
    }
    setForm(EMPTY_FORM);
    load();
  }

  async function cancel(internalOrderId) {
    await api.cancelOrder(internalOrderId);
    load();
  }

  async function modify(order) {
    const next = window.prompt(`New quantity for ${order.trading_symbol} (current: ${order.quantity})`, order.quantity);
    if (!next || Number(next) === order.quantity) return;
    const { ok, body } = await api.modifyOrder(order.internal_order_id, { quantity: Number(next) });
    if (!ok) {
      window.alert((body && body.error) || "Modify failed.");
    }
    load();
  }

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Orders</h2>
        <p className="page__subtitle">Track and place trading orders (PAPER is simulated locally; LIVE calls your real Kotak account).</p>
      </div>

      <div className="card">
        <div className="card__head">
          <h3 className="card__title">Place order</h3>
        </div>
        <form onSubmit={submit} className="order-form">
          <input placeholder="Trading symbol (e.g. RELIANCE-EQ)" value={form.trading_symbol}
                 onChange={(e) => update("trading_symbol", e.target.value)} required />
          <select value={form.exchange_segment} onChange={(e) => update("exchange_segment", e.target.value)}>
            {EXCHANGE_SEGMENTS.map((seg) => (
              <option key={seg} value={seg}>{seg}</option>
            ))}
          </select>
          <select value={form.transaction_type} onChange={(e) => update("transaction_type", e.target.value)}>
            <option value="B">Buy</option>
            <option value="S">Sell</option>
          </select>
          <select value={form.order_type} onChange={(e) => update("order_type", e.target.value)}>
            <option value="MKT">Market</option>
            <option value="L">Limit</option>
            <option value="SL">Stop-loss limit</option>
            <option value="SL-M">Stop-loss market</option>
          </select>
          <select value={form.product} onChange={(e) => update("product", e.target.value)}>
            <option value="CNC">CNC</option>
            <option value="MIS">MIS</option>
            <option value="NRML">NRML</option>
            <option value="MTF">MTF</option>
          </select>
          <input type="number" placeholder="Quantity" value={form.quantity}
                 onChange={(e) => update("quantity", e.target.value)} required min="1" />
          {(form.order_type === "L" || form.order_type === "SL") && (
            <input type="number" placeholder="Price" value={form.price} onChange={(e) => update("price", e.target.value)} />
          )}
          {(form.order_type === "SL" || form.order_type === "SL-M") && (
            <input type="number" placeholder="Trigger price" value={form.trigger_price}
                   onChange={(e) => update("trigger_price", e.target.value)} />
          )}
          {submitError && <div className="form-error">{submitError}</div>}
          <button type="submit" disabled={submitting}>{submitting ? "Placing…" : "Place order"}</button>
        </form>
      </div>

      <div className="card">
        <div className="card__head">
          <h3 className="card__title">Order book</h3>
        </div>
        {loading && <EmptyState title="Loading…" />}
        {!loading && listError && <EmptyState title="Orders unavailable" hint={listError} icon="file-text" />}
        {!loading && !listError && orders.length === 0 && (
          <EmptyState title="No orders yet" hint="Orders you place will appear here." icon="file-text" />
        )}
        {!loading && !listError && orders.length > 0 && (
          <table className="data-table">
            <thead>
              <tr>
                <th>Symbol</th><th>Side</th><th>Qty</th><th>Mode</th><th>Status</th><th>Reason</th><th></th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.internal_order_id}>
                  <td>{o.trading_symbol}</td>
                  <td>{o.transaction_type}</td>
                  <td>{o.quantity}</td>
                  <td>{o.mode}</td>
                  <td>{o.status}</td>
                  <td>{o.status_reason || "--"}</td>
                  <td>
                    {!["CANCELLED", "REJECTED", "COMPLETE"].includes(o.status) && (
                      <>
                        <button type="button" onClick={() => modify(o)}>Modify</button>{" "}
                        <button type="button" onClick={() => cancel(o.internal_order_id)}>Cancel</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
