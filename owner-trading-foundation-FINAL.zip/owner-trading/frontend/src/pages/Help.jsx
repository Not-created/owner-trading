export default function Help() {
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Help</h2>
        <p className="page__subtitle">Documentation and support for Owner Trading.</p>
      </div>

      <div className="card">
        <h3 className="card__title">Getting started</h3>
        <p style={{ color: "#9caebf", fontSize: "0.88rem", lineHeight: 1.7, margin: 0 }}>
          This is the foundation build of Owner Trading. Broker connectivity, live orders,
          positions, and market data are not enabled yet — each section will come online in a
          future update. If you need access help, contact your administrator.
        </p>
      </div>
    </div>
  );
}
