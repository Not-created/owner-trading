import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function Risk() {
  const [state, setState] = useState({ loading: true, error: null, data: null });
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");

  function load() {
    setState((s) => ({ ...s, loading: true }));
    api.getRiskStatus().then(({ ok, status, body }) => {
      if (ok) {
        setState({ loading: false, error: null, data: body });
      } else {
        setState({ loading: false, error: (body && body.error) || `Request failed (HTTP ${status}).`, data: null });
      }
    });
  }

  useEffect(load, []);

  async function activate() {
    setBusy(true);
    await api.activateEmergencyStop(reason || undefined);
    setBusy(false);
    setReason("");
    load();
  }

  async function clear() {
    setBusy(true);
    await api.clearEmergencyStop();
    setBusy(false);
    load();
  }

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Risk</h2>
        <p className="page__subtitle">Trading mode and the emergency stop that blocks every LIVE order path.</p>
      </div>
      <div className="card">
        {state.loading && <EmptyState title="Loading…" />}
        {!state.loading && state.error && <EmptyState title="Risk status unavailable" hint={state.error} icon="alert-triangle" />}
        {!state.loading && !state.error && (
          <div className="risk-status">
            <div><strong>Trading mode:</strong> {state.data.tradingMode}</div>
            <div><strong>Broker connection:</strong> {state.data.brokerConnection.state}</div>
            <div>
              <strong>Emergency stop:</strong>{" "}
              {state.data.emergencyStop.is_active ? "ACTIVE -- all LIVE orders are blocked" : "Not active"}
            </div>
            {state.data.emergencyStop.is_active && state.data.emergencyStop.reason && (
              <div><strong>Reason:</strong> {state.data.emergencyStop.reason}</div>
            )}

            {state.data.emergencyStop.is_active ? (
              <button type="button" disabled={busy} onClick={clear}>Clear emergency stop</button>
            ) : (
              <div className="order-form">
                <input placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} />
                <button type="button" disabled={busy} onClick={activate}>Activate emergency stop</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
