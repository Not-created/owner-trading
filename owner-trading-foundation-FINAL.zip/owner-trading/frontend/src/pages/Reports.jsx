import FoundationPage from "../components/common/FoundationPage";

export default function Reports() {
  return <FoundationPage title="Reports" subtitle="Generate and review account reports." />;
}
