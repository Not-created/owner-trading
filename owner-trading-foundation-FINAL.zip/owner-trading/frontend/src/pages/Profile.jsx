import FoundationPage from "../components/common/FoundationPage";

export default function Profile() {
  return <FoundationPage title="Profile" subtitle="Manage your account profile." />;
}
