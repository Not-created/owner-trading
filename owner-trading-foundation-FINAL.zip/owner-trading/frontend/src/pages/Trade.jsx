import FoundationPage from "../components/common/FoundationPage";

export default function Trade() {
  return <FoundationPage title="Trade" subtitle="Place and manage trades." />;
}
