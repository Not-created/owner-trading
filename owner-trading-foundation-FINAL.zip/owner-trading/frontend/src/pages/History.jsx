import FoundationPage from "../components/common/FoundationPage";

export default function History() {
  return <FoundationPage title="History" subtitle="Review your order and trade history." />;
}
