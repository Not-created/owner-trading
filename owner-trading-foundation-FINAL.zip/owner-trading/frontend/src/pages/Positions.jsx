import { useEffect, useState } from "react";
import { api } from "../api/client";
import EmptyState from "../components/common/EmptyState";

export default function Positions() {
  const [state, setState] = useState({ loading: true, error: null, positions: null });

  useEffect(() => {
    let cancelled = false;
    api.getPositions().then(({ ok, status, body }) => {
      if (cancelled) return;
      if (ok) {
        setState({ loading: false, error: null, positions: body.positions || [] });
      } else {
        setState({ loading: false, error: (body && body.error) || `Request failed (HTTP ${status}).`, positions: null });
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Positions</h2>
        <p className="page__subtitle">Live positions from your connected Kotak account.</p>
      </div>
      <div className="card">
        {state.loading && <EmptyState title="Loading…" />}
        {!state.loading && state.error && <EmptyState title="Positions unavailable" hint={state.error} icon="layers" />}
        {!state.loading && !state.error && state.positions.length === 0 && (
          <EmptyState title="No open positions" hint="Positions will appear here once you have open trades." icon="layers" />
        )}
        {!state.loading && !state.error && state.positions.length > 0 && (
          <table className="data-table">
            <thead>
              <tr>
                <th>Symbol</th>
                <th>Exchange</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Avg. Price</th>
              </tr>
            </thead>
            <tbody>
              {state.positions.map((p, i) => (
                <tr key={i}>
                  <td>{p.trading_symbol || "--"}</td>
                  <td>{p.exchange_segment || "--"}</td>
                  <td>{p.product || "--"}</td>
                  <td>{p.quantity ?? "--"}</td>
                  <td>{p.average_price ?? "--"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
