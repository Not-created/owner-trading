import FoundationPage from "../components/common/FoundationPage";

export default function Analytics() {
  return <FoundationPage title="Analytics" subtitle="Charts and performance analytics." />;
}
