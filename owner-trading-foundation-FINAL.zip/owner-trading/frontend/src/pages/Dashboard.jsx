import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import MetricCard from "../components/common/MetricCard";
import EmptyState from "../components/common/EmptyState";
import SystemStatusCard from "../components/common/SystemStatusCard";

const RANGES = ["1D", "1W", "1M", "3M", "1Y"];

export default function Dashboard() {
  const [range, setRange] = useState("1D");
  const navigate = useNavigate();

  // BUGFIX (Phase 1C): Open Positions and Total Orders used to be
  // hardcoded placeholders forever. Total Equity and Today's P&L stay
  // placeholders deliberately -- computing them honestly needs live LTP
  // valuation of holdings/positions, which this phase does not build (see
  // the final report); showing a number here without that would be
  // fabricated data.
  const [positionsCount, setPositionsCount] = useState(null);
  const [ordersCount, setOrdersCount] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);

  useEffect(() => {
    api.getPositions().then(({ ok, body }) => {
      if (ok && Array.isArray(body.positions)) setPositionsCount(body.positions.length);
    });
    api.getOrders().then(({ ok, body }) => {
      if (ok && Array.isArray(body.orders)) {
        setOrdersCount(body.orders.length);
        setRecentOrders(body.orders.slice(0, 5));
      }
    });
  }, []);

  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">Dashboard</h2>
        <p className="page__subtitle">Welcome to Owner Trading</p>
      </div>

      <div className="metrics-grid">
        <MetricCard label="Total Equity" icon="briefcase" />
        <MetricCard label="Today's P&L" icon="activity" />
        <MetricCard label="Open Positions" icon="layers" value={positionsCount ?? undefined} />
        <MetricCard label="Total Orders" icon="file-text" value={ordersCount ?? undefined} />
      </div>

      <div className="dashboard-row dashboard-row--portfolio">
        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Portfolio Overview</h3>
            <div className="range-tabs">
              {RANGES.map((r) => (
                <button
                  key={r}
                  type="button"
                  className={`range-tabs__btn ${r === range ? "range-tabs__btn--active" : ""}`}
                  onClick={() => setRange(r)}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <EmptyState
            icon="bar-chart"
            title="No portfolio chart yet"
            hint="Charting isn't built in this phase -- see Positions/Holdings for live data"
          />
        </div>

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Recent Orders</h3>
            <button type="button" className="card__link" onClick={() => navigate("/dashboard/orders")}>
              View All
            </button>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Symbol</th>
                <th>Type</th>
                <th>Qty</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((o) => (
                <tr key={o.internal_order_id}>
                  <td>{o.created_at}</td>
                  <td>{o.trading_symbol}</td>
                  <td>{o.transaction_type}</td>
                  <td>{o.quantity}</td>
                  <td>{o.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {recentOrders.length === 0 && <EmptyState icon="file-text" title="No recent orders" hint="Your orders will appear here" />}
        </div>
      </div>

      <div className="dashboard-row dashboard-row--split">
        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Recent Trades</h3>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Symbol</th>
                <th>Type</th>
                <th>Qty</th>
                <th>Price</th>
              </tr>
            </thead>
          </table>
          <EmptyState icon="activity" title="No recent trades" hint="See the Orders page's trade book for live data" />
        </div>

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Market Data</h3>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Symbol</th>
                <th>LTP</th>
                <th>Change</th>
                <th>% Change</th>
              </tr>
            </thead>
          </table>
          <EmptyState
            icon="globe"
            title="No market data on this page yet"
            hint="Use the Market Data page for live quotes"
          />
        </div>
      </div>

      <div className="dashboard-row dashboard-row--split">
        <SystemStatusCard />

        <div className="card">
          <div className="card__head">
            <h3 className="card__title">Quick Stats</h3>
          </div>
          <EmptyState title="No data available" hint="Trading stats will appear here once connected" />
        </div>
      </div>

      <div className="card">
        <div className="card__head">
          <h3 className="card__title">News &amp; Updates</h3>
        </div>
        <EmptyState title="No updates available" hint="Market news and updates will appear here" />
      </div>
    </div>
  );
}
