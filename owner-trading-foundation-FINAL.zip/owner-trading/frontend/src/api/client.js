// Thin fetch wrapper. In production the frontend is served by the same
// origin as the backend, so relative "/api/..." paths work directly; in
// local dev, Vite's proxy (see vite.config.js) forwards them to :4000.
// `credentials: "include"` ensures the session cookie is sent/received.

async function request(path, options = {}) {
  const res = await fetch(path, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch {
    // Non-JSON response — leave body null, ok/status still tell the caller enough.
  }

  return { ok: res.ok, status: res.status, body };
}

export const api = {
  login: (password) =>
    request("/api/auth/login", { method: "POST", body: JSON.stringify({ password }) }),
  logout: () => request("/api/auth/logout", { method: "POST" }),
  getSession: () => request("/api/auth/session", { method: "GET" }),
  getDashboardSection: (section) => request(`/api/dashboard/${section}`, { method: "GET" }),
  getBrokerStatus: () => request("/api/broker/status", { method: "GET" }),
  getReadiness: () => request("/api/readiness", { method: "GET" }),
  getBrokerAccounts: () => request("/api/broker/accounts", { method: "GET" }),
  saveBrokerAccount: (accountLabel) =>
    request("/api/broker/accounts", { method: "POST", body: JSON.stringify({ accountLabel }) }),
  getKotakCredentialsStatus: () => request("/api/broker/kotak/credentials/status", { method: "GET" }),
  saveKotakCredentials: (creds) =>
    request("/api/broker/kotak/credentials", { method: "POST", body: JSON.stringify(creds) }),
  testKotakConnection: () => request("/api/broker/kotak/test", { method: "POST" }),
  connectKotak: () => request("/api/broker/kotak/connect", { method: "POST" }),
  disconnectKotak: () => request("/api/broker/kotak/disconnect", { method: "POST" }),
  reconnectKotak: () => request("/api/broker/kotak/reconnect", { method: "POST" }),

  // Phase 1C -- real portfolio/order/market-data/risk/logs endpoints.
  getFunds: () => request("/api/funds", { method: "GET" }),
  getPositions: () => request("/api/dashboard/positions", { method: "GET" }),
  getHoldings: () => request("/api/dashboard/holdings", { method: "GET" }),
  getOrders: () => request("/api/orders", { method: "GET" }),
  placeOrder: (order) => request("/api/orders", { method: "POST", body: JSON.stringify(order) }),
  cancelOrder: (internalOrderId, brokerParams) =>
    request("/api/orders/cancel", { method: "POST", body: JSON.stringify({ internalOrderId, brokerParams }) }),
  getTrades: () => request("/api/orders/trades", { method: "GET" }),
  getQuotes: (payload) => request("/api/market-data/quotes", { method: "POST", body: JSON.stringify(payload) }),
  searchScrip: (payload) => request("/api/market-data/scrip-search", { method: "POST", body: JSON.stringify(payload) }),
  getAuditLogs: () => request("/api/logs", { method: "GET" }),
  getRiskStatus: () => request("/api/risk", { method: "GET" }),
  activateEmergencyStop: (reason) => request("/api/risk/emergency-stop/activate", { method: "POST", body: JSON.stringify({ reason }) }),
  clearEmergencyStop: () => request("/api/risk/emergency-stop/clear", { method: "POST" }),
};
