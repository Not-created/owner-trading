import { useEffect, useState } from "react";
import { api } from "../../api/client";

const POLL_INTERVAL_MS = 30000;

/**
 * Application-level status, not trading data -- reads the real
 * GET /api/readiness endpoint. Shows exactly what the backend reports;
 * never a fabricated "all systems operational" default.
 */
export default function SystemStatusCard() {
  const [snapshot, setSnapshot] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function poll() {
      const { ok, body } = await api.getReadiness();
      if (cancelled) return;
      if (ok && body) {
        setSnapshot(body);
        setFailed(false);
      } else {
        setFailed(true);
      }
    }

    poll();
    const id = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  return (
    <div className="card">
      <div className="card__head">
        <h3 className="card__title">System Status</h3>
      </div>
      <div className="status-list">
        <div className="status-row">
          <span className="status-row__label">Application</span>
          <span className="status-row__value">
            {failed ? "Unreachable" : snapshot ? snapshot.application : "—"}
          </span>
        </div>
        <div className="status-row">
          <span className="status-row__label">Broker</span>
          <span className="status-row__value">
            {failed ? "Unreachable" : snapshot ? snapshot.broker : "—"}
          </span>
        </div>
        <div className="status-row">
          <span className="status-row__label">Live Trading</span>
          <span className="status-row__value">
            {failed || !snapshot ? "—" : snapshot.liveTradingPossible ? "Available" : "Not Available"}
          </span>
        </div>
      </div>
    </div>
  );
}
