import EmptyState from "./EmptyState";

/**
 * Shared shell for every foundation-stage section page: a title/subtitle
 * and a single empty-state card. Business logic for each section (broker
 * data, tables, charts, etc.) plugs in here in the next stage without
 * needing to touch routing or layout.
 */
export default function FoundationPage({ title, subtitle, emptyTitle = "No data available", hint = "Coming soon" }) {
  return (
    <div className="page">
      <div className="page__header">
        <h2 className="page__title">{title}</h2>
        {subtitle && <p className="page__subtitle">{subtitle}</p>}
      </div>
      <div className="card">
        <EmptyState title={emptyTitle} hint={hint} />
      </div>
    </div>
  );
}
