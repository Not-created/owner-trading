import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import CandlestickBackground from "./CandlestickBackground";
import "./PasswordGate.css";

export default function PasswordGate() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;

    if (password.length !== 8) {
      setError("Password must be exactly 8 characters.");
      return;
    }

    setError("");
    setLoading(true);
    const result = await login(password);
    setLoading(false);

    if (result.success) {
      setPassword("");
      navigate("/dashboard", { replace: true });
    } else {
      setError(result.message || "Incorrect password.");
      setPassword("");
    }
  }

  return (
    <div className="password-gate">
      <CandlestickBackground />
      <div className="password-gate__backdrop" aria-hidden="true" />

      <div className="password-gate__page">
        <div className="password-gate__brand">
          <span className="password-gate__brand-owner">OWNER</span>{" "}
          <span className="password-gate__brand-trading">TRADING</span>
          <div className="password-gate__tagline">DISCIPLINE BUILDS WEALTH</div>
        </div>

        <div className="password-gate__card">
          <div className="password-gate__lock" aria-hidden="true">
            <LockIcon />
          </div>

          <h1 className="password-gate__title">Enter Access Password</h1>
          <p className="password-gate__subtitle">
            This site is protected. Please enter your 8-character password to continue.
          </p>

          <form onSubmit={handleSubmit} noValidate>
            <div className="password-gate__input-row">
              <span className="password-gate__input-icon" aria-hidden="true">
                <SmallLockIcon />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                inputMode="text"
                autoComplete="off"
                autoCapitalize="off"
                spellCheck="false"
                maxLength={8}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError("");
                }}
                placeholder="Enter 8-character password"
                aria-label="8-character access password"
                aria-invalid={!!error}
                disabled={loading}
                autoFocus
              />
              <button
                type="button"
                className="password-gate__toggle"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                tabIndex={-1}
              >
                {showPassword ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>

            {error && (
              <div className="password-gate__error" role="alert">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="password-gate__submit"
              disabled={loading || password.length === 0}
            >
              {loading ? (
                <span className="password-gate__spinner" aria-hidden="true" />
              ) : (
                <>
                  Unlock Access <ArrowIcon />
                </>
              )}
            </button>
          </form>

          <div className="password-gate__quote">"Good Trades, Better Tomorrow"</div>
        </div>
      </div>
    </div>
  );
}

function LockIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="11" width="16" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="15.5" r="1.4" fill="currentColor" />
    </svg>
  );
}

function SmallLockIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="11" width="16" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="15.5" r="1.4" fill="currentColor" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M1.5 12S5 5 12 5s10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <circle cx="12" cy="12" r="3.2" stroke="currentColor" strokeWidth="1.6" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M3 3l18 18M10.6 5.2A10.9 10.9 0 0 1 12 5c7 0 10.5 7 10.5 7a13.4 13.4 0 0 1-3.1 4.1M6.6 6.6C3.6 8.5 1.5 12 1.5 12S5 19 12 19a10.8 10.8 0 0 0 4-.75M9.9 9.9a3.2 3.2 0 0 0 4.2 4.2"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
