# Owner Trading

Owner Trading is a private, single-user, LIVE algorithmic trading platform for Kotak Neo.

## Runtime architecture

React/Vite → Node/Express → Python broker service → official Kotak Neo SDK 3.0.7 → Kotak.
SQLite stores orders, fills, positions, strategies, signals, risk and audit data.

Backtest is historical analysis only and never reaches the live order API. The production execution path is LIVE-only; there is no executable PAPER/simulator path.

## Latest release validation

**v13** (scanner and live-data-path release) is documented in `docs/v13/RELEASE_REPORT.md` (phase reports in `docs/v13/`, what was tested and what was not, known limitations, deploy and first-day checklist). The broker-service suite has 635 unittest tests plus 18 pytest-style tests, the frontend 41 and the backend 30 (+6 Express E2E tests that need the npm dependencies); `deploy.sh` runs the Python suite and the frontend build and stops on any failure.

## Deployment

```bash
./deploy.sh
```

Deployment installs dependencies, configures systemd/Nginx, runs migrations/build/tests and performs health checks. It does not place orders or arm an algorithm.

After deployment, enter Kotak credentials in Settings, connect the account, configure risk limits, reconcile, create/validate a strategy and explicitly arm the selected strategy from the protected UI.

## Safety

Every live order is subject to broker/session/feed/reconciliation/risk/emergency-stop/idempotency gates. Unknown broker outcomes and pending submissions require reconciliation and are never blindly retried. Strategy execution is bound by the immutable Strategy Version → Signal → Internal Order → Broker Order → Trade → Position → Exit chain.

## Phase 14 live execution upgrade

The LIVE runtime now separates scanner qualification from strategy entry. Strategy-linked scanners create durable candidates and acquire strategy-owned feed subscriptions; the complete strategy entry condition and production risk/readiness gates must still pass before any Kotak order is submitted. Shared subscriptions are reference-counted and restart-recoverable.
