const express = require("express");
const requireAuth = require("../middleware/requireAuth");
const brokerClient = require("../services/brokerClient");
const { relay, wrap } = require("./_proxy");

const router = express.Router();
router.use(requireAuth);

// Exact shapes (validated again by the broker service against the official SDK):
//   POST /quotes       { instruments: [{ exchange_segment, instrument_token }], quote_type? }
//   POST /scrip-search { exchange_segment, symbol, expiry?, option_type?, strike_price? }
//   POST /subscribe { exchange_segment, instrument_token, trading_symbol?, name? } | /unsubscribe { exchange_segment, instrument_token }   (live SFeed)
router.post("/quotes", wrap(async (req, res) => {
  const { instruments, quote_type } = req.body || {};
  relay(res, await brokerClient.getQuotes({ instruments, quote_type }));
}));

router.post("/scrip-search", wrap(async (req, res) => {
  const { exchange_segment, symbol, expiry, option_type, strike_price } = req.body || {};
  relay(res, await brokerClient.searchScrip({ exchange_segment, symbol, expiry, option_type, strike_price }));
}));

// POST /instruments { query? | tokens?, exchange_segment?, limit? }  instant lookup in the synced scrip master
router.post("/instruments", wrap(async (req, res) => {
  const { query, tokens, exchange_segment, limit } = req.body || {};
  relay(res, await brokerClient.lookupInstruments({ query, tokens, exchange_segment, limit }));
}));

// GET /scrip-master?exchange_segment=   official scrip_master(); omit the query param for the full file index.
router.get("/scrip-master", wrap(async (req, res) => relay(res, await brokerClient.getScripMaster(req.query.exchange_segment))));

// POST /expiries { exchange, underlying, instrument_type? }
router.post("/expiries", wrap(async (req, res) => {
  const { exchange, underlying, instrument_type } = req.body || {};
  relay(res, await brokerClient.getExpiries({ exchange, underlying, instrument_type }));
}));

// POST /option-chain { exchange, underlying, expiry?, instrument_type?, count? }
router.post("/option-chain", wrap(async (req, res) => {
  const { exchange, underlying, expiry, instrument_type, count } = req.body || {};
  relay(res, await brokerClient.getOptionChain({ exchange, underlying, expiry, instrument_type, count }));
}));

// POST /historical-data { neosymbol, interval, from_date, to_date }
router.post("/historical-data", wrap(async (req, res) => {
  const { neosymbol, interval, from_date, to_date } = req.body || {};
  relay(res, await brokerClient.getHistoricalData({ neosymbol, interval, from_date, to_date }));
}));

// POST /margin -- official margin_required(), used for the order-preview margin estimate.
router.post("/margin", wrap(async (req, res) => {
  const { exchange_segment, price, order_type, product, quantity, instrument_token, transaction_type, trigger_price } = req.body || {};
  relay(res, await brokerClient.getMarginRequired({ exchange_segment, price, order_type, product, quantity, instrument_token, transaction_type, trigger_price }));
}));

router.get("/ticks", wrap(async (req, res) => relay(res, await brokerClient.getMarketTicks())));
// GET /subscriptions[?tier=manual,positions&q=reli&limit=50&offset=0] -> rows with owners / tier / removable + a summary.
router.get("/subscriptions", wrap(async (req, res) => {
  const { tier, q, limit, offset } = req.query || {};
  relay(res, await brokerClient.getSubscriptions({ tier, q, limit, offset }));
}));
// POST /subscribe  one instrument, or { items: [{ exchange_segment, instrument_token, trading_symbol?, name? }, ...] } (up to 500).
router.post("/subscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token, trading_symbol, name, items } = req.body || {};
  relay(res, await brokerClient.subscribe(Array.isArray(items) ? { items } : { exchange_segment, instrument_token, trading_symbol, name }));
}));
// POST /unsubscribe  removes the USER's subscription(s); the answer says what stayed on the feed and why.
router.post("/unsubscribe", wrap(async (req, res) => {
  const { exchange_segment, instrument_token, items } = req.body || {};
  relay(res, await brokerClient.unsubscribe(Array.isArray(items) ? { items } : { exchange_segment, instrument_token }));
}));
router.post("/unsubscribe-all-manual", wrap(async (req, res) => relay(res, await brokerClient.unsubscribeAllManual())));

module.exports = router;
