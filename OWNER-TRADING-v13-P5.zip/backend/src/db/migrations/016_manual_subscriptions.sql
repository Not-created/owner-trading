-- Instruments the user subscribed to by hand (Market Data page / scrip search). The live feed registry is in memory, so
-- without this table every restart, deploy or re-login silently dropped them. One row per instrument; deleting the row
-- is how "unsubscribe" is remembered.
CREATE TABLE IF NOT EXISTS manual_subscriptions (
  exchange_segment TEXT NOT NULL,
  instrument_token TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (exchange_segment, instrument_token)
);
