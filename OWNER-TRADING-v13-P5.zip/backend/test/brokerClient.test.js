const test = require("node:test");
const assert = require("node:assert");

process.env.BROKER_SERVICE_TOKEN = "t".repeat(32);
process.env.DB_PATH = require("node:path").join(require("node:os").tmpdir(), `ot-bc-${process.pid}.db`);
require("../src/db/migrate").run();
const bc = require("../src/services/brokerClient");

function mockFetch(handler) {
  const calls = [];
  global.fetch = async (url, opts) => {
    calls.push({ url, opts });
    const r = await handler(url, opts);
    return { ok: r.status < 400, status: r.status, json: async () => r.body };
  };
  return calls;
}

test("every request carries the internal token", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: {} }));
  await bc.getOrders(); await bc.placeOrder({}); await bc.getPnl(); await bc.getLiveReadiness(); await bc.credentialsStatus();
  assert.ok(calls.length >= 5);
  for (const c of calls) assert.strictEqual(c.opts.headers["X-Internal-Token"], "t".repeat(32));
});

test("cancel sends only internal_order_id (no broker_params)", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: {} }));
  await bc.cancelOrder("abc", { evil: 1 });
  assert.deepStrictEqual(JSON.parse(calls[0].opts.body), { internal_order_id: "abc" });
  assert.ok(calls[0].url.endsWith("/orders/cancel"));
});

test("query strings are encoded and empty values dropped", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: {} }));
  await bc.getOrders("50", undefined);
  await bc.getOrderHistory("a b&c");
  await bc.getFunds(true);
  assert.ok(calls[0].url.endsWith("/orders?limit=50"));
  assert.ok(calls[1].url.endsWith("/order-history?internal_order_id=a%20b%26c"));
  assert.ok(calls[2].url.endsWith("/funds?refresh=1"));
});

test("network failures are reported, never thrown", async () => {
  global.fetch = async () => { throw new Error("ECONNREFUSED"); };
  const r = await bc.getFunds();
  assert.strictEqual(r.ok, false);
  assert.match(r.networkError, /ECONNREFUSED/);
});

test("broker 4xx bodies are relayed with status intact", async () => {
  mockFetch(async () => ({ status: 409, body: { error: "not connected" } }));
  const r = await bc.placeOrder({});
  assert.deepStrictEqual([r.ok, r.status, r.body.error], [false, 409, "not connected"]);
});

test("arm / risk / subscribe endpoints hit the right paths", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: {} }));
  await bc.armLive({ confirm: "x" }); await bc.disarmLive(); await bc.setRiskSettings({ max_daily_loss: 5 });
  await bc.subscribe({ exchange_segment: "nse_cm", instrument_token: "1" }); await bc.reconcile();
  const paths = calls.map((c) => c.url.replace("http://127.0.0.1:8800", ""));
  assert.deepStrictEqual(paths, ["/risk/arm-live", "/risk/disarm-live", "/risk-settings", "/subscribe", "/reconcile"]);
});

test("fetchBrokerStatus maps unknown states to CONNECTION_ERROR and unreachable to an error", async () => {
  mockFetch(async () => ({ status: 200, body: { state: "CONNECTED", last_error: null } }));
  assert.strictEqual((await bc.fetchBrokerStatus()).state, "CONNECTED");
  mockFetch(async () => ({ status: 200, body: { state: "WEIRD" } }));
  assert.strictEqual((await bc.fetchBrokerStatus()).state, "CONNECTION_ERROR");
  global.fetch = async () => { throw new Error("down"); };
  assert.strictEqual((await bc.fetchBrokerStatus()).state, "CONNECTION_ERROR");
});


test("connect preserves AUTH_FAILED state returned with a non-2xx broker response", async () => {
  mockFetch(async () => ({ status: 422, body: { state: "AUTH_FAILED", last_error: "Invalid MPIN." } }));
  const r = await bc.connect();
  assert.strictEqual(r.ok, false);
  const { getBrokerConnectionState } = require("../src/services/brokerState");
  assert.strictEqual(getBrokerConnectionState().state, "AUTH_FAILED");
});

test("reconnect preserves SESSION_EXPIRED state returned with a non-2xx broker response", async () => {
  mockFetch(async () => ({ status: 409, body: { state: "SESSION_EXPIRED", last_error: "Session expired." } }));
  const r = await bc.reconnect();
  assert.strictEqual(r.ok, false);
  const { getBrokerConnectionState } = require("../src/services/brokerState");
  assert.strictEqual(getBrokerConnectionState().state, "SESSION_EXPIRED");
});

test("scanner diagnostics is a read-only GET with the internal token and no body", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: { scanners: [], feed: { used: 0, limit: 3000 } } }));
  const r = await bc.getScannerDiagnostics();
  assert.strictEqual(calls.length, 1);
  assert.ok(calls[0].url.endsWith("/algo/scanner-diagnostics"));
  assert.ok(!calls[0].opts.method || calls[0].opts.method === "GET");
  assert.strictEqual(calls[0].opts.body, undefined);
  assert.strictEqual(calls[0].opts.headers["X-Internal-Token"], "t".repeat(32));
  assert.ok(r && (r.body ? r.body.feed.limit === 3000 : r.feed.limit === 3000));
});

test("subscription list passes its filters, bulk subscribe passes items, and remove-all-mine posts to its own path", async () => {
  const calls = mockFetch(async () => ({ status: 200, body: { subscriptions: [], total_matching: 0, summary: { total: 0 } } }));
  await bc.getSubscriptions({ tier: "manual,positions", q: "reli ance", limit: 50, offset: 100, ignored: undefined });
  await bc.getSubscriptions();
  await bc.subscribe({ items: [{ exchange_segment: "nse_cm", instrument_token: "1" }, { exchange_segment: "nse_cm", instrument_token: "2" }] });
  await bc.unsubscribe({ items: [{ exchange_segment: "nse_cm", instrument_token: "1" }] });
  await bc.unsubscribeAllManual();
  assert.ok(calls[0].url.endsWith("/subscriptions?tier=manual%2Cpositions&q=reli%20ance&limit=50&offset=100"));
  assert.ok(calls[1].url.endsWith("/subscriptions"));
  assert.ok(calls[2].url.endsWith("/subscribe"));
  assert.strictEqual(JSON.parse(calls[2].opts.body).items.length, 2);
  assert.ok(calls[3].url.endsWith("/unsubscribe"));
  assert.ok(calls[4].url.endsWith("/unsubscribe-all-manual"));
  assert.strictEqual(calls[4].opts.method, "POST");
});
