"""Canonical strategy DSL, indicators, sizing and historical backtest engine.

The same validated definition is used by scanner/live/backtest.  This module
contains no broker calls and never creates live orders.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Any

# timeframe -> bar length in minutes (membership checks and minute lookups share one source)
TIMEFRAMES={"1m":1,"3m":3,"5m":5,"10m":10,"15m":15,"30m":30,"1h":60,"1d":1440}
OPS={">",">=","<","<=","==","!=","cross_above","cross_below"}
SIDES={"BUY","SELL"}
PRODUCTS={"CNC","NRML","MIS","MTF"}
INDICATOR_NAMES={"close","open","high","low","volume","sma","ema","rsi","atr","macd","macd_signal","macd_hist","adx","vwap","bb_mid","bb_upper","bb_lower","volume_sma"}


def _num(v):
    try:
        value = float(v)
    except (TypeError,ValueError):
        return None
    return value if math.isfinite(value) else None

def sma(values,n):
    n=int(n); return sum(values[-n:])/n if len(values)>=n and n>0 else None

def ema(values,n):
    n=int(n)
    if len(values)<n or n<=0:return None
    k=2/(n+1); e=sum(values[:n])/n
    for v in values[n:]: e=v*k+e*(1-k)
    return e

def rsi(values,n=14):
    n=int(n)
    if n<=0 or len(values)<n+1:return None
    deltas=[float(b)-float(a) for a,b in zip(values[:-1],values[1:])]
    gains=[max(d,0.0) for d in deltas]; losses=[max(-d,0.0) for d in deltas]
    ag=sum(gains[:n])/n; al=sum(losses[:n])/n
    for i in range(n,len(deltas)):
        ag=((ag*(n-1))+gains[i])/n; al=((al*(n-1))+losses[i])/n
    if al==0: return 100.0 if ag>0 else 50.0
    rs=ag/al
    return 100-(100/(1+rs))

def atr(candles,n=14):
    n=int(n)
    if n<=0 or len(candles)<n+1:return None
    trs=[]
    for prev,c in zip(candles[:-1],candles[1:]):
        trs.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
    value=sum(trs[:n])/n
    for tr in trs[n:]: value=((value*(n-1))+tr)/n
    return value


def _ema_series(values,n):
    """EMA at every index >= n-1 (SMA seed, then the usual recursion); entries before that are None."""
    n=int(n); out=[None]*len(values)
    if n<=0 or len(values)<n:return out
    k=2/(n+1); e=sum(values[:n])/n; out[n-1]=e
    for i in range(n,len(values)):
        e=values[i]*k+e*(1-k); out[i]=e
    return out

def macd(values,fast=12,slow=26,signal=9):
    """MACD line, signal and histogram. Same numbers as the old per-prefix version but O(n), not O(n^2)."""
    if len(values)<slow+signal:return (None,None,None)
    f=_ema_series(values,fast); s_=_ema_series(values,slow)
    series=[f[i]-s_[i] for i in range(slow-1,len(values)) if f[i] is not None and s_[i] is not None]
    line=series[-1] if series else None
    sig=ema(series,signal) if len(series)>=signal else None
    return line,sig,(line-sig if line is not None and sig is not None else None)

def adx(candles,n=14):
    n=int(n)
    if n<=0 or len(candles)<(2*n+1):return None
    tr=[]; plus=[]; minus=[]
    for prev,c in zip(candles[:-1],candles[1:]):
        up=float(c['high'])-float(prev['high']); down=float(prev['low'])-float(c['low'])
        tr.append(max(float(c['high'])-float(c['low']),abs(float(c['high'])-float(prev['close'])),abs(float(c['low'])-float(prev['close']))))
        plus.append(up if up>down and up>0 else 0.0); minus.append(down if down>up and down>0 else 0.0)
    atr_v=sum(tr[:n])/n; p_dm=sum(plus[:n])/n; m_dm=sum(minus[:n])/n; dx=[]
    def dx_value():
        if atr_v==0:return 0.0
        pdi=100*p_dm/atr_v; mdi=100*m_dm/atr_v; den=pdi+mdi
        return 100*abs(pdi-mdi)/den if den else 0.0
    dx.append(dx_value())
    for i in range(n,len(tr)):
        atr_v=((atr_v*(n-1))+tr[i])/n; p_dm=((p_dm*(n-1))+plus[i])/n; m_dm=((m_dm*(n-1))+minus[i])/n
        dx.append(dx_value())
    if len(dx)<n:return None
    adx_v=sum(dx[:n])/n
    for x in dx[n:]: adx_v=((adx_v*(n-1))+x)/n
    return adx_v

def vwap(candles):
    if not candles:return None
    last_day=str(candles[-1].get('candle_at',''))[:10]
    session=[c for c in candles if str(c.get('candle_at',''))[:10]==last_day]
    pv=0.0; vol=0.0
    for c in session:
        v=float(c.get('volume') or 0); typical=(float(c['high'])+float(c['low'])+float(c['close']))/3
        pv+=typical*v; vol+=v
    return pv/vol if vol else None

def indicators(candles):
    closes=[float(x['close']) for x in candles]; opens=[float(x['open']) for x in candles]
    highs=[float(x['high']) for x in candles]; lows=[float(x['low']) for x in candles]; vols=[float(x.get('volume') or 0) for x in candles]
    out={'close':closes[-1] if closes else None,'open':opens[-1] if opens else None,'high':highs[-1] if highs else None,'low':lows[-1] if lows else None,'volume':vols[-1] if vols else None}
    for n in (5,9,20,50,100,200):out[f'sma{n}']=sma(closes,n);out[f'ema{n}']=ema(closes,n)
    out['rsi14']=rsi(closes,14);out['atr14']=atr(candles,14)
    ml,ms,mh=macd(closes);out.update({'macd':ml,'macd_signal':ms,'macd_hist':mh})
    out['adx14']=adx(candles,14);out['vwap']=vwap(candles)
    if len(closes)>=20:
        m=sma(closes,20);sd=(sum((x-m)**2 for x in closes[-20:])/20)**0.5;out['bb_mid']=m;out['bb_upper']=m+2*sd;out['bb_lower']=m-2*sd
    out['volume_sma20']=sma(vols,20)
    # Common price-action fields for no-code conditions.
    if candles:
        c=candles[-1]; out['body']=abs(float(c['close'])-float(c['open']));out['range']=float(c['high'])-float(c['low']);out['bullish_candle']=1 if float(c['close'])>float(c['open']) else 0;out['bearish_candle']=1 if float(c['close'])<float(c['open']) else 0
    return out


# --------------------------------------------------------------------------- condition engine v2
# One operand grammar for scanner, strategy, backtest and live evaluation:
#   close open high low volume price previous_close vwap macd macd_signal macd_hist body range bullish_candle bearish_candle
#   sma<N> ema<N> (N 1-500)  rsi<N> adx<N> (2-100)  atr<N> (1-100)  volume_sma<N> (1-500)
#   hh<N> ll<N>  (highest high / lowest low of the PREVIOUS N bars)   bb_upper|bb_mid|bb_lower[<N>] (default 20, 2 sd)
#   any operand may carry an offset: close[1] = previous completed bar, ema20[3] = three bars ago (0-50)
# A condition may add "mult" (right-hand value x mult, e.g. volume > volume_sma20 x 2) and "not": true.
# A group may add "not": true. Evaluation is three-valued: a result that cannot be computed (not enough
# bars) stays "unknown" through NOT/AND/OR and is never a match.
import re as _re
_OPERAND_RE=_re.compile(r'^(?P<base>[a-z_]+?)(?P<period>\d+)?(?:\[(?P<off>\d+)\])?$')
SIMPLE_OPERANDS={'close','open','high','low','volume','price','previous_close','vwap','macd','macd_signal','macd_hist','body','range','bullish_candle','bearish_candle'}
PERIOD_RANGES={'sma':(1,500),'ema':(1,500),'rsi':(2,100),'atr':(1,100),'adx':(2,100),'volume_sma':(1,500),'hh':(1,500),'ll':(1,500)}
BB_BASES={'bb_upper','bb_mid','bb_lower'}
MAX_OFFSET=50

def parse_operand(name):
    """-> ('num', value) | (base, period|None, offset) | None when it is not a valid operand."""
    if isinstance(name,bool):return None
    if isinstance(name,(int,float)):
        v=_num(name);return ('num',v) if v is not None else None
    if not isinstance(name,str):return None
    key=name.lower().strip()
    n=_num(key)
    if n is not None:return ('num',n)
    m=_OPERAND_RE.match(key)
    if not m:return None
    base,period,off=m.group('base'),m.group('period'),m.group('off')
    offset=int(off) if off is not None else 0
    if offset>MAX_OFFSET:return None
    if base in SIMPLE_OPERANDS:
        return (base,None,offset) if period is None else None
    if base in PERIOD_RANGES:
        if period is None:return None
        lo,hi=PERIOD_RANGES[base]
        return (base,int(period),offset) if lo<=int(period)<=hi else None
    if base in BB_BASES:
        p=int(period) if period is not None else 20
        return (base,p,offset) if 2<=p<=500 else None
    return None

def operand_valid(name):return parse_operand(name) is not None

def operand_min_bars(name):
    """Bars of history an operand needs (for warm-up sizing); 0 for numbers."""
    p=parse_operand(name)
    if not p or p[0]=='num':return 0
    base,period,offset=p
    if base in ('sma','ema','volume_sma'):need=period
    elif base in ('rsi','atr'):need=period+1
    elif base=='adx':need=2*period+1
    elif base in ('hh','ll'):need=period+1
    elif base in BB_BASES:need=period
    elif base in ('macd','macd_signal','macd_hist'):need=35
    elif base=='previous_close':need=2
    else:need=1
    return need+offset

# --------------------------------------------------------------------------- analysis window (parity)
# EMA / RSI / ATR / ADX / MACD are recursive: their value at a bar depends on WHERE the series fed to them starts.
# Before v13 the scanner fed ~22 bars, the live strategy 250 and the backtest 300, so the same condition on the same
# bar gave different numbers in each place (an "ema20 crosses ema50" scanner match the strategy then rejected, or the
# reverse). Now EVERY operand is computed on its own canonical window (`operand_window`): the last N bars where N is
# long enough for the recursion to converge (residual seed error < ~0.3 %), and VWAP always sees its whole session.
# The window belongs to the OPERAND, not to the definition around it, so ema20 has the same value in the scanner, the
# live strategy, the exit check and the backtest whatever else those rules contain and however many bars the caller
# happened to load (as long as it loaded at least that many).
ANALYSIS_MAX_WINDOW=600
BARS_PER_SESSION_MINUTES=375            # 09:15-15:30

def _bars_in_session(timeframe_minutes):
    return 1 if timeframe_minutes>=1440 else -(-BARS_PER_SESSION_MINUTES//max(1,int(timeframe_minutes)))

def operand_window(base,period=None,timeframe_minutes=5):
    """Bars (ending at the evaluated bar) an operand is computed on; None = it needs no more than its own period."""
    if base=='ema':return max(period,3*(period+1))              # (1-2/(n+1))^(3(n+1)) ~ e^-6
    if base in ('rsi','atr'):return max(period+1,6*period+1)    # Wilder smoothing: (1-1/n)^(6n) ~ e^-6
    if base=='adx':return max(2*period+1,8*period+1)            # smoothed twice
    if base in ('macd','macd_signal','macd_hist'):return 150     # slow EMA 26 x ~4 plus the signal EMA
    if base=='vwap':return _bars_in_session(timeframe_minutes)+1
    return None

def operand_warmup_bars(name,timeframe_minutes=5):
    """Bars an operand needs to be CONVERGED (not merely defined, see operand_min_bars); 0 for numbers."""
    p=parse_operand(name)
    if not p or p[0]=='num':return 0
    base,period,offset=p
    w=operand_window(base,period,timeframe_minutes)
    if w is not None:need=w
    elif base in ('sma','volume_sma'):need=period
    elif base in ('hh','ll'):need=period+1
    elif base in BB_BASES:need=period
    elif base=='previous_close':need=2
    else:need=1
    return need+offset

def _definition_operand_names(definition):
    names=set()
    def walk(group):
        if not isinstance(group,dict):return
        for c in group.get('conditions') or []:
            if isinstance(c,dict):
                for k in ('left','right'):
                    if isinstance(c.get(k),str):names.add(c[k].strip().lower())
        for child in group.get('groups') or []:walk(child)
    for part in ('entry','exit'):walk((definition or {}).get(part))
    if ((definition or {}).get('risk') or {}).get('stop_atr_multiple') is not None:names.add('atr14')   # the ATR stop must be converged too
    return names

_WINDOW_CACHE={}
def analysis_window(definition):
    """Completed bars of history a definition needs so EVERY operand it uses has its full window (+2 for the crossover
    look-back and a margin; capped at ANALYSIS_MAX_WINDOW). This is what 'enough history' means for the scanner, the
    warm-up and the live strategy; it never changes any operand's value (see operand_window)."""
    definition=definition or {}
    tf=TIMEFRAMES.get(str(definition.get('timeframe') or '5m'),5)
    names=tuple(sorted(_definition_operand_names(definition)))
    key=(tf,names)
    w=_WINDOW_CACHE.get(key)
    if w is None:
        need=max([operand_warmup_bars(n,tf) for n in names] or [0])
        w=min(ANALYSIS_MAX_WINDOW,max(need+2,2))
        if len(_WINDOW_CACHE)>512:_WINDOW_CACHE.clear()
        _WINDOW_CACHE[key]=w
    return w

def risk_atr(definition,candles,period=14):
    """ATR for stops / sizing on the same canonical window the 'atr<N>' operand uses (live, backtest and recovery agree)."""
    if not candles:return None
    w=operand_window('atr',period)
    return atr(candles[-w:],period)

class Resolver:
    """Computes only the operands a rule actually uses, once per (operand, offset)."""
    def __init__(self,candles,timeframe_minutes=5):
        self.candles=candles or []; self._cache={}; self._lists={}; self.tf=int(timeframe_minutes or 5)
    def _view(self,offset):
        key=('v',offset)
        if key not in self._lists:
            data=self.candles[:len(self.candles)-offset] if offset else self.candles
            self._lists[key]=(data,[float(c['close']) for c in data],[float(c.get('volume') or 0) for c in data])
        return self._lists[key]
    def value(self,name,extra_offset=0):
        p=parse_operand(name)
        if p is None:return None
        if p[0]=='num':return p[1]
        base,period,offset=p; offset+=extra_offset
        key=(base,period,offset)
        if key in self._cache:return self._cache[key]
        if offset>=len(self.candles):self._cache[key]=None;return None
        data,closes,vols=self._view(offset); last=data[-1]; out=None
        try:
            if base in ('close','price'):out=closes[-1]
            elif base=='open':out=float(last['open'])
            elif base=='high':out=float(last['high'])
            elif base=='low':out=float(last['low'])
            elif base=='volume':out=vols[-1]
            elif base=='previous_close':out=closes[-2] if len(closes)>=2 else None
            elif base=='sma':out=sma(closes,period)
            elif base=='ema':out=ema(closes[-operand_window('ema',period):],period)
            elif base=='rsi':out=rsi(closes[-operand_window('rsi',period):],period)
            elif base=='atr':out=atr(data[-operand_window('atr',period):],period)
            elif base=='adx':out=adx(data[-operand_window('adx',period):],period)
            elif base=='volume_sma':out=sma(vols,period)
            elif base=='vwap':out=vwap(data[-operand_window('vwap',None,self.tf):])
            elif base in ('hh','ll'):
                prev=data[-period-1:-1]
                if len(prev)==period:out=max(float(c['high']) for c in prev) if base=='hh' else min(float(c['low']) for c in prev)
            elif base in BB_BASES:
                if len(closes)>=period:
                    m=sum(closes[-period:])/period; sd=(sum((x-m)**2 for x in closes[-period:])/period)**0.5
                    out=m if base=='bb_mid' else (m+2*sd if base=='bb_upper' else m-2*sd)
            elif base in ('macd','macd_signal','macd_hist'):
                mk=('macd3',offset)
                if mk not in self._cache:self._cache[mk]=macd(closes[-operand_window('macd'):])
                ml,ms,mh=self._cache[mk]; out={'macd':ml,'macd_signal':ms,'macd_hist':mh}[base]
            elif base=='body':out=abs(float(last['close'])-float(last['open']))
            elif base=='range':out=float(last['high'])-float(last['low'])
            elif base=='bullish_candle':out=1.0 if float(last['close'])>float(last['open']) else 0.0
            elif base=='bearish_candle':out=1.0 if float(last['close'])<float(last['open']) else 0.0
        except (TypeError,ValueError,KeyError,ZeroDivisionError):
            out=None
        self._cache[key]=out
        return out
    def snapshot(self):
        """Operand values seen so far (for 'why matched' / signal records) plus ATR for ATR stops."""
        out={}
        for key,v in self._cache.items():
            if len(key)!=3 or v is None:continue          # ('macd3', offset) is an internal cache entry, not an operand value
            b,p,o=key
            out[f'{b}{p if p is not None else ""}{"["+str(o)+"]" if o else ""}']=v
        out['atr14']=self.value('atr14');out['close']=self.value('close')
        return out

def _cond3(cond,res):
    """-> (True|False|None, reason). None = cannot be computed with the bars available."""
    op=str(cond.get('operator') or cond.get('op') or '>').lower()
    ln,rn=cond.get('left'),cond.get('right')
    if op not in OPS:return None,f'unsupported operator {op}'
    mult=_num(cond.get('mult')) if cond.get('mult') is not None else None
    left=res.value(ln); right=res.value(rn)
    if left is None or right is None:return None,f'missing operand: {ln} {op} {rn}'
    if mult is not None:right=right*mult
    if op in ('cross_above','cross_below'):
        pl=res.value(ln,1); pr=res.value(rn,1)
        # The previous bar may not have enough history for an indicator yet: a crossover needs BOTH bars.
        if pl is None or pr is None:return None,f'missing previous-bar operand: {ln} {op} {rn}'
        if mult is not None:pr=pr*mult
        ok=(pl<=pr and left>right) if op=='cross_above' else (pl>=pr and left<right)
    elif op=='>':ok=left>right
    elif op=='>=':ok=left>=right
    elif op=='<':ok=left<right
    elif op=='<=':ok=left<=right
    elif op=='==':ok=left==right
    else:ok=left!=right
    if cond.get('not') is True:ok=not ok
    shown=f'{"NOT " if cond.get("not") is True else ""}{ln} {op} {rn}{f" x{mult:g}" if mult is not None else ""}'
    return bool(ok),f'{shown} => {bool(ok)}'

def eval_condition(cond,candles,ind=None,timeframe_minutes=5):
    """Public single-condition API (kept): -> (bool, reason). Unknown counts as not matched."""
    if not candles:return False,'no candle data'
    ok,reason=_cond3(cond,Resolver(candles,timeframe_minutes))
    return (ok is True),reason

def _group3(group,res):
    group=group or {}; op=str(group.get('op','AND')).upper()
    if op not in ('AND','OR'):return None,{'group':op,'reason':f'unsupported group operator {op}','items':[]}
    items=[];states=[]
    for c in group.get('conditions',[]) or []:
        ok,reason=_cond3(c,res); states.append(ok); items.append({'condition':c,'passed':ok is True,'reason':reason})
    for child in group.get('groups',[]) or []:
        ok,detail=_group3(child,res); states.append(ok); items.append({'group_result':detail,'passed':ok is True})
    if not states:return None,{'group':op,'items':items}
    if op=='AND':state=False if any(x is False for x in states) else (None if any(x is None for x in states) else True)
    else:state=True if any(x is True for x in states) else (None if any(x is None for x in states) else False)
    if group.get('not') is True and state is not None:state=not state
    return state,{'group':op,'not':bool(group.get('not')),'items':items}

def eval_group(group,candles,timeframe_minutes=5):
    """Evaluate a boolean group (flat ``conditions`` plus nested ``groups``, AND/OR, optional NOT).
    Returns (passed, details); details['indicators'] holds the operand values that were used."""
    if not candles:return False,{'group':str((group or {}).get('op','AND')).upper(),'items':[],'reason':'no candle data','indicators':{}}
    res=Resolver(candles,timeframe_minutes)
    state,detail=_group3(group,res)
    detail['indicators']=res.snapshot()
    return (state is True),detail

def _tf_minutes(definition):return TIMEFRAMES.get(str((definition or {}).get('timeframe') or '5m'),5)
def evaluate_entry(definition,candles):return eval_group(definition.get('entry',{}),candles,_tf_minutes(definition))
def evaluate_exit(definition,candles):return eval_group(definition.get('exit',{}),candles,_tf_minutes(definition))


OPERANDS={"open","high","low","close","volume"}|{f"sma{x}" for x in (5,9,20,50,100,200)}|{f"ema{x}" for x in (5,9,20,50,100,200)}|{"rsi14","atr14","macd","macd_signal","macd_hist","adx14","vwap","bb_mid","bb_upper","bb_lower","volume_sma20","body","range","bullish_candle","bearish_candle"}

SCAN_RANK_BY={"volume","turnover","change_pct","price"}

def validate_scanner(definition:dict)->list[str]:
    """A scanner is the ENTRY half of a strategy plus a stock filter: no exit, risk, sizing or universe needed."""
    if not isinstance(definition,dict):return ['definition must be an object']
    probe={k:v for k,v in definition.items() if k not in ('scanner_ids',)}
    probe.setdefault('exit',{'op':'OR','conditions':[{'left':'rsi14','operator':'>','right':99}]})
    probe.setdefault('position_sizing',{'quantity':1}); probe.setdefault('risk',{'stop_loss_pct':1})
    if not ((probe.get('universe') or {}).get('instrument_tokens')):probe['universe']={'instrument_tokens':['1']}
    errors=[e for e in validate_strategy(probe) if not e.startswith(('exit','position_sizing','risk'))]
    scan=definition.get('scan')
    if scan is None:return errors
    if not isinstance(scan,dict):return errors+['scan must be an object']
    series=scan.get('series')
    if series is not None and (not isinstance(series,list) or not series or any(str(x).upper() not in ('EQ','BE','SM','BZ','ST','SZ','XT') for x in series)):
        errors.append('scan.series must be a list such as ["EQ"] or ["EQ","BE","SM"]')
    lo=_num(scan.get('min_price')) if scan.get('min_price') is not None else None
    hi=_num(scan.get('max_price')) if scan.get('max_price') is not None else None
    for k in ('min_price','max_price','min_avg_volume'):
        if scan.get(k) is not None and (_num(scan.get(k)) is None or float(scan[k])<0):errors.append(f'scan.{k} must be a number of 0 or more')
    if lo is not None and hi is not None and lo>hi:errors.append('scan.min_price cannot be above scan.max_price')
    if scan.get('max_candidates') is not None:
        try:
            mc=int(scan['max_candidates'])
            if isinstance(scan['max_candidates'],bool) or mc<1 or mc>500:raise ValueError
        except (TypeError,ValueError):errors.append('scan.max_candidates must be a whole number from 1 to 500')
    if scan.get('rank_by') is not None and str(scan['rank_by']) not in SCAN_RANK_BY:errors.append('scan.rank_by must be one of volume, turnover, change_pct, price')
    return errors


def validate_strategy(definition:dict)->list[str]:
    errors=[]
    if not isinstance(definition,dict):return ['definition must be an object']
    if str(definition.get('timeframe','5m')) not in TIMEFRAMES:errors.append('timeframe is invalid')
    side=str(definition.get('side','BUY')).upper()
    if side not in SIDES:errors.append('side must be BUY or SELL')
    ex=definition.get('execution',{}) or {}; product=str(ex.get('product','MIS')).upper()
    if product not in PRODUCTS:errors.append(f'unsupported product: {product}')
    def check_group(group,path):
        if not isinstance(group,dict):errors.append(f'{path} group is required');return
        op=str(group.get('op','AND')).upper()
        if op not in ('AND','OR'):errors.append(f'{path}.op must be AND or OR')
        conditions=group.get('conditions',[])
        if conditions is not None and not isinstance(conditions,list):errors.append(f'{path}.conditions must be a list');conditions=[]
        for i,c in enumerate(conditions or []):
            if not isinstance(c,dict):errors.append(f'{path}.conditions[{i}] must be an object');continue
            if c.get('operator') not in OPS:errors.append(f'{path}.conditions[{i}].operator is invalid')
            if c.get('left') is None or c.get('right') is None:errors.append(f'{path}.conditions[{i}] needs left and right')
            for field in ('left','right'):
                val=c.get(field)
                if isinstance(val,str) and not operand_valid(val):
                    errors.append(f'{path}.conditions[{i}].{field} is an unknown or non-finite operand: {val}')
                elif isinstance(val,(int,float)) and not isinstance(val,bool) and _num(val) is None:
                    errors.append(f'{path}.conditions[{i}].{field} is an unknown or non-finite operand: {val}')
            if c.get('mult') is not None and not (_num(c.get('mult')) is not None and float(c['mult'])>0):
                errors.append(f'{path}.conditions[{i}].mult must be a number greater than 0')
            if c.get('not') is not None and not isinstance(c.get('not'),bool):errors.append(f'{path}.conditions[{i}].not must be true or false')
        if group.get('not') is not None and not isinstance(group.get('not'),bool):errors.append(f'{path}.not must be true or false')
        groups=group.get('groups',[])
        if groups is not None and not isinstance(groups,list):errors.append(f'{path}.groups must be a list');groups=[]
        for i,g in enumerate(groups or []):check_group(g,f'{path}.groups[{i}]')
        if not (conditions or groups):errors.append(f'{path} must contain at least one condition/group')
    check_group(definition.get('entry'), 'entry')
    check_group(definition.get('exit'), 'exit')
    risk=definition.get('risk',{}) or {}
    if not isinstance(risk,dict):errors.append('risk must be an object');risk={}
    for k in ('stop_loss','target','stop_loss_pct','target_pct','trailing_stop_pct','stop_atr_multiple','partial_exit_pct'):
        if k in risk and risk[k] is not None and _num(risk[k]) is None:errors.append(f'risk.{k} must be numeric')
    for k in ('stop_loss_pct','target_pct','trailing_stop_pct','stop_atr_multiple'):
        if risk.get(k) is not None and _num(risk[k]) is not None and float(risk[k]) <= 0:
            errors.append(f'risk.{k} must be greater than 0')
    if risk.get('stop_loss') is not None and _num(risk['stop_loss']) is not None and float(risk['stop_loss']) <= 0:
        errors.append('risk.stop_loss must be greater than 0')
    if risk.get('target') is not None and _num(risk['target']) is not None and float(risk['target']) <= 0:
        errors.append('risk.target must be greater than 0')
    stop_modes=sum(1 for k in ('stop_loss','stop_loss_pct','stop_atr_multiple') if risk.get(k) is not None)
    if stop_modes > 1:
        errors.append('use only one stop-loss mode: price, percentage or ATR multiple')
    target_modes=sum(1 for k in ('target','target_pct') if risk.get(k) is not None)
    if target_modes > 1:
        errors.append('use only one target mode: price or percentage')
    stop_value = _num(risk.get('stop_loss'))
    target_value = _num(risk.get('target'))
    if stop_value is not None and target_value is not None:
        if side == 'BUY' and stop_value >= target_value:
            errors.append('BUY strategy requires stop_loss below target')
        if side == 'SELL' and stop_value <= target_value:
            errors.append('SELL strategy requires stop_loss above target')
    for pct_key, price_key in (('stop_loss_pct','stop_loss'),('target_pct','target')):
        if risk.get(pct_key) is not None and risk.get(price_key) is not None:
            errors.append(f'use either risk.{pct_key} or risk.{price_key}, not both')
    if risk.get('partial_exit_pct') is not None and not (0<float(risk['partial_exit_pct'])<=100):errors.append('risk.partial_exit_pct must be between 0 and 100')
    if risk.get('time_exit_bars') is not None:
        try:
            raw_bars = risk['time_exit_bars']
            bars = int(raw_bars)
            if isinstance(raw_bars, bool) or str(raw_bars).strip() != str(bars) or bars < 1:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('risk.time_exit_bars must be a positive integer')
    if definition.get('time_exit_bars') is not None:
        errors.append('time_exit_bars must be under risk.time_exit_bars')
    scanner_ids=definition.get('scanner_ids')
    if scanner_ids is not None:
        if not isinstance(scanner_ids,list) or any((not str(x).isdigit() or int(x) <= 0) for x in scanner_ids):
            errors.append('scanner_ids must be a list of positive scanner IDs')
    if definition.get('max_positions') is not None:
        try:
            raw_max = definition['max_positions']
            max_pos = int(raw_max)
            if isinstance(raw_max, bool) or str(raw_max).strip() != str(max_pos) or max_pos < 1:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('max_positions must be a positive integer')
    sizing=definition.get('position_sizing',{}) or {}
    if not isinstance(sizing,dict):errors.append('position_sizing must be an object');sizing={}
    if sizing.get('quantity') is not None:
        q=_num(sizing['quantity'])
        if q is None or q<1 or not float(q).is_integer(): errors.append('position_sizing.quantity must be a positive integer')
    if sizing.get('capital_pct') is not None:
        cap_pct = _num(sizing['capital_pct'])
        if cap_pct is None or not math.isfinite(float(cap_pct)) or not (0<float(cap_pct)<=100):
            errors.append('capital_pct must be between 0 and 100')
    if sizing.get('risk_per_trade') is not None and (not _num(sizing['risk_per_trade']) or float(sizing['risk_per_trade'])<=0):errors.append('risk_per_trade must be > 0')
    sizing_modes = sum(1 for k in ('quantity','capital_pct','risk_per_trade') if sizing.get(k) is not None)
    if sizing_modes > 1:
        errors.append('position_sizing must use only one of quantity, capital_pct or risk_per_trade')
    if sizing.get('risk_per_trade') is not None and not any(risk.get(k) is not None for k in ('stop_loss','stop_loss_pct','stop_atr_multiple')):
        errors.append('risk_per_trade sizing requires a stop-loss mode')
    execution=definition.get('execution',{}) or {}
    if not isinstance(execution,dict):
        errors.append('execution must be an object')
        execution={}
    if execution.get('cooldown_bars') is not None:
        try:
            raw_cooldown = execution['cooldown_bars']
            cooldown = int(raw_cooldown)
            if isinstance(raw_cooldown, bool) or str(raw_cooldown).strip() != str(cooldown) or cooldown < 0:
                raise ValueError
        except (TypeError,ValueError):
            errors.append('execution.cooldown_bars must be a non-negative integer')
    universe=definition.get('universe',{}) or {}
    scanner_ids=definition.get('scanner_ids') or []
    scanner_linked=bool(scanner_ids)
    if universe and not isinstance(universe,dict):errors.append('universe must be an object')
    if isinstance(universe,dict) and universe.get('instrument_tokens') is not None:
        toks=universe.get('instrument_tokens')
        # Scanner-linked strategies may intentionally send an empty explicit
        # universe: the scanner owns discovery and candidate subscriptions.
        # Scanner-less strategies still require a non-empty explicit universe.
        if not isinstance(toks,list) or (not toks and not scanner_linked):
            errors.append('universe.instrument_tokens must be a non-empty list when no scanner is configured')
        elif len(toks)>3000:
            errors.append('universe.instrument_tokens cannot exceed the SFeed limit of 3000')
        else:
            cleaned=[]
            for i,tok in enumerate(toks):
                text=str(tok).strip() if tok is not None else ''
                if not text or not text.isdigit() or int(text) <= 0:
                    errors.append(f'universe.instrument_tokens[{i}] must be a positive integer token')
                cleaned.append(text)
            if len(cleaned) != len(set(cleaned)):
                errors.append('universe.instrument_tokens must not contain duplicate tokens')
    return errors


def size_position(definition,price,available_funds=None,atr_value=None,lot_size=1,max_quantity=None):
    sizing=definition.get('position_sizing',{}) or {}; qty=sizing.get('quantity')
    if qty is not None:
        result=max(1,int(qty))
    else:
        pct=sizing.get('capital_pct')
        if pct and available_funds and price>0:
            result=max(1,int((float(available_funds)*float(pct)/100)/price))
        else:
            risk=sizing.get('risk_per_trade'); stop=(definition.get('risk',{}) or {}).get('stop_loss')
            pct_stop=(definition.get('risk',{}) or {}).get('stop_loss_pct')
            if stop is None and pct_stop is not None and price>0:
                # percentage stop: risk per share is price x pct (previously ignored -> silently sized to 1 share)
                dist=price*float(pct_stop)/100
                stop=price-dist if str(definition.get('side','BUY')).upper()=='BUY' else price+dist
            if stop is None and atr_value and (definition.get('risk',{}) or {}).get('stop_atr_multiple') is not None:
                mult=float(definition['risk']['stop_atr_multiple'])
                stop=price-mult*float(atr_value) if str(definition.get('side','BUY')).upper()=='BUY' else price+mult*float(atr_value)
            result=max(1,int(float(risk)/(abs(price-float(stop))))) if risk and stop and price>0 and price!=float(stop) else 1
    lot=max(1,int(lot_size or 1))
    result=(result//lot)*lot
    if result <= 0:
        return 0
    if max_quantity is not None:
        cap=(int(max_quantity)//lot)*lot
        if cap < lot:return 0
        result=min(result,cap)
    if result < lot:
        return 0
    return result


@dataclass
class BacktestTrade:
    symbol:str;entry_time:str;exit_time:str;side:str;quantity:int;entry_price:float;exit_price:float;gross_pnl:float;costs:float;net_pnl:float;exit_reason:str


def _bar_in_cash_session(candle):
    try:
        from datetime import datetime, time
        from zoneinfo import ZoneInfo
        raw=str(candle.get('candle_at','')).replace('Z','+00:00')
        x=datetime.fromisoformat(raw)
        if x.tzinfo is None:x=x.replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        else:x=x.astimezone(ZoneInfo('Asia/Kolkata'))
        return x.weekday()<5 and time(9,15)<=x.time().replace(tzinfo=None)<time(15,30)
    except (TypeError,ValueError,OverflowError):
        # Unknown timestamps are never treated as valid NSE cash-session bars.
        return False

def _cagr(initial_capital, final_equity, start_time, end_time):
    if initial_capital <= 0 or final_equity <= 0 or not start_time or not end_time:
        return None
    try:
        a = __import__("datetime").datetime.fromisoformat(str(start_time).replace("Z","+00:00"))
        b = __import__("datetime").datetime.fromisoformat(str(end_time).replace("Z","+00:00"))
        years = (b-a).total_seconds() / (365.25*86400)
        if years <= 0:
            return None
        return ((final_equity/initial_capital)**(1/years)-1)*100
    except (TypeError, ValueError):
        return None


def _risk_ratios_from_equity_curve(equity_curve, initial_capital, candles=None, requested_from=None, requested_to=None):
    """Annualized daily realized portfolio-return Sharpe/Sortino.

    The daily series is built across the full requested trading-date window,
    carrying equity forward on no-trade days so the denominator is a genuine
    daily portfolio series rather than a trade-count series.
    """
    if initial_capital <= 0: return None, None
    realized={}
    for point in equity_curve or []:
        day=str(point.get("candle_at", ""))[:10]
        if day: realized[day]=float(point["equity"])
    if not realized: return None, None
    if candles:
        days=sorted({str(c.get("candle_at", ""))[:10] for c in candles if str(c.get("candle_at", ""))[:10]})
        frm=str(requested_from or days[0])[:10]; to=str(requested_to or days[-1])[:10]
        days=[d for d in days if frm <= d <= to]
        daily={}; equity=float(initial_capital)
        for day in days:
            if day in realized: equity=realized[day]
            daily[day]=equity
    else:
        daily=realized
    ordered=sorted(daily.items())
    prev=float(initial_capital); returns=[]
    for _,equity in ordered:
        if prev>0: returns.append((equity-prev)/prev)
        prev=equity
    if len(returns)<2:return None,None
    mean=sum(returns)/len(returns)
    var=sum((x-mean)**2 for x in returns)/(len(returns)-1)
    std=var**0.5
    sharpe=(mean/std)*(252**0.5) if std else None
    dstd=(sum(min(0.0,x)**2 for x in returns)/len(returns))**0.5
    sortino=(mean/dstd)*(252**0.5) if dstd else None
    return sharpe,sortino


def _trade_leg_cost(price, qty, *, side, leg, flat_per_side=0.0, model=None):
    model=model or {}
    value=float(price)*int(qty)
    brokerage=float(model.get(f"{leg}_brokerage",flat_per_side) or 0)
    exchange=value*float(model.get("exchange_txn_pct",0) or 0)/100
    sebi=value*float(model.get("sebi_pct",0) or 0)/100
    transaction=str(side).upper()
    is_sell = (transaction == "BUY" and leg == "exit") or (transaction == "SELL" and leg == "entry")
    is_buy = not is_sell
    stt=value*float(model.get("stt_sell_pct",0) or 0)/100 if is_sell else 0.0
    stamp=value*float(model.get("stamp_duty_buy_pct",0) or 0)/100 if is_buy else 0.0
    gst=(brokerage+exchange+sebi)*float(model.get("gst_pct",0) or 0)/100
    return brokerage+exchange+sebi+stt+stamp+gst


def _trade_costs(entry_price, exit_price, qty, side="BUY", flat_per_side=0.0, model=None):
    """Full round-trip cost using separate entry and exit legs."""
    return (_trade_leg_cost(entry_price, qty, side=side, leg="entry", flat_per_side=flat_per_side, model=model)
            + _trade_leg_cost(exit_price, qty, side=side, leg="exit", flat_per_side=flat_per_side, model=model))


# Indicators are evaluated on the most recent bars only (the live engine reads the last 250 bars), so a
# backtest behaves exactly like live trading AND costs O(bars) instead of O(bars^2): the full-history
# version took minutes for ~1000 bars and froze the whole broker service while it ran.
BACKTEST_LOOKBACK=300


def definition_min_bars(definition):
    """Bars of history the entry/exit operands of a definition need (nested groups included)."""
    need=0
    def walk(group):
        nonlocal need
        if not isinstance(group,dict):return
        for c in group.get('conditions') or []:
            if isinstance(c,dict):
                for k in ('left','right'):
                    need=max(need,operand_min_bars(c.get(k)))
        for child in group.get('groups') or []:walk(child)
    for part in ('entry','exit'):walk((definition or {}).get(part))
    return need


def run_backtest(
    candles, definition, symbol, quantity=1, slippage=0.0, fees=0.0,
    initial_capital=100000.0, requested_from=None, requested_to=None, cost_model=None
):
    """Conservative historical simulation.

    Indicator warm-up candles may precede requested_from, but no trade can
    open before requested_from. Signals use only completed candles and entries
    execute at the NEXT candle open, eliminating same-candle look-ahead.
    Stops/targets use candle high/low with stop checked first when both are
    touched. Optional partial exits, trailing stops and time exits are supported.
    """
    side=str(definition.get('side','BUY')).upper()
    lookback=max(BACKTEST_LOOKBACK,analysis_window(definition))          # never less than the window the conditions use
    trades=[]; open_trade=None
    req_from=str(requested_from or "")[:10]
    req_to=str(requested_to or "")[:10]
    realized_equity=float(initial_capital)
    equity_curve=[]

    for i in range(1,len(candles)):
        c=candles[i]; close=float(c['close']); cdate=str(c.get('candle_at',''))[:10]
        if req_to and cdate > req_to:
            break
        if open_trade is None:
            # Warm-up history is available to indicators but is not executable.
            if req_from and cdate < req_from:
                continue
            hist=candles[max(0,i-lookback):i]
            if not _bar_in_cash_session(c): continue
            ok,_=evaluate_entry(definition,hist)
            if ok:
                q=size_position(
                    definition,float(c['open']),definition.get('_available_funds'),
                    risk_atr(definition,hist)
                ) or quantity
                entry=float(c['open'])*(1+slippage if side=='BUY' else 1-slippage)
                entry_cost=_trade_leg_cost(entry,q,side=side,leg='entry',flat_per_side=fees,model=cost_model)
                open_trade={'time':c['candle_at'],'price':entry,'qty':q,'remaining':q,
                            'side':side,'bars':0,'partial_taken':False,'entry_cost_per_unit':entry_cost/q if q else 0.0}
            continue

        open_trade['bars']+=1
        risk=definition.get('risk',{}) or {}; entry=open_trade['price']
        stop=risk.get('stop_loss'); target=risk.get('target')
        if stop is None and risk.get('stop_loss_pct') is not None:
            stop=entry*(1-float(risk['stop_loss_pct'])/100 if side=='BUY' else 1+float(risk['stop_loss_pct'])/100)
        if stop is None and risk.get('stop_atr_multiple') is not None:
            hist=candles[max(0,i-lookback):i]
            av=risk_atr(definition,hist)
            if av is not None:
                mult=float(risk['stop_atr_multiple'])
                stop=entry-mult*av if side=='BUY' else entry+mult*av
        if target is None and risk.get('target_pct') is not None:
            target=entry*(1+float(risk['target_pct'])/100 if side=='BUY' else 1-float(risk['target_pct'])/100)
        if risk.get('trailing_stop_pct') is not None:
            pct=float(risk['trailing_stop_pct'])/100
            candidate=close*(1-pct) if side=='BUY' else close*(1+pct)
            open_trade['trailing_stop']=(
                max(open_trade.get('trailing_stop',candidate),candidate)
                if side=='BUY' else
                min(open_trade.get('trailing_stop',candidate),candidate)
            )

        reason=None; exit_price=close
        if side=='BUY':
            if stop is not None and float(c['low'])<=float(stop): reason='STOP_LOSS'; exit_price=float(stop)
            elif target is not None and float(c['high'])>=float(target): reason='TARGET'; exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['low'])<=open_trade['trailing_stop']:
                reason='TRAILING_STOP'; exit_price=open_trade['trailing_stop']
        else:
            if stop is not None and float(c['high'])>=float(stop): reason='STOP_LOSS'; exit_price=float(stop)
            elif target is not None and float(c['low'])<=float(target): reason='TARGET'; exit_price=float(target)
            elif open_trade.get('trailing_stop') is not None and float(c['high'])>=open_trade['trailing_stop']:
                reason='TRAILING_STOP'; exit_price=open_trade['trailing_stop']

        if reason is None and risk.get('time_exit_bars') and open_trade['bars']>=int(risk['time_exit_bars']):
            reason='TIME_EXIT'
        if reason is None:
            exit_ok,_=evaluate_exit(definition,candles[max(0,i+1-lookback):i+1])
            if exit_ok: reason='STRATEGY_EXIT'
        if reason is None: continue

        exit_price*=1-slippage if side=='BUY' else 1+slippage
        partial=float(risk.get('partial_exit_pct') or 100)
        exit_qty=(
            open_trade['remaining'] if partial>=100 or open_trade['partial_taken']
            else max(1,min(open_trade['remaining'],int(round(open_trade['qty']*partial/100))))
        )
        gross=(exit_price-entry)*exit_qty*(1 if side=='BUY' else -1)
        entry_cost=open_trade.get('entry_cost_per_unit',0.0)*exit_qty
        exit_cost=_trade_leg_cost(exit_price,exit_qty,side=side,leg='exit',flat_per_side=fees,model=cost_model)
        costs=entry_cost+exit_cost
        net=gross-costs
        trades.append(BacktestTrade(
            symbol,open_trade['time'],c['candle_at'],side,exit_qty,
            entry,exit_price,gross,costs,net,reason
        ))
        open_trade['remaining']-=exit_qty
        if open_trade['remaining']<=0:
            open_trade=None
        else:
            open_trade['partial_taken']=True

    # Close any remaining position at the final requested candle so the report
    # cannot hide an open simulated position.
    if open_trade is not None:
        usable=[c for c in candles if not req_to or str(c.get('candle_at',''))[:10] <= req_to]
        if usable:
            last=usable[-1]
            exit_price=float(last['close'])*(1-slippage if side=='BUY' else 1+slippage)
            qty=int(open_trade['remaining'])
            gross=(exit_price-open_trade['price'])*qty*(1 if side=='BUY' else -1)
            entry_cost=open_trade.get('entry_cost_per_unit',0.0)*qty
            exit_cost=_trade_leg_cost(exit_price,qty,side=side,leg='exit',flat_per_side=fees,model=cost_model)
            costs=entry_cost+exit_cost
            net=gross-costs
            trades.append(BacktestTrade(
                symbol,open_trade['time'],last['candle_at'],side,qty,
                open_trade['price'],exit_price,gross,costs,net,'DATA_END'
            ))

    pnl=sum(t.net_pnl for t in trades)
    wins=[t.net_pnl for t in trades if t.net_pnl>0]
    losses=[t.net_pnl for t in trades if t.net_pnl<0]
    equity=float(initial_capital); peak=equity; dd=0.0
    equity_curve=[]; consecutive=0; max_consecutive=0

    # Rebuild a mark-to-market portfolio series across every requested candle.
    # This is the basis for drawdown and daily Sharpe/Sortino; trade-count
    # returns are intentionally not used.
    trade_idx=0
    active=None
    realized=float(initial_capital)
    for c in candles:
        day=str(c.get('candle_at',''))[:10]
        if req_from and day < req_from: continue
        if req_to and day > req_to: break
        # Apply any trade exits that occurred on this candle before the close mark.
        while trade_idx < len(trades) and str(trades[trade_idx].exit_time) == str(c.get('candle_at')):
            realized += float(trades[trade_idx].net_pnl)
            trade_idx += 1
        # Find an open interval by looking at the next trade entry/exit window.
        mark=realized
        if trade_idx < len(trades):
            t=trades[trade_idx]
            if str(t.entry_time) <= str(c.get('candle_at')) < str(t.exit_time):
                px=float(c['close'])
                gross=(px-float(t.entry_price))*int(t.quantity)*(1 if t.side=='BUY' else -1)
                entry_cost = _trade_leg_cost(t.entry_price, t.quantity, side=t.side, leg='entry', flat_per_side=fees, model=cost_model)
                mark += gross - entry_cost
        equity=mark
        peak=max(peak,equity); draw=max(0.0,peak-equity); dd=max(dd,draw)
        equity_curve.append({
            'candle_at':c.get('candle_at'),'equity':equity,'drawdown':draw,
            'drawdown_pct':(draw/peak*100 if peak else 0),
        })

    # Consecutive losses remain trade-based, which is the appropriate unit for
    # this metric and independent of candle frequency.
    for t in trades:
        consecutive=consecutive+1 if t.net_pnl<0 else 0
        max_consecutive=max(max_consecutive,consecutive)

    avg=(sum(t.net_pnl for t in trades)/len(trades)) if trades else 0
    gross_profit=sum(wins); gross_loss=abs(sum(losses))
    sharpe,sortino=_risk_ratios_from_equity_curve(equity_curve,float(initial_capital),candles,requested_from,requested_to)
    final_equity=equity
    first_time=trades[0].entry_time if trades else (candles[0]['candle_at'] if candles else None)
    last_time=trades[-1].exit_time if trades else (candles[-1]['candle_at'] if candles else None)
    return {
        'trades':[t.__dict__ for t in trades],
        'total_trades':len(trades),
        'initial_capital':float(initial_capital),
        'final_equity':final_equity,
        'net_pnl':pnl,
        'win_rate':(len(wins)/len(trades)*100 if trades else 0),
        'profit_factor':(sum(wins)/abs(sum(losses)) if losses else None),
        'max_drawdown':dd,
        'max_drawdown_pct':(dd/peak*100 if peak else 0),
        'cagr':_cagr(float(initial_capital),final_equity,first_time,last_time),
        'sharpe':sharpe,
        'sortino':sortino,
        'average_win':(sum(wins)/len(wins) if wins else 0),
        'average_loss':(sum(losses)/len(losses) if losses else 0),
        'gross_profit':gross_profit,
        'gross_loss':gross_loss,
        'expectancy':avg,
        'max_consecutive_losses':max_consecutive,
        'total_costs':sum(t.costs for t in trades),
        'equity_curve':equity_curve,
        'side':side,
        'execution_model':'next_bar_open',
        'session_filter':'NSE_CASH_WEEKDAY_09:15-15:30_IST',
        'slippage':float(slippage),
        'fees_per_exit':float(fees),
        'cost_model':cost_model or {},
        'risk_metric_basis':'daily_realized_portfolio_returns_annualized_252',
        'requested_from':requested_from,
        'requested_to':requested_to,
    }
