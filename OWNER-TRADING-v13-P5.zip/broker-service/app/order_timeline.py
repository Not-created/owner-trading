"""Read-only story of one order: created -> each broker update -> each fill -> where it stands now.

Built only from rows already in the local database (orders, order_events, trades): no broker call, so it also works
when the broker is disconnected. Updates that repeat the same state (the order feed and the REST reconciliation often
both report it) are merged into one step. Nothing here writes or changes an order."""
from __future__ import annotations

import json

from . import db

_FRIENDLY = {
    "put order req received": "ऑर्डर भेजा गया, broker ने पाया",
    "validation pending": "जाँच जारी है",
    "open pending": "खुलने का इंतज़ार",
    "after market order req received": "AMO ऑर्डर पाया गया",
    "trigger pending": "Trigger का इंतज़ार",
    "open": "बाज़ार में खुला",
    "modified": "बदला गया",
    "complete": "पूरा हुआ",
    "completed": "पूरा हुआ",
    "traded": "पूरा हुआ",
    "rejected": "अस्वीकृत",
    "cancelled": "रद्द",
    "canceled": "रद्द",
}
_TONE = {"complete": "good", "completed": "good", "traded": "good", "rejected": "bad", "cancelled": "bad", "canceled": "bad"}
_SOURCE = {"order_feed_ws": "लाइव फ़ीड", "order_report_rest": "ऑर्डर रिपोर्ट", "reconciliation": "मिलान"}


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return int(f) if f.is_integer() else f


def _clean(v):
    s = str(v).strip() if v is not None else ""
    return s or None


def _event_step(row: dict) -> dict | None:
    try:
        p = json.loads(row["raw_payload"] or "{}")
    except (TypeError, ValueError):
        p = {}
    if not isinstance(p, dict):
        p = {}
    raw_status = _clean(p.get("ordSt"))
    filled = _num(p.get("fldQty"))
    unfilled = _num(p.get("unFldSz"))
    avg = _num(p.get("avgPrc"))
    reason = _clean(p.get("rejRsn")) or _clean(p.get("ordUsrMsg"))
    key = (str(raw_status or "").lower(), filled, unfilled, avg, reason)
    title = _FRIENDLY.get(str(raw_status or "").lower(), raw_status or "अपडेट")
    bits = []
    if filled is not None:
        bits.append(f"भरा {filled}" + (f" (बाकी {unfilled})" if unfilled is not None else ""))
    if avg:
        bits.append(f"औसत {avg}")
    if reason:
        bits.append(f"कारण: {reason}")
    return {
        "kind": "update", "db_at": row["received_at"], "shown_at": _clean(p.get("updRecvTm")) or _clean(p.get("hsUpTm")) or row["received_at"],
        "title": title, "detail": " · ".join(bits), "tone": _TONE.get(str(raw_status or "").lower(), "info"),
        "sources": [_SOURCE.get(row["event_source"], row["event_source"])], "_key": key,
    }


def build_timeline(order: dict, events: list[dict], trades: list[dict]) -> dict:
    side = {"B": "BUY", "S": "SELL"}.get(str(order.get("transaction_type")), str(order.get("transaction_type") or ""))
    px = f" @ {order['price']}" if order.get("price") else ""
    steps = [{
        "kind": "created", "db_at": order.get("created_at"), "shown_at": order.get("created_at"), "title": "ऑर्डर बनाया",
        "detail": f"{side} {order.get('quantity')}{px} · {order.get('order_type')} · {order.get('product')}", "tone": "info", "sources": ["सिस्टम"],
    }]
    merged: list[dict] = []
    for e in sorted(events, key=lambda r: r["id"]):
        s = _event_step(e)
        if merged and merged[-1]["_key"] == s["_key"]:
            if s["sources"][0] not in merged[-1]["sources"]:
                merged[-1]["sources"].append(s["sources"][0])
            merged[-1]["repeats"] = merged[-1].get("repeats", 1) + 1
            continue
        merged.append(s)
    steps += merged
    for t in sorted(trades, key=lambda r: r["id"]):
        steps.append({"kind": "fill", "db_at": t.get("created_at"), "shown_at": t.get("fill_time") or t.get("created_at"),
                      "title": "फ़िल हुआ", "detail": f"{t.get('fill_quantity')} @ {t.get('fill_price')}", "tone": "good", "sources": ["trade report"]})
    order_ix = {"created": 0, "update": 1, "fill": 1}
    steps.sort(key=lambda s: (str(s["db_at"] or ""), order_ix[s["kind"]]))   # same-clock ties keep: created, updates, fills
    for s in steps:
        s.pop("_key", None)
    return {
        "order": {"internal_order_id": order["internal_order_id"], "symbol": order["trading_symbol"], "side": side, "quantity": order["quantity"],
                  "filled_quantity": order.get("filled_quantity"), "average_price": order.get("average_price"), "status": order["status"],
                  "reason": order.get("status_reason"), "broker_status": order.get("broker_status"), "unconfirmed": bool(order.get("outcome_unknown"))},
        "steps": steps,
    }


def order_timeline(internal_order_id: str) -> dict | None:
    order = db.get_order(str(internal_order_id))
    if order is None:
        return None
    with db._connection() as conn:
        conn.row_factory = None
        ev = [dict(zip(("id", "event_source", "raw_payload", "received_at"), r)) for r in conn.execute(
            "SELECT id,event_source,raw_payload,received_at FROM order_events WHERE order_id=? OR (broker_order_id IS NOT NULL AND broker_order_id=?) ORDER BY id LIMIT 500",
            (order["id"], order.get("broker_order_id")))]
        tr = [dict(zip(("id", "fill_quantity", "fill_price", "fill_time", "created_at"), r)) for r in conn.execute(
            "SELECT id,fill_quantity,fill_price,fill_time,created_at FROM trades WHERE order_id=? OR (broker_order_id IS NOT NULL AND broker_order_id=?) ORDER BY id LIMIT 500",
            (order["id"], order.get("broker_order_id")))]
    return build_timeline(order, ev, tr)
