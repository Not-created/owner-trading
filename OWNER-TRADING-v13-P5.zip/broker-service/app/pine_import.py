"""Pine Script (v4/v5 subset) -> the strategy engine's own condition groups.

Why a SUBSET: Pine is TradingView's language and cannot be run here. Only logic whose meaning is identical in the
engine is translated; everything else is reported in plain words and makes the result NOT ok. A partly understood
rule is never returned as tradable: dropping a condition silently would trade on a rule the user did not write.

Supported
  values      close open high low volume vwap, close[1] (offsets), numbers, input.int/float/bool defaults
  indicators  ta.sma/ema (src close; sma also on volume), ta.rsi(close,n), ta.atr(n), ta.macd(close,12,26,9),
              ta.bb(close,n,2), ta.highest(high,n)[1] / ta.lowest(low,n)[1], ta.vwap
  tests       > >= < <= == !=, ta.crossover / ta.crossunder, and / or / not, ( ), a > b * 1.5
  signals     strategy.entry(long/short) under `if` (or when=), strategy.close, alertcondition, plotshape, or a
              boolean variable the user picks
Ignored on purpose (drawing only, no effect on trades): plot*, bgcolor, barcolor, hline, label/line/box/table.*
"""
from __future__ import annotations

import re

from . import strategy_engine as se

# ----------------------------------------------------------------------------- tokenizer
_TOKEN = re.compile(r"""\s*(?:
    (?P<num>\d+\.\d*|\.\d+|\d+)
  | (?P<id>[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*)
  | (?P<str>"[^"]*"|'[^']*')
  | (?P<op>>=|<=|==|!=|:=|=>|[-+*/%<>=(),\[\]?:])
)""", re.X)


class PineError(Exception):
    """A statement uses something the engine cannot reproduce exactly. The message is shown to the user."""


def _tokens(text: str) -> list[tuple[str, str]]:
    out, pos, text = [], 0, text.rstrip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise PineError(f"समझ नहीं आया: {text[pos:pos + 12]!r}")
        pos = m.end()
        kind = m.lastgroup
        out.append((kind, m.group(kind)))
    return out


# ----------------------------------------------------------------------------- values
# A value is one of:
#   ("num", float)                      a constant
#   ("opd", "ema20", k)                 an engine operand times a positive constant k (usually 1.0)
#   ("bool", node)                      a condition tree: ("cond", cond_dict) | ("and"|"or", [nodes]) | ("not", node)
#   ("tuple", [values])                 result of ta.macd / ta.bb
#   ("src_high",) / ("src_low",)        high / low used as a source for ta.highest / ta.lowest


def _op(name: str, k: float = 1.0):
    return ("opd", name, k)


_BUILTIN = {"close", "open", "high", "low", "volume", "vwap", "ta.vwap"}


class _Parser:
    def __init__(self, tokens, env, failed=None):
        self.t, self.i, self.env, self.failed = tokens, 0, env, failed or {}

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self, value=None):
        tok = self.peek()
        if tok[0] is None or (value is not None and tok[1] != value):
            raise PineError(f"{value!r} की उम्मीद थी" if value else "वाक्य अधूरा है")
        self.i += 1
        return tok

    def done(self):
        return self.i >= len(self.t)

    # precedence: or < and < not < comparison < + - < * / < unary < call / index
    def expr(self):
        left = self.and_()
        while self.peek() == ("id", "or"):
            self.take()
            left = self._join("or", left, self.and_())
        return left

    def and_(self):
        left = self.not_()
        while self.peek() == ("id", "and"):
            self.take()
            left = self._join("and", left, self.not_())
        return left

    def not_(self):
        if self.peek() == ("id", "not"):
            self.take()
            return ("bool", ("not", _as_bool(self.not_())))
        return self.cmp_()

    def cmp_(self):
        left = self.add()
        kind, val = self.peek()
        if kind == "op" and val in (">", ">=", "<", "<=", "==", "!="):
            self.take()
            return _compare(left, val, self.add())
        return left

    def add(self):
        left = self.mul()
        while self.peek()[1] in ("+", "-") and self.peek()[0] == "op":
            sign = self.take()[1]
            right = self.mul()
            if left[0] == "num" and right[0] == "num":
                left = ("num", left[1] + right[1] if sign == "+" else left[1] - right[1])
            else:
                raise PineError("शर्त के अंदर जोड़/घटाव (जैसे close + atr) समर्थित नहीं है")
        return left

    def mul(self):
        left = self.unary()
        while self.peek()[1] in ("*", "/") and self.peek()[0] == "op":
            sign = self.take()[1]
            right = self.unary()
            left = _scale(left, right, sign)
        return left

    def unary(self):
        if self.peek() == ("op", "-"):
            self.take()
            v = self.unary()
            if v[0] != "num":
                raise PineError("ऋणात्मक (minus) मान सिर्फ़ संख्या के लिए समर्थित है")
            return ("num", -v[1])
        return self.postfix()

    def postfix(self):
        v = self.atom()
        while self.peek() == ("op", "["):
            self.take()
            idx = self.expr()
            self.take("]")
            if idx[0] != "num" or idx[1] != int(idx[1]) or not 0 <= idx[1] <= se.MAX_OFFSET:
                raise PineError("[ ] में 0 से 50 तक की पूरी संख्या ही चलती है")
            v = _shift(v, int(idx[1]))
        return v

    def atom(self):
        kind, val = self.take()
        if kind == "num":
            return ("num", float(val))
        if kind == "str":
            raise PineError("text मान शर्त में समर्थित नहीं है")
        if kind == "op" and val == "(":
            v = self.expr()
            self.take(")")
            return v
        if kind == "id":
            if self.peek() == ("op", "("):
                return self.call(val)
            return self.name(val)
        raise PineError(f"अनपेक्षित चिह्न {val!r}")

    def name(self, ident):
        if ident in ("true", "false"):
            raise PineError("true/false सीधे शर्त में समर्थित नहीं")
        if ident in self.env:
            return self.env[ident]
        if ident in self.failed:
            raise PineError(f"{ident} समझ नहीं आया ({self.failed[ident]})")
        if ident in ("strategy.long", "strategy.short"):
            return _op(ident)
        if ident == "ta.vwap":
            return _op("vwap")
        if ident in _BUILTIN:
            return _op(ident)
        if ident in ("hl2", "hlc3", "ohlc4", "hlcc4"):
            raise PineError(f"{ident} (औसत price) समर्थित नहीं है")
        raise PineError(f"{ident!r} पहले परिभाषित नहीं हुआ या समर्थित नहीं है")

    def args(self):
        self.take("(")
        pos, named = [], {}
        while self.peek() != ("op", ")"):
            if self.peek()[0] == "id" and self.i + 1 < len(self.t) and self.t[self.i + 1] == ("op", "="):
                key = self.take()[1]
                self.take("=")
                named[key] = self._arg_value()
            else:
                pos.append(self._arg_value())
            if self.peek() == ("op", ","):
                self.take()
        self.take(")")
        return pos, named

    def _arg_value(self):
        if self.peek()[0] == "str":
            return ("str", self.take()[1][1:-1])
        return self.expr()

    def call(self, fn):
        pos, named = self.args()
        return _call(fn, pos, named)

    def _join(self, kind, a, b):
        a, b = _as_bool(a), _as_bool(b)
        items = [x for n in (a, b) for x in (n[1] if n[0] == kind else [n])]
        return ("bool", (kind, items))


# ----------------------------------------------------------------------------- helpers
def _as_bool(v):
    if v[0] == "bool":
        return v[1]
    raise PineError("यहाँ हाँ/नहीं वाली शर्त चाहिए (जैसे close > ema20)")


def _num(v, what):
    if v[0] != "num":
        raise PineError(f"{what} एक निश्चित संख्या होनी चाहिए")
    return v[1]


def _shift(v, n):
    if n == 0:
        return v
    if v[0] == "opd":
        p = se.parse_operand(v[1])
        base, period, off = p
        name = v[1].split("[")[0]
        return ("opd", f"{name}[{off + n}]", v[2])
    if v[0] == "hh":
        return _op(f"{v[1]}{v[2]}") if n == 1 else _no_shift()
    raise PineError("[ ] इस मान पर समर्थित नहीं है")


def _no_shift():
    raise PineError("ta.highest/lowest के साथ सिर्फ़ [1] चलता है")


def _scale(a, b, sign):
    if a[0] == "num" and b[0] == "num":
        if sign == "/" and b[1] == 0:
            raise PineError("शून्य से भाग")
        return ("num", a[1] * b[1] if sign == "*" else a[1] / b[1])
    if a[0] == "opd" and b[0] == "num" and b[1] > 0:
        return ("opd", a[1], a[2] * b[1] if sign == "*" else a[2] / b[1])
    if sign == "*" and a[0] == "num" and b[0] == "opd" and a[1] > 0:
        return ("opd", b[1], b[2] * a[1])
    raise PineError("गुणा/भाग सिर्फ़ 'मान × धनात्मक संख्या' के रूप में समर्थित है")


_FLIP = {">": "<", ">=": "<=", "<": ">", "<=": ">=", "==": "==", "!=": "!="}


def _compare(a, op, b):
    """left op right x mult (mult scales the RIGHT side in the engine). A scaled left side moves over: A*k op B == A op B/k."""
    if a[0] == "num" and b[0] == "num":
        raise PineError("दो संख्याओं की तुलना शर्त नहीं है")
    if "hh" in (a[0], b[0]):
        raise PineError("ta.highest/ta.lowest के साथ [1] लगाना ज़रूरी है (पिछली N candles का उच्चतम/निम्नतम)")
    if a[0] == "num":                       # 55 < rsi  ->  rsi > 55
        a, b, op = b, a, _FLIP[op]
    if a[0] != "opd":
        raise PineError("तुलना के बाएँ तरफ़ कोई indicator/price चाहिए")
    if b[0] not in ("num", "opd"):
        raise PineError("तुलना के दाएँ तरफ़ indicator, price या संख्या चाहिए")
    left, k_left = a[1], a[2]
    if b[0] == "num":
        # (A*k) op N  ==  A op N/k
        return ("bool", ("cond", _cond(left, op, _fmt(b[1] / k_left))))
    right, k_right = b[1], b[2]
    mult = k_right / k_left
    return ("bool", ("cond", _cond(left, op, right, mult)))


def _fmt(x):
    return int(x) if float(x).is_integer() else round(float(x), 10)


def _cond(left, op, right, mult=None):
    c = {"left": left, "operator": op, "right": right}
    if mult is not None and abs(mult - 1.0) > 1e-12:
        c["mult"] = round(mult, 10)
    return c


def _plain(v, what):
    if v[0] != "opd" or v[2] != 1.0:
        raise PineError(f"{what} में सीधा मान चाहिए")
    return v[1]


def _call(fn, pos, named):
    n = len(pos)
    fn = {"crossover": "ta.crossover", "crossunder": "ta.crossunder", "highest": "ta.highest", "lowest": "ta.lowest"}.get(fn, fn)
    if fn in ("input", "input.int", "input.float", "input.bool"):
        d = named.get("defval", pos[0] if pos else None)
        if d is None or d[0] != "num":
            raise PineError("input की डिफ़ॉल्ट संख्या चाहिए")
        return d
    if fn in ("input.source",):
        d = named.get("defval", pos[0] if pos else None)
        if d == _op("close"):
            return d
        raise PineError("input.source सिर्फ़ close के लिए समर्थित है")
    if fn in ("ta.sma", "ta.ema", "sma", "ema"):
        if n != 2:
            raise PineError(f"{fn}(स्रोत, लंबाई) चाहिए")
        base, src, length = fn.split(".")[-1], pos[0], _num(pos[1], "लंबाई")
        if length != int(length):
            raise PineError("लंबाई पूरी संख्या होनी चाहिए")
        src_name = _plain(src, f"{fn} का स्रोत")
        if src_name == "volume" and base == "sma":
            name = f"volume_sma{int(length)}"
        elif src_name == "close":
            name = f"{base}{int(length)}"
        else:
            raise PineError(f"{fn} सिर्फ़ close पर (और sma सिर्फ़ volume पर भी) समर्थित है, {src_name} पर नहीं")
        _need_valid(name)
        return _op(name)
    if fn in ("ta.rsi", "rsi"):
        if n != 2 or _plain(pos[0], "ta.rsi का स्रोत") != "close":
            raise PineError("ta.rsi(close, लंबाई) ही समर्थित है")
        name = f"rsi{int(_num(pos[1], 'लंबाई'))}"
        _need_valid(name)
        return _op(name)
    if fn in ("ta.atr", "atr"):
        if n != 1:
            raise PineError("ta.atr(लंबाई) चाहिए")
        name = f"atr{int(_num(pos[0], 'लंबाई'))}"
        _need_valid(name)
        return _op(name)
    if fn == "ta.macd":
        if n != 4 or _plain(pos[0], "ta.macd का स्रोत") != "close" or [_num(p, "मान") for p in pos[1:]] != [12, 26, 9]:
            raise PineError("ta.macd सिर्फ़ ta.macd(close, 12, 26, 9) के रूप में समर्थित है")
        return ("tuple", [_op("macd"), _op("macd_signal"), _op("macd_hist")])
    if fn == "ta.bb":
        if n != 3 or _plain(pos[0], "ta.bb का स्रोत") != "close" or _num(pos[2], "गुणक") != 2:
            raise PineError("ta.bb सिर्फ़ ta.bb(close, लंबाई, 2) के रूप में समर्थित है")
        length = int(_num(pos[1], "लंबाई"))
        return ("tuple", [_op(f"bb_mid{length}"), _op(f"bb_upper{length}"), _op(f"bb_lower{length}")])
    if fn in ("ta.highest", "ta.lowest"):
        if n != 2:
            raise PineError(f"{fn}(स्रोत, लंबाई) चाहिए")
        src = _plain(pos[0], f"{fn} का स्रोत")
        want = "high" if fn == "ta.highest" else "low"
        if src != want:
            raise PineError(f"{fn} सिर्फ़ {want} पर समर्थित है")
        length = int(_num(pos[1], "लंबाई"))
        return ("hh", "hh" if want == "high" else "ll", length)
    if fn in ("ta.crossover", "ta.crossunder"):
        if n != 2:
            raise PineError(f"{fn}(a, b) चाहिए")
        a, b = pos
        if a[0] == "num":
            raise PineError(f"{fn} के पहले मान में indicator/price चाहिए")
        op = "cross_above" if fn == "ta.crossover" else "cross_below"
        if a[0] != "opd" or b[0] not in ("num", "opd"):
            raise PineError(f"{fn} में सिर्फ़ indicator, price या संख्या चलती है")
        if b[0] == "num":
            return ("bool", ("cond", _cond(a[1], op, _fmt(b[1] / a[2]))))
        return ("bool", ("cond", _cond(a[1], op, b[1], b[2] / a[2])))
    if fn.startswith(("request.security", "security")):
        raise PineError("दूसरे timeframe का data (security) समर्थित नहीं है")
    raise PineError(f"फ़ंक्शन {fn!r} समर्थित नहीं है")


def _need_valid(name):
    if not se.operand_valid(name):
        raise PineError(f"{name} इंजन की सीमा से बाहर है")


# ----------------------------------------------------------------------------- conditions -> engine groups
def _and(a, b):
    items = [x for n in (a, b) for x in (n[1] if n[0] == "and" else [n])]
    return ("and", items)


def _to_group(node, negate=False):
    """Convert a bool tree to the engine's {op, conditions, groups, not} shape."""
    kind = node[0]
    if kind == "cond":
        c = dict(node[1])
        if negate:
            c["not"] = True
        return {"op": "AND", "conditions": [c]}
    if kind == "not":
        return _to_group(node[1], not negate)
    items = node[1]
    group = {"op": "AND" if kind == "and" else "OR", "conditions": [], "groups": []}
    for it in items:
        if it[0] == "cond":
            group["conditions"].append(dict(it[1]))
        elif it[0] == "not" and it[1][0] == "cond":      # not <single test>  ->  the test with not=true
            c = dict(it[1][1])
            if c.get("not"):
                c.pop("not")
            else:
                c["not"] = True
            group["conditions"].append(c)
        else:
            group["groups"].append(_to_group(it))
    if not group["groups"]:
        del group["groups"]
    if negate:
        group["not"] = True
    return group


def _describe(node) -> str:
    kind = node[0]
    if kind == "cond":
        c = node[1]
        txt = f"{c['left']} {c['operator']} {c['right']}"
        if "mult" in c:
            txt += f" ×{c['mult']:g}"
        return ("NOT " if c.get("not") else "") + txt
    if kind == "not":
        return "NOT (" + _describe(node[1]) + ")"
    return "(" + (" AND " if kind == "and" else " OR ").join(_describe(x) for x in node[1]) + ")"


# ----------------------------------------------------------------------------- source -> statements
_IGNORED = re.compile(r"^(?:(?:plot|plotshape|plotchar|plotarrow|plotcandle|plotbar|bgcolor|barcolor|hline|fill|alert)\s*\(|(?:label|line|box|table|linefill)\.\w+)")
_TYPE_PREFIX = re.compile(r"^(?:(?:var|varip)\s+)?(?:float|int|bool|series\s+float|series\s+int|series\s+bool|simple\s+int|simple\s+float|const\s+int|const\s+float)\s+")


def _logical_lines(source: str) -> list[tuple[int, int, str]]:
    """-> [(line_no, indent, text)] with comments stripped and continuation lines joined."""
    out, buf, depth, start, ind = [], "", 0, 0, 0
    for no, raw in enumerate(source.replace("\t", "    ").splitlines(), 1):
        line = re.sub(r"//.*$", "", raw).rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip())
        text = line.strip()
        if not buf and out and re.match(r"^(?:and|or)\b", text):
            out[-1] = (out[-1][0], out[-1][1], out[-1][2] + " " + text)
            continue
        if buf:
            buf += " " + text
        else:
            buf, start, ind = text, no, indent
        depth = buf.count("(") + buf.count("[") - buf.count(")") - buf.count("]")
        if depth > 0 or re.search(r"(?:\band|\bor|[-+*/<>=,(])$", buf):
            continue
        out.append((start, ind, buf))
        buf = ""
    if buf:
        out.append((start, ind, buf))
    return out


def translate(source: str, *, entry: str | None = None, exit_: str | None = None, side: str | None = None) -> dict:
    """Translate Pine text. `entry` / `exit_` name the boolean variable to use when the script does not say clearly."""
    source = str(source or "")
    if len(source) > 60_000:
        return {"ok": False, "errors": [{"line": 0, "text": "", "reason": "Script बहुत बड़ी है (60,000 अक्षर तक)"}]}
    env: dict = {}
    failed: dict[str, str] = {}      # variable -> why it could not be translated
    bools: dict[str, tuple] = {}     # variable -> bool tree
    ignored: list[dict] = []
    notes: list[str] = []
    errors: list[dict] = []
    orders: list[dict] = []          # {kind: entry|close, side, node|None, line}
    candidates: list[dict] = []      # extra signal sources: alertcondition / plotshape
    lines = _logical_lines(source)
    version = None
    m = re.search(r"//@version\s*=\s*(\d+)", source)
    version = int(m.group(1)) if m else None
    if version not in (None, 4, 5):
        notes.append(f"Pine v{version} पूरी तरह जाँची नहीं गई; v5 सबसे भरोसेमंद है")

    def parse(text, line_no):
        p = _Parser(_tokens(text), env, failed)
        v = p.expr()
        if not p.done():
            raise PineError(f"वाक्य के अंत में अतिरिक्त: {p.peek()[1]!r}")
        return v

    guard_stack: list[tuple[int, tuple | None, str | None]] = []   # (indent, node, failed_reason)
    for line_no, indent, text in lines:
        while guard_stack and indent <= guard_stack[-1][0]:
            guard_stack.pop()
        low = text.lower()
        if re.match(r"^(//@|indicator\s*\(|strategy\s*\(|study\s*\()", text) or text.startswith("import "):
            continue
        if _IGNORED.match(text):
            ignored.append({"line": line_no, "text": text[:80]})
            m = re.match(r"^plotshape\s*\(\s*(.+?)\s*(?:,|\))", text)
            if m and low.startswith("plotshape"):
                try:
                    candidates.append({"source": "plotshape", "line": line_no, "node": _as_bool(parse(m.group(1), line_no)),
                                       "side": "SELL" if re.search(r"(?:down|sell|short|abovebar)", low) else "BUY"})
                except PineError:
                    pass
            continue
        try:
            # -- if cond  (block guard)
            m = re.match(r"^if\s+(.+)$", text)
            if m:
                try:
                    guard_stack.append((indent, _as_bool(parse(m.group(1), line_no)), None))
                except PineError as exc:
                    guard_stack.append((indent, None, str(exc)))
                    errors.append({"line": line_no, "text": text[:100], "reason": str(exc), "kind": "guard"})
                continue
            # -- alertcondition(cond, ...)
            m = re.match(r"^alertcondition\s*\(\s*(.+?)\s*(?:,|\)\s*$)", text)
            if m:
                candidates.append({"source": "alertcondition", "line": line_no, "node": _as_bool(parse(m.group(1), line_no)), "side": None})
                continue
            # -- strategy.entry / strategy.close
            m = re.match(r"^strategy\.(entry|close|close_all|exit|order)\s*\((.*)\)\s*$", text)
            if m:
                kind = m.group(1)
                pos, named = _Parser(_tokens("(" + m.group(2) + ")"), env, failed).args()
                guard = None
                for _, node, why in guard_stack:
                    if why:
                        raise PineError("इस order की if-शर्त समझ नहीं आई: " + why)
                    if node is not None:
                        guard = node if guard is None else _and(guard, node)
                if "when" in named:
                    w = _as_bool(named["when"])
                    guard = w if guard is None else _and(guard, w)
                if kind in ("entry", "order"):
                    dirn = (pos[1] if len(pos) > 1 else named.get("direction"))
                    if not dirn or dirn[0] != "opd" or dirn[1] not in ("strategy.long", "strategy.short"):
                        raise PineError("strategy.entry में strategy.long या strategy.short चाहिए")
                    orders.append({"kind": "entry", "side": "BUY" if dirn[1] == "strategy.long" else "SELL", "node": guard, "line": line_no})
                elif kind in ("close", "close_all"):
                    orders.append({"kind": "close", "side": None, "node": guard, "line": line_no})
                else:
                    notes.append(f"लाइन {line_no}: strategy.exit (stop/target) Pine से नहीं लिया गया; Stop-loss और Target Risk में अलग से तय करें")
                continue
            # -- tuple destructuring  [a, b, c] = ta.macd(...)
            m = re.match(r"^\[\s*([A-Za-z_0-9,\s]+?)\s*\]\s*=\s*(.+)$", text)
            if m:
                names = [x.strip() for x in m.group(1).split(",")]
                v = parse(m.group(2), line_no)
                if v[0] != "tuple" or len(v[1]) != len(names):
                    raise PineError("इस रूप का tuple समर्थित नहीं है")
                for nm, val in zip(names, v[1]):
                    if nm != "_":
                        env[nm] = val
                continue
            # -- reassignment / unsupported statements
            if ":=" in text:
                raise PineError(":= (मान बदलना) समर्थित नहीं है")
            if re.match(r"^(for|while|switch|else|function|f_)\b", text) or "=>" in text:
                raise PineError("loop/function/else जैसी बनावट समर्थित नहीं है")
            # -- assignment  name = expr
            if guard_stack and re.match(r"^(?:%s)?[A-Za-z_][A-Za-z_0-9]*\s*=[^=]" % _TYPE_PREFIX.pattern.replace("^", "", 1), text):
                raise PineError("if-block के अंदर मान बनाना समर्थित नहीं है")
            m = re.match(r"^(?:%s)?([A-Za-z_][A-Za-z_0-9]*)\s*=\s*(.+)$" % _TYPE_PREFIX.pattern.replace("^", "", 1), text)
            if m and "==" not in text.split("=", 1)[0]:
                name, expr = m.group(1), m.group(2)
                try:
                    v = parse(expr, line_no)
                except PineError as exc:
                    failed[name] = str(exc)
                    errors.append({"line": line_no, "text": text[:100], "reason": str(exc), "var": name, "kind": "assign"})
                    continue
                env[name] = v
                if v[0] == "bool":
                    bools[name] = v[1]
                continue
            raise PineError("यह लाइन समझ नहीं आई")
        except PineError as exc:
            kind = "order" if re.match(r"^strategy\.(entry|close|close_all|exit|order)\b", text) else "statement"
            errors.append({"line": line_no, "text": text[:100], "reason": str(exc), "kind": kind})

    return _finish(source, env, bools, failed, orders, candidates, errors, ignored, notes, entry, exit_, side)


def _finish(source, env, bools, failed, orders, candidates, errors, ignored, notes, entry, exit_, side):
    # Which boolean means "enter"? Explicit order > chosen variable > alertcondition/plotshape > a clearly named variable.
    entries: list[dict] = []
    # A line that changes state or places/closes orders and could not be understood may change what the rule means
    # (a filter, a reset, a different order). That blocks the result. Plain unsupported assignments do not block on
    # their own: if the rule uses them the failure propagates into the rule; if it does not, they are irrelevant.
    blockers = [e for e in errors if e.get("kind") in ("statement", "order")]
    if blockers:
        shown = "; ".join(f"लाइन {e['line']} ({e['reason']})" for e in blockers[:4])
        return _result(False, errors, ignored, notes, entries, None, bools, candidates,
                       why="ऐसी लाइनें हैं जिन्हें समझा नहीं जा सका और ये शर्त का मतलब बदल सकती हैं: " + shown)
    if entry:
        if entry in bools:
            entries.append({"side": (side or "BUY").upper(), "node": bools[entry], "source": f"आपने चुना: {entry}"})
        elif entry in failed:
            return _result(False, errors, ignored, notes, entries, None, bools, candidates, why=f"{entry} समझ नहीं आया: {failed[entry]}")
        else:
            return _result(False, errors, ignored, notes, entries, None, bools, candidates, why=f"{entry} नाम की कोई शर्त नहीं मिली")
    else:
        for o in orders:
            if o["kind"] == "entry":
                if o["node"] is None:
                    errors.append({"line": o["line"], "text": "strategy.entry", "reason": "बिना शर्त के entry (हर candle पर) समर्थित नहीं"})
                else:
                    entries.append({"side": o["side"], "node": o["node"], "source": f"strategy.entry (लाइन {o['line']})"})
        if not entries:
            named = [(n, t) for n, t in bools.items() if re.fullmatch(r"(?i)(buy|long|entry|longcond\w*|buycond\w*|buysignal|longsignal|longentry)", n)]
            named_short = [(n, t) for n, t in bools.items() if re.fullmatch(r"(?i)(sell|short|shortcond\w*|sellcond\w*|sellsignal|shortsignal|shortentry)", n)]
            for n, t in named:
                entries.append({"side": "BUY", "node": t, "source": f"नाम से पहचाना: {n}"})
            for n, t in named_short:
                entries.append({"side": "SELL", "node": t, "source": f"नाम से पहचाना: {n}"})
        if not entries and len(candidates) == 1:
            c = candidates[0]
            entries.append({"side": c["side"] or "BUY", "node": c["node"], "source": f"{c['source']} (लाइन {c['line']})"})
        if not entries:
            entry_like = [n for n in failed if re.fullmatch(r"(?i)(buy|long|sell|short|entry)\w*", n)]
            if entry_like or any(o["kind"] == "entry" for o in orders):
                first = next((e for e in errors if e.get("var") in entry_like), errors[0] if errors else None)
                return _result(False, errors, ignored, notes, entries, None, bools, candidates,
                               why="Entry की शर्त पूरी समझ नहीं आई: " + (first["reason"] if first else "अज्ञात"))
            if errors and not bools and not candidates:
                return _result(False, errors, ignored, notes, entries, None, bools, candidates, why="Script की कोई शर्त समझ नहीं आई: " + errors[0]["reason"])
            return _result(False, errors, ignored, notes, entries, None, bools, candidates, need_choice=True,
                           why="कौन-सी शर्त BUY की है, यह साफ़ नहीं है। नीचे से चुनें।")
    exit_node = None
    if exit_:
        if exit_ in bools:
            exit_node = bools[exit_]
        else:
            return _result(False, errors, ignored, notes, entries, None, bools, candidates, why=f"{exit_} नाम की कोई शर्त नहीं मिली")
    else:
        closes = [o for o in orders if o["kind"] == "close" and o["node"] is not None]
        if closes:
            exit_node = closes[0]["node"]
    sides = {e["side"] for e in entries}
    primary_side = (side or ("BUY" if "BUY" in sides else "SELL")).upper()
    chosen = next((e for e in entries if e["side"] == primary_side), entries[0])
    ok = True
    definition = {"side": chosen["side"], "entry": _to_group(chosen["node"])}
    if exit_node is not None:
        definition["exit"] = _to_group(exit_node)
    result = _result(ok, errors, ignored, notes, entries, definition, bools, candidates)
    result["entry_summary"] = _describe(chosen["node"])
    result["entry_source"] = chosen["source"]
    result["exit_summary"] = _describe(exit_node) if exit_node is not None else None
    result["needs_exit"] = exit_node is None
    result["other_sides"] = [{"side": e["side"], "summary": _describe(e["node"]), "source": e["source"]} for e in entries if e is not chosen]
    # Always re-validate with the engine's own validator (a stand-in exit is used only for this check).
    placeholder_exit = {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 0}]}
    errs = se.validate_strategy({**definition, "exit": definition.get("exit") or placeholder_exit})
    if errs:
        result["ok"] = False
        result["reason"] = "इंजन की जाँच में गड़बड़ी: " + "; ".join(errs[:3])
        result["definition"] = None
    return result


def _result(ok, errors, ignored, notes, entries, definition, bools, candidates, why="", need_choice=False):
    if ignored:
        notes = notes + [f"{len(ignored)} drawing/alert लाइनें ट्रेड पर असर नहीं डालतीं, इसलिए छोड़ दी गईं"]
    return {
        "ok": bool(ok and definition),
        "reason": why,
        "need_choice": need_choice,
        "definition": definition,
        "errors": errors,
        "notes": notes,
        "ignored_lines": len(ignored),
        "choices": [{"name": n, "summary": _describe(t)} for n, t in bools.items()][:30],
        "accuracy_note": ("TradingView और यह सिस्टम EMA/RSI की शुरुआती गणना थोड़ी अलग तरह करते हैं, इसलिए मान बहुत मामूली अलग "
                          "आ सकते हैं। Backtest से जाँचें।"),
    }
