"""Read-only data for the Live Auto screen: next candle close, armed strategies, last scan per strategy, latest
signals, and candles + indicator lines + signal markers for one stock chart.

Nothing here writes to the database, subscribes to the feed or talks to the broker."""
from __future__ import annotations

import datetime as dt

from . import db, strategy_engine as se
from .scanner_engine import IST, DAILY_SCAN_TIME, SESSION_CLOSE, SESSION_OPEN

LINE_BASES = {"ema", "sma", "vwap", "bb_upper", "bb_mid", "bb_lower", "hh", "ll"}   # same price scale as candles
MAX_LINES = 4
CHART_MAX_BARS = 300


def next_bar_close(timeframe: str, now: dt.datetime | None = None) -> dt.datetime | None:
    """The next instant (IST) a bar of `timeframe` closes, skipping weekends and market holidays. None if unknown."""
    from .market_session import holidays
    minutes = int(se.TIMEFRAMES.get(timeframe, 0))
    if not minutes:
        return None
    local = (now or dt.datetime.now(dt.timezone.utc)).astimezone(IST)
    off = holidays()
    for add_days in range(0, 12):
        day = local.date() + dt.timedelta(days=add_days)
        if day.weekday() >= 5 or day in off:
            continue
        if minutes >= 1440:
            candidate = dt.datetime.combine(day, DAILY_SCAN_TIME, IST)
            if candidate > local:
                return candidate
            continue
        open_dt = dt.datetime.combine(day, SESSION_OPEN, IST)
        close_dt = dt.datetime.combine(day, SESSION_CLOSE, IST)
        step = dt.timedelta(minutes=minutes)
        t = open_dt + step
        while t < close_dt and t <= local:
            t += step
        t = min(t, close_dt)            # the last, possibly partial, bar closes at the session close
        if t > local:
            return t
    return None


def _describe_group(group) -> str:
    """Short text of an entry/exit group (same wording style as the Pine panel)."""
    if not isinstance(group, dict):
        return ""
    parts = []
    for c in group.get("conditions") or []:
        txt = f"{c.get('left')} {c.get('operator')} {c.get('right')}"
        if c.get("mult") is not None:
            txt += f" x{c['mult']:g}"
        parts.append(("NOT " if c.get("not") else "") + txt)
    for g in group.get("groups") or []:
        parts.append("(" + _describe_group(g) + ")")
    joined = (" " + str(group.get("op", "AND")).upper() + " ").join(parts)
    return ("NOT (" + joined + ")") if group.get("not") else joined


def live_status(now: dt.datetime | None = None) -> dict:
    now = now or dt.datetime.now(dt.timezone.utc)
    runs = db.list_scan_runs(60)
    last_run_by_version: dict = {}
    for r in runs:                       # newest first
        vid = r.get("strategy_version_id")
        if vid is not None and vid not in last_run_by_version:
            last_run_by_version[vid] = r
    strategies = []
    for s in db.list_strategies():
        if not s or not s.get("versions"):
            continue
        versions = sorted(s["versions"], key=lambda v: v["version"], reverse=True)
        shown = [v for v in versions if v.get("is_live_armed")] or versions[:1]
        for v in shown:
            d = v.get("definition") or {}
            tf = str(d.get("timeframe") or "5m")
            nxt = next_bar_close(tf, now)
            run = last_run_by_version.get(v["id"])
            stats = (run or {}).get("stats") or {}
            strategies.append({
                "version_id": v["id"], "strategy_id": s["id"], "name": s["name"], "version": v["version"],
                "status": v.get("status"), "armed": bool(v.get("is_live_armed")),
                "timeframe": tf, "side": str(d.get("side") or "BUY").upper(),
                "entry_summary": _describe_group(d.get("entry")), "exit_summary": _describe_group(d.get("exit")),
                "next_close_in_s": int((nxt - now.astimezone(IST)).total_seconds()) if nxt else None,
                "last_scan": None if not run else {
                    "bar_at": run.get("bar_at"), "status": run.get("status"), "duration_ms": run.get("duration_ms"),
                    "universe": run.get("universe"), "evaluated": run.get("evaluated"), "matched": run.get("matched"),
                    "readiness_pct": stats.get("readiness_pct"), "started_at": run.get("started_at")},
            })
    signals = db.list_signals(12)
    today = now.astimezone(IST).strftime("%Y-%m-%d")
    # created_at is stored in UTC by SQLite; only the signal date matters for the "today" tile.
    signals_today = sum(1 for x in db.list_signals(500) if str(x.get("created_at") or "")[:10] == today or str(x.get("candle_at") or "")[:10] == today)
    return {
        "server_now_ist": now.astimezone(IST).strftime("%Y-%m-%d %H:%M:%S"),
        "strategies": strategies,
        "signals": [{"id": x["id"], "symbol": x["trading_symbol"], "side": x["side"], "price": x["signal_price"],
                     "status": x["status"], "candle_at": x["candle_at"], "created_at": x["created_at"],
                     "exchange_segment": x["exchange_segment"], "instrument_token": x["instrument_token"], "timeframe": x["timeframe"]}
                    for x in signals],
        "signals_today": signals_today,
        "armed_count": sum(1 for s in strategies if s["armed"]),
    }


def _line_names(definition: dict) -> list[str]:
    names = []
    for n in sorted(se._definition_operand_names(definition)):
        p = se.parse_operand(n)
        if p and p[0] in LINE_BASES and p[2] == 0 and n not in names:
            names.append(n)
    return names[:MAX_LINES]


def chart_data(segment: str, token: str, timeframe: str = "5m", limit: int = 120, version_id: int | None = None) -> dict:
    """Last `limit` completed-or-forming candles, indicator lines the chosen strategy uses, and that stock's signals."""
    limit = max(10, min(int(limit), CHART_MAX_BARS))
    tf_minutes = int(se.TIMEFRAMES.get(timeframe, 0))
    if not tf_minutes:
        raise ValueError("timeframe is invalid")
    definition = {}
    if version_id:
        v = db.get_strategy_version(int(version_id))
        if v:
            definition = v.get("definition") or {}
    names = _line_names(definition)
    warm = max([se.operand_warmup_bars(n, tf_minutes) for n in names] or [0])
    fetch = min(1000, limit + warm + 2)
    inst = {"exchange_segment": segment, "instrument_token": str(token)}
    rows = db.recent_candles_for_instruments([inst], timeframe, fetch).get((segment, str(token)), [])
    shown = rows[-limit:]
    first_shown = len(rows) - len(shown)
    lines = {n: [] for n in names}
    for i in range(first_shown, len(rows)):
        window = rows[:i + 1]
        res = se.Resolver(window, tf_minutes)
        for n in names:
            v = res.value(n)
            lines[n].append(None if v is None else round(float(v), 4))
    with db._connection() as conn:
        sig_rows = conn.execute(
            "SELECT candle_at,side,signal_price,status FROM signals WHERE exchange_segment=? AND instrument_token=? AND timeframe=? "
            "ORDER BY id DESC LIMIT 60", (segment, str(token), timeframe)).fetchall()
    first_at = shown[0]["candle_at"] if shown else None
    markers = [{"candle_at": r[0], "side": r[1], "price": r[2], "status": r[3]} for r in sig_rows if r[0] and first_at and str(r[0]) >= str(first_at)]
    return {"segment": segment, "token": str(token), "timeframe": timeframe,
            "candles": [{"t": c["candle_at"], "o": c["open"], "h": c["high"], "l": c["low"], "c": c["close"], "v": c["volume"]} for c in shown],
            "lines": lines, "markers": markers}
