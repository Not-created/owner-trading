"""Write-behind buffer for the live tick path (Phase 1 of the v13 upgrade).

Why: the WebSocket callback runs on the asyncio event loop -- the same loop that runs protective exits.
Before this module every tick could open a SQLite connection and commit (fsync) three times
(latest tick, forming-bar checkpoint, completed bar). With ~2,800 subscribed stocks that is thousands of
blocking commits per second on a 1-OCPU VPS.

Now the hot path only updates in-memory dictionaries. One background thread writes them once per second,
each kind in ONE transaction:
  * latest tick per instrument      (coalesced: only the newest survives, optional fields keep the last non-null)
  * forming-bar checkpoint per key   (coalesced)
  * completed candles                (queued; never dropped silently -- re-queued if the write fails)

When the writer is not started (unit tests, scripts) every put_* call writes synchronously, exactly like
the old behaviour, so nothing depends on the thread being alive.
"""
from __future__ import annotations

import logging
import threading
import time

from . import db

logger = logging.getLogger("owner_trading.tick_writer")

FLUSH_INTERVAL_SECONDS = 1.0
MAX_PENDING_CANDLES = 200_000
_OPTIONAL_TICK_FIELDS = ("trading_symbol", "close_price", "volume", "upper_circuit", "lower_circuit")


class TickWriter:
    def __init__(self, flush_interval: float = FLUSH_INTERVAL_SECONDS) -> None:
        self._interval = float(flush_interval)
        self._lock = threading.Lock()          # guards the pending buffers (held only for dict operations)
        self._flush_lock = threading.Lock()    # one flush at a time
        self._ticks: dict[tuple[str, str], dict] = {}
        self._states: dict[tuple[str, str, str], dict] = {}
        self._deletes: set[tuple[str, str, str]] = set()
        self._candles: list[dict] = []
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._last_error_log = 0.0
        self.stats = {"flushes": 0, "ticks": 0, "states": 0, "candles": 0, "errors": 0,
                      "last_flush_ms": None, "last_flush_at": None, "last_error": None, "dropped_candles": 0}

    # ------------------------------------------------------------ lifecycle
    @property
    def running(self) -> bool:
        t = self._thread
        return bool(t and t.is_alive() and not self._stop.is_set())

    def start(self) -> None:
        if self.running:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="tick-writer", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 10.0) -> None:
        """Stop the thread and write whatever is still buffered (graceful shutdown / feed stop)."""
        self._stop.set()
        t = self._thread
        if t and t.is_alive():
            t.join(timeout)
        self._thread = None
        self.flush()

    def _loop(self) -> None:
        while not self._stop.wait(self._interval):
            try:
                self.flush()
            except Exception as exc:  # noqa: BLE001 -- the writer must outlive any single DB problem
                self._record_error(exc)

    # ------------------------------------------------------------ producers (hot path: no I/O when running)
    def put_tick(self, **row) -> None:
        if not self.running:
            db.record_market_tick(**row)
            return
        key = (row.get("exchange_segment") or "", str(row["instrument_token"]))
        # last_tick_at must be when the tick ARRIVED, not when the batch is written up to a second later
        # (the order gate judges price freshness from it). Same format as SQLite datetime('now'), UTC.
        row["tick_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        with self._lock:
            prev = self._ticks.get(key)
            if prev is not None:
                for f in _OPTIONAL_TICK_FIELDS:      # same meaning as the SQL COALESCE: a missing field keeps the last known one
                    if row.get(f) is None and prev.get(f) is not None:
                        row[f] = prev[f]
            self._ticks[key] = row

    def put_runtime_state(self, **row) -> None:
        if not self.running:
            db.upsert_candle_runtime_state(**row)
            return
        key = (row["exchange_segment"], str(row["instrument_token"]), row["timeframe"])
        with self._lock:
            self._states[key] = row
            self._deletes.discard(key)

    def delete_runtime_state(self, exchange_segment, instrument_token, timeframe) -> None:
        if not self.running:
            db.delete_candle_runtime_state(exchange_segment, instrument_token, timeframe)
            return
        key = (exchange_segment, str(instrument_token), timeframe)
        with self._lock:
            self._states.pop(key, None)
            self._deletes.add(key)

    def put_candle(self, row: dict) -> None:
        if not self.running:
            db.upsert_candles([row])
            return
        with self._lock:
            if len(self._candles) >= MAX_PENDING_CANDLES:
                del self._candles[0]
                self.stats["dropped_candles"] += 1
            self._candles.append(row)

    # ------------------------------------------------------------ consumer
    def flush(self) -> dict:
        """Write everything buffered right now. Safe to call from any thread."""
        with self._flush_lock:
            with self._lock:
                candles, self._candles = self._candles, []
                deletes, self._deletes = self._deletes, set()
                states, self._states = self._states, {}
                ticks, self._ticks = self._ticks, {}
            if not (candles or deletes or states or ticks):
                return {"candles": 0, "states": 0, "ticks": 0}
            started = time.monotonic()
            done = {"candles": 0, "states": 0, "ticks": 0}
            # 1. completed candles first: they are the data that must never be lost
            if candles:
                try:
                    done["candles"] = db.upsert_candles(candles)
                except Exception as exc:  # noqa: BLE001
                    self._record_error(exc)
                    with self._lock:                       # put them back in front; the next flush retries
                        self._candles = (candles + self._candles)[-MAX_PENDING_CANDLES:]
            # 2. forming-bar checkpoints (a bar that rolled over has its checkpoint removed, not rewritten)
            try:
                if deletes:
                    db.delete_candle_runtime_states_bulk(deletes)
                if states:
                    done["states"] = db.upsert_candle_runtime_states_bulk(list(states.values()))
            except Exception as exc:  # noqa: BLE001
                self._record_error(exc)
            # 3. latest tick per instrument (a lost tick is replaced by the next one, so it is not retried)
            if ticks:
                try:
                    done["ticks"] = db.record_market_ticks_bulk(list(ticks.values()))
                except Exception as exc:  # noqa: BLE001
                    self._record_error(exc)
            self.stats["flushes"] += 1
            self.stats["ticks"] += done["ticks"]
            self.stats["states"] += done["states"]
            self.stats["candles"] += done["candles"]
            self.stats["last_flush_ms"] = int((time.monotonic() - started) * 1000)
            self.stats["last_flush_at"] = time.time()
            return done

    def pending(self) -> dict:
        with self._lock:
            return {"ticks": len(self._ticks), "states": len(self._states), "deletes": len(self._deletes), "candles": len(self._candles)}

    def _record_error(self, exc: Exception) -> None:
        self.stats["errors"] += 1
        self.stats["last_error"] = f"{type(exc).__name__}: {exc}"[:200]
        now = time.monotonic()
        if now - self._last_error_log > 30:      # one log line per 30 s, not one per second
            self._last_error_log = now
            logger.warning("Tick writer database write failed: %s", self.stats["last_error"])


tick_writer = TickWriter()
