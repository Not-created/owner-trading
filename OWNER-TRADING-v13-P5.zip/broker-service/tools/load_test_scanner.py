"""Synthetic large-universe load test of everything a scan depends on. Uses a TEMPORARY database: it never touches real data.

    cd broker-service && python tools/load_test_scanner.py                  # 2,800 stocks x ~160 bars (the real shape)
    python tools/load_test_scanner.py --stocks 2800 --bars 600             # the heaviest definition (ema200)
    python tools/load_test_scanner.py --json                                # machine-readable

Measures: candle read, what-is-missing check, a full scan with a rich definition, feed manager at the 3,000-key limit (with
priority eviction), the tick path (candle engine + write-behind buffer) and bar close for every stock. The numbers are for THIS
machine: run it on the VPS to know that machine's real figures."""
import argparse
import asyncio
import datetime as dt
import json
import os
import sqlite3
import sys
import tempfile
import time
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

RICH = {"side": "BUY", "timeframe": "5m",
        "entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"}, {"left": "rsi14", "operator": ">", "right": 45}],
                  "groups": [{"op": "OR", "conditions": [{"left": "adx14", "operator": ">", "right": 10}, {"left": "macd_hist", "operator": ">", "right": -5},
                                                         {"left": "close", "operator": ">", "right": "vwap"}]}]},
        "scan": {"series": ["EQ"], "max_candidates": 50, "rank_by": "volume"}}


HEAVY = {"side": "BUY", "timeframe": "5m",
         "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "ema200"}, {"left": "rsi14", "operator": ">", "right": 50}]},
         "scan": {"series": ["EQ"], "max_candidates": 50, "rank_by": "volume"}}


def make_db(stocks, bars):
    import glob
    tmp = tempfile.mkdtemp(prefix="ot-load-")
    path = os.path.join(tmp, "load.db")
    conn = sqlite3.connect(path)
    for f in sorted(glob.glob(os.path.join(HERE, "..", "..", "backend", "src", "db", "migrations", "*.sql"))):
        with open(f, encoding="utf-8") as fh:
            conn.executescript(fh.read())
    conn.commit()
    conn.close()
    os.environ["DB_PATH"] = path
    os.environ.setdefault("NEO_LOG_FILE_ENABLED", "false")
    import importlib
    from app import db
    importlib.reload(db)
    db.bulk_upsert_instruments([{"trading_symbol": f"LOAD{i:04d}-EQ", "instrument_token": str(1000 + i), "lot_size": 1, "tick_size": 0.05} for i in range(stocks)])
    IST = dt.timezone(dt.timedelta(hours=5, minutes=30))
    end = dt.datetime.now(IST).replace(second=0, microsecond=0)
    end -= dt.timedelta(minutes=end.minute % 5 + 5)                 # last completed 5-minute bar
    conn = sqlite3.connect(path)
    conn.execute("BEGIN")
    import random
    rnd = random.Random(1)
    for i in range(stocks):
        px, rows = 100 + rnd.random() * 400, []
        for k in range(bars):
            ts = (end - dt.timedelta(minutes=5 * (bars - 1 - k))).strftime("%Y-%m-%d %H:%M:%S")
            nx = max(1.0, px + rnd.uniform(-1, 1))
            rows.append(("nse_cm", str(1000 + i), f"LOAD{i:04d}-EQ", "5m", ts, px, max(px, nx) + 0.3, min(px, nx) - 0.3, nx, rnd.randint(500, 9000)))
            px = nx
        conn.executemany("INSERT INTO candles(exchange_segment,instrument_token,trading_symbol,timeframe,candle_at,open,high,low,close,volume) VALUES(?,?,?,?,?,?,?,?,?,?)", rows)
    conn.commit()
    conn.close()
    return db, path


async def feed_manager_run(stocks):
    from app import sdk_adapter, websocket_manager as wm_mod

    class Feed:
        is_connected = True
        async def subscribe_scrips(self, t): pass
        async def unsubscribe_scrips(self, t): pass

    out = {}
    with mock.patch.object(sdk_adapter, "make_ws_token", lambda s, t: (s, t)):
        m = wm_mod.WebSocketManager()
        m._market = Feed()
        n = min(stocks, 2800)
        t = time.perf_counter(); await m.subscribe_many([("nse_cm", str(1000 + i)) for i in range(n)], owner="scanner-universe"); out["subscribe_scanner_universe_ms"] = round((time.perf_counter() - t) * 1000, 1)
        t = time.perf_counter(); await m.subscribe_many([("nse_cm", str(900000 + i)) for i in range(150)], owner="strategy:1:candidate:nse_cm:900000"); out["subscribe_150_candidates_ms"] = round((time.perf_counter() - t) * 1000, 1)
        t = time.perf_counter(); r = await m.subscribe_many([("nse_cm", str(800000 + i)) for i in range(120)], owner="position:1"); out["120_positions_on_a_full_feed_ms"] = round((time.perf_counter() - t) * 1000, 1)
        out["evicted_for_positions"] = r["evicted"]
        out["feed_total_after"] = len(m._subs)
        out["positions_rejected"] = len(r["rejected"])
    return out


def run(stocks, bars, definition=RICH):
    result = {"stocks": stocks, "bars_per_stock": bars, "candle_rows": stocks * bars}
    t = time.perf_counter()
    db, path = make_db(stocks, bars)
    result["seed_s"] = round(time.perf_counter() - t, 1)
    from app import scanner_engine as se, candle_engine as ce_mod, tick_writer as tw_mod
    universe = se.scan_universe(definition)
    need = se.required_bars(definition)
    result["required_bars"] = need
    t = time.perf_counter(); db.recent_candles_for_instruments(universe, "5m", need + 3); result["candle_read_s"] = round(time.perf_counter() - t, 2)
    t = time.perf_counter(); targets = se._warmup_targets(universe, "5m", definition, need); result["missing_check_s"] = round(time.perf_counter() - t, 2); result["stocks_missing_history"] = len(targets)
    t = time.perf_counter(); matched, stats = se._scan_with_stats(universe, definition, "5m"); result["full_scan_s"] = round(time.perf_counter() - t, 2)
    result["scan"] = {k: stats[k] for k in ("universe", "ready", "not_ready", "readiness_pct", "evaluated", "stale", "matched_total")}
    result["scan_status"] = se.classify_scan_status(stats)
    result["coverage"] = se.universe_coverage(definition, universe)
    result["feed_manager"] = asyncio.run(feed_manager_run(stocks))
    # tick path + bar close for every stock
    IST = dt.timezone(dt.timedelta(hours=5, minutes=30))
    engine = ce_mod.CandleEngine(); engine._timeframe_cache = {"5m", "15m"}; engine._timeframe_cache_at = 1e12; engine._preloaded = {}
    tw_mod.tick_writer.start()
    t0 = dt.datetime(2026, 10, 14, 9, 16, tzinfo=IST)
    t = time.perf_counter()
    for k in range(3):
        for i in range(stocks):
            engine.on_tick(exchange_segment="nse_cm", instrument_token=str(1000 + i), trading_symbol="X", price=100 + k + i % 7, volume=10 * (k + 1), timestamp=t0 + dt.timedelta(seconds=40 * k))
            tw_mod.tick_writer.put_tick(instrument_token=str(1000 + i), exchange_segment="nse_cm", last_traded_price=100 + k)
    result["tick_path_us_per_tick"] = round((time.perf_counter() - t) / (3 * stocks) * 1e6, 1)
    t = time.perf_counter(); closed = engine.finalize_due(now=t0.replace(minute=20, second=2)); result["bar_close_loop_thread_ms"] = round((time.perf_counter() - t) * 1000, 1); result["bars_closed"] = closed
    t = time.perf_counter(); tw_mod.tick_writer.flush(); result["background_flush_ms"] = round((time.perf_counter() - t) * 1000, 1)
    tw_mod.tick_writer.stop()
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stocks", type=int, default=2800)
    ap.add_argument("--bars", type=int, default=160)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--heavy", action="store_true", help="use the heaviest definition (ema200: a 600-bar window); pass --bars 603 or more")
    a = ap.parse_args()
    r = run(a.stocks, a.bars, HEAVY if a.heavy else RICH)
    print(json.dumps(r, indent=1) if a.json else "\n".join(f"{k}: {v}" for k, v in r.items()))
