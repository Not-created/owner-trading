"""The history hint in the UI (frontend minBarsHint) and the scanner's real requirement (required_bars) are checked against
ONE shared fixture, from both sides. If either formula changes, one of the two test suites fails."""
import importlib.util
import json
import os
import unittest

HERE = os.path.dirname(__file__)
FIXTURE = os.path.join(HERE, "..", "..", "frontend", "test", "fixtures", "scanner-required-bars.json")
GENERATOR = os.path.join(HERE, "..", "tools", "gen_required_bars_fixture.py")


class RequiredBarsContract(unittest.TestCase):
    def test_the_checked_in_fixture_matches_the_backend(self):
        spec = importlib.util.spec_from_file_location("gen_required_bars_fixture", GENERATOR)
        gen = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gen)
        with open(FIXTURE, encoding="utf-8") as fh:
            checked_in = json.load(fh)
        fresh = gen.build()
        self.assertEqual(checked_in["cases"], fresh["cases"],
                         "scanner-required-bars.json is stale: run  python tools/gen_required_bars_fixture.py  (then the JS test checks the UI hint)")

    def test_the_fixture_covers_every_operand_kind_the_builder_offers(self):
        with open(FIXTURE, encoding="utf-8") as fh:
            text = json.dumps(json.load(fh))
        for kind in ("ema", "sma", "vwap", "adx", "rsi", "macd", "macd_signal", "macd_hist", "atr", "bb_upper", "bb_mid", "bb_lower", "hh", "ll", "volume_sma"):
            self.assertIn(kind, text, f"no case uses {kind}")


if __name__ == "__main__":
    unittest.main()
