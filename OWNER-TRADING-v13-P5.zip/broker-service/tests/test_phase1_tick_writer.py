"""Phase 1: the tick hot path must not touch SQLite, and the batched writes must lose nothing."""
import datetime as dt
import sqlite3
import unittest
from unittest import mock
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")


def _t(h, m, s=0):
    return dt.datetime(2026, 10, 14, h, m, s, tzinfo=IST)


class TickWriterTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app import tick_writer as tw, candle_engine as ce
        import importlib
        importlib.reload(tw)       # picks up the freshly reloaded db module state
        importlib.reload(ce)
        self.tw, self.ce = tw, ce
        self.writer = tw.tick_writer
        self.engine = ce.CandleEngine()
        self.engine._timeframe_cache = {"5m"}
        self.engine._timeframe_cache_at = 10 ** 12   # never expires inside the test

    def tearDown(self):
        self.writer.stop()

    def _candles(self):
        return self.db.recent_candles("nse_cm", "1", "5m", 50)

    def test_sync_mode_still_writes_immediately(self):
        self.assertFalse(self.writer.running)
        e = self.engine
        e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=100, volume=10, timestamp=_t(9, 15))
        e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=101, volume=20, timestamp=_t(9, 21))
        self.assertEqual(len(self._candles()), 1)

    def test_running_mode_buffers_then_flush_writes_everything(self):
        self.writer.start()
        e = self.engine
        e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=100, volume=10, timestamp=_t(9, 15))
        e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=102, volume=30, timestamp=_t(9, 17))
        e.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=101, volume=40, timestamp=_t(9, 21))
        self.writer.stop()          # final flush
        rows = self._candles()
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0]["open"], rows[0]["high"], rows[0]["close"]), (100.0, 102.0, 102.0))   # the 09:21 tick belongs to the NEXT bar
        state = self.db.get_candle_runtime_state("nse_cm", "1", "5m")
        self.assertEqual(state["candle_at"], "2026-10-14 09:20:00")     # the NEW forming bar, old checkpoint replaced

    def test_hot_path_opens_no_sqlite_connection(self):
        self.engine._preloaded = {}                   # what preload_runtime_state() leaves after a clean start
        self.writer.start()
        seed = mock.patch.object(self.db, "get_candle", return_value=None)    # one-time seeding read, measured separately
        real_connect = sqlite3.connect
        calls = []
        def counting(*a, **k):
            calls.append(1)
            return real_connect(*a, **k)
        with seed, mock.patch("sqlite3.connect", side_effect=counting):
            for i in range(300):
                tok = str(1000 + i)
                for n in range(10):
                    self.engine.on_tick(exchange_segment="nse_cm", instrument_token=tok, trading_symbol="S", price=100 + n,
                                        volume=n * 10, timestamp=_t(9, 15, n))
                    self.writer.put_tick(instrument_token=tok, exchange_segment="nse_cm", last_traded_price=100 + n)
        self.assertEqual(len(calls), 0, "the tick path must not open a SQLite connection")
        self.assertGreaterEqual(self.writer.pending()["ticks"], 300)

    def test_tick_coalescing_keeps_latest_and_last_known_optional_fields(self):
        self.writer.start()
        self.writer.put_tick(instrument_token="7", exchange_segment="nse_cm", last_traded_price=10.0, close_price=9.0, upper_circuit=11.0)
        self.writer.put_tick(instrument_token="7", exchange_segment="nse_cm", last_traded_price=10.5)
        self.writer.flush()
        with self.db._connection() as c:
            r = c.execute("SELECT last_traded_price, close_price, upper_circuit FROM market_data_state WHERE instrument_token='7'").fetchone()
        self.assertEqual(r, (10.5, 9.0, 11.0))

    def test_failed_candle_write_is_retried_not_lost(self):
        self.writer.start()
        row = {"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "X", "timeframe": "5m",
               "candle_at": "2026-10-14 09:15:00", "open": 1, "high": 2, "low": 1, "close": 2, "volume": 5}
        self.writer.put_candle(row)
        real = self.db.upsert_candles
        with mock.patch.object(self.db, "upsert_candles", side_effect=sqlite3.OperationalError("database is locked")):
            self.writer.flush()
        self.assertEqual(self.writer.pending()["candles"], 1)
        self.assertEqual(len(self._candles()), 0)
        self.writer.flush()                                   # database is back
        self.assertEqual(len(self._candles()), 1)
        self.assertEqual(self.writer.pending()["candles"], 0)

    def test_preload_means_no_per_key_checkpoint_reads(self):
        self.db.upsert_candle_runtime_state(exchange_segment="nse_cm", instrument_token="1", timeframe="5m",
                                            candle_at="2026-10-14 09:15:00", open_=100, high=105, low=99, close=104, volume=50,
                                            trading_symbol="X", cumulative_volume=500)
        with mock.patch.object(self.ce, "dt") as fake_dt:      # "now" inside the checkpoint's bar, so it is resumed, not recovered
            fake_dt.datetime.now.return_value = _t(9, 16)
            fake_dt.datetime.strptime = dt.datetime.strptime
            fake_dt.timedelta = dt.timedelta
            self.assertEqual(self.engine.preload_runtime_state(), 1)
        self.writer.start()
        with mock.patch.object(self.db, "get_candle_runtime_state", side_effect=AssertionError("per-key read")):
            self.engine.on_tick(exchange_segment="nse_cm", instrument_token="1", trading_symbol="X", price=106, volume=520, timestamp=_t(9, 17))
        st = self.engine._state[("nse_cm", "1", "5m")]
        self.assertEqual((st["open"], st["high"], st["volume"]), (100.0, 106.0, 70))   # resumed the checkpoint, +20 volume


class ExitKeyCacheTests(unittest.TestCase):
    def test_ticks_for_instruments_without_positions_do_no_database_work(self):
        try:
            db = fresh_db()
            from app import exit_engine as ee
        except Exception as exc:                  # broker deps (httpx...) not installed in this environment
            self.skipTest(f"exit_engine not importable here: {exc}")
        import asyncio
        ee._POSITION_KEYS.update(keys=None)
        with mock.patch.object(db, "list_algo_positions", wraps=db.list_algo_positions) as spy:
            for _ in range(500):
                asyncio.run(ee.on_tick(exchange_segment="nse_cm", instrument_token="42", price=10.0))
        self.assertEqual(spy.call_count, 1)       # one refresh, not one read per tick


if __name__ == "__main__":
    unittest.main()


class Phase1FollowUpFixTests(unittest.TestCase):
    """Problems found when re-auditing Phase 1."""

    def setUp(self):
        self.db = fresh_db()
        from app import tick_writer as tw
        import importlib
        importlib.reload(tw)
        self.writer = tw.tick_writer

    def tearDown(self):
        self.writer.stop()

    def test_last_tick_at_is_the_tick_time_not_the_flush_time(self):
        import time as _time
        self.writer.start()
        self.writer.put_tick(instrument_token="9", exchange_segment="nse_cm", last_traded_price=5.0)
        tick_time = _time.strftime("%Y-%m-%d %H:%M:%S", _time.gmtime())
        _time.sleep(2.2)                                   # the batch is written later than the tick
        self.writer.flush()
        with self.db._connection() as c:
            stamp = c.execute("SELECT last_tick_at FROM market_data_state WHERE instrument_token='9'").fetchone()[0]
        self.assertLessEqual(abs(_time.mktime(_time.strptime(stamp, "%Y-%m-%d %H:%M:%S")) - _time.mktime(_time.strptime(tick_time, "%Y-%m-%d %H:%M:%S"))), 1)

    def test_sync_mode_tick_still_gets_a_timestamp(self):
        self.writer.put_tick(instrument_token="8", exchange_segment="nse_cm", last_traded_price=5.0)   # writer not running
        with self.db._connection() as c:
            self.assertIsNotNone(c.execute("SELECT last_tick_at FROM market_data_state WHERE instrument_token='8'").fetchone()[0])

    def test_websocket_stop_writes_everything_still_buffered(self):
        from app.websocket_manager import WebSocketManager
        from app import candle_engine as _ce
        import asyncio
        _ce.candle_engine._state.clear()               # the process-wide engine may hold bars fed by other test modules
        self.writer.start()
        self.writer.put_candle({"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "X", "timeframe": "5m",
                                "candle_at": "2026-10-14 09:15:00", "open": 1, "high": 2, "low": 1, "close": 2, "volume": 5})
        self.writer.put_tick(instrument_token="1", exchange_segment="nse_cm", last_traded_price=2.0)
        asyncio.run(WebSocketManager().stop())             # what the service now calls on SIGTERM
        self.assertFalse(self.writer.running)
        self.assertEqual(len(self.db.recent_candles("nse_cm", "1", "5m", 10)), 1)
        with self.db._connection() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM market_data_state WHERE instrument_token='1'").fetchone()[0], 1)
