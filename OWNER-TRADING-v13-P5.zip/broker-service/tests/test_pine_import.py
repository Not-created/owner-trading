"""P3: Pine Script subset -> engine conditions. The rule that matters most: anything not understood must make the
result NOT ok (never a silently shortened rule)."""
import random
import unittest

from app import pine_import as pine
from app import strategy_engine as se

EMA_RSI = """//@version=5
strategy("EMA + RSI", overlay=true)
f = ta.ema(close, 20)
s = ta.ema(close, 50)
r = ta.rsi(close, 14)
buy = ta.crossover(f, s) and r > 55
plot(f)
plot(s, color=color.red)
"""


def conds(group):
    return group["conditions"]


class PineTranslateTests(unittest.TestCase):
    def test_example_from_the_screen(self):
        r = pine.translate(EMA_RSI)
        self.assertTrue(r["ok"], r)
        d = r["definition"]
        self.assertEqual(d["side"], "BUY")
        self.assertEqual(d["entry"], {"op": "AND", "conditions": [
            {"left": "ema20", "operator": "cross_above", "right": "ema50"},
            {"left": "rsi14", "operator": ">", "right": 55}]})
        self.assertTrue(r["needs_exit"])
        self.assertNotIn("exit", d)
        self.assertEqual(r["ignored_lines"], 2)

    def test_volume_spike_and_scaled_sides(self):
        r = pine.translate("buy = volume > ta.sma(volume, 20) * 1.5")
        self.assertEqual(conds(r["definition"]["entry"])[0], {"left": "volume", "operator": ">", "right": "volume_sma20", "mult": 1.5})
        r = pine.translate("buy = close * 1.01 > ema20x\nema20x = 1")
        self.assertFalse(r["ok"])                       # ema20x defined after use -> not silently accepted
        r = pine.translate("e = ta.ema(close, 20)\nbuy = close * 2 > e")
        c = conds(r["definition"]["entry"])[0]
        self.assertEqual((c["left"], c["operator"], c["right"]), ("close", ">", "ema20"))
        self.assertAlmostEqual(c["mult"], 0.5)

    def test_number_on_left_is_flipped(self):
        r = pine.translate("buy = 55 < ta.rsi(close, 14)")
        self.assertEqual(conds(r["definition"]["entry"])[0], {"left": "rsi14", "operator": ">", "right": 55})

    def test_breakout_needs_previous_bar_form(self):
        ok = pine.translate("buy = high > ta.highest(high, 20)[1]")
        self.assertEqual(conds(ok["definition"]["entry"])[0], {"left": "high", "operator": ">", "right": "hh20"})
        bad = pine.translate("buy = high > ta.highest(high, 20)")
        self.assertFalse(bad["ok"])
        self.assertIn("[1]", bad["reason"])

    def test_unsupported_part_blocks_the_whole_rule(self):
        r = pine.translate("a = close + ta.atr(14)\nbuy = close > ta.ema(close, 20) and close > a")
        self.assertFalse(r["ok"])
        self.assertIsNone(r["definition"])
        self.assertIn("buy", r["reason"] + str(r["errors"]))

    def test_security_and_loops_are_rejected(self):
        self.assertFalse(pine.translate("x = request.security(syminfo.tickerid, 'D', close)\nbuy = close > x")["ok"])
        self.assertFalse(pine.translate("buy = ta.ema(hl2, 20) > close")["ok"])
        self.assertFalse(pine.translate("buy = ta.macd(close, 5, 35, 5)")["ok"])

    def test_macd_bb_tuples(self):
        r = pine.translate("[m, sg, h] = ta.macd(close, 12, 26, 9)\nbuy = ta.crossover(m, sg) and h > 0")
        self.assertEqual(conds(r["definition"]["entry"]), [
            {"left": "macd", "operator": "cross_above", "right": "macd_signal"},
            {"left": "macd_hist", "operator": ">", "right": 0}])
        r = pine.translate("[mid, up, lo] = ta.bb(close, 20, 2)\nbuy = close < lo")
        self.assertEqual(conds(r["definition"]["entry"])[0], {"left": "close", "operator": "<", "right": "bb_lower20"})

    def test_offsets(self):
        r = pine.translate("buy = close[1] > open[1] and close > close[1]")
        self.assertEqual(conds(r["definition"]["entry"]), [
            {"left": "close[1]", "operator": ">", "right": "open[1]"}, {"left": "close", "operator": ">", "right": "close[1]"}])

    def test_or_not_grouping(self):
        r = pine.translate("a = close > open\nb = ta.rsi(close, 14) > 60\nc = volume > 1000\nbuy = (a or b) and not c")
        e = r["definition"]["entry"]
        self.assertEqual(e["op"], "AND")
        self.assertEqual(len(e["groups"]), 1)
        self.assertEqual(e["groups"][0]["op"], "OR")
        self.assertEqual(e["conditions"], [{"left": "volume", "operator": ">", "right": 1000, "not": True}])

    def test_strategy_calls_both_sides(self):
        src = """//@version=5
strategy("x")
l = ta.crossover(ta.ema(close, 9), ta.ema(close, 21))
s = ta.crossunder(ta.ema(close, 9), ta.ema(close, 21))
if l
    strategy.entry("L", strategy.long)
if s
    strategy.entry("S", strategy.short)
    strategy.close("L")
"""
        r = pine.translate(src)
        self.assertTrue(r["ok"], r)
        self.assertEqual(r["definition"]["side"], "BUY")
        self.assertEqual(r["other_sides"][0]["side"], "SELL")
        r2 = pine.translate(src, side="SELL")
        self.assertEqual(r2["definition"]["side"], "SELL")
        self.assertEqual(conds(r2["definition"]["entry"])[0]["operator"], "cross_below")

    def test_when_and_close_become_exit(self):
        src = "strategy.entry('L', strategy.long, when = close > ta.ema(close, 20))\nif close < ta.ema(close, 20)\n    strategy.close('L')"
        r = pine.translate(src)
        self.assertTrue(r["ok"], r)
        self.assertFalse(r["needs_exit"])
        self.assertEqual(conds(r["definition"]["exit"])[0]["operator"], "<")

    def test_ambiguous_script_asks_the_user(self):
        src = "foo = close > open\nbar = ta.rsi(close, 14) > 50"
        r = pine.translate(src)
        self.assertFalse(r["ok"])
        self.assertTrue(r["need_choice"])
        self.assertEqual([c["name"] for c in r["choices"]], ["foo", "bar"])
        r2 = pine.translate(src, entry="bar")
        self.assertTrue(r2["ok"])
        self.assertEqual(conds(r2["definition"]["entry"])[0]["left"], "rsi14")
        self.assertFalse(pine.translate(src, entry="nope")["ok"])

    def test_inputs_and_continuation_lines(self):
        src = """len = input.int(20, "Length")
buy = ta.crossover(close, ta.sma(close, len))
    and ta.rsi(close, 14) > 50
"""
        r = pine.translate(src)
        self.assertTrue(r["ok"], r)
        self.assertEqual(conds(r["definition"]["entry"])[0], {"left": "close", "operator": "cross_above", "right": "sma20"})
        self.assertEqual(len(conds(r["definition"]["entry"])), 2)

    def test_v4_names(self):
        r = pine.translate("buy = crossover(ema(close, 9), ema(close, 21))")
        self.assertTrue(r["ok"], r)

    def test_alertcondition_is_the_signal(self):
        r = pine.translate("x = ta.crossover(ta.ema(close, 9), ta.ema(close, 21))\nalertcondition(x, 'Buy now')")
        self.assertTrue(r["ok"], r)
        self.assertIn("alertcondition", r["entry_source"])

    def test_translated_rule_really_fires_in_the_engine(self):
        r = pine.translate(EMA_RSI)
        d = {"timeframe": "5m", **r["definition"], "exit": {"op": "AND", "conditions": [{"left": "close", "operator": "<", "right": "ema20"}]}}
        self.assertEqual(se.validate_strategy(d), [])
        down = [100 - i * 0.3 for i in range(80)]
        up = [down[-1] + i * 1.2 for i in range(1, 30)]
        candles = [{"candle_at": f"2026-10-01 {9 + (15 + 5 * i) // 60:02d}:{(15 + 5 * i) % 60:02d}:00", "open": c, "high": c + .3, "low": c - .3, "close": c, "volume": 1000}
                   for i, c in enumerate(down + up)]
        hits = [i for i in range(60, len(candles) + 1) if se.evaluate_entry(d, candles[:i])[0]]
        self.assertTrue(hits, "a clean V-shaped rally must trigger an ema cross with strong RSI at least once")

    def test_unsupported_filter_under_an_order_blocks_everything(self):
        """Regression: a nested `if` filter that is not understood must not be dropped while the `buy` variable is used."""
        src = ('trendOk = ta.supertrend(3, 10)\n'
               'buy = ta.crossover(ta.ema(close, 9), ta.ema(close, 21))\n'
               'if buy\n    if trendOk\n        strategy.entry("L", strategy.long)\n')
        r = pine.translate(src)
        self.assertFalse(r["ok"])
        self.assertIsNone(r["definition"])
        self.assertIn("लाइन 5", r["reason"])

    def test_unparsed_statements_block_but_unused_failed_assignments_do_not(self):
        closed = "type ob\n    float top\nvar array<ob> obs = array.new<ob>()\nbuy = close > open\n"
        self.assertFalse(pine.translate(closed)["ok"])
        harmless = "x = ta.supertrend(3, 10)\nbuy = ta.crossover(ta.ema(close, 9), ta.ema(close, 21))\n"
        r = pine.translate(harmless)
        self.assertTrue(r["ok"], r)
        self.assertEqual(len(r["errors"]), 1)             # still reported to the user

    def test_failed_variable_used_by_the_rule_blocks(self):
        r = pine.translate("x = ta.supertrend(3, 10)\nbuy = ta.crossover(ta.ema(close, 9), ta.ema(close, 21)) and x")
        self.assertFalse(r["ok"])

    def test_garbage_never_raises(self):
        rnd = random.Random(7)
        alphabet = "abc ()[]=<>!+-*/.,\n\t'\"0123456789 ta.emaandornotif:"
        for _ in range(400):
            text = "".join(rnd.choice(alphabet) for _ in range(rnd.randint(0, 80)))
            r = pine.translate(text)
            self.assertIn("ok", r)
        self.assertFalse(pine.translate("")["ok"])
        self.assertFalse(pine.translate("x" * 70000)["ok"])


if __name__ == "__main__":
    unittest.main()
