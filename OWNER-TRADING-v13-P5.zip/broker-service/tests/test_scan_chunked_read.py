"""P2: the scanner reads candles in chunks (low peak RAM) but must see exactly the same candles as one big read."""
import os
import sqlite3
import unittest


class ChunkedReadTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        from app import scanner_engine
        self.db = fresh_db()
        self.se = scanner_engine
        c = sqlite3.connect(os.environ["DB_PATH"])
        for i in range(23):
            for b in range(6):
                c.execute("INSERT INTO candles(exchange_segment,instrument_token,timeframe,candle_at,open,high,low,close,volume,source) "
                          "VALUES('nse_cm',?, '5m', ?, 1,2,0.5,?,10,'t')", (str(100 + i), f"2026-10-01 09:{15 + 5 * b:02d}:00", 1 + b + i))
        c.commit()
        c.close()
        self.universe = [{"exchange_segment": "nse_cm", "instrument_token": str(100 + i)} for i in range(25)]  # 2 have no candles

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_chunked_equals_single_read(self):
        whole = self.db.recent_candles_for_instruments(self.universe, "5m", 4)
        old = self.se.SCAN_READ_CHUNK
        self.se.SCAN_READ_CHUNK = 7          # several chunks, last one partial
        try:
            got = list(self.se._iter_candles(self.universe, "5m", 4))
        finally:
            self.se.SCAN_READ_CHUNK = old
        self.assertEqual([u for u, _ in got], self.universe)              # same instruments, same order
        for inst, candles in got:
            key = (inst["exchange_segment"], inst["instrument_token"])
            self.assertEqual(candles, whole.get(key, []))                 # identical candles (or none)
        self.assertEqual(sum(1 for _, c in got if not c), 2)

    def test_empty_universe(self):
        self.assertEqual(list(self.se._iter_candles([], "5m", 4)), [])


if __name__ == "__main__":
    unittest.main()
