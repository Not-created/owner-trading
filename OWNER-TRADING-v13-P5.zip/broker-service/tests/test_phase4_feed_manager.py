"""Phase 4 (feed manager): a hard 3,000-key limit with priority eviction, nothing silently dropped, positions protected."""
import asyncio
import unittest
from unittest import mock

from tests.dbutil import fresh_db


class FakeFeed:
    def __init__(self, fail_batches=()):
        self.is_connected = True
        self.subscription_count = 0
        self.subscribed, self.unsubscribed, self.calls = [], [], 0
        self.fail_batches = set(fail_batches)

    async def subscribe_scrips(self, tokens):
        self.calls += 1
        if self.calls in self.fail_batches:
            raise ConnectionError("broker rejected the batch")
        self.subscribed.extend(tokens)

    async def unsubscribe_scrips(self, tokens):
        self.unsubscribed.extend(tokens)


def keys(prefix, n, start=0):
    return [("nse_cm", str(prefix + i)) for i in range(start, start + n)]


class Base(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app import websocket_manager as wm        # no reload: it would replace the process-wide singleton other tests hold
        self.wm = wm
        from app import sdk_adapter
        patcher = mock.patch.object(sdk_adapter, "make_ws_token", lambda seg, tok: (seg, tok))   # the SDK is not needed here
        patcher.start()
        self.addCleanup(patcher.stop)
        self.m = wm.WebSocketManager()
        self.m._max_subscriptions = 100          # same logic as 3,000, quicker

    def run_(self, coro):
        return asyncio.run(coro)


class AdmissionTests(Base):
    def test_a_position_gets_a_slot_by_evicting_scanner_stocks_not_by_being_refused(self):
        async def go():
            await self.m.subscribe_many(keys(1000, 100), owner="scanner-universe")           # feed completely full
            self.assertEqual(len(self.m._subs), 100)
            r = await self.m.subscribe_many([("nse_cm", "7777")], owner="position:5")
            return r
        r = self.run_(go())
        self.assertEqual((r["added"], r["evicted"], r["rejected"]), (1, 1, []))
        self.assertIn(("nse_cm", "7777"), self.m._subs)
        self.assertEqual(len(self.m._subs), 100)                                              # still within the hard limit
        self.assertEqual(self.m.feed_status()["evicted_total"], 1)
        self.assertEqual(self.m.feed_status()["last_eviction"]["tiers"], {"scanner_universe": 1})

    def test_positions_and_candidates_are_never_evicted_by_lower_priority_requests(self):
        async def go():
            await self.m.subscribe_many(keys(1, 10), owner="position:1")
            await self.m.subscribe_many(keys(100, 10), owner="strategy:3:candidate:nse_cm:100")
            await self.m.subscribe_many(keys(1000, 80), owner="scanner-universe")
            return await self.m.subscribe_many(keys(5000, 5), owner="manual-ui")             # manual outranks the scanner only
        r = self.run_(go())
        self.assertEqual((r["added"], r["evicted"]), (5, 5))
        self.assertTrue(all(k in self.m._subs for k in keys(1, 10) + keys(100, 10)))
        self.assertEqual(self.m.tier_counts()["positions"], 10)
        self.assertEqual(self.m.tier_counts()["candidates"], 10)

    def test_a_scanner_request_on_a_full_feed_is_rejected_not_silently_half_owned(self):
        async def go():
            await self.m.subscribe_many(keys(1, 60), owner="position:1")
            await self.m.subscribe_many(keys(100, 40), owner="strategy:3:candidate:nse_cm:100")
            return await self.m.subscribe_many(keys(1000, 20), owner="scanner-universe")
        r = self.run_(go())
        self.assertEqual((r["added"], r["evicted"], len(r["rejected"])), (0, 0, 20))
        self.assertIn("limit reached (100)", r["reason"])
        self.assertTrue(all(k not in self.m._owners for k in keys(1000, 20)))             # no phantom ownership
        self.assertEqual(len(self.m._pending), 20)

    def test_partial_admission_fills_what_fits_in_order(self):
        async def go():
            await self.m.subscribe_many(keys(1, 90), owner="position:1")
            return await self.m.subscribe_many(keys(1000, 20), owner="scanner-universe")
        r = self.run_(go())
        self.assertEqual((r["added"], len(r["rejected"])), (10, 10))
        self.assertEqual([k for k in self.m._subs if k[1].startswith("10") and int(k[1]) >= 1000], keys(1000, 10))

    def test_single_subscribe_still_raises_when_the_key_is_not_admitted(self):
        async def go():
            await self.m.subscribe_many(keys(1, 100), owner="position:1")
            await self.m.subscribe("nse_cm", "9999", owner="scanner-universe")
        with self.assertRaises(ValueError):
            self.run_(go())

    def test_shared_keys_keep_every_owner_and_an_existing_key_needs_no_slot(self):
        async def go():
            await self.m.subscribe_many(keys(1, 100), owner="scanner-universe")
            return await self.m.subscribe_many([("nse_cm", "5")], owner="strategy:1:candidate:nse_cm:5")     # already subscribed
        r = self.run_(go())
        self.assertEqual((r["added"], r["evicted"], r["rejected"]), (0, 0, []))
        self.assertEqual(self.m.subscription_owners(("nse_cm", "5")), ["scanner-universe", "strategy:1:candidate:nse_cm:5"])

    def test_eviction_takes_the_least_liquid_scanner_stocks_first(self):
        for tok, vol in (("1000", 9_000_000), ("1001", 5), ("1002", 500_000)):
            self.db.record_market_tick(instrument_token=tok, exchange_segment="nse_cm", last_traded_price=1.0, volume=vol)
        self.m._max_subscriptions = 3
        async def go():
            await self.m.subscribe_many(keys(1000, 3), owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "7")], owner="position:1")
        self.run_(go())
        self.assertNotIn(("nse_cm", "1001"), self.m._subs)                                 # volume 5: dropped first
        self.assertIn(("nse_cm", "1000"), self.m._subs)


class BrokerFailureTests(Base):
    def test_a_failing_batch_does_not_abandon_the_batches_after_it_and_is_retried(self):
        feed = FakeFeed(fail_batches={2})
        self.m._market = feed
        self.m._max_subscriptions = 3000
        async def go():
            r = await self.m.subscribe_many(keys(1, 1200), owner="scanner-universe")      # batches: 500, 500 (fails), 200
            first = (r["added"], len(r["rejected"]))
            retry = await self.m.retry_pending()
            return first, retry
        first, retry = self.run_(go())
        self.assertEqual(first, (700, 500))
        self.assertEqual(retry["recovered"], 500)
        self.assertEqual(len(self.m._subs), 1200)
        self.assertEqual(self.m.feed_status()["pending"], 0)

    def test_release_uses_batched_broker_calls(self):
        feed = FakeFeed()
        self.m._market = feed
        self.m._max_subscriptions = 3000
        calls = []
        orig = feed.unsubscribe_scrips
        async def counting(tokens):
            calls.append(len(tokens)); await orig(tokens)
        feed.unsubscribe_scrips = counting
        async def go():
            await self.m.subscribe_many(keys(1, 1100), owner="scanner-universe")
            return await self.m.release_owner("scanner-universe")
        removed = self.run_(go())
        self.assertEqual((removed, calls), (1100, [500, 500, 100]))                          # not 1,100 calls

    def test_resubscribe_continues_after_a_failed_batch_and_asks_for_a_retry(self):
        feed = FakeFeed(fail_batches={1})
        self.m._max_subscriptions = 3000
        async def go():
            await self.m.subscribe_many(keys(1, 1200), owner="scanner-universe")
            self.m._market = feed
            await self.m._resubscribe(feed)
            first_flag = self.m._resubscribe_needed
            await self.m.retry_pending()
            return first_flag
        flag = self.run_(go())
        self.assertTrue(flag)
        self.assertEqual(feed.calls, 3 + 3)                  # all 3 batches tried, then the whole registry sent again
        self.assertFalse(self.m._resubscribe_needed)


class PositionProtectionTests(Base):
    def test_a_position_that_cannot_get_a_slot_is_reported_as_an_error(self):
        self.m._max_subscriptions = 2
        pos = [{"id": 1, "exchange_segment": "nse_cm", "instrument_token": "11", "remaining_quantity": 5},
               {"id": 2, "exchange_segment": "nse_cm", "instrument_token": "12", "remaining_quantity": 5},
               {"id": 3, "exchange_segment": "nse_cm", "instrument_token": "13", "remaining_quantity": 5}]
        with mock.patch.object(self.db, "list_algo_positions", return_value=pos):
            r = self.run_(self.m.sync_position_owners())
        self.assertEqual((r["positions"], r["subscribed"]), (3, 2))
        self.assertEqual(len(r["errors"]), 1)                    # surfaced, never silently dropped

    def test_a_position_can_evict_everything_else_but_not_another_position(self):
        self.m._max_subscriptions = 3
        pos = [{"id": 1, "exchange_segment": "nse_cm", "instrument_token": "11", "remaining_quantity": 5}]
        async def go():
            await self.m.subscribe_many(keys(100, 3), owner="scanner-universe")
            with mock.patch.object(self.db, "list_algo_positions", return_value=pos):
                return await self.m.sync_position_owners()
        r = self.run_(go())
        self.assertEqual((r["subscribed"], r["errors"]), (1, []))
        self.assertIn(("nse_cm", "11"), self.m._subs)


if __name__ == "__main__":
    unittest.main()


class FollowUpFixTests(Base):
    def test_a_released_owner_is_not_resurrected_by_the_retry(self):
        self.m._max_subscriptions = 5
        async def go():
            await self.m.subscribe_many(keys(1, 5), owner="position:1")
            r = await self.m.subscribe_many(keys(100, 3), owner="scanner-universe")      # no room: rejected + pending
            pending_before = len(self.m._pending)
            await self.m.release_owner("scanner-universe")                              # the scanner is disarmed
            await self.m.release_owner("position:1")                                    # and room appears
            retry = await self.m.retry_pending()
            return r, pending_before, retry
        r, before, retry = self.run_(go())
        self.assertEqual((len(r["rejected"]), before), (3, 3))
        self.assertEqual(retry["retried"], 0)
        self.assertEqual(len(self.m._subs), 0)                                           # nothing came back

    def test_unsubscribing_an_owner_drops_only_its_own_pending_wishes(self):
        self.m._max_subscriptions = 2
        async def go():
            await self.m.subscribe_many(keys(1, 2), owner="position:1")
            await self.m.subscribe_many([("nse_cm", "50")], owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "51")], owner="manual-ui")
            await self.m.unsubscribe_many([("nse_cm", "50")], owner="scanner-universe")
        self.run_(go())
        self.assertEqual(self.m._pending, {("nse_cm", "51"): "manual-ui"})

    def test_an_evicted_candidate_comes_back_when_a_slot_frees_up(self):
        self.m._max_subscriptions = 3
        cand = "strategy:3:candidate:nse_cm:100"
        async def go():
            await self.m.subscribe_many([("nse_cm", "100")], owner=cand)
            await self.m.subscribe_many(keys(1, 2), owner="position:1")
            r = await self.m.subscribe_many([("nse_cm", "7")], owner="position:2")      # full: the candidate is the only thing less important
            gone = ("nse_cm", "100") not in self.m._subs
            await self.m.release_owner("position:2")                                    # that position closes
            retry = await self.m.retry_pending()
            return r, gone, retry
        r, gone, retry = self.run_(go())
        self.assertEqual((r["evicted"], gone, retry["recovered"]), (1, True, 1))
        self.assertIn(("nse_cm", "100"), self.m._subs)
        self.assertEqual(self.m.subscription_owners(("nse_cm", "100")), [cand])

    def test_an_evicted_scanner_stock_is_not_queued_for_return(self):
        self.m._max_subscriptions = 2
        async def go():
            await self.m.subscribe_many(keys(1, 2), owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "7")], owner="position:1")
        self.run_(go())
        self.assertEqual(self.m._pending, {})
