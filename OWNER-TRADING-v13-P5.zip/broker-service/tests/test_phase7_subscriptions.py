"""Subscribe / unsubscribe: honest outcomes, the user's subscriptions survive a restart, nothing is silently ignored."""
import asyncio
import sqlite3
import unittest
from unittest.mock import patch

from tests.dbutil import fresh_db


class FakeFeed:
    is_connected = True
    subscription_count = 0

    def __init__(self):
        self.subscribed, self.unsubscribed = [], []

    async def subscribe_scrips(self, tokens):
        self.subscribed.extend(tokens)

    async def unsubscribe_scrips(self, tokens):
        self.unsubscribed.extend(tokens)


def keys(prefix, n):
    return [("nse_cm", str(prefix + i)) for i in range(n)]


class Base(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        from app import sdk_adapter, websocket_manager as wm
        p = patch.object(sdk_adapter, "make_ws_token", lambda s, t: (s, t))
        p.start()
        self.addCleanup(p.stop)
        self.wm = wm
        self.m = wm.WebSocketManager()
        self.m._max_subscriptions = 100

    def run_(self, coro):
        return asyncio.run(coro)

    def outcomes(self, result):
        return {(r["exchange_segment"], r["instrument_token"]): r for r in result["results"]}


class ManualUnsubscribeTests(Base):
    def test_removes_every_manual_tier_owner_not_just_the_one_called_manual(self):
        async def go():
            await self.m.subscribe_many([("nse_cm", "1")], owner="manual")
            await self.m.subscribe_many([("nse_cm", "2")], owner="scanner-manual-matches")      # created by a manual scan
            return await self.m.unsubscribe_manual([("nse_cm", "1"), ("nse_cm", "2")])
        r = self.run_(go())
        self.assertEqual((r["removed"], r["still_held"], r["total"]), (2, 0, 0))
        self.assertEqual(self.m.subscriptions(), [])

    def test_a_stock_another_owner_still_needs_stays_and_the_answer_says_why(self):
        cand = "strategy:7:candidate:nse_cm:1"
        async def go():
            await self.m.subscribe_many([("nse_cm", "1")], owner="manual")
            await self.m.subscribe_many([("nse_cm", "1")], owner=cand)
            return await self.m.unsubscribe_manual([("nse_cm", "1")])
        r = self.run_(go())
        row = self.outcomes(r)[("nse_cm", "1")]
        self.assertEqual((row["outcome"], row["held_by"]), ("still_held", [cand]))
        self.assertEqual((r["removed"], r["still_held"]), (0, 1))
        self.assertIn(("nse_cm", "1"), self.m._subs)
        self.assertEqual(self.m.subscription_owners(("nse_cm", "1")), [cand])           # only the user's owner is gone

    def test_an_open_position_keeps_its_feed_when_the_user_unsubscribes(self):
        pos = [{"id": 1, "exchange_segment": "nse_cm", "instrument_token": "1", "remaining_quantity": 5}]
        async def go():
            await self.m.subscribe_many([("nse_cm", "1")], owner="manual")
            with patch.object(self.db, "list_algo_positions", return_value=pos):
                return await self.m.unsubscribe_manual([("nse_cm", "1")])
        r = self.run_(go())
        row = self.outcomes(r)[("nse_cm", "1")]
        self.assertEqual(row["outcome"], "still_held")
        self.assertTrue(any(o.startswith("position:") for o in row["held_by"]))

    def test_automatic_only_and_unknown_instruments_are_reported_not_ignored(self):
        async def go():
            await self.m.subscribe_many([("nse_cm", "1")], owner="scanner-universe")
            return await self.m.unsubscribe_manual([("nse_cm", "1"), ("nse_cm", "999")])
        r = self.run_(go())
        o = self.outcomes(r)
        self.assertEqual((o[("nse_cm", "1")]["outcome"], o[("nse_cm", "999")]["outcome"]), ("not_yours", "not_subscribed"))
        self.assertIn(("nse_cm", "1"), self.m._subs)                      # the scanner's subscription is untouched

    def test_remove_all_mine_leaves_everything_automatic(self):
        async def go():
            await self.m.subscribe_many(keys(1, 3), owner="manual")
            await self.m.subscribe_many(keys(10, 2), owner="scanner-manual-matches")
            await self.m.subscribe_many(keys(20, 4), owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "30")], owner="strategy:7:candidate:nse_cm:30")
            await self.m.subscribe_many([("nse_cm", "1")], owner="strategy:7:candidate:nse_cm:1")     # shared with a manual one
            return await self.m.unsubscribe_manual(None)
        r = self.run_(go())
        self.assertEqual((r["removed"], r["still_held"]), (4, 1))
        self.assertEqual(self.m.tier_counts()["scanner_universe"], 4)
        self.assertEqual(self.m.tier_counts()["candidates"], 2)
        self.assertEqual(self.m.tier_counts()["manual"], 0)

    def test_a_manual_wish_still_waiting_for_a_slot_is_cancelled_too(self):
        self.m._max_subscriptions = 2
        async def go():
            await self.m.subscribe_many(keys(1, 2), owner="position:1")
            await self.m.subscribe_manual([("nse_cm", "50")])                # no room: rejected, kept as a pending wish
            before = dict(self.m._pending)
            await self.m.unsubscribe_manual([("nse_cm", "50")])
            return before
        before = self.run_(go())
        self.assertEqual(list(before), [("nse_cm", "50")])
        self.assertEqual(self.m._pending, {})
        self.assertEqual(self.db.list_manual_subscriptions(), [])

    def test_broker_unsubscribe_is_called_once_per_batch(self):
        feed = FakeFeed()
        self.m._market = feed
        self.m._max_subscriptions = 3000
        async def go():
            await self.m.subscribe_many(keys(1, 40), owner="manual")
            await self.m.unsubscribe_manual(None)
        self.run_(go())
        self.assertEqual(len(feed.unsubscribed), 40)


class ManualSubscribeAndPersistenceTests(Base):
    def test_a_manual_subscription_is_remembered_and_forgotten_in_the_database(self):
        async def go():
            await self.m.subscribe_manual([("nse_cm", "1"), ("nse_cm", "2")])
            saved = self.db.list_manual_subscriptions()
            await self.m.unsubscribe_manual([("nse_cm", "1")])
            return saved
        saved = self.run_(go())
        self.assertEqual(saved, [("nse_cm", "1"), ("nse_cm", "2")])
        self.assertEqual(self.db.list_manual_subscriptions(), [("nse_cm", "2")])

    def test_after_a_restart_the_users_subscriptions_come_back(self):
        self.run_(self.m.subscribe_manual([("nse_cm", "1"), ("nse_cm", "2"), ("nse_cm", "3")]))
        restarted = self.wm.WebSocketManager()                               # a new process: empty registry
        restarted._max_subscriptions = 100
        r = self.run_(restarted.restore_manual_subscriptions())
        self.assertEqual((r["restored"], r["rejected"]), (3, 0))
        self.assertEqual(sorted(s["instrument_token"] for s in restarted.subscriptions()), ["1", "2", "3"])
        again = self.run_(restarted.restore_manual_subscriptions())              # idempotent
        self.assertEqual(len(restarted._subs), 3)
        self.assertEqual(again["rejected"], 0)

    def test_restore_reports_what_could_not_get_a_slot_and_retries_it(self):
        self.run_(self.m.subscribe_manual(keys(1, 5)))
        restarted = self.wm.WebSocketManager()
        restarted._max_subscriptions = 3
        r = self.run_(restarted.restore_manual_subscriptions())
        self.assertEqual((r["restored"], r["rejected"]), (3, 2))
        restarted._max_subscriptions = 5                                      # room appears
        retry = self.run_(restarted.retry_pending())
        self.assertEqual((retry["recovered"], len(restarted._subs)), (2, 5))

    def test_the_answer_says_what_was_already_on_the_feed_and_what_was_evicted(self):
        async def go():
            await self.m.subscribe_many([("nse_cm", "1")], owner="scanner-universe")
            return await self.m.subscribe_manual([("nse_cm", "1"), ("nse_cm", "2")])
        first = self.run_(go())
        self.assertEqual(first["added"], 1)
        self.assertEqual(first["already_on_feed"], [{"exchange_segment": "nse_cm", "instrument_token": "1", "held_by": ["scanner-universe"]}])
        self.assertEqual(self.m.subscription_owners(("nse_cm", "1")), ["manual", "scanner-universe"])

    def test_a_manual_request_on_a_full_feed_evicts_scanner_stocks_and_says_so(self):
        async def go():
            await self.m.subscribe_many(keys(1000, 100), owner="scanner-universe")
            return await self.m.subscribe_manual([("nse_cm", "7")])
        r = self.run_(go())
        self.assertEqual((r["added"], r["evicted"], r["rejected"]), (1, 1, []))

    def test_a_request_that_cannot_fit_is_rejected_but_remembered_as_a_wish(self):
        async def go():
            await self.m.subscribe_many(keys(1, 100), owner="position:1")
            return await self.m.subscribe_manual([("nse_cm", "9999")])
        r = self.run_(go())
        self.assertEqual((r["added"], len(r["rejected"])), (0, 1))
        self.assertIn("limit reached", r["reason"])
        self.assertEqual(self.db.list_manual_subscriptions(), [("nse_cm", "9999")])


class ListingTests(Base):
    def setUp(self):
        super().setUp()
        self.db.bulk_upsert_instruments([{"trading_symbol": f"{n}-EQ", "instrument_token": str(t), "lot_size": 1, "tick_size": 0.05}
                                         for t, n in ((1, "RELIANCE"), (2, "TCS"), (3, "INFY"), (4, "HDFCBANK"))])
        async def go():
            await self.m.subscribe_many([("nse_cm", "4")], owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "3")], owner="scanner-universe")
            await self.m.subscribe_many([("nse_cm", "2")], owner="manual")
            await self.m.subscribe_many([("nse_cm", "1")], owner="position:9")
            await self.m.subscribe_many([("nse_cm", "1")], owner="manual")
        self.run_(go())

    def test_rows_say_why_they_are_subscribed_most_important_first(self):
        rows = self.m.subscriptions()
        self.assertEqual([(r["trading_symbol"], r["tier"], r["removable"]) for r in rows],
                         [("RELIANCE-EQ", "positions", True), ("TCS-EQ", "manual", True), ("HDFCBANK-EQ", "scanner_universe", False), ("INFY-EQ", "scanner_universe", False)])
        self.assertEqual(rows[0]["owners"], ["manual", "position:9"])

    def test_filter_by_tier_text_and_paging(self):
        rows, total = self.m.subscriptions_page(tier="manual,positions")
        self.assertEqual((total, [r["trading_symbol"] for r in rows]), (2, ["RELIANCE-EQ", "TCS-EQ"]))
        rows, total = self.m.subscriptions_page(q="bank")
        self.assertEqual([r["trading_symbol"] for r in rows], ["HDFCBANK-EQ"])
        rows, total = self.m.subscriptions_page(q="3")                         # matches the token
        self.assertEqual([r["instrument_token"] for r in rows], ["3"])
        rows, total = self.m.subscriptions_page(limit=2, offset=1)
        self.assertEqual((total, [r["trading_symbol"] for r in rows]), (4, ["TCS-EQ", "HDFCBANK-EQ"]))
        self.assertEqual(self.m.subscriptions_page(offset=10), ([], 4))

    def test_summary_counts(self):
        s = self.m.subscription_summary()
        self.assertEqual((s["total"], s["limit"], s["removable"], s["pending"]), (4, 100, 2, 0))
        self.assertEqual((s["tiers"]["positions"], s["tiers"]["manual"], s["tiers"]["scanner_universe"]), (1, 1, 2))


class CandidateFlagTests(Base):
    def insert_candidate(self, token="100"):
        conn = sqlite3.connect(self.db.DB_PATH)
        conn.execute("INSERT INTO strategy_candidates(strategy_version_id,scanner_id,exchange_segment,instrument_token,timeframe,conditions_json,status,subscribed_at) "
                     "VALUES(7,1,'nse_cm',?,'5m','{}','ACTIVE',datetime('now'))", (token,))
        conn.commit()
        conn.close()

    def flag(self, token="100"):
        with self.db._connection() as c:
            return c.execute("SELECT subscribed_at,last_error FROM strategy_candidates WHERE instrument_token=?", (token,)).fetchone()

    def test_an_evicted_candidate_is_marked_not_subscribed_and_marked_live_again_when_restored(self):
        self.insert_candidate()
        self.m._max_subscriptions = 3
        cand = "strategy:7:candidate:nse_cm:100"
        async def go():
            await self.m.subscribe_many([("nse_cm", "100")], owner=cand)
            await self.m.subscribe_many(keys(1, 2), owner="position:1")
            await self.m.subscribe_many([("nse_cm", "7")], owner="position:2")          # evicts the candidate
            during = self.flag()
            await self.m.release_owner("position:2")
            await self.m.retry_pending()
            return during
        during = self.run_(go())
        self.assertIsNone(during[0])
        self.assertIn("Feed full", during[1])
        self.assertIsNotNone(self.flag()[0])


class ServerHandlerTests(Base):
    def setUp(self):
        super().setUp()
        from app import server
        self.server = server
        p1 = patch.object(server, "_connected_or_409", lambda: None)
        p2 = patch("app.websocket_manager.websocket_manager", self.m)
        p1.start(); p2.start()
        self.addCleanup(p1.stop); self.addCleanup(p2.stop)

    def post(self, handler, body):
        return self.run_(handler({}, body))

    def test_subscribe_one_reports_what_happened(self):
        status, out = self.post(self.server.h_subscribe, {"exchange_segment": "nse_cm", "instrument_token": "11915", "trading_symbol": "YESBANK-EQ", "name": "YES BANK"})
        self.assertEqual(status, 200)
        self.assertEqual(out["result"]["added"], 1)
        self.assertIn("1 subscribed", out["message"])
        self.assertEqual(self.db.get_instrument("nse_cm", "11915")["trading_symbol"], "YESBANK-EQ")      # display metadata still stored

    def test_subscribe_many_in_one_request(self):
        status, out = self.post(self.server.h_subscribe, {"items": [{"exchange_segment": "nse_cm", "instrument_token": str(i)} for i in range(1, 6)]})
        self.assertEqual((status, out["result"]["added"], len(self.m._subs)), (200, 5, 5))

    def test_subscribing_something_already_on_the_feed_says_so(self):
        self.run_(self.m.subscribe_many([("nse_cm", "1")], owner="scanner-universe"))
        status, out = self.post(self.server.h_subscribe, {"exchange_segment": "nse_cm", "instrument_token": "1"})
        self.assertEqual(status, 200)
        self.assertIn("already on the live feed", out["message"])

    def test_bad_input_is_rejected_with_a_reason(self):
        h = self.server.h_subscribe
        self.assertEqual(self.post(h, {"exchange_segment": "nse_cm"})[0], 400)
        self.assertEqual(self.post(h, {"exchange_segment": "NSE", "instrument_token": "1"})[0], 400)
        self.assertEqual(self.post(h, {"exchange_segment": "nse_cm", "instrument_token": "x" * 41})[0], 400)
        self.assertEqual(self.post(h, {"exchange_segment": "nse_cm", "instrument_token": "a\nb"})[0], 400)
        self.assertEqual(self.post(h, {"items": []})[0], 400)
        self.assertEqual(self.post(h, {"items": ["nope"]})[0], 400)
        self.assertEqual(self.post(h, {"items": [{"exchange_segment": "nse_cm", "instrument_token": str(i)} for i in range(501)]})[0], 400)
        self.assertEqual(len(self.m._subs), 0)

    def test_a_full_feed_gives_an_error_the_ui_can_show(self):
        self.m._max_subscriptions = 2
        self.run_(self.m.subscribe_many(keys(1, 2), owner="position:1"))
        status, out = self.post(self.server.h_subscribe, {"exchange_segment": "nse_cm", "instrument_token": "9"})
        self.assertEqual(status, 400)
        self.assertIn("limit reached", out["error"])

    def test_unsubscribe_tells_the_truth_in_every_case(self):
        self.run_(self.m.subscribe_many([("nse_cm", "1")], owner="manual"))
        self.run_(self.m.subscribe_many([("nse_cm", "2")], owner="manual"))
        self.run_(self.m.subscribe_many([("nse_cm", "2")], owner="scanner-universe"))
        self.run_(self.m.subscribe_many([("nse_cm", "3")], owner="scanner-universe"))
        s, out = self.post(self.server.h_unsubscribe, {"items": [{"exchange_segment": "nse_cm", "instrument_token": t} for t in ("1", "2", "3", "4")]})
        self.assertEqual(s, 200)
        self.assertEqual((out["result"]["removed"], out["result"]["still_held"], out["result"]["not_yours"], out["result"]["not_subscribed"]), (1, 1, 1, 1))
        self.assertIn("1 removed from the live feed", out["message"])
        self.assertIn("still needs it", out["message"])
        self.assertIn("only for automatic reasons", out["message"])
        self.assertIn("were not subscribed", out["message"])
        self.assertEqual(self.post(self.server.h_unsubscribe, {"exchange_segment": "nse_cm"})[0], 400)

    def test_remove_all_mine(self):
        self.run_(self.m.subscribe_manual(keys(1, 3)))
        self.run_(self.m.subscribe_many(keys(50, 2), owner="scanner-universe"))
        s, out = self.post(self.server.h_unsubscribe_all_manual, {})
        self.assertEqual((s, out["result"]["removed"], out["summary"]["total"]), (200, 3, 2))
        self.assertEqual(self.db.list_manual_subscriptions(), [])

    def test_listing_filters_and_summary(self):
        self.run_(self.m.subscribe_manual(keys(1, 3)))
        self.run_(self.m.subscribe_many(keys(50, 5), owner="scanner-universe"))
        s, out = self.run_(self.server.h_subscriptions({"tier": ["manual"], "limit": ["2"]}, {}))
        self.assertEqual((s, len(out["subscriptions"]), out["total_matching"], out["summary"]["total"]), (200, 2, 3, 8))
        s, out = self.run_(self.server.h_subscriptions({}, {}))
        self.assertEqual(len(out["subscriptions"]), 8)                          # no parameters: everything, as before

    def test_ticks_say_whether_the_instrument_is_still_on_the_feed(self):
        self.db.record_market_tick(instrument_token="1", exchange_segment="nse_cm", last_traded_price=10.0)
        self.db.record_market_tick(instrument_token="2", exchange_segment="nse_cm", last_traded_price=20.0)
        self.run_(self.m.subscribe_many([("nse_cm", "1")], owner="manual"))
        s, out = self.run_(self.server.h_ticks({}, {}))
        by = {t["instrument_token"]: t["subscribed"] for t in out["ticks"]}
        self.assertEqual(by, {"1": True, "2": False})

    def test_the_routes_exist(self):
        routes = [v for v in vars(self.server).values() if isinstance(v, dict) and ("GET", "/subscriptions") in v][0]
        self.assertIs(routes[("POST", "/subscribe")], self.server.h_subscribe)
        self.assertIs(routes[("POST", "/unsubscribe")], self.server.h_unsubscribe)
        self.assertIs(routes[("POST", "/unsubscribe-all-manual")], self.server.h_unsubscribe_all_manual)


if __name__ == "__main__":
    unittest.main()


class DisconnectedBrokerTests(Base):
    def test_a_user_can_remove_subscriptions_even_when_the_broker_session_is_gone(self):
        from app import server
        from app.state import BrokerState, current_state
        self.run_(self.m.subscribe_manual(keys(1, 3)))
        with patch("app.websocket_manager.websocket_manager", self.m), patch.object(current_state, "state", BrokerState.SESSION_EXPIRED):
            s_sub, _ = self.run_(server.h_subscribe({}, {"exchange_segment": "nse_cm", "instrument_token": "9"}))
            s_one, one = self.run_(server.h_unsubscribe({}, {"exchange_segment": "nse_cm", "instrument_token": "1"}))
            s_all, all_ = self.run_(server.h_unsubscribe_all_manual({}, {}))
        self.assertEqual(s_sub, 409)                                      # subscribing still needs a live session
        self.assertEqual((s_one, one["result"]["removed"], s_all, all_["result"]["removed"]), (200, 1, 200, 2))
        self.assertEqual(len(self.m._subs), 0)
        self.assertEqual(self.db.list_manual_subscriptions(), [])
