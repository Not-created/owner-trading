"""P1: housekeeping retention trims only derived tables and never touches trading records."""
import os
import sqlite3
import unittest


class HousekeepingPruneTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        self.db = fresh_db()
        self.path = os.environ["DB_PATH"]
        self.db.FINAL_AUDIT_RUNS_KEEP = 3

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _q(self, sql, args=()):
        c = sqlite3.connect(self.path)
        try:
            r = c.execute(sql, args).fetchall()
            c.commit()
            return r
        finally:
            c.close()

    def test_prunes_only_derived_data(self):
        for _ in range(7):
            self._q("INSERT INTO final_audit_runs(status) VALUES('DONE')")
        self._q("INSERT INTO execution_audit_snapshots(internal_order_id,chain_json,created_at) VALUES('o1','{}',datetime('now','-400 days'))")
        self._q("INSERT INTO execution_audit_snapshots(internal_order_id,chain_json) VALUES('o2','{}')")
        self._q("INSERT INTO backtests(request_json,status,created_at) VALUES('{}','DONE',datetime('now','-200 days'))")
        self._q("INSERT INTO backtests(request_json,status) VALUES('{}','DONE')")
        for bt in (1, 2):
            self._q("INSERT INTO backtest_equity_points(backtest_id,point_no,equity) VALUES(?,?,?)", (bt, 1, 100.0))

        removed = self.db.prune_housekeeping()

        self.assertEqual(removed["final_audit_runs"], 4)
        self.assertEqual(self._q("SELECT COUNT(*) FROM final_audit_runs")[0][0], 3)
        self.assertEqual(removed["execution_audit_snapshots"], 1)
        self.assertEqual(self._q("SELECT internal_order_id FROM execution_audit_snapshots")[0][0], "o2")
        self.assertEqual(removed["backtest_equity_points"], 1)
        self.assertEqual(self._q("SELECT backtest_id FROM backtest_equity_points")[0][0], 2)
        # the old backtest row itself is kept
        self.assertEqual(self._q("SELECT COUNT(*) FROM backtests")[0][0], 2)

    def test_idempotent_on_empty(self):
        self.assertEqual(self.db.prune_housekeeping(),
                         {"final_audit_runs": 0, "execution_audit_snapshots": 0, "backtest_equity_points": 0})


if __name__ == "__main__":
    unittest.main()
