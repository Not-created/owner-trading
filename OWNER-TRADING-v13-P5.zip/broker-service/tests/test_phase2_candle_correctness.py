"""Phase 2: bars close by the clock, pre-open/post-close ticks are not bars, completed bars are durable before use."""
import asyncio
import datetime as dt
import importlib
import unittest
from unittest import mock
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")


def at(h, m, s=0, day=14):
    return dt.datetime(2026, 10, day, h, m, s, tzinfo=IST)


class Base(unittest.TestCase):
    TFS = {"5m"}

    def setUp(self):
        self.db = fresh_db()
        from app import tick_writer as tw, candle_engine as ce
        importlib.reload(tw)
        importlib.reload(ce)
        self.tw, self.ce = tw, ce
        self.writer = tw.tick_writer
        self.engine = ce.CandleEngine()
        self.engine._timeframe_cache = set(self.TFS)
        self.engine._timeframe_cache_at = 10 ** 12

    def tearDown(self):
        self.writer.stop()

    def tick(self, ts, price, vol=None, token="1"):
        self.engine.on_tick(exchange_segment="nse_cm", instrument_token=token, trading_symbol="X", price=price, volume=vol, timestamp=ts)

    def candles(self, tf="5m", token="1"):
        return self.db.recent_candles("nse_cm", token, tf, 100)


class ClockFinalizerTests(Base):
    def test_illiquid_stock_bar_is_written_without_a_next_tick(self):
        self.writer.start()
        self.tick(at(9, 16), 100.0, 10)
        self.tick(at(9, 18), 101.0, 20)
        self.assertEqual(self.engine.finalize_due(now=at(9, 20, 0)), 0)          # inside the grace second: not yet
        self.assertEqual(self.engine.finalize_due(now=at(9, 20, 2)), 1)
        self.writer.flush()
        rows = self.candles()
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0]["candle_at"], rows[0]["open"], rows[0]["high"], rows[0]["close"]), ("2026-10-14 09:15:00", 100.0, 101.0, 101.0))
        self.assertIsNone(self.db.get_candle_runtime_state("nse_cm", "1", "5m"))   # checkpoint of a closed bar is gone

    def test_next_tick_does_not_write_or_announce_the_bar_a_second_time(self):
        self.writer.start()
        self.tick(at(9, 16), 100.0, 10)
        self.engine.finalize_due(now=at(9, 20, 2))
        with mock.patch.object(self.engine, "_emit_completed") as emitted, mock.patch.object(self.writer, "put_candle") as put:
            self.tick(at(9, 21), 102.0, 30)
        put.assert_not_called()
        emitted.assert_not_called()
        self.assertEqual(self.engine._state[("nse_cm", "1", "5m")]["at"], at(9, 20))

    def test_late_tick_inside_an_already_closed_bar_updates_it(self):
        self.writer.start()
        self.tick(at(9, 16), 100.0, 10)
        self.engine.finalize_due(now=at(9, 20, 2))
        self.writer.flush()
        self.tick(at(9, 19, 59), 105.0, 20)          # stamped inside the closed bar, newer than the last tick: counted
        self.tick(at(9, 16, 30), 120.0, 25)          # older than the last tick seen: ignored (out of order)
        self.writer.flush()
        row = self.candles()[0]
        self.assertEqual((row["high"], row["close"]), (105.0, 105.0))
        self.assertIsNone(self.db.get_candle_runtime_state("nse_cm", "1", "5m"))   # a closed bar gets no new checkpoint

    def test_two_timeframes_close_independently(self):
        self.engine._timeframe_cache = {"5m", "10m"}
        self.writer.start()
        self.tick(at(9, 16), 100.0, 10)
        self.engine.finalize_due(now=at(9, 20, 2))
        self.writer.flush()
        self.assertEqual(len(self.candles("5m")), 1)
        self.assertEqual(len(self.candles("10m")), 0)
        self.engine.finalize_due(now=at(9, 25, 2))
        self.writer.flush()
        self.assertEqual(len(self.candles("10m")), 1)


class SessionFilterTests(Base):
    def test_pre_open_and_post_close_ticks_make_no_bar_and_opening_volume_is_kept(self):
        self.tick(at(9, 5), 100.0, 1000)             # pre-open: no bar, but the volume baseline moves
        self.assertEqual(self.engine._state, {})
        self.tick(at(9, 15, 5), 101.0, 1500)
        self.tick(at(15, 31), 99.0, 9000)            # post-close: ignored
        self.engine.finalize_due(now=at(15, 32))
        rows = self.candles()
        self.assertEqual([r["candle_at"] for r in rows], ["2026-10-14 09:15:00"])
        self.assertEqual(rows[0]["volume"], 500)     # opening auction volume belongs to the 09:15 bar

    def test_startup_purge_removes_old_fake_bars_but_not_daily_or_session_bars(self):
        base = {"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "X", "open": 1, "high": 1, "low": 1, "close": 1, "volume": 0}
        self.db.upsert_candles([dict(base, timeframe="5m", candle_at="2026-10-14 00:00:00"),
                                dict(base, timeframe="5m", candle_at="2026-10-14 15:30:00"),
                                dict(base, timeframe="5m", candle_at="2026-10-14 09:15:00"),
                                dict(base, timeframe="5m", candle_at="2026-10-14 15:25:00"),
                                dict(base, timeframe="1d", candle_at="2026-10-14 00:00:00")])
        self.assertEqual(self.db.purge_out_of_session_candles(), 2)
        self.assertEqual([r["candle_at"] for r in self.candles("5m")], ["2026-10-14 09:15:00", "2026-10-14 15:25:00"])
        self.assertEqual(len(self.candles("1d")), 1)


class BarEndTests(unittest.TestCase):
    def test_bar_end_is_cut_by_the_close_and_daily_ends_at_close(self):
        from app.market_session import bar_end
        self.assertEqual(bar_end(at(10, 0), 5), at(10, 5))
        self.assertEqual(bar_end(at(15, 15), 60), at(15, 30))
        self.assertEqual(bar_end(at(15, 15), 30), at(15, 30))
        self.assertEqual(bar_end(at(0, 0), 1440), at(15, 30))

    def test_scanner_treats_the_last_partial_bar_and_the_daily_bar_as_complete_at_the_close(self):
        from app import scanner_engine as se
        self.assertTrue(se._bar_is_complete("2026-10-14 15:15:00", "1h", at(15, 31)))
        self.assertFalse(se._bar_is_complete("2026-10-14 15:15:00", "1h", at(15, 20)))
        self.assertTrue(se._bar_is_complete("2026-10-14 00:00:00", "1d", at(15, 45)))
        self.assertFalse(se._bar_is_complete("2026-10-14 00:00:00", "1d", at(11, 0)))
        self.assertTrue(se._bar_is_complete("2026-10-14 10:00:00", "5m", at(10, 5)))


class DurableBeforeEvaluationTests(Base):
    def test_strategy_evaluation_sees_the_bar_that_just_closed(self):
        self.writer.start()
        seen = []

        async def fake_on_tick(**kw):
            seen.append([c["candle_at"] for c in self.db.recent_candles(kw["exchange_segment"], kw["instrument_token"], kw["timeframe"], 10)])

        async def scenario():
            self.tick(at(9, 16), 100.0, 10)
            self.tick(at(9, 21), 101.0, 20)              # closes the 09:15 bar via the next-tick path
            await self.engine._dispatch_task

        from app import algo_engine as ae
        with mock.patch.object(ae.algo_engine, "on_tick", side_effect=fake_on_tick), \
             mock.patch.object(self.ce, "relevant_completed", side_effect=lambda b: b):    # isolate the flush ordering from the prefilter
            asyncio.run(scenario())
        self.assertEqual(seen, [["2026-10-14 09:15:00"]])      # without the flush the list would be empty

    def test_clock_finalizer_also_triggers_evaluation_after_the_write(self):
        self.writer.start()
        seen = []

        async def fake_on_tick(**kw):
            seen.append(len(self.db.recent_candles(kw["exchange_segment"], kw["instrument_token"], kw["timeframe"], 10)))

        async def scenario():
            self.tick(at(9, 16), 100.0, 10)
            self.engine.finalize_due(now=at(9, 20, 2))
            await self.engine._dispatch_task

        from app import algo_engine as ae
        with mock.patch.object(ae.algo_engine, "on_tick", side_effect=fake_on_tick), \
             mock.patch.object(self.ce, "relevant_completed", side_effect=lambda b: b):    # isolate the flush ordering from the prefilter
            asyncio.run(scenario())
        self.assertEqual(seen, [1])


class SeedTests(Base):
    def test_first_tick_of_a_stored_bar_seeds_from_the_preload_without_a_read(self):
        self.db.upsert_candles([{"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "X", "timeframe": "5m",
                                 "candle_at": "2026-10-14 09:15:00", "open": 100, "high": 104, "low": 99, "close": 103, "volume": 50}])
        with mock.patch.object(self.ce, "dt") as fake_dt:      # preload computes "now"; pin it to the stored bucket
            fake_dt.datetime.now.return_value = at(9, 16)
            fake_dt.datetime.side_effect = dt.datetime
            fake_dt.timezone = dt.timezone
            fake_dt.timedelta = dt.timedelta
            self.engine.preload_runtime_state()
        self.writer.start()
        with mock.patch.object(self.db, "get_candle", side_effect=AssertionError("per-key read")):
            self.tick(at(9, 17), 106.0, 10)
        st = self.engine._state[("nse_cm", "1", "5m")]
        self.assertEqual((st["open"], st["high"], st["low"]), (100.0, 106.0, 99.0))


if __name__ == "__main__":
    unittest.main()


class RecoveryAndPrefilterTests(Base):
    def test_unfinished_bar_from_before_a_crash_becomes_a_candle_at_start(self):
        self.db.upsert_candle_runtime_state(exchange_segment="nse_cm", instrument_token="1", timeframe="5m",
                                            candle_at="2026-10-13 15:25:00", open_=100, high=103, low=99, close=102, volume=70,
                                            trading_symbol="X", cumulative_volume=900)
        self.db.upsert_candle_runtime_state(exchange_segment="nse_cm", instrument_token="2", timeframe="5m",
                                            candle_at="2026-10-13 15:25:00", open_=50, high=51, low=49, close=50, volume=5,
                                            trading_symbol="Y", cumulative_volume=100)
        # token 2 already has the authoritative broker bar: it must not be overwritten
        self.db.upsert_candles([{"exchange_segment": "nse_cm", "instrument_token": "2", "trading_symbol": "Y", "timeframe": "5m",
                                 "candle_at": "2026-10-13 15:25:00", "open": 50, "high": 55, "low": 48, "close": 54, "volume": 999}])
        self.assertEqual(self.engine.preload_runtime_state(), 0)           # nothing left to resume: both bars ended long ago
        one = self.candles("5m", "1")[0]
        self.assertEqual((one["candle_at"], one["high"], one["volume"]), ("2026-10-13 15:25:00", 103.0, 70))
        two = self.candles("5m", "2")[0]
        self.assertEqual((two["high"], two["volume"]), (55.0, 999))        # broker data kept
        self.assertEqual(self.db.load_candle_runtime_states(), {})

    def test_relevant_completed_keeps_only_bars_a_strategy_can_act_on(self):
        ce = self.ce
        batch = [("nse_cm", str(i), "S%d" % i, "5m") for i in range(1, 6)] + [("nse_cm", "1", "S1", "15m")]
        with mock.patch.object(self.db, "refresh_algo_runtime") as refresh, \
             mock.patch.object(self.db, "list_live_armed_strategy_versions", return_value=[]):
            self.assertEqual(ce.relevant_completed(batch), [])
            refresh.assert_called_once()                                    # the runtime counter is still kept current
        scanner_linked = {"id": 7, "definition": {"timeframe": "5m", "scanner_ids": [3]}}
        with mock.patch.object(self.db, "refresh_algo_runtime"), \
             mock.patch.object(self.db, "list_live_armed_strategy_versions", return_value=[scanner_linked]), \
             mock.patch.object(self.db, "list_strategy_candidates", return_value=[{"exchange_segment": "nse_cm", "instrument_token": "2"},
                                                                                  {"exchange_segment": "nse_cm", "instrument_token": "4"}]):
            self.assertEqual([b[1] for b in ce.relevant_completed(batch)], ["2", "4"])    # 5m candidates only, no 15m
        bound = {"id": 8, "definition": {"timeframe": "5m", "universe": {"instrument_tokens": ["3"]}}}
        with mock.patch.object(self.db, "refresh_algo_runtime"), mock.patch.object(self.db, "list_live_armed_strategy_versions", return_value=[bound]):
            self.assertEqual([b[1] for b in ce.relevant_completed(batch)], ["3"])
        open_ended = {"id": 9, "definition": {"timeframe": "5m"}}
        with mock.patch.object(self.db, "refresh_algo_runtime"), mock.patch.object(self.db, "list_live_armed_strategy_versions", return_value=[open_ended]):
            self.assertEqual(len(ce.relevant_completed(batch)), 5)          # nothing can be skipped; the 15m bar is not its timeframe
