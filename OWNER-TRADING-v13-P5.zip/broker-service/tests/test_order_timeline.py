"""P5: the order timeline is read-only, built from local rows, merges repeated reports and tells the right story."""
import asyncio
import json
import os
import sqlite3
import unittest


class OrderTimelineTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        from app import order_timeline
        self.db = fresh_db()
        self.ot = order_timeline
        self.path = os.environ["DB_PATH"]
        self.oid = self.db.create_order(
            internal_order_id="ord-1", trading_symbol="RELIANCE-EQ", exchange_segment="nse_cm", transaction_type="B",
            order_type="L", product="MIS", validity="DAY", quantity=10, price=2642.5, trigger_price=None, mode="LIVE",
            status="SUBMITTED", broker_order_id="B100")

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _exec(self, sql, args=()):
        c = sqlite3.connect(self.path)
        try:
            c.execute(sql, args)
            c.commit()
        finally:
            c.close()

    def _event(self, source, payload, at):
        self._exec("INSERT INTO order_events(order_id,broker_order_id,event_source,raw_payload,received_at) VALUES(?,?,?,?,?)",
                   (self.oid, "B100", source, json.dumps(payload), at))

    def test_full_story_with_merge_and_fills(self):
        self._event("order_feed_ws", {"ordSt": "open", "fldQty": 0, "unFldSz": 10}, "2026-10-27 10:05:01")
        self._event("order_report_rest", {"ordSt": "open", "fldQty": 0, "unFldSz": 10}, "2026-10-27 10:05:02")   # same state, other source
        self._event("order_feed_ws", {"ordSt": "open", "fldQty": 4, "unFldSz": 6, "avgPrc": 2642.5}, "2026-10-27 10:06:00")
        self._event("order_feed_ws", {"ordSt": "complete", "fldQty": 10, "unFldSz": 0, "avgPrc": 2642.8}, "2026-10-27 10:07:00")
        self._exec("INSERT INTO trades(order_id,broker_order_id,broker_trade_id,fill_quantity,fill_price,fill_time,raw_payload,created_at) VALUES(?,?,?,?,?,?,?,?)",
                   (self.oid, "B100", "T1", 4, 2642.5, "27-Oct-2026 10:06:00", "{}", "2026-10-27 10:06:01"))
        self._exec("INSERT INTO trades(order_id,broker_order_id,broker_trade_id,fill_quantity,fill_price,fill_time,raw_payload,created_at) VALUES(?,?,?,?,?,?,?,?)",
                   (self.oid, "B100", "T2", 6, 2642.99, "27-Oct-2026 10:07:00", "{}", "2026-10-27 10:07:01"))
        self._exec("UPDATE orders SET created_at='2026-10-27 10:05:00', status='COMPLETE', filled_quantity=10, average_price=2642.8 WHERE id=?", (self.oid,))
        out = self.ot.order_timeline("ord-1")
        kinds = [s["kind"] for s in out["steps"]]
        self.assertEqual(kinds, ["created", "update", "update", "fill", "update", "fill"])   # 2 duplicate reports merged into 1
        self.assertEqual(out["steps"][0]["detail"], "BUY 10 @ 2642.5 · L · MIS")
        first = out["steps"][1]
        self.assertEqual(first["sources"], ["लाइव फ़ीड", "ऑर्डर रिपोर्ट"])
        self.assertEqual(first["repeats"], 2)
        self.assertIn("भरा 4", out["steps"][2]["detail"])
        self.assertEqual(out["steps"][4]["tone"], "good")
        self.assertEqual(out["steps"][4]["title"], "पूरा हुआ")
        self.assertEqual(out["order"]["status"], "COMPLETE")
        self.assertEqual(out["order"]["filled_quantity"], 10)

    def test_rejection_reason_and_unknown_status_text(self):
        self._event("order_feed_ws", {"ordSt": "rejected", "rejRsn": "Insufficient funds"}, "2026-10-27 10:05:03")
        self._event("reconciliation", {"ordSt": "some new state"}, "2026-10-27 10:05:09")
        out = self.ot.order_timeline("ord-1")
        rej = next(s for s in out["steps"] if s["title"] == "अस्वीकृत")
        self.assertEqual(rej["tone"], "bad")
        self.assertIn("Insufficient funds", rej["detail"])
        self.assertTrue(any(s["title"] == "some new state" for s in out["steps"]))     # unknown states are shown as-is

    def test_bad_payloads_never_break_it_and_other_orders_are_not_mixed_in(self):
        self._exec("INSERT INTO order_events(order_id,broker_order_id,event_source,raw_payload) VALUES(?,?,?,?)", (self.oid, "B100", "order_feed_ws", "not json"))
        self._exec("INSERT INTO order_events(order_id,broker_order_id,event_source,raw_payload) VALUES(?,?,?,?)", (self.oid, "B100", "order_feed_ws", "[1,2]"))
        other = self.db.create_order(internal_order_id="ord-2", trading_symbol="INFY-EQ", exchange_segment="nse_cm", transaction_type="S", order_type="MKT",
                                     product="CNC", validity="DAY", quantity=1, price=None, trigger_price=None, mode="LIVE", status="SUBMITTED", broker_order_id="B200")
        self._exec("INSERT INTO order_events(order_id,broker_order_id,event_source,raw_payload) VALUES(?,?,?,?)", (other, "B200", "order_feed_ws", json.dumps({"ordSt": "complete"})))
        out = self.ot.order_timeline("ord-1")
        self.assertFalse(any(s["title"] == "पूरा हुआ" for s in out["steps"]))
        self.assertEqual(out["steps"][0]["kind"], "created")

    def test_unknown_order_and_the_route(self):
        from app import server
        self.assertIsNone(self.ot.order_timeline("nope"))
        run = asyncio.run
        self.assertEqual(run(server.h_order_timeline({"internal_order_id": ["nope"]}, {}))[0], 404)
        self.assertEqual(run(server.h_order_timeline({}, {}))[0], 400)
        status, body = run(server.h_order_timeline({"internal_order_id": ["ord-1"]}, {}))     # real, list-shaped query
        self.assertEqual(status, 200)
        self.assertEqual(body["order"]["symbol"], "RELIANCE-EQ")
        self.assertIn(("GET", "/order-timeline"), server.ROUTES)

    def test_read_only(self):
        self._event("order_feed_ws", {"ordSt": "open"}, "2026-10-27 10:05:01")
        c = sqlite3.connect(self.path)
        before = c.execute("SELECT (SELECT COUNT(*) FROM orders),(SELECT COUNT(*) FROM order_events),(SELECT COUNT(*) FROM trades),(SELECT status FROM orders)").fetchall()
        c.close()
        self.ot.order_timeline("ord-1")
        c = sqlite3.connect(self.path)
        after = c.execute("SELECT (SELECT COUNT(*) FROM orders),(SELECT COUNT(*) FROM order_events),(SELECT COUNT(*) FROM trades),(SELECT status FROM orders)").fetchall()
        c.close()
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
