"""Phase 6 (backend): what the Scanner page shows must be real, and the diagnostics button must be read-only."""
import asyncio
import unittest
from unittest.mock import AsyncMock, patch

from app import scanner_engine as se
from tests.dbutil import fresh_db
from tests.test_v12_scanner_plan import SCANNER, mk_candles


def instruments(*tokens):
    return [{"trading_symbol": f"S{t}-EQ", "instrument_token": str(t), "lot_size": 1, "tick_size": 0.05} for t in tokens]


def counts(db):
    with db._connection() as c:
        return {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in
                ("scan_runs", "strategy_candidates", "candles", "market_data_state", "candle_runtime_state", "orders")}


class DiagnosticsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        se._LAST_RUN.clear()
        self.db.bulk_upsert_instruments(instruments(11, 12))
        self.db.upsert_candles(mk_candles(11, volume=5000))                  # one of the two stocks has history
        sc = self.db.create_scanner("m", dict(SCANNER))
        self.db.set_scanner_active(sc["id"], True)
        self.sid = sc["id"]

    async def test_reports_the_real_numbers_of_each_active_scanner(self):
        out = await se.diagnostics()
        self.assertEqual(len(out["scanners"]), 1)
        sc = out["scanners"][0]
        self.assertEqual((sc["id"], sc["timeframe"], sc["status"]), (self.sid, "5m", "PARTIAL"))
        self.assertEqual((sc["data"]["universe"], sc["data"]["ready"], sc["data"]["not_ready"], sc["data"]["readiness_pct"]), (2, 1, 1, 50.0))
        self.assertEqual((sc["data"]["no_candles"], sc["data"]["required_bars"]), (1, 87))
        self.assertEqual((sc["coverage"]["eligible_total"], sc["coverage"]["universe"], sc["coverage"]["truncated"]), (2, 2, 0))
        self.assertEqual(out["instruments"]["total"], 2)
        for key in ("feed", "tick_writer", "candle_engine", "took_ms", "market_open"):
            self.assertIn(key, out)
        self.assertEqual(out["feed"]["limit"], 3000)
        self.assertIsNone(sc["last_run"])

    async def test_it_is_read_only(self):
        before = counts(self.db)
        subs_before = list(se.websocket_manager._subs)
        with patch.object(se.websocket_manager, "subscribe_many", AsyncMock(side_effect=AssertionError("must not subscribe"))), \
             patch.object(se.websocket_manager, "ensure_owner_subscriptions", AsyncMock(side_effect=AssertionError("must not subscribe"))), \
             patch.object(se, "start_warmup_job", side_effect=AssertionError("must not start a history download")):
            await se.diagnostics()
        self.assertEqual(counts(self.db), before)
        self.assertEqual(list(se.websocket_manager._subs), subs_before)

    async def test_shows_the_last_run_of_the_scanner(self):
        self.db.record_scan_run(scanner_id=self.sid, strategy_version_id=1, timeframe="5m", bar_at="2026-10-08 10:05:00", status="FAILED",
                                error="boom", universe=2, stats={"attempt": 2})
        out = await se.diagnostics()
        self.assertEqual(out["scanners"][0]["last_run"]["status"], "FAILED")
        self.assertEqual((out["scanners"][0]["last_run"]["attempt"], out["scanners"][0]["last_run"]["error"]), (2, "boom"))

    async def test_a_broken_scanner_does_not_hide_the_others_or_the_feed_numbers(self):
        with patch.object(se, "_scan_with_stats", side_effect=RuntimeError("bad data")):
            out = await se.diagnostics()
        self.assertEqual((out["scanners"][0]["status"], out["scanners"][0]["error"]), ("FAILED", "RuntimeError: bad data"))
        self.assertIn("feed", out)

    async def test_no_active_scanner_still_reports_instruments_and_feed(self):
        self.db.set_scanner_active(self.sid, False)
        out = await se.diagnostics()
        self.assertEqual(out["scanners"], [])
        self.assertEqual(out["instruments"]["total"], 2)


class ManualRunRowsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        self.db.bulk_upsert_instruments(instruments(11, 12))
        self.db.upsert_candles(mk_candles(11, volume=5000, step=0.5) + mk_candles(12, volume=5000, step=0.5))

    async def run_scan(self, owners):
        with patch.object(se.websocket_manager, "subscription_owners", lambda key=None: owners.get(key, [])):
            return await se.run({"definition": dict(SCANNER), "timeframe": "5m", "warmup": False})

    async def test_every_match_carries_data_status_feed_status_and_the_last_completed_candle(self):
        out = await self.run_scan({("nse_cm", "11"): ["scanner-universe"]})
        self.assertEqual(out["status"], "COMPLETE")
        rows = {r["instrument_token"]: r for r in out["matches"]}
        self.assertEqual(set(rows), {"11", "12"})
        self.assertEqual((rows["11"]["data_status"], rows["11"]["subscription"]), ("FRESH", "SUBSCRIBED"))
        self.assertEqual((rows["12"]["data_status"], rows["12"]["subscription"]), ("FRESH", "NOT_SUBSCRIBED"))
        self.assertEqual(rows["11"]["last_completed_candle"], rows["11"]["candle_at"])
        self.assertRegex(rows["11"]["last_completed_candle"], r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$")
        self.assertEqual(out["feed_status"]["limit"], 3000)
        self.assertEqual(out["coverage"]["universe"], 2)

    async def test_the_manual_run_is_recorded_with_its_real_status(self):
        await self.run_scan({})
        run = self.db.list_scan_runs(1)[0]
        self.assertEqual((run["trigger"], run["status"], run["stats"]["status"]), ("MANUAL", "COMPLETE", "COMPLETE"))

    async def test_a_scan_with_half_the_data_is_partial_not_complete(self):
        self.db.bulk_upsert_instruments(instruments(13))                     # a third stock with no candles at all
        out = await self.run_scan({})
        self.assertEqual((out["status"], out["diagnostics"]["ready"], out["diagnostics"]["not_ready"]), ("PARTIAL", 2, 1))


class RoutingTests(unittest.TestCase):
    def test_the_endpoint_is_routed_and_has_a_handler(self):
        from app import server
        self.assertTrue(hasattr(server, "h_algo_scanner_diagnostics"))
        routes = [v for v in vars(server).values() if isinstance(v, dict) and ("GET", "/algo/scan-runs") in v]
        self.assertTrue(routes and routes[0][("GET", "/algo/scanner-diagnostics")] is server.h_algo_scanner_diagnostics)


if __name__ == "__main__":
    unittest.main()
