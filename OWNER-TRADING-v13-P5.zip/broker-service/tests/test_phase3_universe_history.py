"""Phase 3: one canonical universe, real coverage numbers, prioritised and non-repeating history back-fill."""
import asyncio
import datetime as dt
import unittest
from unittest import mock

from tests.dbutil import fresh_db


def inst(token, symbol=None, series="EQ"):
    return {"trading_symbol": symbol or f"S{token}-{series}", "instrument_token": str(token), "lot_size": 1, "tick_size": 0.05}


class Base(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        import importlib
        from app import scanner_engine, daily_prep
        importlib.reload(scanner_engine)
        importlib.reload(daily_prep)
        self.se, self.dp = scanner_engine, daily_prep


class CoverageTests(Base):
    def test_coverage_reports_the_real_total_and_what_is_cut(self):
        self.db.bulk_upsert_instruments([inst(i) for i in range(1, 3001)] + [inst(9000 + i, series="BE") for i in range(50)])
        definition = {"timeframe": "5m", "entry": {"op": "AND", "conditions": []}}
        universe = self.se.scan_universe(definition)
        cov = self.se.universe_coverage(definition, universe)
        self.assertEqual((cov["eligible_total"], cov["universe"], cov["cap"], cov["truncated"]), (3000, 2800, 2800, 200))
        self.assertEqual(cov["coverage_pct"], 93.3)
        self.assertIn("200 of 3000 stocks", cov["warning"])
        self.assertIn("NOT scanned", cov["warning"])

    def test_no_warning_when_everything_fits_and_for_explicit_instruments(self):
        self.db.bulk_upsert_instruments([inst(i) for i in range(1, 101)])
        cov = self.se.universe_coverage({"timeframe": "5m"}, self.se.scan_universe({"timeframe": "5m"}))
        self.assertEqual((cov["eligible_total"], cov["truncated"], cov["warning"]), (100, 0, None))
        explicit = {"timeframe": "5m", "universe": {"instrument_tokens": ["1", "2", "3"]}}
        cov = self.se.universe_coverage(explicit, self.se.scan_universe(explicit))
        self.assertEqual((cov["explicit"], cov["universe"], cov["truncated"]), (True, 3, 0))

    def test_series_selection_counts_only_the_chosen_series(self):
        self.db.bulk_upsert_instruments([inst(1), inst(2), inst(3, series="BE")])
        self.assertEqual(self.db.count_scan_universe(("EQ",)), 2)
        self.assertEqual(self.db.count_scan_universe(("EQ", "BE")), 3)

    def test_the_explanation_text_carries_the_coverage_warning(self):
        stats = {"universe": 2800, "evaluated": 10, "matched": 0, "matched_total": 0, "no_candles": 0, "insufficient_history": 0,
                 "stale": 0, "required_bars": 20, "latest_candle_at": None,
                 "coverage": {"warning": "147 of 2947 stocks are beyond the limit and are NOT scanned."}}
        text = self.se._scan_explanation(stats, True, None)
        self.assertIn("none satisfy", text)
        self.assertIn("NOT scanned", text)

    def test_scan_stats_carry_readiness_counts(self):
        self.db.bulk_upsert_instruments([inst(1), inst(2)])
        universe = self.se.scan_universe({"timeframe": "5m"})
        _matched, stats = self.se._scan_with_stats(universe, {"timeframe": "5m", "entry": {"op": "AND", "conditions": [
            {"left": "close", "operator": ">", "right": 0}]}}, "5m")
        self.assertEqual((stats["ready"], stats["not_ready"], stats["readiness_pct"]), (0, 2, 0.0))


class CanonicalUniverseTests(Base):
    def test_daily_prep_warms_the_same_stocks_the_scanner_scans(self):
        # 3,000 EQ stocks plus 400 BE/SM stocks whose symbols sort BEFORE them: the old alphabetical-first-3000 mix
        # (all series) would have warmed the wrong ones.
        rows = [inst(i, symbol=f"ZZ{i:05d}-EQ") for i in range(1, 3001)] + [inst(5000 + i, symbol=f"AA{i:04d}-BE") for i in range(400)]
        self.db.bulk_upsert_instruments(rows)
        sdef = {"timeframe": "5m", "entry": {"op": "AND", "conditions": []}}
        scanner = {"id": 1, "is_active": 1, "definition": sdef}
        version = {"id": 7, "definition": {"timeframe": "5m", "scanner_ids": [1]}}
        with mock.patch.object(self.db, "list_scanners", return_value=[scanner]), \
             mock.patch.object(self.db, "list_live_armed_strategy_versions", return_value=[version]):
            jobs = self.dp._warmup_jobs()
        self.assertEqual(len(jobs), 1)
        warmed = [i["instrument_token"] for i in jobs[0][1]]
        scanned = [i["instrument_token"] for i in self.se.scan_universe(sdef)]
        self.assertEqual(warmed, scanned)
        self.assertTrue(all(not i["trading_symbol"].endswith("-BE") for i in jobs[0][1]))
        self.assertEqual(len(warmed), 2800)


class PriorityTests(Base):
    def test_open_positions_and_candidates_first_then_busiest_then_token_order(self):
        self.db.bulk_upsert_instruments([inst(i) for i in range(1, 7)])
        for token, volume in (("3", 5000), ("5", 100)):
            self.db.record_market_tick(instrument_token=token, exchange_segment="nse_cm", last_traded_price=10.0, volume=volume)
        with mock.patch.object(self.db, "priority_instrument_keys", return_value={("nse_cm", "6")}):
            ordered = self.se.prioritize_targets([inst(i) | {"exchange_segment": "nse_cm"} for i in range(1, 7)])
        self.assertEqual([t["instrument_token"] for t in ordered], ["6", "3", "5", "1", "2", "4"])

    def test_priority_keys_include_open_positions_and_active_candidates_only(self):
        import sqlite3
        conn = sqlite3.connect(self.db.DB_PATH)                      # foreign keys are off on a raw connection
        pos = "INSERT INTO algo_positions(exchange_segment,instrument_token,trading_symbol,status) VALUES('nse_cm',?,?, ?)"
        cand = ("INSERT INTO strategy_candidates(strategy_version_id,scanner_id,exchange_segment,instrument_token,timeframe,"
                "conditions_json,status,expires_at) VALUES(1,1,'nse_cm',?,'5m','{}',?,?)")
        conn.execute(pos, ("11", "A", "OPEN"))
        conn.execute(pos, ("12", "B", "CLOSED"))
        conn.execute(cand, ("13", "ACTIVE", "2999-01-01 00:00:00"))
        conn.execute(cand, ("14", "ACTIVE", "2000-01-01 00:00:00"))      # expired by time
        conn.execute(cand, ("15", "EXPIRED", None))                       # expired by status
        conn.execute(cand, ("16", "ACTIVE", None))                        # no expiry: still active
        conn.commit(); conn.close()
        self.assertEqual(self.db.priority_instrument_keys(), {("nse_cm", "11"), ("nse_cm", "13"), ("nse_cm", "16")})

    def test_volume_rank_map_reads_the_last_known_volume(self):
        self.db.record_market_tick(instrument_token="7", exchange_segment="nse_cm", last_traded_price=1.0, volume=1234)
        self.assertEqual(self.db.volume_rank_map(), {("nse_cm", "7"): 1234})


class WarmupTargetsOnceTests(Base):
    def test_a_precomputed_target_list_skips_the_database_scan(self):
        targets = [inst(i) | {"exchange_segment": "nse_cm"} for i in range(1, 4)]
        calls = []

        async def fake_fetch(seg, tok, tf, start, end, symbol):
            calls.append(tok)
            return [], {}

        from app import backtest_service
        with mock.patch.object(self.se, "_warmup_targets", side_effect=AssertionError("must not rescan")), \
             mock.patch.object(backtest_service, "_fetch_chunks", side_effect=fake_fetch):
            r = asyncio.run(self.se.warmup_history([], "5m", {"timeframe": "5m"}, targets=targets, max_instruments=2, time_budget=5))
        self.assertEqual((r["tried"], r["remaining"]), (2, 1))
        self.assertEqual(calls, ["1", "2"])

    def test_concurrency_is_configurable_and_clamped(self):
        import os
        for raw, want in (("4", 4), ("99", 6), ("0", 1), ("abc", 2)):
            with mock.patch.dict(os.environ, {"HISTORY_FETCH_CONCURRENCY": raw}):
                self.assertEqual(self.se.history_concurrency(), want)
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("HISTORY_FETCH_CONCURRENCY", None)
            self.assertEqual(self.se.history_concurrency(), 2)


class DailyPrepRetryTests(Base):
    def _run(self, previous=None, sync_result=None):
        from app.state import BrokerState, current_state
        sync = mock.AsyncMock(return_value=sync_result or {"ok": True, "synced": 2947})
        warm = mock.AsyncMock(return_value={"fetched": 0, "remaining": 0, "needed": 0, "tried": 0})
        with mock.patch.object(current_state, "state", BrokerState.CONNECTED), \
             mock.patch("app.daily_prep.universe.sync_nse_cash_metadata", sync), \
             mock.patch.object(self.db, "prune_candles", return_value={"5m": 1}) as prune, \
             mock.patch("app.daily_prep._warmup_jobs", return_value=[]):
            result = asyncio.run(self.dp.run_daily_prep(now=dt.datetime(2026, 10, 14, 3, 15, tzinfo=dt.timezone.utc), previous=previous))
        return result, sync, prune

    def test_scrip_master_count_is_reported(self):
        result, _sync, _prune = self._run()
        self.assertEqual(result["scrip_master"], {"ok": True, "count": 2947, "error": None})

    def test_a_retry_does_not_repeat_a_scrip_sync_or_prune_that_already_worked(self):
        first, _s, _p = self._run()
        second, sync, prune = self._run(previous=first)
        sync.assert_not_awaited()
        prune.assert_not_called()
        self.assertEqual(second["scrip_master"], first["scrip_master"])

    def test_a_failed_scrip_sync_is_retried(self):
        failed, _s, _p = self._run(sync_result={"ok": False, "error": "network"})
        self.assertFalse(failed["scrip_master"]["ok"])
        _again, sync, _prune = self._run(previous=failed)
        sync.assert_awaited_once()

    def test_job_entry_reports_missing_ready_and_coverage_and_uses_the_remaining_the_fetcher_reports(self):
        from app.state import BrokerState, current_state
        self.db.bulk_upsert_instruments([inst(1), inst(2)])
        sdef = {"timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": 0}]}}
        insts = self.se.scan_universe(sdef)
        warm = mock.AsyncMock(return_value={"fetched": 2, "remaining": 0, "tried": 2})
        with mock.patch.object(current_state, "state", BrokerState.CONNECTED), \
             mock.patch("app.daily_prep.universe.sync_nse_cash_metadata", mock.AsyncMock(return_value={"ok": True, "synced": 2})), \
             mock.patch("app.daily_prep._warmup_jobs", return_value=[("scanner#1", insts, "5m", sdef)]), \
             mock.patch("app.daily_prep.scanner_engine.warmup_history", warm):
            result = asyncio.run(self.dp.run_daily_prep(now=dt.datetime(2026, 10, 14, 3, 15, tzinfo=dt.timezone.utc)))
        entry = result["history"][0]
        self.assertEqual((entry["missing_at_start"], entry["ready_at_start"], entry["remaining"], entry["fetched"]), (2, 0, 0, 2))
        self.assertEqual(entry["coverage"]["universe"], 2)
        self.assertTrue(result["complete"])
        self.assertEqual(warm.await_args.kwargs["targets"][0]["instrument_token"] in ("1", "2"), True)


class CandleReadTests(Base):
    OLD_SQL = """
        WITH wanted(exchange_segment,instrument_token) AS (VALUES {values}),
        ranked AS (
          SELECT c.exchange_segment,c.instrument_token,c.candle_at,c.open,c.high,c.low,c.close,COALESCE(c.volume,0) AS volume,
                 ROW_NUMBER() OVER (PARTITION BY c.exchange_segment,c.instrument_token ORDER BY c.candle_at DESC) AS rn
          FROM candles c JOIN wanted w ON w.exchange_segment=c.exchange_segment AND w.instrument_token=c.instrument_token
          WHERE c.timeframe=?)
        SELECT exchange_segment,instrument_token,candle_at,open,high,low,close,volume
        FROM ranked WHERE rn<=? ORDER BY exchange_segment,instrument_token,candle_at ASC"""

    def test_indexed_read_returns_exactly_what_the_window_query_returned(self):
        import random
        rnd = random.Random(7)
        rows = []
        for tok in range(1, 8):
            for tf, bars in (("5m", rnd.randint(0, 60)), ("15m", 5)):
                for k in range(bars):
                    at = (dt.datetime(2026, 10, 1, 9, 15) + dt.timedelta(minutes=5 * k)).strftime("%Y-%m-%d %H:%M:%S")
                    rows.append({"exchange_segment": "nse_cm", "instrument_token": str(tok), "trading_symbol": f"S{tok}-EQ", "timeframe": tf,
                                 "candle_at": at, "open": rnd.random() + 1, "high": 3.0, "low": 0.5, "close": rnd.random() + 1,
                                 "volume": rnd.choice([None, 0, 10, 99])})
        self.db.upsert_candles(rows)
        wanted = [{"exchange_segment": "nse_cm", "instrument_token": str(t)} for t in (1, 2, 3, 4, 5, 6, 7, 99, 3)]   # unknown + duplicate
        for limit in (1, 10, 23, 500):
            got = self.db.recent_candles_for_instruments(wanted, "5m", limit)
            uniq = [("nse_cm", str(t)) for t in (1, 2, 3, 4, 5, 6, 7, 99)]
            sql = self.OLD_SQL.format(values=",".join(["(?,?)"] * len(uniq)))
            with self.db._connection() as c:
                old_rows = c.execute(sql, [v for pair in uniq for v in pair] + ["5m", limit]).fetchall()
            expected = {}
            for r in old_rows:
                expected.setdefault((r[0], str(r[1])), []).append(dict(zip(("candle_at", "open", "high", "low", "close", "volume"), r[2:])))
            self.assertEqual(got, expected, f"limit={limit}")
        self.assertEqual(self.db.recent_candles_for_instruments([], "5m", 5), {})


class WarmupTargetsSemanticsTests(Base):
    def _bars(self, token, count, end="2026-10-14 09:55:00"):
        end_dt = dt.datetime.strptime(end, "%Y-%m-%d %H:%M:%S")
        return [{"exchange_segment": "nse_cm", "instrument_token": str(token), "trading_symbol": f"S{token}-EQ", "timeframe": "5m",
                 "candle_at": (end_dt - dt.timedelta(minutes=5 * k)).strftime("%Y-%m-%d %H:%M:%S"),
                 "open": 1, "high": 1, "low": 1, "close": 1, "volume": 1} for k in range(count)]

    def test_only_instruments_that_cannot_be_judged_are_targets(self):
        rows = (self._bars(1, 25)                                   # enough fresh completed bars        -> ready
                + self._bars(2, 5)                                  # too few bars                       -> target
                + self._bars(3, 25, end="2026-10-14 09:15:00")      # enough bars but the last is stale  -> target
                + self._bars(4, 25) + self._bars(4, 1, end="2026-10-14 10:00:00"))   # + one unfinished bar -> ready
        self.db.upsert_candles(rows)
        universe = [{"exchange_segment": "nse_cm", "instrument_token": str(t)} for t in (1, 2, 3, 4, 5)]    # 5 has no data at all
        with mock.patch.object(self.se, "_bar_is_complete", side_effect=lambda at, tf, now: db_canon(at) < "2026-10-14 10:00:00"), \
             mock.patch.object(self.se, "_candle_is_fresh", side_effect=lambda at, tf: at >= "2026-10-14 09:30:00"):
            targets = self.se._warmup_targets(universe, "5m", {"timeframe": "5m"}, 20)
        self.assertEqual(sorted(t["instrument_token"] for t in targets), ["2", "3", "5"])

    def test_a_scanner_needing_more_than_250_bars_can_still_be_satisfied(self):
        self.db.upsert_candles(self._bars(1, 300, end="2026-10-14 09:55:00"))
        with mock.patch.object(self.se, "_bar_is_complete", return_value=True), mock.patch.object(self.se, "_candle_is_fresh", return_value=True):
            targets = self.se._warmup_targets([{"exchange_segment": "nse_cm", "instrument_token": "1"}], "5m", {"timeframe": "5m"}, 280)
        self.assertEqual(targets, [])


def db_canon(at):
    return str(at).replace("T", " ")[:19]


if __name__ == "__main__":
    unittest.main()
