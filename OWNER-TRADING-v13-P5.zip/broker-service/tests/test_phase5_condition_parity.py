"""Phase 5: the same condition on the same bar gives the same answer in the scanner, the live strategy and the backtest."""
import datetime as dt
import random
import unittest
from unittest import mock

from app import scanner_engine as se
from app import strategy_engine as eng

IST = dt.timezone(dt.timedelta(hours=5, minutes=30))


def session_bars(days=12, seed=5, start_day=dt.date(2026, 9, 7), minutes=5, base=100.0, drift=0.0):
    """Random-walk bars: `days` trading days (Mon-Fri) of full 09:15-15:30 sessions."""
    rnd = random.Random(seed)
    out, px, d = [], base, start_day
    per_day = 375 // minutes
    while len([x for x in out if x["candle_at"].endswith("09:15:00")]) < days:
        if d.weekday() < 5:
            for k in range(per_day):
                ts = dt.datetime.combine(d, dt.time(9, 15)) + dt.timedelta(minutes=minutes * k)
                o = px
                c = max(1.0, px + rnd.uniform(-1, 1) + drift)
                out.append({"candle_at": ts.strftime("%Y-%m-%d %H:%M:%S"), "open": o, "high": max(o, c) + rnd.uniform(0, 0.5),
                            "low": min(o, c) - rnd.uniform(0, 0.5), "close": c, "volume": rnd.randint(500, 5000)})
                px = c
        d += dt.timedelta(days=1)
    return out


RICH = {"side": "BUY", "timeframe": "5m",
        "entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"},
                                              {"left": "rsi14", "operator": ">", "right": 45}],
                  "groups": [{"op": "OR", "conditions": [{"left": "adx14", "operator": ">", "right": 10},
                                                         {"left": "macd_hist", "operator": ">", "right": -5, "not": False},
                                                         {"left": "close", "operator": ">", "right": "vwap"}]}]},
        "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": "ema20[2]"}]},
        "risk": {"stop_atr_multiple": 1.5}, "position_sizing": {"quantity": 1}}
OPERANDS = ["ema20", "ema50", "ema20[3]", "rsi14", "atr14", "adx14", "macd", "macd_signal", "macd_hist", "vwap", "sma20", "bb_upper"]


class WindowTests(unittest.TestCase):
    def test_operand_windows_are_long_enough_to_converge(self):
        w = eng.operand_window
        self.assertEqual((w("ema", 20), w("ema", 200)), (63, 603))
        self.assertEqual((w("rsi", 14), w("atr", 14), w("adx", 14)), (85, 85, 113))
        self.assertEqual(w("macd"), 150)
        self.assertEqual((w("vwap", None, 5), w("vwap", None, 1), w("vwap", None, 1440)), (76, 376, 2))
        self.assertIsNone(w("sma", 20))

    def test_analysis_window_is_the_longest_operand_plus_margin_and_capped(self):
        d = lambda *ops, tf="5m", **extra: {"timeframe": tf, "entry": {"op": "AND", "conditions": [{"left": o, "operator": ">", "right": 1} for o in ops]}, **extra}
        self.assertEqual(eng.analysis_window(d("close")), 3)
        self.assertEqual(eng.analysis_window(d("ema20")), 65)
        self.assertEqual(eng.analysis_window(d("ema20[3]", "rsi14")), 87)      # rsi14 needs 85 (+2 margin); ema20[3] needs only 63+3
        self.assertEqual(eng.analysis_window(d("ema200")), 600)
        self.assertEqual(eng.analysis_window(d("vwap")), 78)
        self.assertEqual(eng.analysis_window(d("close", risk={"stop_atr_multiple": 2})), 87)    # an ATR stop needs a converged ATR
        self.assertEqual(eng.analysis_window(d("vwap", tf="1d")), 4)

    def test_scanner_required_bars_is_the_analysis_window_with_a_floor(self):
        self.assertEqual(se.required_bars({"timeframe": "5m", "entry": {"conditions": [{"left": "close", "operator": ">", "right": 1}]}}), se.MIN_BARS)
        self.assertEqual(se.required_bars(RICH), eng.analysis_window(RICH))

    def test_a_long_window_may_use_several_broker_chunks_but_stays_bounded(self):
        self.assertLessEqual(se.history_calendar_days("5m", 65), 29)                       # still one chunk
        daily = se.history_calendar_days("1d", 600)
        self.assertGreater(daily, 179)                                                     # more than one 180-day chunk
        self.assertLessEqual(daily, (180 - 1) * se.MAX_HISTORY_CHUNKS)
        self.assertGreater(se.history_calendar_days("1h", 155), 30)

    def test_live_fetch_always_leaves_enough_bars_after_dropping_the_forming_one(self):
        for req in range(se.MIN_BARS, se.MAX_REQUIRED_BARS + 1):
            fetched = min(700, max(250, req + 5))
            self.assertGreaterEqual(fetched - 1, req, req)


class ParityTests(unittest.TestCase):
    """Value at bar t must not depend on how many earlier bars the caller loaded (as long as it loaded the window)."""

    def setUp(self):
        self.cs = session_bars(days=14)            # 1050 bars
        self.w = eng.analysis_window(RICH)

    def values(self, candles):
        r = eng.Resolver(candles, 5)
        return {o: r.value(o) for o in OPERANDS}

    def test_every_operand_is_identical_for_any_supplied_length_at_or_above_the_window(self):
        t = 900
        reference = self.values(self.cs[:t][-self.w:])
        for supplied in (self.w, 160, 250, 300, 600, t):
            got = self.values(self.cs[:t][-supplied:])
            for o in OPERANDS:
                self.assertEqual(got[o], reference[o], f"{o} with {supplied} bars")

    def test_entry_and_exit_decisions_and_their_numbers_do_not_depend_on_how_much_history_was_loaded(self):
        for t in range(300, 1000, 37):
            ref_e = eng.evaluate_entry(RICH, self.cs[:t][-self.w:])
            ref_x = eng.evaluate_exit(RICH, self.cs[:t][-self.w:])
            for supplied in (250, 300, 600, t):
                part = self.cs[:t][-supplied:]
                e = eng.evaluate_entry(RICH, part)
                x = eng.evaluate_exit(RICH, part)
                self.assertEqual((e[0], e[1]["indicators"]), (ref_e[0], ref_e[1]["indicators"]), f"entry t={t} supplied={supplied}")
                self.assertEqual((x[0], x[1]["indicators"]), (ref_x[0], ref_x[1]["indicators"]), f"exit t={t} supplied={supplied}")

    def test_a_condition_gives_the_same_value_whatever_else_the_definition_contains(self):
        t = 800
        only = {"timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": ">", "right": 0}]}}
        a = eng.evaluate_entry(only, self.cs[:t][-eng.analysis_window(only):])[1]["indicators"]["ema20"]
        b = eng.evaluate_entry(RICH, self.cs[:t][-self.w:])[1]["indicators"]["ema20"]
        self.assertEqual(a, b)

    def test_an_offset_operand_equals_the_operand_one_evaluation_earlier(self):
        t = 700
        self.assertEqual(eng.Resolver(self.cs[:t], 5).value("ema20[3]"), eng.Resolver(self.cs[:t - 3], 5).value("ema20"))
        self.assertEqual(eng.Resolver(self.cs[:t], 5).value("rsi14[1]"), eng.Resolver(self.cs[:t - 1], 5).value("rsi14"))

    def test_risk_atr_matches_the_atr_operand_and_ignores_the_supplied_length(self):
        t = 800
        a = eng.risk_atr(RICH, self.cs[:t])
        self.assertEqual(a, eng.risk_atr(RICH, self.cs[:t][-300:]))
        self.assertEqual(a, eng.Resolver(self.cs[:t], 5).value("atr14"))

    def test_scanner_path_gives_the_same_matches_as_the_condition_engine_on_the_same_bars(self):
        definition = {"timeframe": "5m", "entry": RICH["entry"], "exit": RICH["exit"], "risk": RICH["risk"]}
        inst = {"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "AAA-EQ"}
        end_of_data = dt.datetime.strptime(self.cs[-1]["candle_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=se.IST) + dt.timedelta(minutes=10)
        seen_true = 0
        for t in range(400, 1040, 13):
            part = self.cs[:t]
            now = dt.datetime.strptime(part[-1]["candle_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=se.IST) + dt.timedelta(minutes=5, seconds=3)
            expected = eng.evaluate_entry(definition, part)[0]
            with mock.patch.object(se.db, "recent_candles_for_instruments", return_value={("nse_cm", "1"): part[-(se.required_bars(definition) + 3):]}), \
                 mock.patch.object(se, "_candle_is_fresh", return_value=True), \
                 mock.patch.object(se, "dt", mock.MagicMock(datetime=type("D", (dt.datetime,), {"now": classmethod(lambda cls, tz=None, n=now: n.astimezone(tz) if tz else n)}),
                                                            timedelta=dt.timedelta, timezone=dt.timezone, date=dt.date, time=dt.time)):
                matched, stats = se._scan_with_stats([inst], definition, "5m")
            self.assertEqual(bool(matched), expected, f"t={t}")
            seen_true += expected
        self.assertGreater(seen_true, 0, "the sample must contain at least one match or the test proves nothing")
        self.assertLess(seen_true, 49)

    def test_backtest_enters_on_exactly_the_bar_the_condition_engine_says(self):
        definition = {"side": "BUY", "timeframe": "5m",
                      "entry": {"op": "AND", "conditions": [{"left": "ema20", "operator": "cross_above", "right": "ema50"},
                                                            {"left": "rsi14", "operator": ">", "right": 40}]},
                      "exit": {"op": "OR", "conditions": [{"left": "close", "operator": "<", "right": "ema20"}]},
                      "risk": {}, "position_sizing": {"quantity": 1}}
        cs = session_bars(days=14, seed=11)
        result = eng.run_backtest(cs, definition, "AAA", quantity=1)
        trades = result["trades"] if isinstance(result, dict) else result
        self.assertGreaterEqual(len(trades), 2, "sample must contain trades")
        # replay: whenever flat, the engine would enter on the bar AFTER the first bar whose full-history prefix passes
        by_time = {c["candle_at"]: i for i, c in enumerate(cs)}
        for tr in trades:
            i = by_time[tr["entry_time"] if "entry_time" in tr else tr["time"]]
            self.assertTrue(eng.evaluate_entry(definition, cs[:i])[0], f"entry at {cs[i]['candle_at']} is not supported by the full prefix")


class AccuracyTests(unittest.TestCase):
    def test_the_canonical_window_is_converged_and_the_old_scanner_window_was_not(self):
        cs = session_bars(days=14, seed=3)
        t = 900
        full = eng.Resolver(cs[:t], 5)
        canon = eng.Resolver(cs[:t], 5)               # trims to the operand windows itself
        old = lambda name, bars: eng.Resolver(cs[t - bars:t], 5).value(name)    # what the scanner used to feed (~need+3 bars)
        closes = [c["close"] for c in cs[:t]]
        full_ema = eng.ema(closes, 20)
        full_rsi = eng.rsi(closes, 14)
        self.assertLess(abs(canon.value("ema20") - full_ema), 0.003 * full_ema)
        self.assertLess(abs(canon.value("rsi14") - full_rsi), 0.5)
        err_new_ema, err_old_ema = abs(canon.value("ema20") - full_ema), abs(old("ema20", 25) - full_ema)
        err_new_rsi, err_old_rsi = abs(canon.value("rsi14") - full_rsi), abs(old("rsi14", 20) - full_rsi)
        self.assertLess(err_new_ema, err_old_ema)
        self.assertLess(err_new_rsi, err_old_rsi)

    def test_vwap_sees_the_whole_session_not_just_the_last_few_bars(self):
        cs = session_bars(days=3, seed=9)
        day = cs[-1]["candle_at"][:10]
        today = [c for c in cs if c["candle_at"][:10] == day]
        t = len(cs) - 20                                           # mid-afternoon bar
        part = cs[:t]
        today_part = [c for c in part if c["candle_at"][:10] == part[-1]["candle_at"][:10]]
        manual = sum((c["high"] + c["low"] + c["close"]) / 3 * c["volume"] for c in today_part) / sum(c["volume"] for c in today_part)
        self.assertAlmostEqual(eng.Resolver(part, 5).value("vwap"), manual)
        self.assertNotAlmostEqual(eng.Resolver(part[-25:], 5).value("vwap"), manual, places=3)    # the old 22-25 bar window was wrong
        self.assertGreater(len(today), 70)


class MacdRegressionTests(unittest.TestCase):
    """v12 raised ValueError for ANY condition using macd / macd_signal / macd_hist (Resolver.snapshot unpacked an internal
    two-part cache key as an operand): the scanner and the live strategy could not use MACD at all."""

    def test_macd_conditions_evaluate_and_report_their_values(self):
        cs = session_bars(days=6, seed=2)
        d = {"timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "macd", "operator": ">", "right": "macd_signal"},
                                                                      {"left": "macd_hist", "operator": ">", "right": -100}]}}
        passed, detail = eng.evaluate_entry(d, cs)
        ind = detail["indicators"]
        self.assertTrue(all(k in ind for k in ("macd", "macd_signal", "macd_hist")))
        self.assertAlmostEqual(ind["macd_hist"], ind["macd"] - ind["macd_signal"])
        self.assertEqual(passed, ind["macd"] > ind["macd_signal"])

    def test_the_scanner_can_scan_with_macd(self):
        cs = session_bars(days=6, seed=2)
        inst = {"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "AAA-EQ"}
        d = {"timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "macd_hist", "operator": ">", "right": -100}]}}
        now = dt.datetime.strptime(cs[-1]["candle_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=se.IST) + dt.timedelta(minutes=5, seconds=3)
        fake_dt = mock.MagicMock(datetime=type("D", (dt.datetime,), {"now": classmethod(lambda cls, tz=None: now.astimezone(tz) if tz else now)}),
                                 timedelta=dt.timedelta, timezone=dt.timezone, date=dt.date, time=dt.time)
        with mock.patch.object(se.db, "recent_candles_for_instruments", return_value={("nse_cm", "1"): cs[-(se.required_bars(d) + 3):]}), \
             mock.patch.object(se, "_candle_is_fresh", return_value=True), mock.patch.object(se, "dt", fake_dt):
            matched, stats = se._scan_with_stats([inst], d, "5m")
        self.assertEqual((len(matched), stats["evaluated"], stats["insufficient_history"]), (1, 1, 0))


if __name__ == "__main__":
    unittest.main()


class ExitPathTests(unittest.TestCase):
    def test_the_strategy_exit_loads_the_same_window_the_entry_uses(self):
        from app import exit_engine
        ema200 = {"timeframe": "5m", "entry": {"conditions": [{"left": "close", "operator": ">", "right": "ema200"}]},
                  "exit": {"conditions": [{"left": "close", "operator": "<", "right": "ema200"}]}}
        simple = {"timeframe": "5m", "exit": {"conditions": [{"left": "close", "operator": "<", "right": "sma20"}]}}
        self.assertEqual(exit_engine.exit_candle_limit(ema200), 605)        # 600-bar window + 5 (it used to load 250: a different ema200)
        self.assertEqual(exit_engine.exit_candle_limit(simple), 250)
        for req in range(se.MIN_BARS, se.MAX_REQUIRED_BARS + 1):
            d = {"timeframe": "5m", "entry": {"conditions": [{"left": f"sma{min(req - 2, 400)}", "operator": ">", "right": 1}]}}
            self.assertGreaterEqual(exit_engine.exit_candle_limit(d), min(se.required_bars(d), 700))
