"""Phase 6: a synthetic large universe goes through the whole scan chain correctly and within generous time bounds.
(The bounds are deliberately loose so a slow CI machine does not flake; tools/load_test_scanner.py prints the real figures.)"""
import asyncio
import importlib.util
import os
import unittest

TOOL = os.path.join(os.path.dirname(__file__), "..", "tools", "load_test_scanner.py")


def load_tool():
    spec = importlib.util.spec_from_file_location("load_test_scanner", TOOL)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class LoadTests(unittest.TestCase):
    def tearDown(self):
        from app.tick_writer import tick_writer
        tick_writer.stop()

    def test_a_600_stock_universe_is_scanned_closed_and_written_correctly(self):
        tool = load_tool()
        r = tool.run(stocks=600, bars=160)
        self.assertEqual(r["required_bars"], 155)
        self.assertEqual((r["scan"]["universe"], r["scan"]["ready"], r["scan"]["not_ready"], r["scan_status"]), (600, 600, 0, "COMPLETE"))
        self.assertEqual(r["stocks_missing_history"], 0)
        self.assertEqual((r["coverage"]["eligible_total"], r["coverage"]["truncated"]), (600, 0))
        self.assertEqual(r["bars_closed"], 600)                                    # every stock's bar closes by the clock
        self.assertLess(r["full_scan_s"], 15)
        self.assertLess(r["missing_check_s"], 10)
        self.assertLess(r["tick_path_us_per_tick"], 2000)                          # the tick path stays far below a millisecond
        self.assertLess(r["bar_close_loop_thread_ms"], 1000)

    def test_a_universe_with_missing_history_is_reported_not_hidden(self):
        tool = load_tool()
        db, _path = tool.make_db(200, 160)
        db.bulk_upsert_instruments([{"trading_symbol": f"NEW{i}-EQ", "instrument_token": str(50000 + i), "lot_size": 1, "tick_size": 0.05} for i in range(100)])
        from app import scanner_engine as se
        universe = se.scan_universe(tool.RICH)
        _matched, stats = se._scan_with_stats(universe, tool.RICH, "5m")
        self.assertEqual((stats["universe"], stats["ready"], stats["no_candles"], se.classify_scan_status(stats)), (300, 200, 100, "PARTIAL"))
        self.assertEqual(len(se._warmup_targets(universe, "5m", tool.RICH, se.required_bars(tool.RICH))), 100)

    def test_the_feed_manager_at_the_real_3000_limit(self):
        tool = load_tool()
        out = asyncio.run(tool.feed_manager_run(2800))
        self.assertEqual((out["evicted_for_positions"], out["feed_total_after"], out["positions_rejected"]), (70, 3000, 0))
        self.assertLess(out["120_positions_on_a_full_feed_ms"], 2000)


if __name__ == "__main__":
    unittest.main()
