"""P4: read-only data for the Live Auto screen (next candle close, strategies, last scan, signals, chart)."""
import asyncio
import datetime as dt
import os
import sqlite3
import unittest
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")


def at(y, m, d, h, mi, s=0):
    return dt.datetime(y, m, d, h, mi, s, tzinfo=IST)


class NextBarCloseTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        from app import live_status
        fresh_db()
        self.ls = live_status

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_intraday_boundaries(self):
        n = self.ls.next_bar_close
        self.assertEqual(n("5m", at(2026, 10, 27, 10, 2)), at(2026, 10, 27, 10, 5))
        self.assertEqual(n("5m", at(2026, 10, 27, 10, 5)), at(2026, 10, 27, 10, 10))      # exactly on the close -> the next one
        self.assertEqual(n("5m", at(2026, 10, 27, 15, 27)), at(2026, 10, 27, 15, 30))     # last bar closes with the session
        self.assertEqual(n("15m", at(2026, 10, 27, 10, 2)), at(2026, 10, 27, 10, 15))
        self.assertEqual(n("5m", at(2026, 10, 27, 8, 0)), at(2026, 10, 27, 9, 20))        # before open: first bar closes 09:20

    def test_after_close_and_weekend_roll_forward(self):
        n = self.ls.next_bar_close
        self.assertEqual(n("5m", at(2026, 10, 27, 16, 0)), at(2026, 10, 28, 9, 20))
        self.assertEqual(n("5m", at(2026, 10, 30, 16, 0)), at(2026, 11, 2, 9, 20))        # Friday evening -> Monday
        self.assertEqual(n("5m", at(2026, 10, 31, 11, 0)), at(2026, 11, 2, 9, 20))        # Saturday -> Monday

    def test_daily_and_unknown_timeframe(self):
        self.assertEqual(self.ls.next_bar_close("1d", at(2026, 10, 27, 10, 0)), at(2026, 10, 27, 15, 45))
        self.assertEqual(self.ls.next_bar_close("1d", at(2026, 10, 27, 16, 0)), at(2026, 10, 28, 15, 45))
        self.assertIsNone(self.ls.next_bar_close("7m", at(2026, 10, 27, 10, 0)))


class LiveStatusAndChartTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        from app import live_status, db
        self.db = fresh_db()
        self.ls = live_status
        self.path = os.environ["DB_PATH"]
        s = db.create_strategy("EMA test")
        self.sid = s["id"]
        d = {"timeframe": "5m", "side": "BUY",
             "entry": {"op": "AND", "conditions": [{"left": "ema9", "operator": "cross_above", "right": "ema21"}]},
             "exit": {"op": "AND", "conditions": [{"left": "close", "operator": "<", "right": "ema21"}]}}
        self.vid = db.save_strategy_version(self.sid, d)["id"]
        c = sqlite3.connect(self.path)
        t = dt.datetime(2026, 10, 27, 9, 15)
        price = 100.0
        for i in range(80):
            price += 0.4 if i > 40 else -0.2
            c.execute("INSERT INTO candles(exchange_segment,instrument_token,timeframe,candle_at,open,high,low,close,volume,source) VALUES('nse_cm','500325','5m',?,?,?,?,?,?,'t')",
                      (t.strftime("%Y-%m-%d %H:%M:%S"), price - .1, price + .3, price - .3, price, 1000 + i))
            t += dt.timedelta(minutes=5)
            if t.hour == 15 and t.minute > 25:
                t = (t + dt.timedelta(days=1)).replace(hour=9, minute=15)
        c.commit()
        c.close()
        self.last_at = self._q("SELECT candle_at FROM candles ORDER BY candle_at DESC LIMIT 1")[0][0]

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def _q(self, sql, args=()):
        c = sqlite3.connect(self.path)
        try:
            return c.execute(sql, args).fetchall()
        finally:
            c.close()

    def test_strategy_row_and_last_scan(self):
        self.db.record_scan_run(strategy_version_id=self.vid, timeframe="5m", bar_at="2026-10-27 10:00:00", duration_ms=800,
                                universe=2812, evaluated=2800, matched=3, stats={"readiness_pct": 99.5})
        self.db.record_signal(strategy_version_id=self.vid, exchange_segment="nse_cm", instrument_token="500325",
                              trading_symbol="RELIANCE", timeframe="5m", side="BUY", signal_price=2642.5, candle_at=self.last_at)
        out = self.ls.live_status(at(2026, 10, 27, 10, 2).astimezone(dt.timezone.utc))
        self.assertEqual(out["armed_count"], 0)
        row = out["strategies"][0]
        self.assertEqual((row["name"], row["version_id"], row["armed"], row["timeframe"], row["side"]), ("EMA test", self.vid, False, "5m", "BUY"))
        self.assertEqual(row["next_close_in_s"], 180)
        self.assertIn("ema9 cross_above ema21", row["entry_summary"])
        self.assertEqual(row["last_scan"]["matched"], 3)
        self.assertEqual(row["last_scan"]["readiness_pct"], 99.5)
        self.assertEqual(out["signals"][0]["symbol"], "RELIANCE")
        self.assertEqual(out["server_now_ist"], "2026-10-27 10:02:00")

    def test_chart_candles_lines_and_markers(self):
        self.db.record_signal(strategy_version_id=self.vid, exchange_segment="nse_cm", instrument_token="500325",
                              trading_symbol="RELIANCE", timeframe="5m", side="BUY", signal_price=120, candle_at=self.last_at)
        out = self.ls.chart_data("nse_cm", "500325", "5m", 50, self.vid)
        self.assertEqual(len(out["candles"]), 50)
        self.assertEqual(set(out["lines"]), {"ema9", "ema21"})
        for name, vals in out["lines"].items():
            self.assertEqual(len(vals), 50)
            self.assertIsNotNone(vals[-1])
        self.assertLess(out["lines"]["ema9"][-1], out["candles"][-1]["c"])   # rising market: price above the fast EMA lag
        self.assertEqual(out["markers"][0]["candle_at"], self.last_at)
        self.assertEqual(out["candles"][-1]["t"], self.last_at)

    def test_chart_without_strategy_has_no_lines_and_limits_are_clamped(self):
        out = self.ls.chart_data("nse_cm", "500325", "5m", 9999)
        self.assertEqual(out["lines"], {})
        self.assertEqual(len(out["candles"]), 80)            # only 80 exist; request was clamped to the 300 max
        self.assertEqual(self.ls.chart_data("nse_cm", "000", "5m", 50)["candles"], [])
        with self.assertRaises(ValueError):
            self.ls.chart_data("nse_cm", "500325", "7m", 50)

    def test_handlers_accept_the_real_list_shaped_query(self):
        """Regression: the server passes parse_qs() lists, e.g. {'token': ['500325']}; plain text also works."""
        from app import server
        run = asyncio.run
        for q in ({"token": ["500325"], "timeframe": ["5m"], "limit": ["50"], "version_id": [str(self.vid)]},
                  {"token": "500325", "timeframe": "5m", "limit": "50", "version_id": str(self.vid)}):
            status, body = run(server.h_algo_chart(q, {}))
            self.assertEqual(status, 200, body)
            self.assertEqual(len(body["candles"]), 50)
            self.assertEqual(set(body["lines"]), {"ema9", "ema21"})
        self.assertEqual(run(server.h_algo_chart({"token": [""]}, {}))[0], 400)
        self.assertEqual(run(server.h_algo_chart({"token": ["5"], "limit": ["x"]}, {}))[0], 400)
        self.assertEqual(run(server.h_algo_chart({"token": ["5"], "segment": ["zzz"]}, {}))[0], 400)
        status, body = run(server.h_algo_candidates({"version_id": [str(self.vid)], "limit": ["10"]}, {}))
        self.assertEqual(status, 200, body)

    def test_chart_through_the_real_dispatcher(self):
        import json
        from urllib.parse import parse_qs
        from app import server
        orig = server._token_ok
        server._token_ok = lambda headers: True
        try:
            raw = asyncio.run(server.dispatch("GET", "/algo/chart", parse_qs(f"token=500325&limit=40&version_id={self.vid}"), {}))
        finally:
            server._token_ok = orig
        head, _, payload = raw.partition(b"\r\n\r\n")
        self.assertTrue(head.startswith(b"HTTP/1.1 200"), head)
        self.assertEqual(len(json.loads(payload)["candles"]), 40)

    def test_read_only(self):
        before = self._q("SELECT (SELECT COUNT(*) FROM signals),(SELECT COUNT(*) FROM candles),(SELECT COUNT(*) FROM scan_runs)")
        self.ls.live_status()
        self.ls.chart_data("nse_cm", "500325", "5m", 50, self.vid)
        self.assertEqual(before, self._q("SELECT (SELECT COUNT(*) FROM signals),(SELECT COUNT(*) FROM candles),(SELECT COUNT(*) FROM scan_runs)"))


if __name__ == "__main__":
    unittest.main()
