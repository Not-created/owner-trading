"""Phase 4: scan status, durable retry per (strategy version, scanner, bar), per-scanner failure isolation, feed budget."""
import asyncio
import datetime as dt
import unittest
from unittest import mock
from unittest.mock import AsyncMock, patch

from app import scanner_engine as se
from tests.dbutil import fresh_db
from tests.test_v12_scanner_plan import SCANNER, at, mk_candles

UTC = dt.timezone.utc
KEY = "2026-10-08 10:05:00"


class ClassifyTests(unittest.TestCase):
    def test_status_thresholds(self):
        self.assertEqual(se.classify_scan_status({"universe": 100, "ready": 100}), "COMPLETE")
        self.assertEqual(se.classify_scan_status({"universe": 100, "ready": 95}), "COMPLETE")
        self.assertEqual(se.classify_scan_status({"universe": 100, "ready": 94}), "PARTIAL")
        self.assertEqual(se.classify_scan_status({"universe": 100, "ready": 1}), "PARTIAL")
        self.assertEqual(se.classify_scan_status({"universe": 100, "ready": 0}), "WAITING_FOR_DATA")
        self.assertEqual(se.classify_scan_status({"universe": 0, "ready": 0}), "WAITING_FOR_DATA")
        self.assertEqual(se.classify_scan_status({"universe": 10, "evaluated": 4, "filtered_out": 6}), "COMPLETE")   # older stats shape


class DueLogicTests(unittest.TestCase):
    def setUp(self):
        self.db = fresh_db()
        se._LAST_RUN.clear()

    def run_(self, status, ready=0, error=None):
        self.db.record_scan_run(scanner_id=1, strategy_version_id=7, timeframe="5m", bar_at=KEY, status=status, error=error,
                                universe=100, stats={"ready": ready, "status": status})

    def started(self):
        return se._parse_utc(self.db.scan_attempts(7, 1, KEY)[0]["started_at"])

    def test_first_attempt_is_due_and_complete_is_never_repeated(self):
        self.assertEqual(se.scan_due(7, 1, KEY), (True, "first"))
        self.run_("COMPLETE", 100)
        self.assertEqual(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(hours=1)), (False, "settled"))

    def test_runs_written_before_v13_as_OK_count_as_done(self):
        self.run_("OK", 100)
        self.assertFalse(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(hours=1))[0])

    def test_failed_scan_is_retried_after_backoff_up_to_the_limit(self):
        self.run_("FAILED", error="boom")
        t0 = self.started()
        self.assertEqual(se.scan_due(7, 1, KEY, t0 + dt.timedelta(seconds=10)), (False, "backing off"))
        self.assertEqual(se.scan_due(7, 1, KEY, t0 + dt.timedelta(seconds=31)), (True, "retry 1"))
        for _ in range(se.SCAN_MAX_RETRIES):                        # three more failures: the fourth attempt exists
            self.run_("FAILED", error="boom")
        self.assertEqual(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(hours=1)), (False, "retries exhausted"))

    def test_waiting_for_data_is_retried(self):
        self.run_("WAITING_FOR_DATA", 0)
        self.assertTrue(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(seconds=31))[0])

    def test_partial_is_retried_only_while_more_data_becomes_ready(self):
        self.run_("PARTIAL", 50)
        t = self.started()
        self.assertTrue(se.scan_due(7, 1, KEY, t + dt.timedelta(seconds=31))[0])                     # first partial: try once more
        self.run_("PARTIAL", 70)                                                                        # progress
        self.assertTrue(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(seconds=91))[0])
        self.run_("PARTIAL", 70)                                                                        # no progress
        self.assertEqual(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(hours=1)), (False, "no more data became ready"))

    def test_invalid_scanner_is_never_retried(self):
        self.run_("INVALID", error="bad definition")
        self.assertFalse(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(hours=1))[0])

    def test_retry_state_is_durable_across_a_restart(self):
        self.run_("FAILED", error="boom")
        se._LAST_RUN.clear()                                        # a new process has no memory
        self.assertEqual(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(seconds=40)), (True, "retry 1"))
        self.assertFalse(se.scan_due(7, 1, KEY, self.started() + dt.timedelta(seconds=5))[0])      # and still backs off

    def test_state_is_per_strategy_version_and_per_scanner(self):
        self.run_("COMPLETE", 100)
        self.assertEqual(se.scan_due(8, 1, KEY)[0], True)           # another strategy version on the same scanner
        self.assertEqual(se.scan_due(7, 2, KEY)[0], True)           # same version, another scanner
        self.assertEqual(se.scan_due(7, 1, "2026-10-08 10:10:00")[0], True)    # next bar


class DueCyclesRetryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        se._LAST_RUN.clear()
        sc = self.db.create_scanner("m", dict(SCANNER))
        self.db.set_scanner_active(sc["id"], True)
        st = self.db.create_strategy("s")
        d = dict(SCANNER, scanner_ids=[sc["id"]], exit={"op": "OR", "conditions": [{"left": "rsi14", "operator": "<", "right": 1}]},
                 position_sizing={"quantity": 1}, risk={"stop_loss_pct": 1}, universe={"instrument_tokens": []}, max_positions=1)
        v = self.db.save_strategy_version(st["id"], d)
        self.db.set_strategy_armed(v["id"], True)
        self.sid, self.vid = sc["id"], v["id"]

    async def test_a_failed_bar_is_retried_with_backoff_and_then_given_up(self):
        calls = []

        async def fake(**kw):
            calls.append(kw)
            return {"scanners": 1, "matched": 0, "pairs": {(self.vid, self.sid): {"status": "FAILED", "ready": 0}}}

        with patch.object(se, "run_continuous_cycle", fake), patch.object(se, "ensure_scanner_market_universe", AsyncMock(return_value={})):
            r1 = await se.run_due_cycles(at(10, 5, 4))
            r2 = await se.run_due_cycles(at(10, 5, 14))            # 10 s later: backing off
            r3 = await se.run_due_cycles(at(10, 5, 40))            # 36 s later: retry 1
            r4 = await se.run_due_cycles(at(10, 7, 20))            # retry 2 (>90 s after retry 1)
            r5 = await se.run_due_cycles(at(10, 9, 0))             # retry 3 needs 180 s: not yet, and the next bar supersedes it
            r6 = await se.run_due_cycles(at(10, 10, 4))            # the 10:10 bar starts with a fresh first attempt
        self.assertEqual(r1["due_reason"], {f"{self.vid}:{self.sid}": "first"})
        self.assertIsNone(r2)
        self.assertEqual(r3["due_reason"], {f"{self.vid}:{self.sid}": "retry 1"})
        self.assertEqual(r4["due_reason"], {f"{self.vid}:{self.sid}": "retry 2"})
        self.assertIsNone(r5)
        self.assertEqual(r6["due"], {self.sid: "2026-10-08 10:10:00"})
        self.assertEqual(r6["due_reason"], {f"{self.vid}:{self.sid}": "first"})
        self.assertEqual(len(calls), 4)
        self.assertEqual(calls[0]["only_pairs"], {(self.vid, self.sid)})

    async def test_a_new_bar_starts_fresh_even_after_a_failed_one(self):
        async def fake(**kw):
            return {"scanners": 1, "matched": 0, "pairs": {(self.vid, self.sid): {"status": "FAILED", "ready": 0}}}
        with patch.object(se, "run_continuous_cycle", fake), patch.object(se, "ensure_scanner_market_universe", AsyncMock(return_value={})):
            await se.run_due_cycles(at(10, 5, 4))
            r = await se.run_due_cycles(at(10, 10, 4))
        self.assertEqual(r["due"], {self.sid: "2026-10-08 10:10:00"})
        self.assertEqual(r["due_reason"], {f"{self.vid}:{self.sid}": "first"})


class RealPassTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fresh_db()
        se._LAST_RUN.clear()
        sc = self.db.create_scanner("m", dict(SCANNER))
        self.db.set_scanner_active(sc["id"], True)
        st = self.db.create_strategy("s")
        d = dict(SCANNER, scanner_ids=[sc["id"]], exit={"op": "OR", "conditions": [{"left": "rsi14", "operator": "<", "right": 1}]},
                 position_sizing={"quantity": 1}, risk={"stop_loss_pct": 1}, universe={"instrument_tokens": []}, max_positions=1)
        v = self.db.save_strategy_version(st["id"], d)
        self.db.set_strategy_armed(v["id"], True)
        self.sid, self.vid = sc["id"], v["id"]
        self.db.bulk_upsert_instruments([{"trading_symbol": "AAA-EQ", "instrument_token": "11", "lot_size": 1, "tick_size": 0.05},
                                         {"trading_symbol": "BBB-EQ", "instrument_token": "12", "lot_size": 1, "tick_size": 0.05}])
        self.db.upsert_candles(mk_candles(11, volume=5000))                 # only one of the two stocks has history

    def patches(self):
        wm = se.websocket_manager
        return [patch.object(se, "start_warmup_job", lambda *a, **k: None),
                patch.object(wm, "ensure_owner_subscriptions", AsyncMock(return_value={"added": 1, "total": 1})),
                patch.object(wm, "subscribe", AsyncMock()), patch.object(wm, "release_owner", AsyncMock(return_value=0)),
                patch.object(wm, "remove_if_unneeded", AsyncMock(return_value=0)), patch.object(wm, "non_scanner_used", lambda: 0),
                patch("app.algo_engine.algo_engine.on_tick", AsyncMock())]

    async def run_cycle(self):
        ps = self.patches()
        for p in ps:
            p.start()
        try:
            return await se.run_continuous_cycle(only_scanner_ids={self.sid}, only_pairs={(self.vid, self.sid)}, bar_keys={self.sid: KEY})
        finally:
            for p in ps:
                p.stop()

    async def test_half_the_universe_ready_is_recorded_as_partial_with_the_attempt_number(self):
        r = await self.run_cycle()
        run = self.db.list_scan_runs(1)[0]
        self.assertEqual((run["status"], run["stats"]["attempt"], run["stats"]["ready"], run["stats"]["readiness_pct"]), ("PARTIAL", 1, 1, 50.0))
        self.assertEqual(r["pairs"][(self.vid, self.sid)]["status"], "PARTIAL")
        await self.run_cycle()
        self.assertEqual(self.db.list_scan_runs(1)[0]["stats"]["attempt"], 2)
        self.assertEqual(len(self.db.scan_attempts(self.vid, self.sid, KEY)), 2)

    async def test_once_the_missing_history_arrives_the_next_attempt_is_complete(self):
        await self.run_cycle()
        self.db.upsert_candles(mk_candles(12, volume=5000))
        await self.run_cycle()
        self.assertEqual(self.db.list_scan_runs(1)[0]["status"], "COMPLETE")

    async def test_one_failing_scanner_leaves_a_failed_record_and_does_not_raise(self):
        ps = self.patches()
        for p in ps:
            p.start()
        try:
            with patch.object(se, "run_for_strategy", AsyncMock(side_effect=RuntimeError("database is locked"))):
                r = await se.run_continuous_cycle(only_scanner_ids={self.sid}, only_pairs={(self.vid, self.sid)}, bar_keys={self.sid: KEY})
        finally:
            for p in ps:
                p.stop()
        run = self.db.list_scan_runs(1)[0]
        self.assertEqual((run["status"], run["bar_at"]), ("FAILED", KEY))
        self.assertIn("database is locked", run["error"])
        self.assertEqual(r["pairs"][(self.vid, self.sid)]["status"], "FAILED")
        self.assertEqual(se.scan_due(self.vid, self.sid, KEY, dt.datetime.now(UTC) + dt.timedelta(seconds=40)), (True, "retry 1"))


class FeedBudgetTests(unittest.IsolatedAsyncioTestCase):
    async def test_the_scanner_gets_what_is_left_and_the_busiest_stocks_keep_their_slot(self):
        db = fresh_db()
        from app import sdk_adapter, websocket_manager as wm_mod        # no reload: keep the process-wide singleton intact
        db.bulk_upsert_instruments([{"trading_symbol": f"S{i}-EQ", "instrument_token": str(i), "lot_size": 1, "tick_size": 0.05} for i in range(1, 201)])
        for tok in ("150", "7", "99"):
            db.record_market_tick(instrument_token=tok, exchange_segment="nse_cm", last_traded_price=1.0, volume={"150": 9_000_000, "7": 8_000_000, "99": 7_000_000}[tok])
        wm = wm_mod.WebSocketManager()
        wm._max_subscriptions = 100
        with patch.object(sdk_adapter, "make_ws_token", lambda s, t: (s, t)), patch.object(se, "websocket_manager", wm), \
             patch.object(se, "SCAN_UNIVERSE_CAP", 200):
            await wm.subscribe_many([("nse_cm", str(9000 + i)) for i in range(30)], owner="position:1")      # 30 slots held by positions
            out = await se.ensure_scanner_market_universe(("EQ",), limit=200)
        # budget = 100 - 30 held - 50 cushion = 20
        self.assertEqual((out["budget"], out["held_by_others"], out["subscribed"], out["budget_cut"], out["rejected"]), (20, 30, 20, 180, 0))
        self.assertIn("180 of 200 scanner stocks have no live-feed slot", out["warning"])
        scanner_keys = {k for k in wm._subs if wm._key_rank(k) == wm.TIER_ORDER.index("scanner_universe")}
        self.assertEqual(len(scanner_keys), 20)
        self.assertTrue({("nse_cm", "150"), ("nse_cm", "7"), ("nse_cm", "99")} <= scanner_keys)            # busiest kept
        self.assertEqual(len(wm._subs), 50)                                                                 # positions untouched, well under the limit

    async def test_no_warning_when_everything_fits(self):
        db = fresh_db()
        from app import sdk_adapter, websocket_manager as wm_mod        # no reload: keep the process-wide singleton intact
        db.bulk_upsert_instruments([{"trading_symbol": f"S{i}-EQ", "instrument_token": str(i), "lot_size": 1, "tick_size": 0.05} for i in range(1, 11)])
        wm = wm_mod.WebSocketManager()
        with patch.object(sdk_adapter, "make_ws_token", lambda s, t: (s, t)), patch.object(se, "websocket_manager", wm):
            out = await se.ensure_scanner_market_universe(("EQ",))
        self.assertEqual((out["subscribed"], out["budget_cut"], out["rejected"], "warning" in out), (10, 0, 0, False))


class HousekeepingTests(unittest.IsolatedAsyncioTestCase):
    async def test_skipped_when_the_broker_is_not_connected(self):
        from app import main
        from app.state import BrokerState, current_state
        with patch.object(current_state, "state", BrokerState.DISCONNECTED):
            self.assertEqual(await main._feed_housekeeping(), {"skipped": True})

    async def test_retries_pending_and_reports_a_position_without_a_feed(self):
        from app import main
        from app.state import BrokerState, current_state
        fake = mock.MagicMock()
        fake.running = True
        fake.retry_pending = AsyncMock(return_value={"retried": 4, "recovered": 4, "still_pending": 0})
        fake.sync_position_owners = AsyncMock(return_value={"errors": ["position:3: feed full"]})
        with patch.object(current_state, "state", BrokerState.CONNECTED), patch("app.websocket_manager.websocket_manager", fake):
            out = await main._feed_housekeeping()
        self.assertEqual(out["retry"]["recovered"], 4)
        self.assertEqual(out["position_errors"], ["position:3: feed full"])


if __name__ == "__main__":
    unittest.main()
