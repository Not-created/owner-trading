"""P1: the Python DB connection must use the same durability level as the
Node side (synchronous=NORMAL) and keep temp data in memory."""
import os
import unittest


class DbPragmaTests(unittest.TestCase):
    def setUp(self):
        from tests.dbutil import fresh_db
        self.db = fresh_db()

    def tearDown(self):
        os.environ.pop("DB_PATH", None)

    def test_connection_pragmas(self):
        with self.db._connection() as conn:
            sync = conn.execute("PRAGMA synchronous").fetchone()[0]
            temp = conn.execute("PRAGMA temp_store").fetchone()[0]
            fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
            busy = conn.execute("PRAGMA busy_timeout").fetchone()[0]
        self.assertEqual(sync, 1)   # 1 == NORMAL
        self.assertEqual(temp, 2)   # 2 == MEMORY
        self.assertEqual(fk, 1)
        self.assertEqual(busy, 30000)


if __name__ == "__main__":
    unittest.main()
