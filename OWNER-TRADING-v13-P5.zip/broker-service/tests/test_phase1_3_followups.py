"""Re-audit of Phases 1-3: segments with their own hours, and the whole chain tick -> bar -> scan working together."""
import asyncio
import datetime as dt
import importlib
import types
import unittest
from unittest import mock
from zoneinfo import ZoneInfo

from tests.dbutil import fresh_db

IST = ZoneInfo("Asia/Kolkata")


def at(h, m, s=0, day=14):
    return dt.datetime(2026, 10, day, h, m, s, tzinfo=IST)


class Base(unittest.TestCase):
    TFS = {"5m"}

    def setUp(self):
        self.db = fresh_db()
        from app import tick_writer as tw, candle_engine as ce
        importlib.reload(tw)
        importlib.reload(ce)
        self.tw, self.ce = tw, ce
        self.writer = tw.tick_writer
        self.engine = ce.CandleEngine()
        self.engine._timeframe_cache = set(self.TFS)
        self.engine._timeframe_cache_at = 10 ** 12

    def tearDown(self):
        self.writer.stop()

    def tick(self, ts, price, vol=None, token="1", seg="nse_cm"):
        self.engine.on_tick(exchange_segment=seg, instrument_token=token, trading_symbol=f"S{token}", price=price, volume=vol, timestamp=ts)


class SegmentHoursTests(Base):
    def test_mcx_evening_ticks_build_bars_and_close_by_their_own_window(self):
        self.writer.start()
        self.tick(at(20, 1), 5000.0, 10, seg="mcx_fo")                 # long after the 15:30 equity close
        self.tick(at(20, 3), 5010.0, 20, seg="mcx_fo")
        self.assertEqual(self.engine.finalize_due(now=at(20, 5, 0)), 0)
        self.assertEqual(self.engine.finalize_due(now=at(20, 5, 2)), 1)
        self.writer.flush()
        rows = self.db.recent_candles("mcx_fo", "1", "5m", 10)
        self.assertEqual([(r["candle_at"], r["high"], r["close"]) for r in rows], [("2026-10-14 20:00:00", 5010.0, 5010.0)])

    def test_equity_segments_keep_the_session_rule(self):
        self.tick(at(9, 5), 100.0, 10, seg="nse_fo")
        self.tick(at(15, 40), 100.0, 10, seg="bse_cm")
        self.assertEqual(self.engine._state, {})

    def test_session_helpers_by_segment(self):
        from app.market_session import bar_end, in_session
        self.assertFalse(in_session(at(20, 0), "nse_cm"))
        self.assertTrue(in_session(at(20, 0), "mcx_fo"))
        self.assertEqual(bar_end(at(15, 15), 60, "nse_cm"), at(15, 30))
        self.assertEqual(bar_end(at(15, 15), 60, "mcx_fo"), at(16, 15))
        self.assertEqual(bar_end(at(0, 0), 1440, "mcx_fo"), dt.datetime(2026, 10, 15, 0, 0, tzinfo=IST))

    def test_startup_purge_leaves_mcx_evening_candles_alone(self):
        base = {"trading_symbol": "X", "timeframe": "5m", "open": 1, "high": 1, "low": 1, "close": 1, "volume": 0, "instrument_token": "1"}
        self.db.upsert_candles([dict(base, exchange_segment="mcx_fo", candle_at="2026-10-14 20:00:00"),
                                dict(base, exchange_segment="nse_cm", candle_at="2026-10-14 20:00:00"),
                                dict(base, exchange_segment="nse_cm", candle_at="2026-10-14 09:15:00")])
        self.assertEqual(self.db.purge_out_of_session_candles(), 1)
        self.assertEqual(len(self.db.recent_candles("mcx_fo", "1", "5m", 10)), 1)
        self.assertEqual(len(self.db.recent_candles("nse_cm", "1", "5m", 10)), 1)


class TickToScanChainTests(Base):
    """Phases 1+2+3 together: ticks -> write-behind buffer -> clock-closed bar -> scan sees the last bar."""

    def _scanner_at(self, fixed_now):
        from app import scanner_engine as se
        importlib.reload(se)

        class FakeDT(dt.datetime):
            @classmethod
            def now(cls, tz=None):
                return fixed_now.astimezone(tz) if tz else fixed_now

        fake = types.SimpleNamespace(datetime=FakeDT, timedelta=dt.timedelta, timezone=dt.timezone, date=dt.date, time=dt.time)
        return se, mock.patch.object(se, "dt", fake)

    def test_the_last_bar_is_scanned_without_waiting_for_the_next_tick(self):
        self.writer.start()
        self.db.bulk_upsert_instruments([{"trading_symbol": "AAA-EQ", "instrument_token": "1", "lot_size": 1, "tick_size": 0.05},
                                         {"trading_symbol": "BBB-EQ", "instrument_token": "2", "lot_size": 1, "tick_size": 0.05}])
        start = at(9, 15)
        for k in range(30):                                            # 30 five-minute bars of a steadily rising liquid stock
            for s in (1, 90, 170):
                self.tick(start + dt.timedelta(minutes=5 * k, seconds=s), 100.0 + k, 1000 * (k + 1) + s, token="1")
        self.tick(at(11, 41), 50.0, 5, token="2")                      # a thin stock: a single tick, in the LAST window only
        now = at(11, 45, 3)                                            # 3 s after the 11:40 bar closed; nobody has ticked since
        self.engine.finalize_due(now=at(11, 45, 3), grace_seconds=0.0)
        self.writer.flush()
        se, patched = self._scanner_at(now)
        definition = {"timeframe": "5m", "entry": {"op": "AND", "conditions": [{"left": "close", "operator": ">", "right": "sma5"}]}}
        universe = [{"exchange_segment": "nse_cm", "instrument_token": "1", "trading_symbol": "AAA-EQ"},
                    {"exchange_segment": "nse_cm", "instrument_token": "2", "trading_symbol": "BBB-EQ"}]
        with patched:
            matched, stats = se._scan_with_stats(universe, definition, "5m")
        self.assertEqual(stats["latest_candle_at"], "2026-10-14 11:40:00")        # the bar that JUST closed is in the scan
        self.assertEqual([m["instrument"]["instrument_token"] for m in matched], ["1"])    # rising stock: close > sma5
        self.assertEqual(stats["insufficient_history"], 1)                          # the thin stock has one bar only: reported, not hidden
        self.assertEqual((stats["ready"], stats["not_ready"]), (1, 1))

    def test_the_candle_barrier_makes_a_scan_correct_even_with_buffered_data(self):
        self.writer.start()
        self.tick(at(9, 16), 100.0, 10, token="1")
        from app import scanner_engine as se
        importlib.reload(se)
        with mock.patch("app.candle_engine.candle_engine", self.engine), mock.patch("app.tick_writer.tick_writer", self.writer):
            real_finalize = self.engine.finalize_due
            with mock.patch.object(self.engine, "finalize_due", side_effect=lambda **kw: real_finalize(now=at(9, 20, 1), **kw)):
                asyncio.run(se._candles_barrier())
        self.assertEqual(len(self.db.recent_candles("nse_cm", "1", "5m", 10)), 1)       # closed AND written, before any scan read


class FinalizerLoopTests(unittest.TestCase):
    def test_background_loop_runs_the_finalizer_every_second_and_stops_on_the_event(self):
        try:
            from app import main
        except Exception as exc:                      # pragma: no cover - environment without the broker dependencies
            self.skipTest(f"app.main not importable here: {exc}")
        from app.candle_engine import candle_engine

        async def scenario():
            stop = asyncio.Event()
            task = asyncio.create_task(main._background_candle_finalizer_loop(stop))
            await asyncio.sleep(2.3)
            stop.set()
            await asyncio.wait_for(task, 2)

        with mock.patch.object(candle_engine, "finalize_due", return_value=0) as fin:
            asyncio.run(scenario())
        self.assertGreaterEqual(fin.call_count, 2)
        self.assertLessEqual(fin.call_count, 3)

    def test_a_failing_finalizer_does_not_kill_the_loop(self):
        try:
            from app import main
        except Exception as exc:                      # pragma: no cover
            self.skipTest(f"app.main not importable here: {exc}")
        from app.candle_engine import candle_engine

        async def scenario():
            stop = asyncio.Event()
            task = asyncio.create_task(main._background_candle_finalizer_loop(stop))
            await asyncio.sleep(2.3)
            stop.set()
            await asyncio.wait_for(task, 2)

        with mock.patch.object(candle_engine, "finalize_due", side_effect=RuntimeError("boom")) as fin:
            asyncio.run(scenario())
        self.assertGreaterEqual(fin.call_count, 2)


if __name__ == "__main__":
    unittest.main()
