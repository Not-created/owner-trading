# v13 - Phase 4: scheduler and feed manager

## Feed manager (`websocket_manager.py`) - tests/test_phase4_feed_manager.py
1. **Priority admission instead of whole-batch rejection.** When the 3,000-key limit is reached, `subscribe_many` used to refuse the
   ENTIRE batch, so an open position or a fresh candidate could be denied a feed slot (no ticks, no exits) while 2,800 scanner stocks
   held them all. Now keys that fit are admitted; when full, the least important subscriptions are evicted (order: open positions >
   candidates > strategy stocks > orders > manual > scanner universe > other; equal or more important keys are never touched, least
   liquid first inside a tier). Measured at 3,000 keys: 120 position keys on a full feed evict 70 scanner stocks in 9 ms, total stays 3,000.
2. **Nothing is silently half-owned.** Keys that still do not fit are returned in `rejected` with a reason (and get no phantom owner);
   `subscribe()` of a single key still raises, so candidates/positions are never marked "subscribed" falsely.
3. **Partial-subscription recovery.** A failing broker batch no longer abandons the batches after it; refused/failed keys go to a pending set
   and `retry_pending()` re-attempts them; a failed batch during reconnect re-sends the whole registry on the next retry.
4. **Batched unsubscribe** (one broker call per 500 keys instead of one per key: releasing the scanner universe was ~2,800 calls).
5. **Open-position protection.** `sync_position_owners()` treats a rejected position feed as an error, and now also runs every 30 s
   (`main._feed_housekeeping`) - before it ran only at arm/disarm and reconnect, so a position whose feed was lost stayed unmonitored.
6. `feed_status()` (used/limit/free, tiers, pending, evictions, last rejection) is part of `status()` and of `/algo/scan-runs` (`feed_status`).

## Scanner feed budget (`scanner_engine.ensure_scanner_market_universe`)
The fixed 200-slot reserve is replaced by `budget = limit - held_by_more_important_owners - 50`. If the universe is larger, the busiest
stocks (last known volume) keep a slot; the rest are reported (`budget_cut`, `rejected`, `warning`), never silently dropped.

## Scan status and durable retry (`scanner_engine.py`) - tests/test_phase4_scheduler.py
* Every scan run is recorded as `COMPLETE` (>= 95 % of the universe judged), `PARTIAL`, `WAITING_FOR_DATA` (nothing judged), `FAILED`
  or `INVALID` (bad definition), with `attempt`, `ready`, `readiness_pct` and `coverage` in its stats. Older rows say `OK` (= complete).
* The retry state is the `scan_runs` table itself (no new table): keyed by (strategy version, scanner, bar), so it survives a restart.
  FAILED / WAITING_FOR_DATA are retried after 30 / 90 / 180 s (max 3 retries); PARTIAL is retried only while more data became ready since
  the previous try; COMPLETE / INVALID are never repeated. Before v13 a failed pass was never retried for its bar. A newer bar supersedes
  an older one, so on a 5-minute scanner only the retries that fit inside the bar happen.
* The "already scanned" memory is now per (strategy version, scanner) instead of per scanner, so two strategies sharing a scanner
  cannot suppress each other.
* One failing scanner no longer aborts the others in a cycle and always leaves a FAILED record (it used to leave nothing, so it would
  have been retried every 5 seconds or never).
* Frontend (`Scanner.jsx`): the history table colours COMPLETE normal, PARTIAL / WAITING_FOR_DATA amber, FAILED / INVALID red and shows
  "(try N)". The full diagnostics UI is Phase 6.

## Not verified here
Real Kotak SFeed behaviour on eviction/resubscribe (a fake feed is used), real VPS load, the frontend build (no Node packages here).
## Not done on purpose
Rotating the stocks beyond the feed budget through the feed in batches: they are scanned on stored candles and reported; rotation would
add stale-data risk and is better decided after a real-feed measurement.
