# v13 - subscribe / unsubscribe fixes and the Subscriptions card

Tests: `broker-service/tests/test_phase7_subscriptions.py` (28), `tests/test_phase4_feed_manager.py`, `frontend/test/subscriptionsView.test.js` (8),
`backend/test/brokerClient.test.js`. New migration: `016_manual_subscriptions.sql` (one small table).

## Problems found and fixed
1. **Your subscriptions vanished on every restart / deploy / re-login.** The live-feed registry is in memory and only strategies and positions were
   restored. Manual subscriptions are now saved (`manual_subscriptions` table) and restored after the strategies on every connect (`restore_manual_subscriptions`,
   idempotent; if the feed is full, what does not fit is retried and reported).
2. **"Unsubscribe" silently did nothing for stocks that came from a manual scan.** The button released only the owner called `manual`; stocks added by a
   manual scan (owner `scanner-manual-matches`, also yours) stayed on the feed with no message. Unsubscribe now releases EVERY manual-tier owner.
3. **No answer when a stock stays on the feed.** If a position, candidate, strategy or the scanner still needs it, it correctly stays, but you were never told.
   Every subscribe / unsubscribe now returns a per-instrument outcome (`removed`, `still_held` + who holds it, `not_yours`, `not_subscribed`) and a plain sentence;
   the page shows it. Subscribing says whether the stock was already on the feed for another reason, whether lower-priority scanner stocks were dropped to
   make room, or that the feed is full.
4. **The Subscriptions list could not say WHY a stock is on the feed** and rendered up to 3,000 rows. Rows now carry `owners`, `tier` and `removable`; the list can be
   filtered (`tier`, `q`) and paged (`limit`, `offset`), most important first, with a `summary` (on feed / 3,000, yours, positions, candidates, scanner, waiting).
   With no parameters it still returns everything, as before.
5. **No way to remove all of your subscriptions** and no bulk subscribe: added `POST /unsubscribe-all-manual` and `items: [...]` (up to 500) on `/subscribe` and
   `/unsubscribe`.
6. **A user whose broker session had expired could not remove anything** (409). Unsubscribing only changes the registry (and the feed when it is up), so it no longer
   needs a connection; subscribing still does.
7. **Stale ticks looked live.** An unsubscribed stock keeps its last tick forever in the live-ticks table; rows now say `subscribed`, and the page shows
   "Not subscribed (last tick HH:MM UTC)".
8. **Evicted candidates kept saying "subscribed".** When the feed manager drops a candidate for an open position, the candidate's flag is now cleared with the reason, and set
   again when the subscription is restored.
9. **Input validation:** segment must be a known one, token 1-40 printable characters, 1-500 instruments per request; each problem has its own message.
10. A strategy whose stocks could not all get a slot used to restore silently; the rejected count is logged.

## The Market Data page
Subscriptions card: count chips, tabs (Mine / Positions & strategies / Scanner / All), search box, paging (50 per page), a "Why it is on the feed" column,
a Remove button only for rows you own (with a note when something else keeps it on the feed), "Remove all mine" (confirmed), and the server's sentence after every action.
