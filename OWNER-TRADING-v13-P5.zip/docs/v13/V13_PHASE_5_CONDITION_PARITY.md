# v13 - Phase 5: condition engine parity

Goal: the same condition on the same bar gives the same answer in the scanner, the live strategy, the strategy exit and the backtest.
Tests: `broker-service/tests/test_phase5_condition_parity.py`, `tests/test_required_bars_contract.py`, `frontend/test/conditionBuilder.test.js`.

## Problems fixed
1. **Recursive indicators depended on how many bars the caller loaded.** EMA, RSI, ATR, ADX and MACD are recursive: their value at a bar
   depends on where the series fed to them starts. v12 fed the scanner ~22 bars, the live strategy 250, the backtest 300, the exit check
   250, so "ema20 crosses ema50" could match in the scanner and be rejected by the strategy (or the reverse). Now every operand is computed
   on its own canonical window (`strategy_engine.operand_window`): ema `3*(n+1)` bars, rsi/atr `6n+1`, adx `8n+1`, macd 150, so the recursion
   has converged (residual seed error below ~0.3 %). The window belongs to the OPERAND, not to the definition around it: ema20 is
   bit-identical whatever else the rule contains and however many bars the caller loaded (tests prove it for every supplied length
   from the window up to the full history, for entry, exit, offsets `ema20[3]` and the ATR used by stops).
2. **VWAP in the scanner was wrong.** It only saw the bars in the window (the last ~22), not the whole session. It now always gets the whole
   session (`bars in session + 1`).
3. **MACD conditions crashed in v12.** Any entry/exit using `macd`, `macd_signal` or `macd_hist` raised `ValueError` inside
   `Resolver.snapshot` (an internal two-part cache key was unpacked as an operand): the scanner and the live strategy could not use MACD at all.
4. **The strategy exit loaded only 250 bars**, so an exit on ema200 saw a different ema200 than the entry. It now loads the definition's
   analysis window (`exit_engine.exit_candle_limit`).
5. **ATR for stops/sizing** (`strategy_engine.risk_atr`) uses the same window as the `atr14` operand in live, backtest and recovery.
6. **"Enough history"** now means the converged window: `scanner_engine.required_bars` = `analysis_window` (ema20 65 bars, rsi14 87, adx14 115,
   macd 152, ema200 600, vwap a whole session). The history warm-up fetches that many bars (a long window may use several broker chunks,
   at most 6), the live strategy loads `window + 5`, and the backtest's warm-up before `from_date` follows the same window.
7. **The UI hint "needs about N bars" can no longer drift:** frontend `minBarsHint` and backend `required_bars` are checked against ONE
   generated fixture (`frontend/test/fixtures/scanner-required-bars.json`, 24 cases) from both sides.

## Evidence
* Scanner path == condition engine on the same bars at 49 different bars; backtest enters exactly on bars the full-history evaluation
  supports; convergence: the canonical window is closer to the full-history value than the old scanner window for EMA and RSI.
* 2,800 full entry evaluations of a rich definition (ema, rsi, adx, macd, vwap, nested groups, crossover) on 158 bars: 1.6 s (0.58 ms each).

## Behaviour changes to expect (saved strategies stay valid; their definitions are unchanged)
* Indicator values are now the converged ones (closer to what charting platforms show), so a scan may match slightly different stocks than v12.
* A stock needs the full window before it is judged: ema20 needs 65 bars instead of 22, rsi14 87 instead of 17, ema200 600 instead of 202.
  Until the history back-fill supplies it the stock is reported as "insufficient history" (visible in the scan numbers), never silently judged.

## Not covered (data, not logic)
Live bars are built from LTP ticks; broker history is the official feed, so the same bar can differ slightly in OHLCV between the two sources.
The condition logic is identical; reconciling the two data sources after the close is not part of v13.
