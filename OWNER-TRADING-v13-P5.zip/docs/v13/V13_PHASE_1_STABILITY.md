# v13 - Phase 1: real-time stability (tick hot path)

## Problem (found in v12 audit)
`websocket_manager._on_market_message` runs on the asyncio event loop - the same loop that runs protective exits.
For every tick it could open a SQLite connection and commit up to three times (latest tick, forming-bar checkpoint,
completed bar), and `exit_engine.on_tick` read all open positions from SQLite on every tick.

## Change
* `app/tick_writer.py` (new): write-behind buffer. The hot path only updates in-memory dicts; one background thread
  writes once per second, each kind in ONE transaction. Completed candles are re-queued if a write fails (never dropped
  silently); latest-tick and checkpoint rows are coalesced.
* `app/db.py`: bulk helpers (`record_market_ticks_bulk`, `upsert_candle_runtime_states_bulk`,
  `delete_candle_runtime_states_bulk`, `load_candle_runtime_states`).
* `app/candle_engine.py`: no per-tick DB writes; forming-bar checkpoints are loaded once at feed start.
* `app/exit_engine.py`: `may_have_position()` / `on_tick()` use a once-per-second in-memory set of instruments with an
  open position. If the set cannot be read, every tick takes the old full path (exits can only get slower, never skipped).
* `app/websocket_manager.py`: starts/stops the writer with the feed (stop = final flush); no exit task for instruments
  without an open position; `status()` now reports `tickWriter` (pending, last flush ms, last error).
* When the writer is not running (tests, scripts) every write is synchronous - the old behaviour.

## Measured (sandbox, 2,400 ticks through candle engine + latest-tick write)
| | SQLite connections | time on the event-loop thread |
|---|---|---|
| v12 | 7,200 | 10,723 ms (4,468 us/tick) |
| v13 phase 1 | 400 (one-time seeding reads) | 290 ms (121 us/tick) |

## Known limits (next phases)
* One SQLite read per instrument/timeframe remains the FIRST time a bar is seeded after process start
  (`db.get_candle`). Phase 2 (clock-based bar finalizer) removes it.
* The completed bar still reaches the `candles` table only when that instrument's next tick arrives (Phase 2).
* Not measured: real VPS load with ~2,800 live subscriptions, real Kotak feed.

## After deploy
Restart both services. Check `GET /status` on the broker service: `tickWriter.errors` should stay 0 and
`tickWriter.last_flush_ms` should be small (tens of ms).

## Follow-up fixes found when Phase 1 was re-audited (delivered with Phase 2)
1. **Regression:** completed bars were announced to the strategy engine before they were in SQLite (they sat in the
   write-behind buffer), so every strategy evaluation read the PREVIOUS bar. Closed bars are now flushed first, then
   evaluated (`CandleEngine._dispatch_completed`).
2. **No flush on service restart/deploy:** `main._main` never stopped the feed, so up to a second of buffered candles,
   checkpoints and ticks was lost on every SIGTERM. Shutdown now calls `websocket_manager.stop()` (final flush).
3. **`last_tick_at` was the flush time:** it is now the tick's own arrival time (UTC), so price-freshness checks in the
   order gate are not flattered by up to a second.
