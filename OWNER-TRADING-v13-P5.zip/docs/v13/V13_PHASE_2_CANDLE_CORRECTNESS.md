# v13 - Phase 2: candle correctness

## Problems fixed (all confirmed in v12 code, each has a test in tests/test_phase2_candle_correctness.py)
1. **A bar was written only when the same stock's NEXT tick arrived.** A stock that did not trade again left its last
   bar unwritten and a scan at bar close silently read the bar before it. Now `CandleEngine.finalize_due()` closes every
   bar by the clock (1 s grace), driven by a 1-second background loop (`main._background_candle_finalizer_loop`).
   No database I/O on that loop; 2,800 bars close in ~57 ms on the loop thread (measured), written by the background writer.
2. **Pre-open and post-close ticks created fake bars** (bucketed to 00:00 or 15:30). Ticks outside 09:15:00-15:30:00 are no
   longer candle data; the cumulative-volume baseline still follows them, so the opening-auction volume lands in the 09:15 bar.
   Startup removes the old fake intraday bars (`db.purge_out_of_session_candles`, daily bars untouched).
3. **Bar completeness ignored the 15:30 close.** The last 30m/1h bar (starts 15:15) and the daily bar were treated as
   incomplete when the scan ran at the close, so the day's last bar was never scanned. One shared rule now
   (`market_session.bar_end`) is used by the candle engine, scanner and strategy engine.
4. **Scans could read stale candles.** Before reading candles a scan now closes due bars and flushes the buffer
   (`scanner_engine._candles_barrier`), so correctness no longer depends on the 3-second delay.
5. **One SQLite read per instrument remained** when seeding a bar after a restart. Seeds for the current bar are loaded
   once at feed start; the first tick needs no read.
6. A closed bar is never written or announced twice (next-tick path skips bars the clock already closed); a late tick stamped
   inside a closed bar updates it; a closed bar gets no new checkpoint.

## Deliberate decision
Bars for instruments with NO tick in a window are NOT invented (no flat carry-forward candles): fake prices would feed
indicators. Instead Phase 3 reports "no trade in last bar" separately from "data missing" in Data Status.

## Not verified here
Real VPS with ~2,800 live subscriptions and the real Kotak feed. Frontend / Express tests (Node packages unavailable here).

## Follow-up fixes found when Phase 1-2 were re-audited (delivered with Phase 3)
1. **Bar close hit the strategy engine 2,800 times at the same second.** Each call re-read every strategy from SQLite, although
   almost no instrument can ever produce a signal (before the clock finalizer these calls were spread out by each stock's own
   next tick). `candle_engine.relevant_completed()` now keeps only the bars a LIVE-armed strategy can act on (its scanner
   candidates, its bound instruments, or everything for an open-ended strategy, and only for that strategy's timeframe),
   once per batch; the runtime counter is still refreshed.
2. **A bar that was forming when the service crashed was lost.** At feed start a checkpoint whose bar already ended is now
   written as a candle (never over a stored one: `db.insert_candles_if_missing`) and the checkpoint is cleared.
3. **A manual scan did not close/flush due bars first** (only scheduled scans did). It does now.
