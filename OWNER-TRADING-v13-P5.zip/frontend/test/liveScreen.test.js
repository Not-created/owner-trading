import test from "node:test";
import assert from "node:assert/strict";
import { formatCountdown, remainingSeconds, failedGates, shouldPoll, chartGeometry } from "../src/lib/liveScreen.js";

test("countdown text", () => {
  assert.equal(formatCountdown(180), "03:00");
  assert.equal(formatCountdown(59.9), "00:59");
  assert.equal(formatCountdown(0), "00:00");
  assert.equal(formatCountdown(-5), "00:00");
  assert.equal(formatCountdown(3725), "1:02:05");
  assert.equal(formatCountdown(null), "—");
  assert.equal(formatCountdown(undefined), "—");
  assert.equal(formatCountdown("abc"), "—");
});

test("remaining seconds ticks down from the server value, not from the phone clock", () => {
  assert.equal(remainingSeconds(180, 1_000_000, 1_000_000), 180);
  assert.equal(remainingSeconds(180, 1_000_000, 1_012_400), 168);
  assert.equal(remainingSeconds(5, 1_000_000, 1_010_000), -5);
  assert.equal(remainingSeconds(null, 0, 10), null);
});

test("failed gates text matches the Strategies page wording and ignores non-blocking / passing gates", () => {
  const body = { readiness: { gates: [{ id: "a", ok: true }, { id: "b", ok: false, detail: "no funds" }, { id: "c", ok: false, blocking: false, detail: "x" }] } };
  assert.equal(failedGates(body), " Failing checks — b: no funds");
  assert.equal(failedGates({}), "");
});

test("polling pauses only when the tab is definitely hidden", () => {
  assert.equal(shouldPoll({ hidden: true }), false);
  assert.equal(shouldPoll({ hidden: false }), true);
  assert.equal(shouldPoll(undefined), true);
  assert.equal(shouldPoll({}), true);
});

const DATA = {
  candles: [
    { t: "a", o: 10, h: 12, l: 9, c: 11 },
    { t: "b", o: 11, h: 13, l: 10, c: 10.5 },
    { t: "c", o: 10.5, h: 14, l: 10, c: 13 },
  ],
  lines: { ema9: [null, 10.8, 11.5], ema21: [null, null, null] },
  markers: [{ candle_at: "c", side: "BUY" }, { candle_at: "b", side: "SELL" }, { candle_at: "zzz", side: "BUY" }],
};

test("chart geometry: higher price is higher on screen, direction colours, gaps in lines, marker mapping", () => {
  const g = chartGeometry(DATA);
  assert.equal(g.candles.length, 3);
  assert.ok(g.candles[2].yH < g.candles[0].yH);               // 14 is above 12
  assert.ok(g.candles[0].yL > g.candles[0].yH);               // low is below high on screen
  assert.deepEqual(g.candles.map((c) => c.up), [true, false, true]);
  assert.ok(g.candles[0].x < g.candles[1].x && g.candles[1].x < g.candles[2].x);
  assert.equal(g.lines.length, 1);                            // ema21 is all-null -> not drawn
  assert.ok(g.lines[0].d.startsWith("M"));
  assert.equal((g.lines[0].d.match(/M/g) || []).length, 1);   // starts after the null gap: one segment
  assert.equal(g.markers.length, 2);                          // marker on an unknown candle is dropped
  assert.equal(g.markers.find((m) => m.side === "BUY").x, g.candles[2].x);
  assert.equal(g.ticks.length, 4);
  for (const c of g.candles) for (const y of [c.yH, c.yL, c.yO, c.yC]) assert.ok(y >= 0 && y <= 200);
});

test("chart geometry: empty, flat price and a line that restarts after a gap", () => {
  assert.equal(chartGeometry({ candles: [] }), null);
  assert.equal(chartGeometry(null), null);
  const flat = chartGeometry({ candles: [{ t: "a", o: 5, h: 5, l: 5, c: 5 }], lines: {}, markers: [] });
  assert.ok(Number.isFinite(flat.candles[0].yH));
  const gap = chartGeometry({ candles: [1, 2, 3, 4].map((v, i) => ({ t: String(i), o: v, h: v + 1, l: v - 1, c: v })), lines: { x: [1, null, 3, 4] }, markers: [] });
  assert.equal((gap.lines[0].d.match(/M/g) || []).length, 2);
});
