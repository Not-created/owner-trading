import test from "node:test";
import assert from "node:assert/strict";
import { toneColor, sourceLabel, timelineHeadline, brokerHistoryRows } from "../src/lib/orderTimeline.js";

test("tone colours, unknown tone falls back", () => {
  assert.notEqual(toneColor("good"), toneColor("bad"));
  assert.equal(toneColor("zzz"), toneColor("info"));
  assert.equal(toneColor(undefined), toneColor("info"));
});

test("source label shows merged sources and repeat count", () => {
  assert.equal(sourceLabel({ sources: ["लाइव फ़ीड", "ऑर्डर रिपोर्ट"], repeats: 2 }), "लाइव फ़ीड + ऑर्डर रिपोर्ट ×2");
  assert.equal(sourceLabel({ sources: ["सिस्टम"] }), "सिस्टम");
  assert.equal(sourceLabel(null), "");
});

test("headline: filled, rejected with reason, unconfirmed", () => {
  assert.equal(timelineHeadline({ status: "COMPLETE", quantity: 10, filled_quantity: 10, average_price: 2642.8 }), "COMPLETE · 10/10 भरा @ 2642.8");
  assert.equal(timelineHeadline({ status: "REJECTED", quantity: 5, filled_quantity: 0, reason: "Insufficient funds" }), "REJECTED · 0/5 भरा · कारण: Insufficient funds");
  assert.match(timelineHeadline({ status: "SUBMITTED", quantity: 1, unconfirmed: true }), /पुष्टि बाकी/);
  assert.equal(timelineHeadline(null), "");
});

test("broker history rows tolerate odd shapes", () => {
  assert.deepEqual(brokerHistoryRows(null), []);
  assert.deepEqual(brokerHistoryRows({ history: "x" }), []);
  const rows = brokerHistoryRows({ history: [{ ordSt: "open", fldQty: 0 }, null, { ordSt: "rejected", rejRsn: "RMS", updRecvTm: "10:05:03" }, {}] });
  assert.equal(rows.length, 3);
  assert.deepEqual(rows[0], { status: "open", detail: "भरा 0" });
  assert.equal(rows[1].detail, "कारण: RMS · 10:05:03");
  assert.equal(rows[2].status, "—");
});
