import test from "node:test";
import assert from "node:assert/strict";
import {
  num, statusTone, statusLabel, statusBanner, coverageNotice, buildStatusCards, matchBadges, historyRow, diagnosticsLines,
} from "../src/lib/scanDiagnostics.js";

test("status tone and label: legacy OK means complete; unknown is neutral", () => {
  assert.deepEqual(["COMPLETE", "OK", "PARTIAL", "WAITING_FOR_DATA", "FAILED", "INVALID", "???", null].map(statusTone),
    ["ok", "ok", "warn", "warn", "bad", "bad", "neutral", "neutral"]);
  assert.equal(statusLabel("OK"), "Complete");
  assert.equal(statusLabel("WAITING_FOR_DATA"), "Waiting for data");
  assert.equal(statusLabel(null), "—");
});

test("numbers use Indian grouping and show a dash instead of inventing a value", () => {
  assert.equal(num(2800), "2,800");
  assert.equal(num(123456), "1,23,456");
  assert.equal(num(null), "—");
  assert.equal(num(undefined), "—");
  assert.equal(num(86.04, 1), "86");
});

test("a partial scan never reads as 'no setups'", () => {
  const b = statusBanner("PARTIAL", { ready: 2412, universe: 2800, not_ready: 388 });
  assert.equal(b.tone, "warn");
  assert.match(b.text, /2,412 of 2,800 stocks could be judged/);
  assert.match(b.text, /Zero matches does not mean there are no setups/);
  assert.match(b.text, /388 stocks are waiting/);
  assert.match(statusBanner("PARTIAL", { ready: 5, universe: 6, not_ready: 1 }).text, /1 stock is waiting/);
});

test("waiting / failed / invalid banners, and none for a complete scan", () => {
  assert.match(statusBanner("WAITING_FOR_DATA", {}).text, /Zero matches means nothing/);
  assert.match(statusBanner("FAILED", { attempt: 3 }, "database is locked").text, /after 3 tries: database is locked/);
  assert.match(statusBanner("INVALID", {}, "bad condition").text, /not retried/);
  assert.equal(statusBanner("COMPLETE", { ready: 10, universe: 10 }), null);
  assert.equal(statusBanner("OK", {}), null);
});

test("stocks beyond the feed limit get their own notice even when the scan is complete", () => {
  assert.equal(coverageNotice({ warning: null }), null);
  assert.equal(coverageNotice(undefined), null);
  assert.match(coverageNotice({ warning: "147 of 2947 stocks are NOT scanned." }).text, /NOT scanned/);
});

test("four status cards from real numbers", () => {
  const cards = buildStatusCards({
    stats: { ready: 2771, not_ready: 29, readiness_pct: 99, took_ms: 800, matched_total: 14, coverage: { universe: 2800, eligible_total: 2947, truncated: 147 } },
    status: "COMPLETE", feed: { used: 2845, limit: 3000, free: 155, pending: 0 },
  });
  assert.deepEqual(cards.map((c) => c.key), ["universe", "data", "scan", "feed"]);
  assert.deepEqual([cards[0].value, cards[0].sub, cards[0].tone], ["2,800 / 2,947", "147 stocks over the limit", "warn"]);
  assert.deepEqual([cards[1].value, cards[1].sub, cards[1].tone], ["2,771 ready", "29 not ready", "ok"]);
  assert.deepEqual([cards[2].value, cards[2].sub, cards[2].tone], ["Complete", "0.8 s, 14 matched", "ok"]);
  assert.deepEqual([cards[3].value, cards[3].sub, cards[3].tone], ["2,845 / 3,000", "155 slots free", "ok"]);
});

test("cards: readiness below 95% is a warning, retries and waiting-for-slot are visible, nothing is invented", () => {
  const c = buildStatusCards({ stats: { ready: 2412, not_ready: 388, readiness_pct: 86.1, attempt: 2, matched: 3 }, coverage: { universe: 2800, eligible_total: 2800, truncated: 0 },
    status: "PARTIAL", feed: { used: 3000, limit: 3000, free: 0, pending: 12 } });
  assert.equal(c[0].sub, "every stock scanned");
  assert.equal(c[1].tone, "warn");
  assert.equal(c[2].sub, "3 matched, try 2");
  assert.deepEqual([c[3].sub, c[3].tone], ["12 waiting for a slot", "warn"]);
  const empty = buildStatusCards();
  assert.deepEqual(empty.map((x) => x.value), ["—", "—", "—", "—"]);
  assert.ok(empty.every((x) => x.tone === "neutral"));
});

test("match badges: data, feed and last completed candle", () => {
  assert.deepEqual(matchBadges({ data_status: "FRESH", subscription: "SUBSCRIBED", last_completed_candle: "2026-10-14 10:10:00" }),
    [{ text: "Data fresh", tone: "ok" }, { text: "Feed subscribed", tone: "accent" }, { text: "Candle 10:10", tone: "neutral" }]);
  assert.deepEqual(matchBadges({ data_status: "FRESH", subscription: "NOT_SUBSCRIBED", candle_at: "2026-10-14 10:15:00" }).map((b) => b.text),
    ["Data fresh", "No live feed", "Candle 10:15"]);
  assert.deepEqual(matchBadges({}).map((b) => b.text), ["Data unknown", "Candle unknown"]);
});

test("history rows show status, attempt, readiness, coverage and the error", () => {
  const r = historyRow({ id: 9, started_at: "2026-10-14 04:35:02", bar_at: "2026-10-14 10:05:00", status: "PARTIAL", universe: 2800, evaluated: 2400, matched: 7,
    duration_ms: 900, error: null, stats: { attempt: 2, readiness_pct: 86.04, coverage: { coverage_pct: 95 } } });
  assert.deepEqual([r.label, r.tone, r.attempt, r.retried, r.readiness, r.coverage, r.seconds, r.bar], ["Partial", "warn", 2, true, "86%", "95%", "0.9", "10-14 10:05"]);
  const legacy = historyRow({ id: 1, status: "OK", started_at: "2026-10-01 04:00:00", stats: {} });
  assert.deepEqual([legacy.label, legacy.tone, legacy.attempt, legacy.readiness, legacy.coverage, legacy.bar], ["Complete", "ok", 1, "—", "—", "—"]);
  assert.equal(historyRow({ id: 2, status: "FAILED", error: "boom", stats: {} }).error, "boom");
});

test("diagnostics lines report this installation's real numbers", () => {
  const lines = diagnosticsLines({
    instruments: { total: 2947, by_series: { EQ: 2947 } }, market_open: true,
    scanners: [{ id: 1, name: "Momentum", timeframe: "5m", status: "PARTIAL",
      data: { universe: 2800, ready: 2412, readiness_pct: 86.1, no_candles: 100, insufficient_history: 200, stale: 88, required_bars: 87 },
      coverage: { universe: 2800, eligible_total: 2947 }, last_run: { status: "FAILED", attempt: 2, bar_at: "2026-10-14 10:05:00", error: "boom" } }],
    feed: { used: 2845, limit: 3000, pending: 0, evicted_total: 3, tiers: { positions: 3, candidates: 42, scanner_universe: 2800 } },
    tick_writer: { running: true, last_flush_ms: 41, errors: 0 }, candle_engine: { forming_bars: 5600 }, took_ms: 1800,
  });
  const text = lines.map((l) => `${l.label}: ${l.value}`).join("\n");
  assert.match(text, /Stocks synced: 2,947 \(EQ 2,947\)/);
  assert.match(text, /Scanner Momentum \(5m\): Partial: 2,412 of 2,800 stocks ready \(86.1%\), 100 without candles, 200 with fewer than 87 bars, 88 stale; covers 2,800 of 2,947 stocks/);
  assert.match(text, /last run: Failed \(try 2\) for bar 10-14 10:05: boom/);
  assert.match(text, /Live feed: 2,845 of 3,000 used \(positions 3, candidates 42, scanner 2,800\); 0 waiting, 3 evicted so far/);
  assert.match(text, /Tick writer: running, last write 41 ms, 0 errors/);
  assert.match(text, /Check took: 1.8 s/);
  assert.deepEqual(diagnosticsLines(null), []);
  assert.equal(diagnosticsLines({ scanners: [] }).some((l) => l.value === "none active"), true);
});
