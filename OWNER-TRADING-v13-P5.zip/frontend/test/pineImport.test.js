import test from "node:test";
import assert from "node:assert/strict";
import { pineApplyPatch, pineStatus, pineProblemRows } from "../src/lib/pineImport.js";

const OK = { ok: true, needs_exit: true, definition: { side: "BUY", entry: { op: "AND", conditions: [{ left: "ema20", operator: "cross_above", right: "ema50" }] } } };

test("an ok result becomes a builder patch; exit is null when Pine had none", () => {
  const p = pineApplyPatch(OK);
  assert.equal(p.side, "BUY");
  assert.equal(p.entry.conditions[0].left, "ema20");
  assert.equal(p.exit, null);
  assert.equal(pineApplyPatch({ ...OK, definition: { ...OK.definition, exit: { op: "AND", conditions: [] } } }).exit.op, "AND");
});

test("a result that is not ok, or has no definition, can never be applied", () => {
  assert.equal(pineApplyPatch(null), null);
  assert.equal(pineApplyPatch({ ok: false, definition: OK.definition }), null);
  assert.equal(pineApplyPatch({ ok: true, definition: null }), null);
  assert.equal(pineApplyPatch({ ok: "true", definition: OK.definition }), null);
});

test("status text and problem rows", () => {
  assert.match(pineStatus(OK), /Exit नहीं मिला/);
  assert.match(pineStatus({ ok: false, need_choice: true }), /चुनें/);
  assert.equal(pineStatus({ ok: false, reason: "कारण" }), "कारण");
  const rows = pineProblemRows({ errors: Array.from({ length: 9 }, (_, i) => ({ line: i + 1, reason: "x" })) });
  assert.equal(rows.length, 6);
  assert.equal(rows[0], "लाइन 1: x");
});
