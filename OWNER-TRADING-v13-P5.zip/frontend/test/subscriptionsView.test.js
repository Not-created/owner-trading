import test from "node:test";
import assert from "node:assert/strict";
import {
  tierLabel, ownerLabel, ownerChips, FILTERS, filterParams, pageInfo, summaryChips, rowAction, resultMessage, tickFeedState, PAGE_SIZE,
} from "../src/lib/subscriptionsView.js";

test("owners are worded for a person, not a log file", () => {
  assert.equal(ownerLabel("manual"), "Added by you");
  assert.equal(ownerLabel("scanner-manual-matches"), "Manual scan result");
  assert.equal(ownerLabel("scanner-universe"), "Scanner universe");
  assert.equal(ownerLabel("position:12"), "Open position");
  assert.equal(ownerLabel("order:5"), "Order in progress");
  assert.equal(ownerLabel("strategy:7:candidate:nse_cm:1594"), "Strategy v7 candidate");
  assert.equal(ownerLabel("strategy:7:universe"), "Strategy v7 stocks");
  assert.equal(ownerLabel("whatever"), "whatever");
  assert.equal(tierLabel("scanner_universe"), "Scanner universe");
  assert.equal(tierLabel("nope"), "nope");
});

test("a row's reasons are distinct and keep the server's order", () => {
  assert.deepEqual(ownerChips({ owners: ["manual", "position:9", "scanner-manual-matches"] }), ["Added by you", "Open position", "Manual scan result"]);
  assert.deepEqual(ownerChips({ owners: ["strategy:1:candidate:nse_cm:1", "strategy:1:candidate:nse_cm:1"] }), ["Strategy v1 candidate"]);
  assert.deepEqual(ownerChips({}), []);
});

test("filters map to the tiers the server understands and paging to limit/offset", () => {
  assert.deepEqual(FILTERS.map((f) => f.id), ["mine", "strategy", "scanner", "all"]);
  assert.deepEqual(filterParams(), { tier: "manual", q: undefined, limit: PAGE_SIZE, offset: 0 });
  assert.deepEqual(filterParams({ filter: "all", query: "  reli ", page: 2 }), { tier: undefined, q: "reli", limit: 50, offset: 100 });
  assert.equal(filterParams({ filter: "strategy" }).tier, "positions,candidates,strategy_stocks,orders");
  assert.equal(filterParams({ filter: "unknown" }).tier, "manual");
  assert.equal(filterParams({ page: -3 }).offset, 0);
});

test("page info never goes out of range", () => {
  assert.deepEqual(pageInfo(0), { page: 0, pages: 1, from: 0, to: 0, hasPrev: false, hasNext: false });
  assert.deepEqual(pageInfo(120, 0), { page: 0, pages: 3, from: 1, to: 50, hasPrev: false, hasNext: true });
  assert.deepEqual(pageInfo(120, 2), { page: 2, pages: 3, from: 101, to: 120, hasPrev: true, hasNext: false });
  assert.equal(pageInfo(120, 9).page, 2);
});

test("summary chips come only from the server's numbers", () => {
  const chips = summaryChips({ total: 2845, limit: 3000, removable: 4, pending: 0, tiers: { positions: 3, candidates: 42, scanner_universe: 2800 } });
  assert.deepEqual(chips.map((c) => `${c.label}=${c.value}`), ["On live feed=2,845 / 3,000", "Yours=4", "Open positions=3", "Candidates=42", "Scanner=2,800"]);
  assert.equal(chips[0].tone, "ok");
  const full = summaryChips({ total: 3000, limit: 3000, removable: 0, pending: 7, tiers: {} });
  assert.equal(full[0].tone, "warn");
  assert.deepEqual(full.at(-1), { key: "pending", label: "Waiting for a slot", value: "7", tone: "warn" });
  assert.deepEqual(summaryChips(null), []);
});

test("the action column explains why a row cannot be removed, and what stays after removing one", () => {
  assert.deepEqual(rowAction({ removable: true, owners: ["manual"] }), { canRemove: true, note: "" });
  const shared = rowAction({ removable: true, owners: ["manual", "position:3", "strategy:7:candidate:nse_cm:1"] });
  assert.equal(shared.canRemove, true);
  assert.equal(shared.note, "Also needed by Open position, Strategy v7 candidate: stays on the feed after you remove it");
  const auto = rowAction({ removable: false, owners: ["scanner-universe"] });
  assert.deepEqual([auto.canRemove, auto.note], [false, "Managed automatically (Scanner universe)"]);
});

test("the message after subscribe / unsubscribe is the server's explanation or its error", () => {
  assert.equal(resultMessage({ ok: true, body: { message: "1 subscribed" } }, "x"), "1 subscribed");
  assert.equal(resultMessage({ ok: true, body: {} }, "Done."), "Done.");
  assert.equal(resultMessage({ ok: false, body: { error: "SFeed subscription limit reached (3000)" } }), "SFeed subscription limit reached (3000)");
  assert.equal(resultMessage({ ok: false, body: { result: { reason: "feed full" } } }), "feed full");
  assert.equal(resultMessage({ ok: false, body: null }), "The request failed.");
  assert.equal(resultMessage(undefined, "fallback"), "The request failed.");
});

test("a tick of an unsubscribed instrument no longer looks live", () => {
  assert.deepEqual(tickFeedState({ subscribed: true }), { label: "Live", tone: "ok" });
  assert.deepEqual(tickFeedState({}), { label: "Live", tone: "ok" });
  assert.deepEqual(tickFeedState({ subscribed: false, last_tick_at: "2026-10-14 04:35:02" }), { label: "Not subscribed (last tick 04:35 UTC)", tone: "warn" });
  assert.equal(tickFeedState({ subscribed: false }).label, "Not subscribed");
});
