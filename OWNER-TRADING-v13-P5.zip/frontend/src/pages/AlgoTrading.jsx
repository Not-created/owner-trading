import { useEffect, useRef, useState } from "react";
import usePolling from "../hooks/usePolling";
import { api } from "../api/client";
import LiveChart from "../components/LiveChart";
import { formatCountdown, remainingSeconds, failedGates, shouldPoll } from "../lib/liveScreen";

const hhmm = (s) => (s ? String(s).slice(11, 16) : "—");

export default function AlgoTrading() {
  // One light call every 5 s for the whole screen (strategies, next candle close, last scan, signals).
  const live = usePolling(() => api.getAlgoLiveStatus(), 5000);
  const risk = usePolling(() => api.getRiskStatus(), 10000);
  const d = usePolling(() => api.getAlgoRuntime(), 15000);
  const ready = usePolling(() => api.getLiveReadiness(), 15000);
  const r = d.body?.runtime;

  const data = live.body;
  const strategies = data?.strategies || [];
  const signals = data?.signals || [];
  const stopActive = !!risk.body?.emergencyStop?.is_active;

  // Countdown: server seconds at fetch time, ticked down locally (the phone's own clock is never trusted).
  const fetchedAt = useRef(Date.now());
  const [now, setNow] = useState(Date.now());
  useEffect(() => { fetchedAt.current = Date.now(); setNow(Date.now()); }, [live.body]);
  useEffect(() => {
    const t = setInterval(() => { if (shouldPoll()) setNow(Date.now()); }, 1000);
    return () => clearInterval(t);
  }, []);
  const lead = strategies.find((s) => s.armed) || strategies[0];
  const left = lead ? remainingSeconds(lead.next_close_in_s, fetchedAt.current, now) : null;

  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [pick, setPick] = useState(null);
  const [tokenText, setTokenText] = useState("");

  async function toggle(s) {
    if (busy) return;
    if (!s.armed && !window.confirm(`"${s.name}" का Auto-trade चालू करें?\n\nइससे असली पैसे से ऑर्डर जाएँगे (LIVE), आपकी Risk सीमाओं के भीतर।`)) return;
    setBusy(`t${s.version_id}`);
    setMsg(s.armed ? "" : "चालू हो रहा है… broker मिलान और candle history लोड होने में एक मिनट तक लग सकता है।");
    try {
      const x = s.armed ? await api.disarmAlgoStrategy(s.version_id) : await api.armAlgoStrategy(s.version_id);
      if (x.ok) setMsg(s.armed ? "Auto-trade बंद हो गया।" : "Auto-trade चालू हो गया (सभी जाँच पास)।");
      else setMsg(`${s.armed ? "बंद" : "चालू"} नहीं हो सका: ${x.body?.error || (x.status ? `HTTP ${x.status}` : "सर्वर से जवाब नहीं")}.${failedGates(x.body)}`);
    } finally { setBusy(""); live.reload(); }
  }

  async function emergencyStop() {
    if (busy || !window.confirm("Emergency stop: सारे LIVE ऑर्डर तुरंत रोक दिए जाएँगे। जारी रखें?")) return;
    setBusy("stop");
    try {
      const x = await api.activateEmergencyStop("Live Auto स्क्रीन से");
      setMsg(x.ok ? "Emergency stop चालू: कोई नया LIVE ऑर्डर नहीं जाएगा।" : `Emergency stop नहीं लग सका: ${x.body?.error || "सर्वर से जवाब नहीं"}`);
    } finally { setBusy(""); risk.reload(); }
  }

  const sig0 = signals[0];
  const target = pick || (sig0 ? { segment: sig0.exchange_segment, token: sig0.instrument_token, label: sig0.symbol } : null);
  const chartVersion = lead?.version_id || "";
  const chartTf = lead?.timeframe || "5m";
  const chart = usePolling(
    () => (target ? api.getAlgoChart({ segment: target.segment, token: target.token, timeframe: chartTf, limit: 100, versionId: chartVersion }) : Promise.resolve({ ok: true, body: null })),
    15000, [target?.segment, target?.token, chartTf, chartVersion]);

  async function syncMetadata() {
    const x = await api.syncAlgoUniverse(0);
    alert(x.ok
      ? `NSE cash metadata refreshed: ${x.body.synced} instruments. No live subscriptions were created.`
      : `Metadata sync failed${x.body?.stage ? ` [${x.body.stage}]` : ""}: ${x.body?.error || "Unknown error"}`);
    d.reload();
  }

  return <div className="page">
    <div className="page__header"><h2 className="page__title">Live Auto</h2><p className="page__subtitle">हर candle बंद होने पर आपकी Pine शर्त से स्कैन, और शर्त मिलने पर ऑटो ट्रेड (LIVE)।</p></div>
    {stopActive && <div className="card" role="alert"><strong>Emergency stop चालू है:</strong> कोई LIVE ऑर्डर नहीं जाएगा। Risk पेज से हटाएँ।</div>}
    {live.error && <p className="form-error" role="alert">{live.error}</p>}

    <div className="metrics-grid">
      <div className="card"><strong>अगली candle बंद</strong><h2>{left === null ? "—" : left <= 0 ? "स्कैन…" : formatCountdown(left)}</h2></div>
      <div className="card"><strong>आज के signals</strong><h2>{data?.signals_today ?? "—"}</h2></div>
      <div className="card"><strong>Auto-trade चालू</strong><h2>{data?.armed_count ?? "—"}</h2></div>
      <div className="card"><strong>LIVE readiness</strong><h2>{ready.body?.ready ? "READY" : "BLOCKED"}</h2></div>
    </div>

    <div className="card">
      <div className="card__head"><h3 className="card__title">Strategies</h3></div>
      {!live.loading && strategies.length === 0 && <p className="form-hint">अभी कोई strategy नहीं है। Strategies पेज के Custom rules में Pine Script डालकर बनाएँ।</p>}
      {strategies.map((s) => (
        <div key={s.version_id} style={{ padding: "10px 0", borderTop: "1px solid rgba(128,128,128,0.2)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
            <div><strong>{s.name}</strong> v{s.version} <span className="form-hint">{s.timeframe} · {s.side}</span></div>
            <button type="button" onClick={() => toggle(s)} disabled={!!busy || s.status === "INVALID"} aria-pressed={s.armed}>
              {busy === `t${s.version_id}` ? "…" : s.armed ? "Auto-trade: चालू" : "Auto-trade: बंद"}
            </button>
          </div>
          <div className="form-hint">शर्त: {s.entry_summary || "—"}</div>
          {s.exit_summary && <div className="form-hint">Exit: {s.exit_summary}</div>}
          <div className="form-hint">{s.last_scan
            ? `आख़िरी स्कैन ${hhmm(s.last_scan.bar_at)} · ${s.last_scan.evaluated ?? 0}/${s.last_scan.universe ?? 0} जाँचे · शर्त मिली ${s.last_scan.matched ?? 0}${s.last_scan.duration_ms != null ? ` · ${(s.last_scan.duration_ms / 1000).toFixed(1)}s` : ""}${s.last_scan.status && s.last_scan.status !== "OK" ? ` · ${s.last_scan.status}` : ""}`
            : "अभी कोई स्कैन नहीं हुआ"}</div>
        </div>
      ))}
      {msg && <p className="form-hint" role="status" aria-live="polite">{msg}</p>}
    </div>

    <div className="card">
      <div className="card__head"><h3 className="card__title">ताज़ा signals</h3></div>
      {signals.length === 0 && <p className="form-hint">अभी कोई signal नहीं।</p>}
      {signals.map((x) => (
        <button key={x.id} type="button" onClick={() => setPick({ segment: x.exchange_segment, token: x.instrument_token, label: x.symbol })}
          style={{ display: "flex", width: "100%", justifyContent: "space-between", gap: 8, textAlign: "left" }}>
          <span><strong>{x.symbol}</strong> {x.side}</span>
          <span>{x.price != null ? Number(x.price).toFixed(2) : "—"} · {x.status} · {hhmm(x.candle_at || x.created_at)}</span>
        </button>
      ))}
    </div>

    <div className="card">
      <div className="card__head"><h3 className="card__title">चार्ट{target?.label ? `: ${target.label}` : ""} ({chartTf})</h3></div>
      {target ? <LiveChart data={chart.body} /> : <p className="form-hint">किसी signal पर दबाएँ, या नीचे instrument token लिखें।</p>}
      {chart.error && <p className="form-error" role="alert">{chart.error}</p>}
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <input aria-label="Instrument token" inputMode="numeric" value={tokenText} onChange={(e) => setTokenText(e.target.value)} placeholder="Instrument token (NSE cash)" style={{ flex: 1 }} />
        <button type="button" disabled={!tokenText.trim()} onClick={() => setPick({ segment: "nse_cm", token: tokenText.trim(), label: tokenText.trim() })}>खोलें</button>
      </div>
    </div>

    <details className="card">
      <summary>Advanced: runtime और metadata</summary>
      <div className="metrics-grid">
        <div className="card"><strong>Runtime</strong><h2>{r?.status || "—"}</h2></div>
        <div className="card"><strong>Strategies</strong><h2>{r?.active_strategy_count ?? 0}</h2></div>
        <div className="card"><strong>Scrip metadata</strong><h2>{r?.universe_count ?? 0}</h2></div>
      </div>
      <button onClick={syncMetadata}>Refresh NSE Cash Metadata</button>
      <p className="form-hint">This downloads the official NSE cash scrip master into the instrument database only. It does not subscribe the entire market. LIVE strategies subscribe only their explicit instrument-token universe when armed.</p>
      <h3 className="card__title">Execution path</h3>
      <p>Selected market data → completed candles → indicators → scanner → strategy → signal → risk → Kotak order → fill reconciliation → position → exit.</p>
      <p className="form-hint">Backtest is historical-only; executable orders use the official Kotak path.</p>
    </details>

    <div style={{ position: "sticky", bottom: 8, marginTop: 12 }}>
      <button type="button" onClick={emergencyStop} disabled={!!busy || stopActive}
        style={{ width: "100%", padding: "12px", fontWeight: 700, background: "#c0392b", color: "#fff", border: "none", borderRadius: 8 }}>
        {stopActive ? "Emergency stop चालू है" : "सब रोकें (Emergency stop)"}
      </button>
    </div>
  </div>;
}
