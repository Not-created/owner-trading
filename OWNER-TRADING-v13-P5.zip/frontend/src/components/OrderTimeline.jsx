import { useEffect, useState } from "react";
import { api } from "../api/client";
import { toneColor, sourceLabel, timelineHeadline, brokerHistoryRows } from "../lib/orderTimeline";

/** Story of one order, from the local database (works even when the broker is disconnected). Loads once; no polling. */
export default function OrderTimeline({ internalOrderId }) {
  const [state, setState] = useState({ loading: true, error: "", data: null });
  const [broker, setBroker] = useState(null);   // null | {loading} | {error} | {rows}

  async function load() {
    setState((s) => ({ ...s, loading: true, error: "" }));
    const r = await api.getOrderTimeline(internalOrderId);
    setState(r.ok ? { loading: false, error: "", data: r.body } : { loading: false, error: r.body?.error || `HTTP ${r.status || "?"}`, data: null });
  }
  useEffect(() => { load(); setBroker(null); }, [internalOrderId]); // eslint-disable-line react-hooks/exhaustive-deps

  async function loadBroker() {
    setBroker({ loading: true });
    const r = await api.getBrokerOrderHistory(internalOrderId);
    setBroker(r.ok ? { rows: brokerHistoryRows(r.body) } : { error: r.body?.error || "Kotak से इतिहास नहीं मिल सका।" });
  }

  const { loading, error, data } = state;
  return (
    <div style={{ padding: "8px 4px" }}>
      {loading && <p className="form-hint">Timeline लोड हो रही है…</p>}
      {!loading && error && <p className="form-error" role="alert">{error}</p>}
      {data && (
        <>
          <p style={{ margin: "0 0 8px", fontWeight: 600 }}>{timelineHeadline(data.order)}</p>
          <ol style={{ listStyle: "none", margin: 0, padding: 0 }}>
            {data.steps.map((s, i) => (
              <li key={i} style={{ display: "flex", gap: 10, padding: "6px 0", borderLeft: "2px solid rgba(128,128,128,0.25)", marginLeft: 5, paddingLeft: 12, position: "relative" }}>
                <span style={{ position: "absolute", left: -6, top: 10, width: 10, height: 10, borderRadius: "50%", background: toneColor(s.tone) }} />
                <div>
                  <div><strong>{s.title}</strong> <span className="form-hint">{s.shown_at || ""}</span></div>
                  {s.detail && <div>{s.detail}</div>}
                  <div className="form-hint">{sourceLabel(s)}</div>
                </div>
              </li>
            ))}
          </ol>
        </>
      )}
      <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
        <button type="button" onClick={load} disabled={loading}>रीफ़्रेश</button>
        <button type="button" onClick={loadBroker} disabled={broker?.loading}>{broker?.loading ? "Kotak से ला रहा है…" : "Kotak से ताज़ा इतिहास"}</button>
      </div>
      {broker?.error && <p className="form-error" role="alert">{broker.error}</p>}
      {broker?.rows && (broker.rows.length === 0
        ? <p className="form-hint">Kotak ने कोई इतिहास नहीं दिया।</p>
        : <div className="form-hint" style={{ marginTop: 6 }}><strong>Kotak का इतिहास:</strong>{broker.rows.map((r, i) => <div key={i}>{r.status}{r.detail ? ` · ${r.detail}` : ""}</div>)}</div>)}
    </div>
  );
}
