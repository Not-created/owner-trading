import { useState } from "react";
import { api } from "../api/client";
import { pineApplyPatch, pineStatus, pineProblemRows } from "../lib/pineImport";

const SAMPLE = `//@version=5
strategy("EMA + RSI")
f = ta.ema(close, 20)
s = ta.ema(close, 50)
r = ta.rsi(close, 14)
buy = ta.crossover(f, s) and r > 55`;

/** Paste Pine Script -> check -> load the conditions into the strategy builder below. Nothing is saved or traded here. */
export default function PinePanel({ onApply }) {
  const [source, setSource] = useState("");
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [applied, setApplied] = useState(false);

  async function check(extra = {}) {
    if (busy) return;
    setBusy(true); setErr(""); setApplied(false);
    try {
      const r = await api.translatePine({ source, ...extra });
      if (!r.ok) { setRes(null); setErr(r.body?.error || "जाँच नहीं हो सकी।"); return; }
      setRes({ ...r.body, _extra: extra });
    } finally { setBusy(false); }
  }
  const patch = pineApplyPatch(res);
  function apply(p) { onApply(p); setApplied(true); }

  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <div className="card__head"><h3 className="card__title">Pine Script से शर्त</h3></div>
      <div className="form-hint">Pine Script यहाँ डालें, "जाँचें" दबाएँ। जो हिस्सा समझ नहीं आएगा वह साफ़ बताया जाएगा और ऐसी Script लागू नहीं होगी। यहाँ कुछ save या ट्रेड नहीं होता।</div>
      <textarea aria-label="Pine Script" value={source} onChange={(e) => { setSource(e.target.value); setRes(null); setApplied(false); }}
        rows={8} spellCheck={false} placeholder={SAMPLE} style={{ width: "100%", fontFamily: "monospace", fontSize: 13, marginTop: 8 }} />
      <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
        <button type="button" onClick={() => check()} disabled={busy || !source.trim()}>{busy ? "जाँच रहा है…" : "जाँचें"}</button>
        {!source.trim() && <button type="button" onClick={() => setSource(SAMPLE)}>नमूना डालें</button>}
      </div>
      {err && <p className="form-hint" role="alert">{err}</p>}
      {res && (
        <div style={{ marginTop: 10 }} aria-live="polite">
          <p style={{ margin: "4px 0", fontWeight: 600 }}>{res.ok ? "✓ " : "✗ "}{pineStatus(res)}</p>
          {res.ok && <div className="form-hint">
            <div><strong>{res.definition.side}</strong> शर्त: {res.entry_summary}</div>
            {res.exit_summary && <div>Exit: {res.exit_summary}</div>}
            <div>स्रोत: {res.entry_source}</div>
          </div>}
          {res.need_choice && <div style={{ display: "grid", gap: 6, marginTop: 6 }}>
            {(res.choices || []).map((c) => <button key={c.name} type="button" onClick={() => check({ entry: c.name })} style={{ textAlign: "left" }}>
              <strong>{c.name}</strong>: {c.summary}</button>)}
          </div>}
          {pineProblemRows(res).length > 0 && <div className="form-hint" style={{ marginTop: 6 }}>
            <strong>समझ नहीं आए:</strong>{pineProblemRows(res).map((t, i) => <div key={i}>{t}</div>)}</div>}
          {(res.notes || []).map((n, i) => <div key={i} className="form-hint">{n}</div>)}
          {res.ok && res.other_sides?.length > 0 && <div className="form-hint">इसमें {res.other_sides.map((o) => o.side).join(", ")} की शर्त भी है। उसे अलग strategy में लेने के लिए नीचे का बटन दबाएँ।
            <div style={{ marginTop: 4 }}>{res.other_sides.map((o) => <button key={o.side} type="button" onClick={() => check({ ...(res._extra || {}), side: o.side })}>{o.side} वाली लें</button>)}</div></div>}
          {patch && <div style={{ marginTop: 8 }}>
            <button type="button" onClick={() => apply(patch)}>Builder में लगाएँ</button>
            {applied && <span className="form-hint"> लग गया। नीचे Entry/Exit देखें, Stop-loss और बाकी जाँचकर Save करें।</span>}
            <div className="form-hint">{res.accuracy_note}</div>
          </div>}
        </div>
      )}
    </div>
  );
}
