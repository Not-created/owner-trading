import { chartGeometry } from "../lib/liveScreen";

const LINE_COLORS = ["#378ADD", "#BA7517", "#7F77DD", "#1D9E75"];
const UP = "#2e9d5b";
const DOWN = "#d1453b";

/** Small SVG candle chart: candles, the indicator lines the strategy uses, and BUY/SELL signal markers. No chart library. */
export default function LiveChart({ data }) {
  const g = chartGeometry(data, { w: 340, h: 210 });
  if (!g) return <p className="form-hint">इस stock के लिए अभी candles उपलब्ध नहीं हैं।</p>;
  return (
    <div>
      <svg viewBox="0 0 340 210" width="100%" role="img" aria-label={`${data.timeframe} candle चार्ट, indicator लाइनें और BUY/SELL निशान`}>
        {g.ticks.map((t, i) => (
          <g key={i}>
            <line x1="4" x2="294" y1={t.y} y2={t.y} stroke="currentColor" opacity="0.12" strokeWidth="1" />
            <text x="298" y={t.y + 3} fontSize="9" fill="currentColor" opacity="0.7">{t.label}</text>
          </g>
        ))}
        {g.candles.map((c, i) => {
          const col = c.up ? UP : DOWN;
          return (
            <g key={i}>
              <line x1={c.x} x2={c.x} y1={c.yH} y2={c.yL} stroke={col} strokeWidth="1" />
              <rect x={c.x - g.bodyW / 2} y={Math.min(c.yO, c.yC)} width={g.bodyW} height={Math.max(1.2, Math.abs(c.yO - c.yC))} fill={col} />
            </g>
          );
        })}
        {g.lines.map((l, i) => <path key={l.name} d={l.d} fill="none" stroke={LINE_COLORS[i % LINE_COLORS.length]} strokeWidth="1.5" />)}
        {g.markers.map((m, i) => (
          <g key={i}>
            <polygon points={m.side === "BUY" ? `${m.x},${m.y - 5} ${m.x - 5},${m.y + 4} ${m.x + 5},${m.y + 4}` : `${m.x},${m.y + 5} ${m.x - 5},${m.y - 4} ${m.x + 5},${m.y - 4}`}
              fill={m.side === "BUY" ? UP : DOWN} />
          </g>
        ))}
      </svg>
      <div className="form-hint" style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        {g.lines.map((l, i) => <span key={l.name}><span style={{ display: "inline-block", width: 10, height: 2, background: LINE_COLORS[i % LINE_COLORS.length], verticalAlign: "middle" }} /> {l.name}</span>)}
        <span>▲ BUY / ▼ SELL निशान</span>
      </div>
    </div>
  );
}
