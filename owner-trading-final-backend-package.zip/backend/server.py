from __future__ import annotations

import asyncio, hashlib, json, logging, os, re, secrets, time, uuid
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from cryptography.fernet import Fernet
try:
    import bcrypt
except Exception:
    bcrypt = None
try:
    import jwt
except Exception:
    jwt = None
import base64, hmac

try:
    from motor.motor_asyncio import AsyncIOMotorClient
except Exception:
    AsyncIOMotorClient = None

try:
    from neo_api_client import NeoAPI
except Exception:
    try:
        from kotakneoapi import NeoAPI
    except Exception:
        NeoAPI = None

try:
    import yfinance as yf
except Exception:
    yf = None

load_dotenv(os.getenv("OWNER_TRADING_ENV", os.path.join(os.path.dirname(__file__), ".env")))

# -----------------------------------------------------------------------------
# CONFIG / SECURITY
# -----------------------------------------------------------------------------
APP_NAME = "Owner Trading"
JWT_SECRET = os.getenv("JWT_SECRET", "")
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "")
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "owner_trading_db")
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "")
OWNER_PASSWORD = os.getenv("OWNER_PASSWORD", "")
OWNER_EMAIL = os.getenv("OWNER_EMAIL", "")
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost")
CORS_ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", FRONTEND_URL).split(",") if x.strip()]
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
COOKIE_SAMESITE = os.getenv("COOKIE_SAMESITE", "lax").lower()
SESSION_COOKIE = "owner_trading_session"
ACCESS_HOURS = int(os.getenv("ACCESS_TOKEN_HOURS", "12"))

if ENCRYPTION_KEY:
    try:
        FERNET = Fernet(ENCRYPTION_KEY.encode())
    except Exception as exc:
        raise RuntimeError("ENCRYPTION_KEY is not a valid Fernet key") from exc
else:
    FERNET = None

if not JWT_SECRET and os.getenv("ENVIRONMENT", "production").lower() == "production":
    raise RuntimeError("JWT_SECRET is required in production")

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("owner-trading")

app = FastAPI(title=APP_NAME, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS or [FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

mongo = None
_db = None
BROKER_SESSIONS: dict[str, dict[str, Any]] = {}
RATE_BUCKETS: dict[str, list[float]] = {}
CONTROL = {"trading_enabled": True, "strategy_enabled": True, "orders_enabled": True, "kill_switch": False, "reason": ""}
DEFAULT_RISK = {
    "enabled": True, "maxOrderQuantity": None, "maxPositionQuantity": None,
    "maxDailyLoss": None, "maxDrawdown": None, "maxOpenPositions": None,
    "stopLossRequired": False, "targetRequired": False,
}

# -----------------------------------------------------------------------------
# COMMON HELPERS
# -----------------------------------------------------------------------------
def now(): return datetime.now(timezone.utc)
def iso(v=None): return (v or now()).isoformat()
def rid(): return uuid.uuid4().hex

def clean(obj):
    if isinstance(obj, dict): return {k: clean(v) for k, v in obj.items() if k not in {"_id", "password_hash", "credentials"}}
    if isinstance(obj, list): return [clean(x) for x in obj]
    if isinstance(obj, datetime): return obj.isoformat()
    return obj

def enc(v):
    if not FERNET: raise HTTPException(503, "Server encryption is not configured.")
    return FERNET.encrypt(str(v).encode()).decode()

def dec(v):
    if not FERNET: raise HTTPException(503, "Server encryption is not configured.")
    return FERNET.decrypt(str(v).encode()).decode()

def body_data(data):
    if isinstance(data, dict) and isinstance(data.get("data"), dict): return data["data"]
    return data if isinstance(data, dict) else {}

def list_data(data):
    if isinstance(data, dict):
        for k in ("data", "items", "results", "orders", "positions", "holdings", "trades", "accounts"):
            if isinstance(data.get(k), list): return data[k]
    return data if isinstance(data, list) else []

def broker_ok(data):
    if not isinstance(data, dict): return True
    if "Error" in data or "error" in data: return False
    if str(data.get("stat", "")).lower() in {"not ok", "error", "failed"}: return False
    return True

def require_fields(d, *names):
    for n in names:
        if d.get(n) in (None, "", []): raise HTTPException(422, f"{n} is required")

def normalize_exchange(v):
    m = {"NSE":"nse_cm", "BSE":"bse_cm", "NFO":"nse_fo", "BFO":"bse_fo", "MCX":"mcx_fo"}
    return m.get(str(v or "").upper(), str(v or "").lower())

def normalize_order_type(v):
    m = {"MARKET":"MKT", "LIMIT":"L", "SL-M":"SL-M", "SL":"SL", "MKT":"MKT", "L":"L"}
    return m.get(str(v or "").upper(), str(v or "").upper())

def normalize_side(v): return "B" if str(v or "").upper() == "BUY" else "S" if str(v or "").upper() == "SELL" else str(v or "").upper()

def oid(doc): return str(doc.get("id") or doc.get("_id") or "")

def hash_password(password):
    if bcrypt:
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    salt=secrets.token_bytes(16); digest=hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240000)
    return "pbkdf2$240000$"+base64.urlsafe_b64encode(salt).decode()+"$"+base64.urlsafe_b64encode(digest).decode()

def check_password(password, hashed):
    try:
        if hashed.startswith("$2") and bcrypt:
            return bcrypt.checkpw(password.encode(), hashed.encode())
        if hashed.startswith("pbkdf2$"):
            _, rounds, salt_b64, digest_b64 = hashed.split("$",3)
            salt=base64.urlsafe_b64decode(salt_b64.encode()); expected=base64.urlsafe_b64decode(digest_b64.encode())
            actual=hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(rounds))
            return hmac.compare_digest(actual, expected)
    except Exception: pass
    return False

def token_for(user):
    if jwt is None: raise HTTPException(503,"PyJWT is not installed on the server.")
    payload = {"sub": str(user["id"]), "role": user.get("role", "owner"), "exp": now() + timedelta(hours=ACCESS_HOURS)}
    return jwt.encode(payload, JWT_SECRET or "dev-only-secret", algorithm="HS256")

def audit(action, user_id=None, account_id=None, status="ok", detail=None):
    asyncio.create_task(insert("audit_logs", {"id": rid(), "user_id": user_id, "account_id": account_id, "action": action, "status": status, "detail": clean(detail), "created_at": now()}))

async def insert(coll, doc):
    if _db is None: return doc
    await _db[coll].insert_one(doc)
    return doc

async def find_one(coll, query):
    if _db is None: return None
    return await _db[coll].find_one(query)

async def find_many(coll, query=None, limit=500):
    if _db is None: return []
    return await _db[coll].find(query or {}).sort("created_at", -1).to_list(length=limit)

async def update_one(coll, query, update, upsert=False):
    if _db is None: return None
    return await _db[coll].update_one(query, update, upsert=upsert)

async def delete_one(coll, query):
    if _db is None: return None
    return await _db[coll].delete_one(query)

async def current_user(request: Request):
    raw = request.cookies.get(SESSION_COOKIE)
    if not raw: raise HTTPException(401, "Authentication required.")
    try:
        if jwt is None: raise HTTPException(503,"PyJWT is not installed on the server.")
        payload = jwt.decode(raw, JWT_SECRET or "dev-only-secret", algorithms=["HS256"])
        user = await find_one("users", {"id": payload["sub"]})
        if not user: raise HTTPException(401, "Authentication required.")
        return user
    except HTTPException: raise
    except Exception: raise HTTPException(401, "Authentication required.")

def owner_only(user):
    if user.get("role") not in {"owner", "super_admin", "admin"}: raise HTTPException(403, "Owner permission required.")

async def account_for(user, account_id=None):
    q = {"user_id": user["id"]}
    if account_id: q["id"] = str(account_id)
    account = await find_one("broker_accounts", q)
    if not account: raise HTTPException(404, "Broker account not found.")
    return account

def rate_limit(request: Request, key="global", max_calls=60, window=60):
    client = request.client.host if request.client else "unknown"
    k = f"{client}:{key}"; t = time.time(); arr = [x for x in RATE_BUCKETS.get(k, []) if x > t-window]
    if len(arr) >= max_calls: raise HTTPException(429, "Too many requests. Try again later.")
    arr.append(t); RATE_BUCKETS[k] = arr

# -----------------------------------------------------------------------------
# KOTAK NEO ADAPTER — ACCOUNT SCOPED, REAL DATA ONLY
# -----------------------------------------------------------------------------
def make_kotak(credentials):
    if NeoAPI is None: raise HTTPException(503, "Kotak Neo SDK is not installed on the server.")
    try:
        return NeoAPI(consumer_key=credentials["consumer_key"], environment="prod", access_token=None, neo_fin_key=None)
    except TypeError:
        return NeoAPI(consumer_key=credentials["consumer_key"], environment="prod")

def kotak_call(client, method, **kwargs):
    fn = getattr(client, method, None)
    if not callable(fn): raise RuntimeError(f"Kotak SDK method '{method}' is unavailable")
    result = fn(**kwargs)
    if not broker_ok(result): raise RuntimeError(str(result.get("Error") or result.get("error") or result))
    return result

async def kotak_login(account, credentials, totp=None):
    if not totp: raise HTTPException(422, "A fresh 6-digit TOTP is required to connect Kotak Neo.")
    client = make_kotak(credentials)
    try:
        await asyncio.to_thread(kotak_call, client, "totp_login", mobile_number=credentials["mobile_number"], mobilenumber=credentials["mobile_number"], ucc=credentials["ucc"], totp=totp)
    except TypeError:
        await asyncio.to_thread(kotak_call, client, "totp_login", mobilenumber=credentials["mobile_number"], ucc=credentials["ucc"], totp=totp)
    await asyncio.to_thread(kotak_call, client, "totp_validate", mpin=credentials["mpin"])
    BROKER_SESSIONS[account["id"]] = {"client": client, "connected_at": now(), "last_used": now()}
    return client

async def broker_client(account):
    session = BROKER_SESSIONS.get(account["id"])
    if not session: raise HTTPException(409, "Kotak Neo account is not connected. A fresh TOTP connection is required.")
    session["last_used"] = now(); return session["client"]

async def broker_data(account, method, **kwargs):
    client = await broker_client(account)
    try: return await asyncio.to_thread(kotak_call, client, method, **kwargs)
    except HTTPException: raise
    except Exception as exc:
        log.exception("Broker operation failed")
        raise HTTPException(502, f"Kotak Neo operation failed: {exc}")

# -----------------------------------------------------------------------------
# STARTUP / HEALTH
# -----------------------------------------------------------------------------
@app.on_event("startup")
async def startup():
    global mongo, _db
    if AsyncIOMotorClient is None:
        log.error("Motor is not installed; database unavailable")
        return
    try:
        mongo = AsyncIOMotorClient(MONGO_URL, serverSelectionTimeoutMS=4000)
        await mongo.admin.command("ping")
        _db = mongo[DB_NAME]
        await _db.users.create_index("id", unique=True)
        await _db.broker_accounts.create_index([("user_id", 1), ("id", 1)], unique=True)
        await _db.orders.create_index([("user_id", 1), ("account_id", 1), ("created_at", -1)])
        await _db.positions.create_index([("user_id", 1), ("account_id", 1)])
        await _db.strategies.create_index([("user_id", 1), ("id", 1)], unique=True)
        await _db.audit_logs.create_index([("user_id", 1), ("created_at", -1)])
        if OWNER_USERNAME and OWNER_PASSWORD:
            existing = await find_one("users", {"username": OWNER_USERNAME})
            if not existing:
                await insert("users", {"id": rid(), "username": OWNER_USERNAME, "email": OWNER_EMAIL, "password_hash": hash_password(OWNER_PASSWORD), "role":"owner", "created_at": now(), "updated_at": now()})
            elif not check_password(OWNER_PASSWORD, existing.get("password_hash", "")):
                await update_one("users", {"id": existing["id"]}, {"$set":{"password_hash":hash_password(OWNER_PASSWORD), "updated_at":now()}})
        log.info("Owner Trading backend ready")
    except Exception:
        _db = None
        log.exception("Database unavailable; backend is running in degraded state")

@app.on_event("shutdown")
async def shutdown():
    global mongo
    if mongo: mongo.close()

@app.get("/api/health")
async def health():
    db_ok = False
    if _db is not None:
        try: await mongo.admin.command("ping"); db_ok = True
        except Exception: pass
    return {"status":"ok" if db_ok else "degraded", "database": db_ok, "broker_sessions": len(BROKER_SESSIONS), "timestamp": iso()}

# -----------------------------------------------------------------------------
# AUTH / PROFILE / SETTINGS
# -----------------------------------------------------------------------------
@app.post("/api/auth/login")
async def login(request: Request, response: Response):
    rate_limit(request, "login", 10, 900)
    d = body_data(await request.json()); username = d.get("login") or d.get("username") or d.get("email"); password = d.get("password") or ""
    if not username or not password: raise HTTPException(422, "Login and password are required.")
    user = await find_one("users", {"username": username}) or await find_one("users", {"email": username})
    if not user or not check_password(password, user.get("password_hash", "")):
        raise HTTPException(401, "Invalid login credentials.")
    token = token_for(user)
    response.set_cookie(SESSION_COOKIE, token, httponly=True, secure=COOKIE_SECURE, samesite=COOKIE_SAMESITE, max_age=ACCESS_HOURS*3600, path="/")
    audit("auth.login", user["id"])
    return {"success": True, "user": clean(user)}

@app.get("/api/auth/me")
async def me(request: Request):
    return {"success": True, "user": clean(await current_user(request))}

@app.post("/api/auth/logout")
async def logout(request: Request, response: Response):
    try: user = await current_user(request); audit("auth.logout", user["id"])
    except Exception: pass
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"success": True}

@app.get("/api/profile")
async def profile(request: Request): return {"success":True, "data":clean(await current_user(request))}

@app.put("/api/profile")
async def profile_update(request: Request):
    user = await current_user(request); d = body_data(await request.json()); allowed = {"name","first_name","last_name","email","phone","timezone"}; patch={k:v for k,v in d.items() if k in allowed and v not in (None,"")}
    if patch: patch["updated_at"] = now(); await update_one("users", {"id":user["id"]}, {"$set":patch})
    return {"success":True,"data":clean(await find_one("users", {"id":user["id"]}))}

@app.get("/api/settings")
async def settings_get(request: Request):
    user=await current_user(request); doc=await find_one("settings", {"user_id":user["id"]}); return {"success":True,"data":clean(doc or {})}

@app.put("/api/settings")
async def settings_update(request: Request):
    user=await current_user(request); d=body_data(await request.json()); safe={k:v for k,v in d.items() if k not in {"password","consumer_key","mpin","totp","api_key","secret"}}; safe["updated_at"]=now(); await update_one("settings", {"user_id":user["id"]},{"$set":safe,"$setOnInsert":{"id":rid(),"user_id":user["id"]}}, upsert=True); return {"success":True,"data":clean(safe)}

# -----------------------------------------------------------------------------
# BROKER ACCOUNTS / KOTAK DATA
# -----------------------------------------------------------------------------
@app.get("/api/brokers/plugins")
async def broker_plugins(request: Request):
    await current_user(request)
    return {"success":True,"data":[{"id":"kotak_neo","plugin_id":"kotak_neo","name":"Kotak Neo","enabled":True,"status":"available","credentials":["consumer_key","mobile_number","ucc","totp","mpin"]}]}

@app.get("/api/brokers/accounts")
async def accounts(request: Request):
    user=await current_user(request); return {"success":True,"data":clean(await find_many("broker_accounts", {"user_id":user["id"]}))}

@app.post("/api/brokers/accounts")
async def create_account(request: Request):
    user=await current_user(request); d=body_data(await request.json()); require_fields(d,"consumer_key","mobile_number","ucc","totp","mpin");
    if d.get("broker", "kotak_neo") != "kotak_neo": raise HTTPException(400,"Only Kotak Neo is currently enabled.")
    account={"id":rid(),"user_id":user["id"],"broker":"kotak_neo","name":d.get("name") or "Kotak Neo","status":"CONNECTING","connected":False,"created_at":now(),"updated_at":now(),"credentials":{"consumer_key":enc(d["consumer_key"]),"mobile_number":enc(d["mobile_number"]),"ucc":enc(d["ucc"]),"mpin":enc(d["mpin"])}}
    await insert("broker_accounts",account)
    creds={k:dec(v) for k,v in account["credentials"].items()}
    try:
        await kotak_login(account, creds, d["totp"])
    except Exception as exc:
        await update_one("broker_accounts", {"id":account["id"]},{"$set":{"status":"AUTH_FAILED","connected":False,"updated_at":now()}})
        raise HTTPException(502, f"Kotak Neo authentication failed: {getattr(exc,'detail',str(exc))}")
    await update_one("broker_accounts", {"id":account["id"]},{"$set":{"status":"CONNECTED","connected":True,"connected_at":now(),"updated_at":now()}})
    audit("broker.connect",user["id"],account["id"])
    return {"success":True,"data":clean(await find_one("broker_accounts", {"id":account["id"]}))}

@app.put("/api/brokers/accounts/{account_id}")
async def update_account(account_id: str, request: Request):
    user=await current_user(request); account=await account_for(user,account_id); d=body_data(await request.json()); patch={}
    if d.get("name"): patch["name"]=d["name"]
    for key in ("consumer_key","mobile_number","ucc","mpin"):
        if d.get(key): patch.setdefault("credentials",{})[key]=enc(d[key])
    if patch: patch["updated_at"]=now(); await update_one("broker_accounts", {"id":account_id},{"$set":patch})
    return {"success":True,"data":clean(await find_one("broker_accounts", {"id":account_id}))}

@app.delete("/api/brokers/accounts/{account_id}")
async def delete_account(account_id: str, request: Request):
    user=await current_user(request); await account_for(user,account_id); BROKER_SESSIONS.pop(account_id,None); await delete_one("broker_accounts", {"id":account_id,"user_id":user["id"]}); return {"success":True}

@app.post("/api/brokers/accounts/{account_id}/connect")
async def connect_account(account_id: str, request: Request):
    user=await current_user(request); account=await account_for(user,account_id); d=body_data(await request.json()) if request.headers.get("content-length") else {}
    totp=d.get("totp")
    if not totp: raise HTTPException(422,"Fresh TOTP is required to reconnect an existing Kotak session.")
    creds={k:dec(v) for k,v in account["credentials"].items()}; await kotak_login(account,creds,totp); await update_one("broker_accounts",{"id":account_id},{"$set":{"status":"CONNECTED","connected":True,"connected_at":now(),"updated_at":now()}}); return {"success":True,"data":clean(await find_one("broker_accounts",{"id":account_id}))}

@app.post("/api/brokers/accounts/{account_id}/disconnect")
async def disconnect_account(account_id: str, request: Request):
    user=await current_user(request); account=await account_for(user,account_id); session=BROKER_SESSIONS.pop(account_id,None)
    if session:
        try: await asyncio.to_thread(session["client"].logout)
        except Exception: pass
    await update_one("broker_accounts",{"id":account_id},{"$set":{"status":"DISCONNECTED","connected":False,"updated_at":now()}}); return {"success":True}

@app.post("/api/brokers/accounts/{account_id}/test")
async def test_connection(account_id: str, request: Request):
    user=await current_user(request); account=await account_for(user,account_id); await broker_data(account,"order_report"); return {"success":True,"data":{"connected":True,"broker":"kotak_neo"}}

@app.get("/api/brokers/accounts/{account_id}/info")
async def account_info(account_id: str, request: Request):
    user=await current_user(request); account=await account_for(user,account_id); data=await broker_data(account,"limits",segment="ALL",exchange="ALL",product="ALL"); return {"success":True,"data":clean(data)}

async def selected_account(request, account_id=None):
    user=await current_user(request); header=request.headers.get("X-Broker-Account"); q=request.query_params.get("account_id"); return user, await account_for(user, account_id or header or q)

@app.get("/api/brokers/accounts/info")
async def primary_account_info(request: Request):
    user=await current_user(request); account=await account_for(user); data=await broker_data(account,"limits",segment="ALL",exchange="ALL",product="ALL"); return {"success":True,"data":clean(data)}

@app.get("/api/brokers/funds")
async def funds(request: Request):
    user,account=await selected_account(request); data=await broker_data(account,"limits",segment="ALL",exchange="ALL",product="ALL"); return {"success":True,"data":clean(data)}

@app.get("/api/brokers/positions")
async def positions(request: Request):
    user,account=await selected_account(request); data=await broker_data(account,"positions"); return {"success":True,"data":list_data(data)}

@app.get("/api/brokers/holdings")
async def holdings(request: Request):
    user,account=await selected_account(request); data=await broker_data(account,"holdings"); return {"success":True,"data":list_data(data)}

@app.get("/api/brokers/orders")
async def broker_orders(request: Request):
    user,account=await selected_account(request); data=await broker_data(account,"order_report"); return {"success":True,"data":list_data(data)}

@app.get("/api/brokers/trade-history")
async def trade_history(request: Request):
    user,account=await selected_account(request); data=await broker_data(account,"trade_report"); return {"success":True,"data":list_data(data)}

@app.get("/api/positions")
async def positions_alias(request: Request): return await positions(request)

@app.get("/api/holdings")
async def holdings_alias(request: Request): return await holdings(request)

@app.get("/api/market/quotes")
async def market_quotes_alias(request: Request): return await quotes(request)

@app.get("/api/brokers/quotes")
async def quotes(request: Request):
    user=await current_user(request); account_id=request.query_params.get("account_id") or request.headers.get("X-Broker-Account"); account=await account_for(user,account_id)
    symbols=request.query_params.getlist("symbol")
    if not symbols: raise HTTPException(422,"At least one symbol is required for a real quote request.")
    client=await broker_client(account); results=[]
    for symbol in symbols:
        resolved=None
        for meth in ("search_scrip","scrip_search"):
            try:
                r=await asyncio.to_thread(kotak_call,client,meth,exchange_segment="nse_cm",symbol=symbol.upper())
                candidates=list_data(r); resolved=candidates[0] if candidates else body_data(r); break
            except Exception: continue
        token=(resolved or {}).get("pSymbol") or (resolved or {}).get("tok") or (resolved or {}).get("instrument_token")
        trading=(resolved or {}).get("pTrdSymbol") or (resolved or {}).get("trdSym") or f"{symbol.upper()}-EQ"
        if not token: raise HTTPException(502,f"Kotak could not resolve symbol {symbol}.")
        q=await broker_data(account,"quotes",instrument_tokens=[{"instrument_token":str(token),"exchange_segment":"nse_cm"}],quote_type="all")
        results.append({"symbol":symbol.upper(),"trading_symbol":trading,"source":"kotak_neo","data":body_data(q)})
    return {"success":True,"data":results}

# -----------------------------------------------------------------------------
# ORDERS — REAL BROKER EXECUTION WITH RISK / KILL SWITCH / OWNERSHIP
# -----------------------------------------------------------------------------
async def risk_check(user, account_id, d):
    if CONTROL["kill_switch"] or not CONTROL["trading_enabled"] or not CONTROL["orders_enabled"]: raise HTTPException(423,"Trading is disabled by Owner Control.")
    cfg=await find_one("risk",{"user_id":user["id"],"account_id":account_id}) or DEFAULT_RISK.copy()
    qty=int(d.get("quantity") or 0)
    if qty<=0: raise HTTPException(422,"Quantity must be positive.")
    if cfg.get("maxOrderQuantity") is not None and qty>int(cfg["maxOrderQuantity"]): raise HTTPException(422,"Order exceeds maximum quantity risk limit.")
    if cfg.get("stopLossRequired") and str(d.get("orderType","")).upper() in {"MARKET","LIMIT","L","MKT"} and not d.get("stopLoss"): raise HTTPException(422,"Stop-loss is required by risk policy.")

async def create_real_order(user, account, d):
    await risk_check(user,account["id"],d); require_fields(d,"symbol","side","quantity")
    exchange=normalize_exchange(d.get("exchange","NSE")); product=str(d.get("product","CNC")).upper(); order_type=normalize_order_type(d.get("orderType","MARKET")); side=normalize_side(d.get("side")); validity=str(d.get("validity","DAY")).upper(); qty=str(int(d["quantity"])); price=str(d.get("price",0) or 0); trigger=str(d.get("triggerPrice",0) or 0)
    if order_type in {"L","SL"} and float(price)<=0: raise HTTPException(422,"Positive price is required for limit/SL orders.")
    if order_type in {"SL","SL-M"} and float(trigger)<=0: raise HTTPException(422,"Positive triggerPrice is required for stop-loss orders.")
    client=await broker_client(account)
    params={"exchange_segment":exchange,"product":product,"price":price,"order_type":order_type,"quantity":qty,"validity":validity,"trading_symbol":str(d["symbol"]).upper(),"transaction_type":side}
    if order_type in {"SL","SL-M"}: params["trigger_price"]=trigger
    result=await asyncio.to_thread(kotak_call,client,"place_order",**params)
    if not broker_ok(result): raise HTTPException(502,"Kotak rejected the order request.")
    broker_order=body_data(result); broker_id=broker_order.get("nOrdNo") or broker_order.get("order_id") or broker_order.get("orderId")
    if not broker_id: raise HTTPException(502,"Kotak accepted no identifiable order ID; order was not recorded as successful.")
    doc={"id":rid(),"broker_order_id":str(broker_id),"user_id":user["id"],"account_id":account["id"],"symbol":d["symbol"],"exchange":exchange,"side":side,"order_type":order_type,"quantity":int(qty),"price":float(price),"trigger_price":float(trigger),"product":product,"validity":validity,"status":"SUBMITTED","broker_response":clean(broker_order),"created_at":now(),"updated_at":now()}; await insert("orders",doc); audit("order.place",user["id"],account["id"],detail={"order_id":doc["id"],"broker_order_id":broker_id}); return doc

@app.get("/api/orders")
async def orders(request: Request):
    user=await current_user(request); q={"user_id":user["id"]}; aid=request.query_params.get("accountId") or request.query_params.get("account_id");
    if aid: q["account_id"]=aid
    docs=await find_many("orders",q); return {"success":True,"data":clean(docs)}

@app.post("/api/orders")
async def place_order(request: Request):
    user=await current_user(request); d=body_data(await request.json()); aid=d.get("accountId") or d.get("account_id") or request.headers.get("X-Broker-Account"); account=await account_for(user,aid); return {"success":True,"data":clean(await create_real_order(user,account,d))}

@app.put("/api/orders/{order_id}")
async def modify_order(order_id: str, request: Request):
    user=await current_user(request); d=body_data(await request.json()); aid=d.get("accountId") or d.get("account_id"); account=await account_for(user,aid); doc=await find_one("orders",{"id":order_id,"user_id":user["id"],"account_id":account["id"]});
    if not doc: raise HTTPException(404,"Order not found.")
    params={"order_id":doc["broker_order_id"],"price":str(d.get("price",doc["price"])),"order_type":normalize_order_type(d.get("orderType",doc["order_type"])),"quantity":str(int(d.get("quantity",doc["quantity"]))),"validity":str(d.get("validity",doc["validity"])).upper()}
    result=await broker_data(account,"modify_order",**params); await update_one("orders",{"id":order_id},{"$set":{"updated_at":now(),"broker_response":clean(result),"status":"MODIFICATION_SUBMITTED"}}); return {"success":True,"data":clean(await find_one("orders",{"id":order_id}))}

@app.delete("/api/orders/{order_id}")
async def cancel_order(order_id: str, request: Request):
    user=await current_user(request); aid=request.query_params.get("accountId") or request.query_params.get("account_id"); account=await account_for(user,aid); doc=await find_one("orders",{"id":order_id,"user_id":user["id"],"account_id":account["id"]});
    if not doc: raise HTTPException(404,"Order not found.")
    result=await broker_data(account,"cancel_order",order_id=doc["broker_order_id"]); await update_one("orders",{"id":order_id},{"$set":{"status":"CANCEL_SUBMITTED","updated_at":now(),"broker_response":clean(result)}}); return {"success":True,"data":clean(result)}

@app.get("/api/orders/{order_id}")
async def order_status(order_id: str, request: Request):
    user=await current_user(request); aid=request.query_params.get("accountId") or request.query_params.get("account_id"); account=await account_for(user,aid); doc=await find_one("orders",{"id":order_id,"user_id":user["id"],"account_id":account["id"]});
    if not doc: raise HTTPException(404,"Order not found.")
    result=await broker_data(account,"order_report",order_id=doc["broker_order_id"]); return {"success":True,"data":clean(result)}

# -----------------------------------------------------------------------------
# STRATEGIES — PERSISTED DEFINITIONS; LIVE RUN ONLY AFTER EXPLICIT DEPLOY/RUN
# -----------------------------------------------------------------------------
def validate_strategy(d):
    require_fields(d,"name","symbol","entryCondition","exitCondition")
    if not str(d["entryCondition"]).strip() or not str(d["exitCondition"]).strip(): raise HTTPException(422,"Entry and exit conditions are required.")
    return True

@app.get("/api/strategies")
async def strategies(request: Request):
    user=await current_user(request); q={"user_id":user["id"]}; aid=request.query_params.get("accountId") or request.query_params.get("account_id");
    if aid: q["account_id"]=aid
    return {"success":True,"data":clean(await find_many("strategies",q))}

@app.post("/api/strategies")
async def strategy_create(request: Request):
    user=await current_user(request); d=body_data(await request.json()); validate_strategy(d); doc={**d,"id":rid(),"user_id":user["id"],"account_id":d.get("accountId"),"status":"DRAFT","created_at":now(),"updated_at":now()}; await insert("strategies",doc); return {"success":True,"data":clean(doc)}

@app.get("/api/strategies/{strategy_id}")
async def strategy_get(strategy_id: str, request: Request):
    user=await current_user(request); doc=await find_one("strategies",{"id":strategy_id,"user_id":user["id"]});
    if not doc:
        raise HTTPException(404,"Strategy not found.")
    return {"success":True,"data":clean(doc)}

@app.put("/api/strategies/{strategy_id}")
async def strategy_update(strategy_id: str, request: Request):
    user=await current_user(request); d=body_data(await request.json()); validate_strategy(d); doc=await find_one("strategies",{"id":strategy_id,"user_id":user["id"]});
    if not doc:
        raise HTTPException(404,"Strategy not found.")
    d={k:v for k,v in d.items() if k not in {"id","user_id","created_at"}}
    d["updated_at"]=now()
    await update_one("strategies",{"id":strategy_id,"user_id":user["id"]},{"$set":d})
    return {"success":True,"data":clean(await find_one("strategies",{"id":strategy_id}))}

@app.delete("/api/strategies/{strategy_id}")
async def strategy_delete(strategy_id: str, request: Request):
    user=await current_user(request); doc=await find_one("strategies",{"id":strategy_id,"user_id":user["id"]});
    if not doc:
        raise HTTPException(404,"Strategy not found.")
    await delete_one("strategies",{"id":strategy_id,"user_id":user["id"]})
    return {"success":True}

async def strategy_status(strategy_id,user, status, account_id=None):
    doc=await find_one("strategies",{"id":strategy_id,"user_id":user["id"]});
    if not doc: raise HTTPException(404,"Strategy not found.")
    if status in {"DEPLOYED","RUNNING"} and (CONTROL["kill_switch"] or not CONTROL["strategy_enabled"]): raise HTTPException(423,"Strategies are disabled by Owner Control.")
    if account_id and not doc.get("account_id"): await update_one("strategies",{"id":strategy_id},{"$set":{"account_id":account_id}})
    await update_one("strategies",{"id":strategy_id},{"$set":{"status":status,"updated_at":now()}}); return await find_one("strategies",{"id":strategy_id})

@app.post("/api/strategies/{strategy_id}/activate")
async def strategy_activate(strategy_id:str,request:Request): user=await current_user(request); return {"success":True,"data":clean(await strategy_status(strategy_id,user,"ACTIVE"))}
@app.post("/api/strategies/{strategy_id}/deactivate")
async def strategy_deactivate(strategy_id:str,request:Request): user=await current_user(request); return {"success":True,"data":clean(await strategy_status(strategy_id,user,"STOPPED"))}
@app.post("/api/strategies/{strategy_id}/deploy")
async def strategy_deploy(strategy_id:str,request:Request): user=await current_user(request); d=body_data(await request.json()); return {"success":True,"data":clean(await strategy_status(strategy_id,user,"DEPLOYED",d.get("accountId")))}
@app.post("/api/strategies/{strategy_id}/run")
async def strategy_run(strategy_id:str,request:Request): user=await current_user(request); d=body_data(await request.json()); return {"success":True,"data":clean(await strategy_status(strategy_id,user,"RUNNING",d.get("accountId")))}
@app.post("/api/strategies/{strategy_id}/stop")
async def strategy_stop(strategy_id:str,request:Request): user=await current_user(request); return {"success":True,"data":clean(await strategy_status(strategy_id,user,"STOPPED"))}
@app.post("/api/strategies/{strategy_id}/backtest")
async def strategy_backtest(strategy_id:str,request:Request): user=await current_user(request); d=body_data(await request.json()); d["strategyId"]=strategy_id; return await run_backtest_core(user,d)

# -----------------------------------------------------------------------------
# BACKTEST — REAL HISTORICAL DATA, NO SYNTHETIC PRICE SERIES
# -----------------------------------------------------------------------------
def eval_condition(expr, row):
    # Intentionally small safe DSL; unsupported expressions are rejected, not executed.
    e=str(expr).strip().upper(); price=float(row["Close"]); prev=float(row["PrevClose"])
    if e in {"PRICE > PREVIOUS CLOSE","CLOSE > PREVIOUS CLOSE","PRICE > PREV_CLOSE"}: return price>prev
    if e in {"PRICE < PREVIOUS CLOSE","CLOSE < PREVIOUS CLOSE","PRICE < PREV_CLOSE"}: return price<prev
    m=re.fullmatch(r"PRICE\s*(>|<|>=|<=)\s*([0-9]+(?:\.[0-9]+)?)",e)
    if m:
        n=float(m.group(2)); return {">":price>n,"<":price<n,">=":price>=n,"<=":price<=n}[m.group(1)]
    raise ValueError("Unsupported condition. Supported examples: PRICE > PREVIOUS CLOSE, PRICE < PREVIOUS CLOSE, PRICE > 100.")

async def run_backtest_core(user,d):
    require_fields(d,"symbol","startDate","endDate"); symbol=str(d["symbol"]).upper(); start=d["startDate"]; end=d["endDate"]; capital=float(d.get("initialCapital") or 0); qty=int(d.get("quantity") or 1)
    if capital<=0: raise HTTPException(422,"Initial capital must be positive.")
    if yf is None: raise HTTPException(503,"Historical market-data provider is not installed.")
    try: df=await asyncio.to_thread(yf.download,symbol,start=start,end=end,auto_adjust=False,progress=False)
    except Exception as exc: raise HTTPException(502,f"Historical data request failed: {exc}")
    if df is None or len(df)<2: raise HTTPException(422,"No sufficient historical market data was returned for this symbol/date range.")
    if hasattr(df.columns,"levels"): df.columns=[c[0] if isinstance(c,tuple) else c for c in df.columns]
    trades=[]; equity=capital; in_pos=False; entry=0; entry_date=None; closes=[]
    strategy=None
    if d.get("strategyId"): strategy=await find_one("strategies",{"id":d["strategyId"],"user_id":user["id"]})
    entry_expr=d.get("entryCondition") or (strategy or {}).get("entryCondition") or "PRICE > PREVIOUS CLOSE"; exit_expr=d.get("exitCondition") or (strategy or {}).get("exitCondition") or "PRICE < PREVIOUS CLOSE"
    try:
        for idx,(ts,row) in enumerate(df.iterrows()):
            close=float(row["Close"]); prev=float(df.iloc[idx-1]["Close"]) if idx else close; closes.append(close); item={"Close":close,"PrevClose":prev}
            if not in_pos and idx and eval_condition(entry_expr,item): entry=close; entry_date=str(ts); in_pos=True
            elif in_pos and idx and eval_condition(exit_expr,item):
                pnl=(close-entry)*qty; equity+=pnl; trades.append({"entryDate":entry_date,"exitDate":str(ts),"entryPrice":entry,"exitPrice":close,"quantity":qty,"pnl":pnl}); in_pos=False
        if in_pos:
            close=closes[-1]; pnl=(close-entry)*qty; equity+=pnl; trades.append({"entryDate":entry_date,"exitDate":str(df.index[-1]),"entryPrice":entry,"exitPrice":close,"quantity":qty,"pnl":pnl,"forcedExit":True})
    except ValueError as exc: raise HTTPException(422,str(exc))
    pnl=equity-capital; wins=sum(1 for t in trades if t["pnl"]>0); losses=sum(1 for t in trades if t["pnl"]<0); peak=capital; dd=0; curve=[]
    running=capital
    for t in trades: running+=t["pnl"]; peak=max(peak,running); dd=max(dd,peak-running); curve.append({"date":t["exitDate"],"equity":running})
    doc={"id":rid(),"user_id":user["id"],"account_id":d.get("accountId"),"strategy_id":d.get("strategyId"),"symbol":symbol,"start_date":start,"end_date":end,"initial_capital":capital,"final_equity":equity,"net_pnl":pnl,"return_pct":(pnl/capital*100),"trade_count":len(trades),"win_rate":(wins/len(trades)*100 if trades else 0),"max_drawdown":dd,"trades":trades,"equity_curve":curve,"data_source":"yfinance historical market data","created_at":now()}; await insert("backtests",doc); return {"success":True,"data":clean(doc)}

@app.post("/api/backtest")
async def backtest_run(request:Request): user=await current_user(request); return await run_backtest_core(user,body_data(await request.json()))
@app.get("/api/backtest")
async def backtest_history(request:Request): user=await current_user(request); return {"success":True,"data":clean(await find_many("backtests",{"user_id":user["id"]}))}
@app.get("/api/backtest/{backtest_id}")
async def backtest_result(backtest_id: str, request: Request):
    user = await current_user(request)
    doc = await find_one("backtests", {"id": backtest_id, "user_id": user["id"]})
    if not doc: raise HTTPException(404, "Backtest result not found.")
    return {"success": True, "data": clean(doc)}

# -----------------------------------------------------------------------------
# RISK ENGINE
# -----------------------------------------------------------------------------
@app.get("/api/risk")
async def risk_get(request: Request):
    user=await current_user(request); aid=request.query_params.get("accountId") or request.query_params.get("account_id");
    if not aid: return {"success":True,"data":clean(DEFAULT_RISK)}
    doc=await find_one("risk",{"user_id":user["id"],"account_id":aid}); return {"success":True,"data":clean(doc or {"user_id":user["id"],"account_id":aid,**DEFAULT_RISK})}

@app.put("/api/risk")
async def risk_update(request: Request):
    user=await current_user(request); d=body_data(await request.json()); aid=d.get("accountId") or d.get("account_id");
    if not aid: raise HTTPException(422,"accountId is required.")
    cfg={k:v for k,v in d.items() if k in DEFAULT_RISK}; cfg.update({"id":rid(),"user_id":user["id"],"account_id":aid,"updated_at":now()}); await update_one("risk",{"user_id":user["id"],"account_id":aid},{"$set":cfg},upsert=True); return {"success":True,"data":clean(cfg)}

@app.get("/api/risk/status")
async def risk_status(request: Request):
    user=await current_user(request); aid=request.query_params.get("accountId") or request.query_params.get("account_id"); cfg=(await find_one("risk",{"user_id":user["id"],"account_id":aid})) if aid else None
    return {"success":True,"data":{"enabled":(cfg or DEFAULT_RISK).get("enabled",True),"kill_switch":CONTROL["kill_switch"],"trading_enabled":CONTROL["trading_enabled"]}}

@app.post("/api/risk/validate")
@app.post("/api/risk/check")
async def risk_validate(request: Request):
    user=await current_user(request); d=body_data(await request.json()); aid=d.get("accountId") or d.get("account_id"); await account_for(user,aid); await risk_check(user,aid,d); return {"success":True,"data":{"allowed":True}}

# -----------------------------------------------------------------------------
# OWNER CONTROL
# -----------------------------------------------------------------------------
@app.get("/api/owner-control")
async def owner_status(request: Request):
    user=await current_user(request); owner_only(user); return {"success":True,"data":CONTROL}

@app.put("/api/owner-control")
async def owner_update(request: Request):
    user=await current_user(request); owner_only(user); d=body_data(await request.json())
    for k in ("trading_enabled","strategy_enabled","orders_enabled"):
        if k in d: CONTROL[k]=bool(d[k])
    return {"success":True,"data":CONTROL}

@app.post("/api/owner-control/kill-switch")
async def kill_switch(request: Request):
    user=await current_user(request); owner_only(user); d=body_data(await request.json()); CONTROL["kill_switch"]=bool(d.get("enabled",True)); CONTROL["reason"]=str(d.get("reason") or "");
    if CONTROL["kill_switch"]: CONTROL["trading_enabled"]=False
    else: CONTROL["trading_enabled"]=True
    audit("owner.kill_switch",user["id"],status="enabled" if CONTROL["kill_switch"] else "disabled",detail=CONTROL["reason"]); return {"success":True,"data":CONTROL}

@app.post("/api/owner-control/cancel-all-orders")
async def cancel_all(request: Request):
    user=await current_user(request); owner_only(user); accounts=await find_many("broker_accounts",{"user_id":user["id"]}); out=[]
    for account in accounts:
        if account["id"] not in BROKER_SESSIONS: continue
        try:
            orders=list_data(await broker_data(account,"order_report"))
            for o in orders:
                status=str(o.get("ordSt") or o.get("stat") or "").lower()
                oid_b=o.get("nOrdNo") or o.get("order_id")
                if oid_b and status not in {"complete","traded","cancelled","rejected"}:
                    out.append(clean(await broker_data(account,"cancel_order",order_id=str(oid_b))))
        except Exception as exc: out.append({"account_id":account["id"],"error":str(exc)})
    audit("owner.cancel_all_orders",user["id"]); return {"success":True,"data":out}

@app.post("/api/owner-control/square-off-all")
async def square_off_all(request: Request):
    user=await current_user(request); owner_only(user); accounts=await find_many("broker_accounts",{"user_id":user["id"]}); out=[]
    for account in accounts:
        if account["id"] not in BROKER_SESSIONS: continue
        try:
            positions=list_data(await broker_data(account,"positions"))
            for p in positions:
                qty=int(float(p.get("netQty") or p.get("netqty") or p.get("quantity") or p.get("qty") or 0));
                if qty==0: continue
                side="S" if qty>0 else "B"; symbol=p.get("trdSym") or p.get("trading_symbol") or p.get("symbol"); exchange=p.get("exSeg") or p.get("exchange_segment") or "nse_cm"; product=p.get("prod") or p.get("product") or "CNC"
                if symbol:
                    out.append(clean(await broker_data(account,"place_order",exchange_segment=normalize_exchange(exchange),product=product,price="0",order_type="MKT",quantity=str(abs(qty)),validity="DAY",trading_symbol=symbol,transaction_type=side)))
        except Exception as exc: out.append({"account_id":account["id"],"error":str(exc)})
    audit("owner.square_off_all",user["id"]); return {"success":True,"data":out}

# -----------------------------------------------------------------------------
# LOGS / SYSTEM
# -----------------------------------------------------------------------------
@app.get("/api/logs")
async def logs(request: Request):
    user=await current_user(request); q={"user_id":user["id"]}; severity=request.query_params.get("severity");
    docs=await find_many("audit_logs",q,limit=min(int(request.query_params.get("limit",100)),500));
    if severity: docs=[d for d in docs if str(d.get("status")).lower()==severity.lower()]
    return {"success":True,"data":clean(docs)}

@app.get("/api/logs/categories")
async def log_categories(request: Request): await current_user(request); return {"success":True,"data":["auth","broker","order","strategy","backtest","risk","owner","system"]}

@app.get("/api/system/status")
async def system_status(request: Request):
    user=await current_user(request); accounts=await find_many("broker_accounts",{"user_id":user["id"]}); connected=sum(1 for a in accounts if a.get("id") in BROKER_SESSIONS); db_ok=_db is not None
    return {"success":True,"data":{"status":"healthy" if db_ok else "degraded","database":"connected" if db_ok else "unavailable","broker":{"total":len(accounts),"connected":connected},"owner_control":CONTROL,"timestamp":iso()}}

# -----------------------------------------------------------------------------
# PLUGINS
# -----------------------------------------------------------------------------
@app.get("/api/plugins")
async def plugins(request:Request):
    await current_user(request); return {"success":True,"data":[{"id":"kotak_neo","plugin_id":"kotak_neo","name":"Kotak Neo","type":"broker","enabled":True,"status":"available"}]}
@app.post("/api/plugins")
async def plugin_register(request:Request):
    user=await current_user(request); owner_only(user); d=body_data(await request.json()); require_fields(d,"name")
    doc={"id":d.get("id") or rid(),"name":d["name"],"plugin_id":d.get("plugin_id") or d.get("id") or rid(),"enabled":False,"status":"registered","created_at":now()}
    await insert("plugins",doc); return {"success":True,"data":clean(doc)}

@app.get("/api/plugins/{plugin_id}")
async def plugin_get(plugin_id:str,request:Request):
    await current_user(request)
    doc=await find_one("plugins",{"id":plugin_id})
    if doc: return {"success":True,"data":clean(doc)}
    return {"success":True,"data":{"id":plugin_id,"enabled":plugin_id=="kotak_neo","status":"available" if plugin_id=="kotak_neo" else "unavailable"}}
@app.post("/api/plugins/{plugin_id}/enable")
async def plugin_enable(plugin_id:str,request:Request):
    user=await current_user(request); owner_only(user)
    if plugin_id!="kotak_neo": await update_one("plugins",{"id":plugin_id},{"$set":{"enabled":True,"status":"enabled"}},upsert=False)
    return {"success":True,"data":{"id":plugin_id,"enabled":True}}
@app.post("/api/plugins/{plugin_id}/disable")
async def plugin_disable(plugin_id:str,request:Request):
    user=await current_user(request); owner_only(user)
    if plugin_id=="kotak_neo": raise HTTPException(409,"Kotak Neo core broker cannot be disabled.")
    await update_one("plugins",{"id":plugin_id},{"$set":{"enabled":False,"status":"disabled"}}); return {"success":True,"data":{"id":plugin_id,"enabled":False}}

@app.delete("/api/plugins/{plugin_id}")
async def plugin_remove(plugin_id:str,request:Request):
    user=await current_user(request); owner_only(user)
    if plugin_id=="kotak_neo": raise HTTPException(409,"Kotak Neo is a core broker and cannot be removed.")
    await delete_one("plugins",{"id":plugin_id}); return {"success":True}

# -----------------------------------------------------------------------------
# AI — REAL PROVIDERS ONLY; NO FABRICATED CHAT/HEALTH
# -----------------------------------------------------------------------------
AI_PROVIDERS={"openai":{"name":"OpenAI","env":"OPENAI_API_KEY"},"anthropic":{"name":"Anthropic","env":"ANTHROPIC_API_KEY"},"google":{"name":"Google Gemini","env":"GOOGLE_API_KEY"}}
@app.get("/api/ai/providers")
async def ai_providers(request:Request):
    user=await current_user(request); docs=await find_many("ai_providers",{"user_id":user["id"]}); saved={d["provider"]:d for d in docs}; out=[]
    for pid,meta in AI_PROVIDERS.items(): out.append({"id":pid,"provider_id":pid,"name":meta["name"],"configured":bool(saved.get(pid) or os.getenv(meta["env"])),"models":[]})
    return {"success":True,"data":out}
@app.get("/api/ai/providers/{provider_id}")
async def ai_provider(provider_id:str,request:Request):
    await current_user(request); data=(await ai_providers(request))["data"]; item=next((x for x in data if x["id"]==provider_id),None)
    if not item: raise HTTPException(404,"AI provider not found.")
    return {"success":True,"data":item}
@app.put("/api/ai/providers/{provider_id}")
async def ai_configure(provider_id:str,request:Request):
    user=await current_user(request); d=body_data(await request.json()); key=d.get("api_key") or d.get("key");
    if not key: raise HTTPException(422,"API key is required.")
    await update_one("ai_providers",{"user_id":user["id"],"provider":provider_id},{"$set":{"id":rid(),"user_id":user["id"],"provider":provider_id,"api_key":enc(key),"updated_at":now()}},upsert=True); return {"success":True,"data":{"provider":provider_id,"configured":True}}
@app.post("/api/ai/providers/{provider_id}/test")
async def ai_test(provider_id:str,request:Request):
    user=await current_user(request); doc=await find_one("ai_providers",{"user_id":user["id"],"provider":provider_id}); configured=bool(doc or os.getenv(AI_PROVIDERS.get(provider_id,{}).get("env",""))); return {"success":True,"data":{"provider":provider_id,"configured":configured,"status":"configured" if configured else "unavailable"}}
@app.get("/api/ai/health")
async def ai_health(request:Request): return {"success":True,"data":(await ai_providers(request))["data"]}
@app.post("/api/ai/default")
async def ai_default(request:Request):
    user=await current_user(request); d=body_data(await request.json()); await update_one("settings",{"user_id":user["id"]},{"$set":{"default_provider":d.get("provider") or d.get("default_provider"),"default_model":d.get("model") or d.get("default_model"),"updated_at":now()}},upsert=True); return {"success":True,"data":d}
@app.post("/api/ai/chat")
async def ai_chat(request:Request):
    user=await current_user(request); d=body_data(await request.json()); prompt=d.get("message") or d.get("prompt");
    if not prompt: raise HTTPException(422,"Message is required.")
    provider=d.get("provider") or d.get("default_provider") or "openai"; key_doc=await find_one("ai_providers",{"user_id":user["id"],"provider":provider}); key=dec(key_doc["api_key"]) if key_doc else os.getenv(AI_PROVIDERS.get(provider,{}).get("env",""))
    if not key: raise HTTPException(503,f"AI provider '{provider}' is not configured.")
    if provider=="openai":
        try:
            from openai import OpenAI
            model=d.get("model") or os.getenv("OPENAI_MODEL", "")
            if not model: raise RuntimeError("OPENAI_MODEL is not configured")
            client=OpenAI(api_key=key); result=await asyncio.to_thread(client.responses.create,model=model,input=prompt); text=getattr(result,"output_text",None) or ""
            if not text: raise RuntimeError("Provider returned no text")
            return {"success":True,"data":{"provider":provider,"message":text}}
        except Exception as exc: raise HTTPException(502,f"AI provider request failed: {exc}")
    raise HTTPException(501,f"Provider '{provider}' is configured but its chat adapter is not enabled in this backend build.")
@app.get("/api/ai/usage")
async def ai_usage(request:Request): user=await current_user(request); return {"success":True,"data":[]}

# AI preset CRUD (kept in the same backend file)
@app.get("/api/ai/presets")
async def presets(request:Request): user=await current_user(request); return {"success":True,"data":clean(await find_many("ai_presets",{"user_id":user["id"]}))}
@app.post("/api/ai/presets")
async def preset_create(request:Request): user=await current_user(request); d=body_data(await request.json()); require_fields(d,"name","prompt"); doc={**d,"id":rid(),"user_id":user["id"],"created_at":now(),"updated_at":now()}; await insert("ai_presets",doc); return {"success":True,"data":clean(doc)}
@app.put("/api/ai/presets/{preset_id}")
async def preset_update(preset_id:str,request:Request): user=await current_user(request); d=body_data(await request.json()); d["updated_at"]=now(); await update_one("ai_presets",{"id":preset_id,"user_id":user["id"]},{"$set":d}); return {"success":True,"data":clean(await find_one("ai_presets",{"id":preset_id,"user_id":user["id"]}))}
@app.delete("/api/ai/presets/{preset_id}")
async def preset_delete(preset_id:str,request:Request): user=await current_user(request); await delete_one("ai_presets",{"id":preset_id,"user_id":user["id"]}); return {"success":True}

# -----------------------------------------------------------------------------
# OPTIONAL WEBSOCKET HEALTH/STATUS CHANNEL — NO FABRICATED TICKS
# -----------------------------------------------------------------------------
@app.websocket("/ws/system")
async def ws_system(ws:WebSocket):
    await ws.accept()
    try:
        while True:
            await ws.send_json({"type":"system","timestamp":iso(),"connected_accounts":len(BROKER_SESSIONS)})
            await asyncio.sleep(5)
    except (WebSocketDisconnect, asyncio.CancelledError): return

@app.exception_handler(Exception)
async def unhandled(request:Request, exc:Exception):
    log.exception("Unhandled backend exception")
    return JSONResponse(status_code=500, content={"error":{"code":"INTERNAL_ERROR","message":"Internal server error."}})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app",host="127.0.0.1",port=int(os.getenv("PORT","8000")),workers=1)
