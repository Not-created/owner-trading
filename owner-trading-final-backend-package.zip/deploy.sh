#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"
APP_NAME="owner-trading"
VENV_DIR="$APP_DIR/.venv"
DIST_DIR="$APP_DIR/dist"
BACKEND_DIR="$APP_DIR/backend"
ENV_FILE="$BACKEND_DIR/.env"
SERVICE="${APP_NAME}-backend"
log(){ printf '\n[OWNER-TRADING] %s\n' "$*"; }
fail(){ printf '\n[OWNER-TRADING][ERROR] %s\n' "$*" >&2; exit 1; }
has(){ command -v "$1" >/dev/null 2>&1; }

[[ -f package.json ]] || fail "package.json not found."
[[ -f index.html ]] || fail "index.html not found at project root."
[[ -f src/index.jsx ]] || fail "src/index.jsx not found."
[[ -f src/App.jsx ]] || fail "src/App.jsx not found."
[[ -f backend/server.py ]] || fail "backend/server.py not found."

if [[ $EUID -ne 0 ]]; then
  has sudo || fail "Run as root or install sudo."
  exec sudo -E bash "$0" "$@"
fi

has node || fail "Node.js is required."
has npm || fail "npm is required."
has python3 || fail "Python 3 is required."
has curl || fail "curl is required."
[[ "$(node -p 'process.versions.node.split(".")[0]')" -ge 20 ]] || fail "Node.js 20+ required."

log "Installing required OS packages..."
apt-get update -y >/dev/null
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv python3-pip nginx curl openssl build-essential >/dev/null

log "Installing frontend dependencies and building..."
if [[ -f package-lock.json ]]; then npm ci --no-audit --no-fund; else npm install --no-audit --no-fund; fi
rm -rf "$DIST_DIR"
npm run build
[[ -f "$DIST_DIR/index.html" ]] || fail "Frontend build failed."

log "Preparing Python environment..."
python3 -m venv "$VENV_DIR" 2>/dev/null || true
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip >/dev/null
python -m pip install --upgrade \
  'fastapi>=0.115,<1' 'uvicorn[standard]>=0.30,<1' \
  'motor>=3.6,<4' 'pymongo>=4.9,<5' 'bcrypt>=4.1,<6' \
  'PyJWT>=2.8,<3' 'cryptography>=43,<50' 'python-dotenv>=1.0,<2' \
  'yfinance>=0.2.54,<0.3' 'kotakneoapi==3.0.1' >/dev/null

log "Creating backend environment only when it does not already exist..."
mkdir -p "$BACKEND_DIR"
if [[ ! -f "$ENV_FILE" ]]; then
  JWT_SECRET_GEN="$(openssl rand -hex 32)"
  ENCRYPTION_KEY_GEN="$($VENV_DIR/bin/python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  read -r -p "Owner username: " OWNER_USERNAME
  read -r -s -p "Owner password (min 8 chars): " OWNER_PASSWORD; echo
  [[ ${#OWNER_PASSWORD} -ge 8 ]] || fail "Owner password must be at least 8 characters."
  read -r -p "Owner email: " OWNER_EMAIL
  read -r -p "Mongo URL [mongodb://localhost:27017]: " MONGO_URL_IN
  MONGO_URL_IN="${MONGO_URL_IN:-mongodb://localhost:27017}"
  read -r -p "Database name [owner_trading_db]: " DB_NAME_IN
  DB_NAME_IN="${DB_NAME_IN:-owner_trading_db}"
  read -r -p "Public frontend URL [http://localhost]: " FRONTEND_URL_IN
  FRONTEND_URL_IN="${FRONTEND_URL_IN:-http://localhost}"
  cat > "$ENV_FILE" <<EOF
MONGO_URL="$MONGO_URL_IN"
DB_NAME="$DB_NAME_IN"
JWT_SECRET="$JWT_SECRET_GEN"
ENCRYPTION_KEY="$ENCRYPTION_KEY_GEN"
OWNER_USERNAME="$OWNER_USERNAME"
OWNER_PASSWORD="$OWNER_PASSWORD"
OWNER_EMAIL="$OWNER_EMAIL"
FRONTEND_URL="$FRONTEND_URL_IN"
CORS_ORIGINS="$FRONTEND_URL_IN"
COOKIE_SECURE="false"
COOKIE_SAMESITE="lax"
ENVIRONMENT="production"
EOF
  chmod 600 "$ENV_FILE"
else
  chmod 600 "$ENV_FILE"
  log "Existing backend/.env preserved."
fi

log "Validating backend syntax..."
$VENV_DIR/bin/python -m py_compile "$BACKEND_DIR/server.py"

log "Installing systemd service..."
cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=Owner Trading Backend
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$BACKEND_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$VENV_DIR/bin/uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl restart "$SERVICE"

log "Waiting for backend health..."
for _ in $(seq 1 30); do curl -fsS http://127.0.0.1:8000/api/health >/dev/null 2>&1 && break; sleep 1; done
curl -fsS http://127.0.0.1:8000/api/health >/dev/null || { journalctl -u "$SERVICE" -n 80 --no-pager; fail "Backend health check failed."; }

log "Installing Nginx reverse proxy..."
SERVER_NAME="${OWNER_TRADING_DOMAIN:-_}"
cat > /etc/nginx/sites-available/owner-trading <<EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name $SERVER_NAME;
    root $DIST_DIR;
    index index.html;
    client_max_body_size 10m;

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /ws/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF
ln -sfn /etc/nginx/sites-available/owner-trading /etc/nginx/sites-enabled/owner-trading
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable nginx >/dev/null
systemctl reload nginx

log "Final checks..."
curl -fsS http://127.0.0.1:8000/api/health >/dev/null
curl -fsS http://127.0.0.1/ >/dev/null
systemctl is-active --quiet "$SERVICE"
systemctl is-active --quiet nginx

printf '\n============================================================\n'
printf ' OWNER TRADING — DEPLOYMENT COMPLETE\n'
printf '============================================================\n'
printf 'Frontend : %s\n' "$DIST_DIR"
printf 'Backend  : %s\n' "$BACKEND_DIR/server.py"
printf 'API      : http://127.0.0.1:8000\n'
printf 'Service  : %s\n' "$SERVICE"
printf 'Nginx    : active\n'
printf 'Secrets  : preserved at %s\n' "$ENV_FILE"
printf '============================================================\n'
